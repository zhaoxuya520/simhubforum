#!/usr/bin/env python3
"""Pin accepted-SDP observation and the UPDATE builder without changing native call control."""
from pathlib import Path
import argparse, json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from sip_precondition_patch import verify_sip_precondition, reverse_sip_precondition, PINS, _method, EDITS
p = argparse.ArgumentParser()
p.add_argument('decoded', type=Path)
p.add_argument('--report', type=Path)
a = p.parse_args()
smali = a.decoded/'smali' if (a.decoded/'smali').is_dir() else a.decoded
report = verify_sip_precondition(smali)
# Exact reversal checks the complete h/k methods, including all old hooks and original instructions.
for name, signature in PINS:
    text = (smali/name).read_text()
    original = reverse_sip_precondition(name, text)
    assert reverse_sip_precondition(name, original) == original
    # Every partial hook and orphan marker must fail closed.
    for old, new in EDITS[name]:
        broken = text.replace(new, old, 1)
        if len(EDITS[name]) == 1:
            broken += '\n# sip_early_precondition_orphan\n'
        try:
            reverse_sip_precondition(name, broken)
        except AssertionError:
            pass
        else:
            raise AssertionError(name + ': partial hook accepted')
    try:
        reverse_sip_precondition(name, original + '\n# sip_early_precondition_orphan\n')
    except AssertionError:
        pass
    else:
        raise AssertionError(name + ': orphan marker accepted')
engine = (smali/'o82.smali').read_text()
body = _method(engine, 'public final h(Lkb4;)Z')[2]
observe = body.index('SipEarlyPrecondition;->observe')
assert body.rfind('iput-object v4, v3, Lma4;->p:[B', 0, observe) > body.rfind(':cond_1e', 0, observe)
assert body.index('const-string v4, "RSeq"', observe) > observe
manager = (smali/'cb4.smali').read_text()
builder = _method(manager, 'public final k(Ljava/lang/String;Lma4;[B)Lkb4;')[2]
assert builder.count('move-object v5, p2') == 1
assert builder.index('move-object v5, p2') < builder.index('new-instance p2, Ljava/lang/StringBuilder;')
assert builder.index('SipEarlyPrecondition;->decorate') > builder.index('iput-object p3, v0, Lkb4;->g:[B')
assert builder.count('return-object v0') == 1
report['partial_and_orphan_hooks_rejected'] = True
report['native_abi_pinned'] = True
if a.report:
    a.report.write_text(json.dumps(report, indent=2)+'\n')
print('PASS: negotiated early SDP precondition hooks; exact h/k reversal and partial-marker rejection')
