#!/usr/bin/env python3
"""Check the bounded native SMSC entry patch and its unchanged sender guard."""
from pathlib import Path
import argparse,hashlib,json,re,sys

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from smsc_editor_patch import (
    TARGET,SIGNATURE,METHOD_SHA256,ORIGINAL_SHA256,ORIGINAL_REGION,NEW_REGION,
    HOOK,method,transform,reverse_smsc_editor,verify_smsc_editor,
)

p=argparse.ArgumentParser()
p.add_argument('decoded',type=Path,nargs='?',default=ROOT/'build-config3/apktool')
p.add_argument('--baseline',action='store_true',help='test transformation in memory against an unpatched decoded input')
p.add_argument('--report',type=Path)
a=p.parse_args();smali=a.decoded/'smali' if (a.decoded/'smali').is_dir() else a.decoded
source=(smali/TARGET).read_text();patched=transform(source) if a.baseline else source
restored=transform(patched,True)
assert hashlib.sha256(restored.encode()).hexdigest()==ORIGINAL_SHA256,'unrelated mc0 instructions changed'
assert transform(restored)==patched
assert reverse_smsc_editor('unrelated.smali','unchanged')=='unchanged'

def rejects(label,action):
    try:action()
    except AssertionError:return
    raise AssertionError('accepted '+label)

rejects('double apply',lambda:transform(patched))
rejects('missing state preservation',lambda:transform(patched.replace('    move-object/from16 v60, v7\n    const/4 v14, 0x0\n    if-nez v0, :sms_center_editor_skip',
    '    const/4 v14, 0x0\n    if-nez v0, :sms_center_editor_skip',1),True))
rejects('wrong composer register',lambda:transform(patched.replace('invoke-static {v6, v10}, '+HOOK,'invoke-static {v6, v11}, '+HOOK,1),True))
rejects('unrelated method edit',lambda:transform(patched.replace('    .locals 75','    .locals 76',1),True))

_,_,old_method=method(restored);_,_,new_method=method(patched)
start=old_method.index(ORIGINAL_REGION);end=start+len(ORIGINAL_REGION)
inside=set(re.findall(r'^\s*(:\w+)\s*$',ORIGINAL_REGION,re.M))
outside=old_method[:start]+old_method[end:]
external={label for label in inside if re.search(re.escape(label)+r'(?=\s|$)',outside)}
assert external=={':goto_e'},'removed region gained another external branch target'
assert '.catch' not in old_method,'new exception edge needs explicit review'
assert new_method.count(HOOK)==1
assert NEW_REGION+'    :goto_16\n' in new_method
assert '    iget-object v6, v7, Lgl5;->i:Ljava/lang/String;' in new_method[:start]
assert '    iget-object v0, v0, Lek5;->f:Ljava/lang/String;' in new_method[:start]
assert 'new-instance v6, Ljg5;' in ORIGINAL_REGION and 'const/16 v7, 0xc' in ORIGINAL_REGION
assert 'Lro;->b(' in ORIGINAL_REGION and '0x42300000    # 44.0f' in ORIGINAL_REGION
assert new_method.count('Lro;->b(')==old_method.count('Lro;->b(')-1,'removed another text field or retained SMS keystroke callback'
for label in inside-{':goto_e'}:
    assert not re.search(re.escape(label)+r'(?=\s|$)',new_method),'deleted native SMS branch label still referenced'

# Interpret the actual small replacement, with sentinels, to verify the native
# condition, its arguments, and required live-out values on both paths.
ops=[s.strip() for s in NEW_REGION.splitlines() if s.strip()]
for card_smsc in (None,'+447000000001'):
    regs={'v0':card_smsc,'v6':'current-text','v7':object(),'v10':object(),'v14':99,'v60':None}
    state,composer=regs['v7'],regs['v10'];calls=[];pc=0
    while pc<len(ops):
        op=ops[pc];pc+=1
        if op.startswith(':'):continue
        if op.startswith('move-object/from16 '):
            dst,src=op.split(' ',1)[1].split(', ');regs[dst]=regs[src]
        elif op.startswith('const/4 '):
            dst,value=op.split(' ',1)[1].split(', ');regs[dst]=int(value,0)
        elif op.startswith('if-nez '):
            src,label=op.split(' ',1)[1].split(', ')
            if regs[src] is not None:pc=ops.index(label)
        elif op.startswith('invoke-static '):
            arguments=op.split('{',1)[1].split('}',1)[0].split(', ');calls.append([regs[r] for r in arguments])
        else:raise AssertionError('unreviewed replacement instruction '+op)
    assert regs['v60'] is state and regs['v14']==0
    assert calls==([['current-text',composer]] if card_smsc is None else [])

sender=(smali/'zl5.smali').read_text();signature='.method public final w(Ljava/lang/String;Ljava/lang/String;Ldt0;)Ljava/lang/Object;'
s=sender.index(signature);e=sender.index('.end method',s);send_method=sender[s:e]
guard=('Lcc/forserein/simhub/internal/WifiConfigRuntime;->requireSmsCenter()V' if a.baseline else
       'Lcc/forserein/simhub/internal/WifiConfigRuntime;->prepareSmsCenter(Ljava/lang/Object;)Ljava/lang/String;')
assert send_method.count(guard)==1 and send_method.index(guard)<send_method.index('Lo82;->D('),'SMS send validation removed or moved after send'
if not a.baseline:
    assert 'invoke-static {v5}, '+guard+'\n    move-result-object v0' in send_method
    assert 'invoke-virtual {v5, v14, v15, v0, v1}, Lo82;->D(' in send_method

if not a.baseline:
    verify_smsc_editor(smali)
    helper=(smali/'cc/forserein/simhub/internal/WifiConfigEditor.smali').read_text()
    assert '.method public static smsCenterEntry(Ljava/lang/String;Ljava/lang/Object;)V' in helper,'entry helper absent from final DEX sources'

report=dict(native_method=SIGNATURE,method_pin=METHOD_SHA256,whole_class_reverse_sha256=ORIGINAL_SHA256,
    unrelated_instructions_restored_exactly=True,original_entry_condition_preserved=True,
    removed_region_has_no_other_external_entry=True,state_and_composer_arguments_checked=True,
    missing_smsc_path_calls_editor_once=True,builtin_smsc_path_skips_entry=True,
    required_live_out_values_preserved=['v14','v60'],old_keystroke_input_removed=True,
    sms_send_guard_preserved=True,negative_tamper_checks=4,in_memory_transform=a.baseline,
    helper_in_compiled_smali_checked=not a.baseline,device_tested=False)
if a.report:a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(report,indent=2)+'\n')
print('PASS: reversible native SMS editor entry; branch/register preservation, old onChange removal and sender guard checked')
