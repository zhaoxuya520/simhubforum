#!/usr/bin/env python3
"""Check actual shipped catalogue keys and pinned reflection contracts used by the picker."""
from pathlib import Path
import re,json,sys
r=Path(sys.argv[1]);smali=r/'smali';root=Path(__file__).resolve().parents[1];checks=0
def check(b,msg):
 global checks
 assert b,msg
 checks+=1
for name,sig in [('fj5','a()Ljava/util/List;'),('fj5','b()Lej5;'),('zl3','i(Lbj5;Lek5;)Lxi5;')]:
 check(bool(re.search(r'^\.method public [^\n]* '+re.escape(sig)+r'$',(smali/(name+'.smali')).read_text(),re.M)),name+'.'+sig)
for name,fields in {'ej5':{'a':'Ljava/util/List;'},'bj5':{k:'Ljava/lang/String;' for k in ('a','b','c','d','e','q')},'cj5':{k:'Ljava/lang/String;' for k in 'abcde'},'zi5':{'a':'Ljava/util/Map;'},'yi5':{'a':'Ljava/lang/String;','b':'Ljava/lang/Boolean;','c':'Lak5;','d':'Lyj5;','e':'Ljava/lang/String;','f':'Ljava/lang/String;','g':'Ljava/lang/Boolean;'},'yj5':{'u':'Z'},'ek5':{'a':'Ljava/lang/String;','b':'Ljava/lang/String;','h':'Lz82;'},'z82':{k:'Ljava/lang/String;' for k in 'abc'}}.items():
 s=(smali/(name+'.smali')).read_text()
 for field,typ in fields.items():check(bool(re.search(r'^\.field public [^\n]*\b'+re.escape(field+':'+typ)+r'$',s,re.M)),name+'.'+field+' type')
asset=json.loads((r/'assets/vowifi/carrier_presets.json').read_text());presets=asset['presets'];keys=set()
for p in presets:
 key=p['plmn']+'|'+p['id'];check(bool(re.fullmatch(r'[0-9]{5,6}\|[A-Za-z0-9_.-]{1,200}',key)),key+' serializable')
 check(key not in keys,key+' unique');keys.add(key)
dito=[p for p in presets if p['plmn']=='51566']
check(len(dito)==1 and dito[0]['id']=='apple_dito_ph','dedicated reference DITO preset can be selected by stable key')
check(dito[0]['localIdentifier']=='0$imsi@nai.epc.mnc$mnc.mcc$mcc.3gppnetwork.org','DITO template uses actual IMSI placeholders')
directory=json.loads((r/'assets/data/mcc_mnc.json').read_text());check(any(row[:3]==['515','66','PH'] and row[4]=='DITO' for row in directory),'DITO name and country metadata present')
source=(root/'src/cc/forserein/simhub/internal/WifiConfigEditor.java').read_text()
check('if(mode==20)row("运营商"' in source,'picker visible from existing WiFi config section')
check('action("搜索"' in source and 'CarrierPresets.PAGE_SIZE' in source,'explicit search and bounded result page')
check('s.snapshot=saved;' in source and 's.draft=new WifiConfigDraft(saved.values)' in source,'next edit/reset follows newly selected defaults')
result={'checks':checks,'catalogue_presets':len(presets),'searchable_keys':len(keys),'dito_key':'51566|apple_dito_ph','legacy_dito_key_alias':'51566|standard_plmn_51566','real_imsi_template':True,'device_tested':False}
(root/'build-config3/carrier-picker-integration.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS:',checks,'native carrier adapter/catalogue checks;',len(keys),'selectable preset keys')
