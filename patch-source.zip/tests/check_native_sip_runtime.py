#!/usr/bin/env python3
"""Use the final APK's verified carrier-translated jar to run native SIP checks."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('apk',type=Path);p.add_argument('decoded',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1]
carrier_report=a.report.parent/'native-carrier-runtime.json'
report=json.loads(carrier_report.read_text())
digest=hashlib.sha256(a.apk.read_bytes()).hexdigest()
assert report['apk_sha256']==digest,'Carrier-translated jar must correspond to this exact final APK'
jar=carrier_report.parent/'native-carrier-current/probe.jar';assert jar.is_file(),jar
sys.path.insert(0,str(root));from sip_session_timer_patch import verify_sip_session_timer
from sip_fork_patch import reverse_sip_fork
verify_sip_session_timer(a.decoded/'smali',reverse_sip_fork)
subprocess.run([sys.executable,str(root/'validation/native-sip/sip_check_runtime.py'),str(jar),'--report',str(a.report)],check=True)
result=json.loads(a.report.read_text());result['apk_sha256']=digest;result['carrier_translation_report_sha256']=hashlib.sha256(carrier_report.read_bytes()).hexdigest();result['final_apk_executed']=True
a.report.write_text(json.dumps(result,indent=2)+'\n')
