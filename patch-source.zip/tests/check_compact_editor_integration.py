#!/usr/bin/env python3
"""Check new UI callbacks against the real supplied native Compose and SMS entry contracts."""
from pathlib import Path
import re,sys
r=Path(sys.argv[1]);root=Path(__file__).resolve().parents[1]
s=(r/'smali/rt.smali').read_text();sig='.method public final d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;'
method=s[s.index(sig):s.index('.end method',s.index(sig))]
assert method.index('WifiConfigEditor;->listSection')<method.index('packed-switch'), 'network/device hook must run before old inline dispatch'
s=(r/'smali/dm5.smali').read_text();method=s[s.index(sig):s.index('.end method',s.index(sig))]
assert method.index('WifiConfigEditor;->listSection')<method.index('packed-switch'), 'ePDG nested renderer uses same popup'
assert 'iget v0, v0, Ldm5;->T:I' in method and 'if-nez v0, :compact_epdg_original' in method
assert '    goto/16 :cond_6' in method, 'obsolete inline Apply not displayed'
s=(r/'smali/zl5.smali').read_text();sig='.method public final w(Ljava/lang/String;Ljava/lang/String;Ldt0;)Ljava/lang/Object;'
method=s[s.index(sig):s.index('.end method',s.index(sig))]
a=method.index('WifiConfigRuntime;->requireSmsCenter()V')
assert method.index(':try_start_1')<a<method.index(':try_end_1') and a<method.index('Lo82;->D('), 'empty-list guard must be caught before SMS transmission'
assert '.implements Llt1;' in (r/'smali/fj.smali').read_text(), 'original row content is a three-argument composable'
assert 'Lzn0;->d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)' in (r/'smali/ak2.smali').read_text()
s=(root/'src/cc/forserein/simhub/internal/WifiConfigEditor.java').read_text()
body=s[s.index('    private static void action('):s.index('    private static void fields(')]
assert 'function("lt1"' in body and 'args[1]' in body, 'list action content must follow the actual native three-argument callback'
for verbose in ['当前已保存（','本次保存后（预览）','自定义覆盖值','暂存修改','恢复本组内置','f.help']:
 assert verbose not in s, 'removed description still in editor: '+verbose
assert 'button("重置为内置"' in s and 'button("保存"' in s and 'button("取消"' not in s
print('PASS: compact editor native hooks, callback arity, caught empty-SMSC guard, and removed descriptions')
