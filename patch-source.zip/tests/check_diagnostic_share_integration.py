#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from diagnostic_share_patch import transform,ORIGINAL_SHA256
import hashlib
smali=Path(sys.argv[1])if len(sys.argv)>1 else ROOT/'build-config3/apktool/smali'
text=(smali/'ej.smali').read_text()
restored=transform(text,True)
assert hashlib.sha256(restored.encode()).hexdigest()==ORIGINAL_SHA256
assert transform(restored)==text
assert text.count('DiagnosticShareSanitizer;->sanitize')==1
for name in ['cd2.smali','f23.smali','zl5.smali']:
 assert 'DiagnosticShareSanitizer;'not in(smali/name).read_text(),name
print('PASS: single reversible diagnostic ACTION_SEND hook; logger and general clipboard untouched')
