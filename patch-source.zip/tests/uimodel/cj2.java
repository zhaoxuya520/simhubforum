public class cj2 {public final String a;public final ij2 b;public final boolean c;public final us1 d;public cj2(String a,ij2 b,boolean c,us1 d){this.a=a;this.b=b;this.c=c;this.d=d;}}
