public class qd2 {public static xl3 D(Object value){return new xl3(value);}}
