public enum ij2 {T,U,V}
