public class mk2 {public static final s55 d=new s55(),e=new s55(),g=new s55(),h=new s55();}
