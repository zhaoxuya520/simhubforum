public class mk2 {public static final s55 h=new s55();}
