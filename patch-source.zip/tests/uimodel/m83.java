public interface m83 extends ot4 {void setValue(Object v);}
