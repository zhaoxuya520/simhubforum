public class xl3 implements m83 {Object value;public int reads;public xl3(Object v){value=v;}public Object getValue(){reads++;return value;}public void setValue(Object v){value=v;}}
