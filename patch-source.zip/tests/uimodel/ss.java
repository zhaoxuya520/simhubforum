public class ss {public static zn0 Q(int id,gt1 content,lu1 composer){return new zn0(content);}}
