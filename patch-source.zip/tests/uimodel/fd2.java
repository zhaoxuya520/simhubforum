/** Records only the added country renderer's restart arguments; no fake visual layout. */
public class fd2 {
 public static String country;public static int size,flags,defaults,calls;public static lu1 composer;
 public static void readerWifiFlag(String c,int s,lu1 p,int f,int d){country=c;size=s;composer=p;flags=f;defaults=d;calls++;}
}
