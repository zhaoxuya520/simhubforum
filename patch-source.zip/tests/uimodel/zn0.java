public class zn0 {public final gt1 content;public zn0(gt1 c){content=c;}}
