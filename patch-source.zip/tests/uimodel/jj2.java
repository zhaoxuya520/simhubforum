public class jj2 {public long b=1,e=2,f=3,g=4,h=5;}
