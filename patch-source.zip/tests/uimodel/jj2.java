public class jj2 {public long f=0;}
