public interface us1 extends gt1 {Object a();}
