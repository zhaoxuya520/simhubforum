public class z55 {
 public static final rv3 c=new rv3();
 public static void wifiPanel(kt1 body,lu1 composer){body.f(composer,0);}
 public static r53 wifiField(r53 base,lu1 composer){return base;}
}
