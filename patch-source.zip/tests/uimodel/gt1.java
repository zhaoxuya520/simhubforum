public interface gt1 {}
