public interface ot4 {Object getValue();}
