import java.util.*;
public class yd2 {
 public static final Map<String,String> values=new LinkedHashMap<>();
 public static void d(String label,String value,lu1 c,int flags){if(xq0.bodyActive)throw new AssertionError("two-column settings row used inside editor alert");ak2.labels.add(label);values.put(label,value);}
}
