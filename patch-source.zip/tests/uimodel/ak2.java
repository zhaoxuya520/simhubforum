import java.util.*;
public class ak2 {
 public static final List<String> actionLabels=new ArrayList<>();
 public static final List<us1> actions=new ArrayList<>();
 public static us1 click;public static fj row;
 public static final List<String> labels=new ArrayList<>();
 public static final List<Edit> edits=new ArrayList<>();
 public static class Edit {public String value,hint;public ws1 change;public r53 modifier;public s55 style;Edit(String v,ws1 c,String h,r53 m,s55 s){value=v;change=c;hint=h;modifier=m;style=s;}}
 public static void d(us1 callback,zn0 lambda,lu1 composer,int flags,int mask){if(lambda.content instanceof fj){click=callback;row=(fj)lambda.content;}else {int before=z45.text.size();((lt1)lambda.content).d(new Object(),composer,0);actionLabels.add(z45.text.get(before));actions.add(callback);}if(flags!=48 || (callback!=null && mask!=0))throw new AssertionError("row style args");}
 public static void press(String label){int i=actionLabels.indexOf(label);if(i<0)throw new AssertionError(label);actions.get(i).a();}
 public static void f(String value,ws1 change,String hint,r53 modifier,int keyboard,boolean b,s55 style,lu1 composer,int flags,int mask){z45.events.add("input");edits.add(new Edit(value,change,hint,modifier,style));}
}
