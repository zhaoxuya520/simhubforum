import java.util.*;
public class ak2 {
 public static us1 click;public static fj row;
 public static final List<String> labels=new ArrayList<>();
 public static final List<Edit> edits=new ArrayList<>();
 public static class Edit {public String value,hint;public ws1 change;Edit(String v,ws1 c,String h){value=v;change=c;hint=h;}}
 public static void d(us1 callback,zn0 lambda,lu1 composer,int flags,int mask){click=callback;row=(fj)lambda.content;if(flags!=48 || (callback!=null && mask!=0))throw new AssertionError("row style args");}
 public static void f(String value,ws1 change,String hint,r53 modifier,int keyboard,boolean b,s55 style,lu1 composer,int flags,int mask){z45.events.add("input");edits.add(new Edit(value,change,hint));}
}
