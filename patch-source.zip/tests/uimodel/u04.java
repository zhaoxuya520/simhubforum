public class u04 {public kt1 d;}
