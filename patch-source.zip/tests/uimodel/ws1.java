public interface ws1 extends gt1 {Object i(Object v);}
