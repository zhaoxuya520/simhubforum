public interface kt1 extends gt1 {Object f(Object a,Object b);}
