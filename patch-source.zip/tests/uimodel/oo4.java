public class oo4 {
 public static final class Width implements r53 {public final float fraction;public float minHeight;Width(float f){fraction=f;}}
 public static r53 c(r53 original,float fraction){if(fraction!=1f)throw new AssertionError("text must fill alert width");return new Width(fraction);}
 public static r53 g(r53 modifier,float minimum,float maximum,int mask){if(!(modifier instanceof Width)||minimum!=48f||mask!=2)throw new AssertionError("input min-height contract");((Width)modifier).minHeight=minimum;return modifier;}
}
