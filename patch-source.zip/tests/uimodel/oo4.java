public class oo4 {
 public static final class Width implements r53 {public final float fraction;Width(float f){fraction=f;}}
 public static r53 c(r53 original,float fraction){if(fraction!=1f)throw new AssertionError("text must fill alert width");return new Width(fraction);}
}
