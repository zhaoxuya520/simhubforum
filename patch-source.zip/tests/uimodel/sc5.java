public class sc5 {public static final sc5 a=new sc5();}
