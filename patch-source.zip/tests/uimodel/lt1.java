public interface lt1 extends gt1 {Object d(Object a,Object b,Object c);}
