public class o53 implements r53 {public static final o53 b=new o53();}
