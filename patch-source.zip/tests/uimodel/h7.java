public class h7 {public static final rv3 b=new rv3();}
