public class nq1 {}
