import cc.forserein.simhub.internal.DiagnosticShareSanitizer;

public final class DiagnosticShareSanitizerTest {
    static int checks;
    static void check(boolean value,String reason){checks++;if(!value)throw new AssertionError(reason);}
    static String clean(String input){return DiagnosticShareSanitizer.sanitize(input);}
    public static void main(String[] args){
        for(String identity:new String[]{"tel:+85255551234","TEL:123","tel:%2B85255551234","sip:+85255551234@ims.mnc066.mcc515.3gppnetwork.org","SIPS:1234@ims.example.org:5061;transport=tcp","sip:alice:password@ims.example.org","sip:alice%40department@ims.example.org","sip:%2B85255551234%40ims.example.org"}){
            String result=clean("19:05:09   P-Asserted-Identity: <"+identity+">");
            check(!result.contains("55551234")&&!result.contains("1234")&&!result.contains("alice")&&!result.contains("password")&&!result.contains("TEL:123"),"URI identity removed: "+identity);
            check(result.contains("P-Asserted-Identity:"),"header remains: "+identity);
            check(clean(result).equals(result),"URI sanitization idempotent: "+identity);
        }
        String routes="Record-Route: <sip:10.5.236.161:5060;transport=tcp;lr>\nRoute: <sips:[2001:db8::1]:5061;lr>\nCall-ID: 515660000000001@10.5.236.1\nCall-ID: sip:opaque@identifier\n19:05:07 麦克风 94 帧，发 RTP 94，收 RTP 53，PT 116；10.5.236.218:10804 → :44886\na=rtpmap:116 AMR-WB/16000\nSIP/2.0 403 Forbidden";
        check(clean(routes).equals(routes),"routes, Call-ID, RTP counters, ports, codec and status preserved");
        check(clean("Route: <sip:192.0.2.10:5060?Subject=a%40b>").equals("Route: <sip:192.0.2.10:5060?Subject=a%40b>"),"encoded at-sign in URI query does not turn route into subscriber identity");
        String mixed=clean("19:05:09 INVITE sip:alice@ims.example.org | Call-ID: correlation@trace.example.org");
        check(!mixed.contains("alice")&&mixed.contains("Call-ID: correlation@trace.example.org"),"only Call-ID value exempted on a mixed diagnostic line");
        String names=clean("19:05:09   200 P-Asserted-Identity: \"Doe, <Jane>\\\" D.\" <sip:user@ims.example.org>,\r\n  +12025550173 <tel:+12025550174>\r\n19:05:10   200 Contact: <sip:192.0.2.1:5060>");
        check(names.equals("19:05:09   200 P-Asserted-Identity: [redacted] <sip:[redacted]@ims.example.org>, [redacted] <tel:[redacted]>\n19:05:10   200 Contact: <sip:192.0.2.1:5060>"),"mask quoted names, bare numbers and a folded identity list; keep next route");
        check(clean(names).equals(names),"display name masking is idempotent");
        check(clean("From: Friendly Name <sip:a@ims.example.org>;tag=t1").equals("From: [redacted] <sip:[redacted]@ims.example.org>;tag=t1"),"preserve dialog tag and domain");
        check(clean("短信正文：From: Friendly Name <example>").equals("短信正文：From: Friendly Name <example>"),"do not match headers inside message text");
        String auth="19:05:03 401 wWw-AuThEnTiCaTe: Digest realm=\"ims.mnc066.mcc515.3gppnetwork.org\", nonce=\"private-nonce\", algorithm=AKAv1-MD5, qop=\"auth,auth-int\"\r\n\tcnonce=\"private-cnonce\", response=\"private-response\", opaque=\"private-opaque\", auts=\"private-auts\", nc=00000001\r\n19:05:04 ← 200 OK REGISTER";
        String sanitized=clean(auth);
        check(!sanitized.contains("private-"),"all folded Digest secrets hidden");
        check(sanitized.contains("realm=\"ims.mnc066.mcc515.3gppnetwork.org\"")&&sanitized.contains("algorithm=AKAv1-MD5")&&sanitized.contains("qop=\"auth,auth-int\"")&&sanitized.contains("nc=00000001"),"Digest routing and algorithm metadata retained");
        check(sanitized.endsWith("19:05:04 ← 200 OK REGISTER"),"next log record unchanged");
        check(clean(sanitized).equals(sanitized),"folded auth sanitization idempotent");
        for(String header:new String[]{"Authorization","Proxy-Authorization","WWW-Authenticate","Proxy-Authenticate","Authentication-Info"}){
            String value=header.equals("Authentication-Info")?"nextnonce=\"SECRET\", rspauth=\"SECRET\"":"Digest username=\"SECRET\", nonce=\"SECRET\", unknown=\"SECRET\"";
            check(!clean("19:05:09   "+header+": "+value).contains("SECRET"),"sensitive header boundary: "+header);
        }
        check(!clean("Authorization: Bearer TOKEN\n  FOLDED_TOKEN\nCSeq: 1 REGISTER").contains("TOKEN"),"opaque and folded bearer tokens hidden");
        check(clean("Authorization: Basic TOKEN\nCall-ID: retain-me").endsWith("Call-ID: retain-me"),"next header boundary retained");
        check(!clean("Authorization: Digest nonce=\"TRUNCATED").contains("TRUNCATED"),"truncated secret hidden");
        check(!clean("Authorization: Digest nonce=\"escape\\\"SECRET\", realm=\"ims.example.org\"").contains("SECRET"),"escaped quotes do not expose secret");
        String timed=clean("19:05:01 Authorization: Digest response=\"SECRET_START\n19:05:01     SECRET_CONTINUATION\"\n19:05:01   200 Contact: <sip:10.0.0.1:5060>\n19:05:02   媒体：收 RTP 53，PT 116");
        check(!timed.contains("SECRET_"),"timestamped folded fragment without key-value prefix hidden");
        check(timed.contains("200 Contact: <sip:10.0.0.1:5060>")&&timed.contains("媒体：收 RTP 53，PT 116"),"explicit next SIP header and media record end authentication continuation");
        check(clean("  WWW-Authenticate: Digest realm=\"ims.example.org\",\n nonce=\"SECRET\", algorithm=AKAv1-MD5\n  200 SDP: m=audio 10804 RTP/AVP 116").endsWith("  200 SDP: m=audio 10804 RTP/AVP 116"),"indented next SDP record is not an authentication continuation");
        check(clean("IMSI=51566••••••••01").equals("IMSI=51566••••••••01"),"existing IMSI mask retained");
        check(!clean("19:05:09 收到短信 来自 +85255551234").contains("55551234")&&!clean("收到短信 来自 12345").contains("12345"),"actual SMS sender diagnostic prefix hidden");
        check(clean("短信正文：订单 12345，RTP 94").equals("短信正文：订单 12345，RTP 94"),"SMS body and other numeric content unchanged");
        String body="短信正文：收到短信 来自 +85255551234，来电 alice（前提条件 100rel）";
        check(clean(body).equals(body),"business prefix matching does not search inside arbitrary message text");
        String invite=clean("19:05:09 ← 来电 INVITE 来自 +85255551234；语音编码：AMR-WB PT 116");
        check(!invite.contains("55551234")&&invite.endsWith("；语音编码：AMR-WB PT 116"),"actual incoming INVITE identity hidden, codec retained");
        String caller=clean("19:05:09 来电 alice@example.org（前提条件 100rel，等待 PRACK）");
        check(!caller.contains("alice")&&caller.endsWith("（前提条件 100rel，等待 PRACK）"),"actual bare incoming username hidden, precondition diagnostic retained");
        check(clean(null)==null&&clean("").isEmpty(),"empty input supported");
        System.out.println("PASS: "+checks+" diagnostic share privacy and protocol-context assertions");
    }
}
