#!/usr/bin/env python3
"""Check the actual APK model, live connection entry, and original UI editor integration."""
from pathlib import Path
import json
import os
import re
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from wifi_config_patch import ORIGINAL_SHA256, patch_wifi_class
ORIGINAL=Path(os.environ.get('SIMHUB_RECOVERED','/workspace/recovered/SIMHub-Android-23.1'))/'apktool/smali'
PATCHED=Path(sys.argv[1])
checks=[]
def check(ok,label):
    assert ok,label
    checks.append(label)
def method(text,name):
    matches=re.findall(r'^\.method [^\n]* '+re.escape(name)+r'\n(.*?)^\.end method',text,re.M|re.S)
    assert len(matches)==1,name
    return matches[0]
for name in ORIGINAL_SHA256:
    before=(ORIGINAL/name).read_text();after=(PATCHED/name).read_text()
    check(after==patch_wifi_class(name,before),name+': exact declared hooks only')
    try:patch_wifi_class(name,after)
    except AssertionError:checks.append(name+': already patched input rejected')
    else:raise AssertionError(name+': double patch accepted')
    if name!='b72.smali':
        check(re.findall(r'\.(?:locals|registers) \d+',before)==re.findall(r'\.(?:locals|registers) \d+',after),name+': register counts unchanged')
config=(PATCHED/'xi5.smali').read_text()
fields=dict(re.findall(r'^\.field public final (\w+):(\S+)',config,re.M))
expected=['Llj5;','Ljava/lang/String;','Ljava/lang/String;','Ljava/lang/String;','Ljava/lang/String;','Ljava/util/List;','Ljava/lang/String;','Ljava/lang/String;','Lak5;']+['Ljava/util/List;']*6+['I','Z','Ljava/lang/String;','Ljava/lang/String;','Z','I','Z','Ljava/lang/String;','Ljava/util/List;','Ljava/lang/String;','Lyj5;','Ljava/lang/String;']
names=[chr(97+i) if i<26 else 'A' for i in range(27)]
check([fields[n] for n in names]==expected,'27 config field types match reflection adapter')
check(config.count('<init>('+''.join(expected)+')V')>=1,'full constructor descriptor exists')
check(len(re.findall(r'^\.method public constructor <init>\('+''.join(re.escape(t) for t in expected)+r'\)V$',config,re.M))==1,'unambiguous public full constructor')
state=(PATCHED/'gl5.smali').read_text()
constructor=method(state,'<init>(Ljava/lang/String;Ljava/lang/String;ZLel5;Lek5;Lxi5;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lsd2;ZLhl5;Lfl5;Ljava/lang/Long;Ljava/util/List;Ljava/util/List;ZLjava/lang/String;J)V')
for param,field,helper in [('p6','f','resolve'),('p8','h','epdg'),('p9','i','smsc'),('p10','j','imei')]:
    check(constructor.index('WifiConfigRuntime;->'+helper)<constructor.index('iput-object '+param+', p0, Lgl5;->'+field+':'),'state applies '+helper+' before immutable field assignment')
editor=method((PATCHED/'yd2.smali').read_text(),'j(Lus1;Llu1;I)V')
check(editor.count('WifiConfigEditor;->begin')==1 and editor.count('Lsd2;->a(Lus1;ZZZ')==1 and 'WifiConfigEditor;->present' not in editor,'original configuration sheet restored, no native replacement form')
check('WifiConfigEditor;->cancelCallback' in editor and 'WifiConfigEditor;->overlay' in editor,'original sheet cancellation and same-style editing alert connected')
check('Lh7;->b:Lhu4;' in editor and 'Llu1;->k(Lrv3;)Ljava/lang/Object;' in editor,'uses Compose LocalContext')
check('Llu1;->e0(I)Llu1;' in editor and 'Llu1;->u()Lu04;' in editor and 'Lu04;->d:Lkt1;' in editor,'Compose group and recomposition continuation retained')
check('.method public abstract a()Ljava/lang/Object;' in (PATCHED/'us1.smali').read_text(),'original dismiss callback is public')
for name,symbol in [('zl3','r(Lek5;)Lxi5;'),('rt4','getValue()Ljava/lang/Object;'),('rt4','h(Ljava/lang/Object;Ljava/lang/Object;)Z'),('sd2','z()Z')]:
    check(bool(re.search(r'^\.method public [^\n]*\b'+re.escape(symbol)+r'$',(PATCHED/(name+'.smali')).read_text(),re.M)),'public reflection target '+name+'.'+symbol)
connection=(PATCHED/'zl5.smali').read_text()
start=method(connection,'z()V')
check('Lgl5;->f:Lxi5;' in start and 'Lgl5;->e:Lek5;' in start and 'Lhm0;-><init>' in start,'connection starts with effective card configuration')
connect=method(connection,'u(Lac5;Lxi5;Lek5;ILdt0;)Ljava/lang/Object;')
check('WifiConfigModel;->addressFamilies' in connect and 'Lxi5;->i:Lak5;' in connect,'actual address-family retry list respects explicit IP selection')
check('Lxi5;->d()I' in connect and 'Lzl5;->A(I)V' in connect,'actual keepalive task receives configurable seconds')
copy=method(config,'a(Lxi5;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lak5;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Lyj5;Ljava/lang/String;I)Lxi5;')
for field in ['j','k','l','m','n','o']:
    check('Lxi5;->'+field+':Ljava/util/List;' in copy,'original config copy preserves algorithm-list identity '+field)
b72=(PATCHED/'b72.smali').read_text()
for signature,helper in [('j(Ljava/util/List;)Lf52;','restrictIke'),('f()Lf52;','restrictEsp')]:
    body=method(b72,signature)
    check(body.index('WifiConfigModel;->'+helper)<body.index('new-instance p0, Lf52;'),'filter '+helper+' before config register reused')
    check(body.count('return-object')==1,'single proposal return '+signature)
check('iget-object v6, p0, Lb72;->a:Lxi5;\n    invoke-static {v6, v0}' in b72,'ESP filter keeps SPI registers v1/v2/v3/v4/v5 intact')
# Regression for config1's real register error: p0 is the DH ArrayList at the old hook.
ike=method(b72,'j(Ljava/util/List;)Lf52;')
check('    .locals 11' in ike,'IKE reserves one new local without shifting v0..v9')
check('iget-object p0, p0, Lb72;->a:Lxi5;\n    move-object v10, p0' in ike,'config captured before p0 is overwritten')
check('new-instance p0, Ljava/util/ArrayList;' in ike,'regression retains real DH-list register reuse')
check('invoke-static {v10, v0}, Lcc/forserein/simhub/internal/WifiConfigModel;->restrictIke' in ike,'filter receives preserved config instead of DH ArrayList')
writes=re.findall(r'^\s*(?:move(?:-object|-wide)?(?:/from16|/16)?|move-result(?:-object|-wide)?|iget(?:-object|-wide)?|const(?:/[a-z0-9]+|-string)?|new-instance|new-array)\s+(v10)\b',ike,re.M)
check(len(writes)==1,'new v10 config register never clobbered')
check(not re.search(r'\bv1[1-9]\b',ike),'all original explicit locals remain within v0..v9')
# Pinned source has no other v10 aliases; p0/p1 now encode as v11/v12, still valid 35c operands.
original_ike=method((ORIGINAL/'b72.smali').read_text(),'j(Ljava/util/List;)Lf52;')
check(not re.search(r'\bv10\b',original_ike),'dedicated local does not alias any original operand')
for name,count in [('pt',5),('mt',3)]:
    text=(PATCHED/(name+'.smali')).read_text()
    check(text.count('WifiConfigEditor;->row')==count,name+': only existing IMS/IKE/ESP rows become clickable')
for name in ['ak2','fj','fj2','sd2','z55']:
    check((PATCHED/(name+'.smali')).read_bytes()==(ORIGINAL/(name+'.smali')).read_bytes(),name+': original renderer, theme, spacing and typography byte-identical')
check(method((PATCHED/'yd2.smali').read_text(),'d(Ljava/lang/String;Ljava/lang/String;Llu1;I)V')==method((ORIGINAL/'yd2.smali').read_text(),'d(Ljava/lang/String;Ljava/lang/String;Llu1;I)V'),'shared original row renderer untouched')
java=(ROOT/'src/cc/forserein/simhub/internal/WifiConfigEditor.java').read_text()
check('AlertDialog' not in java and 'LinearLayout' not in java and 'ScrollView' not in java,'replacement Android form removed')
# Check every literal reflective method signature in the actual APK (not just Java model doubles).
primitive={'int':'I','boolean':'Z','long':'J','float':'F'}
for owner,name,args in re.findall(r'call\("([^"\n]+)","([^"\n]+)",new String\[\]\{([^}]+|)\}',java):
    descriptor=''.join(primitive.get(t,'L'+t.replace('.','/')+';') for t in re.findall(r'"([^"]+)"',args))
    content=(PATCHED/(owner+'.smali')).read_text()
    check(bool(re.search(r'^\.method public [^\n]* '+re.escape(name+'('+descriptor+')'),content,re.M)),owner+'.'+name+' reflection signature exists')

for name in ['o82','yk','lf4','h01','xi5','zl3','mg','tb0']:
    if name=='mg':continue # separately verified pinned-certificate addition
    check((PATCHED/(name+'.smali')).read_bytes()==(ORIGINAL/(name+'.smali')).read_bytes(),name+': existing protocol/model/security implementation preserved')
report={'checks':len(checks),'failed':0,'kind':'static config integration; no device execution','details':checks}
(ROOT/'build/wifi-config-integration-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='details'}))
