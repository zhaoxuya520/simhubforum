#!/usr/bin/env python3
"""Independently verify extracted DITO parameters against the exact upstream IPA binary."""
from pathlib import Path
import argparse,hashlib,json,struct,zipfile
p=argparse.ArgumentParser();p.add_argument('ipa',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1];reference=json.loads((root/'validation/dito-reference-v29.3.json').read_text())
assert hashlib.sha256(a.ipa.read_bytes()).hexdigest()==reference['ipa_sha256'],'Upstream package changed; inspect it again before importing parameters'
with zipfile.ZipFile(a.ipa)as z:binary=z.read('Payload/esimSubscription.app/esimSubscription')
assert struct.unpack_from('<I',binary)[0]==0xfeedfacf
segments=[];pos=32
for _ in range(struct.unpack_from('<I',binary,16)[0]):
 command,size=struct.unpack_from('<II',binary,pos)
 if command==0x19:
  address,length,fileoff,filesize=struct.unpack_from('<QQQQ',binary,pos+24);segments.append((address,filesize,fileoff))
 pos+=size
def offset(address):
 for base,size,fileoff in segments:
  if base<=address<base+size:return fileoff+address-base
 raise ValueError(hex(address))
start=offset(int(reference['profile_function'],16));assert hashlib.sha256(binary[start:start+1024]).hexdigest()==reference['profile_function_sha256']
values={}
for name,address in reference['static_array_addresses'].items():
 start=offset(int(address,16));count=struct.unpack_from('<Q',binary,start+16)[0]
 if name=='pcscf_attrs':value=list(struct.unpack_from('<'+'H'*count,binary,start+32))
 else:
  assert count==1;raw=binary[start+32:start+48];value=[raw[:raw[15]&15].decode()]
 assert value==reference['profile'][name],(name,value);values[name]=value
instruction=struct.unpack_from('<I',binary,offset(0x1002074b4))[0]
assert instruction&0xff80001f==0x5280000c
assert ((instruction>>5)&65535)==reference['profile']['register_expires_seconds']==7200
prefix=b''
for address in [0x10020640c,0x100206410,0x100206414,0x100206418,0x10020641c]:
 word=struct.unpack_from('<I',binary,offset(address))[0];prefix+=((word>>5)&65535).to_bytes(2,'little')
assert prefix.decode()==reference['reference_recovery_iccid_batch']
report=dict(reference_ipa_sha256=reference['ipa_sha256'],exact_function_verified=True,reference_recovery_batch=prefix.decode(),
 independent_static_arrays=values,register_expires_seconds=7200,carrier_confirmed=False,device_tested=False)
a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(report,indent=2)+'\n')
print('PASS: exact upstream DITO function, issuer batch, six algorithm lists, four P-CSCF attributes and 7200-second expiry verified')
