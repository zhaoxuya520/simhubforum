#!/usr/bin/env python3
"""Restore bounded notification edits and compare every affected native class byte-for-byte."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from notification_action_patch import EDITS,reverse_notification_actions,verify_notification_actions
p=Path(sys.argv[1]);smali=p/'smali'
baseline=Path(sys.argv[2]) if len(sys.argv)>2 else Path('/workspace/recovery/config2-decoded/smali')
checks=0
for name in sorted({item[0] for item in EDITS}):
 original=(baseline/name).read_text()
 assert reverse_notification_actions(name,(smali/name).read_text())==original,name
 checks+=1
assert (smali/'cc/forserein/simhub/internal/CallNotificationGuard.smali').is_file();checks+=1
report=verify_notification_actions(smali);report.update(checks=checks,native_class_restore_exact=True)
(p.parent/'notification-integration.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS:',checks,'bounded notification identity hooks and complete native class restoration')
