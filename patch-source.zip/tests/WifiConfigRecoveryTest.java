import cc.forserein.simhub.internal.*;
import java.util.*;

/** Damaged saved settings must remain repairable without using the roaming carrier. */
public class WifiConfigRecoveryTest {
 static int passed;
 static final String HOME="515660123456789",ROAM="204049876543210";
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);passed++;}
 static ek5 card(String imsi,String iccid){return DitoHomeIdentityTest.card(imsi,iccid);}
 static Map<String,String> values(String... pairs){return WifiConfigTest.values(pairs);}
 static void active(ek5 card){zl5.b.value=WifiConfigTest.state(card,zl3.r(card));}
 static String legacy(ek5 card){return WifiConfigValues.digest(card.b+"\n"+card.a);}
 static String stable(ek5 card){return WifiConfigValues.digest(card.b+"\nDITO");}
 static void broken(String record,String suffix)throws Exception {
  DitoHomeIdentityTest.Ctx ctx=new DitoHomeIdentityTest.Ctx();zl5.f=ctx;
  ek5 raw=card(ROAM,"896366880012345"+suffix);String key=WifiConfigRuntime.cardKey(raw);
  WifiConfigTest.Prefs prefs=ctx.store("wifi_config_overrides_v1");prefs.data.put(key,record);
  active(raw);gl5 state=(gl5)zl5.b.value;
  check(state.f.c.equals("DITO"),"bad record cannot replace known DITO with roaming Vodafone");
  check(state.f.g.equals("ims.mnc066.mcc515.3gppnetwork.org")&&state.f.f.equals(Collections.singletonList("epdg.epc.mnc066.mcc515.pub.3gppnetwork.org")),"clean DITO domain and endpoint are effective");
  check(state.h.equals("")&&WifiConfigRuntime.epdg(raw,"old.vodafone.example.org").equals(""),"legacy state endpoint cannot bypass recovered DITO endpoints");
  check(state.f.r.startsWith("0"+ROAM+"@")&&state.f.s.startsWith(ROAM+"@")&&state.e==raw,"recovery never invents home credentials or changes physical card");
  check(DitoHomeIdentity.connection(raw)==raw,"damaged settings do not block valid current identity or manufacture home credentials");
  check(record.equals(prefs.data.get(key)),"live recovery leaves exact damaged record on disk");
  WifiConfigRuntime.Snapshot recovery=WifiConfigRuntime.snapshot();
  check(recovery.warning!=null&&recovery.values.isEmpty(),"editor opens existing recovery draft with warning");
  check(recovery.record.equals(record)&&recovery.key.equals(key),"recovery draft retains original revision");
  check(recovery.defaults.get("domain").equals(state.f.g),"editor recovery defaults match live DITO config");
  check(record.equals(prefs.data.get(key)),"opening recovery editor cannot erase saved fields");
  DitoHomeIdentity.observe(card(HOME,raw.b));active(raw);state=(gl5)zl5.b.value;
  check(state.f.r.startsWith("0"+HOME+"@")&&state.f.s.startsWith(HOME+"@"),"verified same-card home identity remains the authentication source");
  check(((ek5)DitoHomeIdentity.connection(raw)).a.equals(HOME)&&raw.a.equals(ROAM),"connection guard and immutable home copy are preserved");
  WifiConfigRuntime.save(recovery.key,recovery.record,Collections.<String,String>emptyMap());
  check(!record.equals(prefs.data.get(key))&&WifiConfigRuntime.snapshot().values.isEmpty(),"only explicit save replaces damaged record");
  active(card(ROAM,raw.b));check(((gl5)zl5.b.value).f.c.equals("DITO")&&((gl5)zl5.b.value).h.equals(""),"repair survives reread without stale endpoint resurrection");
  // An editor opened before another writer acts must still reject stale saves.
  prefs.data.put(key,record);WifiConfigRuntime.Snapshot stale=WifiConfigRuntime.snapshot();
  String newer=WifiConfigValues.encode(values("domain","newer.example.org"));prefs.data.put(key,newer);
  WifiConfigTest.rejects(()->WifiConfigRuntime.save(stale.key,stale.record,Collections.<String,String>emptyMap()),"stale recovery revision");passed++;
  check(newer.equals(prefs.data.get(key)),"stale recovery cannot overwrite another saved update");
 }
 static void boundedMigration()throws Exception {
  DitoHomeIdentityTest.Ctx ctx=new DitoHomeIdentityTest.Ctx();zl5.f=ctx;
  WifiConfigTest.Prefs prefs=ctx.store("wifi_config_overrides_v1");
  ek5 roaming=card(ROAM,"8901234500123450004"),home=card(HOME,roaming.b);
  active(roaming);WifiConfigRuntime.Snapshot before=WifiConfigRuntime.snapshot();
  Map<String,String> selected=values(CarrierPresets.KEY,DitoCarrierProfile.KEY,"smsc","+639333333333");
  WifiConfigRuntime.save(before.key,before.record,selected);String old=prefs.data.get(legacy(roaming));
  DitoHomeIdentity.observe(home);active(home);
  check(WifiConfigRuntime.snapshot().values.equals(selected),"previously loaded unknown issuer retains edits on first home read");
  check(old.equals(prefs.data.get(stable(home)))&&old.equals(prefs.data.get(legacy(roaming))),"same-card bounded migration copies verified disk record and retains source");
  check(((gl5)zl5.b.value).i.equals("+639333333333"),"migrated SMSC becomes effective on home identity");
  ek5 unrelated=card(HOME,"8901234500123450005");DitoHomeIdentity.observe(unrelated);active(unrelated);
  check(!"+639333333333".equals(WifiConfigRuntime.snapshot().values.get("smsc"))&&prefs.data.get(stable(unrelated))==null,"cached different ICCID cannot contribute its settings");
  // Destination and current/home legacy records keep priority over a cached roaming key.
  for(int n=0;n<2;n++){
   ek5 roam=card(ROAM,"890123450012345001"+n),ownHome=card(HOME,roam.b);
   String cached=WifiConfigValues.encode(values("smsc","+639111111111")),preferred=WifiConfigValues.encode(values("smsc","+639222222222"));
   prefs.data.put(legacy(roam),cached);active(roam);
   prefs.data.put(n==0?stable(ownHome):legacy(ownHome),preferred);DitoHomeIdentity.observe(ownHome);active(ownHome);
   check(WifiConfigRuntime.snapshot().values.get("smsc").equals("+639222222222"),"existing destination/current legacy precedes cached roaming record");
   check(cached.equals(prefs.data.get(legacy(roam))),"migration never deletes older recovery record");
  }
  // Without an observed cached identity there is deliberately no IMSI search.
  ek5 unseenRoam=card(ROAM,"8901234500123450006"),unseenHome=card(HOME,unseenRoam.b);
  prefs.data.put(legacy(unseenRoam),old);DitoHomeIdentity.observe(unseenHome);active(unseenHome);
  check(prefs.data.get(stable(unseenHome))==null&&old.equals(prefs.data.get(legacy(unseenRoam))),"unobserved legacy identity is preserved without scanning or guessing");
 }
 static void missingIccidIsolation()throws Exception {
  DitoHomeIdentityTest.Ctx ctx=new DitoHomeIdentityTest.Ctx();zl5.f=ctx;
  for(String iccid:new String[]{"","unavailable"}){
   ek5 first=card(HOME,iccid),second=card("515661234567890",iccid);
   check(DitoHomeIdentity.isDito(first)&&DitoHomeIdentity.isDito(second),"real home PLMN still identifies DITO without usable ICCID");
   check(WifiConfigRuntime.cardKey(first).equals(legacy(first))&&!WifiConfigRuntime.cardKey(first).equals(WifiConfigRuntime.cardKey(second)),"missing ICCID home cards keep separate actual-IMSI keys");
   active(first);WifiConfigRuntime.Snapshot one=WifiConfigRuntime.snapshot();WifiConfigRuntime.save(one.key,one.record,values("domain","first.example.org"));
   active(second);check(((gl5)zl5.b.value).f.g.equals("ims.mnc066.mcc515.3gppnetwork.org"),"second card cannot inherit first card edits");
   WifiConfigRuntime.Snapshot two=WifiConfigRuntime.snapshot();WifiConfigRuntime.save(two.key,two.record,values("domain","second.example.org"));
   active(first);check(((gl5)zl5.b.value).f.g.equals("first.example.org"),"first missing ICCID profile keeps its own saved settings");
   check(ctx.store("wifi_config_overrides_v1").data.get(stable(first))==null,"invalid ICCID never creates shared DITO stable record");
  }
 }
 public static void main(String[]args)throws Exception {
  broken(WifiConfigValues.encode(values(CarrierPresets.KEY,"51566|missing_saved_template","domain","preserved.example.org","smsc","+639111111111","imei","490154203237518")),"5526");
  broken("v1\nunknown\tbroken\n","5527");
  DitoHomeIdentityTest.Ctx ctx=new DitoHomeIdentityTest.Ctx();zl5.f=ctx;
  ek5 raw=card(ROAM,"8963668800123455528");active(raw);WifiConfigRuntime.Snapshot initial=WifiConfigRuntime.snapshot();
  Map<String,String> manual=values(CarrierPresets.KEY,"20404|apple_vodafone_nl","epdg","manual.epdg.example.org","domain","manual.ims.example.org");
  WifiConfigRuntime.save(initial.key,initial.record,manual);
  check(((gl5)zl5.b.value).f.c.equals("Vodafone")&&((gl5)zl5.b.value).h.equals("manual.epdg.example.org"),"valid explicit manual carrier and endpoints remain authoritative");
  check(WifiConfigRuntime.snapshot().values.equals(manual),"valid manual settings are not removed by recovery logic");
  active(card(ROAM,raw.b));check(((gl5)zl5.b.value).f.c.equals("Vodafone"),"valid manual carrier survives reread");
  // Unrecognized foreign cards keep the existing native fallback behavior.
  ek5 foreign=card(ROAM,"8948011234567890123");String key=WifiConfigRuntime.cardKey(foreign);
  ctx.store("wifi_config_overrides_v1").data.put(key,"v1\nunknown\tbroken\n");active(foreign);
  check(((gl5)zl5.b.value).f.c.equals("Vodafone")&&((gl5)zl5.b.value).h.equals("legacy.epdg.example.org"),"DITO-only recovery does not relabel foreign SIMs");
  boundedMigration();missingIccidIsolation();
  System.out.println("PASS: "+passed+" damaged carrier settings, safe DITO fallback and explicit repair assertions");
 }
}
