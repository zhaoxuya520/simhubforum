#!/usr/bin/env python3
"""Exercise actual EID + profile read coroutine, including both suspension points."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parents[1]/'smali/InternalSimChipRead.smali'
sys.argv=[sys.argv[0],str(path)]
import check_refresh_flow as vm
original_type=vm.is_type
vm.is_type=lambda value,kind:isinstance(value,str) if kind=='java/lang/String' else original_type(value,kind)
class Run(vm.Run):
 def __init__(self,suspend=True,mismatch=False,fail=False):
  self.manager=vm.Obj('hh1');self.channel=vm.Obj('vf1')
  self.frame=vm.Obj('InternalSimChipRead',backend=self.manager,channel=self.channel,eid='expected',state=0)
  self.suspend=suspend;self.next_resume=vm.UNIT;self.mismatch=mismatch;self.fail=fail;self.profile_reads=0
 def invoke(self,ref,args):
  if ref=='Lhh1;->z(Lvf1;Ldt0;)Ljava/lang/Object;':
   assert args[1] is self.channel
   return self.result(vm.Cancelled('cancel') if self.fail else ('wrong' if self.mismatch else 'expected'))
  if 'MultiChipSwitch;->verifyEid' in ref:
   if args[0]!=args[1]:raise vm.CardError('wrong EID')
   return None
  if ref=='Lg0;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;':
   assert args[1] is self.channel
   self.profile_reads+=1;return self.result([])
  return super().invoke(ref,args)
class Checked(unittest.TestCase):
 def test_sync(self):
  r=Run(False);self.assertEqual(r.execute(),[]);self.assertEqual(r.profile_reads,1)
 def test_suspended(self):
  r=Run();self.assertEqual(r.execute(),[]);self.assertEqual(r.profile_reads,1)
 def test_wrong_eid_blocks_profile_read(self):
  for suspend in (True,False):
   r=Run(suspend,mismatch=True)
   with self.assertRaises(vm.CardError):r.execute()
   self.assertEqual(r.profile_reads,0)
 def test_cancel_does_not_read_profiles(self):
  r=Run(fail=True)
  with self.assertRaises(vm.Cancelled):r.execute()
  self.assertEqual(r.profile_reads,0)
if __name__=='__main__':unittest.main(verbosity=2)
