#!/usr/bin/env python3
"""Fail closed if timer hook escapes its reviewed native method boundaries."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from sip_session_timer_patch import verify_sip_session_timer,reverse_sip_session_timer,SIP_CLASSES,_method
smali=Path(sys.argv[1]);smali=smali/'smali'if(smali/'smali').is_dir()else smali
verify_sip_session_timer(smali)
engine=(smali/'o82.smali').read_text();cb=(smali/'cb4.smali').read_text()
assert engine.count('Lcb4;->sipApplyRefreshResponse(')==1
response=_method(engine,'public final h(Lkb4;)Z')[2]
hook=response.index('Lcb4;->sipApplyRefreshResponse(')
assert response.rfind(':sswitch_2',0,hook)>response.rfind(':sswitch_1',0,hook)
assert 'if-ne v0, v10, :cond_16' in response[hook-100:hook]
assert response.index('iget-object v0, v1, Lkb4;->g:[B',hook)>hook
sender=_method(engine,'public static final a(Lo82;)Z')[2]
assert 'iget-boolean v0, v2, Lma4;->C:Z'in sender
assert 'if-eqz v0, :cond_10'in sender
for name in SIP_CLASSES:reverse_sip_session_timer(name,(smali/name).read_text())
print('SIP integration passed: exact native boundaries, UPDATE 2xx only, body delivery retained')
