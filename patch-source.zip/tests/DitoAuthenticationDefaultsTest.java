import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import java.util.*;

/** Separates DITO's gateway/IMS profile from the real card's EAP routing identity. */
public class DitoAuthenticationDefaultsTest {
 static int passed;
 static final String ID="8963668800123457391",ROAM="204049876543210",HOME="515661234567890";
 static final String IMS="ims.mnc066.mcc515.3gppnetwork.org";
 static final String GATEWAY="epdg.epc.mnc066.mcc515.pub.3gppnetwork.org";
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);passed++;}
 static void fresh(){zl5.f=new DitoHomeIdentityTest.Ctx();}
 static ek5 card(String imsi,String id,int mnc){return new ek5(imsi,id,mnc,null,null,null,null,null);}
 static String nai(String imsi,String mcc,String mnc){return "0"+imsi+"@nai.epc.mnc"+mnc+".mcc"+mcc+".3gppnetwork.org";}
 static void unchanged(ek5 card,Object[] before)throws Exception {check(Arrays.equals(before,WifiConfigModel.fields(card,8)),"building DITO settings never rewrites a physical identity");}
 static void defaults(ek5 card,String expected,String subscriber)throws Exception {
  Object[] before=WifiConfigModel.fields(card,8);xi5 config=(xi5)CarrierPresets.defaults(card,null);
  check(config.r.equals(expected),"outer NAI uses the actual authentication MCC and MNC length");
  check(config.y.equals(expected),"permanent EAP identity is independently populated from the same card");
  check(config.d.equals("515")&&config.e.equals("66")&&config.f.equals(Collections.singletonList(GATEWAY)),"subscriber EAP realm does not change the DITO ePDG operator");
  check(config.g.equals(IMS)&&config.s.equals(subscriber+"@"+IMS),"IMS remains DITO while preserving the real subscriber digits");
  unchanged(card,before);
 }
 static void saveWait()throws Exception {
  long deadline=System.nanoTime()+2_000_000_000L;
  while(Handler.tasks.isEmpty()&&System.nanoTime()<deadline)Thread.sleep(5);
  check(!Handler.tasks.isEmpty(),"editor persistence finishes");Handler.drain();
 }
 public static void main(String[]args)throws Exception {
  String[][] rows={{ROAM,"2","204","004"},{ROAM,"3","204","049"},
   {"234159876543210","2","234","015"},{"310260123456789","3","310","260"},
   {"310260123456789","2","310","026"},{"001010123456789","2","001","001"},
   {"20404123456789","2","204","004"},{HOME,"2","515","066"}};
  for(String[] row:rows){fresh();defaults(card(row[0],ID,Integer.parseInt(row[1])),nai(row[0],row[2],row[3]),row[0]);}
  fresh();ek5 raw=card(ROAM,ID,3);DitoHomeIdentity.observe(card(HOME,ID,2));
  defaults(raw,nai(HOME,"515","066"),HOME);
  check(((ek5)DitoHomeIdentity.connection(raw,CarrierPresets.defaults(raw,null))).c==2,"same-card observed home MNC length overrides only the effective Wi-Fi copy");
  ek5 other=card(ROAM,"8963668800123457392",2);
  defaults(other,nai(ROAM,"204","004"),ROAM);

  fresh();raw=card(ROAM,ID,2);xi5 base=(xi5)DitoCarrierProfile.defaults(raw);String permanent=nai(ROAM,"204","004");
  xi5 outer=(xi5)WifiConfigModel.merge(base,WifiConfigTest.values("nai","anonymous@outer.example.org"));
  check(outer.r.equals("anonymous@outer.example.org")&&outer.y.equals(permanent),"outer-only edit cannot replace permanent EAP with anonymous identity");
  xi5 eap=(xi5)WifiConfigModel.merge(base,WifiConfigTest.values("eap","permanent@eap.example.org"));
  check(eap.r.equals(permanent)&&eap.y.equals("permanent@eap.example.org"),"explicit permanent EAP has priority without changing outer NAI");
  xi5 both=(xi5)WifiConfigModel.merge(base,WifiConfigTest.values("nai","outer@custom.example.org","eap","permanent@custom.example.org"));
  check(both.r.equals("outer@custom.example.org")&&both.y.equals("permanent@custom.example.org"),"two explicit identity fields remain independent");
  xi5 servers=(xi5)WifiConfigModel.merge(base,WifiConfigTest.values("domain","ims.custom.example.org","epdg","first.example.org\nsecond.example.org"));
  check(servers.g.equals("ims.custom.example.org")&&servers.f.equals(Arrays.asList("first.example.org","second.example.org"))&&servers.r.equals(permanent)&&servers.y.equals(permanent),"explicit IMS/ePDG edits do not accidentally rewrite either EAP identity");
  Map<String,String> cleared=WifiConfigValues.validate(WifiConfigTest.values("nai","outer@custom.example.org","eap",""));
  xi5 clear=(xi5)WifiConfigModel.merge(base,cleared);
  check(clear.r.equals("outer@custom.example.org")&&clear.y.equals(permanent),"clearing only EAP restores card-derived permanent identity rather than the custom outer NAI");
  Map<String,String> fields=new LinkedHashMap<>(WifiConfigModel.display(base));fields.put("nai","outer@custom.example.org");
  Map<String,String> overrides=WifiConfigPresentation.overrides(fields,WifiConfigModel.display(base));
  check(overrides.size()==1&&overrides.containsKey("nai")&&!overrides.containsKey("eap"),"untouched prefilled EAP value is not frozen into a custom record");

  // Invalid read data may be displayed for repair, but never gets a manufactured realm.
  for(ek5 invalid:new ek5[]{card("",ID,2),card("20404",ID,2),card("20404987654321x",ID,2),
      card("2040498765432100",ID,2),card("２０４０４９８７６５４３２１０",ID,2),
      card(ROAM,ID,-1),card(ROAM,ID,0),card(ROAM,ID,1),card(ROAM,ID,4),card(ROAM,ID,Integer.MAX_VALUE),card(HOME,ID,3)}){
   Object[] before=WifiConfigModel.fields(invalid,8);
   xi5 preview=(xi5)DitoCarrierProfile.apply(invalid,base);
   check(preview.r.isEmpty()&&(preview.y==null||preview.y.isEmpty()),"invalid IMSI/MNC preview has no invented outer or permanent EAP identity");
   check(preview.f.equals(Collections.singletonList(GATEWAY))&&preview.g.equals(IMS),"invalid credential preview still preserves visible DITO gateway/settings");
   Map<String,String> visible=WifiConfigModel.display(preview);
   check(visible.get("nai").isEmpty()&&visible.get("eap").isEmpty(),"invalid preview produces safe blank editor identity inputs");
   try{DitoHomeIdentity.connection(invalid,preview);throw new AssertionError("invalid preview became connectable");}
   catch(IllegalStateException expected){check(true,"connection still rejects invalid preview before scheduling");}
   unchanged(invalid,before);
  }

  // Unknown issuer + an explicit dedicated DITO selection follows the same real-card rule.
  fresh();ek5 foreign=card("310260123456789","8901234500123457393",3);
  xi5 nativeForeign=zl3.r(foreign),automatic=(xi5)CarrierPresets.defaults(foreign,null);
  check(automatic.r.equals(nativeForeign.r)&&Objects.equals(automatic.y,nativeForeign.y)&&automatic.f.equals(nativeForeign.f),"automatic non-DITO behavior is untouched");
  xi5 manual=(xi5)CarrierPresets.defaults(foreign,WifiConfigTest.values(CarrierPresets.KEY,DitoCarrierProfile.KEY));
  check(manual.r.equals(nai(foreign.a,"310","260"))&&manual.y.equals(manual.r)&&manual.f.equals(Collections.singletonList(GATEWAY)),"manual dedicated DITO gets selected gateway plus real three-digit authentication PLMN");
  check(!DitoHomeIdentity.isDito(foreign)&&DitoHomeIdentity.connection(foreign,manual)==foreign,"manual template is not learned as card evidence or a synthetic identity");
  xi5 legacy=(xi5)CarrierPresets.defaults(foreign,WifiConfigTest.values(CarrierPresets.KEY,DitoCarrierProfile.LEGACY_KEY));
  check(legacy.r.equals(manual.r)&&legacy.y.equals(manual.y),"legacy dedicated DITO alias uses the same authentication identity");
  xi5 selectedForeign=(xi5)CarrierPresets.defaults(foreign,WifiConfigTest.values(CarrierPresets.KEY,"310260|apple_test"));
  check(Objects.equals(selectedForeign.y,null),"this change does not force new permanent-EAP defaults on other presets");

  // Exercise the existing NAI popup's save/reopen/reset callbacks without new UI.
  fresh();ek5 current=card(ROAM,ID,2);zl5.b.value=WifiConfigTest.state(current,zl3.r(current));
  Activity activity=new Activity();us1 close=()->sc5.a;WifiConfigEditor.begin(activity,close);lu1 composer=new lu1();
  WifiConfigEditor.row("NAI","old",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);
  check(ak2.edits.get(0).value.equals(permanent)&&ak2.edits.get(3).value.equals(permanent),"existing editor prefills outer and permanent EAP separately");
  ak2.edits.get(0).change.i("anonymous@outer.example.org");xq0.press("保存");saveWait();
  gl5 saved=(gl5)zl5.b.value;
  check(saved.f.r.equals("anonymous@outer.example.org")&&saved.f.y.equals(permanent),"actual popup outer-only Save preserves card-derived permanent EAP");
  Map<String,String> savedValues=WifiConfigRuntime.snapshot().values;
  check(savedValues.get("nai").equals("anonymous@outer.example.org")&&!savedValues.containsKey("eap")&&!savedValues.containsKey("impi"),"popup Save persists only the changed identity field, preserving unrelated legacy device settings");
  WifiConfigEditor.row("NAI","old",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);
  check(ak2.edits.get(0).value.equals("anonymous@outer.example.org")&&ak2.edits.get(3).value.equals(permanent),"reopen shows explicit outer and unchanged permanent value");
  ak2.edits.get(3).change.i("chosen@eap.example.org");xq0.press("保存");saveWait();
  check(((gl5)zl5.b.value).f.y.equals("chosen@eap.example.org"),"actual popup explicitly saved EAP remains authoritative");
  WifiConfigEditor.row("NAI","old",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);xq0.press("重置为内置");saveWait();WifiConfigEditor.overlay(composer);
  savedValues=WifiConfigRuntime.snapshot().values;
  check(!savedValues.containsKey("nai")&&!savedValues.containsKey("eap")&&ak2.edits.get(0).value.equals(permanent)&&ak2.edits.get(3).value.equals(permanent),"existing group reset removes custom identities and refills current card defaults");
  xq0.cancel.a();activity.destroy();check(composer.depth==0,"existing editor groups remain balanced");
  System.out.println("PASS: "+passed+" dedicated DITO EAP routing, override, malformed-preview and editor assertions");
 }
}
