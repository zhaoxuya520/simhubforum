public enum lj5 { U,V,W }
