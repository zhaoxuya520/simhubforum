// Public native OMAPI transport boundary, including its concrete service and reader fields.
public final class qf3 {
    public android.se.omapi.SEService a;
    public android.se.omapi.Reader b;
}
