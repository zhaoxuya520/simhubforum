import java.util.*;
public class zl3 {
 public static int builds;
 public static xi5 r(ek5 card){
  builds++;
  return new xi5(lj5.U,"test-preset","Test","001","01",Arrays.asList("default.epdg.example.org"),
   "ims.example.org","ims",ak5.V,Arrays.asList("aes256"),Arrays.asList("sha256"),Arrays.asList("sha256"),
   Arrays.asList("modp2048"),Arrays.asList("aes256"),Arrays.asList("sha256"),20,false,
   "anonymous@nai.example.org",card.a+"@ims.example.org",true,1300,false,null,Arrays.asList(20,21),null,new Object(),null);
 }
}
