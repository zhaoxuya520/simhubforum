public class gl5 {
 public final String a;
 public final String b;
 public final boolean c;
 public final Object d;
 public final ek5 e;
 public final xi5 f;
 public final boolean g;
 public final String h;
 public final String i;
 public final String j;
 public final Phase k;
 public final boolean l;
 public final Object m;
 public final Object n;
 public final Long o;
 public final java.util.List<Object> p;
 public final java.util.List<Object> q;
 public final boolean r;
 public final String s;
 public final long t;
 public gl5(String a,String b,boolean c,Object d,ek5 e,xi5 f,boolean g,String h,String i,String j,Phase k,boolean l,Object m,Object n,Long o,java.util.List<Object> p,java.util.List<Object> q,boolean r,String s,long t) {
this.a=a;this.b=b;this.c=c;this.d=d;this.e=e;this.f=(xi5)cc.forserein.simhub.internal.WifiConfigRuntime.resolve(e,f);this.g=g;this.h=cc.forserein.simhub.internal.WifiConfigRuntime.epdg(e,h);this.i=cc.forserein.simhub.internal.WifiConfigRuntime.smsc(e,i);this.j=cc.forserein.simhub.internal.WifiConfigRuntime.imei(e,j);this.k=k;this.l=l;this.m=m;this.n=n;this.o=o;this.p=p;this.q=q;this.r=r;this.s=s;this.t=t;
}
}
