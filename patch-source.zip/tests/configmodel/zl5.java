public class zl5 {
 public static android.content.Context f;public static final Flow b=new Flow();
 public static boolean enabled;public static String lastLog;
 public static Object legacySettings;public static Object j(){return legacySettings;}
 public static void x(boolean value){enabled=value;}public static void b(String text){lastLog=text;}
}
