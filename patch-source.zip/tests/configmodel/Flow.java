public class Flow {
 public Object value;public int conflicts;public Runnable onCas;
 public Object getValue(){return value;}
 public boolean h(Object old,Object next){if(onCas!=null){onCas.run();onCas=null;return false;}if(conflicts-->0)return false;if(value!=old)return false;value=next;return true;}
}
