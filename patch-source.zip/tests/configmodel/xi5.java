public class xi5 {
 public final lj5 a;
 public final String b;
 public final String c;
 public final String d;
 public final String e;
 public final java.util.List<String> f;
 public final String g;
 public final String h;
 public final ak5 i;
 public final java.util.List<String> j;
 public final java.util.List<String> k;
 public final java.util.List<String> l;
 public final java.util.List<String> m;
 public final java.util.List<String> n;
 public final java.util.List<String> o;
 public final int p;
 public final boolean q;
 public final String r;
 public final String s;
 public final boolean t;
 public final int u;
 public final boolean v;
 public final String w;
 public final java.util.List<Integer> x;
 public final String y;
 public final Object z;
 public final String A;
 public xi5(lj5 a,String b,String c,String d,String e,java.util.List<String> f,String g,String h,ak5 i,java.util.List<String> j,java.util.List<String> k,java.util.List<String> l,java.util.List<String> m,java.util.List<String> n,java.util.List<String> o,int p,boolean q,String r,String s,boolean t,int u,boolean v,String w,java.util.List<Integer> x,String y,Object z,String A) {
this.a=a;this.b=b;this.c=c;this.d=d;this.e=e;this.f=f;this.g=g;this.h=h;this.i=i;this.j=j;this.k=k;this.l=l;this.m=m;this.n=n;this.o=o;this.p=p;this.q=q;this.r=r;this.s=s;this.t=t;this.u=u;this.v=v;this.w=w;this.x=x;this.y=y;this.z=z;this.A=A;
}
}
