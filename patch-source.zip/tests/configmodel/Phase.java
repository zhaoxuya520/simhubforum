public class Phase {public boolean busy;public boolean z(){return busy;} }
