public class ek5 {public final String a,b;public ek5(String imsi,String iccid){a=imsi;b=iccid;} }
