public class ek5 {
 public final String a,b;public final int c;public final String d,e,g;public String f;public Object h;
 public ek5(String imsi,String iccid){this(imsi,iccid,2,null,null,null,null,null);}
 public ek5(String imsi,String iccid,int mnc,String gid1,String gid2,String smsc,String msisdn,Object isim){a=imsi;b=iccid;c=mnc;d=gid1;e=gid2;f=smsc;g=msisdn;h=isim;}
 public String b(){return a.substring(0,3);}public String c(){return a.substring(3,3+c);}public String d(){return b()+c();}
}
