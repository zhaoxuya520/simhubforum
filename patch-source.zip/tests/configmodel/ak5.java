public enum ak5 { U("ipv4"),V("ipv6"),W("dual");public final String T;ak5(String s){T=s;} }
