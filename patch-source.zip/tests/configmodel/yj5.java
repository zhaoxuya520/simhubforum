import java.util.*;
/** Pinned native constructor's relevant semantics, including registerExpires' default mask. */
public class yj5 {
 public final boolean a,c,d,f,h,j,l,m,n,r,s,t,u,v,w,x,y;public final String b,i,o,p;public final Set<?> e;public final Integer g,q;public final List<?> k;
 public yj5(boolean pani,String country,Set<?> codes,Integer max,String agent,List<?> retry,int mask){
  a=(mask&1)!=0||pani;b=(mask&2)!=0?null:country;c=(mask&4)==0;d=(mask&8)==0;e=(mask&16)!=0?Collections.emptySet():codes;f=(mask&32)==0;g=(mask&64)!=0?null:max;h=(mask&128)==0;i=(mask&256)!=0?null:agent;j=(mask&512)==0;k=(mask&1024)!=0?Collections.emptyList():retry;l=(mask&2048)==0;m=(mask&8192)!=0;n=(mask&16384)==0;o=(mask&32768)!=0?null:"path,gruu";p=(mask&65536)!=0?null:"OPTIONS,REGISTER,SUBSCRIBE,NOTIFY,PUBLISH,INVITE,ACK,BYE,CANCEL,UPDATE,PRACK,REFER,INFO,MESSAGE";q=(mask&131072)!=0?null:7200;r=(mask&262144)==0;s=(mask&524288)==0;t=(mask&1048576)==0;u=(mask&2097152)==0;v=(mask&4194304)==0;w=(mask&8388608)==0;x=(mask&16777216)==0;y=(mask&134217728)==0;
 }
}
