import cc.forserein.simhub.internal.RcsChatBinding;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class RcsChatBindingTest {
    private static final String ICCID = "8944000000000000001";
    private static final String OWN = "+447700900001";
    private static final String OTHER = "+447700900002";
    private static final String PEER = "+441632960123";

    public static final class Card { public final String b; Card(String iccid) { b = iccid; } }
    public static final class State { public Object e; State(Object card) { e = card; } }
    public static final class Engine { public Object c,s; Engine(Object card) { c=card; } }
    public static final class Registration {
        public final List<String> a;
        Registration(List<String> numbers) { a = numbers; }
        public boolean equals(Object other) { return other instanceof Registration && a.equals(((Registration) other).a); }
        public int hashCode() { return a.hashCode(); }
    }

    static int checks;
    static Engine engine;
    static State state;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void denied(Runnable op, String label) {
        try { op.run(); } catch (IllegalArgumentException | IllegalStateException expected) {
            checks++;
            return;
        }
        throw new AssertionError(label);
    }
    static void fresh() {
        Card card = new Card(ICCID);
        state = new State(card); engine = new Engine(card);
        zl5.b.value = state; zl5.n = engine;
    }
    static Registration accepted(List<String> network, int seconds, String... nativeVisible) {
        Registration result = new Registration(Arrays.asList(nativeVisible));
        RcsChatBinding.remember(engine,result,network,seconds);
        engine.s=result;
        return result;
    }
    static RcsChatBinding capture(String peer) { return RcsChatBinding.capture(state,peer); }

    static void systemLine() {
        fresh();
        String iccid = RcsSystemLineTest.CARD, self = RcsSystemLineTest.LINE;
        android.telephony.SubscriptionManager manager = RcsSystemLineTest.fresh();
        RcsSystemLineTest.line(manager, 7, "", self);
        state.e = new Card(iccid); zl5.b.value = state; zl5.n = null;
        zl5.j = new Object();
        denied(() -> capture(PEER),"an external reader cannot substitute its ICCID for the system subscription");
        zl5.j = new qf3();
        RcsChatBinding system = capture(PEER);
        system.validateProvider(self);
        check(system.cardKey.equals(RcsChatBinding.lineKey(state)),"works without a SIMHub IMS connection");
        denied(() -> system.validateProvider(OTHER),"system/TAPI own number mismatch");
        Object oldReader = zl5.j;
        zl5.j = new qf3();
        denied(system::validateCurrent,"replacement local reader invalidates an existing conversation");
        zl5.j = oldReader;
        manager.active = Arrays.asList(new android.telephony.SubscriptionInfo(8,iccid));
        RcsSystemLineTest.line(manager,8,self,"");
        denied(system::validateCurrent,"a replacement subId cannot reuse an open view even when number and ICCID match");
        manager.active = Arrays.asList(new android.telephony.SubscriptionInfo(7,iccid));
        RcsSystemLineTest.line(manager,7,OTHER,"");
        denied(() -> system.validateProvider(self),"system line changed while provider operation pending");
        RcsSystemLineTest.line(manager,7,self,"");
        system.validateCurrent();
        manager.activeError = new SecurityException("synthetic denied");
        denied(system::validateCurrent,"revoked number/subscription access invalidates a previous result");
        denied(() -> capture(PEER),"current permission required before opening system path");
        manager.activeError = null;
        state.e = new Card(ICCID);
        denied(system::validateCurrent,"selecting a different card while RCS callback pending");
        zl5.j = null; zl5.f = null;
    }

    public static void main(String[] args) {
        fresh();
        check(RcsChatBinding.lineKey(state).matches("[0-9a-f]{64}"),"card switch preferences before registration");
        denied(() -> capture(PEER), "cannot open before genuine registrar evidence");
        // The native visible list is identical in the first two calls. Only one came from a header.
        accepted(Collections.<String>emptyList(),3600,"tel:"+OWN);
        denied(() -> capture(PEER), "locally configured fallback IMPU is not line proof");
        Registration first = accepted(Collections.singletonList("tel:"+OWN),3600,"tel:"+OWN);
        RcsChatBinding bound = capture("0044 (1632) 960123");
        check(PEER.equals(bound.peer),"explicit international peer normalization");
        check(bound.cardLabel.endsWith("0001")&&!bound.cardLabel.contains(ICCID),"card label displays only last four");
        check(RcsChatBinding.lineKey(state).equals(bound.cardKey),"RCS preference and conversation keys match");
        check(bound.cardKey.matches("[0-9a-f]{64}")&&!bound.cardKey.contains(ICCID),"key does not expose ICCID");
        bound.validateCurrent(); bound.validateProvider(OWN);
        denied(() -> bound.validateProvider(OTHER),"wrong provider self identity");
        denied(() -> bound.validateProvider(null),"missing provider identity");
        denied(() -> bound.validateProvider("447700900001"),"national or private identities cannot prove line");
        Registration sameLooking = new Registration(first.a);
        check(first.equals(sameLooking),"structurally equal test registrations");
        engine.s = sameLooking;
        denied(bound::validateCurrent,"different but structurally equal registration cannot inherit proof");
        engine.s = first;
        bound.validateCurrent();
        engine.s = null;
        denied(bound::validateCurrent,"deregistered underlying engine");
        engine.s = first;
        // Allow legitimate re-registration with a new object and genuine evidence for the same line.
        accepted(Arrays.asList("sips:"+OWN+"@ims.example.invalid;user=phone","sip:alias@ims.example.invalid"),1800);
        bound.validateCurrent();bound.validateProvider(OWN);
        accepted(Collections.singletonList("tel:"+OTHER),1800);
        denied(bound::validateCurrent,"changed current registered line");
        denied(() -> bound.validateProvider(OWN),"old self line removed on refresh");
        denied(() -> bound.validateProvider(OTHER),"new line did not own original view");
        accepted(Collections.singletonList("tel:"+OWN),3600);
        Object newEngine = new Engine(state.e);
        zl5.n = newEngine;
        denied(bound::validateCurrent,"changed engine on same ICCID invalidates old view");
        zl5.n=engine;
        zl5.b.value = new State(new Card("8944000000000000002"));
        denied(bound::validateCurrent,"different active ICCID invalidates old view");
        denied(() -> capture(PEER),"capturing a stale conversation page after changing active card");
        zl5.b.value = new State(new Card(ICCID));
        bound.validateCurrent();
        engine.c=new Card("8944000000000000002");
        denied(bound::validateCurrent,"captured engine must still belong to current card");
        engine.c=new Card(ICCID);
        bound.validateCurrent();
        RcsChatBinding.clear(engine);
        denied(bound::validateCurrent,"immediate deregistration clears previous proof");
        accepted(Collections.singletonList("tel:"+OWN),0);
        denied(() -> capture(PEER),"zero lifetime");
        accepted(Collections.singletonList("tel:"+OWN),-1);
        denied(() -> capture(PEER),"negative lifetime");
        for (String bad : new String[]{"sip:234330000000001@ims.example.invalid","sip:+44123@",
                "sip:+44x1@ims.example.invalid","tel:"+OWN+";ext=123",OWN,"sip:"+OWN+"@a@b"}) {
            accepted(Collections.singletonList(bad),20,bad);
            denied(() -> capture(PEER),"unusable registered identity "+bad);
        }
        accepted(Arrays.asList("tel:"+OWN,"sip:"+OTHER+"@ims.example.invalid"),3600);
        RcsChatBinding unicodePeer = capture("tel:＋４４１６３２９６０１２３");
        unicodePeer.validateProvider(OTHER);
        check(unicodePeer.peer.equals(PEER),"Unicode numeric peer");
        for (String unsupported : new String[]{null,"","+","00","166","0123","+04999","+44999999999999999",
                "sip:"+PEER+"@ims.example.invalid","+44 (0)1632 960123","+4412x345","+44;ext=93","++447700900000"}) {
            denied(() -> capture(unsupported),"ambiguous peer");
        }
        for (String missing : new String[]{"","12345","0000000000000000000","894400000000000000X"}) {
            state.e=new Card(missing);zl5.b.value=state;engine.c=state.e;
            denied(() -> capture(PEER),"no trustworthy ICCID");
        }
        denied(() -> RcsChatBinding.capture(null,PEER),"missing UI state");
        systemLine();
        System.out.println("PASS: "+checks+" checks of profile and registered RCS line matching");
    }
}
