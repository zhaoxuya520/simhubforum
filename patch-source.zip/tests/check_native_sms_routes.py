#!/usr/bin/env python3
"""Check both native SMS composers, their send actions and IMS registration."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from verify_signed import dex_strings

# Pinned native methods after applying the SMS centre fix and before adding RCS.
METHODS = {
    'pk5': ('public static final j(Lem0;Lgl5;Ljava/lang/String;Ljava/lang/String;Lus1;Llu1;I)V',
            '835a72455a42ffa4333a8acbbd935e78cd7107f53ccb691a2ab7e055acec1551'),
    'j51': ('public final a()Ljava/lang/Object;',
            '68229828202fa21b44098efce6400ef6723054db5e41960dba8ac7df2e475097'),
    'mc0': ('public final d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;',
            '7936a627933ef1c69490d1712db0a18dccefd3e8480b31333d53127a09fc4cc3'),
    'zz': ('public final a()Ljava/lang/Object;',
           '97fe3422825d5e10fc9648934ca9ab802e07b5fbb56ea0985bb2dbe852f73f03'),
    'o82': ('public final v(Ldt0;)Ljava/lang/Object;',
            '510b88ecfdd7545ec0c50aa66e27b1b151ce305af89de6169d426b6fa3d648af'),
}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('smali', type=Path)
    p.add_argument('apk', type=Path)
    p.add_argument('--report', required=True, type=Path)
    args = p.parse_args()

    verified = {}
    for name, (signature, expected) in METHODS.items():
        definition = (args.smali / (name + '.smali')).read_text()
        marker = '.method ' + signature + '\n'
        assert definition.count(marker) == 1, (name, signature)
        start = definition.index(marker)
        end = definition.index('\n.end method', start) + len('\n.end method')
        actual = hashlib.sha256(definition[start:end].encode()).hexdigest()
        assert actual == expected, f'Native method changed: {name}.{signature}'
        verified[name + '.' + signature] = actual

    tools = Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery'))
    xml = subprocess.check_output([str(tools / 'sdk/android-15/aapt2'), 'dump', 'xmltree',
                                   '--file', 'AndroidManifest.xml', str(args.apk)], text=True)
    for marker in ('com.gsma.services.', 'android.provider.Telephony.SMS_DELIVER'):
        assert marker not in xml, f'Unexpected manifest declaration: {marker}'

    markers = (b'Lcc/forserein/simhub/internal/Rcs', b'cc.forserein.simhub.internal.Rcs',
               b'com/gsma/services/rcs/', b'com.gsma.services.rcs.', b'com.gsma.services.permission.RCS')
    with ZipFile(args.apk) as archive:
        dex_names = sorted(n for n in archive.namelist() if re.fullmatch(r'classes(?:\d+)?\.dex', n))
        assert 'classes.dex' in dex_names
        for name in dex_names:
            for value in dex_strings(archive.read(name)):
                assert not any(marker in value for marker in markers), f'Unexpected RCS reference in {name}: {value!r}'

    report = dict(status='passed', apk_sha256=hashlib.sha256(args.apk.read_bytes()).hexdigest(),
                  native_method_sha256=verified, dex_files_checked=dex_names,
                  rcs_manifest_entries_absent=True, rcs_helpers_absent=True)
    args.report.write_text(json.dumps(report, indent=2) + '\n')
    print('Native SMS composer/send and IMS registration method pins verified; RCS integration absent.')

if __name__ == '__main__':
    main()
