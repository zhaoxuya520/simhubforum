import cc.forserein.simhub.internal.RcsChatUi;

/** No RCS service, card access or outgoing message: only shared-composer ownership. */
public class RcsChatDraftTest {
 static int passed;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);passed++;}
 static void reject(RcsChatUi.DraftState draft,String message){try{draft.begin();throw new AssertionError(message);}catch(IllegalStateException expected){passed++;}}
 private static void cardChangeModes() throws ReflectiveOperationException {
  Class<?> page=Class.forName(RcsChatUi.class.getName()+"$Session");
  java.lang.reflect.Constructor<?> construct=page.getDeclaredConstructor(android.app.Activity.class,Object.class,String.class,Object.class,String.class,boolean.class);
  construct.setAccessible(true);
  java.lang.reflect.Method retain=page.getDeclaredMethod("retainDraftMode",page);
  retain.setAccessible(true);
  java.lang.reflect.Field on=page.getDeclaredField("on"),confirm=page.getDeclaredField("confirmLine"),history=page.getDeclaredField("historyKey");
  on.setAccessible(true);confirm.setAccessible(true);history.setAccessible(true);
  Object nativeDraft=new Object();
  Object old=construct.newInstance(null,null,"+44123",nativeDraft,"card-a",true);
  on.setBoolean(old,true);history.set(old,"old-card-history");
  Object different=construct.newInstance(null,null,"+44123",nativeDraft,"card-b",true);
  retain.invoke(different,old);
  java.lang.reflect.Field sessions=RcsChatUi.class.getDeclaredField("SESSIONS");
  sessions.setAccessible(true);
  @SuppressWarnings("unchecked") java.util.Map<Object,Object> registry=(java.util.Map<Object,Object>)sessions.get(null);
  registry.put(nativeDraft,different);
  try {
   check(!RcsChatUi.showSmsHint(nativeDraft),"an RCS draft hides the ordinary IMS registration hint");
   on.setBoolean(different,false);
   check(RcsChatUi.showSmsHint(nativeDraft),"explicit SMS restores its registration hint");
   on.setBoolean(different,true);
  } finally {registry.remove(nativeDraft);}
  check(on.getBoolean(different)&&confirm.getBoolean(different),"changing SIM holds the existing RCS draft until reconfirmation");
  check(history.get(different)==null,"same recipient on the other SIM never inherits previous card history");
  Object edited=construct.newInstance(null,null,"+441234",nativeDraft,"card-b",true);
  retain.invoke(edited,different);
  check(on.getBoolean(edited)&&confirm.getBoolean(edited),"editing recipient does not bypass confirmation after a SIM change");
  Object noLine=construct.newInstance(null,null,"",nativeDraft,null,true);
  Object typed=construct.newInstance(null,null,"+44123",nativeDraft,null,true);
  on.setBoolean(noLine,true);retain.invoke(typed,noLine);
  check(on.getBoolean(typed)&&!confirm.getBoolean(typed),"editing a recipient with no verified SIM cannot switch an RCS draft to SMS");
  on.setBoolean(noLine,false);Object off=construct.newInstance(null,null,"+44123",nativeDraft,null,true);
  retain.invoke(off,noLine);
  check(!on.getBoolean(off)&&!confirm.getBoolean(off),"ordinary SMS drafts stay in SMS mode");
 }
 public static void main(String[] args) throws ReflectiveOperationException {
  RcsChatUi.DraftState draft=new RcsChatUi.DraftState();reject(draft,"empty draft cannot send");draft.edit("  \n ");reject(draft,"blank draft cannot send");
  draft.edit("第一条 😀");RcsChatUi.Pending first=draft.begin();check(draft.busy()&&first.text.equals("第一条 😀"),"submitted UTF-8 text is retained exactly");reject(draft,"double click cannot submit twice");
  check(!draft.finish(first,false,false)&&draft.text().equals(first.text)&&!draft.busy(),"failure preserves original draft and releases busy");
  first=draft.begin();check(draft.finish(first,true,false)&&draft.text().isEmpty()&&!draft.busy(),"actual acceptance clears the matching draft");
  draft.edit("old");first=draft.begin();draft.edit("new");check(!draft.finish(first,true,false)&&draft.text().equals("new"),"late acceptance never clears newly edited text");
  draft.edit("same");first=draft.begin();draft.edit("changed");draft.edit("same");check(!draft.finish(first,true,false)&&draft.text().equals("same"),"an edited revision is retained even if its text returns to the old value");
  first=draft.begin();check(!draft.finish(first,false,true)&&draft.uncertain()&&draft.text().equals("same")&&!draft.busy(),"unknown result keeps text and releases busy without allowing another send");reject(draft,"uncertain result cannot retry automatically");
  draft.stop();check(!draft.uncertain()&&!draft.busy()&&draft.text().equals("same"),"explicit Off resets routing state without changing original composer text");
  first=draft.begin();draft.stop();RcsChatUi.Pending second=draft.begin();check(!draft.finish(first,true,false)&&draft.busy()&&draft.text().equals("same"),"old callback after Off/On cannot complete the new request");
  check(draft.finish(second,true,false)&&draft.text().isEmpty(),"only the current request may clear text");
  xl3 nativeDraft=new xl3("SMS text");check(!RcsChatUi.trySend("+441234567890",nativeDraft),"absent RCS session leaves original SMS callback untouched");
  check(RcsChatUi.sendEnabled(true,"+441234567890",nativeDraft)&&!RcsChatUi.sendEnabled(false,"+441234567890",nativeDraft),"Off preserves both native enabled and disabled predicates");
  xl3 nativePeer=new xl3("+441234567890");check(!RcsChatUi.trySendDraft(nativePeer,nativeDraft)&&RcsChatUi.sendEnabledDraft(true,nativePeer,nativeDraft),"new-message Off delegates unchanged");
  check(nativeDraft.getValue().equals("SMS text")&&nativePeer.getValue().equals("+441234567890"),"RCS Off never clears recipient or body");
  check(RcsChatUi.showSmsHint(nativeDraft),"ordinary SMS retains the registration hint");
  cardChangeModes();
  System.out.println("PASS: "+passed+" shared-composer draft, failure, uncertainty and original SMS routing assertions");
 }
}
