import cc.forserein.simhub.internal.RcsSystemLine;
import android.content.Context;
import android.os.Build;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import java.util.*;

/** Actual adapter with explicit synthetic Android service/subscription/permission boundaries. */
public final class RcsSystemLineTest {
    static final String CARD="8944000000000000246",OTHER="8949000000000000246",LINE="+441632960246";
    static int passed;
    static class Ctx extends Context {
        SubscriptionManager manager; int requests;
        Ctx(SubscriptionManager manager){this.manager=manager;}
        @Override public <T>T getSystemService(Class<T> type){requests++;return type.cast(manager);}
    }
    static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);passed++;}
    static SubscriptionManager fresh(){
        Build.VERSION.SDK_INT=35;SubscriptionManager m=new SubscriptionManager();
        m.active=Arrays.asList(new SubscriptionInfo(7,CARD));zl5.f=new Ctx(m);return m;
    }
    static void line(SubscriptionManager m,int id,String carrier,String ims){m.numbers.put(id+":2",carrier);m.numbers.put(id+":3",ims);}
    static void absent(String label){check(RcsSystemLine.query(CARD)==null,label);}
    static void matches(int id,String number,String label){RcsSystemLine.Match m=RcsSystemLine.query(CARD);check(m!=null&&m.subId==id&&number.equals(m.number),label);}
    public static void main(String[] args){
        Context old=zl5.f;int oldApi=Build.VERSION.SDK_INT;
        try {
            SubscriptionManager m=fresh();line(m,7,LINE,LINE);matches(7,LINE,"agreeing carrier/IMS source on exact ICCID");
            check(m.activeCalls==2&&m.calls.size()==4,"subscription membership and selected line rechecked");
            m=fresh();line(m,7,LINE,"");matches(7,LINE,"carrier source alone available");
            m=fresh();line(m,7,null,LINE);matches(7,LINE,"IMS source alone available");
            m=fresh();line(m,7,LINE,"+441632960247");absent("conflicting sources rejected");
            for(String bad:new String[]{null,"","01632960246","00441632960246","tel:"+LINE," "+LINE,LINE+" ","+0441632960246","+4416x960246","+１２３４","+1234567890123456"}){
                m=fresh();line(m,7,bad,"");absent("no guessing or normalization for unavailable/invalid network number");
            }
            for(String bad:new String[]{null,"","123456","0000000000000000000",CARD+"F"," "+CARD}){
                m=fresh();line(m,7,LINE,LINE);check(RcsSystemLine.query(bad)==null,"incomplete/redacted requested ICCID rejected");
                check(m.activeCalls==0&&m.calls.isEmpty(),"invalid identity performs no platform enumeration");
            }
            m=fresh();line(m,7,LINE,LINE);Build.VERSION.SDK_INT=32;absent("pre33 safely unavailable");check(((Ctx)zl5.f).requests==0,"pre33 performs no service lookup");
            m=fresh();line(m,7,LINE,LINE);Build.VERSION.SDK_INT=33;matches(7,LINE,"minimum API33 is supported");
            fresh();zl5.f=null;absent("missing app context");
            fresh();zl5.f=new Ctx(null);absent("device without subscription service");
            m=fresh();m.active=null;absent("unavailable active list");
            m=fresh();m.active=Collections.emptyList();absent("no active subscription");
            m=fresh();m.active=Arrays.asList(new SubscriptionInfo(7,OTHER));line(m,7,LINE,LINE);absent("same number on another ICCID does not select it");check(m.calls.isEmpty(),"no number lookup before matching a physical identity");
            m=fresh();m.active=Arrays.asList(new SubscriptionInfo(7,CARD),new SubscriptionInfo(8,CARD));absent("duplicate target ICCID is ambiguous");
            m=fresh();m.active=Arrays.asList(new SubscriptionInfo(7,CARD),new SubscriptionInfo(7,OTHER));absent("duplicate subscription IDs are inconsistent");
            for(String bad:new String[]{"","1234",null,"0000000000000000000"}){
                m=fresh();m.active=Arrays.asList(new SubscriptionInfo(7,bad));absent("redacted/malformed active ICCID rejected");
            }
            for(int bad:new int[]{-1,Integer.MAX_VALUE}){m=fresh();m.active=Arrays.asList(new SubscriptionInfo(bad,CARD));absent("no default/invalid subscription fallback");check(m.calls.isEmpty(),"invalid ID is never passed to number API");}
            m=fresh();m.active=Arrays.asList(new SubscriptionInfo(7,CARD),null);absent("null active item rejected");
            for(RuntimeException failure:new RuntimeException[]{new SecurityException(),new IllegalStateException(),new UnsupportedOperationException()}){
                m=fresh();m.activeError=failure;absent("active-list permissions/platform failure unavailable");
                for(int source:new int[]{2,3}){m=fresh();line(m,7,LINE,LINE);m.errors.put("7:"+source,failure);absent("number-source failure cannot be silently bypassed");}
            }
            m=fresh();m.active=Arrays.asList(new SubscriptionInfo(7,CARD),new SubscriptionInfo(8,OTHER));line(m,7,LINE,LINE);line(m,8,"+493023125000","");matches(7,LINE,"two fully inspectable distinct subscriptions");
            m=fresh();m.active=Arrays.asList(new SubscriptionInfo(7,CARD),new SubscriptionInfo(8,OTHER));line(m,7,LINE,LINE);line(m,8,LINE,LINE);absent("same registered number on two active subscriptions is ambiguous");
            m=fresh();m.active=Arrays.asList(new SubscriptionInfo(7,CARD),new SubscriptionInfo(8,OTHER));line(m,7,LINE,LINE);absent("unavailable other active number cannot establish uniqueness");
            m=fresh();m.active=Arrays.asList(new SubscriptionInfo(7,CARD),new SubscriptionInfo(8,OTHER));line(m,7,LINE,LINE);m.errors.put("8:2",new SecurityException());absent("other active number permission missing cannot establish uniqueness");
            m=fresh();line(m,7,LINE,LINE);m.laterActive=Arrays.asList(new SubscriptionInfo(8,CARD));absent("subscription changed during query");
            m=fresh();line(m,7,LINE,LINE);m.laterActive=Arrays.asList(new SubscriptionInfo(7,OTHER));absent("card changed during query");
            m=fresh();line(m,7,LINE,LINE);m.laterActive=Collections.emptyList();absent("card removed during query");
            m=fresh();line(m,7,LINE,LINE);RcsSystemLine.Match before=RcsSystemLine.query(CARD);check(before!=null,"initial match");m.active=Arrays.asList(new SubscriptionInfo(9,CARD));line(m,9,LINE,LINE);RcsSystemLine.Match after=RcsSystemLine.query(CARD);check(after!=null&&after.subId!=before.subId,"subId retained for binding repeat check; no cached match");
            m=fresh();line(m,7,LINE,LINE);matches(7,LINE,"initial source number");line(m,7,"+441632960247","+441632960247");matches(7,"+441632960247","subsequent query reads updated source number");
        } finally {zl5.f=old;Build.VERSION.SDK_INT=oldApi;}
        System.out.println("PASS: "+passed+" Android RCS line lookup assertions (synthetic platform; no permissions/network)");
    }
}
