#!/usr/bin/env python3
"""Execute shipped notification entry points with explicit Android/call-controller fixtures."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('apk',type=Path);p.add_argument('decoded',type=Path);p.add_argument('--report',type=Path,required=True);p.add_argument('--legacy',action='store_true');a=p.parse_args()
src=ROOT/'validation/native-notification';adapter=ROOT/'validation/native-carrier'
toolroot=Path(os.environ.get('SIMHUB_DEX2JAR_TOOLS','/workspace/tools/dex2jar-v2.4'));tools=toolroot/'dex-tools-v2.4';lib=tools/'lib'
android=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
manifest=json.loads((adapter/'toolchain.json').read_text());distribution=toolroot/'dex-tools-v2.4.zip'
assert hashlib.sha256(distribution.read_bytes()).hexdigest()==manifest['distribution_sha256']
with zipfile.ZipFile(distribution)as z:
 expected={Path(n).name:z.read(n)for n in z.namelist()if '/lib/'in n and n.endswith('.jar')}
 assert set(expected)=={f.name for f in lib.glob('*.jar')}
 for name,contents in expected.items():assert (lib/name).read_bytes()==contents,name
work=a.report.parent/('native-notification-legacy'if a.legacy else'native-notification-current');work.mkdir(parents=True,exist_ok=True);classes=work/'classes';classes.mkdir(exist_ok=True)
logs=[]
def run(*args):
 r=subprocess.run(list(map(str,args)),cwd=ROOT,capture_output=True,text=True);logs.append(r.stdout+r.stderr)
 (work/'probe.log').write_text('\n'.join(logs))
 if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
 return r.stdout
asm=os.pathsep.join(str(lib/f)for f in ['asm-9.5.jar','asm-tree-9.5.jar'])
run('java','-jar',android/'ecj-3.40.0.jar','-17','-cp',asm,'-d',classes,adapter/'NormalizeR8Constructors.java')
run('sh',tools/'d2j-dex2jar.sh','-f','-o',work/'translated.jar',a.apk)
run('python3',adapter/'normalize_r8_constructors.py',a.decoded/'smali',work/'constructors.tsv')
run('java','-cp',str(classes)+os.pathsep+asm,'NormalizeR8Constructors',work/'translated.jar',work/'constructors.tsv',work/'probe.jar')
cp=os.pathsep.join(map(str,[work/'probe.jar',android/'sdk/android-35/android.jar']))
fixtures=sorted(f for f in src.rglob('*.java')if 'controller' not in f.relative_to(src).parts and f.name!='PrepareNativeController.java')
run('java','-jar',android/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-cp',cp,'-d',classes,*fixtures)
for model in ['cc/forserein/simhub/vowifi/calling/CallActionReceiver','cc/forserein/simhub/ui/call/CallActivity','u00','z00','y00','cc/forserein/simhub/internal/CallNotificationGuard']:
 assert not (classes/(model+'.class')).exists(),'Actual APK notification class replaced: '+model
out=run('java','-noverify','-cp',os.pathsep.join(map(str,[classes,work/'probe.jar',android/'sdk/android-35/android.jar'])),'NativeNotificationProbe','legacy'if a.legacy else'current')
match=re.search(r'NATIVE_NOTIFICATION (?:legacy_regression_reproduced|current_passed)=true checks=(\d+)',out);assert match,out
# Second process uses actual controller methods and actual d10 command objects.
# Only singleton bootstrap is bypassed, with method instruction fingerprints checked.
controller_classes=work/'controller-classes';controller_classes.mkdir(exist_ok=True)
controller_asm=os.pathsep.join(str(lib/f)for f in ['asm-9.5.jar','asm-tree-9.5.jar','asm-util-9.5.jar'])
run('java','-jar',android/'ecj-3.40.0.jar','-17','-cp',controller_asm,'-d',classes,src/'PrepareNativeController.java')
run('java','-cp',str(classes)+os.pathsep+controller_asm,'PrepareNativeController',work/'probe.jar',work/'controller.jar')
controller_cp=os.pathsep.join(map(str,[work/'controller.jar',android/'sdk/android-35/android.jar']))
controller_fixtures=sorted((src/'controller').glob('*.java'))+sorted((src/'android').rglob('*.java'))+[src/n for n in ['xz.java','yz.java','w10.java']]
run('java','-jar',android/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-cp',controller_cp,'-d',controller_classes,*controller_fixtures)
for model in ['k10','d10','u00','c10','cc/forserein/simhub/vowifi/calling/CallActionReceiver','cc/forserein/simhub/internal/CallNotificationGuard']:
 assert not (controller_classes/(model+'.class')).exists(),'Actual APK controller method class replaced: '+model
controller_out=run('java','-noverify','-cp',str(controller_classes)+os.pathsep+controller_cp,'NativeNotificationControllerProbe','legacy'if a.legacy else'current')
controller_match=re.search(r'NATIVE_NOTIFICATION_CONTROLLER (?:legacy_regression_reproduced|current_passed)=true checks=(\d+)',controller_out);assert controller_match,controller_out
report=dict(apk_sha256=hashlib.sha256(a.apk.read_bytes()).hexdigest(),checks=int(match[1])+int(controller_match[1]),entry_checks=int(match[1]),controller_checks=int(controller_match[1]),legacy_regression_reproduced=a.legacy,
 actual_apk_notification_receiver=True,actual_apk_activity_on_create_and_new_intent=True,actual_apk_activity_answer_and_permission_callback=True,
 actual_apk_call_models=True,actual_apk_notification_guard=not a.legacy,
 actual_native_controller_methods_executed=(["h","j","e","l"]if a.legacy else["b","h","j","e","l","p"]),actual_native_d10_command_constructor=True,
 controller_static_initializer_bypassed_only_in_jvm_probe=True,controller_method_bytecode_fingerprints_preserved=True,
 explicit_android_and_compose_boundary_fixtures=True,explicit_call_state_and_sip_scheduling_fixtures=True,
 pending_intent_identity_is_platform_model=True,device_tested=False,art_execution=False,
 covered=(["old decline and hangup dispatch to current B from stale A intent","old first/new Activity answer dispatch to current B","old unbound decline dispatches to current call","old delayed microphone grant dispatches to replacement call","actual native d10 captures replacement B for stale decline/hangup"]if a.legacy else['stale call A notification after call B starts','initial and reused Activity answer entry points','legacy unbound actions rejected',
 'SIP call ID plus per-call token match','valid call phase and direction','unique PendingIntent data across calls despite same requestCode',
 'rendered snapshot preserved after global current-call change','microphone permission grant/denial/repeat/deferred replacement',
 'new call notification cannot overwrite outstanding permission request for prior call',
 'actual native final-call selection changed between validation and command capture','actual d10 captures validated original call',
 'unscoped native and same-call UI controls remain enabled']))
a.report.write_text(json.dumps(report,indent=2)+'\n');print(out.strip());print(controller_out.strip())
