import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import java.util.*;

/** Isolated preferences/model fixtures only: no SIM access or SMS transport. */
public class SmsRecoverySaveTest {
 static int passed;static DitoHomeIdentityTest.Ctx context;static ek5 card;
 static final String A="+441234567890",B="+441234567891",C="+441234567892";
 static final String LONG=EapIdentityValidationTest.repeat("é",506)+"@x.org";
 static final String PREFS="wifi_config_overrides_v1";
 public static class Engine {public Object c;Engine(Object card){c=card;}}
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);passed++;}
 interface Op{void run()throws Exception;}
 static void reject(Op op,String message)throws Exception{try{op.run();throw new AssertionError(message);}catch(IllegalArgumentException|IllegalStateException expected){passed++;}}
 static WifiConfigTest.Prefs prefs(){return context.store(PREFS);}
 static String key()throws Exception{return WifiConfigRuntime.cardKey(card);}
 static String record()throws Exception{return prefs().data.get(key());}
 static Map<String,String> good(){return WifiConfigTest.values(CarrierPresets.KEY,"20404|apple_vodafone_nl","domain","kept.ims.example.org","epdg","kept.epdg.example.org","imei","490154203237518","smsc",A,"smsc_list",A+"\n"+B);}
 static String init(Map<String,String> values)throws Exception{
  context=new DitoHomeIdentityTest.Ctx();zl5.f=context;card=new ek5("204049876543210","8944011234567890123");card.f="+449999999999";
  String raw=WifiConfigValues.encode(values);prefs().data.put(key(),raw);zl5.b.onCas=null;zl5.b.conflicts=0;zl5.b.value=WifiConfigTest.state(card,zl3.r(card));((gl5)zl5.b.value).k.busy=true;return raw;
 }
 static Map<String,String> changed(WifiConfigRuntime.Snapshot snapshot){Map<String,String> draft=new LinkedHashMap<>(snapshot.values);draft.put("smsc",C);draft.put("smsc_list",C+"\n"+B);return draft;}
 static List<String> unrelated(String raw){List<String> rows=new ArrayList<>();for(String line:raw.split("\n",-1))if(!line.startsWith("smsc\t")&&!line.startsWith("smsc_list\t")&&!line.matches("[ \\t\\r]*"))rows.add(line);return rows;}
 static void render(lu1 composer){WifiConfigEditor.smsCenterEntry(((gl5)zl5.b.value).i,composer);}
 static void open(lu1 composer){ak2.actions.clear();render(composer);ak2.actions.get(0).a();render(composer);}
 static void waitSave()throws Exception{long end=System.nanoTime()+2_000_000_000L;while(Handler.tasks.isEmpty()&&System.nanoTime()<end)Thread.sleep(5);check(!Handler.tasks.isEmpty(),"actual editor save callback completes");Handler.drain();}
 static void reproduceBaseline()throws Exception{
  for(String bad:new String[]{"eap","smsc","smsc_list"}){
   Map<String,String> values=good();values.put(bad,bad.equals("eap")?LONG:"not-a-number");String raw=init(values);WifiConfigRuntime.Snapshot s=WifiConfigRuntime.smsSnapshot();
   reject(()->WifiConfigRuntime.saveSmsCenter(s.key,s.record,changed(s)),"24.4 must reproduce blocked SMS repair");check(record().equals(raw),"negative control preserves raw record");
   System.out.println("REPRODUCED 24.4 SMS-only save rejected: "+bad);
  }
 }
 public static void main(String[] args)throws Exception{
  if(args.length>0&&args[0].equals("baseline")){reproduceBaseline();System.out.println("PASS: "+passed+" 24.4 negative-control assertions");return;}
  for(String bad:new String[]{"eap","nai","smsc","smsc_list"}){
   Map<String,String> values=good();values.put(bad,bad.equals("eap")||bad.equals("nai")?LONG:"not-a-number");String raw=init(values);WifiConfigRuntime.Snapshot s=WifiConfigRuntime.smsSnapshot();
   check(s.needsRepair,"recoverable record is disclosed");check(s.values.get("domain").equals("kept.ims.example.org")&&s.values.get(CarrierPresets.KEY).equals(good().get(CarrierPresets.KEY)),"SMS repair retains validated unrelated values and manual template");
   if(bad.equals("smsc"))check(s.values.get("smsc_list").equals(A+"\n"+B),"a bad selected number does not discard independently valid saved candidates");
   if(bad.equals("smsc_list"))check(s.values.get("smsc").equals(A),"a bad list does not discard an independently valid selected number");
   if(bad.startsWith("smsc")){
    check(s.warning.contains("其他配置保留"),"SMS repair warning does not imply unrelated settings are lost");
    try{WifiConfigRuntime.prepareSmsCenter(new Engine(card));throw new AssertionError("invalid stored SMSC cannot silently use EF_SMSP");}
    catch(IllegalStateException invalid){check(invalid.getMessage().contains("打开短信中心")&&invalid.getMessage().contains("保存"),"Send directs repairable SMS errors to the actual SMS editor");}
   }
   gl5 before=(gl5)zl5.b.value;WifiConfigRuntime.saveSmsCenter(s.key,s.record,changed(s));
   check(unrelated(record()).equals(unrelated(raw)),"only SMS rows change, including exact oversized identity bytes");
   check(((gl5)zl5.b.value).f==before.f&&((gl5)zl5.b.value).k==before.k&&((gl5)zl5.b.value).j.equals(before.j),"SMS repair preserves active IMS object, phase and device value");
   check(((gl5)zl5.b.value).h.equals(good().get("epdg")),"stored endpoint remains the same saved value after valid SMS record is restored");
   check(C.equals(WifiConfigRuntime.prepareSmsCenter(new Engine(card)))&&C.equals(((gl5)zl5.b.value).i),"sender and live SMSC use newly confirmed number");
   s=WifiConfigRuntime.smsSnapshot();check(s.values.get("smsc_list").equals(C+"\n"+B),"backup survives explicit save and reopen");
   boolean identity=bad.equals("eap")||bad.equals("nai");check(s.needsRepair==identity,"SMS repair clears only the SMS error, not unrelated EAP repair marker");
   ek5 fresh=new ek5(card.a,card.b);fresh.f=card.f;card=fresh;zl5.b.value=WifiConfigTest.state(card,zl3.r(card));
   check(C.equals(WifiConfigRuntime.prepareSmsCenter(new Engine(card))),"cold card model reload retains repaired SMSC");check(((gl5)zl5.b.value).f.g.equals("kept.ims.example.org"),"manual connection fields survive fresh model reload");
   s=WifiConfigRuntime.smsSnapshot();Map<String,String> empty=new LinkedHashMap<>(s.values);empty.remove("smsc");empty.put("smsc_list","[]");WifiConfigRuntime.saveSmsCenter(s.key,s.record,empty);
   reject(()->WifiConfigRuntime.prepareSmsCenter(new Engine(card)),"explicit empty remains blocked despite native SMSP");check(unrelated(record()).equals(unrelated(raw)),"deleting centers retains unrelated bytes");
  }
  Map<String,String> old=good();old.put("eap",LONG);String raw=init(old);WifiConfigRuntime.Snapshot s=WifiConfigRuntime.smsSnapshot();
  Map<String,String> forbidden=changed(s);forbidden.put("domain","other.example.org");final WifiConfigRuntime.Snapshot first=s;
  reject(()->WifiConfigRuntime.saveSmsCenter(first.key,first.record,forbidden),"SMS repair cannot change another field");check(record().equals(raw),"unauthorized field edit leaves record exact");
  prefs().fail=true;reject(()->WifiConfigRuntime.saveSmsCenter(first.key,first.record,changed(first)),"failed commit must fail save");check(record().equals(raw),"commit failure restores exact old oversized record");
  String external=WifiConfigValues.encode(good());prefs().data.put(key(),external);reject(()->WifiConfigRuntime.saveSmsCenter(first.key,first.record,changed(first)),"stale revision rejected");check(record().equals(external),"stale revision preserves newer record");
  raw=init(old);s=WifiConfigRuntime.smsSnapshot();final WifiConfigRuntime.Snapshot swap=s;final String priorKey=key();final ek5 other=new ek5("204040000000002","8944011234567890124");
  zl5.b.onCas=()->zl5.b.value=WifiConfigTest.state(other,zl3.r(other));reject(()->WifiConfigRuntime.saveSmsCenter(swap.key,swap.record,changed(swap)),"card swap during save rejected");check(prefs().data.get(priorKey).equals(raw),"card swap rolls back only original card record");check(!prefs().data.containsKey(WifiConfigRuntime.cardKey(other)),"different card preferences untouched");
  raw=init(old);s=WifiConfigRuntime.smsSnapshot();final WifiConfigRuntime.Snapshot concurrent=s;final String targetKey=key();
  zl5.b.onCas=()->prefs().data.put(targetKey,external);reject(()->WifiConfigRuntime.saveSmsCenter(concurrent.key,concurrent.record,changed(concurrent)),"concurrent revision during publication rejected");check(record().equals(external),"rollback must never overwrite a newer external revision");
  for(String broken:new String[]{"v1\nsmsc\tnot-a-number\ndomain\thttps://bad.invalid", "v1\nsmsc\tnot-a-number\ncarrier_preset\t20404|gone", "v1\nsmsc\t"+A+"\nsmsc\t"+B, "v1\nsmsc\tnot-a-number\nunknown\tx", "v1\nsmsc\tnot-a-number\nno-tab"}){
   init(good());prefs().data.put(key(),broken);WifiConfigRuntime.Snapshot damaged=WifiConfigRuntime.smsSnapshot();
   reject(()->WifiConfigRuntime.saveSmsCenter(damaged.key,damaged.record,changed(damaged)),"unrelated corruption is not repairable by SMS save");check(record().equals(broken),"rejected structure/other-field error preserves original bytes");
  }
  Map<String,String> deleted=good();deleted.put("smsc","not-a-number");deleted.put("smsc_list","[]");raw=init(deleted);s=WifiConfigRuntime.smsSnapshot();
  check(s.values.get("smsc_list").equals("[]")&&!s.values.containsKey("smsc"),"repair draft retains explicit deleted list rather than reviving EF_SMSP");
  WifiConfigRuntime.saveSmsCenter(s.key,s.record,s.values);reject(()->WifiConfigRuntime.prepareSmsCenter(new Engine(card)),"saving repaired deleted list still blocks sending");
  for(String bad:new String[]{"eap","smsc"}){
   Map<String,String> values=good();values.put(bad,bad.equals("eap")?LONG:"not-a-number");raw=init(values);Handler.drain();Activity owner=new Activity();lu1.context=owner;lu1 composer=new lu1();
   open(composer);check(ak2.edits.size()==2,"real SMS editor retains both valid candidates while repairing "+bad);ak2.edits.get(0).change.i(C);xq0.cancel.a();check(record().equals(raw),"Cancel leaves exact damaged original record intact");
   open(composer);ak2.edits.get(0).change.i(C);prefs().fail=true;xq0.press("保存");waitSave();render(composer);
   check(record().equals(raw)&&ak2.edits.get(0).value.equals(C)&&xq0.message.contains("保存失败"),"real failed Save keeps damaged disk record and editable input");
   xq0.press("保存");waitSave();check(C.equals(WifiConfigRuntime.prepareSmsCenter(new Engine(card))),"actual async editor Save repairs SMS and dispatch uses confirmed value");check(unrelated(record()).equals(unrelated(raw)),"actual UI save leaves all unrelated record lines exact");owner.destroy();
   raw=init(values);WifiConfigRuntime.updateSmsCenter("+");check(record().equals(raw),"legacy inline partial edit stays transient during repair");reject(()->WifiConfigRuntime.prepareSmsCenter(new Engine(card)),"legacy partial repair input cannot send");
   WifiConfigRuntime.updateSmsCenter(C);check(C.equals(WifiConfigRuntime.prepareSmsCenter(new Engine(card)))&&WifiConfigRuntime.smsSnapshot().values.get("smsc_list").equals(C+"\n"+B),"legacy callback uses same bounded repair and preserves backup");check(unrelated(record()).equals(unrelated(raw)),"legacy repair also preserves unrelated original lines");
  }
  System.out.println("PASS: "+passed+" bounded SMS repair, exact unrelated rows, same-card dispatch and conditional rollback assertions");
 }
}
