import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import android.widget.Toast;
import java.util.*;

/** Old preference records only: no packet construction or transport is involved. */
public class EapIdentityRecoveryTest {
 static int passed,closed;static DitoHomeIdentityTest.Ctx context;static ek5 card;
 static final String LONG=EapIdentityValidationTest.repeat("é",506)+"@x.org";
 static final String FOREIGN="20404|apple_vodafone_nl";
 static final String PREFS="wifi_config_overrides_v1";
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);passed++;}
 static Map<String,String> values(String...pairs){return WifiConfigTest.values(pairs);}
 static WifiConfigTest.Prefs prefs(){return context.store(PREFS);}
 static Map<String,String> good(){return values(CarrierPresets.KEY,FOREIGN,"domain","kept.ims.example.org","epdg","kept.epdg.example.org","smsc","+639111111111","smsc_list","+639111111111\n+639222222222","imei","490154203237518");}
 static String init(Map<String,String> record,boolean legacy)throws Exception {
  Handler.drain();context=new DitoHomeIdentityTest.Ctx();zl5.f=context;card=new ek5("204049876543210","8963668800123457319");
  String key=WifiConfigRuntime.cardKey(card),encoded=WifiConfigValues.encode(record);
  prefs().data.put(legacy?WifiConfigValues.digest(card.b+"\n"+card.a):key,encoded);
  zl5.b.value=WifiConfigTest.state(card,zl3.r(card));return encoded;
 }
 static void waitSave()throws Exception {long end=System.nanoTime()+2_000_000_000L;while(Handler.tasks.isEmpty()&&System.nanoTime()<end)Thread.sleep(5);check(!Handler.tasks.isEmpty(),"recovery save completes");Handler.drain();}
 static void preserved(Map<String,String> expected)throws Exception {
  WifiConfigRuntime.Snapshot snapshot=WifiConfigRuntime.snapshot();gl5 state=(gl5)zl5.b.value;
  check(snapshot.needsRepair&&snapshot.warning!=null&&snapshot.warning.contains("EAP"),"old oversized identity is marked for existing editor repair");
  check(snapshot.values.equals(expected),"repair draft retains every unrelated saved field exactly");
  check(state.f.c.equals("Vodafone")&&state.f.d.equals("204")&&state.f.e.equals("04"),"known DITO issuer still uses the user's explicitly selected foreign carrier");
  check(state.f.g.equals(expected.get("domain"))&&state.f.f.equals(Collections.singletonList(expected.get("epdg"))),"selected IMS/ePDG settings survive live identity recovery");
  check(state.h.equals(expected.get("epdg"))&&state.i.equals(expected.get("smsc"))&&state.j.equals(expected.get("imei")),"live scalar settings are recovered from the same preserved record");
  check(state.e==card&&DitoHomeIdentity.connection(card,state.f)==card,"recovery does not invent a DITO home identity or replace the actual read");
  String permanent=state.f.y==null?state.f.r:state.f.y;
  check(permanent.getBytes(java.nio.charset.StandardCharsets.UTF_8).length<=1016,"live effective permanent identity is encodable before any connect request");
 }
 public static void main(String[]args)throws Exception {
  for(boolean legacy:new boolean[]{false,true})for(String field:new String[]{"nai","eap"}){
   Map<String,String> expected=good(),old=new LinkedHashMap<>(expected);old.put(field,LONG);
   String encoded=init(old,legacy);String key=WifiConfigRuntime.cardKey(card);
   preserved(expected);check(encoded.equals(prefs().data.get(key)),"reading old values leaves exact disk record intact");
   if(legacy)check(encoded.equals(prefs().data.get(WifiConfigValues.digest(card.b+"\n"+card.a))),"legacy migration preserves the original source record");
   Object effective=((gl5)zl5.b.value).f;int builds=zl3.builds;
   for(int n=0;n<12;n++)check(WifiConfigRuntime.resolve(card,effective)==effective,"repeated resolution reuses the repaired same-card configuration");
   check(zl3.builds==builds,"record repair does not rebuild defaults on every state update");
   WifiConfigRuntime.Snapshot snapshot=WifiConfigRuntime.snapshot();
   WifiConfigRuntime.save(snapshot.key,snapshot.record,snapshot.values);
   check(!WifiConfigRuntime.snapshot().needsRepair&&WifiConfigValues.decode(prefs().data.get(key)).equals(expected),"explicit save removes only invalid identity fields and clears repair state");
   ek5 reread=new ek5(card.a,card.b);zl5.b.value=WifiConfigTest.state(reread,zl3.r(reread));
   check(((gl5)zl5.b.value).f.c.equals("Vodafone")&&WifiConfigRuntime.snapshot().values.equals(expected),"fixed selected carrier and unrelated settings survive reopening");
   if(legacy)check(encoded.equals(prefs().data.get(WifiConfigValues.digest(card.b+"\n"+card.a))),"repair never deletes legacy backup data");
  }
  Map<String,String> expected=good(),both=new LinkedHashMap<>(expected);both.put("nai",LONG);both.put("eap",LONG);
  String encoded=init(both,false);preserved(expected);
  check(encoded.equals(prefs().data.get(WifiConfigRuntime.cardKey(card))),"two-field in-memory repair still leaves original record unchanged");
  Map<String,String> dito=values("nai",LONG,"eap",LONG,"smsc","+639111111111");encoded=init(dito,false);
  WifiConfigRuntime.Snapshot snapshot=WifiConfigRuntime.snapshot();gl5 state=(gl5)zl5.b.value;
  check(snapshot.needsRepair&&snapshot.values.get("nai").equals(LONG)&&!snapshot.values.containsKey("eap"),"DITO's independent native EAP permits preserving the long outer NAI");
  check(state.f.c.equals("DITO")&&state.f.r.equals(LONG)&&state.f.y.startsWith("0"+card.a+"@"),"DITO live recovery uses genuine card-derived permanent identity without changing explicit outer");

  for(Map<String,String> valid:new Map[]{values("nai",LONG,"eap","short@example.org"),values("nai",LONG),values("impi",LONG)}){
   String record=init(valid,false);WifiConfigRuntime.Snapshot saved=WifiConfigRuntime.snapshot();
   check(!saved.needsRepair&&saved.values.equals(valid)&&prefs().data.get(saved.key).equals(record),"valid independent EAP or unrelated IMS field is never marked damaged");
  }
  Map<String,String> invalidSyntax=good();invalidSyntax.put("eap","missing-at-sign");init(invalidSyntax,false);
  snapshot=WifiConfigRuntime.snapshot();check(snapshot.needsRepair&&snapshot.values.isEmpty(),"unrelated malformed syntax retains the original generic recovery behavior");

  // Done on an unchanged targeted recovery draft must save; Cancel must not.
  Map<String,String> old=good();old.put("eap",LONG);encoded=init(old,false);String key=WifiConfigRuntime.cardKey(card);
  Activity activity=new Activity();closed=0;us1 close=()->{closed++;return sc5.a;};us1 done=(us1)WifiConfigEditor.begin(activity,close);
  ((us1)WifiConfigEditor.cancelCallback(close)).a();check(closed==1&&prefs().data.get(key).equals(encoded),"Cancel keeps exact old oversized record and good fields on disk");activity.destroy();
  activity=new Activity();closed=0;done=(us1)WifiConfigEditor.begin(activity,close);done.a();waitSave();
  check(closed==1&&!WifiConfigRuntime.snapshot().needsRepair&&WifiConfigValues.decode(prefs().data.get(key)).equals(good()),"unchanged recovery Done persists the targeted repair without resetting other settings");activity.destroy();

  encoded=init(old,false);key=WifiConfigRuntime.cardKey(card);activity=new Activity();closed=0;done=(us1)WifiConfigEditor.begin(activity,close);prefs().fail=true;done.a();waitSave();
  check(closed==0&&prefs().data.get(key).equals(encoded)&&Toast.last.contains("保存失败"),"failed recovery save preserves original disk record and keeps editor open");
  done.a();waitSave();check(closed==1&&WifiConfigRuntime.snapshot().values.equals(good()),"retry completes same targeted repair without losing unrelated values");activity.destroy();
  System.out.println("PASS: "+passed+" old EAP record recovery, manual carrier preservation and existing editor assertions (no packets)");
 }
}
