#!/usr/bin/env python3
"""Run actual switch wrapper instructions through both direct and suspended errors."""
import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).parent))
path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parents[1]/'smali/InternalSimSwitchRequest.smali'
sys.argv=[sys.argv[0],str(path)]
import check_refresh_flow as vm
class Rejected(vm.CardError): pass
class Run(vm.Run):
 def __init__(self,slot=True,suspend=True,enable=False,results=None):
  super().__init__(slot=slot,suspend=suspend)
  self.frame=vm.Obj('InternalSimSwitchRequest',backend=self.manager,iccid='old',operation=0xbf31 if enable else 0xbf32,command=vm.Obj('rf1'),state=0)
  self.results=list(results or [vm.UNIT]);self.calls=[];self.logs=[]
 def invoke(self,ref,args):
  if ref=='Lhh1;->v(Ljava/lang/String;ILws1;Lcz4;)Ljava/lang/Object;':
   backend,iccid,operation,callback,frame=args
   assert backend is self.manager and iccid=='old' and frame is self.frame
   self.calls.append((operation,callback.kind))
   if callback.kind=='InternalSimNoRefreshCommand':
    assert callback.fields['args']==[0 if operation==0xbf31 else 1]
   return self.result(self.results.pop(0))
  if ref=='Lcc/forserein/simhub/internal/ProfileRefresh;->retryWithoutRefresh(Ljava/lang/Throwable;ZI)Z':
   error,slot,state=args;return bool(slot) and state==1 and isinstance(error,Rejected)
  if ref=='Lhh1;->u(Ljava/lang/String;)V':self.logs.append(args[1]);return None
  return super().invoke(ref,args)
class Flow(unittest.TestCase):
 def test_success_never_repeated(self):
  for suspend in (False,True):
   r=Run(suspend=suspend);self.assertIs(r.execute(),vm.UNIT);self.assertEqual(len(r.calls),1);self.assertFalse(r.logs)
 def test_rejection_retries_false_once_enable_and_disable(self):
  for suspend in (False,True):
   for enable in (False,True):
    r=Run(suspend=suspend,enable=enable,results=[Rejected('card result 127'),vm.UNIT])
    self.assertIs(r.execute(),vm.UNIT);self.assertEqual([c[1] for c in r.calls],['rf1','InternalSimNoRefreshCommand']);self.assertEqual(len(r.logs),1)
 def test_second_rejection_propagates(self):
  for suspend in (False,True):
   r=Run(suspend=suspend,results=[Rejected('first'),Rejected('second')])
   with self.assertRaises(Rejected):r.execute()
   self.assertEqual(len(r.calls),2)
 def test_transport_and_cancel_never_retry(self):
  for suspend in (False,True):
   for error in (vm.CardError('lost response'),vm.Cancelled('cancel')):
    r=Run(suspend=suspend,results=[error])
    with self.assertRaises(type(error)):r.execute()
    self.assertEqual(len(r.calls),1)
 def test_usb_never_retries(self):
  r=Run(slot=False,results=[Rejected('error')])
  with self.assertRaises(Rejected):r.execute()
  self.assertEqual(len(r.calls),1)
if __name__=='__main__':unittest.main(verbosity=2)
