#!/usr/bin/env python3
"""Validate real shared theme/row/button classes, with reversible native-state invariants."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from ui_theme_patch import verify_ui_theme
decoded=Path(sys.argv[1]);result=verify_ui_theme(decoded/'smali')
(decoded.parent/'ui-theme-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: shared UI theme contrast, dimensions and native callback preservation')
