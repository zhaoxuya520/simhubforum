import cc.forserein.simhub.internal.*;

public class ReaderWifiPresentationTest {
 static int passed;
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);passed++;}
 public static class State {public Object e,f;State(Object card,Object config){e=card;f=config;}}
 public static class Config {public Object c,d,e;Config(Object name,Object mcc,Object mnc){c=name;d=mcc;e=mnc;}}
 public static void main(String[] args)throws Exception {
  ek5 raw=new ek5("204040123456789","8963660000000000001");
  State dito=new State(raw,new Config("DITO","515","66"));
  check(ReaderWifiPresentation.subtitle(dito,"DITO · PLMN 20404").equals("DITO · 51566"),"reader shows the effective DITO network instead of the roaming credential PLMN");
  check("PH".equals(ReaderWifiPresentation.country(dito)),"DITO flag comes from effective PH settings");
  check(raw.a.equals("204040123456789")&&raw.b.equals("8963660000000000001")&&raw.c==2,"presentation leaves actual credentials intact");
  check(ReaderWifiPresentation.subtitle(dito,"old").length()<24,"replacement subtitle fits the short native header");
  State nl=new State(raw,new Config("Vodafone nl","204","04"));String original="Vodafone nl · PLMN 20404";
  check(original.equals(ReaderWifiPresentation.subtitle(nl,original)),"unmodified automatic carrier keeps its existing header");
  check("NL".equals(ReaderWifiPresentation.country(nl)),"automatic non-DITO flag remains unchanged");
  State manual=new State(raw,new Config("Test US","310","260"));
  check(ReaderWifiPresentation.subtitle(manual,original).equals("Test US · 310260"),"manual carrier retains all three MNC digits");
  check("US".equals(ReaderWifiPresentation.country(manual)),"manual country wins over unchanged raw card");
  check("PH".equals(ReaderWifiPresentation.country(dito)),"previous explicit state is independent of another rendered manual state");
  check("NL".equals(ReaderWifiPresentation.country(nl)),"returning to automatic recomputes flag without same-card cache");
  State uncommon=new State(raw,new Config("Other PH","515","99"));
  check("PH".equals(ReaderWifiPresentation.country(uncommon)),"native unambiguous MCC fallback remains available");
  State unknown=new State(raw,new Config("Unknown","999","99"));
  check(ReaderWifiPresentation.country(unknown)==null,"unknown selected country uses globe rather than incorrect old NL flag");
  check(ReaderWifiPresentation.subtitle(unknown,original).equals("Unknown · 99999"),"unknown country still shows exact selected PLMN");
  State missing=new State(raw,null);
  check("NL".equals(ReaderWifiPresentation.country(missing)),"no effective config preserves raw SIM country");
  check(original.equals(ReaderWifiPresentation.subtitle(missing,original)),"missing config preserves original subtitle");
  for(Object bad:new Object[]{null,new Object(),new State(null,null),new State(raw,new Config("Bad","51","566")),new State(raw,new Config("Bad",515,"66"))}){
   check(original.equals(ReaderWifiPresentation.subtitle(bad,original)),"malformed presentation state cannot crash header");
  }
  check(ReaderWifiPresentation.country(null)==null&&ReaderWifiPresentation.country(new State(null,null))==null,"missing card safely renders globe");
  check(original.equals(ReaderWifiPresentation.subtitle(new State(raw,new Config(" ","515","66")),original)),"empty carrier label preserves native fallback");
  u04 scope=new u04();lu1 composer=new lu1();
  ReaderWifiPresentation.restartFlag(scope,"PH",34,0x30,0);
  Object first=scope.d;check(first!=null,"native restart receives a real kt1 callback");
  check(scope.d.f(composer,0)==sc5.a,"restart returns Kotlin Unit");
  check(fd2.calls==1&&"PH".equals(fd2.country)&&fd2.size==34&&fd2.flags==0x31&&fd2.defaults==0&&fd2.composer==composer,"restart preserves explicit country, dimensions and forces recomposition");
  ReaderWifiPresentation.restartFlag(scope,"US",34,0x30,0);scope.d.f(composer,0);
  check(fd2.calls==2&&"US".equals(fd2.country)&&scope.d!=first,"updated country replaces previous restart capture");
  ReaderWifiPresentation.restartFlag(scope,null,40,0,2);scope.d.f(composer,0);
  check(fd2.calls==3&&fd2.country==null&&fd2.size==40&&fd2.flags==1&&fd2.defaults==2,"unknown country survives restart as globe input");
  check(scope.d.equals(scope.d)&&!scope.d.equals(first)&&scope.d.hashCode()==System.identityHashCode(scope.d),"restart proxy has stable object identity");
  System.out.println("PASS: "+passed+" reader Wi-Fi carrier presentation and restart assertions");
 }
}
