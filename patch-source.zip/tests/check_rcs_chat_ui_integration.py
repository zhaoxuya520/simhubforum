#!/usr/bin/env python3
"""Check native RCS toggle/send integration without changing a decoded APK tree."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from rcs_chat_ui_patch import (
    TARGET, SIGNATURE, SEND_TARGET, SEND_SIGNATURE, METHOD_PINS, PATCHES, HELPER,
    RENDER_HOOK, ENABLED_HOOK, SEND_HOOK, RENDER_INSERTION, ENABLED_INSERTION,
    SEND_INSERTION, method, transform, apply_rcs_chat_ui, reverse_rcs_chat_ui,
    verify_rcs_chat_ui,
    COMPOSE_TARGET, COMPOSE_SIGNATURE, COMPOSE_SEND_TARGET,
    SMS_HINT, THREAD_HINT_OLD, THREAD_HINT_NEW, DRAFT_HINT_OLD, DRAFT_HINT_NEW, HINT_END,
    DRAFT_RENDER_INSERTION, DRAFT_ENABLED_INSERTION, DRAFT_SEND_INSERTION,
    DRAFT_RENDER_HOOK, DRAFT_ENABLED_HOOK, DRAFT_SEND_HOOK,
)


def instructions(text):
    return [line.strip() for line in text.splitlines()
            if line.strip() and not line.strip().startswith(('.', '#'))]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('decoded', type=Path)
    args = parser.parse_args()
    smali = args.decoded / 'smali' if (args.decoded / 'smali').is_dir() else args.decoded
    sources, originals, patched, old_methods, new_methods = {}, {}, {}, {}, {}
    applied, negatives = set(), 0

    def rejects(label, operation):
        nonlocal negatives
        try:
            operation()
        except AssertionError:
            negatives += 1
            return
        raise AssertionError('accepted tamper: ' + label)

    for name, (signature, regions) in PATCHES.items():
        source = sources[name] = (smali / name).read_text()
        _, _, body = method(source, signature)
        is_patched = HELPER in body
        applied.add(is_patched)
        original = originals[name] = reverse_rcs_chat_ui(name, source) if is_patched else source
        changed = patched[name] = source if is_patched else transform(source, name=name)
        assert transform(original, name=name) == changed
        assert reverse_rcs_chat_ui(name, changed) == original
        a, b, before = method(original, signature)
        c, d, after = method(changed, signature)
        old_methods[name], new_methods[name] = before, after
        assert hashlib.sha256(before.encode()).hexdigest() == METHOD_PINS[(name, signature)]
        assert original[:a] == changed[:c] and original[b:] == changed[d:], 'non-target method changed: ' + name
        assert before.count('    .locals ') == after.count('    .locals ') == 1
        for old, new in regions:
            assert after.count(new) == 1
            for label, replacement in [('missing', old), ('duplicate', new + new)]:
                bad = changed[:c] + after.replace(new, replacement, 1) + changed[d:]
                rejects(label + ' hook ' + name, lambda value=bad, target=name: transform(value, True, target))
        rejects('double apply ' + name, lambda value=changed, target=name: transform(value, name=target))
        rejects('reverse baseline ' + name, lambda value=original, target=name: transform(value, True, target))
        bad = changed[:c] + after.replace('    .locals ', '    .locals 1', 1) + changed[d:]
        rejects('native register count ' + name, lambda value=bad, target=name: transform(value, True, target))
        bad = original[:a] + before.replace('    .locals ', '    .locals 1', 1) + original[b:]
        rejects('baseline mismatch ' + name, lambda value=bad, target=name: transform(value, name=target))
    assert len(applied) == 1, 'partially applied native RCS integration'
    is_patched = applied.pop()
    assert reverse_rcs_chat_ui('unrelated.smali', 'unchanged') == 'unchanged'

    before, after = old_methods[TARGET], new_methods[TARGET]
    assert '    .locals 66\n' in after and '.catch' not in before
    assert after.count(RENDER_HOOK) == after.count(ENABLED_HOOK) == 1
    assert after.replace(THREAD_HINT_NEW, THREAD_HINT_OLD, 1).replace(RENDER_INSERTION, '', 1).replace(ENABLED_INSERTION, '', 1) == before
    assert re.findall(r'^\s*:\w+\s*$', before, re.M) == re.findall(r'^\s*:\w+\s*$', after.replace(THREAD_HINT_NEW, THREAD_HINT_OLD, 1), re.M)
    ops = instructions(before)
    render = ops.index(':goto_17')
    assert ops[render + 1:render + 3] == ['sget-object v3, Lt3;->g0:Lgp;', 'new-instance v4, Lph;'], 'render temporaries used before native overwrite'
    assert 'move-object/from16 v49, v26' in ops[:render]
    assert instructions(RENDER_INSERTION) == ['move-object/from16 v3, p2', 'move-object/from16 v4, v49', 'invoke-static {v2, v3, v4, v8}, ' + RENDER_HOOK]
    enabled = ops.index('move/from16 v0, v59')
    assert ops[enabled + 1] == 'invoke-virtual {v8, v0}, Llu1;->h(Z)Z', 'enabled must feed native change tracking'
    assert 'move-object/from16 v15, p2' in ops[render:enabled]
    assert 'move-object/from16 v11, v49' in ops[render:enabled]
    assert instructions(ENABLED_INSERTION) == ['invoke-static {v0, v15, v11}, ' + ENABLED_HOOK, 'move-result v0']
    for old, new in [('move-object/from16 v3, p2', 'move-object/from16 v3, p3'),
                     ('move-object/from16 v4, v49', 'move-object/from16 v4, v50'),
                     ('{v2, v3, v4, v8}', '{v2, v3, v4, v7}'),
                     ('{v0, v15, v11}', '{v0, v15, v12}')]:
        start, end, target_body = method(patched[TARGET], SIGNATURE)
        value = patched[TARGET][:start] + target_body.replace(old, new, 1) + patched[TARGET][end:]
        assert value != patched[TARGET]
        rejects('UI register ' + old, lambda value=value: transform(value, True, TARGET))

    before, after = old_methods[SEND_TARGET], new_methods[SEND_TARGET]
    assert '    .locals 5\n' in after and after.count(SEND_HOOK) == 1
    assert after.replace(SEND_INSERTION, '', 1) == before
    prefix = after[:after.index(SEND_INSERTION)]
    assert 'packed-switch v0, :pswitch_data_0' in prefix and ':pswitch_' not in prefix.split('packed-switch v0, :pswitch_data_0', 1)[1]
    assert 'check-cast v1, Ljava/lang/String;' in prefix and prefix.rstrip().endswith('check-cast p0, Lm83;')
    suffix = after[after.index(SEND_INSERTION) + len(SEND_INSERTION):]
    assert instructions(suffix)[0] == 'invoke-interface {p0}, Lot4;->getValue()Ljava/lang/Object;'
    assert 'invoke-interface {p0, v0}, Lm83;->setValue(Ljava/lang/Object;)V' in suffix
    assert 'const/16 v3, 0x16' in suffix, 'result register not overwritten in native SMS branch'
    assert after[after.index('    :pswitch_0'):] == before[before.index('    :pswitch_0'):], 'other callback cases changed'
    for old, new in [('invoke-static {v1, p0}', 'invoke-static {v1, v0}'),
                     ('    move-result v3\n', '    move-result v0\n'),
                     ('    if-eqz v3, :rcs_sms_original', '    if-nez v3, :rcs_sms_original')]:
        start, end, target_body = method(patched[SEND_TARGET], SEND_SIGNATURE)
        value = patched[SEND_TARGET][:start] + target_body.replace(old, new, 1) + patched[SEND_TARGET][end:]
        assert value != patched[SEND_TARGET]
        rejects('send register/branch ' + old, lambda value=value: transform(value, True, SEND_TARGET))

    callback_ops = instructions(SEND_INSERTION)
    for consumed in (False, True):
        draft, peer, unit = object(), object(), object()
        regs = {'p0': draft, 'v0': False, 'v1': peer, 'v3': object()}
        calls, returned, pc = [], None, 0
        while pc < len(callback_ops):
            op = callback_ops[pc]; pc += 1
            if op.startswith(':'): continue
            if op == 'invoke-static {v1, p0}, ' + SEND_HOOK: calls.append((regs['v1'], regs['p0']))
            elif op == 'move-result v3': regs['v3'] = consumed
            elif op == 'if-eqz v3, :rcs_sms_original':
                if not regs['v3']: pc = callback_ops.index(':rcs_sms_original')
            elif op == 'sget-object v3, Lsc5;->a:Lsc5;': regs['v3'] = unit
            elif op == 'return-object v3': returned = regs['v3']; break
            else: raise AssertionError('unreviewed callback op: ' + op)
        assert calls == [(peer, draft)]
        assert regs['p0'] is draft and regs['v0'] is False and regs['v1'] is peer
        assert returned is (unit if consumed else None)

    # New-message composer uses distinct peer/body state holders and an original
    # independent dispatch callback. This path must also consume RCS first.
    before, after = old_methods[COMPOSE_TARGET], new_methods[COMPOSE_TARGET]
    assert '    .locals 75\n' in after
    assert after.replace(DRAFT_HINT_NEW, DRAFT_HINT_OLD, 1).replace(DRAFT_RENDER_INSERTION, '', 1).replace(DRAFT_ENABLED_INSERTION, '', 1) == before
    assert after.count(DRAFT_RENDER_HOOK) == after.count(DRAFT_ENABLED_HOOK) == 1
    ops = instructions(before)
    point = ops.index(':goto_19')
    assert ops[point + 1:point + 4] == [
        'iget-object v1, v0, Lmc0;->X:Lm83;',
        'invoke-interface {v1}, Lot4;->getValue()Ljava/lang/Object;',
        'move-result-object v2',
    ], 'draft render temporary must be overwritten before native use'
    assert 'move-object/from16 v7, v60' in ops[:point]
    assert 'check-cast v7, Lgl5;' in ops[:point]
    assert instructions(DRAFT_RENDER_INSERTION) == ['move-object/from16 v2, v57', 'invoke-static {v7, v2, v1, v10}, ' + DRAFT_RENDER_HOOK]
    point = ops.index('move/from16 v24, v52')
    assert ops[point + 1:point + 4] == [
        'invoke-static/range {v19 .. v31}, Lpk5;->c(Ljava/lang/String;Lws1;Ljava/lang/String;JZZLus1;Lr53;Lfp1;Llu1;II)V',
        'const/4 v7, 0x1', 'invoke-virtual {v10, v7}, Llu1;->q(Z)V',
    ], 'new message enabled injection moved away from native send row'
    # v4/v5/v6 were copied into the range arguments/callback before this point.
    tail = ops[point + 4:]
    end = next(i for i, op in enumerate(tail) if op.startswith('return-object '))
    assert not any(re.search(r'\bv[456]\b', op) for op in tail[:end + 1]), 'new-compose temporaries unexpectedly live'
    assert 'move-object/from16 v21, v5' in ops[:point]
    assert 'move-object/from16 v26, v6' in ops[:point]
    assert instructions(DRAFT_ENABLED_INSERTION) == [
        'move/from16 v4, v24', 'move-object/from16 v5, v57', 'move-object v6, v1',
        'invoke-static {v4, v5, v6}, ' + DRAFT_ENABLED_HOOK, 'move-result v4', 'move/from16 v24, v4',
    ]
    from smsc_editor_patch import reverse_smsc_editor
    reversed_rcs = reverse_rcs_chat_ui(COMPOSE_TARGET, patched[COMPOSE_TARGET])
    reversed_both = reverse_smsc_editor(COMPOSE_TARGET, reversed_rcs)
    assert '->smsCenterEntry(' not in reversed_both and HELPER not in method(reversed_both, COMPOSE_SIGNATURE)[2]
    rejects('wrong shared-method reversal order', lambda: reverse_smsc_editor(COMPOSE_TARGET, patched[COMPOSE_TARGET]))
    before, after = old_methods[COMPOSE_SEND_TARGET], new_methods[COMPOSE_SEND_TARGET]
    assert '    .locals 7\n' in after and after.count(DRAFT_SEND_HOOK) == 1
    assert after.replace(DRAFT_SEND_INSERTION, '', 1) == before
    prefix, suffix = after.split(DRAFT_SEND_INSERTION)
    assert prefix.rstrip().endswith('check-cast v4, Lm83;') and 'check-cast v5, Lm83;' in prefix
    assert instructions(suffix)[:2] == ['invoke-interface {v5}, Lot4;->getValue()Ljava/lang/Object;', 'move-result-object v0']
    assert after[after.index('    :pswitch_0'):] == before[before.index('    :pswitch_0'):]
    assert 'sget-object v3, Lsc5;->a:Lsc5;' in prefix
    assert instructions(DRAFT_SEND_INSERTION) == ['invoke-static {v5, v4}, ' + DRAFT_SEND_HOOK, 'move-result v0', 'if-eqz v0, :rcs_sms_original', 'return-object v3', ':rcs_sms_original']
    for consumed in (False, True):
        peer, draft, unit = object(), object(), object()
        regs = {'v5': peer, 'v4': draft, 'v3': unit, 'p0': False, 'v0': 3}
        calls = [(regs['v5'], regs['v4'])]
        regs['v0'] = consumed
        returned = regs['v3'] if regs['v0'] else None
        assert calls == [(peer, draft)] and returned is (unit if consumed else None)
        assert regs['p0'] is False and regs['v5'] is peer and regs['v4'] is draft

    # Each guard skips precisely the localized hint's Text node and leaves the
    # original group balanced. Other status/error text and its predicates survive.
    for name, marker, read, result_reg in [(TARGET, THREAD_HINT_NEW, 'invoke-static/range {v49 .. v49}, ', 'v25'),
                                           (COMPOSE_TARGET, DRAFT_HINT_NEW, 'invoke-static {v0}, ', 'v0')]:
        checked = instructions(marker)
        where = checked.index(read + SMS_HINT)
        assert checked[where + 1:where + 3] == ['move-result '+result_reg,'if-eqz '+result_reg+', :rcs_sms_hint_done']
        assert 'Lz45;->b(' in checked[where + 3] and checked[where + 4:] == [HINT_END.strip()]
        prefix, suffix = new_methods[name].split(marker)
        assert 'vowifi_sms_send_hint' in prefix and 'Llu1;->q(Z)V' in suffix
        if name == TARGET:
            assert 'move-object/from16 v51, v25' in prefix.rsplit('vowifi_sms_send_hint',1)[1]
            assert next(s for s in suffix.splitlines() if 'v25' in s).strip().startswith('move-object/from16 v25,')
        else:
            assert checked[:2] == ['move-object/from16 v0, p0', 'iget-object v0, v0, Lmc0;->X:Lm83;']
            assert next(s for s in suffix.splitlines() if 'v0' in s).strip() == 'move-object/from16 v0, p0'
    with tempfile.TemporaryDirectory(prefix='simhub-rcs-ui-') as temporary:
        path = Path(temporary)
        for name, source in originals.items(): (path / name).write_text(source)
        apply_rcs_chat_ui(path)
        for name, source in patched.items(): assert (path / name).read_text() == source
        report = verify_rcs_chat_ui(path)
    if is_patched:
        helper = (smali / 'cc/forserein/simhub/internal/RcsChatUi.smali').read_text()
        for signature in ('showSmsHint(Ljava/lang/Object;)Z', 'render(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V',
                          'sendEnabled(ZLjava/lang/String;Ljava/lang/Object;)Z',
                          'trySend(Ljava/lang/String;Ljava/lang/Object;)Z',
                          'renderDraft(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V',
                          'sendEnabledDraft(ZLjava/lang/Object;Ljava/lang/Object;)Z',
                          'trySendDraft(Ljava/lang/Object;Ljava/lang/Object;)Z'):
            assert '.method public static ' + signature in helper
        assert '->appendMenu(' not in helper, 'superseded menu-only UI retained'
    for name, source in sources.items(): assert (smali / name).read_text() == source
    report.update(negative_tamper_checks=negatives, non_target_methods_unchanged=True,
                  native_register_liveness_checked=True, rcs_and_sms_branch_interpreted=True,
                  helper_in_compiled_smali_checked=is_patched, input_unchanged=True)
    print('PASS: native RCS toggle/send; off preserves SMS, RCS consumes before draft clear')
    print(json.dumps(report, sort_keys=True))


if __name__ == '__main__': main()
