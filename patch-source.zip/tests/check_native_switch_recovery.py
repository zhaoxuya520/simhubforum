#!/usr/bin/env python3
"""Verify the eSTK switch hook and preserve the original switch and APDU implementations."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from multichip_patch import verify_native_switch_routes
from estk_switch_patch import restore_estk_hz3, restore_estk_pg1
patched=Path(sys.argv[1]);base=Path(sys.argv[2])
manifest=json.loads((root/'validation/native-switch-baseline.json').read_text())
assert hashlib.sha256(base.read_bytes()).hexdigest()==manifest['base_apk_sha256']
smali=patched/'smali';verify_native_switch_routes(smali)
restored={name:restore((smali/name).read_text()).encode() for name,restore in
          [('hz3.smali',restore_estk_hz3),('pg1.smali',restore_estk_pg1)]}
for name,digest in manifest['class_sha256'].items():
 data=restored[name] if name in restored else (smali/name).read_bytes()
 assert hashlib.sha256(data).hexdigest()==digest,name
text=(smali/'iz3.smali').read_text()
for signature,digest in manifest['iz3_method_sha256'].items():
 method=text.split(signature+'\n',1)[1].split('.end method',1)[0]
 assert hashlib.sha256(method.encode()).hexdigest()==digest,signature
identity=(smali/'cc/forserein/simhub/internal/IdentityBinding.smali').read_text()
for error in ('尚未确认所选芯片','所选芯片有多个启用配置','无法确认当前配置身份','validateSelection','已停止使用错误身份'):
 # apktool escapes Chinese strings; compare their exact escaped forms too.
 escaped=error.encode('unicode_escape').decode()
 assert error not in identity and escaped not in identity,error
report=dict(native_classes_exact=sorted(set(manifest['class_sha256'])-set(restored)),
 native_classes_exact_after_hook_removal=sorted(restored),native_selection_methods_exact=2,
 estk_dual_chip_entry=True,legacy_experimental_adapters_present=False,management_identity_gate_present=False,device_tested=False)
(patched.parent/'native-switch-recovery.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: original switch/channel/USIM classes match the pinned baseline after reversing the bounded switch hook')
