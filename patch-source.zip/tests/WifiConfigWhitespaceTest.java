import cc.forserein.simhub.internal.*;
import java.util.*;
/** Regression for real Android 11 SharedPreferences XML cold-read indentation. */
public class WifiConfigWhitespaceTest {
 static int checks;static void check(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
 interface Op{void run()throws Exception;}
 static void reject(Op op,String why)throws Exception{try{op.run();throw new AssertionError(why);}catch(WifiConfigValues.Invalid expected){checks++;}}
 static Map<String,String> values(String...args){Map<String,String> result=new LinkedHashMap<>();for(int i=0;i<args.length;i+=2)result.put(args[i],args[i+1]);return WifiConfigValues.validate(result);}
 public static void main(String[]args)throws Exception {
  List<Map<String,String>> cases=Arrays.asList(values(),values("smsc","+8613800100500"),values("smsc","+639222222222","smsc_list","+639111111111\n+639222222222"),
   values("epdg","first.example.org\nsecond.example.org","domain","ims.example.org","apn","ims","impi","user@ims.example.org"),
   values("nai","outer@nai.example.org","eap","actual@nai.example.org","impu","sip:user@ims.example.org"),
   values("smsc_list",WifiConfigListDraft.EMPTY,"epdg",WifiConfigListDraft.EMPTY));
  for(Map<String,String> expected:cases){
   String encoded=WifiConfigValues.encode(expected);
   check(expected.isEmpty()?encoded.equals("v1\n"):!encoded.endsWith("\n"),"nonempty records avoid serializer indentation trigger");
   check(WifiConfigValues.decode(encoded).equals(expected),"new v1 record roundtrip");
   // Old writers ended each nonempty record with LF. Android 11 appends XML indentation.
   String legacy=encoded.endsWith("\n")?encoded:encoded+"\n";
   for(String indentation:new String[]{"    ","        ","\t  "," \n    ","\r\n    "})
    check(WifiConfigValues.decode(legacy+indentation).equals(expected),"trailing blank XML text cannot damage fields");
   for(int n=0;n<20;n++)encoded=WifiConfigValues.encode(WifiConfigValues.decode(encoded));
   check(WifiConfigValues.decode(encoded).equals(expected),"repeat saves are stable");
  }
  check(WifiConfigValues.decode("v1\nsmsc\t+8613800100500\n    ").get("smsc").equals("+8613800100500"),"exact ART cold-read reproduction");
  reject(()->WifiConfigValues.decode("v1\nsmsc\t+8613800100500\ncorrupt"),"nonblank unterminated record must still fail");
  reject(()->WifiConfigValues.decode("v1\nsmsc\t+8613800100500\n    \ndomain\tims.example.org"),"interior whitespace line not silently discarded");
  reject(()->WifiConfigValues.decode("v1\nsmsc\t+8613800100500\nsmsc\t+639111111111\n    "),"duplicate SMSC remains rejected");
  reject(()->WifiConfigValues.decode("v1\nsmsc\t+\n    "),"incomplete SMSC still rejected");
  check(!WifiConfigValues.decode("v1\nsmsc_list\t[]\nsmsc\t+639111111111\n    ").containsKey("smsc"),"explicit empty list retains existing priority over selected number");
  reject(()->WifiConfigValues.decode("v1\nunknown\tvalue\n    "),"unknown field still rejected");
  reject(()->WifiConfigValues.decode("v1\nepdg\tone.example\ntwo.example\n    "),"unproven raw multiline format not guessed");
  reject(()->WifiConfigValues.decode("v1\nsmsc\t+8613800100500\n\u00a0"),"non-ASCII suffix not treated as XML indent");
  System.out.println("PASS: "+checks+" Android XML whitespace and strict-record assertions");
 }
}
