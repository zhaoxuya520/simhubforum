import android.app.Activity;
import android.content.Intent;
import android.content.pm.*;
import android.provider.Telephony;
import android.telephony.*;
import cc.forserein.simhub.internal.RcsChatBinding;
import cc.forserein.simhub.internal.RcsSystemComposer;
import java.util.*;

public final class RcsSystemComposerTest {
    static final String CARD="8944000000000000247", OTHER_CARD="8948000000000000247", PEER="+441632960247";
    static final String PKG="test.defaultmessages";
    static final String TEXT="测试\n🌍";
    static RcsChatBindingTest.State state;
    static FakeActivity activity;
    static SubscriptionManager telephony;
    static TelephonyManager topology;
    static Resolver resolver;
    static int checks;

    static class FakeActivity extends Activity {
        Intent launched; boolean closed, permission, globalPhoneState = true;
        public boolean isFinishing(){return closed;}
        public PackageManager getPackageManager(){return resolver;}
        public int checkSelfPermission(String name){
            if ("android.permission.READ_PHONE_STATE".equals(name)) return globalPhoneState ? 0 : -1;
            return permission ? 0 : -1;
        }
        public <T>T getSystemService(Class<T> type){return type.cast(type==TelephonyManager.class?topology:telephony);}
        public void startActivity(Intent intent){
            check(Intent.ACTION_SENDTO.equals(intent.action),"only compose intent may launch");
            check(intent.component!=null,"never launch implicit intent");
            check(launched==null,"one launch per click");
            launched=intent;
        }
    }
    static class Resolver extends PackageManager {
        ResolveInfo result=new ResolveInfo();
        Runnable onResolve; int calls;
        @Override public ResolveInfo resolveActivity(Intent query,int flags){
            calls++;
            check(Telephony.Sms.fixtureDefaultPackage.equals(query.pkg),"queries only current SMS package");
            check(query.extras.isEmpty(),"discovery must not carry message body");
            check("smsto".equals(query.data.scheme)&&query.data.fragment==null,"safe compose URI structure");
            check(flags==MATCH_DEFAULT_ONLY,"resolves only a default-compatible activity");
            if(onResolve!=null)onResolve.run();
            return result;
        }
    }
    static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);checks++;}
    static void denied(Runnable action,String label){
        try{action.run();}catch(IllegalStateException|IllegalArgumentException expected){
            check(activity.launched==null,label+" no activity opened");return;
        }
        throw new AssertionError(label);
    }
    static ActivityInfo info(){
        ActivityInfo out=new ActivityInfo();
        out.name="test.defaultmessages.Compose";out.packageName=PKG;out.exported=true;
        out.applicationInfo=new ApplicationInfo();out.applicationInfo.uid=12345;
        out.applicationInfo.packageName=PKG;out.applicationInfo.fixtureLabel="测试信息";
        return out;
    }
    static void fresh(){
        telephony=new SubscriptionManager();topology=new TelephonyManager();
        telephony.active=Arrays.asList(new SubscriptionInfo(22,CARD),new SubscriptionInfo(23,OTHER_CARD));
        activity=new FakeActivity(); resolver=new Resolver(); resolver.result.activityInfo=info();
        state=new RcsChatBindingTest.State(new RcsChatBindingTest.Card(CARD));
        zl5.b.value=state;zl5.j=new qf3();zl5.n=null;
        Telephony.Sms.fixtureDefaultPackage=PKG;
    }
    static RcsSystemComposer prepare(){return RcsSystemComposer.capture(activity,state,PEER);}
    static void valid(){
        fresh();
        RcsSystemComposer draft=RcsSystemComposer.capture(activity,state,"tel:0044 1632 960247");
        check(activity.launched==null && !draft.requiresManualSim && "测试信息".equals(draft.appLabel),"only target label is disclosed before click");
        draft.open(activity,state,PEER,TEXT);
        Intent launch=activity.launched;
        check(PKG.equals(launch.component.getPackageName()),"opens the user-selected package");
        check("test.defaultmessages.Compose".equals(launch.component.getClassName()),"pins exact resolved component");
        check(PEER.equals(launch.data.schemeSpecificPart),"canonical E.164 only in URI");
        check(launch.extras.equals(Collections.singletonMap("sms_body",TEXT)),"exact body only, no sub, SMS send or transport flag");
        check(telephony.calls.isEmpty(),"draft never reads own telephone number");
        fresh();draft=prepare();draft.open(activity,state,PEER,"");
        check(activity.launched.extras.isEmpty(),"blank draft does not fabricate a body");
    }
    static void negatives(){
        fresh();zl5.j=new Object();denied(RcsSystemComposerTest::prepare,"external reader");
        fresh();telephony.active=Arrays.asList(new SubscriptionInfo(22,CARD),new SubscriptionInfo(23,CARD));denied(RcsSystemComposerTest::prepare,"duplicate ICCID");
        fresh();telephony.active=Arrays.asList(new SubscriptionInfo(22,CARD),new SubscriptionInfo(23,""));manualOpen("masked second card");
        fresh();telephony.active=Collections.emptyList();denied(RcsSystemComposerTest::prepare,"complete subscription view is empty");
        fresh();telephony.active=Collections.singletonList(new SubscriptionInfo(22,OTHER_CARD));denied(RcsSystemComposerTest::prepare,"complete list contains only another card");
        fresh();telephony.active=Collections.singletonList(new SubscriptionInfo(22,"bad-mask",0,120,0));denied(RcsSystemComposerTest::prepare,"malformed card information");
        fresh();telephony.activeError=new IllegalStateException();denied(RcsSystemComposerTest::prepare,"unexpected platform failure");
        fresh();denied(()->RcsSystemComposer.capture(activity,state,"+123;body=other"),"no URI body injection");
        fresh();Telephony.Sms.fixtureDefaultPackage=null;denied(RcsSystemComposerTest::prepare,"no default package");
        fresh();Telephony.Sms.fixtureDefaultPackage=activity.getPackageName();denied(RcsSystemComposerTest::prepare,"no circular self-handoff");
        fresh();resolver.result=null;denied(RcsSystemComposerTest::prepare,"no compose activity");
        fresh();resolver.result.activityInfo.exported=false;denied(RcsSystemComposerTest::prepare,"not exported");
        fresh();resolver.result.activityInfo.applicationInfo.enabled=false;denied(RcsSystemComposerTest::prepare,"disabled application");
        fresh();resolver.result.activityInfo.applicationInfo.flags=ApplicationInfo.FLAG_SUSPENDED;denied(RcsSystemComposerTest::prepare,"suspended role holder");
        fresh();resolver.result.activityInfo.enabled=false;denied(RcsSystemComposerTest::prepare,"disabled component");
        fresh();resolver.result.activityInfo.packageName="test.foreign";denied(RcsSystemComposerTest::prepare,"different activity owner");
        fresh();resolver.result.activityInfo.applicationInfo.packageName="test.foreign";denied(RcsSystemComposerTest::prepare,"different app metadata");
        fresh();resolver.result.activityInfo.permission="privileged.only";denied(RcsSystemComposerTest::prepare,"inaccessible activity");
        fresh();resolver.onResolve=()->zl5.j=new qf3();denied(RcsSystemComposerTest::prepare,"reader changed during capture");
        fresh();resolver.onResolve=()->telephony.active=Arrays.asList(new SubscriptionInfo(24,CARD));denied(RcsSystemComposerTest::prepare,"subscription changed during capture");
    }
    static void maskedSecond(){
        fresh();android.os.Build.VERSION.SDK_INT=33;
        telephony.active=Arrays.asList(new SubscriptionInfo(22,CARD,1,123,0),new SubscriptionInfo(23,"",0,111,0));
        topology.cards=Arrays.asList(new UiccCardInfo(0,111,new UiccPortInfo("FFFFFFFFFFFFFFFFFFFF",0,0,true)),
                new UiccCardInfo(1,123,new UiccPortInfo(CARD,0,1,true)));
        qf3 local=(qf3)zl5.j;
        local.a=new android.se.omapi.SEService(activity,Runnable::run,()->{});
        local.b=new android.se.omapi.Reader("SIM2",true);
        android.se.omapi.SEService.secondSlot=local.b;
    }
    static void topology(){
        maskedSecond();RcsSystemComposer draft=prepare();draft.open(activity,state,PEER,TEXT);
        check(activity.launched!=null&&telephony.calls.isEmpty(),"verified physical slot and port make redacted peer slot safe for draft only");
        maskedSecond();
        denied(()->RcsChatBinding.capture(state,PEER),"draft-only match cannot authorize direct RCS");
        maskedSecond();android.se.omapi.SEService.secondSlot=new android.se.omapi.Reader("SIM2",true);
        denied(RcsSystemComposerTest::prepare,"SIM-reader name alone cannot authorize handoff");
        maskedSecond();topology.cards.set(1,new UiccCardInfo(1,123,new UiccPortInfo(CARD,0,0,true)));
        denied(RcsSystemComposerTest::prepare,"nontrivial logical-physical mapping refused");
        maskedSecond();topology.cards=Arrays.asList(new UiccCardInfo(0,123,new UiccPortInfo(CARD,0,1,true)),
                new UiccCardInfo(1,111,new UiccPortInfo("",0,0,true)));
        android.se.omapi.SEService.explicitSlot=((qf3)zl5.j).b;
        manualOpen("valid remapped modems require explicit SIM selection");
        maskedSecond();topology.cards.set(0,new UiccCardInfo(0,111,new UiccPortInfo(CARD,0,0,true)));
        denied(RcsSystemComposerTest::prepare,"duplicate target ICCID in port of masked peer");
        maskedSecond();topology.cards.set(1,new UiccCardInfo(1,124,new UiccPortInfo(CARD,0,1,true)));
        denied(RcsSystemComposerTest::prepare,"cardId mismatch");
        maskedSecond();topology.cards.set(1,new UiccCardInfo(1,123,new UiccPortInfo(CARD,1,1,true)));
        denied(RcsSystemComposerTest::prepare,"portId mismatch");
        maskedSecond();topology.cards.set(1,new UiccCardInfo(1,123,new UiccPortInfo("",0,1,true)));
        manualOpen("target port ICCID missing");
        maskedSecond();topology.cards.set(1,new UiccCardInfo(1,123,new UiccPortInfo(CARD,0,1,false)));
        denied(RcsSystemComposerTest::prepare,"target port inactive");
        maskedSecond();topology.cards=Collections.singletonList(topology.cards.get(1));
        manualOpen("no independent port/slot evidence for masked peer");
        maskedSecond();topology.cards.set(0,new UiccCardInfo(0,111,new UiccPortInfo("",0,0,true),new UiccPortInfo("",1,0,true)));
        denied(RcsSystemComposerTest::prepare,"conflicting concurrent ports");
        maskedSecond();android.os.Build.VERSION.SDK_INT=32;manualOpen("pre-33 must choose SIM for redacted list");
        maskedSecond();RcsSystemComposer bound=prepare();
        telephony.active=Arrays.asList(new SubscriptionInfo(22,CARD,1,123,0),new SubscriptionInfo(23,OTHER_CARD,0,111,0));
        topology.cards=Collections.emptyList();
        denied(()->bound.open(activity,state,PEER,TEXT),"do not discard the captured port proof after privilege or topology changes");
    }
    static void manualOpen(String label) {
        RcsSystemComposer draft = prepare();
        check(draft.requiresManualSim && activity.launched == null, label + " prepares only a manual choice");
        draft.open(activity, state, PEER, TEXT);
        Intent result = activity.launched;
        check(PKG.equals(result.component.getPackageName()) && PEER.equals(result.data.schemeSpecificPart)
                && Collections.singletonMap("sms_body", TEXT).equals(result.extras), label + " no subscription or send hint");
    }
    static SubscriptionInfo hidden(String mask) { return new SubscriptionInfo(22,mask,1,123,0); }
    static void privateSubscription() {
        for (String mask : new String[]{"",null,"FFFFFFFFFFFFFFFFFFFF"}) {
            fresh();telephony.active=Collections.singletonList(hidden(mask));manualOpen("masked card " + mask);
        }
        maskedSecond();topology.cards=Arrays.asList(new UiccCardInfo(0,111),new UiccCardInfo(1,123));
        telephony.active=Arrays.asList(new SubscriptionInfo(22,"",1,123,0),new SubscriptionInfo(23,"",0,111,0));
        manualOpen("active subscription rows, inaccessible port list and redacted ICCIDs");
        maskedSecond();((qf3)zl5.j).a=null;manualOpen("OMAPI reader cannot be mapped by telephony");
        maskedSecond();android.se.omapi.SEService.secondSlot=null;manualOpen("OMAPI does not expose the requested slot");
        fresh();telephony.activeError=new SecurityException();manualOpen("ordinary access denied");
        fresh();activity.globalPhoneState=false;telephony.active=Collections.emptyList();manualOpen("filtered empty list");
        fresh();activity.globalPhoneState=false;telephony.active=null;manualOpen("older Android returned null for filtered list");
        fresh();activity.globalPhoneState=false;telephony.active=Collections.singletonList(new SubscriptionInfo(23,OTHER_CARD,0,111,0));
        manualOpen("only another carrier's visible row");
        maskedSecond();activity.globalPhoneState=false;
        telephony.active=Collections.singletonList(new SubscriptionInfo(23,OTHER_CARD,0,111,0));
        topology.cards.set(0,new UiccCardInfo(0,111,new UiccPortInfo(OTHER_CARD,0,0,true)));
        manualOpen("all returned subscription rows omit the current reader even though it has a UICC port");
        maskedSecond();activity.globalPhoneState=false;
        telephony.active=Collections.singletonList(new SubscriptionInfo(22,OTHER_CARD,1,123,0));
        topology.cards.set(1,new UiccCardInfo(1,123,new UiccPortInfo(OTHER_CARD,0,1,true)));
        denied(RcsSystemComposerTest::prepare,"other visible card independently mapped to current physical reader");
        fresh();telephony.active=Collections.singletonList(hidden(""));
        RcsSystemComposer draft=prepare();
        telephony.active=Collections.singletonList(new SubscriptionInfo(22,OTHER_CARD));
        denied(()->draft.open(activity,state,PEER,TEXT),"known different subscription after manual choice prepared");
        fresh();telephony.activeError=new SecurityException();
        RcsSystemComposer changedRole=prepare();Telephony.Sms.fixtureDefaultPackage=null;
        denied(()->changedRole.open(activity,state,PEER,TEXT),"default app gone while card info hidden");
        fresh();telephony.activeError=new SecurityException();
        RcsSystemComposer changedCard=prepare();state.e=new RcsChatBindingTest.Card(OTHER_CARD);
        denied(()->changedCard.open(activity,state,PEER,TEXT),"actual local card changed while system identity hidden");
        fresh();RcsSystemComposer proved=prepare();telephony.activeError=new SecurityException();
        denied(()->proved.open(activity,state,PEER,TEXT),"verified draft may not become manual after permission loss");
        fresh();telephony.active=Collections.singletonList(hidden(""));
        denied(()->RcsChatBinding.capture(state,PEER),"manual choice never grants direct registered-line access");
    }
    static void changed(Runnable mutate,String label){
        fresh();RcsSystemComposer draft=prepare();mutate.run();
        denied(()->draft.open(activity,state,PEER,TEXT),label);
    }
    public static void main(String[] ignored){
        valid();negatives();topology();privateSubscription();
        changed(()->zl5.j=new qf3(),"reader replaced since preview");
        changed(()->state.e=new RcsChatBindingTest.Card(OTHER_CARD),"SIM changed");
        changed(()->telephony.active=Arrays.asList(new SubscriptionInfo(31,CARD)),"subId changed");
        changed(()->Telephony.Sms.fixtureDefaultPackage="new.default","role changed");
        changed(()->resolver.result.activityInfo.name="different.Compose","component changed");
        changed(()->resolver.result.activityInfo.applicationInfo.uid++,"different app UID");
        changed(()->resolver.onResolve=()->Telephony.Sms.fixtureDefaultPackage="new.default","role changed during final resolution");
        changed(()->resolver.onResolve=()->zl5.j=new qf3(),"card switched during final resolution");
        changed(()->activity.closed=true,"activity closed");
        fresh();RcsSystemComposer draft=prepare();
        denied(()->draft.open(activity,state,"+441632960248",TEXT),"edited peer mismatch");
        System.out.println("PASS: "+checks+" draft-only handoff and card/default-app checks (Android host doubles)");
    }
}
