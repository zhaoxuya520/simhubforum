#!/usr/bin/env python3
"""Run real APK da1 identity replay checks using the already verified carrier jar."""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, sys, zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from eap_identity_replay_patch import BASE_SHA256, verify_eap_identity_replay

p = argparse.ArgumentParser()
p.add_argument('apk', type=Path)
p.add_argument('decoded', type=Path)
p.add_argument('--report', type=Path, required=True)
p.add_argument('--carrier-report', type=Path)
p.add_argument('--native-dir', type=Path)
p.add_argument('--legacy', action='store_true')
a = p.parse_args()
carrier_report = a.carrier_report or a.report.parent / 'native-carrier-runtime.json'
native = a.native_dir or carrier_report.parent / 'native-carrier-current'
provenance = json.loads(carrier_report.read_text())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert provenance['apk_sha256'] == digest(a.apk), 'carrier jar is not from this APK'
assert provenance['apk_translated_jar_sha256'] == digest(native / 'probe.jar'), 'native jar changed since carrier validation'
required = ['da1.class', 'ma1.class', 'la1.class', 'z91.class']
if not a.legacy:
    required += ['cc/forserein/simhub/internal/EapIdentityReplay.class', 'cc/forserein/simhub/internal/EapIdentityLog.class']
with zipfile.ZipFile(native / 'probe.jar') as original, zipfile.ZipFile(native / 'auth-probe.jar') as adapted:
    for name in required:
        assert original.read(name) == adapted.read(name), 'authentication fixture modified EAP code: ' + name
smali = a.decoded / 'smali' / 'da1.smali'
if a.legacy:
    assert digest(smali) == BASE_SHA256, 'legacy mode requires the unmodified native da1'
    patch = None
else:
    patch = verify_eap_identity_replay(a.decoded / 'smali')
work = a.report.parent / ('native-eap-legacy' if a.legacy else 'native-eap-current')
work.mkdir(parents=True, exist_ok=True)
classes = work / 'classes'
classes.mkdir(exist_ok=True)
source = ROOT / 'validation/native-eap/NativeEapReplayProbe.java'
tools = Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery'))
android = tools / 'sdk/android-35/android.jar'
jar = native / 'auth-probe.jar'
logs = []
def run(*args):
    result = subprocess.run(list(map(str, args)), cwd=ROOT, capture_output=True, text=True)
    logs.append(result.stdout + result.stderr)
    (work / 'probe.log').write_text('\n'.join(logs))
    if result.returncode:
        print(result.stdout + result.stderr)
        raise SystemExit(result.returncode)
    return result.stdout
run('java', '-jar', tools / 'ecj-3.40.0.jar', '-8', '-encoding', 'UTF-8', '-cp', str(jar) + os.pathsep + str(android), '-d', classes, source)
assert {f.name for f in classes.rglob('*.class')} == {'NativeEapReplayProbe.class'}, 'unexpected class replaced native EAP code'
output = run('java', '-noverify', '-cp', os.pathsep.join(map(str, [classes, jar, android])), 'NativeEapReplayProbe', 'legacy' if a.legacy else 'current')
match = re.search(r'NATIVE_EAP_REPLAY (?:legacy_regression_reproduced|current_passed)=true checks=(\d+)', output)
assert match, output
result = {'apk_sha256': digest(a.apk), 'native_jar_sha256': digest(jar), 'carrier_report_sha256': digest(carrier_report),
          'probe_source_sha256': digest(source), 'checks': int(match[1]), 'legacy_regression_reproduced': a.legacy,
          'actual_native_da1_and_serializers_executed': True, 'eap_classes_unchanged_by_transport_fixture': True,
          'reused_native_carrier_translation': True, 'patch': patch,
          'native_identity_replay_and_transcript_tested': not a.legacy,
          'native_generated_response_realm_log_checked': not a.legacy,
          'challenge_boundary': 'Well-framed synthetic RAND/AUTN/MAC reaches original null-AKA-adapter boundary; no real challenge or key validation claimed',
          'physical_apdu_or_gateway_tested': False, 'android_art_tested': False,
          'jvm_r8_constructor_adapter': True, 'jvm_verification_disabled_for_translated_dex': True}
a.report.write_text(json.dumps(result, indent=2) + '\n')
print(output.strip())
