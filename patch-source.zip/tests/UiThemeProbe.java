import java.lang.reflect.*;

/** Execute actual APK theme/static button styling; no Compose renderer fixtures. */
public final class UiThemeProbe {
 static int checks;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
 public static void main(String[]args)throws Exception {
  Class<?> theme=Class.forName("z55"),button=Class.forName("cj2"),role=Class.forName("ij2"),callback=Class.forName("us1");
  String[][] palettes={
   {"2563EB","16824B","B75B08","D62D3A","17233A","53627A","63718A","DCE4EF","FFFFFF","F3F6FB","F3F6FB","FFFFFF","E6EDF6","EFF3F9"},
   {"7AB2FF","5AD294","FFBD6C","FF8990","F1F5FC","B3C1D7","93A4BF","344359","101825","1B2738","101825","1B2738","2D3C51","233147"}};
  for(int mode=0;mode<2;mode++){
   Object colors=theme.getField(mode==0?"a":"b").get(null);
   check(colors.getClass().getField("a").getBoolean(colors)==(mode==1),"native dark/light discriminator");
   for(int n=0;n<14;n++){
    long actual=colors.getClass().getField(String.valueOf((char)('b'+n))).getLong(colors);
    long expected=(0xff000000L|Long.parseLong(palettes[mode][n],16))<<32;
    check(actual==expected,"actual Compose packed sRGB token "+mode+"/"+n);
   }
  }
  Object fn=Proxy.newProxyInstance(callback.getClassLoader(),new Class<?>[]{callback},(p,m,a)->null);
  Constructor<?> ctor=button.getConstructor(String.class,role,boolean.class,callback);
  Method primary=Class.forName("xq0").getMethod("simhubPrimary",button);
  for(String title:new String[]{"保存","确认","确定","完成","继续","Save","Confirm","OK","Done","Continue"}){
   Object ordinary=role.getField("T").get(null);
   check((Boolean)primary.invoke(null,ctor.newInstance(title,ordinary,true,fn)),"enabled primary action");
   check(!(Boolean)primary.invoke(null,ctor.newInstance(title,ordinary,false,fn)),"disabled primary stays disabled presentation");
   for(String other:new String[]{"U","V"})check(!(Boolean)primary.invoke(null,ctor.newInstance(title,role.getField(other).get(null),true,fn)),"cancel/destructive semantic role cannot become primary");
  }
  for(String title:new String[]{"重置为内置","重置","取消","删除","保存中…","Cancel","Delete","Reset","Don't Save","保存失败"})
   check(!(Boolean)primary.invoke(null,ctor.newInstance(title,role.getField("T").get(null),true,fn)),"secondary/unknown title is not promoted");
  System.out.println("UI_THEME_PROBE passed=true checks="+checks);
 }
}
