#!/usr/bin/env python3
"""Pin native read/auth contracts and verify the DITO hook in the actual rebuilt smali."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from registration_timing_patch import restore_native as restore_registration
from sip_session_timer_patch import reverse_sip_session_timer
from sip_fork_patch import reverse_sip_fork
decoded=Path(sys.argv[1]);smali=decoded/'smali';baseline=json.loads(Path(sys.argv[2]).read_text());checks=0
def check(value,message):
 global checks
 assert value,message
 checks+=1
def method(text,signature):return text.split('.method '+signature+'\n',1)[1].split('.end method',1)[0]
check(baseline['base_apk_sha256']=='cdd748532360f5632dc5661c0e8d9c9907967a0a136be16dfde118de43ad81c2','native baseline is the pinned delivered APK')
native=(smali/'zl5.smali').read_text()
start=method(native,'public static z()V')
call='DitoHomeIdentity;->connection(Ljava/lang/Object;)Ljava/lang/Object;'
check(start.count(call)==1,'connection identity resolved exactly once at native scheduler boundary')
check(start.index(call)<start.index('new-instance v0, Lhm0;'),'corrected identity passed before job creation')
check('check-cast v0, Lek5;' in start and 'move-object v3, v0' in start,'native card parameter has exact ek5 type')
check('.catch Ljava/lang/Exception; {:dito_connection_start .. :dito_connection_end} :dito_connection_error' in start,'missing identity is caught before asynchronous authentication')
check('DitoHomeIdentity;->connectionError(Ljava/lang/Throwable;)V' in start,'failed connect reports reason and disables retries')
check(hashlib.sha256(method(native,'public final u(Lac5;Lxi5;Lek5;ILdt0;)Ljava/lang/Object;').encode()).hexdigest()==baseline['native_worker_sha256'],'entire native IKE/AKA/IMS worker unchanged')
for name in ['ek5','o82','ac5','vb5','hm0','sl5']:
 data=(smali/(name+'.smali')).read_bytes()
 if name=='o82':
  data=restore_registration('o82.smali',reverse_sip_session_timer('o82.smali',reverse_sip_fork('o82.smali',data.decode()))).encode()
 check(hashlib.sha256(data).hexdigest()==baseline['class_sha256'][name],name+' identity model/authentication/read coroutine unchanged outside exact bounded call/timing hooks')
constructor='public constructor <init>(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lz82;)V'
check('.method '+constructor in (smali/'ek5.smali').read_text(),'exact eight-field immutable identity constructor')
identity=(smali/'cc/forserein/simhub/internal/IdentityBinding.smali').read_text()
check('DitoHomeIdentity;->observe(Ljava/lang/Object;)V' in identity,'real USIM read feeds home identity store')
read=method(native,'public final q(Ldt0;)Ljava/lang/Object;')
check('IdentityBinding;->read(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V' in read,'generation-checked read boundary retained')
home=(smali/'cc/forserein/simhub/internal/DitoHomeIdentity.smali').read_text()
check('896366' in home and 'wifi_calling_dito_identity_v1' in home,'DITO IIN and dedicated same-card private store present')
check('WifiConfigRuntime;->resolve(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;' in read,'native completion log resolves local config instead of reporting stale Vodafone')
profile=(smali/'cc/forserein/simhub/internal/DitoCarrierProfile.smali').read_text()
check('apple_dito_ph' in profile and 'modp1024' in profile and 'aes128' in profile,'dedicated reference DITO profile shipped')
quirks=(smali/'yj5.smali').read_text()
check('.method public constructor <init>(ZLjava/lang/String;Ljava/util/Set;Ljava/lang/Integer;Ljava/lang/String;Ljava/util/List;I)V' in quirks and '0x1c20' in quirks and '0x20000' in quirks,'pinned native constructor supports reference 7200-second registration expiry')
check('DitoHomeIdentity;->maskLog(Ljava/lang/String;)Ljava/lang/String;' in method(native,'public static b(Ljava/lang/String;)V'),'native logs mask restored full home IMSI')
source=root/'src/cc/forserein/simhub/internal'
check('DitoHomeIdentity.mask(card,value.replace(imsi,masked))' in (source/'WifiConfigEditor.java').read_text(),'existing hidden-identity UI also masks remembered identity')
report=dict(checks=checks,reference_release='https://github.com/maow318/simhubforum/releases/tag/v29.3',
 reference_ipa_sha256='1d0b3c0bea93695bf467efda8c3b07793b03532fd55c096207177e8f2edf2b5d',
 issuer_iccid_prefix='896366',reference_recovery_batch='8963662600',home_plmn='51566',roaming_plmn='20404',
 identity_source='actual same-ICCID generation-checked USIM read; never inferred from roaming IMSI',
 native_authentication_worker_unchanged=True,fork_and_timing_hooks_reversed_before_full_class_comparison=True,device_tested=False)
(decoded.parent/'dito-identity-integration.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS:',checks,'DITO native read, immutable identity, scheduler, authentication and privacy integration checks')
