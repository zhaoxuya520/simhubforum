#!/usr/bin/env python3
"""Pin exact original methods while validating both early fork hooks and native ABI."""
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from sip_fork_patch import verify_sip_fork,reverse_sip_fork
p=argparse.ArgumentParser();p.add_argument('decoded',type=Path);p.add_argument('--report',type=Path);a=p.parse_args();smali=a.decoded/'smali' if(a.decoded/'smali').is_dir()else a.decoded
report=verify_sip_fork(smali)
abi={'kb4.smali':['public constructor <init>(ZLjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/util/ArrayList;[B)V','public final e()Lfa4;','public final g()Ljava/lang/String;','public final j(Ljava/lang/String;)Ljava/util/ArrayList;'],
 'ma4.smali':['public constructor <init>(Lga4;Ljava/lang/String;Lla4;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IILkb4;D)V'],
 'cb4.smali':['public final b(Lkb4;Lma4;)V','public final k(Ljava/lang/String;Lma4;[B)Lkb4;','public static m(Lcb4;Lkb4;ILjava/lang/String;Loc2;)Lpa4;'],
 'o82.smali':['public final C(Lkb4;)V','public final k(Ljava/util/List;)V'],
 'jb4.smali':['public static b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;'],
 'jl3.smali':['public constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V']}
for name,signatures in abi.items():
 text=(smali/name).read_text()
 for signature in signatures:assert '.method '+signature in text,(name,signature)
report['native_abi_pinned']=True
report['dex_full_method_targets']=['o82.h(Lkb4;)Z','o82.r(Lkb4;Loc2;Ljava/lang/String;)V']
report['reverse_order']=['fork','session_timer','registration']
if a.report:a.report.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
