import cc.forserein.simhub.internal.*;
import java.util.*;

/** Current physical identity is a registration input, not proof of carrier acceptance. */
public class DitoCurrentIdentityTest {
 static int passed;
 static final String HOME="515661234567890",ROAM="204049876543210",ID="8963668800123457010";
 static final String HOMES="wifi_calling_dito_identity_v1";
 static void check(boolean value,String reason){if(!value)throw new AssertionError(reason);passed++;}
 static DitoHomeIdentityTest.Ctx fresh(){DitoHomeIdentityTest.Ctx ctx=new DitoHomeIdentityTest.Ctx();zl5.f=ctx;return ctx;}
 static ek5 card(String imsi,String iccid,int mnc){return new ek5(imsi,iccid,mnc,"g1","g2","+639123456789","+639000000000",new Object());}
 static void active(ek5 card){zl5.b.value=WifiConfigTest.state(card,zl3.r(card));}
 static void sameCurrent(ek5 raw)throws Exception {
  Object[] before=WifiConfigModel.fields(raw,8);
  check(DitoHomeIdentity.connection(raw)==raw,"valid current read passes unchanged when no genuine home is available");
  check(Arrays.equals(before,WifiConfigModel.fields(raw,8)),"no field of the physical identity was rewritten");
  xi5 config=(xi5)CarrierPresets.defaults(raw,null);
  check(DitoHomeIdentity.connection(raw,config)==raw,"native captured DITO config uses the valid current identity without home history");
  check(config.c.equals("DITO"),"DITO operator configuration remains selected");
  String mnc=raw.a.substring(3,3+raw.c);if(raw.c==2)mnc="0"+mnc;
  String expected="0"+raw.a+"@nai.epc.mnc"+mnc+".mcc"+raw.a.substring(0,3)+".3gppnetwork.org";
  check(config.r.equals(expected)&&config.y.equals(expected),"outer and permanent EAP identities keep current IMSI and its actual two/three-digit PLMN");
  check(config.s.equals(raw.a+"@ims.mnc066.mcc515.3gppnetwork.org"),"IMS identity uses the same current subscriber number");
 }
 static void rejected(ek5 raw)throws Exception {
  try{DitoHomeIdentity.connection(raw);throw new AssertionError("malformed current identity was allowed");}
  catch(IllegalStateException expected){check(expected.getMessage()!=null&&!expected.getMessage().isEmpty(),"malformed identity has a useful error");}
  xi5 captured=(xi5)CarrierPresets.defaults(card(ROAM,ID,2),null);
  try{DitoHomeIdentity.connection(raw,captured);throw new AssertionError("native captured DITO config allowed a malformed current identity");}
  catch(IllegalStateException expected){check(expected.getMessage()!=null&&!expected.getMessage().isEmpty(),"native captured-config path retains malformed-read guard");}
 }
 public static final class Isim {
  public final String a=HOME+"@ims.mnc066.mcc515.3gppnetwork.org";
  public final String b="ims.mnc066.mcc515.3gppnetwork.org";
  public final String c="sip:"+a;
 }
 public static void main(String[]args)throws Exception {
  for(String current:new String[]{ROAM,"20404123456789","234159876543210","310260123456789"})for(int mnc:new int[]{2,3}){
   DitoHomeIdentityTest.Ctx ctx=fresh();ek5 raw=card(current,ID,mnc);
   sameCurrent(raw);DitoHomeIdentity.observe(raw);
   check(ctx.store(HOMES).data.isEmpty(),"current roaming identity is not persisted as a 51566 home record");
   zl5.lastLog="";DitoHomeIdentity.readStatus(raw);
   check(!zl5.lastLog.contains("暂不可连接")&&!zl5.lastLog.contains(current)&&!zl5.lastLog.contains(ID),"status does not claim blocking or reveal full identity");
  }
  // A genuine observed home remains preferred, preserving the physical card and ISIM.
  DitoHomeIdentityTest.Ctx ctx=fresh();DitoHomeIdentity.observe(card(HOME,ID,2));
  for(String current:new String[]{ROAM,"234159876543210","310260123456789"})for(int mnc:new int[]{2,3}){
   ek5 raw=card(current,ID,mnc),effective=(ek5)DitoHomeIdentity.connection(raw);
   check(effective!=raw&&effective.a.equals(HOME)&&effective.c==2,"same-card genuine home takes priority over current roaming identity");
   check(((ek5)DitoHomeIdentity.connection(raw,CarrierPresets.defaults(raw,null))).a.equals(HOME),"native captured DITO config also prefers genuine same-card home");
   Object[] fields=WifiConfigModel.fields(raw,8),restored=WifiConfigModel.fields(effective,8);
   for(int i:new int[]{1,3,4,5,6,7})check(Objects.equals(fields[i],restored[i]),"restoration keeps metadata field "+i);
   check(raw.a.equals(current)&&raw.c==mnc,"original current read remains unchanged after home restoration");
  }
  ek5 other=card(ROAM,"8963668800123457011",2);sameCurrent(other);
  check(ctx.store(HOMES).data.size()==1,"another ICCID cannot borrow or duplicate home history");
  // Neither malformed cached history nor an IMS private identity creates a new IMSI.
  ctx=fresh();ek5 raw=card(ROAM,ID,2);raw.h=new Isim();sameCurrent(raw);
  check(ctx.store(HOMES).data.isEmpty(),"ISIM text is not converted or learned as a home IMSI");
  DitoHomeIdentity.observe(card(HOME,ID,2));String homeKey=ctx.store(HOMES).data.keySet().iterator().next();
  for(String corrupt:new String[]{"",ROAM,"51566","51566123456789x","5156612345678900"}){
   ctx.store(HOMES).data.put(homeKey,corrupt);sameCurrent(raw);
   check(ctx.store(HOMES).data.get(homeKey).equals(corrupt),"reading an unusable record does not rewrite or guess it");
  }
  // No remembered identity may hide a malformed fresh read.
  ctx.store(HOMES).data.put(homeKey,HOME);
  for(String bad:new String[]{"","51566","2040412345678","20404987654321x","2040498765432100"," 204049876543210","２０４０４９８７６５４３２１０"})rejected(card(bad,ID,2));
  for(int bad:new int[]{-1,0,1,4,Integer.MAX_VALUE})rejected(card(ROAM,ID,bad));
  rejected(card(HOME,ID,3));
  check(ctx.store(HOMES).data.get(homeKey).equals(HOME),"invalid current reads cannot poison genuine stored home");
  // Explicit DITO selection uses actual identity too; the choice itself is not evidence.
  ctx=fresh();ek5 manual=card("234159876543210","8901234500123457012",2);active(manual);
  WifiConfigRuntime.Snapshot snapshot=WifiConfigRuntime.snapshot();
  WifiConfigRuntime.save(snapshot.key,snapshot.record,WifiConfigTest.values(CarrierPresets.KEY,DitoCarrierProfile.KEY));
  check(!DitoHomeIdentity.isDito(manual),"manual preset does not become physical carrier evidence");
  check(DitoHomeIdentity.connection(manual)==manual,"manual DITO selection permits the actual read without home history");
  gl5 state=(gl5)zl5.b.value;check(state.e==manual&&state.f.c.equals("DITO")&&state.f.r.startsWith("0"+manual.a+"@"),"manual choice changes preset but not subscriber identity");
  check(DitoHomeIdentity.connection(manual,state.f)==manual,"native captured manual DITO config keeps the physical current identity");
  check(ctx.store(HOMES).data.isEmpty(),"manual carrier choice does not persist invented credentials");
  DitoHomeIdentity.observe(card(HOME,manual.b,2));
  check(((ek5)DitoHomeIdentity.connection(manual)).a.equals(HOME),"manual DITO selection still prefers genuine same-card history");
  // The actual scheduler binds its config; later global selection must not change it.
  ctx=fresh();ek5 recognized=card(ROAM,ID,2);DitoHomeIdentity.observe(card(HOME,ID,2));
  xi5 dito=(xi5)CarrierPresets.defaults(recognized,null);
  xi5 vodafone=(xi5)CarrierPresets.defaults(recognized,WifiConfigTest.values(CarrierPresets.KEY,"20404|apple_vodafone_nl"));
  check(vodafone.c.equals("Vodafone")&&vodafone.r.contains(ROAM)&&vodafone.s.contains(ROAM),"explicit non-DITO preset is built from current identity before any DITO restoration");
  check(!vodafone.r.contains(HOME)&&!vodafone.s.contains(HOME),"DITO home history is never injected into a manually chosen foreign preset");
  check(DitoHomeIdentity.connection(recognized,vodafone)==recognized,"native captured non-DITO config bypasses DITO identity replacement");
  Object[] fields=WifiConfigModel.fields(dito,27);fields[2]="DITO variant";
  Object renamed=WifiConfigModel.constructor(xi5.class,27).newInstance(fields);
  check(((ek5)DitoHomeIdentity.connection(recognized,renamed)).a.equals(HOME),"DITO PLMN remains authoritative when a variant has another display name");
  fields=WifiConfigModel.fields(vodafone,27);fields[2]="DITO";
  Object misleadingName=WifiConfigModel.constructor(xi5.class,27).newInstance(fields);
  check(DitoHomeIdentity.connection(recognized,misleadingName)==recognized,"display name alone cannot turn a non-DITO PLMN into DITO authentication");
  active(card("234159876543210","8901234500123457013",2));
  check(((ek5)DitoHomeIdentity.connection(recognized,dito)).a.equals(HOME),"captured DITO config remains authoritative after global UI changes to another card");
  active(recognized);snapshot=WifiConfigRuntime.snapshot();
  WifiConfigRuntime.save(snapshot.key,snapshot.record,WifiConfigTest.values(CarrierPresets.KEY,"20404|apple_vodafone_nl"));
  check(((gl5)zl5.b.value).f.r.contains(ROAM)&&!((gl5)zl5.b.value).f.r.contains(HOME),"manual non-DITO saved state preserves current identity");
  check(((ek5)DitoHomeIdentity.connection(recognized,dito)).a.equals(HOME),"captured DITO config does not re-read later manual carrier preference");
  check(DitoHomeIdentity.connection(recognized,vodafone)==recognized,"captured foreign config remains unchanged despite DITO classification/history");
  System.out.println("PASS: "+passed+" DITO current-identity fallback, genuine home priority, malformed-read and isolation assertions");
 }
}
