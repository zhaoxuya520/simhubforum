import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import android.widget.Toast;
import java.util.*;

/** Actual editor Java callbacks with platform/Compose doubles; styling checked against original smali. */
public class WifiConfigUiTest {
 static int passed,closed;
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);passed++;}
 static void waitForSave() throws Exception {
  long end=System.nanoTime()+2_000_000_000L;
  while(Handler.tasks.isEmpty() && System.nanoTime()<end)Thread.sleep(5);
  check(!Handler.tasks.isEmpty(),"save completes");Handler.drain();
 }
 public static void main(String[] args)throws Exception {
  WifiConfigTest.Ctx ctx=new WifiConfigTest.Ctx();zl5.f=ctx;
  ek5 card=new ek5("001010000000001","ui-test-profile");
  zl5.b.value=WifiConfigTest.state(card,zl3.r(card));
  Activity activity=new Activity();us1 close=()->{closed++;return sc5.a;};
  us1 done=(us1)WifiConfigEditor.begin(activity,close);
  check(done!=close && activity.app.callbacks.size()==1,"page lifecycle and Done intercepted");
  check(WifiConfigEditor.begin(activity,close)==done,"recomposition reuses session");
  lu1 composer=new lu1();
  WifiConfigEditor.row("Domain","ims.example.org",composer,6);
  check(ak2.row.mode==3 && ak2.row.label.equals("Domain") && ak2.row.value.equals("ims.example.org"),"original row renderer and value retained");
  check(ak2.click!=null && composer.depth==0,"row clickable, composition group balanced");
  ak2.click.a();WifiConfigEditor.overlay(composer);
  check(xq0.title.equals("Domain") && ak2.edits.size()==1,"original alert contains selected field only");
  check(z45.events.size()>2 && z45.events.get(1).equals("input"),"input precedes long reference text");
  check(z45.text.get(0).contains("自定义覆盖值") && z45.text.stream().anyMatch(t->t.contains("ims.example.org")),"full-width input and reference text replace narrow setting rows");

  check(yd2.values.get("内置默认值（不可改写）").equals("ims.example.org") && yd2.values.get("当前已保存（内置 / 自动）").equals("ims.example.org") && yd2.values.get("本次保存后（预览）").startsWith("ims.example.org"),"builtin, override and effective value explicit");
  check(ak2.edits.get(0).value.isEmpty() && ak2.edits.get(0).hint.contains("留空使用内置"),"default is hint, no implicit override");
  ak2.edits.get(0).change.i("custom.example.org");xq0.press("取消");
  WifiConfigEditor.row("Domain","ims.example.org",composer,6);
  check(ak2.row.value.equals("ims.example.org"),"popup cancel discards typing");
  ak2.click.a();WifiConfigEditor.overlay(composer);ak2.edits.get(0).change.i("bad\nheader");xq0.press("暂存修改");WifiConfigEditor.overlay(composer);
  check(!xq0.message.contains("右上角") && ak2.edits.get(0).value.contains("header"),"invalid value stays in alert with error");
  ak2.edits.get(0).change.i("custom.example.org");xq0.press("暂存修改");
  WifiConfigEditor.row("Domain","ims.example.org",composer,6);
  ak2.click.a();WifiConfigEditor.overlay(composer);
  ak2.edits.get(0).change.i("CUSTOM.EXAMPLE.ORG");WifiConfigEditor.overlay(composer);
  check(yd2.values.get("本次保存后（预览）").startsWith("custom.example.org") && yd2.values.get("内置默认值（不可改写）").equals("ims.example.org"),"preview uses save normalization and preserves builtin");
  ak2.edits.get(0).change.i("bad\nheader");WifiConfigEditor.overlay(composer);
  check(yd2.values.get("本次保存后（预览）").contains("无法保存"),"invalid draft not shown as applicable");
  xq0.press("取消");
  check(ak2.row.value.equals("custom.example.org"),"confirmation previews staged value");
  check(ctx.prefs.data.isEmpty() && ((gl5)zl5.b.value).f.g.equals("ims.example.org"),"staged values not persisted or applied to engine");
  check(WifiConfigEditor.editLegacy(17,"49"),"existing IMEI callback intercepted");
  check(WifiConfigEditor.scalar("old",17).equals("49"),"partial IMEI text retained");
  check(!WifiConfigEditor.imeiValid(zl5.b.value) && WifiConfigEditor.imeiText("old").equals("49"),"original IMEI inline validation follows partial draft");
  done.a();check(closed==0 && Toast.last.contains("IMEI"),"Done validates entire page without closing on invalid input");
  WifiConfigEditor.editLegacy(17,"490154203237518");
  check(WifiConfigEditor.imeiValid(zl5.b.value),"valid draft clears original IMEI error");
  WifiConfigEditor.editLegacy(17,"");
  WifiConfigEditor.editLegacy(18,"+441234567890");
  ((us1)WifiConfigEditor.cancelCallback(close)).a();
  check(closed==1 && ctx.prefs.data.isEmpty() && activity.app.callbacks.isEmpty(),"sheet cancel discards all changes and unregisters lifecycle");
  check(!WifiConfigEditor.editLegacy(17,"12"),"callbacks outside page retain legacy path");
  done=(us1)WifiConfigEditor.begin(activity,close);
  WifiConfigEditor.row("IKE","aes256 sha256 sha256 modp2048",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);
  check(ak2.edits.size()==4,"IKE aggregate opens four algorithm fields");
  check(xq0.message.contains("填写自定义值") && xq0.message.contains("暂存修改"),"scope and deferred save explicit");
  ak2.edits.get(0).change.i("aes128");xq0.press("恢复本组内置");xq0.press("取消");
  WifiConfigEditor.row("IKE","aes256 sha256 sha256 modp2048",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);
  check(ak2.edits.get(0).value.isEmpty() && ctx.prefs.data.isEmpty(),"reset then cancel leaves page and disk unchanged");
  ak2.edits.get(0).change.i("aes128");ak2.edits.get(1).change.i("sha256");xq0.press("暂存修改");
  WifiConfigEditor.row("IKE","aes256 sha256 sha256 modp2048",composer,6);
  check(ak2.row.value.equals("aes128 sha256 sha256 modp2048"),"aggregate display keeps original format");
  ((us1)WifiConfigEditor.stageCallback(close)).a();
  check(ctx.prefs.data.isEmpty() && closed==1 && Toast.last.contains("尚未保存"),"inline Apply never commits or closes the page");
  done.a();done.a();waitForSave();
  check(closed==2 && ((gl5)zl5.b.value).f.j.equals(Arrays.asList("aes128")),"Done commits staged algorithms once");
  check(WifiConfigRuntime.snapshot().values.get("ike_encr").equals("aes128"),"save persists across reopening");
  done=(us1)WifiConfigEditor.begin(activity,close);
  WifiConfigEditor.row("IKE","aes128 sha256 sha256 modp2048",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);xq0.press("恢复本组内置");
  WifiConfigEditor.overlay(composer);check(ak2.edits.get(0).value.equals(""),"restore only clears popup draft");
  xq0.press("暂存修改");done.a();waitForSave();
  check(((gl5)zl5.b.value).f.j.equals(Arrays.asList("aes256")),"clear then Done restores original algorithm list");
  done=(us1)WifiConfigEditor.begin(activity,close);
  WifiConfigEditor.row("NAI","anonymous@nai.example.org",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);
  check(ak2.edits.size()==4,"identity advanced edits don't add main-page rows");
  xq0.press("取消");
  WifiConfigEditor.editLegacy(17,"49");activity.destroy();
  check(activity.app.callbacks.isEmpty() && !WifiConfigEditor.editLegacy(17,"50"),"destroyed activity releases draft and callbacks");
  check(WifiConfigPresentation.defaultText("eap",Collections.emptyMap()).contains("当前卡身份"),"automatic identity not shown as unset");
  check(WifiConfigPresentation.defaultText("imei",Collections.emptyMap()).equals("未设置"),"missing IMEI not claimed automatic");
  check(WifiConfigPresentation.effective("domain","   ",Collections.singletonMap("domain","ims.example.org")).equals("ims.example.org"),"whitespace restores builtin");
  check(composer.depth==0,"all editor composition groups balanced");
  System.out.println("PASS: "+passed+" original-UI callback assertions (platform/Compose doubles)");
 }
}
