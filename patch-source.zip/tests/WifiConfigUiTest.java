import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import android.widget.Toast;
import java.util.*;

/** Real Java editor callbacks, with Android/Compose doubles; not a device screenshot test. */
public class WifiConfigUiTest {
 static int passed,closed;static final lu1 composer=new lu1();
 static WifiConfigTest.Ctx ctx;static Activity activity;static ek5 card;static us1 close,done;
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);passed++;}
 static void waitForSave()throws Exception{long end=System.nanoTime()+2_000_000_000L;while(Handler.tasks.isEmpty()&&System.nanoTime()<end)Thread.sleep(5);check(!Handler.tasks.isEmpty(),"save completes");Handler.drain();}
 static void open(String name){WifiConfigEditor.row(name,"old",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);}
 static void render(){WifiConfigEditor.overlay(composer);}
 static Map<String,String> saved()throws Exception{return WifiConfigRuntime.snapshot().values;}
 static void init()throws Exception{
  ctx=new WifiConfigTest.Ctx();zl5.f=ctx;card=new ek5("001010000000001","compact-ui");card.f="+441111111111";
  zl5.b.value=WifiConfigTest.state(card,zl3.r(card));WifiConfigRuntime.save(WifiConfigRuntime.snapshot().key,Collections.emptyMap());
  activity=new Activity();close=()->{closed++;return sc5.a;};done=(us1)WifiConfigEditor.begin(activity,close);
 }
 public static void main(String[]args)throws Exception{
  init();check(done!=close&&activity.app.callbacks.size()==1,"original sheet lifecycle retained");
  check(WifiConfigEditor.begin(activity,close)==done,"recomposition keeps session");
  open("NAI");
  check(xq0.buttons.size()==2&&xq0.buttons.get(0).a.equals("重置为内置")&&xq0.buttons.get(1).a.equals("保存"),"only reset and save buttons");
  check(xq0.message==null,"no explanation paragraph");
  check(ak2.edits.size()==4&&z45.text.equals(Arrays.asList("NAI","IMPI（私有身份）","IMPU（公共身份）","EAP Identity")),"only field names, no default/saved/preview/help blocks");
  check(ak2.edits.get(0).value.equals("anonymous@nai.example.org")&&ak2.edits.get(1).value.equals(card.a+"@ims.example.org")&&ak2.edits.get(2).value.isEmpty()&&ak2.edits.get(3).value.isEmpty(),"defaults filled with real values, missing defaults stay blank");
  check(ak2.edits.stream().allMatch(e->e.hint.isEmpty()),"no verbose placeholder explanations");
  check(z45.styles.stream().allMatch(style->style==mk2.g)&&z45.colors.stream().allMatch(color->color==4L),"field labels use 15sp secondary text, not action styling");
  check(ak2.edits.stream().allMatch(e->e.style==mk2.e&&((oo4.Width)e.modifier).minHeight==48f),"inputs use 17sp text and a 48dp minimum target");
  ak2.edits.get(0).change.i("own@nai.example.org");xq0.press("保存");render();
  check(xq0.buttons.stream().noneMatch(b->b.c)&&xq0.buttons.get(1).a.equals("保存中…"),"save operation immediately renders disabled busy buttons");
  xq0.press("保存中…");waitForSave();
  check(saved().get("nai").equals("own@nai.example.org")&&((gl5)zl5.b.value).f.r.equals("own@nai.example.org"),"popup Save immediately persists and applies value");
  check(!saved().containsKey("impi"),"untouched prefilled identity is not frozen as an override");
  ((us1)WifiConfigEditor.cancelCallback(close)).a();done=(us1)WifiConfigEditor.begin(activity,close);open("NAI");
  check(ak2.edits.get(0).value.equals("own@nai.example.org"),"saved value survives page dismissal and reopening without Done");
  xq0.press("重置为内置");waitForSave();render();
  check(!saved().containsKey("nai")&&ak2.edits.get(0).value.equals("anonymous@nai.example.org"),"reset immediately deletes own value and fills builtin");
  xq0.cancel.a();
  open("Domain");ak2.edits.get(0).change.i("bad\nheader");String before=WifiConfigRuntime.snapshot().record;xq0.press("保存");render();
  check(xq0.message!=null&&ak2.edits.get(0).value.equals("bad\nheader")&&WifiConfigRuntime.snapshot().record.equals(before),"invalid value stays editable without persistence");
  ak2.edits.get(0).change.i("CUSTOM.EXAMPLE.ORG");xq0.press("保存");waitForSave();
  check(saved().get("domain").equals("custom.example.org"),"save normalizes input");
  open("Domain");check(ak2.edits.get(0).value.equals("custom.example.org"),"reopen prefilled with own value");
  ak2.edits.get(0).change.i("unsaved.example.org");xq0.cancel.a();open("Domain");check(ak2.edits.get(0).value.equals("custom.example.org"),"dismiss discards only unsaved typing");xq0.cancel.a();
  WifiConfigEditor.editLegacy(17,"49");open("APN");ak2.edits.get(0).change.i("custom.ims");xq0.press("保存");waitForSave();
  check(saved().get("apn").equals("custom.ims")&&!saved().containsKey("imei"),"field Save excludes incomplete unrelated input");
  done.a();check(Toast.last.contains("IMEI"),"page Done still validates remaining inline drafts");WifiConfigEditor.editLegacy(17,"");
  open("IKE");check(ak2.edits.size()==4&&ak2.edits.get(0).value.equals("aes256"),"algorithm group prefilled without notes");ak2.edits.get(0).change.i("aes128");xq0.press("保存");waitForSave();check(((gl5)zl5.b.value).f.j.equals(Arrays.asList("aes128")),"algorithm save immediate");
  open("IKE");xq0.press("重置为内置");waitForSave();render();check(ak2.edits.get(0).value.equals("aes256")&&((gl5)zl5.b.value).f.j.equals(Arrays.asList("aes256"))&&saved().get("domain").equals("custom.example.org"),"group reset restores defaults without clearing unrelated saves");xq0.cancel.a();

  check(WifiConfigEditor.listSection(20,composer)&&ak2.row.label.equals("ePDG"),"original ePDG inline section now opens list");
  check(WifiConfigEditor.listSection(21,composer)&&ak2.row.label.equals("短信中心"),"original SMSC inline section now opens list");
  check(WifiConfigEditor.listSection(22,composer)&&ak2.row.label.equals("IMEI"),"IMEI uses same compact popup");
  open("ePDG");check(ak2.edits.size()==1&&ak2.edits.get(0).value.equals("default.epdg.example.org")&&ak2.actionLabels.contains("删除"),"builtin ePDG has same editable field and Delete action");
  check(z45.colors.get(z45.text.indexOf("删除"))==2L&&z45.colors.get(z45.text.indexOf("添加"))==1L,"dangerous Delete and primary Add have distinct semantic colors");
  check(z45.styles.get(z45.text.indexOf("添加"))==mk2.e,"actions use readable 17sp text");
  ak2.press("删除");render();check(ak2.edits.isEmpty(),"builtin ePDG can be removed");ak2.press("添加");render();ak2.edits.get(0).change.i("one.epdg.example.org");ak2.press("添加");render();ak2.edits.get(1).change.i("two.epdg.example.org");xq0.press("保存");waitForSave();
  check(((gl5)zl5.b.value).f.f.equals(Arrays.asList("one.epdg.example.org","two.epdg.example.org")),"saved ordered endpoints replace deleted builtin");
  open("ePDG");check(ak2.edits.size()==2&&ak2.edits.get(1).value.equals("two.epdg.example.org"),"multiple endpoints survive reopen");
  ak2.press("删除");render();ak2.press("删除");xq0.press("保存");waitForSave();open("ePDG");check(ak2.edits.isEmpty()&&((gl5)zl5.b.value).f.f.isEmpty(),"empty endpoint list stays empty without resurrecting defaults");
  xq0.press("重置为内置");waitForSave();render();check(ak2.edits.size()==1&&ak2.edits.get(0).value.equals("default.epdg.example.org"),"reset restores builtin endpoint list");
  ak2.edits.get(0).change.i("edited-default.example.org");xq0.press("保存");waitForSave();check(((gl5)zl5.b.value).f.f.equals(Arrays.asList("edited-default.example.org")),"builtin endpoint editable exactly like an added one");

  open("短信中心");check(ak2.edits.get(0).value.equals(card.f)&&ak2.actionLabels.contains("删除"),"card SMSC is an ordinary editable/deletable entry");
  ak2.press("添加");render();ak2.edits.get(1).change.i("+442222222222");ak2.press("○ 使用此号码");xq0.press("保存");waitForSave();
  check(((gl5)zl5.b.value).i.equals("+442222222222")&&WifiConfigListDraft.decode(saved().get("smsc_list")).size()==2,"multiple SMSCs saved with the selected number applied");
  open("短信中心");check(ak2.edits.size()==2&&ak2.actionLabels.get(2).equals("● 当前使用"),"selection and entries survive reopen");
  ak2.press("删除");render();xq0.press("保存");waitForSave();open("短信中心");check(ak2.edits.size()==1&&ak2.edits.get(0).value.equals("+442222222222"),"deleted builtin SMSC stays absent");
  ak2.press("删除");xq0.press("保存");waitForSave();open("短信中心");check(ak2.edits.isEmpty()&&saved().get("smsc_list").equals("[]")&&((gl5)zl5.b.value).i.isEmpty(),"all SMSCs can be deleted persistently");
  try{WifiConfigRuntime.requireSmsCenter();throw new AssertionError("deleted SMSC auto-restored");}catch(IllegalStateException expected){check(expected.getMessage().contains("添加短信中心"),"empty SMSC list blocks fallback to a deleted builtin");}
  xq0.press("重置为内置");waitForSave();render();check(ak2.edits.size()==1&&ak2.edits.get(0).value.equals(card.f)&&!saved().containsKey("smsc_list"),"reset restores card SMSC and removes list overrides");xq0.cancel.a();WifiConfigRuntime.requireSmsCenter();
  open("Domain");ctx.prefs.fail=true;ak2.edits.get(0).change.i("failed.example.org");xq0.press("保存");waitForSave();render();check(xq0.message.contains("保存失败")&&saved().get("domain").equals("custom.example.org"),"failed persistence retains saved state and shows only error");xq0.cancel.a();
  open("Domain");WifiConfigRuntime.save(WifiConfigRuntime.snapshot().key,Collections.singletonMap("domain","external.example.org"));ak2.edits.get(0).change.i("stale.example.org");xq0.press("保存");waitForSave();render();check(xq0.message.contains("其他操作")&&saved().get("domain").equals("external.example.org"),"popup Save does not overwrite concurrent updates");
  activity.destroy();check(activity.app.callbacks.isEmpty()&&!WifiConfigEditor.editLegacy(17,"50"),"destroy releases callbacks");
  check(composer.depth==0,"Compose groups balanced");
  System.out.println("PASS: "+passed+" compact editor persistence and list UI assertions (platform/Compose doubles)");
 }
}
