#!/usr/bin/env python3
"""Execute shipped Android audio controller bytecode with explicit platform failure doubles."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('apk',type=Path);p.add_argument('decoded',type=Path);p.add_argument('--report',type=Path,required=True);p.add_argument('--legacy',action='store_true');a=p.parse_args()
src=ROOT/'validation/native-audio';adapter=ROOT/'validation/native-carrier'
toolroot=Path(os.environ.get('SIMHUB_DEX2JAR_TOOLS','/workspace/tools/dex2jar-v2.4'));tools=toolroot/'dex-tools-v2.4';lib=tools/'lib'
android=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
manifest=json.loads((adapter/'toolchain.json').read_text());distribution=toolroot/'dex-tools-v2.4.zip'
assert hashlib.sha256(distribution.read_bytes()).hexdigest()==manifest['distribution_sha256']
with zipfile.ZipFile(distribution)as z:
 expected={Path(n).name:z.read(n)for n in z.namelist()if '/lib/'in n and n.endswith('.jar')}
 assert set(expected)=={f.name for f in lib.glob('*.jar')}
 for name,contents in expected.items():assert (lib/name).read_bytes()==contents,name
work=a.report.parent/('native-audio-legacy'if a.legacy else'native-audio-current');work.mkdir(parents=True,exist_ok=True);classes=work/'classes';classes.mkdir(exist_ok=True)
logs=[]
def run(*args):
 r=subprocess.run(list(map(str,args)),cwd=ROOT,capture_output=True,text=True);logs.append(r.stdout+r.stderr)
 (work/'probe.log').write_text('\n'.join(logs))
 if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
 return r.stdout
asm=os.pathsep.join(str(lib/f)for f in ['asm-9.5.jar','asm-tree-9.5.jar'])
run('java','-jar',android/'ecj-3.40.0.jar','-17','-cp',asm,'-d',classes,adapter/'NormalizeR8Constructors.java')
run('sh',tools/'d2j-dex2jar.sh','-f','-o',work/'translated.jar',a.apk)
run('python3',adapter/'normalize_r8_constructors.py',a.decoded/'smali',work/'constructors.tsv')
run('java','-cp',str(classes)+os.pathsep+asm,'NormalizeR8Constructors',work/'translated.jar',work/'constructors.tsv',work/'probe.jar')
cp=os.pathsep.join(map(str,[work/'probe.jar',android/'sdk/android-35/android.jar']))
run('java','-jar',android/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-cp',cp,'-d',classes,*sorted(src.rglob('*.java')))
for model in ['yz','xz','py3','wz','k7','vz','tz','uz']:
 assert not (classes/(model+'.class')).exists(),'Actual APK audio class replaced: '+model
out=run('java','-noverify','-cp',os.pathsep.join(map(str,[classes,work/'probe.jar',android/'sdk/android-35/android.jar'])),'NativeAudioProbe','legacy'if a.legacy else'current')
match=re.search(r'NATIVE_AUDIO (?:legacy_regression_reproduced|current_passed)=true checks=(\d+)',out);assert match,out
report=dict(apk_sha256=hashlib.sha256(a.apk.read_bytes()).hexdigest(),checks=int(match[1]),legacy_regression_reproduced=a.legacy,
 actual_apk_audio_controller=True,actual_capture_and_playback_workers=True,actual_permission_and_routing_functions=True,
 explicit_android_hardware_system_api_fixtures=True,platform_failure_injection=True,device_tested=False,art_execution=False,
 covered=['normal acquisition/start/stop','AudioTrack.play failure rollback','audio-focus request failure rollback','optional audio-effect enable failure disposal',
 'independent recorder/player/effects release failure cleanup','focus abandon failure mode restoration','idempotent cleanup','Telecom owned system state preserved'])
a.report.write_text(json.dumps(report,indent=2)+'\n');print(out.strip())
