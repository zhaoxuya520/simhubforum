import cc.forserein.simhub.internal.DialingSupport;

public final class DialingSupportTest {
    private static int passed;
    private static void eq(String expected, String actual, String label) {
        if (!expected.equals(actual)) throw new AssertionError(label + ": " + actual);
        passed++;
    }
    private static void rejectsNull(int method) {
        try {
            if (method == 0) DialingSupport.ascii(null);
            else if (method == 1) DialingSupport.normalize(null);
            else if (method == 2) DialingSupport.smsDestination(null);
            else DialingSupport.callInput(null);
            throw new AssertionError("null must retain original rejection");
        } catch (NullPointerException expected) { passed++; }
    }
    public static void main(String[] args) {
        String cn = "+8613800000000";
        eq(cn, DialingSupport.normalize("+86 (138) 0000-0000"), "formatted mainland");
        eq(cn, DialingSupport.normalize(" ＋８６（１３８）００００－００００ "), "fullwidth pasted number");
        eq(cn, DialingSupport.normalize("+٨٦١٣٨٠٠٠٠٠٠٠٠"), "decimal digits become ASCII");
        eq("123", DialingSupport.normalize("\uD835\uDFD9\uD835\uDFDA\uD835\uDFDB"), "supplementary decimal digits");
        eq("", DialingSupport.normalize("abc"), "non-number stays invalid");
        eq("+", DialingSupport.normalize("＋"), "no invented digits");
        eq("13800000000", DialingSupport.normalize("13800000000"), "no guessed country code");
        eq("008613800000000", DialingSupport.normalize("00 86 138 0000 0000"), "UI keeps international access prefix");
        eq("888", DialingSupport.normalize("888"), "short code unchanged");
        eq("110", DialingSupport.normalize("１１０"), "emergency check receives canonical digits");
        eq("112", DialingSupport.normalize("１１２"), "international emergency check");
        eq("*123#", DialingSupport.ascii("*１２３#"), "call service syntax retained");
        eq("+86 (138) 0000-0000", DialingSupport.ascii("＋８６ (１３８) ００００-００００"), "wire call keeps formatting for original parser");
        for (String input : new String[] {cn, "00 86 138 0000 0000", "＋８６１３８００００００００", "００８６１３８００００００００", " +86 (138) 0000-0000 "}) {
            String actual = DialingSupport.smsDestination(input);
            eq(cn, actual, "SMS canonical recipient");
            eq(actual, DialingSupport.smsDestination(actual), "SMS coroutine cloning is idempotent");
            // Existing ub4 strips '+' before BCD and sets international TON for '+'.
            eq("8613800000000", actual.substring(1), "SMS address excludes the 00 access prefix");
        }
        eq("+442000000000", DialingSupport.smsDestination("0044 2000 000000"), "other countries");
        eq("888", DialingSupport.smsDestination("8 8 8"), "formatted short SMS recipient");
        eq("13800000000", DialingSupport.smsDestination("13800000000"), "no domestic-to-international inference");
        eq("0118613800000000", DialingSupport.smsDestination("0118613800000000"), "no locale-free 011 rewrite");
        eq("00", DialingSupport.smsDestination("00"), "incomplete prefix not converted to plus only");
        eq("", DialingSupport.smsDestination(""), "empty stays empty");
        for (String[] sample : new String[][] {
            {"+32 (0)2 555 01 23", "+32 2 555 01 23", "+3225550123", "+32025550123"},
            {"0032 (0)470 12 34 56", "0032 470 12 34 56", "0032470123456", "+320470123456"},
            {"＋３２（０）４７０１２３４５６", "+32470123456", "+32470123456", "+320470123456"},
            {"+33 (0)1 99000123", "+33 1 99000123", "+33199000123", "+330199000123"},
            {"+86 (0)10 0000 0123", "+86 10 0000 0123", "+861000000123", "+8601000000123"},
            {"00353 (0)1 234 5678", "00353 1 234 5678", "0035312345678", "+353012345678"},
            {"+63 (0)917 123 4567", "+63 917 123 4567", "+639171234567", "+6309171234567"},
            {"+49 (0)30 23125 000", "+49 30 23125 000", "+493023125000", "+4903023125000"},
            {"0049 (0)30 23125 000", "0049 30 23125 000", "00493023125000", "+4903023125000"},
            {"+44 (0)1632 960123", "+44 1632 960123", "+441632960123", "+4401632960123"},
            {"0044 (0)1632 960123", "0044 1632 960123", "00441632960123", "+4401632960123"},
            {"＋４９（０）３０ ２３１２５ ０００", "+4930 23125 000", "+493023125000", "+4903023125000"},
            {"００４４（０）１６３２ ９６０１２３", "00441632 960123", "00441632960123", "+4401632960123"},
            {" + 4 9\u00a0( 0 ) 30-23125-000 ", " + 4 9\u00a0 30-23125-000 ", "+493023125000", "+4903023125000"},
            {"00 49 - (0) - 30 23125 000", "00 49 -  - 30 23125 000", "00493023125000", "+4903023125000"}
        }) {
            eq(sample[1], DialingSupport.callInput(sample[0]), "raw call removes only explicit marker");
            eq(sample[2], DialingSupport.normalize(sample[0]), "UI/contact sees marker before filtering");
            eq(sample[2], DialingSupport.normalize(DialingSupport.normalize(sample[0])), "UI normalization idempotent");
            eq(sample[1], DialingSupport.callInput(sample[1]), "raw call normalization idempotent");
            eq(sample[3], DialingSupport.smsDestination(sample[0]), "SMS and SMSC preserve prior zero semantics");
        }
        for (String[] sample : new String[][] {
            {"+32 2 555 01 23", "+3225550123"}, {"+32025550123", "+32025550123"},
            {"02 555 01 23", "025550123"}, {"0470 12 34 56", "0470123456"},
            {"+32 (0)12", "+32012"}, {"+32 (0)2 5550 1234", "+320255501234"},
            {"+49 30 23125 000", "+493023125000"}, {"+4903023125000", "+4903023125000"},
            {"004903023125000", "004903023125000"}, {"+4401632960123", "+4401632960123"},
            {"+39 (0)6 123456", "+3906123456"}, {"0039 06 123456", "003906123456"},
            {"+225 (0)7 12 34 56 78", "+2250712345678"}, {"+33 (0)1 234", "+3301234"},
            {"+1 (0)2025550123", "+102025550123"}, {"+491 (0)23125000", "+491023125000"},
            {"+49 (30) 23125 000", "+493023125000"}, {"030 23125 000", "03023125000"},
            {"(0)30 23125 000", "03023125000"}, {"01149 (0)30 23125000", "0114903023125000"},
            {"+49 (0)", "+490"}, {"+49 (0)30", "+49030"}, {"+44 (0)123", "+440123"},
            {"+49 (0)03023125000", "+49003023125000"}, {"+49 (00)3023125000", "+49003023125000"},
            {"+49 ((0))3023125000", "+4903023125000"}, {"+49 (0)30 23125000;ext=78", "+490302312500078"},
            {"+49 (0)30 23125000,78", "+490302312500078"}, {"+49 (0)30 23125000#", "+4903023125000"},
            {"tel:+49 (0)3023125000", "+4903023125000"}, {"+49 (0)1234567890123456", "+4901234567890123456"},
            {"112", "112"}, {"110", "110"}, {"999", "999"}, {"*123#", "123"}
        }) {
            eq(sample[0], DialingSupport.callInput(sample[0]), "ambiguous/other-country/normal raw call unchanged");
            eq(sample[1], DialingSupport.normalize(sample[0]), "other notation keeps prior UI normalization");
            eq(sample[0], DialingSupport.ascii(sample[0]), "shared ASCII converter does not acquire call policy");
        }
        for (int i = 0; i < 4; i++) rejectsNull(i);
        System.out.println("PASS: " + passed + " dialing normalization assertions");
    }
}
