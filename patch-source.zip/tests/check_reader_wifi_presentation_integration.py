#!/usr/bin/env python3
"""Bound the reader header changes; verify explicit country recomposition inputs."""
from pathlib import Path
import argparse,hashlib,json,re,sys,tempfile

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from reader_wifi_presentation_patch import (
    TARGET,READER,FLAG,RENDERER,METHOD_PINS,HELPER,FLAG_OLD,FLAG_NEW,
    SUBTITLE_OLD,SUBTITLE_NEW,method,renderer,transform,
    reverse_reader_wifi_presentation,verify_reader_wifi_presentation,
)
p=argparse.ArgumentParser();p.add_argument('decoded',type=Path,nargs='?',default=ROOT/'build-config3/apktool')
p.add_argument('--baseline',action='store_true');p.add_argument('--report',type=Path);a=p.parse_args()
smali=a.decoded/'smali' if (a.decoded/'smali').is_dir() else a.decoded
source=(smali/TARGET).read_text();patched=transform(source) if a.baseline else source
restored=transform(patched,True);checks=0
def check(condition,message):
    global checks
    assert condition,message;checks+=1
def rejects(label,action):
    try:action()
    except AssertionError:check(True,label);return
    raise AssertionError('accepted '+label)

check(transform(restored)==patched,'non-exact forward/reverse')
check(reverse_reader_wifi_presentation('unrelated.smali','unchanged')=='unchanged','unrelated class changed')
rejects('double application',lambda:transform(patched))
rejects('wrong gl5 register',lambda:transform(patched.replace('invoke-static {v1}, '+HELPER+'->country','invoke-static {v0}, '+HELPER+'->country',1),True))
rejects('wrong subtitle state',lambda:transform(patched.replace('invoke-static {v1, v3}, '+HELPER+'->subtitle','invoke-static {v2, v3}, '+HELPER+'->subtitle',1),True))
rejects('wrong composer register',lambda:transform(patched.replace('invoke-static {v0, v3, v8, v14, v2}, Lfd2;->readerWifiFlag','invoke-static {v0, v3, v9, v14, v2}, Lfd2;->readerWifiFlag',1),True))
rejects('missing renderer restart',lambda:transform(patched.replace('->restartFlag(Ljava/lang/Object;Ljava/lang/String;III)V','->lostRestart(Ljava/lang/Object;Ljava/lang/String;III)V',1),True))
rejects('source native flag changed',lambda:transform(restored.replace('    const v1, 0x24e7ea22','    const v1, 0x24e7ea23',1)))
rejects('source reader changed',lambda:transform(restored.replace('    .locals 69','    .locals 70',1)))

def methods(text):
    return {sig:body for sig,body in re.findall(r'\.method ([^\n]+)\n(.*?)\.end method',text,re.S)}
old,new=methods(restored),methods(patched)
check(set(new)-set(old)=={RENDERER},'unexpected added native methods')
check(set(old)<=set(new),'original native method removed')
changed={signature for signature in old if old[signature]!=new[signature]}
check(changed=={READER},'native methods changed beyond reader header')
for signature in [FLAG,'public static final a(Lgl5;Lws1;Llu1;I)V','public static final u(Lsd2;Llu1;I)V',
        'public static final h(Lsd2;Llu1;I)V']:
    check(old[signature]==new[signature],'shared flag/switch/status/progress changed')
_,_,reader=method(patched,READER);_,_,flag=method(patched,RENDERER)
check(reader.count(FLAG_NEW)==1 and reader.count(SUBTITLE_NEW)==1,'reader hooks duplicate')
check(FLAG_OLD not in reader,'reader still derives flag from raw SIM')
check('move-object/from16 v1, p0' in reader[:reader.index(FLAG_NEW)],'explicit state provenance missing')
check('    iget-object v0, v1, Lgl5;->e:Lek5;' in reader[:reader.index(FLAG_NEW)],'existing card presence guard moved')
check('    if-eqz v4, :cond_b' in reader[:reader.index(SUBTITLE_NEW)],'existing config presence guard moved')
check('    const/16 v18, 0x1' in reader[reader.index(SUBTITLE_NEW):reader.index(SUBTITLE_NEW)+900], 'single-line subtitle changed')
check(flag==renderer(method(restored,FLAG)[2]),'flag layout diverges from pinned native template')
check('Lek5;' not in flag and 'Lo95;' not in flag and 'Lzl5;' not in flag,'renderer uses identity or global state')
check('move-object/from16 v0, p0' in flag and 'invoke-virtual {v5, v0}, Llu1;->g(Ljava/lang/Object;)Z' in flag,'entry skip dependency is not the explicit country')
check('move-object v1, v0\n    sget-object v11, Lxo0;->a:Lq8;\n    invoke-virtual {v5, v1}, Llu1;->g(Ljava/lang/Object;)Z' in flag,'image remember cache is not keyed by country')
check(flag.count('Lfd2;->B(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;')==1,'native flag asset lookup changed')
check(flag.count('Lei0;->z(Ljava/lang/String;)Ljava/lang/String;')==1 and '\\ud83c\\udf10' in flag,'native emoji/globe fallback missing')
check('    move-object/from16 v1, p0\n    move v2, v6\n    move/from16 v3, p3\n    move/from16 v4, p4' in flag,'restart lost its explicit arguments')
check('Lfd2;->m(' not in flag and 'Ll33;' not in flag,'restart fell back to the raw-card renderer')

# Compose's changed input mask: same country may skip; a changed country and
# the restart bit must execute. This is independent of rawCard object equality.
def executes(changed,flags):
    mask=flags|(4 if changed else 2)
    return (mask&0x13)!=0x12 or (mask&1)!=0
check(not executes(False,0x30),'unchanged country should remain skippable')
check(executes(True,0x30),'changed effective country must render with the same raw card')
check(executes(False,0x31),'restart bit must redraw theme/local changes')

helper=(ROOT/'src/cc/forserein/simhub/internal/ReaderWifiPresentation.java').read_text()
check('Class.forName("zl5")' not in helper and 'DitoHomeIdentity' not in helper,'presentation reads global state or chooses authentication')
check('getMethod("c",String.class,String.class)' in helper,'effective country does not use native directory rules')
check('flags|1' in helper and 'getMethod("readerWifiFlag"' in helper,'restart target/flags changed')
if a.baseline:
    with tempfile.TemporaryDirectory(prefix='reader-presentation-') as tmp:
        (Path(tmp)/TARGET).write_text(patched);detail=verify_reader_wifi_presentation(tmp)
else:
    detail=verify_reader_wifi_presentation(smali)
    compiled=(smali/'cc/forserein/simhub/internal/ReaderWifiPresentation.smali').read_text()
    for api in ['country(Ljava/lang/Object;)Ljava/lang/String;','subtitle(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;',
            'restartFlag(Ljava/lang/Object;Ljava/lang/String;III)V']:
        check('.method public static '+api in compiled,'compiled helper entry absent: '+api)
report=dict(checks=checks,method_pins={sig:digest for (_,sig),digest in METHOD_PINS.items()},
    checks_are_static=True,in_memory_transform=a.baseline,
    explicit_country_dependency=True,original_methods_changed=sorted(changed),**detail)
if a.report:a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(report,indent=2)+'\n')
print('PASS: '+str(checks)+' bounded reader header, original flag layout, callback and explicit-state checks')
