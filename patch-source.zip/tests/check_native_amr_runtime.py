#!/usr/bin/env python3
"""Host execution of the shipped DEX's media path with explicit hardware/network fixtures."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('apk',type=Path);p.add_argument('decoded',type=Path);p.add_argument('--report',type=Path,required=True);mode=p.add_mutually_exclusive_group();mode.add_argument('--legacy',action='store_true');mode.add_argument('--stream-legacy',action='store_true');a=p.parse_args()
src=ROOT/'validation/native-amr';adapter=ROOT/'validation/native-carrier'
toolroot=Path(os.environ.get('SIMHUB_DEX2JAR_TOOLS','/workspace/tools/dex2jar-v2.4'));tools=toolroot/'dex-tools-v2.4';lib=tools/'lib'
android=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
manifest=json.loads((adapter/'toolchain.json').read_text());distribution=toolroot/'dex-tools-v2.4.zip'
assert hashlib.sha256(distribution.read_bytes()).hexdigest()==manifest['distribution_sha256']
with zipfile.ZipFile(distribution)as z:
 expected={Path(n).name:z.read(n)for n in z.namelist()if '/lib/'in n and n.endswith('.jar')}
 assert set(expected)=={f.name for f in lib.glob('*.jar')}
 for name,contents in expected.items():assert (lib/name).read_bytes()==contents,name
work=a.report.parent/('native-amr-stream-legacy'if a.stream_legacy else 'native-amr-legacy'if a.legacy else'native-amr-current');work.mkdir(parents=True,exist_ok=True);classes=work/'classes';classes.mkdir(exist_ok=True)
logs=[]
def run(*args):
 r=subprocess.run(list(map(str,args)),cwd=ROOT,capture_output=True,text=True);logs.append(r.stdout+r.stderr)
 (work/'probe.log').write_text('\n'.join(logs))
 if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
 return r.stdout
asm=os.pathsep.join(str(lib/f)for f in ['asm-9.5.jar','asm-tree-9.5.jar'])
run('java','-jar',android/'ecj-3.40.0.jar','-17','-cp',asm,'-d',classes,adapter/'NormalizeR8Constructors.java')
run('sh',tools/'d2j-dex2jar.sh','-f','-o',work/'translated.jar',a.apk)
run(sys.executable,adapter/'normalize_r8_constructors.py',a.decoded/'smali',work/'constructors.tsv')
run('java','-cp',str(classes)+os.pathsep+asm,'NormalizeR8Constructors',work/'translated.jar',work/'constructors.tsv',work/'probe.jar')
fixtures=list(src.rglob('*.java'))+[ROOT/'tests/AmrFramingTest.java',ROOT/'tests/android/content/Context.java',ROOT/'tests/android/content/SharedPreferences.java']
compile_only=work/'compile-only';compile_only.mkdir(exist_ok=True)
run('java','-jar',android/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-d',compile_only,ROOT/'src/cc/forserein/simhub/internal/AmrFraming.java')
cp=os.pathsep.join(map(str,[compile_only,work/'probe.jar',android/'sdk/android-35/android.jar']))
run('java','-jar',android/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-cp',cp,'-d',classes,*fixtures)
for model in ['t10','m10','k7','q93','w','bl2','hx3','d43','th']:
 assert not (classes/(model+'.class')).exists(),'Actual APK class replaced: '+model
assert not (classes/'cc/forserein/simhub/internal/AmrFraming.class').exists()
out=run('java','-noverify','-cp',os.pathsep.join(map(str,[classes,work/'probe.jar',android/'sdk/android-35/android.jar'])),'NativeAmrProbe','stream-legacy'if a.stream_legacy else'legacy'if a.legacy else'current')
match=re.search(r'NATIVE_AMR (?:stream_legacy_regression_reproduced|legacy_regression_reproduced|current_passed)=true checks=(\d+)',out);assert match,out
report=dict(apk_sha256=hashlib.sha256(a.apk.read_bytes()).hexdigest(),checks=int(match[1]),legacy_regression_reproduced=a.legacy,
 legacy_stream_regression_reproduced=a.stream_legacy,
 actual_apk_media_constructor=True,native_rtp_parser=True,native_amr_depacketizer=True,native_jitter_queue=True,native_amr_packetizer=True,
 explicit_audio_codec_hardware_and_network_fixtures=True,synthetic_speech_vectors=True,device_tested=False,art_execution=False)
a.report.write_text(json.dumps(report,indent=2)+'\n');print(out.strip())
