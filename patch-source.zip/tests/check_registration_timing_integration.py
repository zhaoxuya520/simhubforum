#!/usr/bin/env python3
"""Verify bounded registration hooks and exact restoration of all three native methods."""
from pathlib import Path
import argparse,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from registration_timing_patch import restore_native,METHOD_PINS,method
p=argparse.ArgumentParser();p.add_argument('decoded',type=Path);p.add_argument('--report',type=Path);a=p.parse_args()
smali=a.decoded/'smali';checks=0
for name in ['o82.smali','bh1.smali']:
 value=(smali/name).read_text();original=restore_native(name,value)
 for (target,sig),digest in METHOD_PINS.items():
  if target==name:
   assert hashlib.sha256(method(original,sig).encode()).hexdigest()==digest,(target,sig);checks+=1
assert 'RegistrationTiming;->acceptedExpires(I)I' in (smali/'o82.smali').read_text();checks+=1
assert 'RegistrationTiming;->refreshDelayMillis(I)J' in (smali/'bh1.smali').read_text();checks+=1
helper=(smali/'cc/forserein/simhub/internal/RegistrationTiming.smali').read_text()
assert 'acceptedExpires(I)I' in helper and 'refreshDelayMillis(I)J' in helper;checks+=1
report=dict(checks=checks,native_methods=['o82.v','o82.y','bh1.q registration branch'],native_contact_matching_unchanged=True,native_aka_security_negotiation_unchanged=True,device_tested=False)
out=a.report or a.decoded.parent/'registration-timing-integration.json';out.write_text(json.dumps(report,indent=2)+'\n')
print('PASS:',checks,'registration expiry hooks and exact native method restoration checks')
