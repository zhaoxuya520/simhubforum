import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import java.util.*;
public class CarrierPickerUiTest {
 static int passed;static final lu1 composer=new lu1();
 static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);passed++;}
 static void waitSave()throws Exception{long end=System.nanoTime()+2_000_000_000L;while(Handler.tasks.isEmpty()&&System.nanoTime()<end)Thread.sleep(5);check(!Handler.tasks.isEmpty(),"background save completed");Handler.drain();}
 static void render(){WifiConfigEditor.overlay(composer);}
 static void open(String row){WifiConfigEditor.row(row,"old",composer,6);ak2.click.a();render();}
 public static void main(String[]args)throws Exception{
  WifiConfigTest.Ctx ctx=new WifiConfigTest.Ctx();zl5.f=ctx;ek5 card=new ek5("204040123456789","preset-ui");card.f="+441234567890";
  zl5.b.value=WifiConfigTest.state(card,zl3.r(card));WifiConfigRuntime.save(WifiConfigRuntime.snapshot().key,Collections.emptyMap());
  WifiConfigRuntime.save(WifiConfigRuntime.snapshot().key,new LinkedHashMap<String,String>(){{put("smsc_list","+499999999999");put("smsc","+499999999999");}});
  Activity activity=new Activity();us1 close=()->sc5.a;WifiConfigEditor.begin(activity,close);
  WifiConfigEditor.listSection(20,composer);check(ak2.row.label.equals("ePDG"),"carrier entry does not replace existing ePDG row");
  WifiConfigEditor.row("运营商","",composer,6);check(ak2.row.value.equals("自动识别 · Vodafone"),"automatic operator shown before manual selection");ak2.click.a();render();
  check(xq0.title.equals("选择运营商")&&ak2.edits.size()==1&&z45.text.get(0).equals("搜索运营商")&&ak2.actionLabels.get(0).equals("搜索"),"search input and explicit search button present");
  check(ak2.actionLabels.contains("下一页")&&ak2.actionLabels.size()==CarrierPresets.PAGE_SIZE+2,"long operator catalogue is paginated");
  ak2.press("下一页");render();check(ak2.actionLabels.contains("上一页")&&!ak2.actionLabels.contains("下一页"),"next page reaches remaining operators");ak2.press("上一页");render();
  ak2.edits.get(0).change.i("no-such-operator");ak2.press("搜索");render();check(z45.text.contains("未找到运营商")&&!ak2.actionLabels.contains("下一页"),"empty search does not show unrelated operators");
  ak2.edits.get(0).change.i("DITO 菲律宾");ak2.press("搜索");render();check(ak2.actionLabels.size()==3&&ak2.actionLabels.get(1).contains("DITO"),"search by name and country finds matching presets only");
  String key=DitoCarrierProfile.KEY;ak2.press(CarrierPresets.find(key).title);waitSave();
  gl5 state=(gl5)zl5.b.value;check(state.f.c.equals("DITO")&&state.f.g.equals("ims.mnc066.mcc515.3gppnetwork.org")&&state.f.f.equals(Arrays.asList("epdg.epc.mnc066.mcc515.pub.3gppnetwork.org")),"tapping result immediately replaces live carrier parameters");
  check(state.i.equals(card.f)&&!WifiConfigRuntime.snapshot().values.containsKey("smsc_list")&&WifiConfigRuntime.displaySmsCenter(card).equals(card.f),"manual choice clears old SMSC and applies the same card default as automatic mode");
  WifiConfigEditor.row("运营商","",composer,6);check(ak2.row.value.contains("DITO")&&!ak2.row.value.contains("Vodafone"),"selected carrier displayed instead of automatic mismatch");
  open("Domain");check(ak2.edits.get(0).value.equals("ims.mnc066.mcc515.3gppnetwork.org"),"details popup prefilled from selected operator");ak2.edits.get(0).change.i("mine.example.org");xq0.press("保存");waitSave();
  open("Domain");xq0.press("重置为内置");waitSave();render();check(ak2.edits.get(0).value.equals("ims.mnc066.mcc515.3gppnetwork.org"),"field reset restores selected operator default, not wrong automatic carrier");xq0.cancel.a();
  ((us1)WifiConfigEditor.cancelCallback(close)).a();WifiConfigEditor.begin(activity,close);open("运营商");
  ak2.edits.get(0).change.i("51566");ak2.press("搜索");render();check(ak2.actionLabels.contains("✓ "+CarrierPresets.find(key).title),"selection persists across reopening and is marked in filtered results");
  xq0.press("自动识别");waitSave();check(((gl5)zl5.b.value).f.c.equals("Vodafone")&&!WifiConfigRuntime.snapshot().values.containsKey(CarrierPresets.KEY),"automatic action restores native detection and clears manual selection");
  open("运营商");ak2.edits.get(0).change.i("Dito");ak2.press("搜索");render();ctx.prefs.fail=true;ak2.press(CarrierPresets.find(key).title);waitSave();render();check(xq0.message.contains("保存失败")&&((gl5)zl5.b.value).f.c.equals("Vodafone"),"failed choice stays in picker and retains previous live operator");
  xq0.press("取消");check(composer.depth==0,"picker Compose groups balanced");activity.destroy();
  System.out.println("PASS: "+passed+" carrier search and one-tap selection UI assertions (platform/Compose doubles)");
 }
}
