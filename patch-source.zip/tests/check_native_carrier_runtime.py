#!/usr/bin/env python3
"""Execute the actual APK's carrier code on the JVM, with explicit DEX/JVM/platform adapters."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('apk',type=Path);p.add_argument('decoded',type=Path);p.add_argument('--report',type=Path,required=True);modes=p.add_mutually_exclusive_group();modes.add_argument('--legacy',action='store_true');modes.add_argument('--recognition-legacy',action='store_true');modes.add_argument('--identity-policy-legacy',action='store_true');modes.add_argument('--identity-realm-legacy',action='store_true');a=p.parse_args()
source=ROOT/'validation/native-carrier';toolroot=Path(os.environ.get('SIMHUB_DEX2JAR_TOOLS','/workspace/tools/dex2jar-v2.4'))
android=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'));manifest=json.loads((source/'toolchain.json').read_text())
distribution=toolroot/'dex-tools-v2.4.zip';assert hashlib.sha256(distribution.read_bytes()).hexdigest()==manifest['distribution_sha256']
tools=toolroot/'dex-tools-v2.4';lib=tools/'lib'
with zipfile.ZipFile(distribution)as z:
 expected={Path(n).name:z.read(n)for n in z.namelist()if '/lib/'in n and n.endswith('.jar')}
 assert set(expected)=={f.name for f in lib.glob('*.jar')}
 for name,contents in expected.items():assert (lib/name).read_bytes()==contents,name
work=a.report.parent/('native-carrier-legacy'if a.legacy else'native-carrier-recognition-legacy'if a.recognition_legacy else'native-carrier-identity-policy-legacy'if a.identity_policy_legacy else'native-carrier-identity-realm-legacy'if a.identity_realm_legacy else'native-carrier-current');work.mkdir(parents=True,exist_ok=True);classes=work/'classes';classes.mkdir(exist_ok=True)
logs=[]
def run(*args):
 r=subprocess.run(list(map(str,args)),cwd=ROOT,capture_output=True,text=True);logs.append(r.stdout+r.stderr)
 (work/'probe.log').write_text('\n'.join(logs))
 if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
 return r.stdout
asm=os.pathsep.join(str(lib/f)for f in ['asm-9.5.jar','asm-tree-9.5.jar'])
run('java','-jar',android/'ecj-3.40.0.jar','-17','-cp',asm,'-d',classes,source/'NormalizeR8Constructors.java')
run('sh',tools/'d2j-dex2jar.sh','-f','-o',work/'translated.jar',a.apk)
run(sys.executable,source/'normalize_r8_constructors.py',a.decoded/'smali',work/'constructors.tsv')
run('java','-cp',str(classes)+os.pathsep+asm,'NormalizeR8Constructors',work/'translated.jar',work/'constructors.tsv',work/'probe.jar')
fixtures=[source/f for f in ['NativeCarrierProbe.java','Context.java','AssetManager.java','zl5.java']]+[ROOT/'tests'/f for f in ['android/content/SharedPreferences.java','android/util/Log.java','android/widget/Toast.java','android/os/Handler.java','android/os/Looper.java']]
run('java','-jar',android/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-cp',str(android/'sdk/android-35/android.jar')+os.pathsep+str(work/'probe.jar'),'-d',classes,*fixtures)
for model in ['ek5','xi5','gl5','yj5','fj5','zl3','vb5','qy3','xx3']:assert not (classes/(model+'.class')).exists(),'Probe must use actual APK model: '+model
# JVM bytecode adapters do not reconstruct stack maps for R8's DEX-only optimizations.
# Actual shipped DEX register types are checked independently by check_dex_types.py.
out=run('java','-noverify','-cp',os.pathsep.join(map(str,[classes,work/'probe.jar',android/'sdk/android-35/android.jar'])),'NativeCarrierProbe',a.decoded/'assets','legacy'if a.legacy else'recognition-legacy'if a.recognition_legacy else'identity-policy-legacy'if a.identity_policy_legacy else'identity-realm-legacy'if a.identity_realm_legacy else'current')
match=re.search(r'NATIVE_PROBE (?:legacy_regression_reproduced|recognition_legacy_regression_reproduced|identity_policy_legacy_regression_reproduced|identity_realm_legacy_regression_reproduced|current_passed)=true checks=(\d+)',out);assert match,out
auth_checks=0;auth_out='';auth_executed=not a.legacy and not a.recognition_legacy
if auth_executed:
 auth_asm=os.pathsep.join(str(lib/f)for f in ['asm-9.5.jar','asm-tree-9.5.jar','asm-util-9.5.jar'])
 run('java','-jar',android/'ecj-3.40.0.jar','-17','-cp',auth_asm,'-d',classes,source/'AuthenticationTransportAdapter.java')
 run('java','-cp',str(classes)+os.pathsep+auth_asm,'AuthenticationTransportAdapter',work/'probe.jar',work/'auth-probe.jar')
 auth_classes=work/'auth-classes';shutil.copytree(classes,auth_classes,dirs_exist_ok=True)
 # The carrier parser process uses ac5 as an explicit APDU boundary. The auth
 # process must load the APK's real ac5 constructor and keep physical qg0 inert.
 (auth_classes/'ac5.class').unlink(missing_ok=True)
 auth_cp=os.pathsep.join(map(str,[work/'auth-probe.jar',auth_classes,android/'sdk/android-35/android.jar']))
 run('java','-jar',android/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-cp',auth_cp,'-d',auth_classes,source/'NativeAuthenticationInputsProbe.java')
 for model in ['b72','da1','o82','ac5','s01','hm0','ek5','xi5']:
  assert not (auth_classes/(model+'.class')).exists(),'Actual native authentication class replaced: '+model
 auth_out=run('java','-noverify','-cp',str(auth_classes)+os.pathsep+str(work/'auth-probe.jar')+os.pathsep+str(android/'sdk/android-35/android.jar'),'NativeAuthenticationInputsProbe',a.decoded/'assets','identity-policy-legacy'if a.identity_policy_legacy else'identity-realm-legacy'if a.identity_realm_legacy else'current')
 auth_match=re.search(r'NATIVE_AUTH_INPUTS (?:legacy_regression_reproduced|identity_realm_legacy_regression_reproduced|current_passed)=true checks=(\d+)',auth_out);assert auth_match,auth_out
 auth_checks=int(auth_match[1])
report=dict(probe_source_sha256=hashlib.sha256((source/'NativeCarrierProbe.java').read_bytes()).hexdigest(),apk_translated_jar_sha256=hashlib.sha256((work/'probe.jar').read_bytes()).hexdigest(),apk_sha256=hashlib.sha256(a.apk.read_bytes()).hexdigest(),checks=int(match[1])+auth_checks,carrier_checks=int(match[1]),authentication_input_checks=auth_checks,identity_policy_legacy_regression_reproduced=a.identity_policy_legacy,identity_realm_legacy_regression_reproduced=a.identity_realm_legacy,legacy_regression_reproduced=a.legacy,recognition_legacy_regression_reproduced=a.recognition_legacy,
 actual_apk_helpers_executed=True,native_usim_coroutine_executed=not a.legacy,apdu_transport_fixture=not a.legacy,native_profile_models_executed=not a.legacy,native_json_parser_executed=True,native_preset_builder_executed=True,native_model_constructors_executed=True,
 actual_native_authentication_inputs_executed=auth_executed and not a.identity_policy_legacy,
 native_authentication_methods=['b72 constructor','b72.e post-IKE response continuation','da1 constructor','da1.b Type23/Subtype5 AT_IDENTITY response','s62.a','ac5 constructor','s01 constructor','hm0 constructor','o82 constructor','o82.n','o82.v REGISTER builder']if auth_executed and not a.identity_policy_legacy else[],
 outgoing_ims_transport_fixture='o82.K captures request and returns suspended marker; every other o82 method instruction fingerprint preserved'if auth_executed else None,
 aka_identity_wire_format_checked=auth_executed and not a.identity_policy_legacy,
 native_aka_engine_keeps_same_physical_adapter=auth_executed and not a.identity_policy_legacy,
 physical_apdu_and_network_authentication_tested=False,
 dex_to_jvm_constructor_and_interface_adapters=True,android_platform_and_session_doubles=True,device_tested=False,art_execution=False)
a.report.write_text(json.dumps(report,indent=2)+'\n');(work/'probe.log').write_text('\n'.join(logs))
print(out.strip())
if auth_out:print(auth_out.strip())
