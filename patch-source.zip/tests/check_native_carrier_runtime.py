#!/usr/bin/env python3
"""Execute the actual APK's carrier code on the JVM, with explicit DEX/JVM/platform adapters."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('apk',type=Path);p.add_argument('decoded',type=Path);p.add_argument('--report',type=Path,required=True);modes=p.add_mutually_exclusive_group();modes.add_argument('--legacy',action='store_true');modes.add_argument('--recognition-legacy',action='store_true');a=p.parse_args()
source=ROOT/'validation/native-carrier';toolroot=Path(os.environ.get('SIMHUB_DEX2JAR_TOOLS','/workspace/tools/dex2jar-v2.4'))
android=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'));manifest=json.loads((source/'toolchain.json').read_text())
distribution=toolroot/'dex-tools-v2.4.zip';assert hashlib.sha256(distribution.read_bytes()).hexdigest()==manifest['distribution_sha256']
tools=toolroot/'dex-tools-v2.4';lib=tools/'lib'
with zipfile.ZipFile(distribution)as z:
 expected={Path(n).name:z.read(n)for n in z.namelist()if '/lib/'in n and n.endswith('.jar')}
 assert set(expected)=={f.name for f in lib.glob('*.jar')}
 for name,contents in expected.items():assert (lib/name).read_bytes()==contents,name
work=a.report.parent/('native-carrier-legacy'if a.legacy else'native-carrier-recognition-legacy'if a.recognition_legacy else'native-carrier-current');work.mkdir(parents=True,exist_ok=True);classes=work/'classes';classes.mkdir(exist_ok=True)
logs=[]
def run(*args):
 r=subprocess.run(list(map(str,args)),cwd=ROOT,capture_output=True,text=True);logs.append(r.stdout+r.stderr)
 if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
 return r.stdout
asm=os.pathsep.join(str(lib/f)for f in ['asm-9.5.jar','asm-tree-9.5.jar'])
run('java','-jar',android/'ecj-3.40.0.jar','-17','-cp',asm,'-d',classes,source/'NormalizeR8Constructors.java')
run('sh',tools/'d2j-dex2jar.sh','-f','-o',work/'translated.jar',a.apk)
run(sys.executable,source/'normalize_r8_constructors.py',a.decoded/'smali',work/'constructors.tsv')
run('java','-cp',str(classes)+os.pathsep+asm,'NormalizeR8Constructors',work/'translated.jar',work/'constructors.tsv',work/'probe.jar')
fixtures=[source/f for f in ['NativeCarrierProbe.java','Context.java','AssetManager.java','zl5.java']]+[ROOT/'tests'/f for f in ['android/content/SharedPreferences.java','android/util/Log.java','android/widget/Toast.java','android/os/Handler.java','android/os/Looper.java']]
run('java','-jar',android/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-cp',str(android/'sdk/android-35/android.jar')+os.pathsep+str(work/'probe.jar'),'-d',classes,*fixtures)
for model in ['ek5','xi5','gl5','yj5','fj5','zl3','vb5','qy3','xx3']:assert not (classes/(model+'.class')).exists(),'Probe must use actual APK model: '+model
# JVM bytecode adapters do not reconstruct stack maps for R8's DEX-only optimizations.
# Actual shipped DEX register types are checked independently by check_dex_types.py.
out=run('java','-noverify','-cp',os.pathsep.join(map(str,[classes,work/'probe.jar',android/'sdk/android-35/android.jar'])),'NativeCarrierProbe',a.decoded/'assets','legacy'if a.legacy else'recognition-legacy'if a.recognition_legacy else'current')
match=re.search(r'NATIVE_PROBE (?:legacy_regression_reproduced|recognition_legacy_regression_reproduced|current_passed)=true checks=(\d+)',out);assert match,out
report=dict(probe_source_sha256=hashlib.sha256((source/'NativeCarrierProbe.java').read_bytes()).hexdigest(),apk_translated_jar_sha256=hashlib.sha256((work/'probe.jar').read_bytes()).hexdigest(),apk_sha256=hashlib.sha256(a.apk.read_bytes()).hexdigest(),checks=int(match[1]),legacy_regression_reproduced=a.legacy,recognition_legacy_regression_reproduced=a.recognition_legacy,
 actual_apk_helpers_executed=True,native_usim_coroutine_executed=not a.legacy,apdu_transport_fixture=not a.legacy,native_profile_models_executed=not a.legacy,native_json_parser_executed=True,native_preset_builder_executed=True,native_model_constructors_executed=True,
 dex_to_jvm_constructor_and_interface_adapters=True,android_platform_and_session_doubles=True,device_tested=False,art_execution=False)
a.report.write_text(json.dumps(report,indent=2)+'\n');(work/'probe.log').write_text('\n'.join(logs))
print(out.strip())
