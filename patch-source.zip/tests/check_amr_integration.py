#!/usr/bin/env python3
"""Check minimal framing hooks and byte-exact preservation of the native media engine."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from amr_framing_patch import replacements,restore_native
from registration_timing_patch import restore_native as restore_registration
from sip_session_timer_patch import reverse_sip_session_timer
from audio_lifecycle_patch import transform as audio_lifecycle_transform
decoded=Path(sys.argv[1]);base=Path(sys.argv[2]);smali=decoded/'smali'
assert hashlib.sha256(base.read_bytes()).hexdigest()=='cdd748532360f5632dc5661c0e8d9c9907967a0a136be16dfde118de43ad81c2'
baseline=Path('/workspace/recovery/config2-decoded/smali')
checks=0
for name in replacements():
 assert restore_native(name,(smali/name).read_text())==(baseline/name).read_text(),name
 checks+=1
unchanged=['d43','bl2','hx3','q93','w','s','t','k10','n10']
for name in unchanged:
 assert (smali/(name+'.smali')).read_bytes()==(baseline/(name+'.smali')).read_bytes(),name
 checks+=1
assert (smali/'yz.smali').read_text()==audio_lifecycle_transform((baseline/'yz.smali').read_text());checks+=1
assert restore_registration('o82.smali',reverse_sip_session_timer('o82.smali',(smali/'o82.smali').read_text()))==(baseline/'o82.smali').read_text();checks+=1
assert (smali/'cc/forserein/simhub/internal/AmrFraming.smali').is_file();checks+=1
report=dict(checks=checks,native_codec_audio_jitter_rtp_and_sdp_unchanged=unchanged,
 bounded_native_changes={'yz':'startup rollback and independent resource cleanup only; full transformed baseline compared','o82':'registration and session timer hooks reversed; full baseline compared'},
 hooks_only=['per-call constructor','receive format selection','transmit format selection','changed SDP reset'],
 device_tested=False)
(decoded.parent/'amr-integration.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS:',checks,'AMR hook and unchanged native media checks')
