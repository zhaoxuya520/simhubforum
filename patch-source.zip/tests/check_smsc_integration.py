#!/usr/bin/env python3
"""Verify SMSC/save/masking contracts while permitting the explicitly requested UI redesign."""
import sys,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];r=Path(sys.argv[1]);smali=r/'smali'
for name in ['fd2','i21']:
 text=(smali/(name+'.smali')).read_text()
 assert text.count('WifiConfigRuntime;->displaySmsCenter(Ljava/lang/Object;)Ljava/lang/String;')==1,name
assert 'const/16 v4, 0x6f42'in(smali/'vb5.smali').read_text()
assert 'iput-object p6, p0, Lek5;->f:Ljava/lang/String;'in(smali/'ek5.smali').read_text()
asset=json.loads((r/'assets/vowifi/carrier_presets.json').read_text())
assert not any(any('smsc'in k.lower()or'smscenter'in k.lower()for k in p)for p in asset['presets'])
source=root/'src/cc/forserein/simhub/internal/WifiConfigEditor.java'
editor=source.read_text()
new='try{if(selection.row.equals("短信中心"))WifiConfigRuntime.saveSmsCenter(s.snapshot.key,s.record,merged);else WifiConfigRuntime.save(s.snapshot.key,s.record,merged);}'
old='try{WifiConfigRuntime.save(s.snapshot.key,s.record,merged);}'
assert editor.count(new)==1
close_saved='''        if(values.equals(s.saved)){
            dispose(s);
            try{invoke(s.original);}catch(Exception e){toast(s,message(e));}
            return;
        }
'''
assert editor.count(close_saved)==1
home_mask='return DitoHomeIdentity.mask(card,value.replace(imsi,masked));'
assert editor.count(home_mask)==1
selection_alias='CarrierPresets.sameSelection(entry.key,s.saved.get(CarrierPresets.KEY))'
assert editor.count(selection_alias)==1
# The user explicitly requested a new visual design; do not freeze unrelated UI text/style.
# Preserve the functional hooks and immediate-save/list semantics instead.
for required in ['s.saved=new LinkedHashMap<>(WifiConfigValues.validate(merged))',
                 'for(String key:WifiConfigDraft.keys(selection.row))merged.remove(key);',
                 'list.remove(index)', 'list.add()', 'list.choose(index)',
                 'new Selection(selection.row,s.draft,s.snapshot.defaults)',
                 'current!=s || s.busy || s.selection!=selection',
                 's.snapshot=saved;', 's.draft=new WifiConfigDraft(saved.values)']:
 assert required in editor,required

native=(smali/'zl5.smali').read_text().split('.method public static y(Ljava/lang/String;)V',1)[1].split('.end method',1)[0]
assert 'WifiConfigRuntime;->updateSmsCenter(Ljava/lang/String;)V'in native
assert 'vowifi_sms_smsc_'not in native
assert 'WifiConfigEditor;->renderButton'not in(smali/'xq0.smali').read_text()
assert 'paintAction'not in(smali/'cc/forserein/simhub/internal/WifiConfigEditor.smali').read_text()
report=dict(native_compose_editor_retained=True,requested_visual_redesign=True,native_smsc_save_unified=True,custom_button_style_hook_removed=True,unified_effective_smsc_display=True,
 auto_smsc_source='SIM EF_SMSP / card.f',carrier_catalogue_has_smsc=False,device_tested=False)
(r.parent/'smsc-integration.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: requested editor redesign retains both SMSC save paths, effective display, list editing and SIM source')
