import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import java.util.*;

/** Missing-EF_SMSP entry uses the same explicit-save list editor, including during IMS. */
public class SmsCenterEditorUiTest {
 static int passed;static final lu1 composer=new lu1();static Activity activity;
 static WifiConfigTest.Ctx context;static ek5 card;
 static final String A="+441234567890",B="+44123456789",C="+441234567891";
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);passed++;}
 static Map<String,String> values(String... pairs){return WifiConfigTest.values(pairs);}
 static String record()throws Exception{return context.prefs.getString(WifiConfigRuntime.cardKey(card),null);}
 static Map<String,String> saved()throws Exception{return WifiConfigRuntime.smsSnapshot().values;}
 static void render(){WifiConfigEditor.smsCenterEntry(((gl5)zl5.b.value).i,composer);}
 static void open(){ak2.actions.clear();ak2.actionLabels.clear();render();check(ak2.actionLabels.size()==1&&ak2.actionLabels.get(0).startsWith("短信中心"),"original SMS position exposes one standalone entry");ak2.actions.get(0).a();render();}
 static void waitSave()throws Exception{long end=System.nanoTime()+2_000_000_000L;while(Handler.tasks.isEmpty()&&System.nanoTime()<end)Thread.sleep(5);check(!Handler.tasks.isEmpty(),"SMS save finishes");Handler.drain();}
 public static void main(String[]args)throws Exception {
  context=new WifiConfigTest.Ctx();zl5.f=context;card=new ek5("001010000000001","sms-entry");card.f=null;
  zl5.b.value=WifiConfigTest.state(card,zl3.r(card));
  WifiConfigRuntime.save(WifiConfigRuntime.cardKey(card),values("smsc",A,"smsc_list",A+"\n"+B,"domain","custom.example.org","imei","490154203237518"));
  ((gl5)zl5.b.value).k.busy=true;xi5 config=((gl5)zl5.b.value).f;Object phase=((gl5)zl5.b.value).k;
  activity=new Activity();lu1.context=activity;
  open();check(xq0.title.equals("短信中心")&&ak2.edits.size()==2,"list opens without first opening the Wi-Fi configuration page");
  check(activity.app.callbacks.size()==1,"standalone editor owns one lifecycle callback");
  String before=record();ak2.edits.get(0).change.i(B);render();ak2.edits.get(0).change.i("");render();ak2.edits.get(0).change.i(C);
  check(record().equals(before)&&((gl5)zl5.b.value).i.equals(A),"typing duplicate, clearing and final replacement are drafts only");
  xq0.press("保存");waitSave();check(saved().get("smsc_list").equals(C+"\n"+B)&&((gl5)zl5.b.value).i.equals(C),"explicit save replaces A with C and keeps the existing B candidate");
  check(((gl5)zl5.b.value).f==config&&((gl5)zl5.b.value).k==phase&&saved().get("domain").equals("custom.example.org")&&saved().get("imei").equals("490154203237518"),"active IMS/config/device fields are unchanged by SMS save");
  check(activity.app.callbacks.isEmpty(),"successful standalone save closes and releases owner");
  open();check(ak2.edits.get(0).value.equals(C)&&ak2.edits.get(1).value.equals(B),"reopen shows both saved entries");
  before=record();ak2.edits.get(0).change.i(A);xq0.cancel.a();check(record().equals(before)&&activity.app.callbacks.isEmpty(),"Cancel discards SMS draft and closes cleanly");
  open();check(ak2.edits.get(0).value.equals(C),"reopen cannot resurrect cancelled edit");
  ak2.press("○ 使用此号码");xq0.press("保存");waitSave();check(((gl5)zl5.b.value).i.equals(B)&&saved().get("smsc_list").equals(C+"\n"+B),"existing candidate can be selected without overwriting the list");
  open();before=record();ak2.edits.get(0).change.i("");xq0.press("保存");render();check(xq0.message!=null&&ak2.edits.get(0).value.isEmpty()&&record().equals(before),"required blank entry stays editable and cannot silently erase candidates");
  ak2.edits.get(0).change.i(A);context.prefs.fail=true;xq0.press("保存");waitSave();render();check(xq0.message.contains("保存失败")&&ak2.edits.get(0).value.equals(A)&&record().equals(before),"storage error preserves text and prior record for retry");
  xq0.press("保存");waitSave();check(saved().get("smsc_list").equals(A+"\n"+B),"retry succeeds with both entries");
  open();ak2.press("删除");render();ak2.press("删除");xq0.press("保存");waitSave();
  check(saved().get("smsc_list").equals("[]")&&((gl5)zl5.b.value).i.isEmpty(),"explicitly deleting every entry persists an empty list");
  WifiConfigTest.rejects(()->WifiConfigRuntime.requireSmsCenter(),"empty SMSC cannot send");passed++;
  open();check(ak2.edits.isEmpty()&&ak2.actionLabels.contains("添加"),"empty list remains reachable from original position");
  ak2.press("添加");render();ak2.edits.get(0).change.i(C);xq0.press("保存");waitSave();WifiConfigRuntime.requireSmsCenter();
  check(((gl5)zl5.b.value).i.equals(C),"saved newly added number enables the existing SMS send guard");
  open();before=record();ak2.edits.get(0).change.i(A);activity.destroy();check(activity.app.callbacks.isEmpty()&&record().equals(before),"destroying the SMS owner drops unfinished input without persistence");
  check(composer.depth==0,"standalone entry and modal groups remain balanced");
  System.out.println("PASS: "+passed+" standalone SMS-center editor, saved candidates and active IMS assertions");
 }
}
