import json,os,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]))
from carrier_presets_patch import expand,domains,STANDARD
BASE=Path(os.environ.get('SIMHUB_BASE_ASSETS','/workspace/recovery/config2-decoded/assets'))
class Presets(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.old=json.loads((BASE/'vowifi/carrier_presets.json').read_text())
  cls.rows=json.loads((BASE/'data/mcc_mnc.json').read_text())
  cls.new,cls.catalogue=expand(cls.old,cls.rows)
 def test_original_preserved(self):
  self.assertEqual(self.old['presets'],self.new['presets'][:len(self.old['presets'])])
  self.assertEqual(self.old['selectorRules'],self.new['selectorRules'][:len(self.old['selectorRules'])])
 def test_coverage(self):
  expected={r[0]+r[1] for r in self.rows if len(r[0])==3 and len(r[1]) in (2,3) and (r[0]+r[1]).isascii() and (r[0]+r[1]).isdigit()}
  self.assertLessEqual(expected,{p['plmn'] for p in self.new['presets']})
  self.assertEqual(len(self.catalogue['entries']),len(expected))
 def test_no_duplicate_generic_templates(self):
  added=self.new['presets'][len(self.old['presets']):]
  self.assertEqual(len(added),2264)
  self.assertEqual(len({p['id'] for p in added}),len(added))
  self.assertEqual(len({p['plmn'] for p in added}),len(added))
  old={p['plmn'] for p in self.old['presets']}
  self.assertFalse(old&{p['plmn'] for p in added})
 def test_generated_match_exact_schema(self):
  keys=set(self.old['presets'][0])
  for p in self.new['presets'][len(self.old['presets']):]:
   self.assertEqual(set(p),keys)
   self.assertIn('未实测',p['bundleName'])
   self.assertEqual(p['localIdentifier'],STANDARD['localIdentifier'])
   self.assertIsNone(p['epdgAddress']);self.assertIsNone(p['imsDomain'])
 def test_dito(self):
  p=next(p for p in self.new['presets'] if p['plmn']=='51566')
  self.assertIn('DITO',p['bundleName'])
  self.assertEqual(domains('515','66')['ims'],'ims.mnc066.mcc515.3gppnetwork.org')
  self.assertEqual(domains('515','66')['epdg'],'epdg.epc.mnc066.mcc515.pub.3gppnetwork.org')
  self.assertNotIn('204',p['localIdentifier'])
 def test_mnc_length_retained(self):
  self.assertEqual(domains('310','260')['ims'],'ims.mnc260.mcc310.3gppnetwork.org')
  self.assertEqual(domains('234','33')['ims'],'ims.mnc033.mcc234.3gppnetwork.org')
  rows=[['310','26','US','A','A'],['310','026','US','B','B']]
  n,_=expand({'presets':[],'selectorRules':[]},rows)
  self.assertEqual({p['plmn'] for p in n['presets']},{'31026','310026'})
 def test_uncertainty_explicit(self):
  for e in self.catalogue['entries']:
   self.assertIsNone(e['wifiCallingSupported']);self.assertFalse(e['deviceVerified'])
 def test_reapply_rejected(self):
  with self.assertRaises(ValueError):expand(self.new,self.rows)
 def test_invalid_plmn(self):
  for mcc,mnc in [('51','66'),('515','6'),('515','0666'),('５１５','66'),('515','xx')]:
   with self.assertRaises(ValueError):domains(mcc,mnc)
if __name__=='__main__':unittest.main(verbosity=2)
