import cc.forserein.simhub.internal.*;
public class IdentityBindingTest {
 public static class Flow {public Object value;public boolean h(Object old,Object next){if(value!=old)return false;value=next;return true;}}
 static int passed;static void check(boolean b){if(!b)throw new AssertionError();passed++;}
 public static class Card {public String a,b;Card(String imsi,String iccid){a=imsi;b=iccid;}public String d(){return a.substring(0,5);}}
 public static class Transport {public String f="SIM2";}
 public static void main(String[]args)throws Exception {
  MultiChipSwitchTest.Profile dito=new MultiChipSwitchTest.Profile("8963660000005526",true);
  MultiChipSwitchTest.Controller c=new MultiChipSwitchTest.Controller(new MultiChipSwitchTest.Chip("8962",dito));
  Transport t=new Transport();IdentityBinding.track(t,c);
  IdentityBinding.read(t,new Object(),new Card("515660000000001",dito.a));check(true);
  try{IdentityBinding.read(t,new Object(),new Card("204040000000023","8900000000006164"));throw new AssertionError();}
  catch(IllegalStateException expected){check(expected.getMessage().contains("不一致"));check(!expected.getMessage().contains(dito.a));}
  IdentityBinding.read(new Transport(),new Object(),new Card("204040000000023","plain"));check(true);
  check(IdentityBinding.identity("0204040000000023@nai.epc.mnc004.mcc204.3gppnetwork.org").equals("020404…@nai.epc.mnc004.mcc204.3gppnetwork.org"));
  check(!IdentityBinding.identity("515660000000001@example.org").contains("000000001"));
  check(IdentityBinding.identity("anonymous@example.org").equals("masked@example.org"));
  check(IdentityBinding.tail(dito.a).equals("…5526"));
  // Capture immutable selection; reject a changed selection instead of silently rebinding.
  Object auth=new Object();IdentityBinding.begin(t,auth);
  c.selected="missing";IdentityBinding.track(t,c);
  try{IdentityBinding.read(t,auth,new Card("515660000000001",dito.a));throw new AssertionError();}catch(IllegalStateException expected){check(expected.getMessage().contains("期间"));}
  Object invalid=new Object();IdentityBinding.begin(t,invalid);
  try{IdentityBinding.read(t,invalid,new Card("204040000000023","other"));throw new AssertionError();}catch(IllegalStateException expected){check(expected.getMessage().contains("确认"));}
  check(IdentityBinding.needsRead(t));check(!IdentityBinding.needsRead(new Transport()));
  c.selected="8962";dito.b=false;IdentityBinding.track(t,c);
  Object disabled=new Object();IdentityBinding.begin(t,disabled);
  try{IdentityBinding.read(t,disabled,new Card("204040000000023","other"));throw new AssertionError();}catch(IllegalStateException expected){check(expected.getMessage().contains("启用配置"));}
  c.selected="8962";dito.b=true;IdentityBinding.track(t,c);Object newest=new Object();IdentityBinding.begin(t,newest);
  check(!IdentityBinding.current(t,auth)&&IdentityBinding.current(t,newest));
  Flow flow=new Flow();Object newValue=new Object();
  check(!IdentityBinding.publish(t,auth,flow,null,newValue)&&flow.value==null);
  check(!IdentityBinding.publishError(t,auth,flow,null,newValue)&&flow.value==null);
  check(IdentityBinding.publish(t,newest,flow,null,newValue)&&flow.value==newValue);
  c.selected="changed";IdentityBinding.track(t,c);
  try{IdentityBinding.publish(t,newest,flow,newValue,new Object());throw new AssertionError();}catch(IllegalStateException expected){check(flow.value==newValue);}
  check(IdentityBinding.publishError(t,newest,flow,newValue,null)&&flow.value==null);
  System.out.println("PASS: "+passed+" identity binding and redaction assertions");
 }
}
