import cc.forserein.simhub.internal.*;
import java.util.*;

public class IdentityBindingTest {
 public static class Flow {public Object value;public boolean h(Object old,Object next){if(value!=old)return false;value=next;return true;}}
 static int passed;static void check(boolean b){if(!b)throw new AssertionError();passed++;}
 public static class Card {public String a,b;Card(String imsi,String iccid){a=imsi;b=iccid;}public String d(){return a.substring(0,5);}}
 public static class Transport {public String f="SIM2";}
 public static class Profile {
  public String a,c,d,e;public boolean b;
  Profile(String iccid,boolean enabled){this(iccid,enabled,null);}
  Profile(String iccid,boolean enabled,String provider){a=iccid;b=enabled;d=provider;}
 }
 public static class Chip {public String b;public List<Profile>d;Chip(String eid,Profile...p){b=eid;d=Arrays.asList(p);}}
 public static class Controller {
  public String selected;public List<Chip> chips;
  Controller(Chip...c){chips=Arrays.asList(c);selected=c.length==0?null:c[0].b;}
  public String r(){return selected;}public List<Chip> l(){return chips;}
 }
 static int nextIccid=1001;
 static String iccid(){return String.format(Locale.ROOT,"89012345001234%05d",nextIccid++);}
 static ek5 physical(String iccid){return new ek5("204049876543210",iccid,2,null,null,null,null,null);}
 static Object begin(Transport transport,Controller controller){IdentityBinding.track(transport,controller);Object auth=new Object();IdentityBinding.begin(transport,auth);return auth;}
 static void notDito(ek5 card)throws Exception {check(!DitoHomeIdentity.isDito(card));check(((xi5)CarrierPresets.defaults(card,null)).c.equals("Vodafone"));}
 static void missingHome(ek5 card)throws Exception {
  try{DitoHomeIdentity.connection(card);throw new AssertionError("provider must not invent home IMSI");}
  catch(IllegalStateException expected){check(expected.getMessage().contains("51566"));}
 }
 static void providerEvidence()throws Exception {
  zl5.f=new DitoHomeIdentityTest.Ctx();
  // Exact physical ICCID, not selected chip or enabled profile, owns the evidence.
  ek5 card=physical(iccid());Profile provider=new Profile(card.b,false," DITO ");
  Controller controller=new Controller(new Chip("selected-other",new Profile(iccid(),true,"Vodafone")),new Chip("read-chip",provider));
  Transport t=new Transport();Object auth=begin(t,controller);notDito(card);
  IdentityBinding.read(t,auth,card);check(DitoHomeIdentity.isDito(card));check(((xi5)CarrierPresets.defaults(card,null)).c.equals("DITO"));
  missingHome(card);check(card.a.equals("204049876543210")&&card.c==2);

  // A legitimate metadata provider is separate from nickname/profileName text.
  card=physical(iccid());provider=new Profile(card.b,true,"Vodafone");provider.c="DITO";provider.e="DITO_51566_005";
  t=new Transport();auth=begin(t,new Controller(new Chip("chip",provider)));IdentityBinding.read(t,auth,card);notDito(card);
  card=physical(iccid());provider=new Profile(iccid(),true,"DITO");provider.c=card.b;
  t=new Transport();auth=begin(t,new Controller(new Chip("chip",provider)));IdentityBinding.read(t,auth,card);notDito(card);

  // All duplicate ICCIDs must agree; differing, absent and empty providers conflict.
  for(String other:new String[]{"Vodafone",null,""}){
   card=physical(iccid());t=new Transport();
   auth=begin(t,new Controller(new Chip("a",new Profile(card.b,true,"DITO")),new Chip("b",new Profile(card.b,false,other))));
   IdentityBinding.read(t,auth,card);notDito(card);
  }
  card=physical(iccid());t=new Transport();auth=begin(t,new Controller(new Chip("a",new Profile(card.b,true,"DITO")),new Chip("b",new Profile(card.b,false," dito "))));
  IdentityBinding.read(t,auth,card);check(DitoHomeIdentity.isDito(card));missingHome(card);

  // Never fill an absent ICCID or normalize malformed metadata into a match.
  for(String invalid:new String[]{"","5526","890123450012345678F","890123450012345678901"," 8901234500123456789"}){
   card=physical(invalid);t=new Transport();auth=begin(t,new Controller(new Chip("chip",new Profile(invalid,true,"DITO"))));
   IdentityBinding.read(t,auth,card);notDito(card);check(card.b.equals(invalid));
  }

  // Evidence is captured before asynchronous reads, never borrowed from a later selection.
  card=physical(iccid());provider=new Profile(card.b,true,"DITO");controller=new Controller(new Chip("old",provider));
  t=new Transport();auth=begin(t,controller);provider.d="Vodafone";provider.a=iccid();controller.chips=Collections.emptyList();IdentityBinding.track(t,controller);
  IdentityBinding.read(t,auth,card);check(DitoHomeIdentity.isDito(card));missingHome(card);
  card=physical(iccid());provider=new Profile(card.b,true,"Vodafone");controller=new Controller(new Chip("old",provider));
  t=new Transport();auth=begin(t,controller);provider.d="DITO";IdentityBinding.track(t,controller);
  IdentityBinding.read(t,auth,card);notDito(card);

  // No begin, wrong transport, and metadata arriving after begin provide no authority.
  card=physical(iccid());t=new Transport();controller=new Controller(new Chip("chip",new Profile(card.b,true,"DITO")));
  IdentityBinding.track(t,controller);IdentityBinding.read(t,new Object(),card);notDito(card);
  card=physical(iccid());t=new Transport();auth=begin(t,new Controller(new Chip("chip",new Profile(card.b,true,"DITO"))));
  IdentityBinding.read(new Transport(),auth,card);notDito(card);
  card=physical(iccid());t=new Transport();auth=new Object();IdentityBinding.begin(t,auth);
  IdentityBinding.track(t,new Controller(new Chip("chip",new Profile(card.b,true,"DITO"))));IdentityBinding.read(t,auth,card);notDito(card);

  card=physical(iccid());t=new Transport();auth=begin(t,new Controller(new Chip("chip",new Profile(card.b,true,"DITO"))));
  IdentityBinding.begin(t,new Object());
  try{IdentityBinding.read(t,auth,card);throw new AssertionError("stale provider evidence accepted");}
  catch(IllegalStateException expected){check(expected.getMessage().contains("过期"));}notDito(card);
 }
 public static void main(String[]args)throws Exception {
  Profile dito=new Profile("8963660000005526",true);
  Controller c=new Controller(new Chip("8962",dito));
  Transport t=new Transport();IdentityBinding.track(t,c);
  Card actual=new Card("515660000000001",dito.a);
  IdentityBinding.read(t,new Object(),actual);check(true);
  // The management page may show another profile; only the USIM read owns authentication identity.
  Card other=new Card("204040000000023","8900000000006164");
  IdentityBinding.read(t,new Object(),other);check(other.a.equals("204040000000023"));
  check(other.b.equals("8900000000006164"));
  IdentityBinding.read(new Transport(),new Object(),new Card("204040000000023","plain"));check(true);
  check(IdentityBinding.identity("0204040000000023@nai.epc.mnc004.mcc204.3gppnetwork.org").equals("020404…@nai.epc.mnc004.mcc204.3gppnetwork.org"));
  check(!IdentityBinding.identity("515660000000001@example.org").contains("000000001"));
  check(IdentityBinding.identity("anonymous@example.org").equals("masked@example.org"));
  check(IdentityBinding.tail(dito.a).equals("…5526"));
  Object auth=new Object();IdentityBinding.begin(t,auth);
  // A UI selection change is not a new USIM read and must not invalidate a valid result.
  c.selected="missing";IdentityBinding.track(t,c);
  IdentityBinding.read(t,auth,actual);check(true);
  Object missing=new Object();IdentityBinding.begin(t,missing);
  IdentityBinding.read(t,missing,other);check(true);
  check(IdentityBinding.needsRead(t));check(!IdentityBinding.needsRead(new Transport()));
  // Empty / disabled / multiple-enabled / unavailable management lists must not block Wi-Fi Calling.
  c.selected="8962";dito.b=false;IdentityBinding.track(t,c);
  Object disabled=new Object();IdentityBinding.begin(t,disabled);
  IdentityBinding.read(t,disabled,actual);check(true);
  c.chips=Arrays.asList(new Chip("8962",new Profile("a",true),new Profile("b",true)));
  IdentityBinding.track(t,c);Object ambiguous=new Object();IdentityBinding.begin(t,ambiguous);
  IdentityBinding.read(t,ambiguous,actual);check(true);
  IdentityBinding.track(t,new Controller());Object empty=new Object();IdentityBinding.begin(t,empty);
  IdentityBinding.read(t,empty,actual);check(true);
  IdentityBinding.track(t,new Object());Object unavailable=new Object();IdentityBinding.begin(t,unavailable);
  IdentityBinding.read(t,unavailable,actual);check(true);
  check(IdentityBinding.needsRead(t));
  // A newer read still supersedes late completions from the previous read.
  Object newest=new Object();IdentityBinding.begin(t,newest);
  check(!IdentityBinding.current(t,auth)&&IdentityBinding.current(t,newest));
  try{IdentityBinding.read(t,unavailable,other);throw new AssertionError();}
  catch(IllegalStateException expected){check(expected.getMessage().contains("过期"));}
  Flow flow=new Flow();Object newValue=new Object();
  check(!IdentityBinding.publish(t,unavailable,flow,null,newValue)&&flow.value==null);
  check(!IdentityBinding.publishError(t,unavailable,flow,null,newValue)&&flow.value==null);
  check(IdentityBinding.publish(t,newest,flow,null,newValue)&&flow.value==newValue);
  c.selected="changed";IdentityBinding.track(t,c);
  Object afterSelection=new Object();
  check(IdentityBinding.publish(t,newest,flow,newValue,afterSelection)&&flow.value==afterSelection);
  check(!IdentityBinding.publish(t,newest,flow,newValue,new Object())&&flow.value==afterSelection);
  check(IdentityBinding.publishError(t,newest,flow,afterSelection,null)&&flow.value==null);
  Transport second=new Transport();IdentityBinding.begin(second,new Object());
  check(IdentityBinding.current(t,newest));
  check(actual.a.equals("515660000000001")&&actual.b.equals("8963660000005526"));
  providerEvidence();
  System.out.println("PASS: "+passed+" USIM generation, management-cache regression and redaction assertions");
 }
}
