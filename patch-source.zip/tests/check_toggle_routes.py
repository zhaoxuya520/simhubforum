#!/usr/bin/env python3
"""Ensure both original UI switch entries coordinate all chips and the obsolete banner is skipped."""
from pathlib import Path
import sys
r=Path(sys.argv[1])
for name in ('sj.smali','cg0.smali'):
 s=(r/'smali'/name).read_text()
 assert s.count('LInternalSimMultiChipSwitch;-><init>(Liz3;Lqy3;ZLct0;)V')==1,name
 assert 'Lhz3;-><init>' not in s,name
# Detect an additional uncoordinated original constructor call, not just the two known entries.
for p in (r/'smali').glob('*.smali'):
 if p.name not in ('hz3.smali','InternalSimMultiChipSwitch.smali'):
  assert 'Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V' not in p.read_text(),p.name
s=(r/'smali/fd2.smali').read_text();end=s.index('    const-string v3, "vowifi_sms_profile_mismatch"')
assert s.rfind('    goto/16 :cond_14',0,end)>s.rfind('    if-eqz v25, :cond_14',0,end)
for lang in ('zh-Hans','zh-Hant'):
 assert '"vowifi_sms_profile_mismatch" = "";' in (r/f'assets/i18n/{lang}.strings').read_text()
print('PASS: both original toggle routes coordinate; no alternate original switch bypass; obsolete USIM banner removed')
