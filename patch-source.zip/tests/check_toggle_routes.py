#!/usr/bin/env python3
"""Static native switch UI dataflow checks; not a rendering/hardware test."""
from pathlib import Path
import re
import sys


def instructions(text):
    return '\n'.join(line.strip() for line in text.splitlines()
                     if line.strip() and not line.strip().startswith(('.line ', '#')))


def method(text, signature):
    matches = re.findall(r'^\.method [^\n]* ' + re.escape(signature)
                         + r'\n(.*?)^\.end method', text, re.M | re.S)
    assert len(matches) == 1, signature
    return instructions(matches[0])


def contains(text, block, label):
    assert instructions(block) in text, label


def verify_ui_routes(texts):
    """Preserve requested false/off, common guarded entry and readback state."""
    constructor = 'Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V'
    for name in ('sj', 'cg0'):
        assert texts[name].count(constructor) == 1, name
        assert 'InternalSimMultiChipSwitch' not in texts[name], name
    for name in ('c4', 'yc0', 'px3', 'sj', 'qf0', 'cg0', 'pf0', 'bf0', 'ga2', 'd0'):
        assert not re.search(r'iput-boolean[^\n]*Lqy3;->b:Z', texts[name]), name

    c4 = method(texts['c4'], 'i(Ljava/lang/Object;)Ljava/lang/Object;')
    contains(c4, '''check-cast v0, Ljava/lang/Boolean;
        invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
        move-result v6
        invoke-static/range {v1 .. v6}, Lpx3;->g(Lm83;Lm83;Lm83;Lqy3;Liz3;Z)V''',
        'list forwards requested true AND false without replacing/inverting it')
    entry = method(texts['px3'], 'g(Lm83;Lm83;Lm83;Lqy3;Liz3;Z)V')
    contains(entry, '''invoke-interface {p0}, Lot4;->getValue()Ljava/lang/Object;
        move-result-object v0
        check-cast v0, Ljava/lang/String;
        if-nez v0, :cond_2
        iget-boolean v0, p3, Lqy3;->b:Z
        if-ne p5, v0, :cond_0
        goto :goto_0''', 'list pending/no-change gate precedes switch request')
    contains(entry, '''move-object v5, p3
        move-object v3, p4
        move v7, p5
        iget-object p0, v5, Lqy3;->a:Ljava/lang/String;
        invoke-interface {v2, p0}, Lm83;->setValue(Ljava/lang/Object;)V
        iget-object p0, v3, Liz3;->b:Lat0;
        move-object v6, v4
        move-object v4, v5
        move v5, v7
        move-object v7, v2
        new-instance v2, Lsj;
        const/4 v8, 0x0
        invoke-direct/range {v2 .. v8}, Lsj;-><init>(Liz3;Lqy3;ZLm83;Lm83;Lct0;)V''',
        'list passes original target and desired state to coroutine')
    nf0 = method(texts['nf0'], 'a()Ljava/lang/Object;')
    contains(nf0, '''iget-boolean v11, p0, Lnf0;->U:Z
        invoke-static/range {v6 .. v11}, Lpx3;->g(Lm83;Lm83;Lm83;Lqy3;Liz3;Z)V''',
        'Wi-Fi confirmation resumes original list request including off')
    sj_ctor = method(texts['sj'], '<init>(Liz3;Lqy3;ZLm83;Lm83;Lct0;)V')
    assert 'iput-boolean p3, p0, Lsj;->Z:Z' in sj_ctor, 'list stores desired state'
    sj = method(texts['sj'], 'q(Ljava/lang/Object;)Ljava/lang/Object;')
    contains(sj, '''iget-boolean p1, p0, Lsj;->Z:Z
        iput v9, p0, Lsj;->Y:I
        new-instance v0, Lhz3;
        invoke-direct {v0, v6, v4, p1, v11}, Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V
        invoke-virtual {v6, v0, p0}, Liz3;->C(Lkt1;Ldt0;)Ljava/lang/Object;''',
        'list on/off uses common guarded switch entry')
    contains(sj, '''move-result p1
        if-nez p1, :cond_c
        invoke-virtual {v6}, Liz3;->o()Ljava/lang/String;''',
        'list displays backend failure instead of treating it as success')
    assert 'const-string p0, "card_reader_toggle_failed"' in sj, 'fallback error stays localized'
    contains(sj, ''':cond_d
        :goto_7
        invoke-interface {v5, v11}, Lm83;->setValue(Ljava/lang/Object;)V''',
        'list pending marker clears after normal success or handled failure')

    yc0 = method(texts['yc0'], 'i(Ljava/lang/Object;)Ljava/lang/Object;')
    contains(yc0, '''check-cast v1, Ljava/lang/Boolean;
        invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z
        move-result v19
        invoke-virtual/range {v17 .. v17}, Liz3;->u()Z
        move-result v1
        if-eqz v1, :cond_6
        goto :goto_3
        :cond_6
        new-instance v16, Lqf0;
        iget-boolean v0, v0, Lyc0;->U:Z
        move/from16 v20, v0
        invoke-direct/range {v16 .. v22}, Lqf0;-><init>(Liz3;Lqy3;ZZLws1;Lus1;)V''',
        'details busy gate and original desired Boolean including manual off')
    contains(yc0, '''invoke-interface {v8, v0}, Lm83;->setValue(Ljava/lang/Object;)V
        goto :goto_3
        :cond_7
        invoke-virtual {v0}, Lqf0;->a()Ljava/lang/Object;''',
        'details confirmation and immediate path use same request')
    qf0 = method(texts['qf0'], 'a()Ljava/lang/Object;')
    assert 'iget-boolean v3, p0, Lqf0;->V:Z' in qf0, 'details desired field preserved'
    assert 'invoke-direct/range {v0 .. v7}, Lcg0;-><init>(Liz3;Lqy3;ZZLws1;Lus1;Lct0;)V' in qf0
    cg0_ctor = method(texts['cg0'], '<init>(Liz3;Lqy3;ZZLws1;Lus1;Lct0;)V')
    assert 'iput-boolean p3, p0, Lcg0;->b0:Z' in cg0_ctor, 'details stores desired state'
    cg0 = method(texts['cg0'], 'q(Ljava/lang/Object;)Ljava/lang/Object;')
    contains(cg0, '''iget-boolean v3, p0, Lcg0;->b0:Z
        invoke-direct {p1, v4, v0, v3, v1}, Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V
        invoke-virtual {v4, p1, p0}, Liz3;->C(Lkt1;Ldt0;)Ljava/lang/Object;''',
        'details on/off uses common guarded switch entry')
    contains(cg0, ''':goto_2
        if-eqz v0, :cond_5
        invoke-virtual {v4}, Liz3;->o()Ljava/lang/String;
        move-result-object p1
        if-nez p1, :cond_5
        iget-object p0, p0, Lcg0;->e0:Lus1;
        invoke-interface {p0}, Lus1;->a()Ljava/lang/Object;''',
        'details closes only after success with no backend error')

    d0 = method(texts['d0'], 'i(Ljava/lang/Object;)Ljava/lang/Object;')
    contains(d0, '''check-cast v2, Ljava/lang/String;
        invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
        invoke-virtual {v1, v2}, Liz3;->D(Ljava/lang/String;)V
        new-instance v2, Lwf0;''', 'chip tab selects/reads instead of implicit enable/disable')
    assert constructor not in d0 and 'Lhh1;->v(' not in d0, 'chip selection has no profile command'
    ga2 = method(texts['ga2'], 'a(Ljava/util/List;Ljava/lang/String;ZLws1;Llu1;I)V')
    contains(ga2, '''check-cast v4, Lxx3;
        iget-object v4, v4, Lxx3;->d:Ljava/util/List;''', 'chip subtitle reads its profile list')
    contains(ga2, '''check-cast v6, Lqy3;
        iget-boolean v6, v6, Lqy3;->b:Z
        if-eqz v6, :cond_14''', 'chip subtitle uses readback enabled flag')
    assert 'card_reader_chip_none_enabled' in ga2, 'no-enabled chip presentation preserved'


def mutation_checks(texts):
    """Catch regressions even if both hz3 constructor names remain unchanged."""
    cases = [
        ('sj', 'iget-boolean p1, p0, Lsj;->Z:Z', 'const/4 p1, 0x1'),
        ('cg0', 'iget-boolean v3, p0, Lcg0;->b0:Z', 'const/4 v3, 0x1'),
        ('yc0', 'move-result v19', 'const/16 v19, 0x1'),
        ('cg0', 'if-eqz v0, :cond_5', 'if-nez v0, :cond_5'),
        ('sj', 'invoke-interface {v5, v11}, Lm83;->setValue(Ljava/lang/Object;)V', 'nop'),
        ('ga2', 'iget-boolean v6, v6, Lqy3;->b:Z', 'const/4 v6, 0x1'),
    ]
    for name, old, new in cases:
        assert old in texts[name], (name, old)
        changed = dict(texts)
        changed[name] = texts[name].replace(old, new)
        try:
            verify_ui_routes(changed)
        except AssertionError:
            continue
        raise AssertionError('missed UI mutation: ' + name + ' ' + old)
    return len(cases)


def main():
    root = Path(sys.argv[1])
    names = ('sj', 'cg0', 'c4', 'yc0', 'px3', 'nf0', 'qf0', 'pf0', 'bf0', 'ga2', 'd0')
    texts = {name: (root / 'smali' / (name + '.smali')).read_text() for name in names}
    verify_ui_routes(texts)
    negative_count = mutation_checks(texts)
    # The new eSTK coordinator lives at hz3, not these historical adapters.
    for path in (root / 'smali').glob('*.smali'):
        text = path.read_text()
        assert 'LInternalSimMultiChipSwitch;' not in text, path.name
        assert 'LInternalSimSwitchRequest;' not in text, path.name
    text = (root / 'smali/fd2.smali').read_text()
    end = text.index('    const-string v3, "vowifi_sms_profile_mismatch"')
    assert text.rfind('    goto/16 :cond_14', 0, end) > text.rfind('    if-eqz v25, :cond_14', 0, end)
    for lang in ('zh-Hans', 'zh-Hant'):
        assert '"vowifi_sms_profile_mismatch" = "";' in (root / f'assets/i18n/{lang}.strings').read_text()
    print('PASS: native list/details preserve requested on/off, busy/error gates, confirmation and readback; '
          + str(negative_count) + ' UI mutations rejected; obsolete adapters/banner absent')


if __name__ == '__main__':
    main()
