import cc.forserein.simhub.internal.AmrFraming;
import java.util.*;

/** Independently packed RFC 4867 vectors; no live subscriber/audio data. */
public class AmrFramingTest {
 static int passed;
 static final int[] NB={95,103,118,134,148,159,204,244,39},WB={132,177,253,285,317,365,397,461,477,40};
 static void check(boolean ok,String what){if(!ok)throw new AssertionError(what);passed++;}
 static String bin(int v,int count){String s=Integer.toBinaryString(v);return "0000000000000000".substring(0,count-s.length())+s;}
 public static byte[] speech(boolean wide,int type,int seed){
  int bits=type<(wide?WB:NB).length?(wide?WB:NB)[type]:0;
  byte[] out=new byte[(bits+7)/8];new Random(seed).nextBytes(out);
  if(bits%8!=0)out[out.length-1]&=(byte)(0xff<<(8-bits%8));return out;
 }
 public static byte[] packet(boolean wide,boolean aligned,int[] types,int seed){
  StringBuilder b=new StringBuilder(aligned?"11110000":"1111");
  for(int i=0;i<types.length;i++)b.append(i+1<types.length?'1':'0').append(bin(types[i],4)).append('1').append(aligned?"00":"");
  for(int i=0;i<types.length;i++){
   int type=types[i],bits=type<(wide?WB:NB).length?(wide?WB:NB)[type]:0;
   byte[] speech=speech(wide,type,seed+i);
   int length=aligned?speech.length*8:bits;
   for(int k=0;k<length;k++)b.append((speech[k/8]>>>(7-k%8))&1);
  }
  while(b.length()%8!=0)b.append('0');byte[] out=new byte[b.length()/8];
  for(int i=0;i<out.length;i++)out[i]=(byte)Integer.parseInt(b.substring(i*8,i*8+8),2);
  return out;
 }
 public static void main(String[]args){
  for(boolean wide:new boolean[]{false,true})for(boolean aligned:new boolean[]{false,true}){
   int[] sizes=wide?WB:NB;
   for(int mode=0;mode<sizes.length;mode++){
    byte[] p=packet(wide,aligned,new int[]{mode},mode+71);
    check(AmrFraming.shape(p,wide,aligned)>=0,"all speech/SID types "+wide+"/"+aligned+"/"+mode);
    AmrFraming f=new AmrFraming(wide?16000:8000,aligned);
    check(f.receive(p)==(aligned?1:0)&&f.isOctetAligned()==aligned&&f.takeNotice()==null,"normal traffic retains SDP");
    check(AmrFraming.shape(Arrays.copyOf(p,p.length-1),wide,aligned)<0,"truncated frame rejected");
    check(AmrFraming.shape(Arrays.copyOf(p,p.length+1),wide,aligned)<0,"trailing bytes rejected");
   }
   int[] modes=new int[12];for(int i=0;i<modes.length;i++)modes[i]=i%sizes.length;
   check(AmrFraming.shape(packet(wide,aligned,modes,33),wide,aligned)>0,"twelve interleaved ToCs then speech blocks");
   check(AmrFraming.shape(packet(wide,aligned,new int[13],33),wide,aligned)<0,"native twelve-frame bound");
   check(AmrFraming.shape(packet(wide,aligned,new int[]{0,15,sizes.length-1},7),wide,aligned)>0,"speech with NO_DATA and SID");
   byte[] reserved=packet(wide,aligned,new int[]{0},98);reserved[0]&=15;reserved[0]|=(byte)0xb0;
   if(aligned){reserved[0]|=15;reserved[1]|=3;}
   reserved[reserved.length-1]|=1;
   check(AmrFraming.shape(reserved,wide,aligned)>=0,"ignore reserved CMR/reserved/padding bits per RFC");
   check(AmrFraming.shape(packet(wide,aligned,new int[]{wide?10:9},0),wide,aligned)<0,"reserved frame type rejected");
   check(AmrFraming.shape(packet(wide,aligned,new int[]{14},0),wide,aligned)==(wide?0:-1),"WB SPEECH_LOST, NB reserved");
   check(AmrFraming.shape(packet(wide,aligned,new int[]{15},0),wide,aligned)==0,"NO_DATA");
  }
  byte[] compact=packet(true,false,new int[]{2},3);
  check(compact.length+12==45,"matches observed first RTP length with basic RTP header");
  check(AmrFraming.shape(compact,true,true)<0&&AmrFraming.shape(compact,true,false)==1,"45B WB frame disambiguates BE from declared OA");
  AmrFraming f=new AmrFraming(16000,true);
  check(f.receive(compact)==0&&f.isOctetAligned(),"first validated alternate decoded without changing send");
  check(f.receive(compact)==0&&f.isOctetAligned(),"two packets do not change send");
  check(f.receive(compact)==0&&!f.isOctetAligned(),"three verified alternate speech packets change send");
  check(f.takeNotice().contains("bandwidth-efficient")&&f.takeNotice()==null,"one log per change, no speech bytes");
  f.updateNegotiation(true);check(!f.isOctetAligned(),"repeated final SDP retains detected mode");
  f.updateNegotiation(false);check(!f.isOctetAligned(),"changed SDP resets to new mode");
  f.updateNegotiation(true);check(f.isOctetAligned(),"new offer can return to OA");
  f.receive(compact);f.receive(compact);f.receive(new byte[]{0});f.receive(compact);
  check(f.isOctetAligned(),"malformed packet breaks mismatch streak");
  byte[] aligned=packet(true,true,new int[]{2},9);f.receive(aligned);f.receive(compact);f.receive(compact);
  check(f.isOctetAligned(),"valid negotiated packet breaks mismatch streak");
  f.receive(compact);check(!f.isOctetAligned(),"detection resumes after interruptions");
  f.receive(aligned);f.receive(aligned);f.receive(aligned);
  check(f.isOctetAligned(),"remote can switch back after three verified packets");
  AmrFraming other=new AmrFraming(16000,true);check(other.isOctetAligned(),"next call is independent");
  for(int i=0;i<30;i++)other.receive(packet(true,false,new int[]{9},i));
  check(other.isOctetAligned(),"SID packets alone do not change outgoing speech");
  check(other.receive(null)==-1&&other.receive(new byte[0])==-1,"empty payloads rejected");
  check(other.receive(new byte[1025])==-1,"oversized payload bounded");
  byte[] endless=new byte[14];Arrays.fill(endless,(byte)0x84);endless[0]=(byte)0xf0;
  check(AmrFraming.shape(endless,true,true)<0,"unterminated ToC rejected");
  AmrFraming tracked=new AmrFraming(16000,true);
  for(int i=0;i<9;i++)check(tracked.receive(compact,200,17)==0,"repeated valid frame remains decodable");
  check(tracked.isOctetAligned()&&tracked.takeNotice()==null,"duplicate RTP cannot meet three-packet confidence threshold");
  tracked.receive(compact,199,17);tracked.receive(compact,198,17);
  check(tracked.isOctetAligned(),"late packets cannot change transmit framing");
  tracked.receive(compact,201,17);tracked.receive(compact,202,17);
  check(!tracked.isOctetAligned(),"three distinct advancing packets confirm framing");
  tracked.receive(compact,1,18);
  check(tracked.isOctetAligned()&&tracked.takeNotice()==null,"new SSRC cannot inherit previous peer's framing");
  tracked.receive(compact,2,18);tracked.receive(compact,3,18);
  check(!tracked.isOctetAligned(),"new SSRC can independently confirm alternate format");
  tracked.receive(compact,65534,19);tracked.receive(compact,65535,19);tracked.receive(compact,0,19);
  check(!tracked.isOctetAligned(),"RTP sequence wrap still provides distinct evidence");
  tracked.receive(compact,5,20);tracked.receive(compact,7,20);
  check(tracked.isOctetAligned(),"missing sequence breaks consecutive confirmation");
  tracked.receive(compact,8,20);tracked.receive(compact,9,20);
  check(!tracked.isOctetAligned(),"confirmation resumes after packet loss");
  tracked.updateNegotiation(false);tracked.updateNegotiation(true);
  tracked.receive(compact,9,20);tracked.receive(compact,10,20);tracked.receive(compact,11,20);
  check(!tracked.isOctetAligned(),"changed SDP resets old sequence tracking");
  Random random=new Random(9182);
  for(int i=0;i<4000;i++){
   byte[] noise=new byte[random.nextInt(1100)];random.nextBytes(noise);
   int outcome=other.receive(noise);check(outcome>=-1&&outcome<=1,"bounded arbitrary input");
  }
  System.out.println("PASS: "+passed+" AMR framing assertions");
 }
}
