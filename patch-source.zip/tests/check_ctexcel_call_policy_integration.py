#!/usr/bin/env python3
"""Verify initial INVITE-only anchors and exact original builder restoration."""
import argparse, hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ctexcel_call_policy_patch import verify_ctexcel_call_policy, reverse_ctexcel_call_policy, EDITS, _method
p = argparse.ArgumentParser()
p.add_argument('decoded', type=Path)
p.add_argument('--report', type=Path)
a = p.parse_args()
smali = a.decoded/'smali' if (a.decoded/'smali').is_dir() else a.decoded
report = verify_ctexcel_call_policy(smali)
text = (smali/'f82.smali').read_text()
original = reverse_ctexcel_call_policy('f82.smali', text)
assert reverse_ctexcel_call_policy('f82.smali', original) == original
for old, new in EDITS:
    try:
        reverse_ctexcel_call_policy('f82.smali', text.replace(new, old, 1))
    except AssertionError:
        pass
    else:
        raise AssertionError('incomplete CTExcel hook accepted')
try:
    reverse_ctexcel_call_policy('f82.smali', original+'\n# ctexcel_call_policy_orphan\n')
except AssertionError:
    pass
else:
    raise AssertionError('orphan hook accepted')
body = _method(text)[2]
assert body.index('CtExcelCallPolicy;->destination') < body.index('invoke-static {v2, v1}, Ljb4;->d')
assert body.index('CtExcelCallPolicy;->callerIdentity') < body.index('invoke-direct/range {v13 .. v25}, Lma4;-><init>')
assert body.index('CtExcelCallPolicy;->decorate') > body.index('iput-object v5, v3, Lkb4;->g:[B')
assert body.index('CtExcelCallPolicy;->decorate') < body.index('iput-object v3, v13, Lma4;->j:Lkb4;')
assert text.count('Lu10;->b(Ljava/lang/String;Ljava/lang/String;)Z') == original.count('Lu10;->b(Ljava/lang/String;Ljava/lang/String;)Z') == 1
report['complete_coroutine_class_restored'] = True
report['original_destination_policy_call_retained'] = True
report['partial_orphan_hooks_rejected'] = True
report['helper_source_sha256'] = hashlib.sha256((ROOT/'src/cc/forserein/simhub/internal/CtExcelCallPolicy.java').read_bytes()).hexdigest()
if a.report:
    a.report.write_text(json.dumps(report, indent=2)+'\n')
print('PASS: bounded CTExcel initial INVITE hooks and unchanged complete native coroutine')
