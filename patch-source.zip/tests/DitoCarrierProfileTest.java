import cc.forserein.simhub.internal.*;
import java.util.*;

public class DitoCarrierProfileTest {
 static int passed;static void check(boolean b,String text){if(!b)throw new AssertionError(text);passed++;}
 public static void main(String[]args)throws Exception {
  zl5.f=new DitoHomeIdentityTest.Ctx();
  ek5 raw=new ek5("204049876543210","8963668800123455526");
  check(zl3.r(raw).c.equals("Vodafone"),"regression input reproduces original native Vodafone selection");
  xi5 p=(xi5)CarrierPresets.defaults(raw,Collections.<String,String>emptyMap());
  check(p.c.equals("DITO")&&p.b.equals("apple_dito_ph")&&p.a==lj5.U,"automatic DITO chooses dedicated preset, not a relabelled generic template");
  check(p.d.equals("515")&&p.e.equals("66")&&p.g.equals("ims.mnc066.mcc515.3gppnetwork.org"),"home PLMN and IMS realm match reference");
  check(p.i==ak5.U&&p.h.equals("ims")&&p.t&&p.u==1300&&!p.v,"reference IPv4/APN/IPsec/UDP settings");
  check(p.j.equals(Arrays.asList("aes128"))&&p.k.equals(Arrays.asList("sha1"))&&p.l.equals(Arrays.asList("sha1"))&&p.m.equals(Arrays.asList("modp1024")),"reference IKE algorithms exact");
  check(p.n.equals(Arrays.asList("aes128"))&&p.o.equals(Arrays.asList("sha1")),"reference ESP algorithms exact");
  check(p.p==20&&!p.q&&p.x.equals(Arrays.asList(20,21,16384,16386)),"keepalive, DPD and all four P-CSCF attributes match reference");
  yj5 quirks=(yj5)p.z;
  check(quirks.q.equals(7200)&&quirks.a&&quirks.m,"7200-second REGISTER expiry with normal PANI defaults");
  check(!quirks.u&&!quirks.n&&!quirks.r&&!quirks.v&&!quirks.w,"unrelated carrier/ISIM/authorization quirks remain disabled");
  check(p.r.equals("0"+raw.a+"@nai.epc.mnc004.mcc204.3gppnetwork.org")&&p.s.equals(raw.a+"@ims.mnc066.mcc515.3gppnetwork.org"),"EAP uses actual card PLMN and IMS retains DITO realm without inventing a home subscriber");
  check(p.y.equals(p.r)&&p.A==null,"permanent EAP is separately bound to real card identity, public identity remains automatic");
  ArrayList<WifiConfigTest.Transform> proposals=WifiConfigTest.ike();WifiConfigModel.restrictIke(p,proposals);
  check(proposals.size()==4&&proposals.get(0).c.equals(128)&&proposals.get(1).b==2&&proposals.get(2).b==2&&proposals.get(3).b==2,"native extra IKE alternatives do not override DITO's dedicated profile");
  ArrayList<WifiConfigTest.Transform> esp=new ArrayList<>(Arrays.asList(new WifiConfigTest.Transform(1,12,256),new WifiConfigTest.Transform(1,12,128),new WifiConfigTest.Transform(3,12,null),new WifiConfigTest.Transform(3,2,null),new WifiConfigTest.Transform(5,0,null)));
  WifiConfigModel.restrictEsp(p,esp);check(esp.size()==3&&esp.get(0).c.equals(128)&&esp.get(1).b==2,"native ESP restricted to DITO algorithms, retaining ESN metadata");
  List<WifiConfigTest.Family> families=Arrays.asList(new WifiConfigTest.Family("dual"),new WifiConfigTest.Family("ipv6"),new WifiConfigTest.Family("ipv4"));
  check(WifiConfigModel.addressFamilies(p,families).equals(Collections.singletonList(families.get(2))),"automatic DITO IPv4 is respected, not only explicit custom IP");
  xi5 changed=(xi5)WifiConfigModel.merge(p,WifiConfigTest.values("domain","mine.example.org"));
  check(WifiConfigModel.addressFamilies(changed,families).equals(Collections.singletonList(families.get(2))),"editing an unrelated field retains DITO IPv4 preference");
  xi5 dual=(xi5)WifiConfigModel.merge(p,WifiConfigTest.values("ip","dual"));
  check(WifiConfigModel.addressFamilies(dual,families)==families,"user can still override DITO IP settings");
  xi5 custom=(xi5)WifiConfigModel.merge(p,WifiConfigTest.values("ike_encr","aes256","keepalive","45","nai","mine@nai.example.org"));
  check(custom.j.equals(Arrays.asList("aes256"))&&custom.p==45&&custom.r.equals("mine@nai.example.org"),"explicit user edits override dedicated defaults");
  check(custom.y.equals(p.y),"changing only outer NAI cannot replace the real permanent EAP identity");
  check(CarrierPresets.find(DitoCarrierProfile.LEGACY_KEY).key.equals(DitoCarrierProfile.KEY)&&CarrierPresets.sameSelection(DitoCarrierProfile.LEGACY_KEY,DitoCarrierProfile.KEY),"saved legacy DITO selection resolves and remains selected in picker");
  check(!CarrierPresets.sameSelection(DitoCarrierProfile.KEY,null)&&!CarrierPresets.sameSelection(DitoCarrierProfile.KEY,"20404|apple_vodafone_nl"),"legacy alias does not collapse other carrier or automatic choices");
  ek5 home=new ek5("515660123456789",raw.b);DitoHomeIdentity.observe(home);
  xi5 restored=(xi5)CarrierPresets.defaults(raw,null);
  check(restored.r.startsWith("0"+home.a+"@")&&restored.s.startsWith(home.a+"@"),"all DITO identities consistently use saved home subscriber");
  check(((ek5)DitoHomeIdentity.connection(raw)).a.equals(home.a)&&raw.a.equals("204049876543210"),"native connection receives home copy and physical identity stays unchanged");
  DitoHomeIdentity.readStatus(raw);check(zl5.lastLog.contains("DITO 已识别")&&zl5.lastLog.contains("已恢复")&&!zl5.lastLog.contains(home.a),"existing log reports restored DITO without leaking full IMSI");
  // Automatic identification should remain usable even when the picker catalogue is unavailable.
  fj5.presets.remove(fj5.DITO);fj5.presets.remove(fj5.VARIANT);
  xi5 independent=(xi5)CarrierPresets.defaults(raw,null);
  check(independent.c.equals("DITO")&&independent.b.equals("apple_dito_ph")&&independent.r.startsWith("0"+home.a+"@"),"automatic DITO does not depend on picker lookup or silently revert to Vodafone");
  ek5 ordinary=new ek5(raw.a,"8948011234567890123");xi5 untouched=(xi5)CarrierPresets.defaults(ordinary,null);
  check(untouched.c.equals("Vodafone")&&untouched.i==ak5.V,"ordinary Vodafone profile unaffected");
  System.out.println("PASS: "+passed+" DITO reference profile, negotiation, native expiry, overrides and regression assertions");
 }
}
