package android.telephony;
import java.util.*;
/** Synthetic public-API boundary; no Android service or SIM access. */
public class SubscriptionManager {
    public static final int INVALID_SIM_SLOT_INDEX = -1;
    public static final int PHONE_NUMBER_SOURCE_UICC=1, PHONE_NUMBER_SOURCE_CARRIER=2, PHONE_NUMBER_SOURCE_IMS=3;
    public List<SubscriptionInfo> active = new ArrayList<>();
    public List<SubscriptionInfo> laterActive;
    public RuntimeException activeError;
    public int activeCalls;
    public final Map<String,String> numbers = new HashMap<>();
    public final Map<String,RuntimeException> errors = new HashMap<>();
    public final List<String> calls = new ArrayList<>();
    public List<SubscriptionInfo> getActiveSubscriptionInfoList() {
        activeCalls++; if(activeError!=null)throw activeError;
        return activeCalls>1&&laterActive!=null?laterActive:active;
    }
    public List<SubscriptionInfo> getCompleteActiveSubscriptionInfoList() {
        return getActiveSubscriptionInfoList();
    }
    public String getPhoneNumber(int id,int source) {
        if(source!=PHONE_NUMBER_SOURCE_CARRIER&&source!=PHONE_NUMBER_SOURCE_IMS)
            throw new AssertionError("Unexpected UICC/default number source");
        if(id<0||id==Integer.MAX_VALUE)throw new AssertionError("Default/invalid subscription requested");
        String key=id+":"+source;calls.add(key);
        if(errors.containsKey(key))throw errors.get(key);
        return numbers.containsKey(key)?numbers.get(key):"";
    }
}
