package android.telephony;

import java.util.*;
public final class UiccCardInfo {
    private final int physical, card;
    private final Collection<UiccPortInfo> ports;
    public UiccCardInfo(int physical, int card, UiccPortInfo... ports) {
        this.physical=physical;this.card=card;this.ports=Arrays.asList(ports);
    }
    public int getPhysicalSlotIndex(){return physical;}
    public int getCardId(){return card;}
    public Collection<UiccPortInfo> getPorts(){return ports;}
}
