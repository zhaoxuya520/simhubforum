package android.telephony;
/** Synthetic public-API boundary for RcsSystemLine host tests only. */
public class SubscriptionInfo {
    private final int id;
    private final String iccid;
    public SubscriptionInfo(int id, String iccid) { this.id=id; this.iccid=iccid; }
    public int getSubscriptionId() { return id; }
    public String getIccId() { return iccid; }
}
