package android.telephony;
/** Synthetic public-API boundary for RcsSystemLine host tests only. */
public class SubscriptionInfo {
    private final int id;
    private final String iccid;
    private final int slot, card, port;
    public SubscriptionInfo(int id, String iccid) { this(id, iccid, -1, -1, -1); }
    public SubscriptionInfo(int id, String iccid, int slot, int card, int port) {
        this.id=id; this.iccid=iccid; this.slot=slot; this.card=card; this.port=port;
    }
    public int getSimSlotIndex(){return slot;}
    public int getCardId(){return card;}
    public int getPortIndex(){return port;}
    public int getSubscriptionId() { return id; }
    public String getIccId() { return iccid; }
}
