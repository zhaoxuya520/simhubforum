package android.telephony;
public class TelephonyManager {
    public java.util.List<UiccCardInfo> cards = new java.util.ArrayList<>();
    public java.util.List<UiccCardInfo> getUiccCardsInfo() { return cards; }
    public int getActiveModemCount() { return 2; }
}
