package android.telephony;

public final class UiccPortInfo {
    private final String iccid;
    private final int port, logical;
    private final boolean active;
    public UiccPortInfo(String iccid,int port,int logical,boolean active) {
        this.iccid=iccid;this.port=port;this.logical=logical;this.active=active;
    }
    public String getIccId(){return iccid;}
    public int getPortIndex(){return port;}
    public int getLogicalSlotIndex(){return logical;}
    public boolean isActive(){return active;}
}
