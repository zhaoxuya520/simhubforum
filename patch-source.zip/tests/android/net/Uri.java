package android.net;

public final class Uri {
    public final String scheme, schemeSpecificPart, fragment;
    private Uri(String scheme,String ssp,String fragment) {
        this.scheme=scheme;this.schemeSpecificPart=ssp;this.fragment=fragment;
    }
    public static Uri fromParts(String scheme,String ssp,String fragment) { return new Uri(scheme,ssp,fragment); }
}
