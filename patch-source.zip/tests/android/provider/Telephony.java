package android.provider;

import android.content.Context;

public final class Telephony {
    public static final class Sms {
        public static String fixtureDefaultPackage;
        public static String getDefaultSmsPackage(Context context) { return fixtureDefaultPackage; }
    }
}
