package android.util;
public final class Log { public static int e(String tag,String message){return 0;} public static int i(String tag,String message){return 0;} }
