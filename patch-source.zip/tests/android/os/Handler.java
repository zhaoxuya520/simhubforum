package android.os;
public class Handler {
 public static final java.util.Queue<Runnable> tasks=new java.util.concurrent.ConcurrentLinkedQueue<>();
 public Handler(Looper l){} public boolean post(Runnable r){tasks.add(r);return true;}
 public static void drain(){Runnable r;while((r=tasks.poll())!=null)r.run();}
}
