package android.content;

public final class ComponentName {
    private final String pkg, name;
    public ComponentName(String pkg, String name) { this.pkg=pkg; this.name=name; }
    public String getPackageName() { return pkg; }
    public String getClassName() { return name; }
    @Override public boolean equals(Object other) {
        if (!(other instanceof ComponentName)) return false;
        ComponentName c=(ComponentName)other;
        return pkg.equals(c.pkg) && name.equals(c.name);
    }
    @Override public int hashCode() { return 31*pkg.hashCode()+name.hashCode(); }
}
