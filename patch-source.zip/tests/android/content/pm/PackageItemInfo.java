package android.content.pm;

public class PackageItemInfo {
    public String name, packageName, fixtureLabel;
    public CharSequence loadLabel(PackageManager packages) { return fixtureLabel; }
}
