package android.content.pm;

public class ActivityInfo extends PackageItemInfo {
    public boolean exported, enabled=true;
    public String permission;
    public ApplicationInfo applicationInfo;
}
