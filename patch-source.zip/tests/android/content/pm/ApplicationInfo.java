package android.content.pm;

public class ApplicationInfo extends PackageItemInfo {
    public boolean enabled=true;
    public int uid;
}
