package android.content.pm;

public class ApplicationInfo extends PackageItemInfo {
    public boolean enabled=true;
    public static final int FLAG_SUSPENDED = 1 << 30;
    public int uid, flags;
}
