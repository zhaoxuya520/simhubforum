package android.content.pm;

import android.content.Intent;

public abstract class PackageManager {
    public static final int MATCH_DEFAULT_ONLY=65536, PERMISSION_GRANTED=0;
    public abstract ResolveInfo resolveActivity(Intent query,int flags);
}
