package android.content;

import android.net.Uri;
import java.util.*;

public class Intent {
    public static final String ACTION_SENDTO="android.intent.action.SENDTO";
    public final String action;
    public final Uri data;
    public String pkg;
    public ComponentName component;
    public final Map<String,String> extras=new HashMap<>();
    public Intent(String action,Uri uri) { this.action=action;this.data=uri; }
    public Intent setPackage(String pkg) { this.pkg=pkg;return this; }
    public Intent setComponent(ComponentName component) { this.component=component;return this; }
    public Intent putExtra(String key,String value) { extras.put(key,value);return this; }
}
