package android.app;
import android.os.Bundle;
public class Application {
 public final java.util.List<ActivityLifecycleCallbacks> callbacks=new java.util.ArrayList<>();
 public void registerActivityLifecycleCallbacks(ActivityLifecycleCallbacks c){callbacks.add(c);}
 public void unregisterActivityLifecycleCallbacks(ActivityLifecycleCallbacks c){callbacks.remove(c);}
 public interface ActivityLifecycleCallbacks {
  void onActivityCreated(Activity a,Bundle b);void onActivityStarted(Activity a);void onActivityResumed(Activity a);
  void onActivityPaused(Activity a);void onActivityStopped(Activity a);void onActivitySaveInstanceState(Activity a,Bundle b);void onActivityDestroyed(Activity a);
 }
}
