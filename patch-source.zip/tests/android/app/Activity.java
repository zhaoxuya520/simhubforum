package android.app;
public class Activity extends android.content.ContextWrapper {
 public final Application app=new Application();public boolean destroyed;
 public Application getApplication(){return app;}public boolean isDestroyed(){return destroyed;}
 public void destroy(){destroyed=true;for(Application.ActivityLifecycleCallbacks c:new java.util.ArrayList<>(app.callbacks))c.onActivityDestroyed(this);}
}
