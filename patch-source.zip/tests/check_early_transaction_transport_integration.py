#!/usr/bin/env python3
"""Verify narrow early-transaction hooks and exact reversible native method boundaries."""
from pathlib import Path
import argparse, json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from sip_early_transaction_transport_patch import PINS, EDITS, _method, verify_sip_early_transaction_transport, reverse_sip_early_transaction_transport
from sip_invite_transport_patch import verify_sip_invite_transport

p = argparse.ArgumentParser()
p.add_argument('decoded', type=Path)
p.add_argument('--report', type=Path)
a = p.parse_args()
smali = a.decoded / 'smali' if (a.decoded / 'smali').is_dir() else a.decoded
report = verify_sip_early_transaction_transport(smali)
verify_sip_invite_transport(smali)  # The older whole-class inverse still accepts the composed callback.
for (name, signature), pin in PINS.items():
    text = (smali / name).read_text()
    restored = reverse_sip_early_transaction_transport(name, text)
    assert reverse_sip_early_transaction_transport(name, restored) == restored
    start, end, body = _method(text, signature)
    broken = text[:start] + body.replace('.line 1\n', '.line 99999\n', 1) + text[end:]
    try:
        reverse_sip_early_transaction_transport(name, broken)
    except AssertionError:
        pass
    else:
        raise AssertionError(name + ': unrelated native edit accepted')
timer = _method((smali/'cb4.smali').read_text(), 'public final p(Lkb4;Lma4;D)V')[2]
assert timer.index('SipEarlyTransactionTransport;->rememberTcp') < timer.index('iget-object p0, p0, Lcb4;->a:')
callback = _method((smali/'a82.smali').read_text(), 'public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;')[2]
hook = callback.index('SipEarlyTransactionTransport;->onFallbackSent')
assert callback.rfind('invoke-virtual {v6, v2}, Lo82;->C', 0, hook) >= 0
assert callback.rfind('SipInviteTransport;->onFallbackSent', 0, hook) >= 0
report['old_invite_inverse_compatible'] = True
report['native_method_negative_mutations_rejected'] = True
if a.report:
    a.report.write_text(json.dumps(report, indent=2) + '\n')
print('PASS: bounded early PRACK/UPDATE transport hooks; exact inverses and original INVITE callback preserved')
