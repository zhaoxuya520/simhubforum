#!/usr/bin/env python3
"""Verify the bounded raw-call hook, shared call/contact normalizer and unchanged SMS entry points."""
from pathlib import Path
import argparse, hashlib, json, sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from international_dialing_patch import verify_international_dialing, reverse_international_dialing
from ctexcel_call_policy_patch import reverse_ctexcel_call_policy, BASE_CLASS_SHA256

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('decoded', type=Path)
parser.add_argument('--report', type=Path, required=True)
args = parser.parse_args()
smali = args.decoded / 'smali' if (args.decoded / 'smali').exists() else args.decoded
pins = {
 'u10.smali': '282c058b59e5965cbfae1b6eb153ed0e764d9d6c91c07c37beb3a7a7e6071252',
 'b00.smali': 'f282cdb6df9ca536757cde34b0e5760336382128e3b6ec63820bb914eaf66e92',
 'ye3.smali': 'e83cc8bba93416a014534e60e5da05224de8b0dfd4c24ff50e31c99023c44411',
 'yk.smali': 'c2c21059b76f0bcc5ed6a57bfcdd0db5ae1f95869432c1017bed1b12fae83f7b',
 'f2.smali': 'd0849c8b0e1398eb6f75ad6b0ef2609354de95334eea43bb6754223919f681d5',
 'd3.smali': 'c6cd4284ed1ba00650d721d8c68aa30a9f416d5ac36b71bc0eadc9408128a719',
 'mu4.smali': '889bb222f27df73f0e8344615b15d5bfde5f4b51ba38efbaef4955b15ca9b0f8',
 'mc0.smali': 'a83e7ab89d8e68320a9f88dc245361a223e4a476ff336f0fe7068883a9ba5130',
 'pk5.smali': '55930a7fc8e646efc25b80dabc1c66659d6acd8916a8dec2def6aa121458c606',
 'ub4.smali': 'cb77c73c23b908a79a00a4743a5e12b801fe60d0c76635bbfdba19fe478de2d1',
}
checks = []
def check(condition, label):
    assert condition, label
    checks.append(label)

hook = verify_international_dialing(smali)
original = reverse_international_dialing('f82.smali', (smali/'f82.smali').read_text())
original = reverse_ctexcel_call_policy('f82.smali', original)
check(hashlib.sha256(original.encode()).hexdigest() == BASE_CLASS_SHA256,
      'full f82 restores pinned base after both reviewed overlays, including non-dial and emergency paths')
for name, expected in pins.items():
    check(hashlib.sha256((smali/name).read_bytes()).hexdigest() == expected,
          name + ': prior native entry/callback instructions unchanged')
for name in ('b00', 'ye3', 'yk', 'f2', 'd3'):
    check('Lu10;->c(Ljava/lang/String;)Ljava/lang/String;' in (smali/(name+'.smali')).read_text(),
          name + ': call/contact selection retains common normalization entry')
check('DialingSupport;->normalize(' in (smali/'u10.smali').read_text(), 'common UI entry reaches corrected helper')
check('DialingSupport;->smsDestination(' in (smali/'ub4.smali').read_text(), 'SMS recipient reaches unchanged-semantics helper')
check('Lu10;->c(' not in (smali/'mu4.smali').read_text(), 'SMS system-contact picker retains its independent original filter')
check('Lmu4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V' in (smali/'pk5.smali').read_text(),
      'SMS compose page retains native mu4 picker callback')
result = dict(checks=len(checks), failed=0, hook=hook, results=checks,
              pinned_classes=pins, android_device_test=False,
              sms_scope='native mu4 picker, mc0/pk5 editor and ub4 sender preserved; helper SMS/SMSC output checked separately')
args.report.parent.mkdir(parents=True, exist_ok=True)
args.report.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'checks':len(checks),'failed':0}))
