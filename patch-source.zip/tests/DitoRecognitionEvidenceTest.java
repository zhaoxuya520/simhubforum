import cc.forserein.simhub.internal.*;
import android.content.*;
import java.util.*;

/** Evidence and credential recovery are intentionally tested as separate operations. */
public class DitoRecognitionEvidenceTest {
 static int passed;
 static final String HOME="515661234567890",OTHER_HOME="515669876543210",ROAM="204049876543210",OTHER="234159876543210";
 static final String IIN="8963668800123455526",UNKNOWN="8901234500123450004";
 static final String HOMES="wifi_calling_dito_identity_v1",PROVIDERS="wifi_calling_dito_provider_v1";
 static void check(boolean yes,String what){if(!yes)throw new AssertionError(what);passed++;}
 interface Run{void run()throws Exception;}
 static void reject(Run op,String fragment)throws Exception{
  try{op.run();throw new AssertionError("accepted: "+fragment);}catch(IllegalStateException expected){check(expected.getMessage().contains(fragment),"useful rejection: "+fragment);}
 }
 static class Ctx extends Context {
  final Map<String,WifiConfigTest.Prefs> stores=new HashMap<>();
  public SharedPreferences getSharedPreferences(String name,int mode){if(!stores.containsKey(name))stores.put(name,new WifiConfigTest.Prefs());return stores.get(name);}
  WifiConfigTest.Prefs store(String name){return (WifiConfigTest.Prefs)getSharedPreferences(name,0);}
 }
 // Native ek5 has value equality; distinct reads must not share transient evidence.
 public static final class EqualCard extends ek5 {
  EqualCard(String imsi,String iccid){super(imsi,iccid,2,null,null,null,null,null);}
  public boolean equals(Object other){if(!(other instanceof EqualCard))return false;EqualCard x=(EqualCard)other;return a.equals(x.a)&&b.equals(x.b)&&c==x.c&&Objects.equals(d,x.d)&&Objects.equals(e,x.e)&&Objects.equals(f,x.f)&&Objects.equals(g,x.g)&&Objects.equals(h,x.h);}
  public int hashCode(){return Objects.hash(a,b,c,d,e,f,g,h);}
 }
 static Ctx fresh(){Ctx ctx=new Ctx();zl5.f=ctx;return ctx;}
 static ek5 card(String imsi,String iccid,int mnc){return new ek5(imsi,iccid,mnc,"a1","b2","+639123456789","+639000000000",new Object());}
 static void active(ek5 card){zl5.b.value=WifiConfigTest.state(card,zl3.r(card));}
 static void privateStatus(ek5 card,String... fragments){
  zl5.lastLog="";DitoHomeIdentity.readStatus(card);
  for(String fragment:fragments)check(zl5.lastLog.contains(fragment),"status describes "+fragment);
  check(card.a.isEmpty()||!zl5.lastLog.contains(card.a),"status never exposes full IMSI");
  check(card.b==null||card.b.isEmpty()||!zl5.lastLog.contains(card.b),"status never exposes full ICCID");
 }
 public static void main(String[] args)throws Exception {
  Ctx ctx=fresh();
  // A recognized issuer is independent of whichever network identity is current.
  for(String imsi:new String[]{OTHER,"001010123456789","310260123456789",ROAM}){
   ek5 roaming=card(imsi,IIN,imsi.startsWith("310")?3:2);
   check(DitoHomeIdentity.isDito(roaming),"known DITO issuer survives current PLMN changes");
   check(DitoHomeIdentity.settings(roaming)==roaming,"recognition alone cannot manufacture home credentials");
   check(DitoHomeIdentity.connection(roaming)==roaming,"identified DITO keeps its current genuine identity when home history is absent");
   DitoHomeIdentity.observe(roaming);
  }
  check(ctx.store(HOMES).data.isEmpty(),"no non-home IMSI learned");
  privateStatus(card(OTHER,IIN,2),"DITO 发卡机构","23415","当前");check(!zl5.lastLog.contains("暂不可连接"),"missing history alone is no longer reported as blocked");
  DitoHomeIdentity.observe(card(HOME,IIN,2));
  ek5 non20404=card(OTHER,IIN,2),effective=(ek5)DitoHomeIdentity.connection(non20404);
  check(effective!=non20404&&effective.a.equals(HOME)&&effective.c==2,"a non-20404 identity restores its actual same-card home");
  check(effective.b.equals(non20404.b)&&effective.d.equals(non20404.d)&&effective.e.equals(non20404.e)&&effective.f.equals(non20404.f)&&effective.g.equals(non20404.g)&&effective.h==non20404.h,"restoration preserves every other native identity field");
  check(non20404.a.equals(OTHER),"physical read is not rewritten");
  privateStatus(non20404,"23415","已恢复同卡真实");

  // Real home PLMN is sufficient to identify the carrier, but not to bind storage to a card.
  ctx=fresh();
  for(String id:new String[]{"",null,"123","8963668800123455526F"}){
   ek5 home=card(HOME,id,2);
   check(DitoHomeIdentity.isDito(home),"actual home identity identifies DITO without valid ICCID");
   check(DitoHomeIdentity.settings(home)==home&&DitoHomeIdentity.connection(home)==home,"actual home identity needs no remembered replacement");
   DitoHomeIdentity.observe(home);DitoHomeIdentity.observeProvider(home,"DITO");
   check(ctx.store(HOMES).data.isEmpty()&&ctx.store(PROVIDERS).data.isEmpty(),"missing or invalid ICCID cannot create a persistent record");
   privateStatus(home,"51566","归属未核实","不能保存或恢复");
   ek5 unknown=card(ROAM,id,2);
   check(!DitoHomeIdentity.isDito(unknown),"roaming identity without complete ICCID remains unverified");
   privateStatus(unknown,"20404","归属未核实");
  }

  ctx=fresh();ek5 ordinaryVodafone=card(ROAM,UNKNOWN,2);
  check(!DitoHomeIdentity.isDito(ordinaryVodafone),"an ordinary 20404 identity remains unclassified as DITO");
  privateStatus(ordinaryVodafone,"20404","ICCID 已读取","未找到可核实的 DITO 归属依据","按当前身份匹配运营商");
  zl5.lastLog="unchanged";DitoHomeIdentity.readStatus(card(OTHER,UNKNOWN,2));
  check(zl5.lastLog.equals("unchanged"),"unrelated ordinary PLMN receives no extra DITO status");

  // Home history is card specific and does not depend on an allowlisted issuer or current PLMN.
  ctx=fresh();ek5 unknownRoam=card(OTHER,UNKNOWN,2);
  check(!DitoHomeIdentity.isDito(unknownRoam),"unknown issuer and PLMN alone are not DITO evidence");
  DitoHomeIdentity.observe(card(HOME,UNKNOWN,2));
  check(DitoHomeIdentity.isDito(unknownRoam),"same-card actual home history identifies an unknown issuer");
  check(((ek5)DitoHomeIdentity.connection(unknownRoam)).a.equals(HOME),"history restores full observed IMSI without derivation");
  privateStatus(unknownRoam,"同卡真实归属记录","23415");
  check(!DitoHomeIdentity.isDito(card(OTHER,"8901234500123450005",2)),"same PLMN on a different card receives no history");
  ek5 mismatch=card(OTHER_HOME,UNKNOWN,3);
  check(DitoHomeIdentity.isDito(mismatch),"history can identify a card even if its current MNC length is inconsistent");
  DitoHomeIdentity.observe(mismatch);
  check(DitoHomeIdentity.settings(mismatch)==mismatch&&mismatch.a.equals(OTHER_HOME),"51566 with c3 is neither replaced nor learned");
  reject(()->DitoHomeIdentity.connection(mismatch),"MNC 长度不是 2");
  check(((ek5)DitoHomeIdentity.connection(unknownRoam)).a.equals(HOME),"inconsistent c3 read cannot overwrite actual home history");
  privateStatus(mismatch,"515669","MNC 长度 3","MNC 长度不一致");
  ek5 freshMismatch=card(HOME,IIN,3);DitoHomeIdentity.observe(freshMismatch);
  check(DitoHomeIdentity.isDito(freshMismatch)&&DitoHomeIdentity.settings(freshMismatch)==freshMismatch,"known issuer survives c3 while keeping the current identity intact");
  reject(()->DitoHomeIdentity.connection(freshMismatch),"MNC 长度不是 2");

  // Only exact provider names may add a classification marker. They never supply a home IMSI.
  for(String provider:new String[]{"DITO","dito telecommunity"," DITO   Telecommunity Corporation ","\tDiTo\n"}){
   ctx=fresh();ek5 fromProvider=card(OTHER,UNKNOWN,2);
   DitoHomeIdentity.observeProvider(fromProvider,provider);
   check(DitoHomeIdentity.isDito(fromProvider),"exact canonical provider identifies the matched card");
   check(ctx.store(HOMES).data.isEmpty()&&ctx.store(PROVIDERS).data.size()==1,"provider evidence and home credential stores are separate");
   String key=ctx.store(PROVIDERS).data.keySet().iterator().next();
   check(key.length()==64&&!key.contains(UNKNOWN),"provider persistence uses a hashed card key");
   check(!ctx.store(PROVIDERS).data.values().contains(OTHER),"provider marker contains no IMSI");
   check(DitoHomeIdentity.isDito(card(ROAM,UNKNOWN,2)),"persisted marker survives a new card object and changed IMSI");
   check(!DitoHomeIdentity.isDito(card(OTHER,"8901234500123450006",2)),"provider marker cannot identify a different full ICCID");
   check(DitoHomeIdentity.connection(fromProvider)==fromProvider,"provider evidence never invents a home IMSI and permits the current read");
   privateStatus(fromProvider,"同卡服务提供商记录","23415","当前");check(!zl5.lastLog.contains("暂不可连接"),"provider-only recognition does not imply an authentication preflight failure");
   Ctx restarted=new Ctx();restarted.store(PROVIDERS).data.putAll(ctx.store(PROVIDERS).data);zl5.f=restarted;
   check(DitoHomeIdentity.isDito(card(OTHER,UNKNOWN,2)),"provider classification restores from persistent marker alone");
  }
  for(String provider:new String[]{null,"","Vodafone","not DITO","DITO_51566_005","DITO roaming","DITO Telecommunity Corp","DITO Telecommunity Corporation extra"}){
   ctx=fresh();ek5 untrusted=card(OTHER,UNKNOWN,2);DitoHomeIdentity.observeProvider(untrusted,provider);
   check(!DitoHomeIdentity.isDito(untrusted)&&ctx.store(PROVIDERS).data.isEmpty(),"nicknames, substrings and other providers are rejected");
  }
  for(ek5 invalid:new ek5[]{card("51566",UNKNOWN,2),card("51566012345678x",UNKNOWN,2),card("5156601234567890",UNKNOWN,2),card(ROAM,"",2),card(ROAM,"8901234500123450004F",2)}){
   ctx=fresh();DitoHomeIdentity.observeProvider(invalid,"DITO");
   check(!DitoHomeIdentity.isDito(invalid)&&ctx.store(PROVIDERS).data.isEmpty(),"provider cannot validate malformed IMSI or ICCID");
  }

  // A failed commit warns but cannot erase the provider freshly verified for this read.
  ctx=fresh();ek5 freshProvider=card(OTHER,UNKNOWN,2);ctx.store(PROVIDERS).fail=true;
  reject(()->DitoHomeIdentity.observeProvider(freshProvider,"DITO"),"未能保存 DITO 运营商");
  check(DitoHomeIdentity.isDito(freshProvider),"disk failure retains current read's verified provider evidence");
  check(ctx.store(PROVIDERS).data.isEmpty()&&ctx.store(HOMES).data.isEmpty(),"failed provider write rolls back and never teaches credentials");
  check(DitoHomeIdentity.connection(freshProvider)==freshProvider,"provider save failure leaves the real current identity available");
  check(!DitoHomeIdentity.isDito(card(OTHER,UNKNOWN,2)),"unmatched new read cannot inherit a failed persistent marker");
  DitoHomeIdentity.observeProvider(freshProvider,"DITO");
  check(DitoHomeIdentity.isDito(card(ROAM,UNKNOWN,2)),"successful retry persists same-card provider evidence");

  ctx=fresh();EqualCard equalFirst=new EqualCard(OTHER,UNKNOWN),equalSecond=new EqualCard(OTHER,UNKNOWN);
  check(equalFirst!=equalSecond&&equalFirst.equals(equalSecond),"fixture represents distinct native value-equal read results");
  ctx.store(PROVIDERS).fail=true;
  reject(()->DitoHomeIdentity.observeProvider(equalFirst,"DITO"),"未能保存 DITO 运营商");
  check(DitoHomeIdentity.isDito(equalFirst),"fresh exact object keeps provider evidence after storage failure");
  check(!DitoHomeIdentity.isDito(equalSecond),"distinct value-equal read cannot inherit transient provider evidence");

  // An explicit DITO choice retains current identity; real same-card home still takes priority.
  ctx=fresh();ek5 manual=card(OTHER,UNKNOWN,2);active(manual);
  WifiConfigRuntime.Snapshot draft=WifiConfigRuntime.snapshot();
  WifiConfigRuntime.save(draft.key,draft.record,WifiConfigTest.values(CarrierPresets.KEY,DitoCarrierProfile.KEY));
  check(!DitoHomeIdentity.isDito(manual),"manual preset is not learned as physical carrier evidence");
  check(DitoHomeIdentity.connection(manual)==manual,"manual DITO selection does not block a valid current identity");
  DitoHomeIdentity.observe(card(HOME,UNKNOWN,2));
  check(((ek5)DitoHomeIdentity.connection(manual)).a.equals(HOME),"manual choice prefers actual same-card home after it was learned");
  fresh();ek5 foreign=card(OTHER,UNKNOWN,2);
  check(!DitoHomeIdentity.isDito(foreign)&&DitoHomeIdentity.connection(foreign)==foreign,"unrelated carrier's native connection remains unchanged");
  System.out.println("PASS: "+passed+" DITO evidence, provider persistence, home authenticity, MNC and private status assertions");
 }
}
