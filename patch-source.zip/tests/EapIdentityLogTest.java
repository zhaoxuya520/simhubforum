import cc.forserein.simhub.internal.EapIdentityLog;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public class EapIdentityLogTest {
    static final String SUMMARY = "EAP 第 1 轮 → 回复";
    static int checks;
    static void expect(String expected, byte[] reply) {
        String actual = EapIdentityLog.describe(SUMMARY, reply);
        if (!expected.equals(actual)) throw new AssertionError(actual);
        checks++;
    }
    static byte[] identity(int method, String value) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        int attribute = (4 + bytes.length + 3) & ~3;
        ByteBuffer packet = ByteBuffer.allocate(8 + attribute);
        packet.put((byte)2).put((byte)1).putShort((short)packet.capacity());
        packet.put((byte)method).put((byte)5).putShort((short)0);
        packet.put((byte)14).put((byte)(attribute/4)).putShort((short)bytes.length).put(bytes);
        return packet.array();
    }
    public static void main(String[] args) {
        String publicDomain = "@nai.epc.mnc004.mcc204.3gppnetwork.org";
        for (String user : new String[]{"a","ab","abc","abcd","测试用户","0204049876543210"}) {
            expect(SUMMARY + "（AKA 身份域 mnc004.mcc204）", identity(23, user + publicDomain));
        }
        expect(SUMMARY + "（AKA′ 身份域 mnc066.mcc515）", identity(50, "private@nai.epc.mnc066.mcc515.3gppnetwork.org"));
        expect(SUMMARY + "（AKA 身份）", identity(23, "test@example.org"));
        expect(SUMMARY + "（AKA 身份）", identity(23, "0204049876543210"));
        expect(SUMMARY, new byte[]{3,1,0,4});
        expect(SUMMARY, null);
        System.out.println("PASS: " + checks + " private EAP reply log assertions");
    }
}
