#!/usr/bin/env python3
"""Execute the patched hz3 instruction paths with simulated dispatch/card results.

This bounded interpreter checks the actual generated coroutine control flow. It
is deliberately not an Android runtime, a general DEX VM, or a device test.
Unknown instructions/calls fail rather than being silently treated as success.
"""
from pathlib import Path
import re
import json
import sys
import unittest

SMALI = Path(sys.argv.pop(1)) if len(sys.argv) > 1 else Path(__file__).parents[1] / 'build/apktool/smali/hz3.smali'
SUSPENDED, UNIT = object(), object()

class CardError(Exception): pass
class Cancelled(CardError): pass
class SwitchUnconfirmed(CardError): pass

class Obj:
    def __init__(self, kind, **fields):
        self.kind, self.fields = kind, fields

class Program:
    def __init__(self, path):
        text = path.read_text().split('.method public final q(Ljava/lang/Object;)Ljava/lang/Object;', 1)[1].split('.end method', 1)[0]
        self.code, self.labels, self.tables, self.handlers = [], {}, {}, []
        last_label, table = None, None
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line.startswith(('.line', '.locals', '#')): continue
            if line.startswith('.packed-switch '):
                table = []
                self.tables[last_label] = (int(line.split()[1], 0), table)
            elif line == '.end packed-switch': table = None
            elif table is not None: table.append(line)
            elif line.startswith(':'):
                last_label = line
                self.labels[line] = len(self.code)
            elif line.startswith('.catchall '):
                m = re.fullmatch(r'\.catchall \{(\S+) \.\. (\S+)\} (\S+)', line)
                assert m, line
                self.handlers.append(m.groups())
            else:
                assert not line.startswith('.'), line
                self.code.append(line)

PROGRAM = Program(SMALI)

def profiles(enabled, name='target'):
    return [Obj('qy3', a=name, b=enabled)]

def is_type(value, kind):
    if kind == 'java/util/concurrent/CancellationException': return isinstance(value, Cancelled)
    if kind == 'java/util/List': return isinstance(value, list)
    if kind == 'java/lang/Boolean': return isinstance(value, bool)
    return isinstance(value, Obj) and value.kind == kind

class Run:
    def __init__(self, slot=True, enable=True, reads=None, suspend=True, reset=False, cancel_delay=False, mutation_error=None):
        self.transport = Obj('s4' if slot else 'usb')
        self.manager = Obj('hh1', a=self.transport, d=True, e=True, h=0)
        self.controller = Obj('iz3')
        self.frame = Obj('hz3', Z=0, a0=self.manager, b0=self.controller, c0=Obj('qy3', a='target'), d0=enable)
        self.reads = list(reads if reads is not None else [profiles(enable)])
        self.suspend, self.reset, self.cancel_delay, self.mutation_error = suspend, reset, cancel_delay, mutation_error
        self.writes, self.read_count, self.delays, self.updated, self.finished = [], 0, [], [], 0
        self.next_resume = UNIT

    def result(self, value):
        if self.suspend:
            self.next_resume = value
            return SUSPENDED
        if isinstance(value, CardError): raise value
        return value

    def invoke(self, ref, args):
        if ref == 'Loc2;->N(Ljava/lang/Object;)V':
            if isinstance(args[0], CardError): raise args[0]
            return None
        if ref == 'Ljava/lang/Object;->getClass()Ljava/lang/Class;':
            assert args[0] is not None and args[0] != 0
            return Obj('Class')
        if '-><init>(' in ref:
            args[0].fields['args'] = args[1:]
            return None
        if ref == 'Liz3;->a(Liz3;Ljava/lang/String;)V':
            assert args[0] is self.controller and args[1] == 'target'
            return None
        if ref == 'Liz3;->s()Lqg0;': return self.transport
        if ref in ('Lhh1;->v(Ljava/lang/String;ILws1;Lcz4;)Ljava/lang/Object;', 'LInternalSimSwitchRequest;->start(Lhh1;Ljava/lang/String;ILws1;Lcz4;)Ljava/lang/Object;'):
            assert args[0] is self.manager and args[1] == 'target'
            assert args[2] == (0xbf31 if self.frame.fields['d0'] else 0xbf32)
            self.writes.append(args[2])
            return self.result(self.mutation_error or UNIT)
        if ref == 'Lqg0;->d(Lct0;)Ljava/lang/Object;':
            assert self.transport.kind != 's4', 'Phone must request refresh in ES10c, not raw reader reset'
            return self.result(self.reset)
        if ref == 'Ljava/lang/Boolean;->booleanValue()Z': return args[0]
        if ref == 'Lg7;->J(JLct0;)Ljava/lang/Object;':
            self.delays.append(args[0])
            return self.result(Cancelled('during wait') if self.cancel_delay else UNIT)
        if ref == 'Lhh1;->s(Lws1;Ldt0;)Ljava/lang/Object;':
            assert args[0].kind == 'kg1' and args[0].fields['args'][2] == 1, 'Only profile reads allowed in refresh loop'
            self.read_count += 1
            result = self.reads[min(self.read_count - 1, len(self.reads) - 1)]
            return self.result(result)
        if ref == 'LInternalSimProfileState;->matches(Ljava/util/List;Ljava/lang/String;Z)Z':
            rows, wanted, enabled = args
            if not isinstance(rows, list): return False
            same = [row for row in rows if row.fields['a'] == wanted]
            return len(same) == 1 and same[0].fields['b'] == enabled
        if ref == 'Liz3;->J(Ljava/util/List;)V': self.updated.append(args[1]); return None
        if ref == 'Liz3;->H(Ljava/util/List;)V': return None
        if ref == 'Liz3;->K()V': self.finished += 1; return None
        raise AssertionError('Unmodelled call: ' + ref)

    def execute(self):
        incoming = UNIT
        for resume in range(100):
            regs = {'p0': self.frame, 'p1': incoming}
            pc, result, pending_error = 0, None, None
            for step in range(10000):
                origin = pc
                line = PROGRAM.code[pc]
                pc += 1
                op, _, operand = line.partition(' ')
                a = operand.split(', ')
                try:
                    if op == 'nop': pass
                    elif op.startswith('const-wide'):
                        regs[a[0]] = int(a[1], 0)
                        regs['v' + str(int(a[0][1:]) + 1)] = 'wide-high'
                    elif op == 'const-string': regs[a[0]] = operand.split(', ', 1)[1][1:-1]
                    elif op.startswith('const'): regs[a[0]] = int(a[1], 0)
                    elif op == 'move-exception': regs[a[0]] = pending_error
                    elif op.startswith('move-result'): regs[a[0]] = result
                    elif op.startswith('move'): regs[a[0]] = regs[a[1]]
                    elif op.startswith('iget'):
                        field = a[2].split('->')[1].split(':')[0]
                        regs[a[0]] = regs[a[1]].fields.get(field, 0)
                    elif op.startswith('iput'):
                        field = a[2].split('->')[1].split(':')[0]
                        regs[a[1]].fields[field] = regs[a[0]]
                    elif op == 'sget-object':
                        assert a[1] in ('Lpu0;->T:Lpu0;', 'Lsc5;->a:Lsc5;'), line
                        regs[a[0]] = SUSPENDED if a[1].startswith('Lpu0;') else UNIT
                    elif op == 'new-instance': regs[a[0]] = Obj(a[1][1:-1])
                    elif op == 'instance-of': regs[a[0]] = is_type(regs[a[1]], a[2][1:-1])
                    elif op == 'check-cast':
                        assert regs[a[0]] == 0 or is_type(regs[a[0]], a[1][1:-1]), line
                    elif op.startswith('invoke'):
                        match = re.fullmatch(r'\{([^}]*)\}, (\S+)', operand)
                        assert match, line
                        values = [regs[x] for x in match[1].split(', ')] if match[1] else []
                        result = self.invoke(match[2], values)
                    elif op == 'packed-switch':
                        base, labels = PROGRAM.tables[a[1]]
                        key = regs[a[0]] - base
                        if 0 <= key < len(labels): pc = PROGRAM.labels[labels[key]]
                    elif op.startswith('goto'): pc = PROGRAM.labels[a[0]]
                    elif op.startswith('if-'):
                        left = regs[a[0]]
                        right = 0 if op.endswith('z') else regs[a[1]]
                        condition = {'if-eqz': lambda: not bool(left), 'if-nez': lambda: bool(left),
                                     'if-lez': lambda: left <= 0, 'if-ge': lambda: left >= right,
                                     'if-ne': lambda: left != right, 'if-eq': lambda: left == right}[op]()
                        if condition: pc = PROGRAM.labels[a[-1]]
                    elif op == 'add-int/lit8': regs[a[0]] = regs[a[1]] + int(a[2], 0)
                    elif op == 'throw':
                        value = regs[a[0]]
                        if isinstance(value, CardError): raise value
                        assert value.kind == 'java/lang/IllegalStateException'
                        raise SwitchUnconfirmed(value.fields['args'][0])
                    elif op == 'return-object':
                        if regs[a[0]] is SUSPENDED:
                            incoming = self.next_resume
                            break
                        return regs[a[0]]
                    else: raise AssertionError('Unmodelled opcode: ' + line)
                except CardError as error:
                    handlers = [(start, end, target) for start, end, target in PROGRAM.handlers
                                if PROGRAM.labels[start] <= origin < PROGRAM.labels[end]]
                    if not handlers: raise
                    pending_error = error
                    pc = PROGRAM.labels[handlers[0][2]]
            else: raise AssertionError('Instruction limit exceeded')
        raise AssertionError('Resume limit exceeded')

class RefreshFlowTest(unittest.TestCase):
    def test_enable_sync_and_suspended(self):
        for suspend in (False, True):
            with self.subTest(suspend=suspend):
                run = Run(reads=[profiles(False), profiles(True)], suspend=suspend)
                self.assertIs(run.execute(), UNIT)
                self.assertEqual((len(run.writes), run.read_count, run.finished), (1, 2, 1))
                self.assertEqual(run.delays, [3000, 1000])
                self.assertEqual(len(run.updated), 1)
    def test_disable_transient_read_error(self):
        run = Run(enable=False, reads=[CardError('refreshing'), profiles(False)])
        self.assertIs(run.execute(), UNIT)
        self.assertEqual((len(run.writes), run.read_count), (1, 2))
    def test_stale_readback_is_bounded(self):
        run = Run(reads=[profiles(False)])
        with self.assertRaises(SwitchUnconfirmed): run.execute()
        self.assertEqual((len(run.writes), run.read_count, run.finished), (1, 30, 0))
        self.assertEqual(run.delays, [3000] + [1000] * 29)
        self.assertFalse(run.updated)
    def test_wrong_profile_cannot_confirm(self):
        run = Run(reads=[profiles(True, 'wrong')])
        with self.assertRaises(SwitchUnconfirmed): run.execute()
        self.assertEqual((len(run.writes), run.read_count), (1, 30))
    def test_missing_profile_cannot_confirm_disable(self):
        run = Run(enable=False, reads=[[]])
        with self.assertRaises(SwitchUnconfirmed): run.execute()
        self.assertEqual((len(run.writes), run.read_count), (1, 30))
    def test_cancel_during_delay(self):
        run = Run(cancel_delay=True)
        with self.assertRaises(Cancelled): run.execute()
        self.assertEqual((len(run.writes), run.read_count, run.finished), (1, 0, 0))
    def test_cancel_during_read(self):
        run = Run(reads=[Cancelled('read cancelled')])
        with self.assertRaises(Cancelled): run.execute()
        self.assertEqual((len(run.writes), run.read_count, run.finished), (1, 1, 0))
    def test_rejected_mutation_is_not_retried(self):
        run = Run(mutation_error=CardError('access denied'))
        with self.assertRaises(CardError): run.execute()
        self.assertEqual((len(run.writes), run.read_count, run.finished), (1, 0, 0))
    def test_usb_does_not_enter_phone_refresh_loop(self):
        run = Run(slot=False)
        self.assertIs(run.execute(), UNIT)
        self.assertEqual((len(run.writes), run.read_count, run.finished), (1, 1, 1))
        self.assertEqual(run.delays, [])
    def test_original_usb_reset_retry_behavior(self):
        run = Run(slot=False, reset=True, reads=[CardError('resetting'), profiles(True)])
        self.assertIs(run.execute(), UNIT)
        self.assertEqual((len(run.writes), run.read_count), (1, 2))
        self.assertEqual(run.delays, [500])

if __name__ == '__main__':
    result = unittest.main(verbosity=2, exit=False).result
    if not result.wasSuccessful(): sys.exit(1)
    report = {'cases': result.testsRun, 'failed': len(result.failures), 'errors': len(result.errors),
              'method': 'hz3.q simulated instruction paths', 'android_runtime': False, 'card_operations': 'simulated'}
    (SMALI.parents[2] / 'refresh-flow-results.json').write_text(json.dumps(report, indent=2) + '\n')
