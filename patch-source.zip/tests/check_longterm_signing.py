#!/usr/bin/env python3
import sys,ssl,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from signing_policy import patch_delivered_security_policy,ORIGINAL_ALLOWLIST,DELIVERED_CONFIG2_SIGNER,expected_allowlist,test_signer_digest
source=Path('/workspace/recovery/config2-decoded/smali/mg.smali').read_text()
patched=patch_delivered_security_policy(source)
old='const-string v2, "'+ORIGINAL_ALLOWLIST+','+DELIVERED_CONFIG2_SIGNER+'"'
new='const-string v2, "'+expected_allowlist()+'"'
assert patched.replace(new,old)==source
assert test_signer_digest()!=DELIVERED_CONFIG2_SIGNER
try:patch_delivered_security_policy(patched)
except ValueError:pass
else:raise AssertionError('Duplicate policy patch accepted')
try:patch_delivered_security_policy(source.replace(old,'const-string v2, "unexpected"'))
except ValueError:pass
else:raise AssertionError('Unexpected self-check accepted')
print('PASS: 4 new-signer policy regression checks')
