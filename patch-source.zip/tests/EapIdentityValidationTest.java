import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Field-only validation: no EAP packets, authentication challenges or network operations. */
public class EapIdentityValidationTest {
 static int passed;
 static void check(boolean value,String reason){if(!value)throw new AssertionError(reason);passed++;}
 interface Run {void run()throws Exception;}
 static void rejects(String key,Run run)throws Exception {
  try{run.run();throw new AssertionError("accepted oversized permanent identity: "+key);}
  catch(WifiConfigValues.Invalid expected){check(expected.key.equals(key)&&expected.getMessage().contains("1016"),"error identifies the effective permanent field and UTF-8 bound");}
 }
 static String repeat(String part,int count){StringBuilder out=new StringBuilder();for(int i=0;i<count;i++)out.append(part);return out.toString();}
 static Map<String,String> values(String...pairs){return WifiConfigTest.values(pairs);}
 static xi5 merge(xi5 config,Map<String,String> values)throws Exception {return(xi5)WifiConfigModel.merge(config,WifiConfigValues.validate(values));}
 static xi5 permanent(xi5 config,String value)throws Exception {Object[] fields=WifiConfigModel.fields(config,27);fields[24]=value;return(xi5)WifiConfigModel.constructor(xi5.class,27).newInstance(fields);}
 static void saveWait()throws Exception {long end=System.nanoTime()+2_000_000_000L;while(Handler.tasks.isEmpty()&&System.nanoTime()<end)Thread.sleep(5);check(!Handler.tasks.isEmpty(),"asynchronous validation/save completed");Handler.drain();}
 static void open(lu1 composer){WifiConfigEditor.row("NAI","original",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);}
 public static void main(String[]args)throws Exception {
  String ascii=repeat("a",1010)+"@x.org",unicode=repeat("é",505)+"@x.org",wide=repeat("界",336)+"aa@x.org",emoji=repeat("😀",252)+"aa@x.org";
  for(String boundary:new String[]{ascii,unicode,wide,emoji}) {
   check(boundary.getBytes(StandardCharsets.UTF_8).length==1016,"boundary counts UTF-8 bytes, including multi-byte characters");
   check(WifiConfigValues.validate(values("eap",boundary)).get("eap").equals(boundary),"1016-byte explicit EAP field is accepted exactly");
   check(WifiConfigValues.validate(values("eap","  "+boundary+"  ")).get("eap").equals(boundary),"normal whitespace trimming precedes byte validation");
   rejects("eap",()->WifiConfigValues.validate(values("eap",boundary+"a")));
   rejects("eap",()->WifiConfigValues.decode(WifiConfigValues.encode(values("eap",boundary+"a"))));
  }
  String longOuter=ascii+"a";
  check(WifiConfigValues.validate(values("nai",longOuter)).get("nai").equals(longOuter),"outer NAI has no unconditional permanent-identity bound");
  check(WifiConfigValues.validate(values("impi",longOuter)).get("impi").equals(longOuter),"private IMS identity retains existing validation");
  check(WifiConfigValues.validate(values("impu","sip:"+longOuter)).get("impu").equals("sip:"+longOuter),"public IMS identity retains existing validation");
  check(WifiConfigValues.validate(values("eap"," ")).isEmpty(),"blank EAP remains a request for carrier default");

  zl5.f=new DitoHomeIdentityTest.Ctx();ek5 card=new ek5("204049876543210","8948011234567897399");xi5 nativeConfig=zl3.r(card);
  check(nativeConfig.y==null,"non-DITO fixture follows native y=null fallback");
  rejects("nai",()->merge(nativeConfig,values("nai",longOuter)));
  rejects("nai",()->merge(nativeConfig,values("nai",longOuter,"eap","")));
  xi5 exact=merge(nativeConfig,values("nai",ascii));check(exact.r.equals(ascii)&&exact.y==null,"exact-boundary fallback NAI remains valid");
  xi5 explicit=merge(nativeConfig,values("nai",longOuter,"eap","permanent@example.org"));
  check(explicit.r.equals(longOuter)&&explicit.y.equals("permanent@example.org"),"short explicit EAP makes independent long outer NAI valid");
  xi5 separate=permanent(nativeConfig,"native-permanent@example.org");
  check(merge(separate,values("nai",longOuter)).y.equals(separate.y),"native non-null permanent identity prevents unrelated outer-NAl rejection");
  xi5 emptyPermanent=permanent(nativeConfig,"");
  check(merge(emptyPermanent,values("nai",longOuter)).y.isEmpty(),"empty non-null native permanent value does not use the null-only fallback rule");
  xi5 dito=(xi5)DitoCarrierProfile.defaults(new ek5(card.a,"8963668800123457399"));
  check(merge(dito,values("nai",longOuter)).y.equals(dito.y),"DITO card-derived EAP stays independent from long custom outer NAI");
  rejects("eap",()->merge(dito,values("eap",longOuter)));
  xi5 ims=merge(nativeConfig,values("impi",longOuter,"impu","sip:"+longOuter));
  check(ims.s.equals(longOuter)&&ims.A.equals("sip:"+longOuter)&&ims.y==null,"unrelated IMS fields cannot accidentally trigger the EAP bound");

  // Save checks the actual effective identity before changing disk or live state.
  DitoHomeIdentityTest.Ctx context=new DitoHomeIdentityTest.Ctx();zl5.f=context;zl5.b.value=WifiConfigTest.state(card,nativeConfig);
  WifiConfigRuntime.Snapshot initial=WifiConfigRuntime.snapshot();WifiConfigRuntime.save(initial.key,initial.record,Collections.emptyMap());
  WifiConfigRuntime.Snapshot clean=WifiConfigRuntime.snapshot();Object originalState=zl5.b.value;
  rejects("nai",()->WifiConfigRuntime.save(clean.key,clean.record,values("nai",longOuter)));
  check(WifiConfigRuntime.snapshot().record.equals(clean.record)&&zl5.b.value==originalState,"rejected fallback identity cannot change persistent or live configuration");
  rejects("eap",()->WifiConfigRuntime.save(clean.key,clean.record,values("eap",longOuter)));
  check(WifiConfigRuntime.snapshot().record.equals(clean.record)&&zl5.b.value==originalState,"rejected explicit identity cannot change persistent or live configuration");
  WifiConfigRuntime.save(clean.key,clean.record,values("nai",longOuter,"eap","short@example.org"));
  check(((gl5)zl5.b.value).f.r.equals(longOuter)&&((gl5)zl5.b.value).f.y.equals("short@example.org"),"valid outer/permanent split survives real save and resolution");
  ek5 reread=new ek5(card.a,card.b);zl5.b.value=WifiConfigTest.state(reread,zl3.r(reread));
  check(((gl5)zl5.b.value).f.r.equals(longOuter)&&((gl5)zl5.b.value).f.y.equals("short@example.org"),"reopening/re-reading preserves the valid explicit EAP split");
  WifiConfigRuntime.Snapshot saved=WifiConfigRuntime.snapshot();
  rejects("nai",()->WifiConfigRuntime.save(saved.key,saved.record,values("nai",longOuter)));
  check(WifiConfigRuntime.snapshot().values.get("eap").equals("short@example.org"),"clearing EAP cannot persist an oversized newly active NAI fallback");

  // Existing editor reports failure without losing the draft or closing the sheet.
  WifiConfigRuntime.save(saved.key,saved.record,Collections.emptyMap());Activity activity=new Activity();lu1 composer=new lu1();
  WifiConfigEditor.begin(activity,(us1)()->sc5.a);open(composer);String before=WifiConfigRuntime.snapshot().record;
  ak2.edits.get(0).change.i(longOuter);xq0.press("保存");saveWait();WifiConfigEditor.overlay(composer);
  check(xq0.message!=null&&xq0.message.contains("1016")&&ak2.edits.get(0).value.equals(longOuter),"contextual NAI failure stays visible and preserves exact draft");
  check(WifiConfigRuntime.snapshot().record.equals(before),"failed editor save leaves original record unchanged");
  ak2.edits.get(3).change.i("short@example.org");xq0.press("保存");saveWait();open(composer);
  check(ak2.edits.get(0).value.equals(longOuter)&&ak2.edits.get(3).value.equals("short@example.org"),"adding an independent valid EAP identity repairs the existing draft");
  ak2.edits.get(3).change.i(longOuter);xq0.press("保存");WifiConfigEditor.overlay(composer);
  check(xq0.message!=null&&xq0.message.contains("1016")&&ak2.edits.get(3).value.equals(longOuter),"oversized explicit EAP fails immediately without losing draft");
  check(WifiConfigRuntime.snapshot().values.get("eap").equals("short@example.org"),"immediate validation cannot overwrite last saved identity");
  xq0.cancel.a();activity.destroy();check(composer.depth==0,"existing editor groups remain balanced");
  System.out.println("PASS: "+passed+" UTF-8 permanent EAP field limits, native fallback and persistence assertions (no packets)");
 }
}
