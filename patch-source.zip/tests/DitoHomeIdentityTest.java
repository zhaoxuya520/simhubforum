import cc.forserein.simhub.internal.*;
import android.content.*;
import android.os.Handler;
import android.widget.Toast;
import java.util.*;

public class DitoHomeIdentityTest {
 static int passed;
 static final String ICCID="8963662600123455526",HOME="515660123456789",ROAM="204049876543210";
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);passed++;}
 interface Run{void run()throws Exception;}
 static void reject(Run run,String fragment)throws Exception{
  try{run.run();throw new AssertionError("accepted: "+fragment);}catch(IllegalStateException expected){check(expected.getMessage().contains(fragment),"useful failure: "+fragment);}
 }
 public static class Ctx extends Context {
  final Map<String,WifiConfigTest.Prefs> stores=new HashMap<>();
  public SharedPreferences getSharedPreferences(String name,int mode){WifiConfigTest.Prefs p=stores.get(name);if(p==null){p=new WifiConfigTest.Prefs();stores.put(name,p);}return p;}
  WifiConfigTest.Prefs store(String name){return (WifiConfigTest.Prefs)getSharedPreferences(name,0);}
 }
 static ek5 card(String imsi,String iccid){return new ek5(imsi,iccid,2,"a1","b2","+639123456789","+639000000000",new Object());}
 static String legacy(ek5 card){return WifiConfigValues.digest(card.b+"\n"+card.a);}
 static void active(ek5 card){zl5.b.value=WifiConfigTest.state(card,zl3.r(card));}
 static Map<String,String> values(String... pairs){return WifiConfigTest.values(pairs);}
 public static void main(String[] args)throws Exception {
  Ctx ctx=new Ctx();zl5.f=ctx;ek5 home=card(HOME,ICCID),roam=card(ROAM,ICCID);
  check(DitoHomeIdentity.isDito(home)&&DitoHomeIdentity.isDito(roam),"exact issuer and home/roaming identities recognized");
  xi5 pending=(xi5)CarrierPresets.defaults(roam,null);
  check(pending.c.equals("DITO")&&pending.d.equals("515")&&pending.e.equals("66"),"no-home roaming card displays DITO settings, not Vodafone");
  check(DitoHomeIdentity.settings(roam)==roam,"missing home identity is never invented");
  check(DitoHomeIdentity.connection(roam)==roam,"no stored home keeps the genuine current read available for registration");
  check(ctx.store("wifi_calling_dito_identity_v1").data.isEmpty(),"no home identity was learned from a roaming IMSI or template");
  active(roam);check(((gl5)zl5.b.value).e==roam&&((gl5)zl5.b.value).f.c.equals("DITO"),"physical read remains usable before home identity is available");
  int builds=zl3.builds;for(int i=0;i<10;i++)WifiConfigRuntime.resolve(roam,((gl5)zl5.b.value).f);
  check(zl3.builds==builds,"automatic DITO resolution is cached during recomposition");
  zl5.enabled=true;DitoHomeIdentity.connectionError(new IllegalStateException("卡片身份无效，请重新读取"));Handler.drain();
  check(!zl5.enabled&&zl5.lastLog.contains("身份无效")&&Toast.last.contains("身份无效"),"invalid identity still stops connection cleanly with a visible reason");

  // Only a current, real read is allowed to teach the full home IMSI.
  Object transport=new Object(),auth=new Object();IdentityBinding.begin(transport,auth);
  IdentityBinding.read(transport,auth,home);
  check(((xi5)WifiConfigRuntime.resolve(roam,((gl5)zl5.b.value).f)).r.startsWith("0"+HOME+"@"),"newly learned home identity invalidates credentials cached for the same raw card object");
  check(ctx.store("wifi_calling_dito_identity_v1").data.size()==1,"fresh home read is durably saved");
  check(ctx.store("wifi_calling_dito_identity_v1").data.containsValue(HOME),"store preserves the full real home IMSI");
  check(!ctx.store("wifi_calling_dito_identity_v1").data.keySet().iterator().next().contains(ICCID),"preference key does not expose ICCID");
  Object obsolete=new Object();IdentityBinding.begin(transport,obsolete);IdentityBinding.begin(transport,new Object());
  reject(()->IdentityBinding.read(transport,obsolete,card("515661111111111",ICCID)),"过期");
  ek5 effective=(ek5)DitoHomeIdentity.connection(roam);
  check(effective!=roam&&effective.a.equals(HOME)&&effective.c==2,"connection receives verified same-card home IMSI and two-digit MNC");
  check(effective.b.equals(roam.b)&&effective.d.equals(roam.d)&&effective.e.equals(roam.e),"ICCID and group identifiers preserved");
  check(effective.f.equals(roam.f)&&effective.g.equals(roam.g)&&effective.h==roam.h,"SMSC, number and ISIM copied without modification");
  check(roam.a.equals(ROAM)&&roam.c==2&&home.a.equals(HOME),"actual read results remain immutable");
  xi5 restored=(xi5)CarrierPresets.defaults(roam,null);
  check(restored.r.equals("0"+HOME+"@nai.epc.mnc066.mcc515.3gppnetwork.org"),"IKE identity uses saved full home IMSI");
  check(restored.y.equals(restored.r),"restored permanent EAP uses the same actual home IMSI and home MNC length");
  check(restored.s.equals(HOME+"@ims.mnc066.mcc515.3gppnetwork.org"),"IMS identity uses the same home IMSI");
  check(!restored.r.contains(ROAM)&&!restored.s.contains(ROAM),"roaming identity is absent from restored credentials");
  check(restored.f.equals(Arrays.asList("epdg.epc.mnc066.mcc515.pub.3gppnetwork.org")),"DITO ePDG realm selected");
  check(DitoHomeIdentity.connection(home)==home,"actual home card requires no fabricated copy");
  String masked=DitoHomeIdentity.mask(roam,restored.r+" "+restored.s);
  check(!masked.contains(HOME)&&masked.contains("51566••••••••89"),"existing identity hiding also masks restored home credentials");
  active(card(ROAM,ICCID));check(!DitoHomeIdentity.maskLog(restored.r).contains(HOME),"session logs redact remembered IMSI before native roaming-IMSI redaction");
  check(!WifiConfigRuntime.cardKey(home).equals(legacy(home))&&WifiConfigRuntime.cardKey(home).equals(WifiConfigRuntime.cardKey(roam)),"DITO config key stays stable across home and roaming IMSIs");

  // Restore from persisted preferences with no cached original card/store object.
  Ctx restarted=new Ctx();restarted.store("wifi_calling_dito_identity_v1").data.putAll(ctx.store("wifi_calling_dito_identity_v1").data);
  zl5.f=restarted;ek5 reread=card(ROAM,ICCID);
  check(((ek5)DitoHomeIdentity.connection(reread)).a.equals(HOME),"new card/context restore from preferences without in-memory home-card cache");
  ek5 another=card(ROAM,"8963662600123450001");
  check(DitoHomeIdentity.connection(another)==another,"different full ICCID uses its own current read without borrowing home history");
  check(!WifiConfigRuntime.cardKey(another).equals(WifiConfigRuntime.cardKey(roam)),"different DITO profiles remain isolated");
  String identityKey=restarted.store("wifi_calling_dito_identity_v1").data.keySet().iterator().next();
  restarted.store("wifi_calling_dito_identity_v1").data.put(identityKey,ROAM);
  check(DitoHomeIdentity.connection(reread)==reread,"invalid saved history falls back to the genuine current read");
  restarted.store("wifi_calling_dito_identity_v1").data.put(identityKey,"51566");
  check(DitoHomeIdentity.connection(reread)==reread,"invalid saved history falls back to the genuine current read");
  restarted.store("wifi_calling_dito_identity_v1").data.put(identityKey,HOME);

  // A DITO IIN covers other batches; same-card history improves the current-read fallback.
  for(String iccid:new String[]{"8963660000123455526","8963662601123455526","8963668800123455526"}){
   ek5 dito=card(ROAM,iccid);check(DitoHomeIdentity.isDito(dito),"other DITO batches are recognized by IIN");
   check(((xi5)CarrierPresets.defaults(dito,null)).c.equals("DITO"),"other batch receives DITO preset instead of Vodafone");
   check(DitoHomeIdentity.connection(dito)==dito,"other batch may register with its current read when no home record exists");
   ek5 actualHome=card(HOME,iccid);DitoHomeIdentity.observe(actualHome);
   check(((ek5)DitoHomeIdentity.connection(dito)).a.equals(HOME),"other batch restores only its actual recorded home identity");
  }
  // An arbitrary 20404 card and malformed ICCID are still not DITO evidence.
  for(String iccid:new String[]{"8948011234567890123","8963652601123455526",ICCID.substring(0,18),ICCID+"00","8963662600abcdefghi"}){
   ek5 foreign=card(ROAM,iccid);check(!DitoHomeIdentity.isDito(foreign),"reject non-DITO issuer or malformed ICCID");
   check(DitoHomeIdentity.connection(foreign)==foreign,"foreign card authentication is untouched");
   check(((xi5)CarrierPresets.defaults(foreign,null)).c.equals("Vodafone"),"genuine 20404 automatic carrier remains native");
   check(WifiConfigRuntime.cardKey(foreign).equals(legacy(foreign)),"foreign settings key unchanged");
  }
  for(ek5 invalid:new ek5[]{card("51566",ICCID),card("51566012345678x",ICCID),card("5156601234567890",ICCID)}){
   check(!DitoHomeIdentity.isDito(invalid),"invalid home identity rejected");DitoHomeIdentity.observe(invalid);
   check(((ek5)DitoHomeIdentity.connection(reread)).a.equals(HOME),"invalid read cannot poison existing verified identity");
  }
  for(ek5 recognized:new ek5[]{card("001010123456789",ICCID),new ek5(HOME,ICCID,3,null,null,null,null,null)}){
   check(DitoHomeIdentity.isDito(recognized),"valid issuer evidence survives another PLMN or inconsistent MNC length");
   DitoHomeIdentity.observe(recognized);
   check(((ek5)DitoHomeIdentity.connection(reread)).a.equals(HOME),"non-home read cannot poison existing verified identity");
  }
  ek5 alternateIssuer=card(HOME,"8901234500123450004"),alternateRoam=card(ROAM,alternateIssuer.b);
  check(!DitoHomeIdentity.isDito(alternateRoam),"unknown issuer's roaming identity alone is insufficient");
  DitoHomeIdentity.observe(alternateIssuer);
  check(DitoHomeIdentity.isDito(alternateRoam)&&((ek5)DitoHomeIdentity.connection(alternateRoam)).a.equals(HOME),"real same-card 51566 history supports an alternate ICCID issuer without guessing");
  ek5 nineteen=card("51566123456789","89636626001234567890");DitoHomeIdentity.observe(nineteen);
  check(((ek5)DitoHomeIdentity.connection(card(ROAM,nineteen.b))).a.equals(nineteen.a),"reference 14-digit IMSI and 20-digit ICCID lengths supported");

  // Migrate original settings atomically; SMSC/manual choices must survive identity changes.
  WifiConfigTest.Prefs settings=restarted.store("wifi_config_overrides_v1");
  Map<String,String> edits=values("smsc","+639111111111","smsc_list","+639111111111\n+639222222222","imei","490154203237518","domain","custom.ims.example.org");
  String previous=WifiConfigValues.encode(edits);settings.data.put(legacy(roam),previous);
  active(reread);WifiConfigRuntime.Snapshot snapshot=WifiConfigRuntime.snapshot();
  check(snapshot.values.equals(edits)&&snapshot.record.equals(previous),"roaming-key SMSC and other old edits migrate intact");
  check(settings.data.get(snapshot.key).equals(previous)&&settings.data.get(legacy(roam)).equals(previous),"verified stable copy retains legacy record for recovery");
  check(((gl5)zl5.b.value).i.equals("+639111111111")&&((gl5)zl5.b.value).f.g.equals("custom.ims.example.org"),"migrated edits remain effective");
  ek5 backHome=card(HOME,ICCID);active(backHome);
  check(WifiConfigRuntime.snapshot().values.equals(edits),"SMSC edits survive return to home IMSI");
  WifiConfigRuntime.Snapshot saved=WifiConfigRuntime.snapshot();Map<String,String> selected=CarrierPresets.selection(saved.values,"51566|dito_variant");
  WifiConfigRuntime.save(saved.key,saved.record,selected);active(card(ROAM,ICCID));
  check(WifiConfigRuntime.snapshot().values.get(CarrierPresets.KEY).equals("51566|dito_variant"),"explicit carrier variant survives roaming change");
  check(((gl5)zl5.b.value).f.r.startsWith("0"+HOME+"@"),"manual DITO preset also uses verified home credentials");
  gl5 variantState=(gl5)zl5.b.value;
  ek5 variantIdentity=(ek5)DitoHomeIdentity.connection(variantState.e,variantState.f);
  check(variantIdentity.a.equals(HOME)&&variantState.f.r.startsWith("0"+variantIdentity.a+"@"),"captured DITO variant config and connection use the same verified subscriber identity");
  saved=WifiConfigRuntime.snapshot();WifiConfigRuntime.save(saved.key,saved.record,Collections.<String,String>emptyMap());
  check(((gl5)zl5.b.value).f.c.equals("DITO")&&((gl5)zl5.b.value).f.r.startsWith("0"+HOME+"@"),"reset/automatic restores DITO home defaults");
  ek5 homeOnly=card("515669999999999","8963662600123450002");DitoHomeIdentity.observe(homeOnly);
  Map<String,String> fromHome=values("smsc","+639333333333");settings.data.put(legacy(homeOnly),WifiConfigValues.encode(fromHome));
  active(card(ROAM,homeOnly.b));check(WifiConfigRuntime.snapshot().values.equals(fromHome),"saved home-key edits migrate when first seen in roaming mode");
  ek5 failed=card("515668888888888","8963662600123450003");
  restarted.store("wifi_calling_dito_identity_v1").fail=true;
  reject(()->DitoHomeIdentity.observe(failed),"未能保存");
  ek5 afterFailedSave=card(ROAM,failed.b);check(DitoHomeIdentity.connection(afterFailedSave)==afterFailedSave,"failed home persistence cannot invent history or block a valid current read");
  // Learning failure warns but does not turn an otherwise successful SIM read into a read failure.
  restarted.store("wifi_calling_dito_identity_v1").fail=true;
  Object readAuth=new Object();IdentityBinding.begin(transport,readAuth);IdentityBinding.read(transport,readAuth,failed);Handler.drain();
  check(Toast.last.contains("未能保存")&&IdentityBinding.current(transport,readAuth),"storage failure leaves real USIM read usable and warns visibly");
  ek5 manual=card(ROAM,"8948011234567890007");active(manual);WifiConfigRuntime.Snapshot manualDraft=WifiConfigRuntime.snapshot();
  WifiConfigRuntime.save(manualDraft.key,manualDraft.record,values(CarrierPresets.KEY,DitoCarrierProfile.KEY));
  check(((gl5)zl5.b.value).f.c.equals("DITO"),"explicit DITO choice replaces a foreign automatic preset");
  check(DitoHomeIdentity.connection(manual)==manual,"manual DITO choice retains the genuine current identity without inventing history");
  System.out.println("PASS: "+passed+" DITO same-card home identity, authentication, isolation and settings migration assertions");
 }
}
