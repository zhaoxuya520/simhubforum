#!/usr/bin/env python3
"""Run the active Java regressions against this build's compiled helpers."""
from pathlib import Path
import argparse,json,os,re,subprocess
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--report',type=Path,required=True);args=p.parse_args()
tools=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
work=args.report.parent/'host-regressions';work.mkdir(parents=True,exist_ok=True)
classes=work/'classes';classes.mkdir(exist_ok=True)
sources=sorted(f for f in (ROOT/'tests').rglob('*.java')if f.name!='MultiChipSwitchTest.java')
cmd=['java','-jar',tools/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-cp',ROOT/'build-config3/classes','-d',classes,*sources]
r=subprocess.run(list(map(str,cmd)),capture_output=True,text=True)
(work/'compile.log').write_text(r.stdout+r.stderr)
if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
results=[]
for source in sorted((ROOT/'tests').glob('*Test.java')):
    if source.name=='MultiChipSwitchTest.java':continue
    name=source.stem
    r=subprocess.run(['java','-cp',str(classes)+os.pathsep+str(ROOT/'build-config3/classes'),name],capture_output=True,text=True)
    (work/(name+'.log')).write_text(r.stdout+r.stderr)
    print(name+': '+r.stdout.strip(),flush=True)
    if r.returncode:print(r.stderr);raise SystemExit(r.returncode)
    match=re.search(r'PASS: (\d+)',r.stdout)
    results.append(dict(test=name,passed=True,assertions=int(match[1])if match else None))
args.report.write_text(json.dumps(dict(tests=results,device_tested=False,platform_doubles=True),indent=2)+'\n')
