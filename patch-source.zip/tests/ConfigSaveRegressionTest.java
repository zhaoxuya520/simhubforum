import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import java.util.*;
public class ConfigSaveRegressionTest {
 static int passed;static final lu1 c=new lu1();
 static void check(boolean b,String why){if(!b)throw new AssertionError(why);passed++;}
 static void waitSave()throws Exception{long end=System.nanoTime()+2_000_000_000L;while(Handler.tasks.isEmpty()&&System.nanoTime()<end)Thread.sleep(5);check(!Handler.tasks.isEmpty(),"save callback completes");Handler.drain();}
 static void open(String row){WifiConfigEditor.row(row,"old",c,6);ak2.click.a();WifiConfigEditor.overlay(c);}
 public static void main(String[]args)throws Exception{
  WifiConfigTest.Ctx ctx=new WifiConfigTest.Ctx();zl5.f=ctx;ek5 card=new ek5("001010000000001","save-matrix");card.f="+441111111111";
  zl5.b.value=WifiConfigTest.state(card,zl3.r(card));WifiConfigRuntime.save(WifiConfigRuntime.cardKey(card),Collections.emptyMap());
  Activity owner=new Activity();int[] closed={0};us1 close=()->{closed[0]++;return sc5.a;};us1 done=(us1)WifiConfigEditor.begin(owner,close);
  String[][] cases={{"短信中心","+639111111111"},{"ePDG","mine.epdg.example.org"},{"IMEI","490154203237518"},{"Domain","mine.ims.example.org"},{"APN","custom.ims"},{"IP","ipv4"},{"IPsec","off"},{"Keepalive","45"},{"NAI","own@nai.example.org","own@ims.example.org","sip:own@ims.example.org","own@eap.example.org"},{"IKE","aes128","sha512","sha384","ecp256"},{"ESP","aes128","sha512"}};
  for(String[] row:cases){
   open(row[0]);check(ak2.edits.size()==row.length-1,"group field count "+row[0]);
   for(int i=1;i<row.length;i++)ak2.edits.get(i-1).change.i(row[i]);
   xq0.press("保存");waitSave();open(row[0]);
   for(int i=1;i<row.length;i++)check(ak2.edits.get(i-1).value.equals(row[i]),"saved field survives reopen "+row[0]+" #"+i);
   xq0.cancel.a();
  }
  open("短信中心");ak2.edits.get(0).change.i("+639222222222");
  gl5 before=(gl5)zl5.b.value;xi5 config=before.f;before.k.busy=true;
  xq0.press("保存");waitSave();
  check(((gl5)zl5.b.value).i.equals("+639222222222"),"edit existing SMSC then Save applies without a second select action");
  check(((gl5)zl5.b.value).f==config&&((gl5)zl5.b.value).k.busy,"SMSC popup save preserves active connection");
  done.a();check(closed[0]==1,"Done closes an already-saved page while connected without a second save");
  check(((gl5)zl5.b.value).i.equals("+639222222222")&&((gl5)zl5.b.value).f==config,"Done preserves the saved SMSC and active connection");
  before.k.busy=false;WifiConfigEditor.begin(owner,close);open("短信中心");check(ak2.edits.get(0).value.equals("+639222222222"),"changed existing number persists");xq0.cancel.a();
  ((us1)WifiConfigEditor.cancelCallback(close)).a();WifiConfigEditor.begin(owner,close);open("短信中心");
  check(ak2.edits.get(0).value.equals("+639222222222"),"SMS save survives dismissing the whole settings page");xq0.cancel.a();
  owner.destroy();check(c.depth==0,"Compose scopes remain balanced");
  System.out.println("PASS: "+passed+" all configuration groups edit-save-reopen and existing-SMSC regression assertions");
 }
}
