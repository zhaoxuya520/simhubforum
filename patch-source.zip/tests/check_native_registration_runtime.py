#!/usr/bin/env python3
"""Run actual shipped IMS response/parser/expiry/task code with scheduler/clock/log fixtures."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('apk',type=Path);p.add_argument('decoded',type=Path);p.add_argument('--report',type=Path,required=True);p.add_argument('--legacy',action='store_true');a=p.parse_args()
digest=hashlib.sha256(a.apk.read_bytes()).hexdigest()
carrier_report=a.report.parent/'native-carrier-runtime.json'
probe=a.report.parent/'native-carrier-current/probe.jar'
if not probe.exists() or not carrier_report.exists() or json.loads(carrier_report.read_text()).get('apk_sha256')!=digest:
 subprocess.run([sys.executable,str(ROOT/'tests/check_native_carrier_runtime.py'),str(a.apk),str(a.decoded),'--report',str(carrier_report)],check=True)
assert json.loads(carrier_report.read_text())['apk_sha256']==digest
work=a.report.parent/('native-registration-legacy' if a.legacy else 'native-registration-current');work.mkdir(parents=True,exist_ok=True)
classes=work/'classes';classes.mkdir(exist_ok=True)
android=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
cp=os.pathsep.join(map(str,[probe,android/'sdk/android-35/android.jar']))
sources=sorted((ROOT/'validation/native-registration').glob('*.java'))
compile=subprocess.run(['java','-jar',str(android/'ecj-3.40.0.jar'),'-8','-nowarn','-encoding','UTF-8','-cp',cp,'-d',str(classes),*map(str,sources)],capture_output=True,text=True)
assert compile.returncode==0,compile.stdout+compile.stderr
for name in ['o82','bh1','j82','x72','kb4','jb4','ls4','pl2']:
 assert not (classes/(name+'.class')).exists(),'Native implementation replaced: '+name
assert not (classes/'cc/forserein/simhub/internal/RegistrationTiming.class').exists()
r=subprocess.run(['java','-noverify','-cp',str(classes)+os.pathsep+cp,'NativeRegistrationProbe','legacy' if a.legacy else 'current'],capture_output=True,text=True)
(work/'probe.log').write_text(compile.stdout+compile.stderr+r.stdout+r.stderr)
print(r.stdout,end='');assert r.returncode==0,r.stderr
m=re.search(r'NATIVE_REGISTRATION (legacy_regression_reproduced|current_passed)=true checks=(\d+)',r.stdout);assert m,r.stdout
report=dict(apk_sha256=digest,normalized_dex_jar_sha256=hashlib.sha256(probe.read_bytes()).hexdigest(),checks=int(m[2]),legacy_regression_reproduced=a.legacy,
 actual_register_response_coroutine=True,actual_contact_expiry_parser=True,actual_refresh_task=True,actual_old_job_cancellation=not a.legacy,
 explicit_fixtures=['scheduler entry xq0','clock g7','log sink g11','synthetic REGISTER 200 response and resumed continuation'],
 exercised_ike_authentication=False,device_tested=False,art_execution=False)
a.report.write_text(json.dumps(report,indent=2)+'\n')
