#!/usr/bin/env python3
"""Run actual-final-APK fork checks using its SHA-matched carrier translation."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('apk',type=Path);p.add_argument('decoded',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1];carrier_report=a.report.parent/'native-carrier-runtime.json';carrier=json.loads(carrier_report.read_text());digest=hashlib.sha256(a.apk.read_bytes()).hexdigest();assert carrier['apk_sha256']==digest,'Carrier translation must match exact APK'
jar=carrier_report.parent/'native-carrier-current/probe.jar';assert jar.is_file(),jar
sys.path.insert(0,str(root));from sip_fork_patch import verify_sip_fork
verify_sip_fork(a.decoded/'smali')
subprocess.run([sys.executable,str(root/'validation/native-fork/sip_fork_check_runtime.py'),str(jar),'--report',str(a.report)],check=True)
result=json.loads(a.report.read_text());result.update(apk_sha256=digest,carrier_translation_report_sha256=hashlib.sha256(carrier_report.read_bytes()).hexdigest(),final_apk_executed=True);a.report.write_text(json.dumps(result,indent=2)+'\n')
