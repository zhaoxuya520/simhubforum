import cc.forserein.simhub.internal.*;
import android.widget.Toast;
import java.util.*;
public class SmsCenterSaveTest {
 static int passed;static void check(boolean b,String why){if(!b)throw new AssertionError(why);passed++;}
 static Map<String,String> v(String...s){Map<String,String>m=new LinkedHashMap<>();for(int i=0;i<s.length;i+=2)m.put(s[i],s[i+1]);return m;}
 static Map<String,String> stored(ek5 card)throws Exception{return WifiConfigValues.decode(((WifiConfigTest.Ctx)zl5.f).prefs.getString(WifiConfigRuntime.cardKey(card),"v1\n"));}
 static gl5 oldNativeWrite(gl5 s,String number){return new gl5(s.a,s.b,s.c,s.d,s.e,s.f,s.g,s.h,number,s.j,s.k,s.l,s.m,s.n,s.o,s.p,s.q,s.r,s.s,s.t);}
 interface Op{void run()throws Exception;}
 static void rejects(Op op)throws Exception{try{op.run();throw new AssertionError("accepted invalid save");}catch(IllegalStateException|IllegalArgumentException e){passed++;}}
 public static void main(String[]args)throws Exception{
  WifiConfigTest.Ctx ctx=new WifiConfigTest.Ctx();zl5.f=ctx;ek5 card=new ek5("001010000000001","sms-save");card.f="+441111111111";
  zl5.b.value=WifiConfigTest.state(card,zl3.r(card));String key=WifiConfigRuntime.cardKey(card);
  WifiConfigRuntime.save(key,v("domain","mine.example.org","smsc","+442222222222","smsc_list","+442222222222\n+443333333333","imei","490154203237518"));
  gl5 before=(gl5)zl5.b.value;
  check(oldNativeWrite(before,"+639999999999").i.equals("+442222222222"),"reproduce original setter losing its edit to stored overrides");
  before.k.busy=true;xi5 config=before.f;Object phase=before.k;
  WifiConfigRuntime.updateSmsCenter("00639999999999");gl5 current=(gl5)zl5.b.value;
  check(current.i.equals("+639999999999")&&WifiConfigRuntime.displaySmsCenter(card).equals(current.i),"native SMS-page save immediately changes the live and displayed value");
  check(current.f==config&&current.k==phase&&current.k.busy,"SMS-only save preserves the exact active IMS config and connection state");
  check(current.h.equals(before.h)&&current.j.equals(before.j)&&current.p==before.p&&current.q==before.q,"unrelated state and history retained");
  check(stored(card).get("smsc_list").equals("+639999999999\n+443333333333"),"editing current SMSC replaces old number and retains other saved numbers");
  check(stored(card).get("domain").equals("mine.example.org"),"carrier connection overrides retained");
  String stableRecord=ctx.prefs.getString(key,null);
  WifiConfigRuntime.updateSmsCenter("+");check(((gl5)zl5.b.value).i.equals("+")&&ctx.prefs.getString(key,null).equals(stableRecord),"native inline field accepts a typed plus without persisting invalid data");
  rejects(()->WifiConfigRuntime.requireSmsCenter());
  WifiConfigRuntime.updateSmsCenter("+6");check(((gl5)zl5.b.value).i.equals("+6"),"first country-code digit remains editable");
  WifiConfigRuntime.updateSmsCenter("+639999999999");check(((gl5)zl5.b.value).i.equals("+639999999999")&&ctx.prefs.getString(key,null).equals(stableRecord),"completing the number clears the transient draft and preserves storage");WifiConfigRuntime.requireSmsCenter();
  String record=ctx.prefs.getString(key,null);
  Map<String,String> same=new LinkedHashMap<>(stored(card));same.put("smsc","+443333333333");WifiConfigRuntime.saveSmsCenter(key,record,same);
  check(((gl5)zl5.b.value).i.equals("+443333333333"),"list selection uses the same live save path");
  final String staleRecord=record;rejects(()->WifiConfigRuntime.saveSmsCenter(key,staleRecord,same));
  record=ctx.prefs.getString(key,null);final String latest=record;
  Map<String,String> forbidden=new LinkedHashMap<>(stored(card));forbidden.put("domain","other.example.org");
  rejects(()->WifiConfigRuntime.saveSmsCenter(key,latest,forbidden));check(ctx.prefs.getString(key,null).equals(record)&&((gl5)zl5.b.value).f==config,"SMS-only permission cannot change IMS fields");
  ctx.prefs.fail=true;WifiConfigRuntime.updateSmsCenter("+638888888888");
  check(Toast.last.contains("保存失败")&&((gl5)zl5.b.value).i.equals("+443333333333")&&ctx.prefs.getString(key,null).equals(record),"storage failure is visible and retains previous number");
  WifiConfigRuntime.updateSmsCenter("invalid");check(Toast.last.contains("短信中心")&&ctx.prefs.getString(key,null).equals(record),"invalid number reports error without corrupting saved settings");
  WifiConfigRuntime.updateSmsCenter("");
  check(!stored(card).containsKey("smsc")&&!stored(card).containsKey("smsc_list")&&WifiConfigRuntime.displaySmsCenter(card).equals(card.f),"clearing original edit restores the card default");
  ((gl5)zl5.b.value).k.busy=false;WifiConfigRuntime.updateSmsCenter("+637777777777");
  ek5 reread=new ek5(card.a,card.b);reread.f=card.f;zl5.b.value=WifiConfigTest.state(reread,zl3.r(reread));
  check(((gl5)zl5.b.value).i.equals("+637777777777"),"saved number survives reread and a new card model");
  ek5 other=new ek5("001010000000002","other-sms-card");other.f="+445555555555";zl5.b.value=WifiConfigTest.state(other,zl3.r(other));
  WifiConfigRuntime.updateSmsCenter("+");WifiConfigRuntime.updateSmsCenter("+6");check(((gl5)zl5.b.value).i.equals("+6")&&ctx.prefs.getString(WifiConfigRuntime.cardKey(other),null)==null,"first-ever native edit accepts partial input without creating a damaged record");
  WifiConfigRuntime.updateSmsCenter("+636666666666");check(((gl5)zl5.b.value).i.equals("+636666666666")&&stored(card).get("smsc").equals("+637777777777"),"other card saves stay isolated");
  check(stored(other).get("imei").equals("490154203237518")&&stored(other).get("epdg").equals("legacy.epdg.example.org"),"first native save migrates device and endpoint settings without resetting them");
  WifiConfigRuntime.updateSmsCenter("+");Map<String,String> confirmed=stored(other);WifiConfigRuntime.save(WifiConfigRuntime.cardKey(other),confirmed);
  check(((gl5)zl5.b.value).i.equals(confirmed.get("smsc")),"saving a confirmed settings snapshot discards an unfinished native SMSC draft");WifiConfigRuntime.requireSmsCenter();
  WifiConfigRuntime.updateSmsCenter("+6");ek5 fresh=new ek5(other.a,other.b);fresh.f=other.f;zl5.b.value=WifiConfigTest.state(fresh,zl3.r(fresh));
  check(((gl5)zl5.b.value).i.equals(confirmed.get("smsc")),"fresh card read restores the last valid saved number rather than a partial draft");
  System.out.println("PASS: "+passed+" original SMS-page save, active connection, persistence and rollback assertions");
 }
}
