import cc.forserein.simhub.internal.*;
import java.util.*;
public class SmsCenterDispatchTest {
 public static final class LegacySettings {public android.content.SharedPreferences a;LegacySettings(android.content.SharedPreferences prefs){a=prefs;}}
 public static final class Engine {public Object c;Engine(Object card){c=card;}}
 static int checks;static void check(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
 interface Op{void run()throws Exception;}
 static void reject(Op op,String fragment)throws Exception{try{op.run();throw new AssertionError("accepted invalid SMS dispatch");}catch(IllegalStateException expected){check(expected.getMessage().contains(fragment),"actionable rejection: "+expected.getMessage());}}
 static WifiConfigTest.Ctx context;static ek5 card;static Engine engine;static String key;
 static void fresh(String record)throws Exception {
  context=new WifiConfigTest.Ctx();zl5.f=context;zl5.legacySettings=null;card=new ek5("001010000000001","sms-dispatch");card.f="+441111111111";engine=new Engine(card);
  key=WifiConfigRuntime.cardKey(card);if(record!=null)context.prefs.data.put(key,record);zl5.b.value=WifiConfigTest.state(card,zl3.r(card));
 }
 static String sendValue()throws Exception{return WifiConfigRuntime.prepareSmsCenter(engine);}
 static Map<String,String> values(String...args){Map<String,String> out=new LinkedHashMap<>();for(int i=0;i<args.length;i+=2)out.put(args[i],args[i+1]);return out;}
 public static void main(String[]args)throws Exception {
  fresh("v1\nsmsc\t+442222222222\n    ");String old=context.prefs.getString(key,null);
  check(sendValue().equals("+442222222222"),"actual cold-read suffix retains explicit center at send boundary");
  check(context.prefs.getString(key,null).equals(old),"reading compatibility does not rewrite disk");
  WifiConfigRuntime.Snapshot snapshot=WifiConfigRuntime.smsSnapshot();
  check(!snapshot.needsRepair&&snapshot.values.get("smsc").equals("+442222222222"),"cold-read record opens as a normal SMS editor draft");
  Map<String,String> edit=new LinkedHashMap<>(snapshot.values);edit.put("smsc","+443333333333");edit.put("smsc_list","+443333333333\n+444444444444");
  WifiConfigRuntime.saveSmsCenter(snapshot.key,snapshot.record,edit);
  check(sendValue().equals("+443333333333"),"SMS editor change is returned for actual transmission");
  check(!context.prefs.getString(key,null).endsWith("\n"),"saved replacement avoids LF suffix");
  check(WifiConfigValues.decode(context.prefs.getString(key,null)).get("smsc_list").contains("+444444444444"),"saving selected center retains alternatives");
  fresh("v1\ndomain\tims.example.org\nsmsc\t+442222222222\nsmsc_list\t+442222222222 +443333333333\n    ");
  check(sendValue().equals("+442222222222"),"combined native-compatible values survive real cold-read layout");
  snapshot=WifiConfigRuntime.smsSnapshot();edit=new LinkedHashMap<>(snapshot.values);edit.put("smsc","+443333333333");
  ((gl5)zl5.b.value).k.busy=true;Object config=((gl5)zl5.b.value).f;
  WifiConfigRuntime.saveSmsCenter(snapshot.key,snapshot.record,edit);
  check(sendValue().equals("+443333333333")&&((gl5)zl5.b.value).f==config,"connected SMS-only save retains IMS config");
  check(WifiConfigValues.decode(context.prefs.getString(key,null)).get("domain").equals("ims.example.org"),"SMS save preserves other fields");
  fresh(null);check(sendValue().equals(card.f),"no saved override uses this current card EF_SMSP");
  // A legacy state-level string is not proof that the number belongs to this card.
  gl5 before=(gl5)zl5.b.value;
  zl5.b.value=new gl5(before.a,before.b,before.c,before.d,before.e,before.f,before.g,before.h,"+499999999999",before.j,before.k,before.l,before.m,before.n,before.o,before.p,before.q,before.r,before.s,before.t);
  check(sendValue().equals(card.f),"previous/global legacy SMSC cannot override current card");
  card.f=null;reject(()->sendValue(),"此卡的短信中心");
  fresh("v1\nsmsc_list\t[]\n    ");reject(()->sendValue(),"先添加短信中心");
  fresh("v1\nsmsc\t+\n    ");reject(()->sendValue(),"配置无法读取");
  fresh("v1\nsmsc\t+442222222222\nsmsc\t+443333333333\n    ");reject(()->sendValue(),"配置无法读取");
  fresh("v1\nsmsc\t+442222222222\ncorrupt");old=context.prefs.getString(key,null);reject(()->sendValue(),"配置无法读取");
  check(context.prefs.getString(key,null).equals(old),"genuine damaged record never silently reset");
  fresh(null);WifiConfigRuntime.updateSmsCenter("+");reject(()->sendValue(),"完整的短信中心");
  fresh(null);ek5 another=new ek5("001010000000002","second-sms-card");another.f="+455555555555";
  zl5.b.value=WifiConfigTest.state(another,zl3.r(another));reject(()->sendValue(),"卡片已切换");
  check(WifiConfigRuntime.prepareSmsCenter(new Engine(another)).equals(another.f),"new captured connection uses its own physical center");
  fresh("v1\nsmsc\t+442222222222\n    ");ek5 reread=new ek5(card.a,card.b);reread.f=card.f;
  zl5.b.value=WifiConfigTest.state(reread,zl3.r(reread));check(sendValue().equals("+442222222222"),"same card reread is accepted without requiring identical Java object");
  reject(()->WifiConfigRuntime.prepareSmsCenter(null),"卡片已切换");
  fresh(null);card=new ek5("234151234567890","8944111234567890123");card.f="+447700000111";engine=new Engine(card);
  key=WifiConfigRuntime.cardKey(card);zl5.b.value=WifiConfigTest.state(card,zl3.r(card));
  WifiConfigTest.Prefs legacy=new WifiConfigTest.Prefs();zl5.legacySettings=new LegacySettings(legacy);
  String legacyKey="vowifi_sms_smsc_"+card.b;legacy.data.put(legacyKey," +44 (7700) 000222 ");
  check(sendValue().equals("+447700000222"),"author-version persisted same-ICCID override precedes EF_SMSP");
  check(context.prefs.getString(key,null)==null&&legacy.data.get(legacyKey).equals(" +44 (7700) 000222 "),"legacy read never rewrites either preference store");
  legacy.data.remove(legacyKey);legacy.data.put("vowifi_sms_smsc_8944111234567890999","+447700000333");
  check(sendValue().equals(card.f),"another ICCID legacy override cannot leak into current card");
  legacy.data.put(legacyKey,"+");check(sendValue().equals(card.f),"invalid old center falls back only to current EF_SMSP");
  legacy.data.put(legacyKey,"not-a-number");card.f=null;reject(()->sendValue(),"此卡的短信中心");card.f="+447700000111";
  legacy.data.put(legacyKey,"+447700000222");context.prefs.data.put(key,"v1\n    ");
  check(sendValue().equals(card.f),"managed empty reset does not resurrect old center");
  context.prefs.data.put(key,"v1\nsmsc_list\t[]\n    ");reject(()->sendValue(),"先添加短信中心");
  context.prefs.data.put(key,"v1\nsmsc\t+447700000444");
  check(sendValue().equals("+447700000444"),"managed choice wins over author override and EF_SMSP");
  context.prefs.data.remove(key);legacy.data.put(legacyKey,"");check(sendValue().equals(card.f),"blank old center uses current EF_SMSP");
  legacy.data.put(legacyKey,"+447700000222");ek5 missing=new ek5(card.a,"");missing.f="+447700000555";
  legacy.data.put("vowifi_sms_smsc_","+447700000666");zl5.b.value=WifiConfigTest.state(missing,zl3.r(missing));
  check(WifiConfigRuntime.prepareSmsCenter(new Engine(missing)).equals(missing.f),"missing ICCID never uses a shared legacy key");
  ek5 shortId=new ek5(card.a,"12345");shortId.f="+447700000777";legacy.data.put("vowifi_sms_smsc_12345","+447700000888");
  zl5.b.value=WifiConfigTest.state(shortId,zl3.r(shortId));
  check(WifiConfigRuntime.prepareSmsCenter(new Engine(shortId)).equals(shortId.f),"invalid ICCID never permits legacy lookup");
  zl5.legacySettings=null;
  System.out.println("PASS: "+checks+" bound SMS-center dispatch and cold-read save assertions");
 }
}
