import cc.forserein.simhub.internal.MultiChipSwitch;
import java.util.*;
public class MultiChipSwitchTest {
 static int passed;
 static void check(boolean b){if(!b)throw new AssertionError();passed++;}
 public static class Profile {public String a;public boolean b;Profile(String a,boolean b){this.a=a;this.b=b;}}
 public static class Chip {public String b;public List<Profile>d;Chip(String b,Profile...p){this.b=b;d=new ArrayList<>(Arrays.asList(p));}}
 public static class Controller {
  public List<Chip> chips;public String selected;public String lastRead;public List<?> shown;public Object d;public boolean immutableReads;public int enableCommands,disableCommands;
  Controller(Chip...c){chips=Arrays.asList(c);selected=c[0].b;}
  public List<Chip> l(){return chips;}public String r(){return selected;}
  public void D(String eid){if(MultiChipSwitch.allowSelection(this))selected=eid;}public void J(List<?>v){shown=v;}public void K(){}
  List<Profile> physical(){for(Chip c:chips)if(c.b.equals(selected))return c.d;throw new AssertionError();}
  List<Profile> read(){lastRead=selected;if(!immutableReads)return physical();List<Profile> copy=new ArrayList<>();for(Profile p:physical())copy.add(new Profile(p.a,p.b));return copy;}
 }
 public static class Backend {public Object a=new Object();public final List<String> logs=new ArrayList<>();public void u(String s){logs.add(s);}}
 static void run(Controller c,MultiChipSwitch p,boolean ignoreDisable)throws Exception {
  p.next(null);int reads=0,changes=0;
  while(p.kind!=0){
   if(p.kind==1){reads++;p.next(c.read());}
   else {changes++;if(p.enabled)c.enableCommands++;else c.disableCommands++;check(reads>=c.chips.size());Profile profile=(Profile)p.profile;
    Profile actual=null;for(Profile q:c.physical())if(q.a.equals(profile.a))actual=q;
    check(actual!=null);
    if(p.enabled || !ignoreDisable)actual.b=p.enabled;
    p.next(null);
   }
   if(reads+changes>30)throw new AssertionError("loop");
  }
  check(reads>=c.chips.size()*2);check(c.selected.equals(c.lastRead));
 }
 public static void main(String[]args)throws Exception {
  Profile a=new Profile("a",true),b=new Profile("b",false);
  Controller c=new Controller(new Chip("8962",a),new Chip("9059",b));
  run(c,new MultiChipSwitch(c,b,true),false);check(!a.b&&b.b&&c.selected.equals("9059"));
  run(c,new MultiChipSwitch(c,a,true),false);check(a.b&&!b.b&&c.selected.equals("8962"));
  // Both initially active: enabling a target cleans up the other chip.
  int previousEnables=c.enableCommands;
  b.b=true;run(c,new MultiChipSwitch(c,a,true),false);check(a.b&&!b.b);
  check(c.enableCommands==previousEnables);
  int previousDisables=c.disableCommands;run(c,new MultiChipSwitch(c,a,true),false);
  check(c.enableCommands==previousEnables && c.disableCommands==previousDisables);
  // Cached disabled profile becomes active: fresh reads, rather than cached UI, decide cleanup.
  a.b=true;b.b=false;MultiChipSwitch p=new MultiChipSwitch(c,b,true);run(c,p,false);check(!a.b&&b.b);
  // Failure to disable must not be accepted as a successful final transaction.
  a.b=true;b.b=false;p=new MultiChipSwitch(c,b,true);
  try{run(c,p,true);throw new AssertionError("accepted multiple active profiles");}catch(IllegalStateException expected){check(!b.b);p.restore();check(c.selected.equals("9059"));}
  // Disable does not disable another chip's active profile.
  a.b=true;b.b=true;run(c,new MultiChipSwitch(c,b,false),false);check(a.b&&!b.b);
  // Failed scan stops before any mutation.
  p=new MultiChipSwitch(c,a,true);p.next(null);
  try{p.next(null);throw new AssertionError();}catch(IllegalStateException expected){check(a.b);p.restore();}
  Profile duplicate=new Profile("a",true);
  try{new MultiChipSwitch(new Controller(new Chip("x",a),new Chip("y",duplicate)),a,true);throw new AssertionError();}catch(IllegalStateException expected){check(true);}
  c.immutableReads=true;a.b=true;b.b=false;run(c,new MultiChipSwitch(c,b,true),false);check(!a.b&&b.b);
  run(c,new MultiChipSwitch(c,a,true),false);check(a.b&&!b.b);
  Backend backend=new Backend();c.d=backend;
  check(MultiChipSwitch.shouldCoordinate(c,backend));
  Controller single=new Controller(new Chip("single",a));check(!MultiChipSwitch.shouldCoordinate(single,backend));
  p=MultiChipSwitch.create(c,backend,a,true);p.next(null);
  String locked=c.selected;c.D("other");check(c.selected.equals(locked));
  check(!MultiChipSwitch.allowSelection(c));p.restore();check(MultiChipSwitch.allowSelection(c));
  c.D("other");check(c.selected.equals("other"));
  MultiChipSwitch.verifyEid("89000000000000000000000000008962","89000000000000000000000000008962");check(true);
  try{MultiChipSwitch.verifyEid("89000000000000000000000000008962","89000000000000000000000000009059");throw new AssertionError();}catch(IllegalStateException expected){check(expected.getMessage().contains("不匹配"));check(!expected.getMessage().contains("89000000000000000000000000008962"));}
  p=MultiChipSwitch.create(c,backend,a,true);c.d=new Backend();
  try{p.next(null);throw new AssertionError();}catch(IllegalStateException expected){p.restore();check(MultiChipSwitch.allowSelection(c));}
  check(!backend.logs.isEmpty());
  System.out.println("PASS: "+passed+" multi-chip transaction assertions");
 }
}
