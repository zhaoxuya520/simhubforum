import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Handler;
import android.widget.Toast;
import java.util.*;

/** Exercise actual editor callbacks, including unchanged recovery drafts. */
public class WifiConfigRepairUiTest {
 static int passed,closed;static us1 done;static Activity activity;static Ctx ctx;static ek5 card;
 static final lu1 composer=new lu1();
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);passed++;}
 static class CountingPrefs extends WifiConfigTest.Prefs {
  int commits;
  public SharedPreferences.Editor edit(){final SharedPreferences.Editor delegate=super.edit();return new SharedPreferences.Editor(){
   public SharedPreferences.Editor putString(String key,String value){delegate.putString(key,value);return this;}
   public SharedPreferences.Editor remove(String key){delegate.remove(key);return this;}
   public boolean commit(){commits++;return delegate.commit();}
  };}
 }
 public static class Ctx extends DitoHomeIdentityTest.Ctx {
  public SharedPreferences getSharedPreferences(String name,int mode){if(!stores.containsKey(name))stores.put(name,new CountingPrefs());return stores.get(name);}
 }
 static CountingPrefs prefs(){return (CountingPrefs)ctx.store("wifi_config_overrides_v1");}
 static String badKey(){return WifiConfigValues.encode(Collections.singletonMap(CarrierPresets.KEY,"51566|missing_saved_template"));}
 static String init(String record,boolean legacy)throws Exception {
  Handler.drain();closed=0;ctx=new Ctx();zl5.f=ctx;card=DitoHomeIdentityTest.card("204049876543210","8963668800123459991");
  String key=WifiConfigRuntime.cardKey(card);
  if(record!=null)prefs().data.put(legacy?WifiConfigValues.digest(card.b+"\n"+card.a):key,record);
  zl5.b.value=WifiConfigTest.state(card,zl3.r(card));activity=new Activity();
  done=(us1)WifiConfigEditor.begin(activity,(us1)()->{closed++;return sc5.a;});return key;
 }
 static void waitSave()throws Exception {
  long end=System.nanoTime()+2_000_000_000L;while(Handler.tasks.isEmpty()&&System.nanoTime()<end)Thread.sleep(5);
  check(!Handler.tasks.isEmpty(),"background editor save completed");Handler.drain();
 }
 static void repair(String bad,boolean legacy)throws Exception {
  String key=init(bad,legacy);WifiConfigRuntime.Snapshot before=WifiConfigRuntime.snapshot();
  check(before.needsRepair&&before.values.isEmpty(),"invalid record explicitly marks an empty recovery draft");
  check(Objects.equals(before.record,legacy?null:bad),"snapshot retains correct destination revision");
  done.a();check(closed==0,"Done waits for persistence even when recovery values were not edited");waitSave();
  check(closed==1&&WifiConfigValues.decode(prefs().getString(key,null)).isEmpty(),"Done writes an explicit managed-empty repair then closes");
  check(!WifiConfigRuntime.snapshot().needsRepair,"reopening no longer sees a damaged record");
  if(legacy)check(bad.equals(prefs().data.get(WifiConfigValues.digest(card.b+"\n"+card.a))),"repair preserves legacy recovery source");
  check(activity.app.callbacks.isEmpty(),"successful repair releases page lifecycle callback");activity.destroy();
 }
 public static void main(String[]args)throws Exception {
  repair(badKey(),false);repair("v1\nunknown\tbroken\n",false);repair("v1\nunknown\tbroken\n",true);
  String bad=badKey(),key=init(bad,false);int writes=prefs().commits;
  ((us1)WifiConfigEditor.cancelCallback(null)).a();
  check(closed==1&&bad.equals(prefs().getString(key,null))&&prefs().commits==writes,"Cancel preserves exact damaged record without writing");activity.destroy();
  key=init(bad,false);prefs().fail=true;done.a();waitSave();
  check(closed==0&&bad.equals(prefs().getString(key,null))&&Toast.last.contains("保存失败"),"failed repair stays open and restores original record");
  done.a();waitSave();check(closed==1&&WifiConfigValues.decode(prefs().getString(key,null)).isEmpty(),"unchanged recovery can retry after failure");activity.destroy();
  key=init(bad,false);String newer=WifiConfigValues.encode(Collections.singletonMap("domain","newer.example.org"));prefs().data.put(key,newer);
  done.a();waitSave();check(closed==0&&newer.equals(prefs().getString(key,null))&&Toast.last.contains("其他操作"),"recovery Done cannot overwrite a newer saved revision");
  ((us1)WifiConfigEditor.cancelCallback(null)).a();activity.destroy();
  for(String record:new String[]{WifiConfigValues.encode(Collections.<String,String>emptyMap()),null}){
   key=init(record,false);writes=prefs().commits;check(!WifiConfigRuntime.snapshot().needsRepair,"valid untouched page needs no repair");
   done.a();check(closed==1&&prefs().commits==writes&&Objects.equals(record,prefs().getString(key,null)),"unchanged valid or unmanaged page closes without creating a record");activity.destroy();
  }
  key=init(bad,false);WifiConfigEditor.row("Domain","old",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);
  xq0.press("重置为内置");waitSave();writes=prefs().commits;done.a();
  check(closed==1&&prefs().commits==writes,"successful field reset clears repair flag before page Done");activity.destroy();
  check(composer.depth==0,"recovery editor Compose groups remain balanced");
  System.out.println("PASS: "+passed+" editor Done recovery, cancellation, revision and retry assertions");
 }
}
