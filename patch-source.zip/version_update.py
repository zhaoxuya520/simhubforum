"""Change only the app version attributes in the pinned binary Android manifest."""
import struct
from pathlib import Path

VERSION_NAME='24.2'
VERSION_CODE=21

def manifest_version(data,update=False):
    b=bytearray(data);strings=[];locations=[];result={};pos=8
    assert struct.unpack_from('<HHI',b,0)==(3,8,len(b))
    while pos<len(b):
        typ,header,size=struct.unpack_from('<HHI',b,pos)
        assert size>=header and pos+size<=len(b)
        if typ==1:
            count,_,flags,start,_=struct.unpack_from('<IIIII',b,pos+8)
            def length(at,utf8):
                if utf8:
                    v=b[at];return (((v&127)<<8)|b[at+1],at+2) if v&128 else (v,at+1)
                v=struct.unpack_from('<H',b,at)[0]
                return (((v&32767)<<16)|struct.unpack_from('<H',b,at+2)[0],at+4) if v&32768 else (v,at+2)
            for i in range(count):
                at=pos+start+struct.unpack_from('<I',b,pos+header+4*i)[0]
                n,at=length(at,bool(flags&256))
                if flags&256:n,at=length(at,True)
                else:n*=2
                encoding='utf-8' if flags&256 else 'utf-16le'
                strings.append(bytes(b[at:at+n]).decode(encoding));locations.append((at,n,encoding))
        elif typ==0x102:
            ext=pos+16;name=struct.unpack_from('<I',b,ext+4)[0]
            if strings[name]=='manifest':
                offset,width,count=struct.unpack_from('<HHH',b,ext+8)
                for i in range(count):
                    at=ext+offset+i*width;_,name,raw=struct.unpack_from('<III',b,at);kind=b[at+15];value=struct.unpack_from('<I',b,at+16)[0]
                    key=strings[name]
                    if key=='versionCode':
                        assert kind==16;result[key]=value
                        if update:
                            assert value==10;struct.pack_into('<I',b,at+16,VERSION_CODE)
                    elif key=='versionName':
                        assert kind==3;result[key]=strings[value]
                        if update:
                            assert strings[value]=='23.1'
                            p,n,encoding=locations[value];replacement=VERSION_NAME.encode(encoding)
                            assert len(replacement)==n;b[p:p+n]=replacement
        pos+=size
    assert set(result)=={'versionCode','versionName'}
    return bytes(b) if update else result

def apply_version(decoded:Path):
    p=decoded/'AndroidManifest.xml';p.write_bytes(manifest_version(p.read_bytes(),True))
    about=decoded/'smali/r75.smali';text=about.read_text()
    assert text.count('"SIMHub Android 23.1"')==1
    about.write_text(text.replace('"SIMHub Android 23.1"','"SIMHub Android '+VERSION_NAME+'"'))
