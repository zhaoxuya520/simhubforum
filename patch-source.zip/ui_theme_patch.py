"""Shared Compose design tokens and dimensions; no action callbacks or UI state changes."""
from pathlib import Path
import hashlib,json,re
import wifi_editor_style as wifi

BASELINE={
 'z55.smali':'63155a0c1a639fa67456273b0f8b0c15ab8d47a4644a9e4f3831dc39a7a7c66b',
 'yd2.smali':'4df177b80d60728a46143e419c787cd6612403046622a783b08b86c2b28eddff',
 'fj2.smali':'f0a3e2df7a2bd66d86299d781e888119952b464a7b5412bd6f29cac3e5f9719b',
 'ak2.smali':'0e3ec9176448f1c98ff893e649dfc035c61182dc3711b3b78723f2c3d4340407',
 'xq0.smali':'97dfc5918c1bb4f0473367060dc51cf11198a32c74e66b1c82a603746801d4ee',
}
ROLES=['blue','green','orange','red','label','secondaryLabel','tertiaryLabel','separator',
       'systemBackground','secondarySystemBackground','groupedBackground','secondaryGroupedBackground','fill','tertiaryFill']
LIGHT=['2563EB','16824B','B75B08','D62D3A','17233A','53627A','63718A','DCE4EF','FFFFFF','F3F6FB','F3F6FB','FFFFFF','E6EDF6','EFF3F9']
DARK=['7AB2FF','5AD294','FFBD6C','FF8990','F1F5FC','B3C1D7','93A4BF','344359','101825','1B2738','101825','1B2738','2D3C51','233147']
UI_CLASSES=set(BASELINE)

def primary_helper():
 labels=['保存','确认','确定','完成','继续','Save','Confirm','OK','Done','Continue']
 text='''
.method public static simhubPrimary(Lcj2;)Z
    .locals 2
    iget-boolean v0, p0, Lcj2;->c:Z
    if-eqz v0, :not_primary
    iget-object v0, p0, Lcj2;->b:Lij2;
    sget-object v1, Lij2;->T:Lij2;
    if-ne v0, v1, :not_primary
    iget-object v0, p0, Lcj2;->a:Ljava/lang/String;
'''
 for label in labels:
  label=''.join(('\\u%04x'%ord(ch))if ord(ch)>127 else ch for ch in label)
  text+=f'''    const-string v1, "{label}"
    invoke-virtual {{v1, v0}}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v1
    if-nez v1, :primary
'''
 return text+'''    :not_primary
    const/4 v0, 0x0
    return v0
    :primary
    const/4 v0, 0x1
    return v0
.end method
'''

def primary_edits(name):
 # Both native renderers keep their disabled check, press interaction source and
 # original onClick. v18 is dead until after the background is drawn.
 composer,theme,temp,bg,modifier,anchor=('v1','v2','v8','v7','v3',':goto_3')if name=='a'else('v2','v3','v6','v5','v4',':goto_4')
 setup=f'''    {anchor}
    invoke-static {{v0}}, Lxq0;->simhubPrimary(Lcj2;)Z
    move-result v18
    if-eqz v18, :simhub_foreground_ready
    iget-boolean {temp}, {theme}, Ljj2;->a:Z
    if-eqz {temp}, :simhub_light_primary
    const-wide v16, {packed('101825')}
    goto :simhub_foreground_ready
    :simhub_light_primary
    const-wide v16, {packed('FFFFFF')}
    :simhub_foreground_ready'''
 bg2='v8'if name=='a'else'v6'
 shape=f'    sget-object {theme}, Lgi2;->l:Lp32;'
 filled=f'''    if-eqz v18, :simhub_background_ready
    sget-object {theme}, Lz55;->c:Lhu4;
    invoke-virtual {{{composer}, {theme}}}, Llu1;->k(Lrv3;)Ljava/lang/Object;
    move-result-object {theme}
    check-cast {theme}, Ljj2;
    iget-wide v11, {theme}, Ljj2;->b:J
    invoke-static {{{bg}, {bg2}, v11, v12}}, Lf93;->p(JJ)J
    move-result-wide {bg}
    :simhub_background_ready
    sget-object {theme}, Lgi2;->l:Lp32;
    if-eqz v18, :simhub_shape_ready
    const/high16 {theme}, 0x41400000    # 12.0f
    invoke-static {{{theme}}}, Lp74;->b(F)Lo74;
    move-result-object {theme}
    :simhub_shape_ready
    check-cast {theme}, Lim4;'''
 edits=[('    '+anchor,setup),(shape,filled)]
 if name=='b':
  old='    invoke-static {v3}, Lxq0;->u(Lij2;)Ls55;\n\n    move-result-object v19'
  # Original APK line metadata may intervene between invoke and move-result.
  edits.append(('    invoke-static {v3}, Lxq0;->u(Lij2;)Ls55;',
'''    invoke-static {v0}, Lxq0;->simhubPrimary(Lcj2;)Z
    move-result v4
    if-eqz v4, :simhub_normal_weight
    sget-object v19, Lmk2;->d:Ls55;
    goto :simhub_weight_ready
    :simhub_normal_weight
    invoke-static {v3}, Lxq0;->u(Lij2;)Ls55;'''))
  edits.append(('    move-result-object v19','    move-result-object v19\n    :simhub_weight_ready'))
 else:
  old='    sget-object v3, Lij2;->U:Lij2;'
  edits.append((old,'''    invoke-static {v0}, Lxq0;->simhubPrimary(Lcj2;)Z
    move-result v3
    if-nez v3, :simhub_primary_weight
'''+old))
  edits.append(('    sget-object v3, Lnq1;->X:Lnq1;','    :simhub_primary_weight\n    sget-object v3, Lnq1;->X:Lnq1;'))
 anchor = f'    invoke-interface {{{bg}}}, Lot4;->getValue()Ljava/lang/Object;'
 edits.append((anchor, f'    invoke-static {{{modifier}, {theme}}}, Lz55;->wifiActionInset(Lr53;Ljj2;)Lr53;\n    move-result-object {modifier}\n'+anchor))
 return edits

def packed(color):
 value=(0xff000000|int(color,16))<<32
 return '-0x%xL'%((1<<64)-value)

def palette_block(start,colors):
 return '\n    # SIMHub shared visual tokens; native Compose sRGB packed colors.\n'+''.join(
  '    const-wide v%d, %s    # %s #%s\n'%(start+2*i,packed(color),role,color)
  for i,(role,color)in enumerate(zip(ROLES,colors)))

def method(text,name):
 match=re.search(r'^\.method .*? '+re.escape(name)+r'\([^\n]*\n',text,re.M)
 assert match,name
 end=text.index('.end method',match.start())+len('.end method')
 return match.start(),end,text[match.start():end]

def replace_method(text,name,edits,reverse=False):
 start,end,body=method(text,name)
 for old,new in (reversed(edits)if reverse else edits):
  a,b=(new,old)if reverse else(old,new)
  assert body.count(a)==1,(name,a)
  body=body.replace(a,b)
 return text[:start]+body+text[end:]

def dimension_edits():
 return {
  'yd2.smali':{'j':[
    ('    new-instance v3, Ldm5;', '    invoke-static {v0}, Lz55;->wifiPalette(Ljj2;)Ljj2;\n    move-result-object v0\n    new-instance v3, Ldm5;'),
    ('    const v0, -0x40ee5747','    invoke-static {v3}, Lcc/forserein/simhub/internal/WifiConfigEditor;->sheetContent(Ljava/lang/Object;)Ljava/lang/Object;\n    move-result-object v3\n    check-cast v3, Llt1;\n    const v0, -0x40ee5747')
  ]},
  'fj2.smali':{'d':[(wifi.SURFACE_CALL,wifi.SURFACE_EDIT)]},
  'ak2.smali':{
   'd':[
    ('const/high16 v10, 0x42300000    # 44.0f','const/high16 v10, 0x42500000    # 52.0f'),
    ('const/high16 v3, 0x41800000    # 16.0f','const/high16 v3, 0x41900000    # 18.0f'),
    ('const/high16 v6, 0x41300000    # 11.0f','const/high16 v6, 0x41600000    # 14.0f'),
   ],
   'e':[
    ('const/high16 v12, 0x41800000    # 16.0f','const/high16 v12, 0x41900000    # 18.0f'),
    ('const/high16 v8, 0x41200000    # 10.0f','const/high16 v8, 0x41900000    # 18.0f'),
    ('const/high16 v2, 0x41b00000    # 22.0f','const/high16 v2, 0x41900000    # 18.0f'),
    # v8 is now the ordinary card radius; shadow radius is independently 4dp.
    ('    move v13, v8\n','    const/high16 v13, 0x40800000    # 4.0f\n'),
    ('const-wide v8, 0xd91c1c1eL','const-wide v8, 0xff1b2738L'),
   ],
  },
  'xq0.smali':{
   'k':[('    const v1, -0x326ec0e0','    invoke-static {v0,v7}, Lz55;->wifiDialogContent(Llt1;Llu1;)Llt1;\n    move-result-object v0\n    const v1, -0x326ec0e0')],
   'a':primary_edits('a'),
   'b':[
    ('const/high16 v6, 0x42380000    # 46.0f','const/high16 v6, 0x42500000    # 52.0f'),
    ('const/high16 v5, 0x41400000    # 12.0f','const/high16 v5, 0x41800000    # 16.0f'),
    ('const/high16 v6, 0x41300000    # 11.0f','const/high16 v6, 0x41600000    # 14.0f'),
   ]+primary_edits('b'),
  },
 }

def patch_text(name,text):
 assert hashlib.sha256(text.encode()).hexdigest()==BASELINE[name],name+' baseline changed'
 if name=='z55.smali':
  for start,end,colors in [(0,29,LIGHT),(34,63,DARK)]:
   marker='    invoke-direct/range {v%d .. v%d}, Ljj2;-><init>(ZJJJJJJJJJJJJJJ)V'%(start,end)
   assert text.count(marker)==1
   text=text.replace(marker,palette_block(start+2,colors)+'\n'+marker)
  text=text.replace('# direct methods',wifi.FIELDS+'\n# direct methods')+wifi.helpers(packed)
 else:
  for name_,edits in dimension_edits()[name].items():text=replace_method(text,name_,edits)
  if name=='xq0.smali':text+=primary_helper()
 return text

def restore_ui_theme(name,text):
 if name=='z55.smali':
  assert text.endswith(wifi.helpers(packed)) and text.count(wifi.FIELDS)==1
  text=text[:-len(wifi.helpers(packed))].replace(wifi.FIELDS+'\n','')
  for start,colors in [(2,LIGHT),(36,DARK)]:
   block=palette_block(start,colors)+'\n';assert text.count(block)==1
   text=text.replace(block,'')
 else:
  if name=='xq0.smali':
   helper=primary_helper();assert text.endswith(helper);text=text[:-len(helper)]
  for name_,edits in reversed(list(dimension_edits()[name].items())):text=replace_method(text,name_,edits,True)
 assert hashlib.sha256(text.encode()).hexdigest()==BASELINE[name],name+' native callbacks changed'
 return text

def contrast(a,b):
 def lum(s):
  rgb=[int(s[i:i+2],16)/255 for i in (0,2,4)]
  return sum((v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4)*w for v,w in zip(rgb,[.2126,.7152,.0722]))
 x,y=sorted([lum(a),lum(b)]);return (y+.05)/(x+.05)

def apply_ui_theme(smali):
 smali=Path(smali)
 for name in BASELINE:
  p=smali/name;p.write_text(patch_text(name,p.read_text()))

def verify_ui_theme(smali):
 smali=Path(smali)
 for name in BASELINE:restore_ui_theme(name,(smali/name).read_text())
 ratios={}
 for theme,colors in [('light',LIGHT),('dark',DARK)]:
  palette=dict(zip(ROLES,colors))
  for fg in ['blue','red','label','secondaryLabel','tertiaryLabel']:
   for bg in ['systemBackground','groupedBackground','secondaryGroupedBackground']:
    ratio=contrast(palette[fg],palette[bg]);assert ratio>=4.5,(theme,fg,bg,ratio)
    ratios[theme+'/'+fg+'/'+bg]=round(ratio,2)
 report={'design':'SIMHub clear blue','light':dict(zip(ROLES,LIGHT)),'dark':dict(zip(ROLES,DARK)),
  'text_contrast':ratios,'row_min_dp':52,'row_padding_dp':[18,14],'card_radius_dp':18,
  'light_card_shadow_dp':4,'inline_alert_button_min_dp':52,'stacked_alert_button_min_dp':56,
  'primary_buttons':'enabled Default actions: 保存/确认/确定/完成/继续 and Save/Confirm/OK/Done/Continue; blue fill, contrast text, semibold; native press feedback',
  'native_callback_and_state_instructions_unchanged':True,'theme_switching_preserved':True,
  'baseline_classes':BASELINE,'device_screenshot_verified':False}
 return report

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('smali',type=Path);p.add_argument('--verify-only',action='store_true');p.add_argument('--report',type=Path)
 a=p.parse_args()
 if not a.verify_only:apply_ui_theme(a.smali)
 result=verify_ui_theme(a.smali)
 if a.report:a.report.write_text(json.dumps(result,indent=2)+'\n')
 print('PASS: shared light/dark palette, 52dp rows/buttons, 18dp cards; all original callbacks restored exactly')
