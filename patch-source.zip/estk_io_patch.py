"""Explicit-AID eSTK access; ordinary native pg1 callers remain unchanged."""
from pathlib import Path
import hashlib

_ROOT = Path(__file__).resolve().parent
FILES = ('InternalEstkAccess.smali', 'InternalEstkCommand.smali')
ORIGINAL_PG1_SHA256 = 'd10c5146cba38342443d34ef70826ff4a52bec71b43eb6dff642ec1e5741e07c'
ANCHOR = '    long-to-int v3, v3\n\n    .line 355\n    if-nez v3, :cond_11'
HOOK = '''    # ESTK_EXPLICIT_AID_RESULT_BEGIN
    iget-object v4, v0, Lpg1;->d0:Ljava/lang/Object;
    invoke-static {v4, v3}, LInternalEstkCommand;->record(Ljava/lang/Object;I)Z
    move-result v4
    if-nez v4, :cond_10
    # ESTK_EXPLICIT_AID_RESULT_END
'''
PATCHED = ANCHOR.replace('    .line 355\n', HOOK + '\n    .line 355\n')


def apply_estk_io(smali):
    smali = Path(smali)
    path = smali / 'pg1.smali'
    text = path.read_text()
    assert hashlib.sha256(restore_estk_pg1(text).encode()).hexdigest() == ORIGINAL_PG1_SHA256, 'unexpected pg1 baseline'
    if PATCHED not in text:
        assert text.count(ANCHOR) == 1, 'pg1 result anchor changed'
        assert 'ESTK_EXPLICIT_AID_RESULT' not in text
        path.write_text(text.replace(ANCHOR, PATCHED))
    for name in FILES:
        (smali / name).write_bytes((_ROOT / 'smali' / name).read_bytes())
    verify_estk_io(smali)


def restore_estk_pg1(text):
    if PATCHED in text:
        assert text.count(PATCHED) == 1
        return text.replace(PATCHED, ANCHOR)
    assert 'ESTK_EXPLICIT_AID_RESULT' not in text
    return text


def verify_estk_io(smali):
    smali = Path(smali)
    text = (smali / 'pg1.smali').read_text()
    assert text.count(PATCHED) == 1, 'missing or repeated typed result hook'
    assert hashlib.sha256(restore_estk_pg1(text).encode()).hexdigest() == ORIGINAL_PG1_SHA256, 'pg1 changed outside typed result hook'
    for name in FILES:
        assert (smali / name).read_bytes() == (_ROOT / 'smali' / name).read_bytes(), name
    return {'new_classes': list(FILES), 'pg1_restored_sha256': hashlib.sha256(
        restore_estk_pg1(text).encode()).hexdigest()}
