"""Exact-input hooks for the existing config entry, state and IKE/ESP proposals."""
import hashlib
import re

ORIGINAL_SHA256 = {
    'rt.smali': '43c6c5195e766d572f732a60617d1e45ed5d83d6a43470d7df3421d11d6158e6',
    'pt.smali': 'fdf6f83531c3a69f7518d24b37a8f7fab9c202d0231a0c69b3035a6b31ee729e',
    'mt.smali': '9671c43f31fe94ae6798365c749c2618b02354b050ebcecee16624b2fc1835e7',
    'du.smali': '963184b3a9a243db6bf314373b0f32770a97ac4d76eec8b1bf2d861cfa30bcc1',
    'jg5.smali': '97d0c8131f91ab7d394b3d26b388ba28e2580b496da787c782c6733a8104ec3f',
    'dm5.smali': '60878b929a53fa745f975be2c79d85442234c7d2f82f4bbae7571bd024143236',
    'zl5.smali': '916faaec619ffee0fb49016d6d93bcd838733f3fc5b8cbe55253975baa05ed66',
    'gl5.smali': '8033ae822f8d0eb336ec22f601c892cb9e93c150916fbb0203f68e84d813afda',
    'yd2.smali': '9e6c65cea1672984f3fcd72517416369c62c7668ed61e5fb5d549247c9a29c9e',
    'b72.smali': 'cba2cef63be29e04187a5d4cf42e72eb702fd37c3e3a045ee1445ff77129bca9',
}
PREFIX = 'Lcc/forserein/simhub/internal/'

def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

def in_method(text, signature, edit):
    pattern = r'^\.method ' + re.escape(signature) + r'\n.*?^\.end method'
    assert len(re.findall(pattern, text, flags=re.M|re.S)) == 1, signature
    return re.sub(pattern, lambda m: edit(m[0]), text, flags=re.M|re.S)

def patch_wifi_class(name, text):
    assert hashlib.sha256(text.encode()).hexdigest() == ORIGINAL_SHA256[name], name
    if name == 'gl5.smali':
        signature = 'public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZLel5;Lek5;Lxi5;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lsd2;ZLhl5;Lfl5;Ljava/lang/Long;Ljava/util/List;Ljava/util/List;ZLjava/lang/String;J)V'
        def state(m):
            old = '    iput-object p6, p0, Lgl5;->f:Lxi5;'
            m = replace_once(m, old, f'''    invoke-static {{p5, p6}}, {PREFIX}WifiConfigRuntime;->resolve(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p6
    check-cast p6, Lxi5;
{old}''')
            for param, field, method in [('p8','h','epdg'),('p9','i','smsc'),('p10','j','imei')]:
                old = f'    iput-object {param}, p0, Lgl5;->{field}:Ljava/lang/String;'
                m = replace_once(m, old, f'''    invoke-static {{p5, {param}}}, {PREFIX}WifiConfigRuntime;->{method}(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;
    move-result-object {param}
{old}''')
            return m
        return in_method(text, signature, state)
    if name == 'yd2.smali':
        def page(m):
            anchor = '    new-instance v3, Ldm5;'
            m = replace_once(m, anchor, f'''    sget-object v4, Lh7;->b:Lhu4;
    invoke-virtual {{p1, v4}}, Llu1;->k(Lrv3;)Ljava/lang/Object;
    move-result-object v4
    check-cast v4, Landroid/content/Context;
    invoke-static {{v4, p0}}, {PREFIX}WifiConfigEditor;->begin(Landroid/content/Context;Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v5
    check-cast v5, Lus1;
{anchor}''')
            m = replace_once(m, 'invoke-direct {v3, p0, v2, v0, v1}, Ldm5;', 'invoke-direct {v3, v5, v2, v0, v1}, Ldm5;')
            anchor = '    invoke-static/range {v4 .. v11}, Lsd2;->a(Lus1;ZZZLzn0;Llu1;II)V'
            return replace_once(m, anchor, f'''    invoke-static {{p0}}, {PREFIX}WifiConfigEditor;->cancelCallback(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v4
    check-cast v4, Lus1;
{anchor}
    invoke-static {{p1}}, {PREFIX}WifiConfigEditor;->overlay(Ljava/lang/Object;)V''')
        return in_method(text, 'public static final j(Lus1;Llu1;I)V', page)
    if name in ('pt.smali','mt.smali'):
        old='Lyd2;->d(Ljava/lang/String;Ljava/lang/String;Llu1;I)V'
        # Only their initial config branch; the numerous unrelated switch cases stay byte-identical.
        end=text.index('    :pswitch_0')
        before=text[:end]
        assert before.count(old)==(5 if name=='pt.smali' else 3)
        return before.replace(old, PREFIX+'WifiConfigEditor;->row(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;I)V')+text[end:]
    if name == 'rt.smali':
        def imei_validation(m):
            old='    iget-object p1, p1, Lgl5;->j:Ljava/lang/String;'
            m=replace_once(m,old,old+f'\n    invoke-static {{p1}}, {PREFIX}WifiConfigEditor;->imeiText(Ljava/lang/String;)Ljava/lang/String;\n    move-result-object p1')
            return replace_once(m,'    invoke-virtual {p1}, Lgl5;->c()Z',f'    invoke-static {{p1}}, {PREFIX}WifiConfigEditor;->imeiValid(Ljava/lang/Object;)Z')
        return in_method(text,'private final k(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;',imei_validation)
    if name == 'du.smali':
        for field,mode in [('h',16),('j',17),('i',18)]:
            anchor=f'    iget-object v0, v0, Lgl5;->{field}:Ljava/lang/String;'
            text=replace_once(text,anchor,anchor+f'''
    const/16 v3, {hex(mode)}
    invoke-static {{v0, v3}}, {PREFIX}WifiConfigEditor;->scalar(Ljava/lang/String;I)Ljava/lang/String;
    move-result-object v0''')
        return text
    if name == 'jg5.smali':
        def callback(m):
            anchor='    move-object/from16 v0, p0'
            return replace_once(m,anchor,f'''    move-object/from16 v0, p0
    iget v1, v0, Ljg5;->T:I
    move-object/from16 v2, p1
    invoke-static {{v1, v2}}, {PREFIX}WifiConfigEditor;->editLegacy(ILjava/lang/Object;)Z
    move-result v3
    if-eqz v3, :wifi_original_callback
    sget-object v0, Lsc5;->a:Lsc5;
    return-object v0
    :wifi_original_callback
{anchor}''')
        return in_method(text,'public final i(Ljava/lang/Object;)Ljava/lang/Object;',callback)
    if name == 'dm5.smali':
        # Original ePDG Apply button now uses the same atomic page Done callback.
        text=replace_once(text,'    new-instance v3, Lwu;','    move-object v3, v0')
        return replace_once(text,'    invoke-direct {v3, v8, v0}, Lwu;-><init>(ILus1;)V','    # Unified draft save; original button content and layout retained.')
    if name == 'zl5.smali':
        # u() is a suspend method with 91 locals. v10 is the config and v4 the candidate
        # inner families at this single initial-attempt anchor; no coroutine slots change.
        old = '    :goto_f\n    invoke-static {v8, v5}, Lyk0;->T0(Ljava/lang/Iterable;I)Ljava/util/List;'
        new = f'''    :goto_f
    invoke-static {{v10, v4}}, {PREFIX}WifiConfigModel;->addressFamilies(Ljava/lang/Object;Ljava/util/List;)Ljava/util/List;
    move-result-object v4
    invoke-static {{v8, v5}}, Lyk0;->T0(Ljava/lang/Iterable;I)Ljava/util/List;'''
        return in_method(text, 'public final u(Lac5;Lxi5;Lek5;ILdt0;)Ljava/lang/Object;', lambda m:replace_once(m,old,new))
    if name == 'b72.smali':
        old = '    new-instance p0, Lf52;'
        def ike(m):
            # p0 becomes the DH list later. Preserve the config in a dedicated, verified local.
            m=replace_once(m,'    .locals 10','    .locals 11')
            anchor='    iget-object p0, p0, Lb72;->a:Lxi5;'
            m=replace_once(m,anchor,anchor+'\n    move-object v10, p0')
            return replace_once(m,old,f'    invoke-static {{v10, v0}}, {PREFIX}WifiConfigModel;->restrictIke(Ljava/lang/Object;Ljava/util/ArrayList;)V\n'+old)
        text = in_method(text, 'public final j(Ljava/util/List;)Lf52;', ike)
        # v6/v7 held 0x100 for OR-ing the SPI and are dead here; next use defines both again.
        return in_method(text, 'public final f()Lf52;', lambda m:replace_once(m,old,
            f'    iget-object v6, p0, Lb72;->a:Lxi5;\n    invoke-static {{v6, v0}}, {PREFIX}WifiConfigModel;->restrictEsp(Ljava/lang/Object;Ljava/util/ArrayList;)V\n'+old))
    raise AssertionError(name)
