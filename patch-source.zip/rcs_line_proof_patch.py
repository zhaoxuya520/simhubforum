"""Observe the registrar's associated identities before SIMHub applies its local IMPU fallback."""
import hashlib
from pathlib import Path
import re

TARGET = re.compile(r'(?ms)^\.method public final v\(Ldt0;\)Ljava/lang/Object;\n.*?^\.end method')
BASE_SHA256 = '510b88ecfdd7545ec0c50aa66e27b1b151ce305af89de6169d426b6fa3d648af'
HELPER = 'Lcc/forserein/simhub/internal/RcsChatBinding;'
SUBSTITUTIONS = (
    ('    iput-object v2, v0, Lo82;->s:Lx72;\n    invoke-virtual {v0, v9}, Lo82;->y(I)V',
     '    iput-object v2, v0, Lo82;->s:Lx72;\n'
     '    invoke-static {v0}, ' + HELPER + '->clear(Ljava/lang/Object;)V\n'
     '    invoke-virtual {v0, v9}, Lo82;->y(I)V'),
    ('    move-result v9\n    new-instance v10, Lx72;',
     '    move-result v9\n    move-object v5, v6\n    new-instance v10, Lx72;'),
    ('    iput-object v10, v0, Lo82;->s:Lx72;',
     '    invoke-static {v0, v10, v5, v9}, ' + HELPER +
     '->remember(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/List;I)V\n'
     '    iput-object v10, v0, Lo82;->s:Lx72;'),
)


def _replace(value, before, after):
    if value.count(before) != 1:
        raise ValueError('Unexpected registration evidence instruction count')
    return value.replace(before, after)


def _digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def _method(text):
    found = list(TARGET.finditer(text))
    if len(found) != 1:
        raise ValueError('Expected exactly one IMS registration method')
    return found[0]


def reverse_rcs_line_proof(name, text):
    if name != 'o82.smali' or HELPER not in text:
        return text
    match = _method(text)
    base = match.group()
    for original, replacement in reversed(SUBSTITUTIONS):
        base = _replace(base, replacement, original)
    if _digest(base) != BASE_SHA256:
        raise ValueError('Unexpected IMS registration method after restoring original instructions')
    return text[:match.start()] + base + text[match.end():]


def apply_rcs_line_proof(smali):
    path = Path(smali) / 'o82.smali'
    text = path.read_text()
    if HELPER in text:
        reverse_rcs_line_proof(path.name, text)
        return
    match = _method(text)
    transformed = match.group()
    if _digest(transformed) != BASE_SHA256:
        raise ValueError('Unexpected IMS registration method before applying RCS line evidence')
    for original, replacement in SUBSTITUTIONS:
        transformed = _replace(transformed, original, replacement)
    patched = text[:match.start()] + transformed + text[match.end():]
    if reverse_rcs_line_proof(path.name, patched) != text:
        raise ValueError('IMS registration evidence patch is not exactly reversible')
    path.write_text(patched)


def verify_rcs_line_proof(smali):
    text = (Path(smali) / 'o82.smali').read_text()
    if HELPER not in text:
        raise ValueError('IMS registration evidence patch missing')
    restored = reverse_rcs_line_proof('o82.smali', text)
    return {'method': 'o82.v', 'original_method_sha256': BASE_SHA256,
            'patched_method_sha256': _digest(_method(text).group()),
            'exact_reverse': _digest(_method(restored).group()) == BASE_SHA256}
