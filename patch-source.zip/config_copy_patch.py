"""Clarify the existing inline override placeholders without changing layout."""
from pathlib import Path
import re

def apply_config_copy(decoded):
    path=Path(decoded)/'assets/i18n/zh-Hans.strings'
    text=path.read_text()
    labels={'vowifi_sms_imei_hint':'填写需要使用的 15 位 IMEI 自定义值，仅保存在本机。留空并完成后恢复内置值；内置为空时保持未设置，不会自动读取手机 IMEI。',
            'vowifi_sms_custom_epdg':'ePDG 自定义覆盖（留空并点完成恢复内置）',
            'vowifi_sms_imei':'IMEI 自定义覆盖（留空恢复内置，不会自动获取手机 IMEI）',
            'vowifi_sms_smsc_override':'SMSC 自定义覆盖（留空并点完成恢复卡内值）'}
    for key,value in labels.items():
        text,count=re.subn(r'^"'+re.escape(key)+r'" = ".*";$','"'+key+'" = "'+value+'";',text,flags=re.M)
        assert count==1,key
    path.write_text(text)

    # Remove the obsolete mismatch card, including its icon/container, at the render branch.
    path=Path(decoded)/'smali/fd2.smali'
    text=path.read_text()
    marker='    const-string v3, "vowifi_sms_profile_mismatch"'
    assert text.count(marker)==1
    end=text.index(marker)
    start=text.rfind('    if-eqz v25, :cond_14',0,end)
    assert start>=0 and end-start<7000
    text=text[:start]+text[start:].replace('    if-eqz v25, :cond_14','    goto/16 :cond_14',1)
    path.write_text(text)
    for locale in ('zh-Hans','zh-Hant'):
        path=Path(decoded)/('assets/i18n/'+locale+'.strings')
        text=path.read_text()
        text,count=re.subn(r'^"vowifi_sms_profile_mismatch" = ".*";$','"vowifi_sms_profile_mismatch" = "";',text,flags=re.M)
        assert count==1
        path.write_text(text)
