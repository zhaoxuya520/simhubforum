"""Clarify the existing inline override placeholders without changing layout."""
from pathlib import Path
import re

def apply_config_copy(decoded):
    path=Path(decoded)/'assets/i18n/zh-Hans.strings'
    text=path.read_text()
    labels={'vowifi_sms_imei_hint':'填写需要使用的 15 位 IMEI 自定义值，仅保存在本机。留空并完成后恢复内置值；内置为空时保持未设置，不会自动读取手机 IMEI。',
            'vowifi_sms_custom_epdg':'ePDG 自定义覆盖（留空并点完成恢复内置）',
            'vowifi_sms_imei':'IMEI 自定义覆盖（留空恢复内置，不会自动获取手机 IMEI）',
            'vowifi_sms_smsc_override':'SMSC 自定义覆盖（留空并点完成恢复卡内值）'}
    for key,value in labels.items():
        text,count=re.subn(r'^"'+re.escape(key)+r'" = ".*";$','"'+key+'" = "'+value+'";',text,flags=re.M)
        assert count==1,key
    path.write_text(text)
