"""Generate typed GSMA TAPI1.6.1 clients from pinned, unmodified public AIDL."""
from pathlib import Path
import hashlib, json, shutil, subprocess
ROOT = Path(__file__).resolve().parent
VENDOR = ROOT/'third_party/gsma-tapi'

def generate_rcs_tapi(output, tools='/workspace/tools/android-recovery'):
    output, tools = Path(output), Path(tools)
    manifest = json.loads((VENDOR/'sources.json').read_text())
    for name, digest in manifest['files'].items():
        assert hashlib.sha256((VENDOR/name).read_bytes()).hexdigest() == digest, 'Changed vendored TAPI source: '+name
    if output.exists(): shutil.rmtree(output)
    output.mkdir(parents=True)
    inputs = [p for p in sorted((VENDOR/'aidl').rglob('*.aidl')) if '\ninterface ' in p.read_text()]
    subprocess.run([str(tools/'sdk/android-15/aidl'), '--lang=java', '--min_sdk_version=28', '--omit_invocation',
                    '-I'+str(VENDOR/'aidl'), '-p'+str(tools/'sdk/android-35/framework.aidl'), '-o'+str(output),
                    *map(str, inputs)], check=True)
    generated = sorted(output.rglob('*.java'))
    assert len(generated) == len(inputs)
    return sorted((VENDOR/'java').rglob('*.java')) + generated

def copy_rcs_tapi_smali(module_decoded, decoded):
    src=Path(module_decoded)/'smali/com/gsma/services/rcs'
    dst=Path(decoded)/'smali/com/gsma/services/rcs'
    assert src.is_dir() and not dst.exists(), 'Unexpected existing TAPI namespace'
    shutil.copytree(src,dst)
    assets=Path(decoded)/'assets/licenses/gsma-tapi';assets.mkdir(parents=True,exist_ok=True)
    for name in ('NOTICE.txt','LICENSE-2.0.txt'):shutil.copyfile(VENDOR/name,assets/name)

if __name__ == '__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args()
    for source in generate_rcs_tapi(a.output): print(source)
