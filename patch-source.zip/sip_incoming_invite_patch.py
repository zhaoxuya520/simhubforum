"""Remember native rejected incoming INVITEs and replay only completed transactions."""
from pathlib import Path
import hashlib

REQUEST = '.method public final r(Lkb4;Loc2;Ljava/lang/String;)V'
RESPONSE = '.method public final n(Lma4;ILjava/lang/String;[BZD)Lpa4;'
REQUEST_SHA = '4db2cbb2c28cbf5fd5d12116a4337989d1978fd312ef6be5e9a1884d8d1f87bc'
RESPONSE_SHA = 'a7a12af2ff73785a980a41870cab1480a6557a5dffa945e189859c65d18133ec'
ENTRY = '    :sip_fork_native_request\n'
REQUEST_HOOK = '''
    invoke-static {v0, v11, v3}, Lcc/forserein/simhub/internal/SipIncomingInvite;->handle(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, :sip_incoming_native_request
    return-void
    :sip_incoming_native_request
'''
OLD_LOCALS = '    .locals 10\n'
NEW_LOCALS = '    .locals 11\n\n    move-object v10, p0\n'
STORE = '    iput-object v1, p1, Lma4;->G:Lkb4;\n'
RESPONSE_HOOK = '''
    invoke-static {v10, p1, v1}, Lcc/forserein/simhub/internal/SipIncomingInvite;->remember(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
'''


def _method(text, signature):
    a = text.index(signature)
    b = text.index('.end method', a) + len('.end method')
    return a, b, text[a:b]


def apply_sip_incoming_invite(smali):
    root = Path(smali)
    path = root / 'o82.smali'
    text = path.read_text()
    a, b, body = _method(text, REQUEST)
    assert hashlib.sha256(body.encode()).hexdigest() == REQUEST_SHA, 'apply after SIP fork request hook'
    assert body.count(ENTRY) == 1
    path.write_text(text[:a] + body.replace(ENTRY, ENTRY + REQUEST_HOOK) + text[b:])
    path = root / 'cb4.smali'
    text = path.read_text()
    a, b, body = _method(text, RESPONSE)
    assert hashlib.sha256(body.encode()).hexdigest() == RESPONSE_SHA
    assert body.count(OLD_LOCALS) == 1 and body.count(STORE) == 1
    body = body.replace(OLD_LOCALS, NEW_LOCALS).replace(STORE, STORE + RESPONSE_HOOK)
    path.write_text(text[:a] + body + text[b:])


def reverse_sip_incoming_invite(name, text):
    if name == 'o82.smali' and 'SipIncomingInvite;->handle' in text:
        a, b, body = _method(text, REQUEST)
        assert body.count(ENTRY + REQUEST_HOOK) == 1
        body = body.replace(ENTRY + REQUEST_HOOK, ENTRY)
        assert hashlib.sha256(body.encode()).hexdigest() == REQUEST_SHA
        return text[:a] + body + text[b:]
    if name == 'cb4.smali' and 'SipIncomingInvite;->remember' in text:
        a, b, body = _method(text, RESPONSE)
        assert body.count(NEW_LOCALS) == 1 and body.count(STORE + RESPONSE_HOOK) == 1
        body = body.replace(NEW_LOCALS, OLD_LOCALS).replace(STORE + RESPONSE_HOOK, STORE)
        assert hashlib.sha256(body.encode()).hexdigest() == RESPONSE_SHA
        return text[:a] + body + text[b:]
    return text


def verify_sip_incoming_invite(smali):
    root = Path(smali)
    request = (root / 'o82.smali').read_text()
    response = (root / 'cb4.smali').read_text()
    assert request.count(ENTRY + REQUEST_HOOK) == 1
    assert response.count(STORE + RESPONSE_HOOK) == 1
    reverse_sip_incoming_invite('o82.smali', request)
    reverse_sip_incoming_invite('cb4.smali', response)
    return {
        'scope': 'native initial incoming INVITE final 603 or 487 only',
        'match': 'Call-ID, CSeq, branch, From, To without tag, request URI and Via sent-by',
        'response': 'original final status/To-tag; current request Via chain and inbound transport',
        'cache_limit': 64, 'cache_seconds': 32, 'retransmission_extends_cache': False,
        'cache_owner': 'weak native call manager; no dialog or original request retained',
        'expiry': 'bounded daemon expiry tasks with weak owner/bucket references',
        'native_methods_exactly_reversible': True, 'real_carrier_tested': False,
    }
