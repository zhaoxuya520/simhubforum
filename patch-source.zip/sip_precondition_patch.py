"""Add the negotiated early-dialog precondition requirement to an SDP UPDATE only."""
from pathlib import Path
import hashlib

PINS = {
    ('o82.smali', 'public final h(Lkb4;)Z'): 'c20c533427b96ab6ee72b5d41efb3825cc96df2b338d2441d36d5fa1d87d1c1e',
    ('cb4.smali', 'public final k(Ljava/lang/String;Lma4;[B)Lkb4;'): '9b7ee0a797132310b85e5455a3010725406d35be8edfbde69856f2eae4c9d012',
}
OBSERVE_OLD = '    iput-object v4, v3, Lma4;->p:[B\n\n    .line 700\n'
OBSERVE_NEW = '    iput-object v4, v3, Lma4;->p:[B\n\n    # sip_early_precondition_observe\n    invoke-static {v1, v3}, Lcc/forserein/simhub/internal/SipEarlyPrecondition;->observe(Ljava/lang/Object;Ljava/lang/Object;)V\n\n    .line 700\n'
LOCALS_OLD = '    .locals 5\n'
LOCALS_NEW = '    .locals 6\n\n    # sip_early_precondition_dialog\n    move-object v5, p2\n'
RETURN_OLD = '    return-object v0\n'
RETURN_NEW = '    # sip_early_precondition_decorate\n    invoke-static {v5, v0}, Lcc/forserein/simhub/internal/SipEarlyPrecondition;->decorate(Ljava/lang/Object;Ljava/lang/Object;)V\n\n    return-object v0\n'
EDITS = {'o82.smali': [(OBSERVE_OLD, OBSERVE_NEW)],
         'cb4.smali': [(LOCALS_OLD, LOCALS_NEW), (RETURN_OLD, RETURN_NEW)]}


def _method(text, signature):
    start = text.index('.method ' + signature)
    end = text.index('.end method', start) + len('.end method')
    return start, end, text[start:end]


def apply_sip_precondition(smali):
    for (name, signature), pin in PINS.items():
        path = Path(smali) / name
        text = path.read_text()
        start, end, body = _method(text, signature)
        assert hashlib.sha256(body.encode()).hexdigest() == pin, name + ': apply after existing SIP patches'
        for old, new in EDITS[name]:
            assert body.count(old) == 1, name + ': expected unique native anchor'
            body = body.replace(old, new)
        path.write_text(text[:start] + body + text[end:])


def reverse_sip_precondition(name, text):
    if name not in EDITS:
        return text
    if 'SipEarlyPrecondition;->' not in text and 'sip_early_precondition_' not in text:
        return text
    signature, pin = next((sig, digest) for (target, sig), digest in PINS.items() if target == name)
    start, end, body = _method(text, signature)
    for old, new in reversed(EDITS[name]):
        assert body.count(new) == 1, name + ': incomplete or changed precondition hook'
        body = body.replace(new, old)
    assert 'SipEarlyPrecondition;->' not in body and 'sip_early_precondition_' not in body
    assert hashlib.sha256(body.encode()).hexdigest() == pin, name + ': unrelated native instructions changed'
    result = text[:start] + body + text[end:]
    assert 'SipEarlyPrecondition;->' not in result and 'sip_early_precondition_' not in result
    return result


def verify_sip_precondition(smali):
    for (name, signature), pin in PINS.items():
        text = (Path(smali) / name).read_text()
        for old, new in EDITS[name]:
            assert text.count(new) == 1, name + ': missing precondition hook'
        reverse_sip_precondition(name, text)
    return {'native_methods': ['o82.h', 'cb4.k'],
            'scope': 'outgoing early-dialog SDP UPDATE after accepted INVITE provisional SDP requires precondition',
            'initial_invite_unchanged': True, 'confirmed_dialog_unchanged': True,
            'correlation': ['Call-ID', 'original INVITE CSeq and Via branch', 'local and remote tags', 'accepted SDP digest'],
            'evidence_limit': 64, 'evidence_seconds': 180, 'repeated_identical_evidence_extends_lifetime': False,
            'header_preservation': 'append Require precondition only when absent; existing headers unchanged',
            'native_methods_exactly_reversible': True, 'real_carrier_tested': False}
