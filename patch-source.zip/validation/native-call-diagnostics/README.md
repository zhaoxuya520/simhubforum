# Native CTExcel call diagnostics regression

`check_runtime.py APK --carrier-report REPORT --report OUTPUT [--unsigned-apk APK] [--jar JAR] [--previous-24-4]`

The runner validates the selected APK hash, translated JAR hash, and exact signed/unsigned DEX bytes before running. The negative control is the signed 24.4 APK: all call actions still work, but the new `通话诊断` lines must be absent. The fixed package must add redacted observations while retaining the same ordinary call outcomes.

The fixture reuses the existing native-preconditions setup and the APK's real CTExcel policy. It retains the actual `f82`, `o82.C`, `o82.h`, SIP parser, call manager, request builders, and shipped SIP helpers. Only the final TCP payload output (`o82.E`) and tunnel output (`b72.r`) are intercepted. The latter is available through the shared adapter but is not exercised in this TCP-only suite. Registered-session state and Gm keys are synthetic; Android logs and call-controller events are collected by fixtures. There is no real SIM, network, carrier account, socket traffic, or Android ART test here. Translated DEX execution uses the existing dex2jar constructor adapters and `-noverify`.

The shared native-preconditions constructor does not populate configuration MCC/MNC. This suite first verifies that this unset scope emits no diagnostics, then sets MCC 234/MNC 33 and explicitly resubmits the same already generated native INVITE through real `o82.C`. It verifies identical request bytes; it does not present this resubmission as a second native dialing operation. Subsequent responses and actions traverse the real native control flow.

Coverage includes:

- Reliable 183 with SDP → real PRACK → 200 PRACK → real negotiated UPDATE → remote 487 → native ACK and original failure event, without a fabricated CANCEL.
- Real `cb4.j` local hangup → CANCEL → 200 CANCEL / 487 INVITE → ACK, without changing the normal cancellation outcome.
- Same process-local dialog token on INVITE, CANCEL, and final response; no raw SIP Call-ID.
- Incoming input objects and serialized bytes remain unchanged. Outgoing `C` preserves the request bytes, dialog fields, and transmitted serialization.
- Real safe metadata for Gm context, TCP Via, SDP, 100rel/precondition requirements, RSeq/RAck presence, and fixed P-Early-Media tokens.
- No diagnostics for another MCC/MNC combination. Arbitrary header text, address/number values, SDP, unknown early-media values, and quoted fake Reason/Warning codes are not disclosed by the new log lines.

The fixture checks only the newly added diagnostic prefix for redaction. Existing native logs are not rewritten by this change. `提交` is an entry into native dispatch, including queueing; it is not evidence of delivery. `收到` is receipt by the dispatcher, not proof that a response passed subsequent transaction guards. A reported 487 still has its original meaning; this suite does not establish the cause of the user's live carrier failure.
