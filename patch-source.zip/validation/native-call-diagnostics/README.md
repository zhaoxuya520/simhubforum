# Native cross-carrier call diagnostics regression

`check_runtime.py APK --carrier-report REPORT --report OUTPUT [--unsigned-apk APK] [--jar JAR] [--previous-24-4 | --previous-24-9]`

The runner validates the selected APK hash, translated JAR hash, and exact signed/unsigned DEX bytes. The 24.4 control expects zero `通话诊断` lines. The 24.9 control expects these lines exclusively for CTExcel UK. The fixed package must produce redacted observations for each tested operator and preserve ordinary call outcomes.

The fixture reuses the existing native-preconditions setup and the APK's real CTExcel policy. It retains the actual `f82`, `o82.C`, `o82.h`, SIP parser, call manager, request builders, and shipped SIP helpers. Only the final TCP payload output (`o82.E`) and tunnel output (`b72.r`) are intercepted. The latter is available through the shared adapter but is not exercised in this TCP-only suite. Registered-session state and Gm keys are synthetic; Android logs and call-controller events are collected by fixtures. There is no real SIM, network, carrier account, socket traffic, or Android ART test here. Translated DEX execution uses the existing dex2jar constructor adapters and `-noverify`.

The shared constructor starts with an unset configuration MCC/MNC. The suite checks this first dispatch, clears the log, then sets MCC/MNC for CTExcel UK (23433), BASE Belgium (20620), or Vodafone Germany (26202). It resubmits the same native INVITE through `o82.C` and verifies identical request bytes. This isolates the diagnostics check from the carrier's dialing policy. Subsequent responses and actions traverse the native control flow.

Coverage includes:

- Reliable 183 with SDP → real PRACK → 200 PRACK → real negotiated UPDATE → remote 487 → native ACK and original failure event, without a fabricated CANCEL.
- Real `cb4.j` local hangup → CANCEL → 200 CANCEL / 487 INVITE → ACK, without changing the normal cancellation outcome.
- Same process-local dialog token on INVITE, CANCEL, and final response; no raw SIP Call-ID.
- Incoming input objects and serialized bytes remain unchanged. Outgoing `C` preserves the request bytes, dialog fields, and transmitted serialization.
- Real safe metadata for Gm context, TCP Via, SDP, 100rel/precondition requirements, RSeq/RAck presence, and fixed P-Early-Media tokens.
- The BASE fixture receives 100, 180 and 487. The German fixture receives 100, 180 and 486. Both check the outbound URI type, provisional Reason, final numeric Reason and Warning, matched call token, ACK delivery to the transport fixture, and zero locally generated CANCELs.
- Arbitrary header text, addresses, phone numbers, SDP and quoted fake Reason/Warning codes stay private.

The fixture checks only the newly added diagnostic prefix for redaction. Existing native logs are not rewritten by this change. `提交` is an entry into native dispatch, including queueing; it is not evidence of delivery. `收到` is receipt by the dispatcher, not proof that a response passed subsequent transaction guards. A reported 487 still has its original meaning; this suite does not establish the cause of the user's live carrier failure.
