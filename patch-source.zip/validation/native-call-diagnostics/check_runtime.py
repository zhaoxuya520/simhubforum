#!/usr/bin/env python3
"""Validate read-only CTExcel call diagnostics on actual native C/h entry points."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

here = Path(__file__).resolve().parent
shared = here.parent / "native-fork"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("apk", type=Path)
parser.add_argument("--carrier-report", type=Path, required=True)
parser.add_argument("--report", type=Path, required=True)
parser.add_argument("--unsigned-apk", type=Path)
parser.add_argument("--jar", type=Path)
parser.add_argument("--previous-24-4", action="store_true")
args = parser.parse_args()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


carrier = json.loads(args.carrier_report.read_text())
jar = args.jar or args.carrier_report.parent / "native-carrier-current" / "probe.jar"
unsigned = args.unsigned_apk or args.apk
assert carrier["apk_sha256"] == digest(unsigned), "unexpected unsigned APK"
assert carrier["apk_translated_jar_sha256"] == digest(jar), "unexpected translated JAR"
with zipfile.ZipFile(unsigned) as original, zipfile.ZipFile(args.apk) as signed:
    dex_pattern = re.compile(r"classes\d*\.dex")
    names = set(filter(dex_pattern.fullmatch, original.namelist()))
    assert names and names == set(filter(dex_pattern.fullmatch, signed.namelist())), "DEX set mismatch"
    dex_hashes = {}
    for name in sorted(names):
        content = signed.read(name)
        assert original.read(name) == content, name
        dex_hashes[name] = hashlib.sha256(content).hexdigest()

kit = Path(os.environ.get("SIMHUB_TOOLS", "/workspace/tools/android-recovery"))
dexkit = Path(os.environ.get("SIMHUB_DEX2JAR_TOOLS", "/workspace/tools/dex2jar-v2.4"))
lib = dexkit / "dex-tools-v2.4/lib"
asm = os.pathsep.join(str(lib / name) for name in ("asm-9.5.jar", "asm-tree-9.5.jar"))
sources = [shared / "g11.java", shared / "SipForkProbe.java", shared.parent / "native-invite-failure" / "t00.java", here.parent / "native-preconditions" / "PreconditionTransportAdapter.java", here.parent / "native-preconditions" / "PreconditionProbe.java", here / "CallDiagnosticsProbe.java"]
mode = "previous-24-4" if args.previous_24_4 else "fixed"
args.report.parent.mkdir(parents=True, exist_ok=True)
log = []


def run(*command):
    result = subprocess.run(list(map(str, command)), capture_output=True, text=True)
    log.append(result.stdout + result.stderr)
    args.report.with_suffix(".log").write_text("\n".join(log))
    if result.returncode:
        print(log[-1])
        raise SystemExit(result.returncode)
    return result.stdout


with tempfile.TemporaryDirectory(dir=args.report.parent, prefix="native-call-diagnostics-") as tmp:
    work = Path(tmp)
    classes = work / "classes"
    classes.mkdir()
    run("java", "-jar", kit / "ecj-3.40.0.jar", "-17", "-warn:none", "-proc:none", "-cp", asm, "-d", classes, *sources)
    adapted = work / "transport.jar"
    run("java", "-cp", os.pathsep.join([str(classes), asm]), "PreconditionTransportAdapter", jar, adapted)
    with zipfile.ZipFile(jar) as before, zipfile.ZipFile(adapted) as after:
        assert set(before.namelist()) == set(after.namelist())
        changed = {name for name in before.namelist() if before.read(name) != after.read(name)}
        assert changed == {"o82.class", "b72.class"}, changed
    cp = os.pathsep.join(map(str, [classes, adapted, kit / "sdk/android-35/android.jar"]))
    output = run("java", "-noverify", "-cp", cp, "CallDiagnosticsProbe", mode)

match = re.search(r"CALL_DIAGNOSTICS_PROBE mode=([\w-]+) checks=(\d+) native_snapshot_checks=(\d+) shared_path_checks=(\d+) diagnostic_lines=(\d+)", output)
assert match and match[1] == mode, output
report = {
    "runner_sha256": digest(Path(__file__).resolve()),
    "apk_sha256": digest(args.apk), "dex_sha256": dex_hashes,
    "apk_translated_jar_sha256": digest(jar), "carrier_report_sha256": digest(args.carrier_report),
    "mode": mode, "checks": int(match[2]) + int(match[3]) + int(match[4]),
    "diagnostic_checks": int(match[2]), "native_snapshot_checks": int(match[3]),
    "shared_path_checks": int(match[4]), "diagnostic_lines": int(match[5]),
    "real_native_outgoing_C_and_incoming_h": True,
    "real_prack_update_cancel_ack_and_failure_event": True,
    "incoming_objects_and_outgoing_request_bytes_preserved": True,
    "real_ctexcel_policy": "zi5.a[23433].d",
    "baseline_logging_absent": args.previous_24_4,
    "fixture_boundaries": ["o82.E receives outgoing TCP payload before its TCP stack", "b72.r final datagram boundary replaced but not exercised by this TCP-only probe", "synthetic registered session and Gm security context", "native parser receives synthetic clear SIP responses", "Android log and event sinks", "shared constructor initial INVITE has unset MCC/MNC; fixture sets 234/33 then explicitly resubmits same native request through C for diagnostic verification"],
    "network_calls_placed": False, "real_carrier_tested": False, "android_art_tested": False,
    "dex_to_jvm_constructor_adapters": True, "jvm_verification_disabled_for_translated_dex": True,
    "diagnostic_observations": [s for s in output.splitlines() if not s.startswith("CALL_DIAGNOSTICS_PROBE")],
    "fixture_sources": {str(source.relative_to(here.parents[1])): digest(source) for source in sources},
}
args.report.write_text(json.dumps(report, indent=2) + "\n")
print(output.strip())
