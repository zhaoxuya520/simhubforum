import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/** Actual shipped f82/C/h/cb4 path; only final transport and Android-facing sinks are fixtures. */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class CallDiagnosticsProbe {
  static boolean previous, carrierLimited;
  static int checks, diagnosisCount;
  static final IdentityHashMap<g11, Integer> logOffsets = new IdentityHashMap<>();
  static final String PRIVATE = "PRIVATE_REASON_+441632960123_at_2001:db8::2";

  static void check(boolean ok, String label) {
    if (!ok) throw new AssertionError(label);
    checks++;
  }
  static byte[] wire(Object message) throws Exception {
    return (byte[]) SipForkProbe.call(message, "b", new Class<?>[0]);
  }
  static void accept(PreconditionProbe.Call call, Object response) throws Exception {
    byte[] before = wire(response);
    SipForkProbe.Snapshot snapshot = new SipForkProbe.Snapshot(response);
    call.accept(response);
    check(Arrays.equals(before, wire(response)), "actual h preserves incoming wire bytes");
    snapshot.unchanged("actual h preserves incoming object");
  }
  static List<String> diagnostics(PreconditionProbe.Call call) throws Exception {
    List<String> result = new ArrayList<>();
    g11 sink = (g11) SipForkProbe.get(call.nativeSession.e, "g");
    int previousOffset = logOffsets.getOrDefault(sink, 0);
    for (int i = 0; i < sink.messages.size(); i++) {
      String line = sink.messages.get(i);
      if (line.startsWith("通话诊断")) { result.add(line); if (i >= previousOffset) diagnosisCount++; }
    }
    logOffsets.put(sink, sink.messages.size());
    for (String line : result) {
      for (String forbidden : new String[] {
          "+441632960123", "192.0.2.", "2001:db8", "example.invalid", "3gppnetwork.org",
          "PRIVATE_REASON", "v=0", "a=curr:", "a=rtpmap:", "z9hG4bK", "sip:", "tel:"
      }) check(!line.contains(forbidden), "new diagnosis omits private/opaque value " + forbidden);
      check(!line.contains("\r") && !line.contains("\n"), "diagnosis is a single line");
      check(line.length() <= 512, "diagnosis has a bounded line length");
    }
    return result;
  }
  static String find(List<String> lines, String text) {
    for (String line : lines) if (line.contains(text)) return line;
    return null;
  }
  static String token(String line) {
    if (line == null) return null;
    Matcher match = Pattern.compile("#([0-9a-fA-F]+)").matcher(line);
    return match.find() ? match.group(1) : null;
  }
  static void expected(List<String> lines, String... text) {
    if (previous) check(lines.isEmpty(), "24.4 has no new diagnosis lines");
    else for (String part : text) check(find(lines, part) != null, "actual hook logs " + part);
  }
  static int networkFailureCount(PreconditionProbe.Call call) throws Exception {
    int count = 0;
    for (Object event : call.sink.events) if (event.getClass().getName().equals("eb4")) {
      Object reason = SipForkProbe.get(event, "b");
      if (reason.getClass().getName().equals("ta4")) {
        check(Integer.valueOf(487).equals(SipForkProbe.get(reason, "l")), "native error remains 487");
        count++;
      }
    }
    return count;
  }

  static PreconditionProbe.Call scopedCall(String mcc, String mnc) throws Exception {
    PreconditionProbe.Call call = new PreconditionProbe.Call(true);
    List<String> unconfigured = diagnostics(call);
    check((find(unconfigured, "提交 INVITE") != null) == !(previous || carrierLimited),
        "dispatch observation is independent of the availability of MCC/MNC");
    g11 sink = (g11) SipForkProbe.get(call.nativeSession.e, "g");
    sink.messages.clear();
    logOffsets.remove(sink);
    Object config = SipForkProbe.get(call.nativeSession.e, "b");
    SipForkProbe.set(config, "d", mcc); SipForkProbe.set(config, "e", mnc);
    // The shared constructor already exercised f82. Explicitly resubmit that same request to C
    // after adding scope metadata; this is not a second native dialing operation.
    PreconditionProbe.wires.clear();
    SipForkProbe.call(call.nativeSession.e, "C", new Class<?>[] {Class.forName("kb4")},
        SipForkProbe.get(call.dialog(), "j"));
    check(PreconditionProbe.wires.size() == 1 && call.initial.equals(PreconditionProbe.wires.get(0)),
        "scope metadata and diagnosis preserve the exact original native INVITE bytes");
    return call;
  }

  static void remoteTermination() throws Exception {
    PreconditionProbe.Call call = scopedCall("234", "33");
    Object progress = PreconditionProbe.response(call.initial, 183, "A", PreconditionProbe.answer(true),
        "Require: 100rel, precondition\r\nRSeq: 1\r\nP-Early-Media: sendrecv\r\n");
    accept(call, progress);
    String prack = PreconditionProbe.last("PRACK");
    check(prack != null, "actual reliable progress emits PRACK");
    accept(call, PreconditionProbe.response(prack, 200, "unused", "", ""));
    String update = PreconditionProbe.last("UPDATE");
    check(update != null, "actual PRACK response emits UPDATE");
    check(PreconditionProbe.option(PreconditionProbe.parse(update), "Require", "precondition"),
        "24.4 negotiated precondition behavior stays intact");
    accept(call, PreconditionProbe.response(update, 200, "unused", "", ""));
    String cause = "Reason: Q.850;cause=16;text=\"" + PRIVATE + "\"\r\n"
        + "Reason: SIP;cause=487;text=\"" + PRIVATE + "\"\r\n"
        + "Warning: 399 diagnostic.example.invalid \"" + PRIVATE + "\"\r\n";
    accept(call, PreconditionProbe.response(call.initial, 487, "A", "", cause));
    check(PreconditionProbe.count("CANCEL") == 0, "remote 487 never fabricates local CANCEL");
    check(PreconditionProbe.count("ACK") == 1 && networkFailureCount(call) == 1,
        "actual 487 sends one ACK and one unchanged failure event");
    check(((Map) SipForkProbe.get(call.nativeSession.m, "e")).isEmpty(), "remote final removes dialog");
    List<String> lines = diagnostics(call);
    expected(lines, "提交 INVITE", "收到 183 INVITE", "提交 PRACK", "收到 200 PRACK",
        "提交 UPDATE", "收到 487 INVITE");
    check(find(lines, "提交 CANCEL") == null, "no diagnostic asserts a CANCEL absent from actual C");
    if (!previous) {
      String invite = find(lines, "提交 INVITE"), finalResponse = find(lines, "收到 487 INVITE");
      check(token(invite) != null && token(invite).equals(token(finalResponse)),
          "actual pending call identity token links INVITE and final response");
      check(finalResponse.contains("16") && finalResponse.contains("487") && finalResponse.contains("399"),
          "sanitized numeric reason and warning remain available");
      check(invite.contains("Via=TCP") && invite.contains("Gm上下文=有"), "actual Gm/TCP metadata recorded");
      String progressLine = find(lines, "收到 183 INVITE"), prackLine = find(lines, "提交 PRACK"),
          updateLine = find(lines, "提交 UPDATE");
      check(progressLine.contains("SDP=有") && progressLine.contains("100rel要求=有")
          && progressLine.contains("precondition要求=有") && progressLine.contains("RSeq=有")
          && progressLine.contains("早期媒体授权=sendrecv"), "received progress diagnosis describes actual safe protocol fields");
      check(prackLine.contains("SDP=无") && prackLine.contains("RAck=有"), "actual bodyless PRACK is described correctly");
      check(updateLine.contains("SDP=有") && updateLine.contains("precondition要求=有"),
          "actual negotiated UPDATE is described correctly");
    }
    System.out.println("REMOTE_487 actual_cancel_count=0 actual_ack_count=1 network_failure_count=1 diagnostic_lines=" + lines.size());
  }

  static void localCancellation() throws Exception {
    PreconditionProbe.Call call = scopedCall("234", "33");
    accept(call, PreconditionProbe.response(call.initial, 180, "A", "", ""));
    String id = (String) SipForkProbe.get(call.dialog(), "b");
    Object actions = SipForkProbe.call(call.nativeSession.m, "j", new Class<?>[] {String.class, double.class}, id, 12.0);
    SipForkProbe.call(call.nativeSession.e, "k", new Class<?>[] {List.class}, actions);
    check(PreconditionProbe.count("CANCEL") == 1, "actual native hangup emits exactly one CANCEL");
    accept(call, PreconditionProbe.response(PreconditionProbe.last("CANCEL"), 200, "unused", "", ""));
    accept(call, PreconditionProbe.response(call.initial, 487, "A", "", ""));
    check(PreconditionProbe.count("ACK") == 1 && networkFailureCount(call) == 0,
        "actual user cancellation completion keeps normal outcome");
    List<String> lines = diagnostics(call);
    expected(lines, "提交 INVITE", "收到 180 INVITE", "提交 CANCEL", "收到 487 INVITE");
    if (!previous) {
      String start = token(find(lines, "提交 INVITE"));
      check(start != null && start.equals(token(find(lines, "提交 CANCEL")))
          && start.equals(token(find(lines, "收到 487 INVITE"))), "one actual dialog token links local cancellation sequence");
    }
    System.out.println("LOCAL_CANCEL actual_cancel_count=1 actual_ack_count=1 network_failure_count=0 diagnostic_lines=" + lines.size());
  }

  static void outgoingReadOnly() throws Exception {
    PreconditionProbe.Call call = scopedCall("234", "33");
    accept(call, PreconditionProbe.response(call.initial, 180, "A", "", ""));
    Object request = SipForkProbe.call(call.nativeSession.m, "k", new Class<?>[] {String.class, Class.forName("ma4"), byte[].class},
        "UPDATE", call.dialog(), null);
    byte[] before = wire(request);
    SipForkProbe.Snapshot requestSnapshot = new SipForkProbe.Snapshot(request), dialogSnapshot = new SipForkProbe.Snapshot(call.dialog());
    SipForkProbe.call(call.nativeSession.e, "C", new Class<?>[] {Class.forName("kb4")}, request);
    check(Arrays.equals(before, wire(request)), "actual C preserves request bytes");
    check(PreconditionProbe.last("UPDATE").equals(new String(before, StandardCharsets.UTF_8)),
        "actual C transmits exact serialized request");
    requestSnapshot.unchanged("actual C request unchanged");
    dialogSnapshot.unchanged("actual C dialog unchanged");
    Object gm = SipForkProbe.get(call.nativeSession.e, "q");
    Object config = SipForkProbe.get(call.nativeSession.e, "b");
    Object useIpsec = SipForkProbe.get(config, "t");
    try {
      SipForkProbe.set(call.nativeSession.e, "q", null);
      SipForkProbe.set(config, "t", false);
      SipForkProbe.call(call.nativeSession.e, "C", new Class<?>[] {Class.forName("kb4")}, request);
    } finally { SipForkProbe.set(call.nativeSession.e, "q", gm); SipForkProbe.set(config, "t", useIpsec); }
    List<String> lines = diagnostics(call);
    expected(lines, "提交 UPDATE");
    if (!previous) check(find(lines, "Gm上下文=无") != null, "absence of Gm context is reported without inference");
  }

  static void carrierResult(String mcc, String mnc, int status) throws Exception {
    PreconditionProbe.Call call = scopedCall(mcc, mnc);
    accept(call, PreconditionProbe.response(call.initial, 100, "A", "", ""));
    accept(call, PreconditionProbe.response(call.initial, 180, "A", "",
        "Reason: Q.850;cause=19;text=\"" + PRIVATE + "\"\r\n"));
    accept(call, PreconditionProbe.response(call.initial, status, "A", "",
        "Reason: Q.850;cause=17;text=\"" + PRIVATE + "\"\r\nWarning: 399 host \"" + PRIVATE + "\"\r\n"));
    check(PreconditionProbe.count("ACK") == 1 && PreconditionProbe.count("CANCEL") == 0,
        "remote non-success response produces an ACK without a local CANCEL");
    List<String> lines = diagnostics(call);
    if (previous || carrierLimited) {
      check(lines.isEmpty(), "prior build omits the operator's diagnostics");
    } else {
      expected(lines, "提交 INVITE", "收到 100 INVITE", "收到 180 INVITE", "收到 " + status + " INVITE");
      String start = find(lines, "提交 INVITE"), end = find(lines, "收到 " + status + " INVITE");
      check(start.contains("被叫地址类型=TEL（国际）"), "safe target type reported");
      check(token(start) != null && token(start).equals(token(end)), "response linked to original call");
      check(find(lines, "收到 180 INVITE").contains("Reason=Q.850/19"), "provisional Reason survives");
      check(end.contains("Reason=Q.850/17") && end.contains("Warning=399"), "final numeric facts survive");
      check(find(lines, "提交 CANCEL") == null, "no local cancellation logged");
    }
    System.out.println("CARRIER_RESULT plmn=" + mcc + mnc + " final=" + status + " diagnostic_lines=" + lines.size());
  }

  static void scopeAndPrivateValues() throws Exception {
    PreconditionProbe.Call call = scopedCall("234", "33");
    for (String value : new String[] {"sendrecv", "sendonly", "recvonly", "inactive", "gated", PRIVATE}) {
      accept(call, PreconditionProbe.response(call.initial, 180, "A", "",
          "P-Early-Media: " + value + "\r\nReason: NotAllowed;cause=999;text=\"" + PRIVATE
              + "\"\r\nWarning: private-warning \"" + PRIVATE + "\"\r\n"));
    }
    accept(call, PreconditionProbe.response(call.initial, 180, "A", "",
        "P-Early-Media: sendonly, sendrecv, gated\r\n"));
    accept(call, PreconditionProbe.response(call.initial, 180, "A", "",
        "P-Early-Media: " + String.join(",", Collections.nCopies(20, "sendonly")) + "\r\n"));
    accept(call, PreconditionProbe.response(call.initial, 180, "A", "",
        "P-Early-Media: " + String.join(",", Collections.nCopies(300, PRIVATE)) + "\r\n"));
    List<String> lines = diagnostics(call);
    if (previous) check(lines.isEmpty(), "baseline has no scope/allowlist diagnosis");
    else {
      for (String value : new String[] {"sendrecv", "sendonly", "recvonly", "inactive", "gated"})
        check(find(lines, value) != null, "allowed P-Early-Media token retained " + value);
      check(find(lines, "未识别值") != null, "unknown P-Early-Media is indicated without raw value");
      check(find(lines, "sendonly/sendrecv/gated") != null, "P-Early-Media direction order is preserved");
      check(find(lines, "sendonly/sendonly/sendonly/sendonly/sendonly/sendonly/sendonly/sendonly/其余已省略") != null,
          "repeated media direction tokens are bounded without reordering or deduplication");
      check(find(lines, "NotAllowed") == null,
          "non-allowlisted Reason scheme cannot disclose numeric or string data");
    }
    Object update = SipForkProbe.call(call.nativeSession.m, "k", new Class<?>[] {String.class, Class.forName("ma4"), byte[].class},
        "UPDATE", call.dialog(), null);
    accept(call, PreconditionProbe.response(new String(wire(update), StandardCharsets.UTF_8), 487, "unused", "",
        "Reason: SIP;text=\"" + PRIVATE + ";cause=777,Q.850;cause=888\"\r\n"
            + "Reason: NotAllowed;cause=999\r\n"
            + "Warning: 399 diagnostic.example.invalid \"" + PRIVATE + ", 777 hidden-code\"\r\n"));
    List<String> finalLines = diagnostics(call);
    if (!previous) {
      String line = find(finalLines, "收到 487 UPDATE");
      check(line != null && !line.contains("Reason="), "quoted text cannot manufacture a Reason cause");
      check(line != null && line.contains("Warning=399") && !line.contains("399,777"),
          "quoted warning text cannot manufacture a warning code");
    }
  }

  public static void main(String[] args) throws Exception {
    previous = args[0].equals("previous-24-4");
    carrierLimited = args[0].equals("previous-24-9");
    SipForkProbe.msg = Class.forName("kb4"); SipForkProbe.dialog = Class.forName("ma4");
    SipForkProbe.manager = Class.forName("cb4"); SipForkProbe.direction = Class.forName("ga4");
    SipForkProbe.state = Class.forName("la4");
    SipForkProbe.helper = Class.forName("cc.forserein.simhub.internal.SipForkProtection");
    remoteTermination(); localCancellation(); outgoingReadOnly(); scopeAndPrivateValues();
    carrierResult("206", "20", 487); carrierResult("262", "02", 486);
    System.out.println("CALL_DIAGNOSTICS_PROBE mode=" + args[0]
        + " checks=" + checks + " native_snapshot_checks=" + SipForkProbe.checks
        + " shared_path_checks=" + PreconditionProbe.checks + " diagnostic_lines=" + diagnosisCount + " no_network=true");
  }
}
