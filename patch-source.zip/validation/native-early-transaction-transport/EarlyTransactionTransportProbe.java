import java.util.*;
import java.nio.charset.StandardCharsets;

/** Shipped native cb4.p, a82.f, o82.C/h/a and CTExcel Gm packet serialization. */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class EarlyTransactionTransportProbe {
  static boolean previous;
  static int checks, helperGuardChecks;
  static Object get(Object x,String f)throws Exception{return SipForkProbe.get(x,f);}
  static void set(Object x,String f,Object v)throws Exception{SipForkProbe.set(x,f,v);}
  static Object call(Object x,String m,Class<?>[] types,Object...args)throws Exception{return SipForkProbe.call(x,m,types,args);}
  static void check(boolean value,String text){if(!value)throw new AssertionError(text);checks++;}
  static double now()throws Exception{return (Double)Class.forName("o82").getMethod("p").invoke(null);}
  static String wire(Object message)throws Exception{return new String((byte[])call(message,"b",new Class<?>[0]),StandardCharsets.UTF_8);}
  static void header(Object message,String name,String value)throws Exception{call(message,"i",new Class<?>[]{String.class,String.class},name,value);}
  static List timers(PreconditionProbe.Call c)throws Exception{return (List)get(c.dialog(),"F");}
  static Object timer(PreconditionProbe.Call c,String method)throws Exception{
    Object found=null;
    for(Object t:timers(c))if(method.equals(get(get(t,"a"),"b"))){check(found==null,"one pending "+method+" timer");found=t;}
    return found;
  }
  static int count(String method)throws Exception{return PreconditionProbe.count(method);}
  static void tick(PreconditionProbe.Call c)throws Exception{OutboundTransportProbe.tick(c.nativeSession);}
  static boolean active(PreconditionProbe.Call c)throws Exception{return ((Map)get(c.nativeSession.m,"e")).get(get(c.dialog(),"b"))==c.dialog();}
  static void accept(PreconditionProbe.Call c,String request,int status)throws Exception{
    c.accept(PreconditionProbe.response(request,status,"unused","",""));
  }
  static void directFallback(Object engine,Object queued)throws Exception{
    Class.forName("cc.forserein.simhub.internal.SipEarlyTransactionTransport")
        .getMethod("onFallbackSent",Object.class,Object.class).invoke(null,engine,queued);
  }
  static PreconditionProbe.Call fresh(boolean tcp)throws Exception{
    PreconditionProbe.Call c=new PreconditionProbe.Call(tcp);
    set(get(c.nativeSession.e,"b"),"d","234");set(get(c.nativeSession.e,"b"),"e","33");
    return c;
  }
  static final class Pending {
    final PreconditionProbe.Call c;
    final String method;
    final Object queued,timer,original;
    final double deadline;
    final String originalWire;
    Pending(String method)throws Exception{
      this.method=method;c=fresh(true);
      if(method.equals("UPDATE")){
        PreconditionProbe.progress(c,"A",1,true,PreconditionProbe.answer(true));
        String prack=PreconditionProbe.last("PRACK");
        set(c.nativeSession.e,"U",false);
        accept(c,prack,200);
      }else{
        set(c.nativeSession.e,"U",false);
        PreconditionProbe.progress(c,"A",1,true,PreconditionProbe.answer(true));
      }
      List q=(List)get(c.nativeSession.e,"V");
      check(q.size()==1&&method.equals(get(q.get(0),"b")),"native C queues one pending "+method);
      queued=q.get(0);originalWire=wire(queued);timer=timer(c,method);
      check((timer==null)==previous,"TCP deadline tracked only in fixed build for "+method);
      original=timer==null?null:get(timer,"a");deadline=timer==null?0:(Double)get(timer,"e");
      if(timer!=null){
        check(original!=queued&&originalWire.equals(wire(original)),"native TCP queue clone remains independent");
        check(Double.isInfinite((Double)get(timer,"c"))&&Double.isInfinite((Double)get(timer,"d")),"ordinary TCP has no retransmission interval");
        check(deadline>now()&&deadline<=now()+32.1,"original transaction deadline is bounded at native 32s");
      }
    }
    void fallback()throws Exception{OutboundTransportProbe.fallback(c.nativeSession);}
  }

  static void retryAndCompletion(String method,int finalStatus)throws Exception{
    Pending p=new Pending(method);Object selected=get(p.c.dialog(),"l"),target=get(p.c.dialog(),"g"),route=get(p.c.dialog(),"m"),sdp=get(p.c.dialog(),"p");
    p.fallback();String fallback=PreconditionProbe.last(method);
    check(PreconditionProbe.first(PreconditionProbe.parse(fallback),"Via").startsWith("SIP/2.0/UDP"),"actual fallback serializes UDP "+method);
    check(get(p.c.dialog(),"l")==selected&&get(p.c.dialog(),"g")==target&&get(p.c.dialog(),"m")==route&&get(p.c.dialog(),"p")==sdp,"fallback leaves selected dialog route/target/SDP intact");
    int sends=count(method);
    if(previous){
      check(timer(p.c,method)==null,"baseline lacks fallback "+method+" retransmission timer");
      tick(p.c);check(count(method)==sends,"baseline native tick cannot retransmit missing transaction");
    }else{
      check(timer(p.c,method)==p.timer&&get(p.timer,"a")==p.original,"fallback reuses exact timer and original request");
      check((Double)get(p.timer,"e")==p.deadline,"fallback retains absolute deadline");
      check(wire(p.original).equals(fallback),"timer retransmits exact fallback Via, route, URI, headers and body");
      check((Double)get(p.timer,"c")==0.5,"UDP starts at native T1");
      double next=(Double)get(p.timer,"d");directFallback(p.c.nativeSession.e,p.queued);
      check(timer(p.c,method)==p.timer&&(Double)get(p.timer,"d")==next&&(Double)get(p.timer,"e")==p.deadline,"repeat hook neither duplicates nor extends transaction");
      for(double interval:new double[]{1,2,4,4}){
        set(p.timer,"d",now()-1);tick(p.c);
        check(count(method)==++sends,"actual native scheduler retransmits "+method);
        check((Double)get(p.timer,"c")==interval,"native retransmit interval doubles and caps at 4s");
        check((Double)get(p.timer,"e")==p.deadline,"retry cannot extend deadline");
        check(PreconditionProbe.last(method).equals(fallback),"each native Gm UDP retransmission preserves full SIP bytes");
      }
      if(method.equals("PRACK")){
        PreconditionProbe.progress(p.c,"A",1,true,PreconditionProbe.answer(true));
        check(count(method)==sends,"duplicate183 neither builds another PRACK nor bypasses its timer");
      }
    }
    accept(p.c,fallback,finalStatus);
    check(timer(p.c,method)==null,"native final response removes matching "+method+" timer");
    if(!previous){directFallback(p.c.nativeSession.e,p.queued);check(timer(p.c,method)==null,"post-final hook cannot resurrect completed transaction");}
    check(count("CANCEL")==0,"transaction repair never cancels or redials");
    System.out.println("RETRY method="+method+" final="+finalStatus+" baseline_missing="+previous);
  }

  static void tcpAndTimeout(String method)throws Exception{
    Pending p=new Pending(method);int count=count(method);tick(p.c);
    check(count(method)==count,"pending TCP does not acquire UDP retries");
    if(!previous){
      set(p.timer,"e",now()-1);tick(p.c);
      check(timer(p.c,method)==null&&active(p.c),"TCP Timer F expires without ending INVITE");
      check(count(method)==count&&count("CANCEL")==0,"TCP deadline expiry sends neither UDP nor CANCEL");
    }
    p.fallback();check(timer(p.c,method)==null,"already-expired TCP transaction cannot revive on fallback");
    count=count(method);tick(p.c);check(count(method)==count,"expired fallback cannot retransmit");

    p=new Pending(method);p.fallback();count=count(method);
    if(!previous){set(p.timer,"e",now()-1);set(p.timer,"d",now()-2);}
    tick(p.c);check(timer(p.c,method)==null&&active(p.c),"UDP transaction expiry uses native cleanup");
    check(count(method)==count&&count("CANCEL")==0,"expired timer is removed before another retry");
  }

  static void finalBeforeFallback(String method,int status)throws Exception{
    Pending p=new Pending(method);accept(p.c,p.originalWire,status);
    check(timer(p.c,method)==null,"response received on TCP removes pending timer");
    p.fallback();check(timer(p.c,method)==null,"actual fallback after final response does not revive timer");
  }

  static void inviteEndedBeforeFallback(boolean accepted)throws Exception{
    Pending p=new Pending("PRACK");
    p.c.accept(PreconditionProbe.response(p.c.initial,accepted?200:487,"A",accepted?PreconditionProbe.answer(false):"",""));
    p.fallback();
    if(accepted){
      check(get(p.c.dialog(),"D")!=null&&active(p.c),"accepted INVITE remains accepted");
      if(!previous)check(Double.isInfinite((Double)get(p.timer,"c"))&&Double.isInfinite((Double)get(p.timer,"d")),"confirmed call does not arm old early transaction");
    }else check(!active(p.c)&&timers(p.c).isEmpty(),"terminated INVITE remains removed with no timers");
  }

  static void normalTransports()throws Exception{
    PreconditionProbe.Call c=fresh(false);PreconditionProbe.progress(c,"A",1,true,PreconditionProbe.answer(true));
    Object nativeTimer=timer(c,"PRACK");check(nativeTimer!=null&&(Double)get(nativeTimer,"c")==0.5,"ordinary UDP keeps exactly its native timer");
    c=fresh(true);PreconditionProbe.progress(c,"A",1,true,PreconditionProbe.answer(true));
    int sends=count("PRACK");tick(c);check(count("PRACK")==sends,"working TCP never retransmits PRACK");
    accept(c,PreconditionProbe.last("PRACK"),200);check(timer(c,"PRACK")==null,"working TCP final removes PRACK deadline");
    check(((List)get(c.nativeSession.e,"V")).isEmpty(),"established TCP never used fallback queue");
    for(String method:new String[]{"INFO","OPTIONS","BYE","CANCEL","UPDATE"}){
      Object req=call(c.nativeSession.m,"k",new Class<?>[]{String.class,Class.forName("ma4"),byte[].class},method,c.dialog(),null);
      int before=timers(c).size();call(c.nativeSession.m,"p",new Class<?>[]{Class.forName("kb4"),Class.forName("ma4"),double.class},req,c.dialog(),now());
      check(timers(c).size()==before,"unrelated/bodyless TCP request not tracked: "+method);
    }
  }

  static void correlationGuards()throws Exception{
    if(previous)return;
    for(String change:new String[]{"Via","From","To","Call-ID","CSeq","RAck","URI","Route","body"}){
      Pending p=new Pending("PRACK");Object q=PreconditionProbe.parse(p.originalWire);
      header(q,"Via",PreconditionProbe.first(q,"Via").replace("SIP/2.0/TCP","SIP/2.0/UDP"));
      if(change.equals("URI"))set(q,"c","sip:other@example.invalid");
      else if(change.equals("body"))set(q,"g","different".getBytes(StandardCharsets.UTF_8));
      else if(change.equals("CSeq"))header(q,change,"2147483647 PRACK");
      else if(change.equals("RAck"))header(q,change,"900 900 INVITE");
      else if(change.equals("Via"))header(q,change,PreconditionProbe.first(q,change)+";changed=true");
      else header(q,change,"changed@example.invalid");
      set(p.c.nativeSession.e,"W",true);directFallback(p.c.nativeSession.e,q);
      check(timer(p.c,"PRACK")==p.timer&&wire(p.original).equals(p.originalWire)
          &&Double.isInfinite((Double)get(p.timer,"d"))&&(Double)get(p.timer,"e")==p.deadline,"mismatched fallback cannot alter transaction: "+change);
      helperGuardChecks++;
    }
    Pending p=new Pending("PRACK");
    int size=timers(p.c).size();double deadline=p.deadline;
    call(p.c.nativeSession.m,"p",new Class<?>[]{Class.forName("kb4"),Class.forName("ma4"),double.class},p.original,p.c.dialog(),now());
    check(timers(p.c).size()==size&&(Double)get(p.timer,"e")==deadline,"same TCP transaction cannot be duplicated or extended");
  }

  static void earlyBranches()throws Exception{
    Pending p=new Pending("PRACK");
    PreconditionProbe.progress(p.c,"B",1,true,PreconditionProbe.answer(true));
    check(((List)get(p.c.nativeSession.e,"V")).size()==2,"two early branches have independently queued PRACKs");
    String selected=(String)get(p.c.dialog(),"l");Object route=get(p.c.dialog(),"m"),body=get(p.c.dialog(),"p");
    List<Object> pending=new ArrayList<>();for(Object t:timers(p.c))if("PRACK".equals(get(get(t,"a"),"b")))pending.add(t);
    check(pending.size()==(previous?0:2),"independent branch deadlines tracked");p.fallback();
    check(selected.equals(get(p.c.dialog(),"l"))&&route==get(p.c.dialog(),"m")&&body==get(p.c.dialog(),"p"),"replaying recorded branch transactions never selects or rewrites a dialog");
    for(Object t:pending)check((Double)get(t,"c")==0.5,"each still-pending branch gets its own UDP cadence");
    int before=count("PRACK");for(Object t:pending)set(t,"d",now()-1);tick(p.c);
    check(count("PRACK")==before+pending.size(),"native scheduler retransmits both exact branch PRACKs");
  }

  public static void main(String[]args)throws Exception{
    previous=args.length>0&&args[0].equals("previous-24-5");
    SipForkProbe.msg=Class.forName("kb4");SipForkProbe.dialog=Class.forName("ma4");SipForkProbe.manager=Class.forName("cb4");SipForkProbe.direction=Class.forName("ga4");SipForkProbe.state=Class.forName("la4");SipForkProbe.helper=Class.forName("cc.forserein.simhub.internal.SipForkProtection");
    for(String method:new String[]{"PRACK","UPDATE"}){
      retryAndCompletion(method,200);retryAndCompletion(method,481);tcpAndTimeout(method);
      finalBeforeFallback(method,200);finalBeforeFallback(method,481);
    }
    inviteEndedBeforeFallback(false);inviteEndedBeforeFallback(true);normalTransports();correlationGuards();earlyBranches();
    System.out.println("EARLY_TRANSACTION_TRANSPORT mode="+(previous?"previous-24-5":"fixed")+" checks="+checks
        +" shared_checks="+PreconditionProbe.checks+" guard_checks="+helperGuardChecks+" protected_packets="+PreconditionProbe.protectedPackets+" no_network=true");
  }
}
