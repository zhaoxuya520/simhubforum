# SIMCAT SIM/eUICC 管理与 SIMHub 23.3 对照

2026-11-17，只读审查。未改 SIMHub 生产代码、原生 APDU、签名或 MultiChipSwitch；未启动 SIMCAT 应用/Go 引擎、未发送物理 APDU，也未上传用户 APK。

**结论：SIMCAT 的实际启禁流程提供了同一 EID 内“先关闭、读回确认、再启用”的实现，不能证明解决了用户的跨芯片旧配置仍启用问题。它始终携带 `refreshFlag=false`，也没有对另一个 EID/ISD-R 上的旧配置发起关闭的流程。本轮不建议移植其切卡代码。**

## 输入与证据

- 用户 APK：`../SIMCAT-v0.0.1.apk`，SHA-256 `edd3a9ca5f144e9b9ca278a6020c149aca159b140d2a7520e5bb1075f99eef91`。
- 官方发布库：<https://github.com/ecChat/simcat.org>，固定提交 `3b50dadb1c7c9f326dc9d73f7797d9891bfd811f` 的发布校验文件与用户 APK 完全匹配。该仓库只有发布产物，未找到应用源码/源码许可。完整链接、API 原文、依赖参考源码许可在 `public-source/SOURCE-REVIEW.zh-CN.md` 和 `source-provenance.json`。
- `decoded/smali` 是 APK 原始字节码的反汇编依据；`switch-review/decompiled` 是 CFR 辅助阅读产物，有反编译失败/控制流伪影，关键结论均核对 Smali 或执行原 APK 方法。
- `method-evidence.json` 保存相关 Smali 文件 SHA-256 和方法起始行，以下行号均指 `../decoded/smali/org/jm01/euicc/`。
- 实际 APK 协议方法探针：`SimcatSwitchProbe.java`、`run_probe.py`、`switch-probe.log`、`switch-probe-report.json`。12 项通过；仅替换物理 `N` 传输接口，未替换 Z/T/j/l 协议方法。dex2jar JVM 兼容转换只补 R8 构造桥（37 个调用、16 个转发构造器）；没有在 ART/真实卡上执行。

## 实际启用调用链

1. `MainActivity.beginCardOp`（1809 行）捕获 source、目标 reader/device、slot、EID、原启用 ICCID、目标 ICCID，设置当前 Activity 的 `reading=true`，递增 `uiGeneration`，通过单线程 `worker` 执行。
2. `lambda$beginCardOp$53`（8081 行）新建 `Q.c` transport，然后调用 `Q.d(eid, oldIccid, targetIccid)`，结束关闭 transport。`postCurrent`（13258 行；回调判断在 10616 行）仅在 generation 仍相等、Activity 未销毁时发布结果。
3. `Q.d`（1214 行）在 OMAPI/CCID 路径调用 `Z.v`；USB AT 棒采用 `V` 对象的同一套单卡验证思路。主 Activity 对 `source=ble` 提示使用 BLE 流程，没有假装该 worker 覆盖全部 BLE 操作。
4. `Z.v`（4337 行）先 `Z.m()` 读取 EID 和 profiles，要求当前 EID 和预期 EID 一致、当前启用 ICCID 和操作前快照一致。目标必须在这份 profile 列表里，已经启用时直接拒绝重复写入。
5. 若该 EID 有旧启用 profile，`Z.B(Z.w(oldAid,false))` 发送关闭。明确拒绝直接停止；丢失响应后不重发，转入读回。只有同一 EID 的读回列表中没有启用 profile，才发送 `Z.B(Z.w(targetAid,true))`。
6. 启用后读回同一 EID 且目标 ICCID 为 enabled 才返回成功；不确定结果明确标记，不做自动写重试。

`Z.w`（463 行）从 APK 精确提取为：`E291001A` + `BF31/BF32` + `17A0124F10` + 目标 ISD-P AID + `810100`。最后的 `810100` 是 false refresh 参数。这里只记录真实参考行为，不向 SIMHub 引入该字节序列。

`Z.A`（561 行）和 `Z.s`（4016 行）：通常仅读回 2 次、间隔 800 ms；9eSIM 为 6 次、间隔 1500 ms。AT 棒 `Q.d/Q.b` 使用 18 次、间隔 2000 ms。它不是统一的跨芯片刷新状态机。

## 为什么这不等于跨芯片修复

- `Q.c` 的 OMAPI 分支只构建一个指定名称的 `o1` reader，随后 `new Q(transport,0)` 固定该 transport slot。
- `o1.g()`（801 行）固定返回 1，`o1.h()` 返回 0，`o1.i()`（817 行）只接受 slot 0。
- `Z.m()`（2411 行）可能对 CCID 的物理 slot 尝试读取，但返回第一个成功 snapshot；`Z.v` 后续的禁用和启用都在同一 transport 上。它不会保存“旧 EID + 旧 ISD-R AID + 旧 profile”的独立上下文并切回那里关闭。
- `T` 构造（44 行）拒绝一份 snapshot 内多个 enabled profile。这个规则不能直接用作 SIMHub 所有芯片/MEP 端口的全局规则；合法独立端口可以各自有启用配置。
- `Z` 的品牌 AID 表只用于辨认卡片/选择应用，不是多个芯片的互斥协调器。
- `l.A`（49 行）替换当前通信 transport 时会停止旧 IMS、关闭 bridge、disconnect 旧 transport；**关闭 transport 不会发送 DisableProfile，也不等于旧 profile 关闭。**

12 项实际方法探针确认：同卡成功顺序是 disable → 读回 → enable；旧配置仍 enabled 时只发送一次 disable、不发送 enable；明确拒绝不重发；丢回应但卡已完成关闭时可读回再继续；EID/旧 ICCID 不匹配时没有写操作；多 enabled snapshot 被拒绝。探针不构造真实多芯片硬件，因此不能宣称 SIMCAT 的跨芯片实机能力。

## OMAPI、USB、BLE 与资源恢复

| 路径 | APK 中实际行为 | 可迁移性判断 |
|---|---|---|
| OMAPI `o1.j/f/i/disconnect`（927/624/817/470 行） | 同一实例同步开通道/传输/重连/断开；SEService 最长等待 12 秒；优先 ISD-R，失败尝试 basic/USIM；IOException 标记连接失效，下次 i(0) 才重连；失败不自动重发原 APDU | 有明确实例所有权，但不是全应用/多芯片锁。SIMHub 已有 ChannelLease/ConnectionLease 取消释放与 OmapiSupport 失效分类，未发现可证明比现有实现更好的新移植点 |
| CCID `Z1.f/i/close`（477/737/333 行） | 单实例 APDU 同步、USB slot 与 sequence framing；open/close power、claim/release interface；Z 操作后 close，下一次读取重新建立 | 不应将物理 USB slot 与芯片 ISD-R 混为一谈 |
| AT `W1.a/e/close`、`V.f` | AT 命令同步；一次唯一 CCHO owner，finally CCHC；会话不同步后停止写入，报告不确定而不重发 | 能参考“不确定不重写”的原则，SIMHub 当前传输同样不自动重发 mutation；不构成跨芯片实现 |
| BLE `h.f`（411 行）、`l1.t`（2538 行） | BeeSIM 实例同步传输；9eSIM 分片序号、队列、校验、30 秒 deadline，超时保留链路且明确不重发；部分方法同步不代表全部事务全局互斥 | 不复制协议、设备特定回收通道或超时策略。9eSIM/BeeSIM 的扫描式关闭逻辑通道不能用于 Android OMAPI |
| Activity worker/generation | 防止同 Activity 重复点击、过期结果覆盖当前 UI | 可以作为今后可复现 UI 竞态的设计参考，本轮没有证实 SIMHub 相同路径存在新回归，不为“借鉴”强行增加锁 |

## 与 SIMHub 23.3 逐项对照

| 行为 | SIMCAT | 我们当前版本 | 结论 |
|---|---|---|---|
| 目标 profile 定位 | 单 reader/EID snapshot + ISD-P AID | `iz3.a` 根据目标 ICCID 找 `xx3`，将其 ISD-R AID 写入 `hh1.c`；随后 `hz3.q` 在该管理 context 操作目标 | 两者都不能仅凭目标 enabled 证明另一芯片已 disabled |
| 启禁原生命令 | 总是 AID 标识 + refresh false | `rf1.i → ProfileRefresh.command` 使用 ICCID 标识；手机 s4 transport 为 refresh true，外置 reader 为 false | 不应把 SIMCAT 固定 false 覆盖我们的手机刷新逻辑 |
| 写入重试 | 已发送但回应丢失后只读回 | `OmapiSupport.transmit` 单次传输，失效明确报错；实验 no-refresh 协调/重试入口未接入 | 保持现有不盲目重发策略 |
| 读回确认 | 同 EID、目标 enabled；关闭阶段要求列表无 enabled | `hz3.q` 手机路径首次等待 3 秒、后续 1 秒，最多 30 次；`InternalSimProfileState.matches → ProfileRefresh.confirmed` 校验目标唯一且状态相符 | 我们的等待更适合 modem refresh；不能把 SIMCAT 全局单 enabled 假设直接移植 |
| 普通 SIM/USIM 身份 | 管理 EID/active ICCID 是写操作前置条件 | `IdentityBinding` 对 USIM 异步读取做 generation 隔离；管理选择仅用于诊断，新的真实 USIM 读值决定通信身份 | 不重新引入“管理页尚未确认即禁止 WiFi Calling”的旧回归 |
| 资源取消 | o1 同步对象断开；Activity close | ChannelLease/ConnectionLease 处理取消、重复 attach、释放未交付 channel/session/service；OmapiSupport 保留具体访问错误 | 现有机制已有测试，不换成未验证参考实现 |
| 跨芯片协调 | 未发现跨 EID 关闭旧 profile 路径 | `multichip_patch.py` 保证实验 MultiChipSwitch 等入口缺席，build 排除该类 | 继续禁用，不以参考 APK 为理由启用 |

SIMHub 当前 `ProfileRefresh.confirmed` 只证明“目标 profile 在当前返回列表里的状态”；没有宣称跨芯片全局互斥。真正解决用户历史问题还需要确定旧芯片所对应的管理 AID/通道、刷新后恢复其可达性，并在原芯片验证关闭。SIMCAT 没提供这部分硬件依据。

## 本轮建议

保留我们的原生启禁/刷新与身份读取路径，不引入 SIMCAT 的关闭-启用串联、固定 false refresh、扫描关闭逻辑通道或全局单 enabled 约束。没有找到足够证据支持本轮修改 SIMHub 切卡生产代码。能确定的收获是把状态表述、读回确认和写入不确定性保持清晰；若后续实机重现 UI 过期结果或资源竞态，再以实际日志与测试做局部修复。
