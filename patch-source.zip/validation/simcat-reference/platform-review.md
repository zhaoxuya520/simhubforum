# SIMCAT Android 音频、服务、网络对照

样本：`SIMCAT-v0.0.1.apk`，SHA-256 `edd3a9ca5f144e9b9ca278a6020c149aca159b140d2a7520e5bb1075f99eef91`。SIMCAT versionCode 157、minSdk 26、targetSdk 32、compileSdk 35；SIMHub 23.3 实际 manifest 为 minSdk 26、targetSdk 37。本文以解码后的 smali 为依据，CFR 只帮助导航；未运行 SIMCAT 真机呼叫或修改它。

## 可以借鉴并已获准实施：通知绑定通话身份

- SIMCAT `org/jm01/euicc/E1.smali` 的 `a(String)` 创建 Answer/Decline PendingIntent，使用递增 requestCode，并带 `call_id`。`NativeIMS.smali:4638` 的 `notificationCommand(String,String)` 在执行前检查非空 call_id、与当前 callId 相等、仍是 incoming。
- SIMHub `sj5.l` 使用固定请求码 20/21/22/23，动作只有 SHOW/ANSWER/DECLINE/HANGUP，没有通话身份。`CallActionReceiver.onReceive` 直接执行当前 `k10.e/l`，`CallActivity.onCreate/onNewIntent` 只判断 ANSWER 后进入 `i()`。
- 已用实际 23.3 接收器和 Activity 方法、显式 Android/执行出口替身复现旧 A 通知操作新 B；这属于本地异步动作归属错误，不是运营商故障。另发现 `au0.e` 的麦克风授权回调不核对原待接听通话，也不检查授权 Boolean。
- 方案：用原生 `u00.a` SIP call ID 和 `u00.j` 每通 UUID token 共同绑定，加入唯一 PendingIntent data URI（只加 extras 不能避免固定 requestCode 的 UPDATE_CURRENT 替换问题）。无身份、旧身份、状态不符的危险动作不执行；普通 SHOW 保持可用。授权成功后只继续原通来电，拒绝或取消不接听。
- 在 `k10.b/h` 取得最终 `u00` 后再次核对显式 scoped identity。随后原生 `d10` 协程继续捕获该对象及其 call ID；未带 scope 的 Telecom/耳机原生控制路径保持原样。实现和独立探针在 patch 项目的 `notification_action_patch.py`、`CallNotificationGuard.java`、`validation/native-notification/`。

## 音频：不直接移植 SIMCAT 的路由策略

证据：`org/jm01/euicc/D1.smali` 构造函数、`a()`、`b(byte[])`、`close()`；录音循环在 `E.smali` 的 D1 分支。

- 固定 8000 Hz、单声道 PCM16，每帧 320 字节即 20 ms；MIC(source 1) 优先，失败才尝试 VOICE_COMMUNICATION(source 7)。播放使用 USAGE_MEDIA(1)、CONTENT_TYPE_MUSIC(2)，AudioTrack volume 1.0。
- 主动检查 STREAM_MUSIC(3) 静音并解除静音；音量低于最大值 70% 时升至约 85%。这会修改手机的日常媒体音量，不符合本项目保持通话与个人网络/日常使用分开的目标，不能作为“无声修复”直接搬入。
- 应用 DEX 中未找到 `requestAudioFocus`、`AudioFocusRequest`、`setMode`、`setCommunicationDevice`、`setSpeakerphoneOn`、Bluetooth SCO 路由调用。蓝牙权限主要服务于读卡器，不能据此推断蓝牙通话路由完善。
- 录音累积短读取，组成完整 320 字节帧后入队；队列构造容量 25，但实际发送前丢弃到低于 10 帧，约 200 ms。AudioRecord 负返回值使用 5 ms 重试；未见区分 ERROR_DEAD_OBJECT 的恢复。`AudioTrack.write(..., WRITE_NON_BLOCKING)` 返回值未检查，可能短写；这里是代码事实，不等于已实测用户丢音。
- SIMHub 23.3 已有通信音频用途、AudioFocus、MODE_IN_COMMUNICATION、Android 12+ communication device 选择、Telecom 托管分支、8k/16k 编码采样率和录音重采样、AEC/NS，以及本轮已验证的失败回收。继续保留这些实现。SIMCAT 的窄带播放器不应替换 AMR-WB 路径。

## 前后台服务与兼容

证据：`BleCardService.onCreate/enableMicrophone/onStartCommand/onDestroy/closeOwned`、`com/google/android/gms/common/stats/a.d/f`、`d0` 音频 open 回调。

- Service 初始以 connectedDevice(0x10) 提升前台，音频打开前升级为 connectedDevice|microphone(0x90)。API 26-28 使用两参 startForeground；29+ 用类型参数。通知有明确 Disconnect，onStartCommand 返回 START_NOT_STICKY(2)。会话资源归 Service 所有，Activity 退出不立即释放读卡器/IMS。
- Manifest 声明 FOREGROUND_SERVICE、CONNECTED_DEVICE、MICROPHONE、RECORD_AUDIO、POST_NOTIFICATIONS；来电通知频道高优先级、静音频道配合 Ringtone，按 ringer mode 决定响铃。未声明 MANAGE_OWN_CALLS / ConnectionService，也未声明 USE_FULL_SCREEN_INTENT，不能视为系统电话集成的参考实现。
- 未见应用申请或持有 WakeLock / WifiLock，也未见进程死亡后的持久恢复。不能把 START_NOT_STICKY 和持续前台通知描述成可靠保活。
- SIMHub 的 `VoWiFiForegroundService.a` 已按 API/通话状态尝试 specialUse、phoneCall、microphone 所需组合；smali 确认首个成功就返回（CFR 把该 break 反编译丢了，**不存在重复成功降级类型的已证实 bug**）。服务已有 partial wake lock、Wi-Fi latency lock，onDestroy 独立释放。
- 两者 targetSdk 差异很大。SIMCAT 在 target 32 下可启动，不证明同样的调用顺序在 SIMHub target 37、Android 新版的前台服务/麦克风限制下可行。服务升级已有实现，暂不移植；后续真机回归应覆盖后台来电、锁屏接听、授权拒绝和切换到其他声音应用。

## 网络选择和断线

- 全应用 DEX 未见 `ConnectivityManager`、Android `Network` 绑定、`NetworkCallback`、`bindProcessToNetwork` 或 `bindSocket`，也没有 VpnService。`libsimcat-engine.so` 实际是 Go ARM64 PIE 可执行文件，Java `NativeIMS.register()` 通过 ProcessBuilder 启动并用标准输入/输出 JSON RPC 控制。
- Java 层 engine EOF/IO 异常释放资源并提示 `Shared engine connection ended; retry manually`，未见 Android 网络变更自动重建服务逻辑。
- 协议审查代理补充：native `engineListenUDP`(0x29dad0) 调 `net.ListenUDP("udp4", addr)`；`engineNATSocket`(0x29d2b0) 同样调用 net.ListenUDP 并在 context 取消时关闭。这里不足以证明 Android Network 独立路由；native syscall 全路径未完整还原，结论应限定为“未找到可借鉴的 Android 按网络隔离实现”。
- SIMHub 已在 `VoWiFiForegroundService.onCreate` 注册 defaultNetworkCallback，`ka3.onAvailable` 比较先前 Network；切换时经 `gc.q` 进入“网络已切换，重新连接”流程。也未找到按 Android Network 的专用 IMS socket 绑定方案，不能承诺独立代理/只影响系统 Wi-Fi Calling。

资料目录包含 APK 译码 jar、选定类 CFR 导航输出、SIMHub manifest dump。这些只用于核查；本项目不包含或替换 SIMCAT 的可执行引擎。
