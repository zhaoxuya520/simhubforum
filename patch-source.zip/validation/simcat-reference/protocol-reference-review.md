# SIMCAT 协议静态审查与 SIMHub 23.3 对照

输入 APK SHA-256：edd3a9ca5f144e9b9ca278a6020c149aca159b140d2a7520e5bb1075f99eef91。没有上传 APK、绕过 Passport 或访问登录后的服务。未执行 ARM64 引擎；目前 x86_64 模拟器不能运行它。

libsimcat-engine.so/libeapstep.so 是带 Android linker64 的 Go PIE 可执行文件，Java NativeIMS 使用 ProcessBuilder 和标准输入/输出 JSON 桥接，不是 JNI 协议库。Go 元数据记录 module simcat、Go1.27.0、revision 4789fab483f070118d548b9a4bca8ea405385eae、vcs.modified=true。inspect_go.py 从完整 .gopclntab 恢复 7436 个函数地址，再用 ARM64 指令和真实 call target 核对；函数名字本身不作为功能完成证据。

## 最有价值的可借鉴行为：对话分叉保护

SIMCAT 的 rejectCallFork 位于0x28fa20–0x28fb40：把原call结构复制到独立栈对象，清除该副本的部分对话字段，captureCallDialog针对副本捕获新腿；0x28faa8调用sendCallACK，0x28fac4装载BYE，0x28fad4调用buildCallDialogRequest，0x28fb04发送。调用点handleCallResponse 0x289b08确实连接到这一实现。这是实际控制流证据，非单看函数名。

SIMHub 23.3已用实际o82.h入口复现漏洞：已选A后，同Call-ID/CSeq但不同To-tag的200将A的tag、Contact、Route和SDP全部覆盖成B；只发ACK，没有清理B。相同tag重传正确保留A并再ACK；尚未选腿的CANCEL晚到200正确ACK然后BYE。native-fork-entry.log保存结果；NativeForkEntryReview.java是回归fixture，SipTransportCollector.java只把最终发送边界o82.C替换为packet collector，h/cb4/SDP事件路径保持原生，防止发网。这是有明确平台边界适配的原生JVM回归，不是实机通话。

建议只处理已选确认腿收到不同tag的原INVITE 2xx：新腿用独立临时对话ACK/BYE，保留A全部状态和媒体；缓存按tag去重，重复2xx继续ACK。不要为此重写SIP状态机。根agent已经批准这一最小修复，后续实现为独立自写适配，未复制SIMCAT实现。

## 不应直接采用的部分

- 媒体：parseSDPAudio在0x27df34–0x27df9c明确比较amr/8000及amr/8000/1；decodeAMRRTP在0x27cf68仅调用一次amrRTPFrames，错误立即返回。amrRTPFrames的0x27c1fc仅按octet布尔选择OA/BE。未见我们23.3已有的AMR-WB与经验证的格式纠偏行为。SIMCAT音频Java固定8k的结论由平台审查相互印证；不替换SIMHub媒体核心。
- SMSC：resolveSessionSMSC 0x294660先取运行时SMS_SMSC；空时仅对ims.mnc010.mcc234.3gppnetwork.org返回+447802002606，其余空。engineSetSMSC把读到的值放回运行时map。这里没有全球运营商正式模板证据，也不能修复DITO身份问题。
- 注册：reregisterDelay 0x2b8880默认以绑定有效期的80%计算，然后钳制到120秒至86400秒，或使用PERSIST_REREG覆盖。小于120秒的绑定可能来不及刷新。SIMHub23.3已按实际有效期85%安排刷新，不应引入120秒下限。
- 自动重连：NativeIMS.start有1.5秒人工重试节流及worker排他，并明确no auto-retry。Go持久会话实际调用NAT keepalive、DPD、OPTIONS、reregister，但这不等于完整自动重连。run中普通reregister错误返回、aka_cooldown特殊处理，不宜把宣传文字当恢复能力。
- 网络隔离：engineListenUDP 0x29dad0和engineNATSocket直接调用net.ListenUDP；未见Android Network绑定桥接。无法据此提供仅WiFiCalling走独立节点的系统网络隔离。
- 会话定时器：已找到Invite构造Session-Expires:1800及广告timer，尚未证明完整RFC4028响应/角色/超时实现。不能因为出现字符串就认为比23.3的已测试实现完善。

## 可留待另行复现的候选

callDialogRoute 0x28df20先调用routeHasLR，再分别处理松散/严格路由；sameSIPTransaction 0x2bc520比较Call-ID/CSeq；acknowledgeReliableProvisional包含RSeq解析、缓存PRACK、重复时重发及失败路径。它们有代码控制流证据，但尚未完成与SIMHub真实入口的缺陷回归，不在当前融合范围。

## 公开源码与许可

GitHub公开repository搜索simcat（49个结果）、org.jm01.euicc、simcat VoWiFi、simcat esim、jm01 euicc、eeuicc，及commit搜索精确revision和simcat VoWiFi/eeuicc，未找到匹配协议源码。相关公开域名tools.eeuicc.com首页未提供匹配源码仓库；仅访问公开首页，没有绕过账号。不能由“未找到”断言绝对闭源，也不能由Go依赖或lpac开源许可推定SIMCAT自身许可。对应源代码/库复制许可未确认，因此不移植APK中的代码或二进制，只根据标准和验证后的行为自行实现修复。

主要产物：protocol-review-evidence.json、native/functions.json、native/*.asm、NativeForkEntryReview.java、SipTransportCollector.java、native-fork-entry.log；所有分析文件留在recovery目录，不把第三方逆向内容随应用发布。
