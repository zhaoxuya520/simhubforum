# SIMCAT 配置与诊断交互审查

参考 APK：`SIMCAT-v0.0.1.apk`，SHA-256 `edd3a9ca5f144e9b9ca278a6020c149aca159b140d2a7520e5bb1075f99eef91`。对照：当前 SIMHub 23.3 的 `WifiConfig*`、`CarrierPresets`、`IdentityBinding`。本次没有修改 SIMHub 生产代码。

结论：保留 SIMHub 现有配置管理。此 Android APK 可证实的优点主要是连接阶段呈现和集中诊断；没有足够代码证据证明它具备比我们更完整的运营商搜索、配置编辑、保存/重置能力。参考包的版本号与翻译文案不能作为功能已实现或质量更好的证据。

## 配置能力：文案与实际接线

| 项目 | 参考证据 | 实际结论 | SIMHub 取舍 |
|---|---|---|---|
| 自动/手动 ePDG、运营商预设、重置 | `decoded/assets/locales/en.json:8–16` | 翻译包含这些项目；对整个 DEX smali 检索未发现 `adv.epdgAuto/Manual/Presets/Reset` 字面引用。不能据此认定 Android 配置页已实现。 | 保留现有可搜索运营商、多条 ePDG、逐项重置。 |
| SMSC 自动、自定义、预设、重置 | 同文件 `34–40`、`751–759` | 文案声称卡内 EF_SMSP 优先及部分英国卡回退号码，但对应设置键在 DEX 无字面引用。这里不能证明真实回退条件或适用于 DITO。 | 不导入猜测 SMSC，不把号码当作全球官方模板。 |
| Android 到引擎的配置传递 | `decoded/smali/org/jm01/euicc/NativeIMS.smali`，`register()V`，起于 `2721`；JSON 构造约 `2833–2871` | 实际 `start.config` 新建为空对象，仅在开启录音时加入 `call_record=1`；没有读取/写入运营商/ePDG/SMSC 用户设置。引擎可能内部自动处理，但不能将其内部能力等同于可编辑页面。 | 不用此简化桥接替换我们的配置模型。 |
| SMS 发送配置 | 同类 `sendSms(String,String)`，起于 `5056` | 发出 `kind=command, cmd=sms_send, request, number, text`，Android 该方法不附带自定义 SMSC。 | 保留我们已验证的 SMSC 持久化和连接中单独更新路径。 |
| 配置保存/重置 | 已追踪本 APK 的 `getSharedPreferences` 调用 | 可见 locale、录音、诊断开关、登录/回调等偏好；未找到 IMS 配置草稿、原子整组保存、过期页面覆盖保护的 Android 实现。此为静态范围内未发现，不排除 native 内部其他配置来源。 | 不替换 SIMHub 的逐卡 key、版本记录 CAS、回滚、默认值/覆盖值分离。 |

完整键检索记录：`config-locale-references.json`。9 个代表性配置键存在于 locale，DEX 字面引用总数为 0；“零字面引用”不是对所有动态调用路径的数学证明，结合 `register()` 请求构造才支持上述有限结论。

## 有价值的候选，按优先级

1. **给现有连接状态/失败日志增加简短阶段摘要。**
   - 来源：`NativeIMS.chainStart/chainAdvanceTo/chainFail/chainFinish/chainStates`；`M1.k()` 创建 Card/Network/IKE/Auth/Tunnel/IMS 六段，`M1.m(boolean)` 从 `chainStates()` 渲染进行中、完成、失败；定位 `M1.smali:1089`、`:2417`，`NativeIMS.smali:4222`。
   - 优点：用户能区分尚未读卡、隧道鉴权、IMS 注册阶段，避免把网络超时误以为切卡或卡身份失败。
   - 融入方式：优先在 SIMHub 现有状态栏或日志首行显示真实阶段与终止原因，不新增一整套六步 UI，不更换现有页面。
   - 条件：使用我们已有连接状态和实际事件；参考实现部分推进依赖日志关键字，不能照搬。

2. **集中处理本地日志复制/导出的脱敏，并保留技术定位信息。**
   - 来源与实际探针由 `logs-review.md` / `redaction-probe.log` 补充；核心为 `org/jm01/euicc/i0` 的统一诊断入口和 sanitizer。
   - 优点：比每处自行决定遮蔽什么更容易保持一致，可保留 SIP 状态码、网络阶段、RTP 计数，移除用户号码、完整 IMSI、鉴权内容。
   - 融入方式：挂到 SIMHub 现有复制/分享动作，不增加云端上传或诊断服务。
   - 条件：重新实现并用合成样例验证。参考正则在带时间戳的 Authorization 和 `tel:+...` 标识上存在实际漏脱敏，不可直接复制或宣称“完全匿名”。

3. **配置载入失败时，在诊断中给出可定位的原因类别。**
   - 这是由参考集中诊断思路导出的 SIMHub 小改进，并不是声称参考 APK 有更好的配置编辑器。
   - 当前 `WifiConfigRuntime.error()` 面向用户统一显示“自定义配置未能载入”，日志只有异常类/根异常类。可在现有诊断中区分记录损坏、选择的模板不存在、模型构造失败，同时保持当前简洁弹窗，不输出配置全文或完整身份。
   - 优点：用户发日志时更容易识别是持久化还是模板问题；风险低于改配置语义。最终是否实施由主代理结合当前日志框架决定。

## 不应直接移植的逻辑：已运行参考 APK 代码验证

`NativeIMS.explainFailure()` 根据最近最多 6 条、每条最多 160 字符的诊断摘要做 `contains()` 分类。它会把普通的历史 `401` challenge 当成当前终止原因，也会把包含 `P-CSCF` 的明确算法拒绝判成没有 SIP 响应。

通过实际 APK 转换出的 `NativeIMS` 类，使用纯合成诊断输入反射调用私有方法（无网络、无 SIM）得到：

| 输入摘要 | 实际返回 |
|---|---|
| `P-CSCF rejected Security-Server; did not accept an offered IMS IPsec suite` | P-CSCF 已获得但没有 SIP 响应 |
| 正常 `SIP REGISTER 401 authentication challenge`，随后同一算法拒绝 | IMS 401/403，认证失败 |
| 不含 `P-CSCF` 的 `Security-Server rejected; did not accept...` | 正确分类为 IPsec 算法不匹配 |
| `epdg auth verified`、正常 401 challenge、`not_ready` | IMS 401/403，认证失败 |

探针源码：`FailureSummaryProbe.java`；输出：`failure-summary-probe.log`。因此只能借鉴“简短阶段/原因说明”的结构，不能照搬这个判断顺序或以正常 SIP challenge 判失败。

## 验证边界

- 配置审查依据：解包资源、实际 smali 调用和请求构造、辅助 CFR 反编译；反编译失败的方法以 smali 为准。
- 诊断探针执行真实 APK 的 Java 字节码方法；为运行 DEX→JVM 转换代码使用 `-noverify`，不等于 Android ART 验证。
- 没有运行参考 APK 的 native 网络引擎，没有进行真实 SIM、运营商、短信中心或端到端通话验证。
- 没有复制或移植参考实现，没有修改 SIMHub UI、默认模板、身份或保存语义。
