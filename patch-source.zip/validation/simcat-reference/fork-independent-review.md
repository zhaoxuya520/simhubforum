# SIP 分叉隔离独立复核（生产补丁闭环前）

这份记录验证分叉隔离补丁的协议边界，不是手机、运营商或音频通话测试。基线使用 23.3 译出的实际原生 `o82.h`、`o82.r`、`cb4`、`ma4`、`kb4`；只有最终网络出口 `o82.C` 被收集器替代，日志 `g11.i` 是无协议逻辑的测试替身。引擎通过 Unsafe 分配以避开网络构造。入站请求测试把 `K` 预设为一个未执行的实际 `ls4` 实例，以跳过真实后台定时器；不模拟 dispatcher、SIP 解析、对话对象或响应构造逻辑。

## 已通过的局部检查

`ForkCompactReview.java` 经实际 `cb4` 构造 ACK/BYE，核实紧凑 To `t` 的分叉被 helper 消费，选定 A 的目标和 SDP 未变。helper 源码固定在 `snapshot-src/SipForkProtection.java`。这是手工调用 guard 后原生 fallback 的独立边界探针，完整 APK hook 由生产负责人另行验证。

静态复核确认临时分叉不复用 A 的非空路由列表；原 INVITE 的头列表和 body 克隆；缓存 value 不引用 key A、manager 或 engine；ACK 使用初始 INVITE CSeq；BYE 仅生成一次、失败重发同包且有整数溢出保护。

## 已复现的三个闭环缺口

1. 已选定 A，helper 已生成 B 的 ACK/BYE；把 A 设为正在结束 X。B 的 BYE 200 仍进入实际 `o82.h`，A 被置 Y 并从 Call-ID map 删除。原生 BYE response 分支只依据 Call-ID 和 A.state=X，没有匹配 remote tag。
2. 已选定 A=W，B 的主动 BYE 使用 `From: ...;tag=forked`、`To: ...;tag=local-tag`。实际 `o82.r` 回 200，并把 A 置 Y、从 map 删除。没有匹配完整 dialog ID。
3. 相同 B 的 UPDATE，空 body、`Session-Expires: 777;refresher=uas`。实际 `o82.r` 把 A 的 timer B 从 null 改为 777、C 改为 true。即使不涉及 BYE，分叉请求仍可改动 A。

对应输出为 `bye-negative.log`、`update-negative.log`。测试代码和输入校验可见 `ForkByeReview.java`、`ForkUpdateReview.java`；SHA-256 在 `review-provenance.json`。

## 最小闭环建议（交由生产负责人实现与复测）

在 `o82.r(kb4,oc2,String)` 原生 dispatcher 前验证选定出站 A 的完整 dialog ID。已记录 B 的 BYE 可用实际 `cb4.m` 和 `o82.k` 仅回 200；不应发送结束 A 的事件。未知或 cap 外 tag 的请求必须避免进入 A，可以按 RFC 481 拒绝；ACK 不能生成 SIP 响应。相同 A tag 的请求保留原路径。响应侧还应隔离 B 的 BYE response，避免结束状态 X 的 A 被删除。要覆盖紧凑 From/To/Call-ID、错误 local tag、重复请求与失败发送，且不得将新逻辑绑定到仅 64 个可保存 tag 才安全。

依据 RFC 3261 §12（Call-ID + local tag + remote tag），§12.2.2（不重建未知 dialog 时回 481），§15.1.2（BYE 必须匹配 dialog，未知回 481），§13.2.2.4（每个 INVITE 2xx ACK，不保留的分叉 BYE）。RFC 副本在 `/workspace/recovery/ims-lifecycle-review/rfc3261.txt`。

这些发现已经同步 root 和补丁作者 ui_theme；本目录未修改生产代码。补丁闭环后的结论必须以修复后实际入口回归更新，不能把当前局部通过当成整项修复完成。

## 修复后独立复验

`RawForkClosureReview.java` 使用生产负责人 `fork-development/native-fork/transport-adapted.jar` 中已插入 hook 的真实 `o82.h/r` 及 helper，直接把 SIP 字节交给原生 `jb4.c(byte[])`。输入含 compact `i/f/t` 以及混用的 `v`/`Via`。UPDATE（Session-Expires 777）回 481；已记录 B 的 BYE 回 200；选中 A 的全部字段引用/内容不变。A=X 时 B 的 BYE 200 也不再从 map 删除 A。回复保留完整 Via 顺序。输出见 `raw-closure-positive.log`。

补充边界说明：原生网络 parser `jb4.c` 自身已规范化紧凑头；此前通过 `kb4` 构造器直接添加 compact 头的测试是 helper 防御性兼容检查，不能据此宣称线上网络 parser 有 compact/mixed Via 缺陷。独立 raw 字节检查已确认真实 parser 保留 mixed Via 顺序。

Smali 入口审查：`r` 使用 `v0/v11/v3` 三个已初始化对象传参（均在 invoke 非 range 编码范围），`v2` 仅存 boolean 返回值，native fallthrough 紧随的 `iget-boolean v2, v11.a` 立即覆盖；未改既有 locals、异常范围或事件循环。`h` 同样只在方法前增加 guard。`CANCEL` 保留原 transaction 路径：实际 native r 的 CANCEL 仅在呼入 direction=T、D=null 的情况下改生命周期，helper 当前范围为出站 U、D 非空。

目前发现的三个分叉闭环 blocker 在该候选上均通过实际入口复验。仍需最终 APK 同源 DEX 检验；本验证不证明 ART/手机网络/运营商端行为。
