# SIMCAT 官方产物与公开源码调查

调查时间：2026-11-17。仅只读官网/API/本地 APK 与已下载的公开参考源码，没有执行 APK、连接 SIMCAT 服务或上传用户 APK。

## 已确认的官方对应关系

APK 中 MainActivity 的 tools.eeuicc.com / games.eeuicc.com 链接指向 eeuicc.com；该官网链接 simcat.org。simcat.org 的 Android 下载与 GitHub release 链接均指向官方发布仓库 https://github.com/ecChat/simcat.org 。

该仓库 main 固定提交 `3b50dadb1c7c9f326dc9d73f7797d9891bfd811f` 的 `releases/v0.0.0/SIMCAT-v0.0.1-android-release.apk.sha256` 为：

`edd3a9ca5f144e9b9ca278a6020c149aca159b140d2a7520e5bb1075f99eef91`

与用户提供 APK 完全相同。仓库 README 明确称 “官方发布仓库 / Official release repository”；递归树共 26 项，仅 README、发布 workflow、二进制及校验文件，无应用源码、LICENSE 或 AGENTS。GitHub repository API 的 license 字段为 null。没有找到可将 SIMCAT 应用实现视为开源代码的公开源码许可；这不妨碍只读行为对照，也不能把依赖库许可推及整个应用。

官方 docs、官方域名关联的 git.eeuicc.com 也未找到应用源码链接；后者实际为博客而非代码托管 API。GitHub 仓库查询 `SIMCAT euicc` / `org.jm01.euicc` / `SIMCAT esim` 返回 0。这是搜索范围内未找到，并非断言世界上没有源码。

## Go 二进制构建信息

`libsimcat-engine.so` 的 Go build info 显示 module `simcat (devel)`，path `simcat/cmd/simcat-android-engine`，git revision `4789fab483f070118d548b9a4bca8ea405385eae`、时间 `2026-11-14T02:35:07Z`，且 `vcs.modified=true`。没有公开远端 URL，因此不能将它与官方 release repository 的提交混淆，也不能据此恢复精确应用源码。

`libeapstep.so` 的 path 是 `simcat/cmd/eapstep`；未看到其独立 vcs revision。两者 build 信息与文件 SHA-256 保存在 `go-build-provenance.json`。

## LPAC / OpenEUICC 的可确认边界

SIMCAT 包含 `net/typeblog/lpac_jni/LpacJni` 与 `liblpac-jni.so`，命名和接口对应 OpenEUICC 的 lpac-jni。已只读核对公开参考仓库 https://github.com/estkme-group/openeuicc ，本地干净提交 `b79e03bbf42f4d69b9d9dd21cd6132bb1b9314d7`；先完整读取 AGENTS.md 与 CONTRIBUTING.md 的 LLM Policy。这里只做代码理解，没有替该项目提交/发帖。

参考实现中：

- `LpacJni.kt:24–25` 声明 enable/disable，并接受 refresh 布尔参数。
- `lpac-jni.c:195–219` JNI 函数分别将同一 context、ICCID 与 refresh 参数传给 `es10c_enable_profile` / `es10c_disable_profile`；没有跨芯片枚举、旧芯片关闭或全局排他流程。
- `LocalProfileAssistantImpl.kt:207–213` 为这两项调用持有该实例的 lock。
- lpac 子模块提交为 `50cdf15ab40942b00f8819a1c2ca19997f1a6d34`，`euicc/es10c.c:255–270` 分别构造标准 enable / disable 操作并携带 refreshFlag。它只作用于传入的单个 context，不证明跨芯片管理行为。

SIMCAT 二进制导出对应函数：

| 符号 | ELF 虚拟地址 | 大小 |
|---|---:|---:|
| Java_net_typeblog_lpac_1jni_LpacJni_es10cEnableProfile | 0x0000d5a0 | 132 |
| Java_net_typeblog_lpac_1jni_LpacJni_es10cDisableProfile | 0x0000d624 | 132 |
| es10c_enable_profile | 0x00010e24 | 28 |
| es10c_disable_profile | 0x00011018 | 28 |

但用户 APK 的 Java `LpacJni.smali` 仅保留下载、context、EID 等声明，没有 enable/disable native 声明或调用。所以“库中导出 enable/disable”不能作为 SIMCAT 实际切卡调用链证据。实际调用路径仍应以 `org.jm01.euicc.Q` / `Z` 的 APDU 管理实现为准，由主审查补齐。

OpenEUICC 主仓库 LICENSE 为 GPL v3；lpac-jni 自身 LICENSE 为 LGPL v2.1。APK locale 的 usb.licenses 只宣称 libeuicc 为 LGPL 2.1、cJSON/cjson-ext 为 MIT，不能证明该 APK 的精确 lpac 源码提交。所有参考源码快照与 SHA-256 见 `source-provenance.json`。

## 对跨芯片修复的结论

公开发布页和 lpac-jni 血缘没有提供“跨芯片切换时会自动关闭另一芯片旧 profile”的证据。不能据此启用 SIMHub 已禁用的 MultiChipSwitch，也不应依据库符号猜测应用发送的 APDU。适合参考的是明确的资源所有权、按实际通道持锁和失败恢复边界；具体是否改动仍需由 APK 调用链与 SIMHub 当前代码的可复现问题决定。
