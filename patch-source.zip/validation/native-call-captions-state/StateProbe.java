package cc.forserein.simhub.internal;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BooleanSupplier;

// Only this standalone build uses a substitute key store and translator.
class CaptionKeyStore {
    static volatile String value = "";
    static boolean has(Context context) { return !value.isEmpty(); }
    static String read(Context context) { return value; }
    static void write(Context context, String key) { value = key; }
}
class CaptionBackend {
    interface Listener { void onReady(); void onText(String text); void onError(String text); }
    static final CopyOnWriteArrayList<CaptionBackend> sessions = new CopyOnWriteArrayList<>();
    final Listener listener;
    final String language;
    final int rate;
    volatile int frames;
    volatile boolean closed;
    CaptionBackend(String key,String language,int rate,Listener listener) {
        this.listener=listener; this.language=language; this.rate=rate;
        if(key.isEmpty()) throw new AssertionError("empty service credential");
    }
    void start() { listener.onReady(); sessions.add(this); }
    void offer(short[] pcm,int offset,int count) { if (!closed) frames++; }
    void close() { closed=true; }
}
public class StateProbe {
    private static int checks;
    static void check(boolean value, String description) {
        if (!value) throw new AssertionError(description);
        checks++;
    }
    static void await(BooleanSupplier condition,String description) throws Exception {
        long deadline=System.nanoTime()+3_000_000_000L;
        while(!condition.getAsBoolean() && System.nanoTime()<deadline) Thread.sleep(5);
        check(condition.getAsBoolean(),description);
    }
    static final class Memory extends Context implements SharedPreferences,SharedPreferences.Editor {
        final ConcurrentHashMap<String,String> strings=new ConcurrentHashMap<>();
        public SharedPreferences getSharedPreferences(String name,int mode){return this;}
        public String getString(String name,String fallback){return strings.getOrDefault(name,fallback);}
        public Editor edit(){return this;}
        public Editor putString(String name,String text){strings.put(name,text);return this;}
        public Editor remove(String name){strings.remove(name);return this;}
        public boolean commit(){return true;}
    }
    public static void main(String[] args) throws Exception {
        Memory context=new Memory();
        Object first=new Object(),second=new Object();
        short[] pcm={12,23};
        check(!CallCaptions.enabled(context),"new installation is off");
        check(CallCaptions.target(context).equals("zh-Hans"),"initial target");
        CallCaptions.mediaStarted(first,context,8000);
        CallCaptions.remotePcm(first,pcm);
        CallCaptions.setEnabled(context,true);
        await(()->CallCaptions.status().contains("密钥"),"missing credential explained without sending audio");
        check(CaptionBackend.sessions.isEmpty(),"no session with missing credential");
        CallCaptions.setKey(context,"dummy-key-for-probe");
        await(()->CaptionBackend.sessions.size()==1,"can configure during a call");
        CaptionBackend a=CaptionBackend.sessions.get(0);
        check(a.rate==8000 && a.language.equals("zh-Hans"),"first configuration");
        CallCaptions.remotePcm(second,pcm);
        CallCaptions.remotePcm(first,pcm);
        check(a.frames==1,"only current remote stream");
        a.listener.onText("第一句");
        CallCaptions.Display firstDisplay = CallCaptions.display();
        a.listener.onText("第二句");
        CallCaptions.Display nextDisplay = CallCaptions.display();
        check(CallCaptions.subtitle().equals("第二句") && CallCaptions.previousSubtitle().equals("第一句"),"two display lines");
        check(firstDisplay.current.equals("第一句") && firstDisplay.previous.isEmpty(),"prior render snapshot stays immutable");
        check(nextDisplay.current.equals("第二句") && nextDisplay.previous.equals(firstDisplay.current)
                && nextDisplay.utterance == firstDisplay.utterance + 1 && nextDisplay.status.isEmpty(),"one complete render per utterance");
        a.listener.onText("  ");
        check(CallCaptions.display() == nextDisplay,"silence preserves scroll position");
        a.listener.onText("第二句");
        check(CallCaptions.display().utterance == nextDisplay.utterance + 1
                && CallCaptions.display().previous.equals("第二句"),"identical subsequent utterance can return to its first line");
        CallCaptions.setTarget(context,"de");
        await(()->CaptionBackend.sessions.size()==2,"target changes during call");
        CaptionBackend b=CaptionBackend.sessions.get(1);
        check(a.closed && b.language.equals("de"),"old translator closed");
        CallCaptions.Display languageChange = CallCaptions.display();
        a.listener.onText("late"); a.listener.onError("late error");
        check(CallCaptions.subtitle().isEmpty() && !CallCaptions.status().equals("late error"),"old translation discarded");
        check(CallCaptions.display() == languageChange && languageChange.previous.isEmpty(),"stale events do not update the visible frame");
        CallCaptions.mediaStarted(second,context,16000);
        await(()->CaptionBackend.sessions.size()==3,"new call and sample rate");
        CaptionBackend c=CaptionBackend.sessions.get(2);
        CallCaptions.mediaStopped(first);
        CallCaptions.remotePcm(first,pcm); CallCaptions.remotePcm(second,null);
        check(b.closed && !c.closed && c.rate==16000 && c.frames==1,"late hangup cannot cancel new call");
        c.listener.onText("Fehler beim Termin");
        CallCaptions.Display beforeError = CallCaptions.display();
        c.listener.onError("测试网络错误");
        c.listener.onText("late");
        CallCaptions.Display error = CallCaptions.display();
        check(c.closed && error.status.equals("测试网络错误"),"terminal error is visible");
        check(error.utterance == beforeError.utterance && error.current.equals(beforeError.current)
                && beforeError.status.isEmpty(),"error keeps last readable utterance and its scroll identity");
        CallCaptions.setEnabled(context,false);
        CallCaptions.setEnabled(context,true);
        await(()->CaptionBackend.sessions.size()==4,"retry from toggle");
        CaptionBackend d=CaptionBackend.sessions.get(3);
        d.listener.onText("visible"); CallCaptions.setEnabled(context,false);
        check(d.closed && !CallCaptions.enabled(context) && CallCaptions.subtitle().isEmpty(),"off clears transcript");
        CallCaptions.remotePcm(second,pcm); d.listener.onText("late");
        check(d.frames==0 && CallCaptions.subtitle().isEmpty(),"nothing transmitted when off");
        CallCaptions.mediaStopped(second);
        CallCaptions.setTarget(context,"ja"); CallCaptions.setEnabled(context,true);
        check(CallCaptions.target(context).equals("ja") && CaptionBackend.sessions.size()==4,"settings survive outside call");
        CallCaptions.setKey(context,"");
        try { CallCaptions.setTarget(context,"text that is not a target"); throw new AssertionError(); }
        catch(IllegalArgumentException expected){check(CallCaptions.target(context).equals("ja"),"unsupported target rejected");}
        check(!CallCaptions.hasKey(context),"credential removed");
        System.out.println("Caption session checks passed: "+checks);
    }
}
