"""Exercise the production session state with isolated Android and translator substitutes."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import subprocess
import tempfile
import zipfile

here = Path(__file__).resolve().parent
root = here.parents[1]
kit = Path(os.environ.get("SIMHUB_TOOLS", "/workspace/tools/android-recovery"))
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("report", nargs="?", type=Path)
parser.add_argument("--apk", type=Path)
parser.add_argument("--unsigned-apk", type=Path)
parser.add_argument("--carrier-report", type=Path)
args = parser.parse_args()
sources = [root / "tests/android/content/Context.java", root / "tests/android/content/SharedPreferences.java",
           here / "StateProbe.java"]
proof = {"production_state": True,"test_key_store": True,"test_translator": True}
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
classpath = []
if args.apk:
    if not args.unsigned_apk or not args.carrier_report:
        parser.error("APK verification needs the matching unsigned APK and carrier report")
    bridge = json.loads(args.carrier_report.read_text())
    jar = args.carrier_report.parent / "native-carrier-current/probe.jar"
    assert digest(jar) == bridge["apk_translated_jar_sha256"]
    assert digest(args.unsigned_apk) == bridge["apk_sha256"]
    with zipfile.ZipFile(args.unsigned_apk) as base, zipfile.ZipFile(args.apk) as signed:
        names = {n for n in base.namelist() if re.fullmatch(r"classes\d*\.dex",n)}
        assert names and names == {n for n in signed.namelist() if re.fullmatch(r"classes\d*\.dex",n)}
        assert all(base.read(n)==signed.read(n) for n in names)
    classpath = [str(jar)]
    proof.update(apk_sha256=digest(args.apk), dex_derived_core=True, translated_jar_sha256=digest(jar))
else:
    sources.append(root / "src/cc/forserein/simhub/internal/CallCaptions.java")
with tempfile.TemporaryDirectory() as output:
    subprocess.run(["java","-jar",str(kit/"ecj-3.40.0.jar"),"-8","-proc:none","-warn:none","-encoding","UTF-8",
                    "-cp",os.pathsep.join(classpath) or output,"-d",output, *map(str,sources)],check=True)
    # dex2jar does not emit JVM stack map frames. The canonical APK build checks DEX register types separately.
    vm = ["java", "-noverify"] if args.apk else ["java"]
    result = subprocess.check_output([*vm,"-cp",os.pathsep.join([output,*classpath]),
                                      "cc.forserein.simhub.internal.StateProbe"],text=True).strip()
    print(result)
if args.report:
    proof["checks"] = int(result.split()[-1])
    args.report.write_text(json.dumps(proof,indent=2)+"\n")
