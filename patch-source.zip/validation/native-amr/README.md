# Actual APK media regression probe

`python3 tests/check_native_amr_runtime.py APK DECODED --report REPORT.json` executes the real APK's `t10`, `m10`, `k7`, `q93`, `hx3`, `bl2`, AMR native parser/packetizer and frame queue. Use `--legacy` with the previously delivered APK for a negative control. DEX-to-JVM normalization is the same pinned, generic constructor/interface adapter used by the carrier probe. Shipped DEX register types are checked separately.

Explicit fixtures replace `o82` (network send), `g11` (logging), `yz` (audio hardware), Android Context/MediaCodec/MediaFormat. Pre-encoded synthetic frames are inserted into the real encoder frame queue; hardware encoding and decoding are not exercised. Receiving verifies byte-exact codec frames in the actual jitter queue. Sending verifies actual native RTP payloads against independently packed RFC 4867 vectors, including automatically corrected framing. Sequence/timestamp wrap, RTP CSRC, extensions/padding, wrong PT, telephone events, changed SSRC, repeated/changed SDP and per-call isolation are covered.

There is no physical-device, Android ART, microphone, speaker or carrier-network test. User call logs are summarized without subscriber identifiers; no recorded speech is included.

The receive hook also passes the original RTP sequence and SSRC into framing detection. Extra regression cases check that copies of one packet cannot count as three independent observations, late packets cannot change transmit format, and a new SSRC confirms its own framing across sequence wrap before the sender adopts it. Native jitter handling and RTP fields are retained.
