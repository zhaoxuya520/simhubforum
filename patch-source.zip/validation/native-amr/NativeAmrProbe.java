import java.lang.reflect.*;
import java.util.*;

/** Actual APK media constructor, RTP/AMR parser, jitter queue and packetizer. */
public final class NativeAmrProbe {
 static int checks;
 static boolean legacy;
 static void check(boolean value,String text){if(!value)throw new AssertionError(text);checks++;}
 static q93 config(boolean wide,boolean aligned){
  return new q93("198.51.100.2",10804,10805,wide?116:97,wide?xk.U:xk.V,wide?16000:8000,aligned,
   Collections.<Integer>emptyList(),20,Integer.valueOf(20),Integer.valueOf(wide?100:101),Integer.valueOf(wide?16000:8000),y84.T);
 }
 static t10 call(boolean wide,boolean aligned){return new t10(new o82(),config(wide,aligned),false,new android.content.Context(),false,false);}
 static void receive(t10 c,byte[] payload,int seq,long timestamp,long ssrc,int pt,boolean extensions)throws Exception {
  byte[] rtp=new hx3(pt,seq,timestamp,ssrc,false,payload).a();
  if(extensions){
   byte[] extended=new byte[rtp.length+16];
   System.arraycopy(rtp,0,extended,0,12);extended[0]=(byte)0xb1; // padding, extension, one CSRC
   extended[18]=0;extended[19]=1; // extension data length = one 32-bit word
   System.arraycopy(rtp,12,extended,24,rtp.length-12);extended[extended.length-1]=4;rtp=extended;
  }
  ((Runnable)m10.class.getConstructor(t10.class,byte[].class,x82.class,int.class,int.class).newInstance(c,rtp,null,10804,44886)).run();
 }
 static byte[] codecFrame(boolean wide,int type,int seed){
  byte[] speech=AmrFramingTest.speech(wide,type,seed),frame=new byte[1+speech.length];frame[0]=(byte)((type<<3)|4);
  System.arraycopy(speech,0,frame,1,speech.length);return frame;
 }
 static boolean mode(t10 c)throws Exception {
  Object f=t10.class.getField("simhubAmrFraming").get(c);
  return (Boolean)f.getClass().getMethod("isOctetAligned").invoke(f);
 }
 static void task(int kind,Object first,Object second)throws Exception {
  ((Runnable)k7.class.getConstructor(int.class,Object.class,Object.class).newInstance(kind,first,second)).run();
 }
 static void send(t10 c,boolean wide,int type,int seed)throws Exception {
  // Real d43 frame queue and k7 packetizer; hardware encoder returns no output.
  c.f=new d43(wide?n.W:n.V,1);
  ((th)c.f.g).add(codecFrame(wide,type,seed));
  task(4,c,new short[wide?320:160]);
 }
 static void stream(boolean wide,boolean declared,boolean actual,int seed)throws Exception {
  t10 c=call(wide,declared);
  try{
   int mode=wide?2:7,clock=wide?320:160;
   for(int i=0;i<10;i++)receive(c,AmrFramingTest.packet(wide,actual,new int[]{mode},seed+i),65530+i,0xffffff00L+(long)i*clock,7,wide?116:97,i==3);
   check(c.w==10&&c.z==0,"all RTP payloads accepted including CSRC/extension/padding");
   check(c.i.c.size()==10,"actual native jitter queue contains ten speech frames");
   for(int i=0;i<10;i++)check(Arrays.equals((byte[])c.i.c.get((long)i),codecFrame(wide,mode,seed+i)),"bit-exact speech to native decoder queue "+i);
   check(mode(c)==actual,"confirmed receive format used for send");
   check(c.b.g==declared,"immutable negotiated SDP is retained");
   check(c.a.g.messages.stream().filter(s->s.contains("收发已适配")).count()==(declared==actual?0:1),"one correction log only");
   send(c,wide,mode,seed);
   check(c.a.sent.size()==1,"native transmit worker emitted RTP");
   byte[] sent=c.a.sent.get(0);
   check((sent[1]&127)==(wide?116:97),"negotiated payload type retained");
   check(Arrays.equals(Arrays.copyOfRange(sent,12,sent.length),AmrFramingTest.packet(wide,actual,new int[]{mode},seed)),"actual native send payload matches independent RFC vector");
   // A repeated final answer cannot reset the correction learned during early media.
   task(5,config(wide,declared),c);check(mode(c)==actual,"repeated 200 SDP retains detection");
   task(5,config(wide,!declared),c);check(mode(c)==!declared,"changed SDP updates state");
   int before=c.z;receive(c,new byte[]{0},24,7000,7,wide?116:97,false);check(c.z==before+1,"malformed frame rejected by native failure path");
   int received=c.w;receive(c,new byte[]{0,0,0,0},25,7320,7,wide?100:101,false);check(c.w==received,"telephone events bypass AMR detector");
   received=c.w;receive(c,new byte[]{0,0},26,7640,7,33,false);check(c.w==received&&c.x==1,"wrong PT bypasses AMR detector");
   receive(c,AmrFramingTest.packet(wide,!declared,new int[]{mode},5),27,100,8,wide?116:97,false);
   check(c.i.h.equals(8L)&&c.i.c.size()==1,"SSRC change keeps native jitter reset");
  }finally{c.h.shutdownNow();}
 }
 public static void main(String[]args)throws Exception {
  legacy=args.length>0&&args[0].equals("legacy");
  if(legacy){
   t10 c=call(true,true);
   try{
    for(int i=0;i<12;i++)receive(c,AmrFramingTest.packet(true,false,new int[]{2},i+301),i,320L*i,7,116,false);
    check(c.w==12,"old APK receives RTP");check(c.z>0,"old declared-OA parser fails real BE vectors");
    boolean exact=true;for(int i=0;i<12;i++)exact&=Arrays.equals((byte[])c.i.c.get((long)i),codecFrame(true,2,i+301));
    check(!exact,"old APK fails to deliver intact speech frames");
    check(c.a.g.messages.stream().noneMatch(s->s.contains("收发已适配")),"old APK has no framing recovery");
    System.out.println("LEGACY_RECEIVE packets="+c.w+" failures="+c.z+" queued="+c.i.c.size());
   }finally{c.h.shutdownNow();}
  }else{
   for(boolean wide:new boolean[]{false,true})for(boolean declared:new boolean[]{false,true})for(boolean actual:new boolean[]{false,true})stream(wide,declared,actual,37);
   t10 a=call(true,true),b=call(true,true);
   try{
    for(int i=0;i<3;i++)receive(a,AmrFramingTest.packet(true,false,new int[]{2},i),i,320L*i,7,116,false);
    check(!mode(a)&&mode(b),"independent native call constructors have independent state");
   }finally{a.h.shutdownNow();b.h.shutdownNow();}
  }
  System.out.println("NATIVE_AMR "+(legacy?"legacy_regression_reproduced":"current_passed")+"=true checks="+checks);
 }
}
