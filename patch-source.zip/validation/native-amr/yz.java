import android.content.Context;
/** Audio hardware fixture only. No Android audio or audible playback is tested. */
public final class yz {
 public boolean d,f,x,q;public g11 e;public int g,h;
 public yz(Context context,int rate){}
 public void a(){}
 public void b(short[] pcm){h+=pcm.length;}
 public void d(){}
 public void g(){}
}
