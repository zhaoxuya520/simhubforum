import java.util.*;
/** Log sink fixture only. */
public final class g11 {
 public final List<String> messages=new ArrayList<>();
 public Object i(Object value){messages.add(String.valueOf(value));return null;}
}
