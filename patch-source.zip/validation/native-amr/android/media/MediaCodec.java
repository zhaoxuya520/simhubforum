package android.media;
import java.nio.ByteBuffer;
/** Codec hardware fixture: no actual speech encoding/decoding, pre-encoded test frames only. */
public final class MediaCodec {
 public static final class BufferInfo {public int offset,size,flags;public long presentationTimeUs;}
 public static MediaCodec createEncoderByType(String type){return new MediaCodec();}
 public static MediaCodec createDecoderByType(String type){return new MediaCodec();}
 public void configure(MediaFormat f,android.view.Surface s,MediaCrypto c,int flags){}
 public void start(){} public void stop(){} public void release(){}
 public int dequeueInputBuffer(long timeout){return -1;}
 public int dequeueOutputBuffer(BufferInfo info,long timeout){return -1;}
 public ByteBuffer getInputBuffer(int index){return null;}
 public ByteBuffer getOutputBuffer(int index){return null;}
 public void queueInputBuffer(int i,int offset,int size,long stamp,int flags){}
 public void releaseOutputBuffer(int index,boolean render){}
}
