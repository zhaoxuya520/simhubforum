package android.media;
public final class MediaFormat {
 public static MediaFormat createAudioFormat(String mime,int rate,int channels){return new MediaFormat();}
 public void setInteger(String key,int value){}
}
