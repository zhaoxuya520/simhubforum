import java.util.*;
/** IMS socket fixture only: captures RTP instead of sending over a network. */
public final class o82 {
 public final g11 g=new g11();
 public final List<byte[]> sent=new ArrayList<>();
 public void B(byte[] data,x82 address,int port,boolean rtcp){sent.add(data.clone());}
}
