#!/usr/bin/env python3
"""Replay a synthetic REGISTER 200 against the APK's registration coroutine and RCS binding."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

here = Path(__file__).resolve().parent
root = here.parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("apk", type=Path)
parser.add_argument("--unsigned-apk", type=Path)
parser.add_argument("--carrier-report", type=Path, required=True)
parser.add_argument("--jar", type=Path)
parser.add_argument("--report", type=Path, required=True)
args = parser.parse_args()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


carrier = json.loads(args.carrier_report.read_text())
jar = args.jar or args.carrier_report.parent / "native-carrier-current/probe.jar"
unsigned = args.unsigned_apk or args.apk
assert carrier["apk_sha256"] == digest(unsigned)
assert carrier["apk_translated_jar_sha256"] == digest(jar)
dex = {}
with zipfile.ZipFile(args.apk) as target, zipfile.ZipFile(unsigned) as built:
    names = {name for name in target.namelist() if re.fullmatch(r"classes\d*\.dex", name)}
    assert names and names == {name for name in built.namelist() if re.fullmatch(r"classes\d*\.dex", name)}
    for name in sorted(names):
        data = target.read(name)
        assert data == built.read(name), name
        dex[name] = hashlib.sha256(data).hexdigest()

kit = Path(os.environ.get("SIMHUB_TOOLS", "/workspace/tools/android-recovery"))
android = kit / "sdk/android-35/android.jar"
sources = [here / "NativeRcsRegistrationProbe.java", *sorted((here.parent / "native-registration").glob("*.java")),
           root / "tests/configmodel/Flow.java", root / "tests/configmodel/zl5.java"]
args.report.parent.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(dir=args.report.parent, prefix="native-rcs-binding-") as tmp:
    cp = os.pathsep.join(map(str, (jar, android)))
    compile = subprocess.run(["java", "-jar", str(kit / "ecj-3.40.0.jar"), "-8", "-proc:none",
                              "-warn:none", "-encoding", "UTF-8", "-cp", cp, "-d", tmp, *map(str, sources)],
                             capture_output=True, text=True)
    assert compile.returncode == 0, compile.stdout + compile.stderr
    execute = subprocess.run(["java", "-noverify", "-cp", tmp + os.pathsep + cp, "NativeRcsRegistrationProbe"],
                             capture_output=True, text=True)
    args.report.with_suffix(".log").write_text(compile.stdout + compile.stderr + execute.stdout + execute.stderr)
    if execute.returncode:
        raise SystemExit(execute.stdout + execute.stderr)

m = re.search(r"NATIVE_RCS_REGISTRATION checks=(\d+)", execute.stdout)
assert m, execute.stdout
report = {
    "apk_sha256": digest(args.apk), "unsigned_apk_sha256": digest(unsigned), "dex_sha256": dex,
    "apk_translated_jar_sha256": digest(jar), "carrier_report_sha256": digest(args.carrier_report),
    "mode": "fixed", "checks": int(m[1]),
    "real_register_response_coroutine": True, "actual_rcs_binding": True,
    "real_card_tested": False, "android_art_tested": False, "carrier_network_tested": False,
    "actual_tapi_service_contacted": False, "rcs_messages_sent": 0,
    "fixture_boundaries": ["Synthetic REGISTER 200 on a resumed native j82 continuation",
                           "App selection and active engine inputs; native card, engine and registration types",
                           "Native refresh scheduler, delay and Android log doubles"],
    "dex_to_jvm_constructor_adapters": True, "jvm_verification_disabled_for_translated_dex": True,
    "fixture_sources": {str(p.relative_to(root)): digest(p) for p in sources}
}
args.report.write_text(json.dumps(report, indent=2) + "\n")
print(execute.stdout.strip())
