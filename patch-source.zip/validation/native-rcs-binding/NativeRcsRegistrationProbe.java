import java.lang.reflect.*;
import java.util.*;
import cc.forserein.simhub.internal.RcsChatBinding;

public final class NativeRcsRegistrationProbe {
    static final String LINE="+447700900001", URI="sip:"+LINE+"@ims.example.invalid;user=phone";
    static int checks;
    static void check(boolean b,String detail){ if(!b)throw new AssertionError(detail);checks++; }

    static Object registered(o82 engine,int expires,String...associated)throws Exception{
        kb4 response=new kb4(false,"","",200,"OK",new ArrayList(),new byte[0]);
        response.a("Expires",Integer.toString(expires));
        for(String value:associated)response.a("P-Associated-URI","<"+value+">");
        j82 c=new j82(engine,null);
        NativeRegistrationProbe.set(c,"U",qd1.T);
        c.m0=3;c.e0=new byte[0];c.f0=new byte[0];c.g0=new byte[0];
        return c.q(response);
    }

    static Object proof(o82 engine)throws Exception{
        Field map=RcsChatBinding.class.getDeclaredField("registrations");map.setAccessible(true);
        return ((Map<?,?>)map.get(null)).get(engine);
    }
    static void verify(o82 engine,Object previous)throws Exception{
        Object proof=proof(engine);
        check(proof!=null,"proof exists");
        Field lines=proof.getClass().getDeclaredField("lines");lines.setAccessible(true);
        check(((Set<?>)lines.get(proof)).contains(LINE),"raw P-Associated-URI parsed as public line");
        Method active=proof.getClass().getDeclaredMethod("active",Object.class);active.setAccessible(true);
        check(Boolean.TRUE.equals(active.invoke(proof,engine.s)),"proof bound to native registration by reference");
        if(previous!=null)check(Boolean.FALSE.equals(active.invoke(proof,previous)),"old registration evidence retired");
    }
    public static class State {public Object e; State(Object card){e=card;}}
    public static void main(String[]args)throws Exception{
        o82 engine=NativeRegistrationProbe.session();
        NativeRegistrationProbe.set(engine.b,"A",URI);
        State state=new State(engine.c);
        zl5.n=engine;zl5.b.value=state;
        Object absent=registered(engine,30);
        check(engine.s==absent&&engine.s.a.equals(Collections.singletonList(URI)),"native missing-header fallback reaches configured IMPU");
        check(proof(engine)==null,"missing header not proof");
        try {RcsChatBinding.capture(state,"+441632960123");throw new AssertionError("fallback-only");}
        catch(IllegalStateException expected) {check(true,"manual IMPU cannot open RCS conversation");}
        Object actual=registered(engine,30,URI);
        check(engine.s.a.equals(((x72)absent).a),"native identities identical for real header and local fallback");
        verify(engine,absent);
        RcsChatBinding binding=RcsChatBinding.capture(state,"+441632960123");
        binding.validateProvider(LINE);
        check(true,"actual captured card and REGISTER proof accept same TAPI MSISDN");
        try{binding.validateProvider("+447700900002");throw new AssertionError("wrong provider");}
        catch(IllegalStateException expected){check(true,"another provider MSISDN rejected");}
        check(binding.cardKey.equals(RcsChatBinding.lineKey(state)),"per-line UI setting and actual bound key agree");
        state.e = new ek5("515660000000002","8963660000000000002",2,null,null,null,null,null);
        try {binding.validateProvider(LINE);throw new AssertionError("changed active card");}
        catch(IllegalStateException expected) {check(true,"late callback after card switch rejected");}
        state.e=engine.c;
        zl5.n=NativeRegistrationProbe.session();
        try {binding.validateProvider(LINE);throw new AssertionError("changed native engine");}
        catch(IllegalStateException expected) {check(true,"replaced native engine invalidates old view");}
        zl5.n=engine;
        binding.validateCurrent();
        registered(engine,30,"tel:"+LINE,URI);verify(engine,actual);
        registered(engine,30);
        check(proof(engine)==null,"subsequent REGISTER with missing header revokes earlier genuine evidence");
        try {binding.validateProvider(LINE);throw new AssertionError("registration lost");}
        catch(IllegalStateException expected){check(true,"late operation after missing new header rejected");}
        registered(engine,30,"sip:234330000000001@ims.example.invalid");
        check(proof(engine)==null,"private textual SIP identity is not a phone number");
        registered(engine,30,URI);verify(engine,null);
        try{registered(engine,0,URI);throw new AssertionError("0 expiry");}catch(IllegalStateException expected){check(engine.s==null&&proof(engine)==null,"expired state and proof are cleared");}
        System.out.println("NATIVE_RCS_REGISTRATION checks="+checks+" actual_j82_register_200=true live_network=false");
    }
}
