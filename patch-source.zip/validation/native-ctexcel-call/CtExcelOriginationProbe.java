import java.util.*;
import java.nio.file.Paths;

/** Drive the real registered IMS call setup, then inspect the serialized initial request. */
public final class CtExcelOriginationProbe {
    static final String CT_REALM = "ims.mnc033.mcc234.3gppnetwork.org";
    static final String TEL = "tel:+447700900121";
    static final String SIP = "sip:+447700900121@registered.example.invalid;user=phone";
    static final String NON_NUMBER = "sip:alias@registered.example.invalid";
    static int checks;

    static void check(boolean value, String text) {
        if (!value) throw new AssertionError(text);
        checks++;
    }
    static Object get(Object o, String k) throws Exception {return PreconditionProbe.get(o,k);}
    static void set(Object o, String k, Object v) throws Exception {PreconditionProbe.set(o,k,v);}
    static Object call(Object o, String m, Class<?>[] p, Object... args) throws Exception {
        return PreconditionProbe.call(o,m,p,args);
    }
    static String first(Object sip, String k) throws Exception {return PreconditionProbe.first(sip,k);}
    static Object builtIn(Object card) throws Exception {
        return Class.forName("zl3").getMethod("r",Class.forName("ek5")).invoke(null,card);
    }

    static void verify(String name, String plmn, List<String> identities, String dial,
            String destination, String expectedOrigin, boolean early, boolean tcp) throws Exception {
        verify(name,plmn,identities,dial,destination,expectedOrigin,early,tcp,true,true);
    }

    static void verify(String name, String plmn, List<String> identities, String dial,
            String destination, String expectedOrigin, boolean early, boolean tcp,
            boolean ipsecEnabled, boolean hasSecurityAssociation) throws Exception {
        verify(name, plmn, identities, dial, destination, expectedOrigin, early, tcp,
                ipsecEnabled, hasSecurityAssociation, null, null);
    }

    static void verify(String name, String plmn, List<String> identities, String dial,
            String destination, String expectedOrigin, boolean early, boolean tcp,
            boolean ipsecEnabled, boolean hasSecurityAssociation, String selected, String overrideId) throws Exception {
        verify(name,plmn,identities,dial,destination,expectedOrigin,early,tcp,ipsecEnabled,hasSecurityAssociation,
                selected,overrideId,Collections.emptyMap());
    }

    static void verify(String name, String plmn, List<String> identities, String dial,
            String destination, String expectedOrigin, boolean early, boolean tcp,
            boolean ipsecEnabled, boolean hasSecurityAssociation, String selected, String overrideId,
            Map<String,String> edits) throws Exception {
        // Reuse the live-state fixture; discard its probe call before dispatching this test call.
        PreconditionProbe.Call base = new PreconditionProbe.Call(tcp);
        SipForkProbe.Session session=base.nativeSession;
        Object e=session.e, m=session.m;
        ((Map<?,?>)get(m,"e")).clear();
        PreconditionProbe.wires.clear();

        String imsi = (plmn + "0000000001").substring(0,15);
        Object card=Class.forName("ek5").getConstructors()[0].newInstance(imsi,
                "8999900000000000001",plmn.length()-3,null,null,null,null,null);
        set(e,"c",card);
        Class<?> presets = Class.forName("cc.forserein.simhub.internal.CarrierPresets");
        Object config = presets.getMethod("defaults",Object.class,Map.class).invoke(null,card,null);
        if (selected != null) {
            Object entry = presets.getMethod("find",String.class).invoke(null,plmn+"|"+selected);
            config = presets.getMethod("apply",entry.getClass(),Object.class).invoke(null,entry,card);
            check(selected.equals(get(config,"b")),name+" uses the selected template");
        }
        if (overrideId != null) set(config,"b",overrideId);
        if (!edits.isEmpty()) {
            config = Class.forName("cc.forserein.simhub.internal.WifiConfigModel").getMethod("merge",Object.class,Map.class)
                    .invoke(null,config,edits);
            check(((String)get(config,"b")).startsWith("local:"),name+" custom configuration from editor merge");
        }
        set(e,"b",config);
        if (!ipsecEnabled) set(config,"t",false);
        if (!hasSecurityAssociation) set(e,"q",null);
        boolean registered = identities != null;
        if (!registered) identities = Collections.emptyList();
        List<String> originalOrder=new ArrayList<>(identities);
        set(get(e,"s"),"a",Collections.unmodifiableList(identities));
        call(e,"s",new Class<?>[0]);
        if(expectedOrigin==null)expectedOrigin=(String)call(e,"n",new Class<?>[0]);
        Object managerOrigin=get(get(m,"a"),"e");
        if (destination == null) {
            check(dial.startsWith("+"),name+" native global target control");
            destination = (Boolean)get(get(m,"a"),"k") ? "sip:"+dial+"@"+get(config,"g")+";user=phone" : "tel:"+dial;
        } else destination = destination.replace("{realm}",(String)get(config,"g"));

        if (!registered) set(e,"s",null);

        Object task=Class.forName("f82").getConstructor(Class.forName("o82"),String.class,
                Class.forName("ct0"),int.class).newInstance(e,dial,null,4);
        Object id=call(task,"q",new Class<?>[]{Object.class},Class.forName("sc5").getField("a").get(null));
        if (!registered) {
            check(id == null && ((Map<?,?>)get(m,"e")).isEmpty() && PreconditionProbe.wires.isEmpty(),
                    name+" call attempted without a registered session");
            return;
        }
        Object d=((Map<?,?>)get(m,"e")).get(id);
        check(d!=null && PreconditionProbe.wires.size()==1,name+" dispatch exactly one call");
        String wire=PreconditionProbe.wires.get(0);
        Object invite=PreconditionProbe.parse(wire);
        check("INVITE".equals(get(invite,"b")),name+" native request");
        check(destination.equals(get(invite,"c")),name+" wire destination="+get(invite,"c"));
        check(("<"+destination+">").equals(first(invite,"To")),name+" To="+first(invite,"To"));
        check(destination.equals(get(d,"f")) && destination.equals(get(d,"g")),name+" dialog original/target");
        check(expectedOrigin.equals(get(d,"e")),name+" dialog caller");
        check(first(invite,"From").startsWith("<"+expectedOrigin+">;tag="),name+" From="+first(invite,"From"));
        check(("<"+expectedOrigin+">").equals(first(invite,"P-Preferred-Identity")),name+" PPI="+first(invite,"P-Preferred-Identity"));
        List<?> earlyHeaders=SipForkProbe.headers(invite,"P-Early-Media");
        check(early?earlyHeaders.equals(Arrays.asList("supported")):earlyHeaders.isEmpty(),name+" early media="+earlyHeaders);
        check(managerOrigin.equals(get(get(m,"a"),"e")),name+" no manager origin mutation by INVITE");
        check(identities.equals(originalOrder),name+" registered identity list remains unchanged");
        check(!wire.toLowerCase(Locale.ROOT).contains("srvcc"),name+" no new SRVCC capabilities");
        check(PreconditionProbe.option(invite,"Supported","precondition"),name+" preconditions preserved");
        check(PreconditionProbe.body(invite).contains("a=rtpmap:116 AMR-WB"),name+" native codec offer preserved");
        Object r=PreconditionProbe.response(wire,183,"simulated","", "Require: 100rel\r\nRSeq: 1\r\n");
        check(session.accept(r),name+" actual 183 dispatcher");
        Object prack=PreconditionProbe.parse(PreconditionProbe.last("PRACK"));
        check(SipForkProbe.headers(prack,"P-Early-Media").isEmpty(),name+" no early-media header on PRACK");
        check(identities.equals(get(get(e,"s"),"a")),name+" no extraneous identity");
        System.out.println(name+" template="+get(config,"c")+" origin="+expectedOrigin+" target="+destination
                +" early="+early+" via="+first(invite,"Via").split(" ")[0]);
    }

    static void crossCarrier(boolean aligned) throws Exception {
        List<String> identities = Arrays.asList(TEL,NON_NUMBER,SIP);
        String global = "+33199000123", local = "0401234567";
        verify("O2-UK-identity","23410",identities,global,null,aligned?SIP:TEL,false,true);
        verify("O2-UK-malformed-SIP","23410",Arrays.asList(TEL,"sip:+44x700@example.invalid"),
                global,null,TEL,false,false);
        verify("UK-23487-existing-selector","23487",identities,global,null,SIP,false,true);
        verify("2degrees-local","53024",identities,local,
                aligned?"tel:"+local+";phone-context={realm}":"sip:"+local+"@{realm}",TEL,false,false);
        verify("2degrees-global","53024",identities,global,"tel:"+global,TEL,false,true);
        verify("BASE-template-default","20620",identities,global,"tel:"+global,TEL,false,false);
        verify("AT&T","310410",identities,global,null,TEL,aligned,true,true,true,"apple_att_us",null);
        String attRealm = aligned ? "one.att.net" : "ims.mnc410.mcc310.3gppnetwork.org";
        verify("AT&T-local-target","310410",identities,"5550123","sip:5550123@"+attRealm,TEL,
                aligned,true,true,true,"apple_att_us",null);
        verify("AT&T-MVNO","310280",identities,global,null,TEL,aligned,true,true,true,"apple_att_mvno_us",null);
        verify("AT&T-AIO","310150",identities,global,null,TEL,aligned,true,false,false,"apple_att_aio_us",null);
        verify("FirstNet","313100",identities,global,null,TEL,aligned,true,true,true,"apple_att_firstnet_us",null);
        verify("FirstNet-local-target","313100",identities,"5550123","sip:5550123@ims.mnc100.mcc313.3gppnetwork.org",
                TEL,aligned,true,true,true,"apple_att_firstnet_us",null);
        verify("BT-business","23430",identities,global,null,TEL,aligned,true,true,true,"apple_bt_business_uk",null);
        verify("BT-consumer","23430",identities,global,null,TEL,aligned,true,true,true,"apple_bt_consumer_uk",null);
        Map<String,String> smsc = Collections.singletonMap("smsc","+12025550123");
        verify("edited-AT&T-SMSC","310410",identities,global,null,TEL,aligned,true,true,true,"apple_att_us",null,smsc);
        verify("edited-BT-domain","23430",identities,"5550123","sip:5550123@custom.example.invalid",TEL,
                aligned,true,true,true,"apple_bt_business_uk",null,Collections.singletonMap("domain","custom.example.invalid"));
        verify("edited-unknown-AT&T-MVNO","310410",identities,global,null,TEL,false,true,true,true,
                "apple_att_us","different_mvno",smsc);
        String[][] additionalTemplates = {
                {"23430", "apple_tmobile_uk"}, {"23430", "apple_bt_onephone_uk"},
                {"310030", "apple_att_nr_us"}, {"310150", "apple_att_aio_nr_us"},
                {"310170", "apple_att_cc_us"}, {"310280", "apple_att_redpocket_us"},
                {"310410", "apple_att_dish_mvno_us"}, {"310560", "apple_att_tfw_us"},
                {"310950", "apple_att_puretalk_us"}, {"311180", "apple_att_us"},
                {"312670", "apple_att_firstnet_us"}
        };
        for (String[] pair : additionalTemplates) {
            verify("Early-media-"+pair[0]+"-"+pair[1],pair[0],identities,global,null,TEL,
                    aligned,true,true,true,pair[1],null);
        }
        verify("AT&T-unknown-MVNO","310410",identities,global,null,TEL,false,true,true,true,"apple_att_us","different_mvno");
        verify("FirstNet-with-AT&T-template","313100",identities,global,null,TEL,false,true,true,true,
                "apple_att_firstnet_us","apple_att_us");
        verify("BASE-with-BT-template","20620",identities,global,null,TEL,false,true,true,true,
                "apple_base_be","apple_bt_consumer_uk");
        verify("BT-without-registration","23430",null,global,null,TEL,false,true,true,true,
                "apple_bt_consumer_uk",null);
    }

    /** Verify the plain IPv6/UDP negative control and forward ESP to the existing validator. */
    public static void tunnel(byte[] packet) {
        if (packet.length>48 && (packet[0]>>>4&15)==6 && (packet[6]&255)==17) {
            check(PreconditionProbe.u16(packet,4)==packet.length-40,"IPv6 header payload length");
            check(PreconditionProbe.u16(packet,44)==packet.length-40,"plain UDP length");
            PreconditionProbe.wires.add(new String(packet,48,packet.length-48,java.nio.charset.StandardCharsets.UTF_8));
        } else PreconditionProbe.tunnel(packet);
    }

    public static void main(String[] args) throws Exception {
    SipForkProbe.msg = Class.forName("kb4"); SipForkProbe.dialog = Class.forName("ma4");
    SipForkProbe.manager = Class.forName("cb4"); SipForkProbe.direction = Class.forName("ga4");
    SipForkProbe.state = Class.forName("la4");
    SipForkProbe.helper = Class.forName("cc.forserein.simhub.internal.SipForkProtection");
        boolean old=args[0].equals("previous-24-4");
        android.content.res.AssetManager.root=Paths.get(args[1]);
        Class.forName("fj5").getField("d").set(null,new android.content.Context());
        List<String> both=Arrays.asList(TEL,NON_NUMBER,SIP);
        String local="01632960123", global="tel:+441632960123";
        String national=old?"sip:"+local+"@"+CT_REALM:"tel:"+local+";phone-context="+CT_REALM;
        verify("CTExcel-national","23433",both,local,national,old?TEL:SIP,!old,false);
        verify("CTExcel-global-plus","23433",both,"+441632960123",global,old?TEL:SIP,!old,true);
        verify("CTExcel-global-00","23433",both,"00441632960123",global,old?TEL:SIP,!old,false);
        verify("CTExcel-tel-only","23433",Arrays.asList(NON_NUMBER,TEL),local,national,TEL,!old,true);
        verify("CTExcel-sip-only","23433",Arrays.asList(SIP),local,national,SIP,!old,false);
        verify("CTExcel-alias-only","23433",Arrays.asList(NON_NUMBER),local,national,NON_NUMBER,!old,true);
        verify("CTExcel-no-registered-URI","23433",Collections.emptyList(),local,national,null,!old,false);
        verify("Vodafone-NL-national","20404",both,local,"sip:"+local+"@ims.mnc004.mcc204.3gppnetwork.org",TEL,false,true);
        verify("Vodafone-NL-global","20404",both,"00441632960123",global,TEL,false,false);
        verify("CTExcel-malformed-before-SIP","23433",Arrays.asList(TEL,"sip:+44x700@registered.example.invalid","sip:+447700900122@",SIP),local,national,old?TEL:SIP,!old,true);
        verify("CTExcel-malformed-with-TEL","23433",Arrays.asList("sip:+@registered.example.invalid",TEL,"sip:+44x700@registered.example.invalid"),local,national,TEL,!old,false);
        verify("CTExcel-no-SA","23433",both,local,national,old?TEL:SIP,false,true,true,false);
        verify("CTExcel-plain","23433",both,local,national,old?TEL:SIP,false,true,false,false);
        verify("Vodafone-UK-national","23415",both,local,"sip:"+local+"@ims.mnc015.mcc234.3gppnetwork.org",TEL,false,true);
        if (!old) crossCarrier(args[0].equals("fixed"));
        System.out.println("NATIVE_CTEXCEL_ORIGINATION mode="+args[0]+" checks="+checks+" protected="+PreconditionProbe.protectedPackets);
    }
}
