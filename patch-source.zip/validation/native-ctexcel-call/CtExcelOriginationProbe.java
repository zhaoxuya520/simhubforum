import java.util.*;
import java.nio.file.Paths;

/** Drive the real registered IMS call setup, then inspect the serialized initial request. */
public final class CtExcelOriginationProbe {
    static final String CT_REALM = "ims.mnc033.mcc234.3gppnetwork.org";
    static final String TEL = "tel:+447700900121";
    static final String SIP = "sip:+447700900121@registered.example.invalid;user=phone";
    static final String NON_NUMBER = "sip:alias@registered.example.invalid";
    static int checks;

    static void check(boolean value, String text) {
        if (!value) throw new AssertionError(text);
        checks++;
    }
    static Object get(Object o, String k) throws Exception {return PreconditionProbe.get(o,k);}
    static void set(Object o, String k, Object v) throws Exception {PreconditionProbe.set(o,k,v);}
    static Object call(Object o, String m, Class<?>[] p, Object... args) throws Exception {
        return PreconditionProbe.call(o,m,p,args);
    }
    static String first(Object sip, String k) throws Exception {return PreconditionProbe.first(sip,k);}
    static Object builtIn(Object card) throws Exception {
        return Class.forName("zl3").getMethod("r",Class.forName("ek5")).invoke(null,card);
    }

    static void verify(String name, String plmn, List<String> identities, String dial,
            String destination, String expectedOrigin, boolean early, boolean tcp) throws Exception {
        verify(name,plmn,identities,dial,destination,expectedOrigin,early,tcp,true,true);
    }

    static void verify(String name, String plmn, List<String> identities, String dial,
            String destination, String expectedOrigin, boolean early, boolean tcp,
            boolean ipsecEnabled, boolean hasSecurityAssociation) throws Exception {
        // Reuse the live-state fixture; discard its probe call before dispatching this test call.
        PreconditionProbe.Call base = new PreconditionProbe.Call(tcp);
        SipForkProbe.Session session=base.nativeSession;
        Object e=session.e, m=session.m;
        ((Map<?,?>)get(m,"e")).clear();
        PreconditionProbe.wires.clear();

        String imsi = plmn + "0000000001";
        Object card=Class.forName("ek5").getConstructors()[0].newInstance(imsi,
                "8944000000000000001",2,null,null,null,null,null);
        set(e,"c",card);
        Object config=builtIn(card);
        set(e,"b",config);
        if (!ipsecEnabled) set(config,"t",false);
        if (!hasSecurityAssociation) set(e,"q",null);
        List<String> originalOrder=new ArrayList<>(identities);
        set(get(e,"s"),"a",Collections.unmodifiableList(identities));
        call(e,"s",new Class<?>[0]);
        if(expectedOrigin==null)expectedOrigin=(String)call(e,"n",new Class<?>[0]);
        Object managerOrigin=get(get(m,"a"),"e");

        Object task=Class.forName("f82").getConstructor(Class.forName("o82"),String.class,
                Class.forName("ct0"),int.class).newInstance(e,dial,null,4);
        Object id=call(task,"q",new Class<?>[]{Object.class},Class.forName("sc5").getField("a").get(null));
        Object d=((Map<?,?>)get(m,"e")).get(id);
        check(d!=null && PreconditionProbe.wires.size()==1,name+" dispatch exactly one call");
        String wire=PreconditionProbe.wires.get(0);
        Object invite=PreconditionProbe.parse(wire);
        check("INVITE".equals(get(invite,"b")),name+" native request");
        check(destination.equals(get(invite,"c")),name+" wire destination="+get(invite,"c"));
        check(("<"+destination+">").equals(first(invite,"To")),name+" To="+first(invite,"To"));
        check(destination.equals(get(d,"f")) && destination.equals(get(d,"g")),name+" dialog original/target");
        check(expectedOrigin.equals(get(d,"e")),name+" dialog caller");
        check(first(invite,"From").startsWith("<"+expectedOrigin+">;tag="),name+" From="+first(invite,"From"));
        check(("<"+expectedOrigin+">").equals(first(invite,"P-Preferred-Identity")),name+" PPI="+first(invite,"P-Preferred-Identity"));
        List<?> earlyHeaders=SipForkProbe.headers(invite,"P-Early-Media");
        check(early?earlyHeaders.equals(Arrays.asList("supported")):earlyHeaders.isEmpty(),name+" early media="+earlyHeaders);
        check(managerOrigin.equals(get(get(m,"a"),"e")),name+" no manager origin mutation by INVITE");
        check(identities.equals(originalOrder),name+" registered identity list remains unchanged");
        check(!wire.toLowerCase(Locale.ROOT).contains("srvcc"),name+" no new SRVCC capabilities");
        check(PreconditionProbe.option(invite,"Supported","precondition"),name+" preconditions preserved");
        check(PreconditionProbe.body(invite).contains("a=rtpmap:116 AMR-WB"),name+" native codec offer preserved");
        Object r=PreconditionProbe.response(wire,183,"simulated","", "Require: 100rel\r\nRSeq: 1\r\n");
        check(session.accept(r),name+" actual 183 dispatcher");
        Object prack=PreconditionProbe.parse(PreconditionProbe.last("PRACK"));
        check(SipForkProbe.headers(prack,"P-Early-Media").isEmpty(),name+" no early-media header on PRACK");
        check(identities.equals(get(get(e,"s"),"a")),name+" no extraneous identity");
        System.out.println(name+" template="+get(config,"c")+" origin="+expectedOrigin+" target="+destination
                +" early="+early+" via="+first(invite,"Via").split(" ")[0]);
    }

    /** Verify the plain IPv6/UDP negative control and forward ESP to the existing validator. */
    public static void tunnel(byte[] packet) {
        if (packet.length>48 && (packet[0]>>>4&15)==6 && (packet[6]&255)==17) {
            check(PreconditionProbe.u16(packet,4)==packet.length-40,"IPv6 header payload length");
            check(PreconditionProbe.u16(packet,44)==packet.length-40,"plain UDP length");
            PreconditionProbe.wires.add(new String(packet,48,packet.length-48,java.nio.charset.StandardCharsets.UTF_8));
        } else PreconditionProbe.tunnel(packet);
    }

    public static void main(String[] args) throws Exception {
    SipForkProbe.msg = Class.forName("kb4"); SipForkProbe.dialog = Class.forName("ma4");
    SipForkProbe.manager = Class.forName("cb4"); SipForkProbe.direction = Class.forName("ga4");
    SipForkProbe.state = Class.forName("la4");
    SipForkProbe.helper = Class.forName("cc.forserein.simhub.internal.SipForkProtection");
        boolean old=args[0].equals("previous-24-4");
        android.content.res.AssetManager.root=Paths.get(args[1]);
        Class.forName("fj5").getField("d").set(null,new android.content.Context());
        List<String> both=Arrays.asList(TEL,NON_NUMBER,SIP);
        String local="01632960123", global="tel:+441632960123";
        String national=old?"sip:"+local+"@"+CT_REALM:"tel:"+local+";phone-context="+CT_REALM;
        verify("CTExcel-national","23433",both,local,national,old?TEL:SIP,!old,false);
        verify("CTExcel-global-plus","23433",both,"+441632960123",global,old?TEL:SIP,!old,true);
        verify("CTExcel-global-00","23433",both,"00441632960123",global,old?TEL:SIP,!old,false);
        verify("CTExcel-tel-only","23433",Arrays.asList(NON_NUMBER,TEL),local,national,TEL,!old,true);
        verify("CTExcel-sip-only","23433",Arrays.asList(SIP),local,national,SIP,!old,false);
        verify("CTExcel-alias-only","23433",Arrays.asList(NON_NUMBER),local,national,NON_NUMBER,!old,true);
        verify("CTExcel-no-registered-URI","23433",Collections.emptyList(),local,national,null,!old,false);
        verify("Vodafone-NL-national","20404",both,local,"sip:"+local+"@ims.mnc004.mcc204.3gppnetwork.org",TEL,false,true);
        verify("Vodafone-NL-global","20404",both,"00441632960123",global,TEL,false,false);
        verify("CTExcel-malformed-before-SIP","23433",Arrays.asList(TEL,"sip:+44x700@registered.example.invalid","sip:+447700900122@",SIP),local,national,old?TEL:SIP,!old,true);
        verify("CTExcel-malformed-with-TEL","23433",Arrays.asList("sip:+@registered.example.invalid",TEL,"sip:+44x700@registered.example.invalid"),local,national,TEL,!old,false);
        verify("CTExcel-no-SA","23433",both,local,national,old?TEL:SIP,false,true,true,false);
        verify("CTExcel-plain","23433",both,local,national,old?TEL:SIP,false,true,false,false);
        verify("Vodafone-UK-national","23415",both,local,"sip:"+local+"@ims.mnc015.mcc234.3gppnetwork.org",TEL,false,true);
        System.out.println("NATIVE_CTEXCEL_ORIGINATION mode="+args[0]+" checks="+checks+" protected="+PreconditionProbe.protectedPackets);
    }
}
