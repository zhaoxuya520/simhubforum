# IMS 外呼与 BASE 对话路由回归

以下命令在 android/phone-slot-patch 目录运行。构建流程会先从 APK 生成 native-carrier-runtime.json 与对应的 probe.jar。验证签名包时，脚本会比对签名前后每个 DEX 的实际字节。

```sh
python validation/native-ctexcel-call/check_runtime.py /path/to/signed.apk \
  --unsigned-apk build-config3/SIMHub-23.1-config3-unsigned.apk \
  --carrier-report build-config3/native-carrier-runtime.json \
  --report build-config3/native-ctexcel-call-runtime.json \
  --route-report build-config3/signed-base-dialog-routes.json
```

使用 24.9 的签名 APK、该版的 unsigned APK 与 carrier report，并加上 `--previous-24-9`，即可复现旧版运营商策略和路由行为。若转译产物另存，使用 `--jar` 指定报告记录的文件。

外呼用例从内置配置或运营商选择入口创建会话，并核对原生 INVITE 的主叫身份、目的地址和早期媒体头。BASE 用例向真实 SIP 解析器输入 183 和 200，然后检查发出的 PRACK、UPDATE 和 ACK 如何排列 Route。用例包含独立行、合并行、大小写混用、多跳、带逗号的显示名和带转义双引号的显示名。分别覆盖 TCP 发送边界与 IPv6 Gm ESP/UDP 序列化。注册状态、密钥与对端响应均为测试数据，无需向运营商拨号。
