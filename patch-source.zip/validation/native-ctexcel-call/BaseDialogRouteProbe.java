import java.nio.file.Paths;
import java.util.*;

/** Exercise incoming Record-Route syntax and the resulting outgoing routes using real SIP engine code. */
public final class BaseDialogRouteProbe {
    static final String FAR="<sip:far.example.invalid;lr>";
    static final String NEAR="<sip:near.example.invalid;lr>";
    static final String MIDDLE="<sip:mid.example.invalid;lr>";
    static final String QUOTED="\"Near, Edge\" <sip:near.example.invalid;lr>";
    static final String ESCAPED="\"Near\\\"A, Edge\" <sip:near.example.invalid;lr>";
    static int tests;

    static void check(boolean ok, String label) {
        if (!ok) throw new AssertionError(label);
        tests++;
    }

    static String routes(String wire) {
        List<String> values=new ArrayList<>();
        for (String line:wire.split("\r\n")) {
            int colon=line.indexOf(':');
            if (colon>0 && line.substring(0,colon).equalsIgnoreCase("Route"))
                values.add(line.substring(colon+1).trim());
            if(line.isEmpty()) break;
        }
        return String.join(", ", values);
    }
    static String checkCall(boolean tcp, String recordRoutes, String wanted, String previous, boolean fixed) throws Exception {
        PreconditionProbe.Call fixture=new PreconditionProbe.Call(tcp);
        Object engine=fixture.nativeSession.e, manager=fixture.nativeSession.m;
        Map<?,?> dialogs=(Map<?,?>)PreconditionProbe.get(manager,"e");
        dialogs.clear();
        PreconditionProbe.wires.clear();
        Object card=Class.forName("ek5").getConstructors()[0].newInstance("206200000000001","8999900000000001002",2,null,null,null,null,null);
        Object config=Class.forName("cc.forserein.simhub.internal.CarrierPresets")
                .getMethod("defaults",Object.class,Map.class).invoke(null,card,null);
        check("apple_base_be".equals(PreconditionProbe.get(config,"b")),"BASE default selected");
        PreconditionProbe.set(engine,"c",card);
        PreconditionProbe.set(engine,"b",config);
        PreconditionProbe.set(PreconditionProbe.get(engine,"s"),"a",Collections.singletonList(CtExcelOriginationProbe.TEL));
        PreconditionProbe.call(engine,"s",new Class<?>[0]);
        Object task=Class.forName("f82").getConstructor(Class.forName("o82"),String.class,Class.forName("ct0"),int.class)
                .newInstance(engine,"+33199000123",null,4);
        Object id=PreconditionProbe.call(task,"q",new Class<?>[]{Object.class},Class.forName("sc5").getField("a").get(null));
        check(dialogs.containsKey(id) && PreconditionProbe.wires.size()==1,"actual initial INVITE");
        String initial=PreconditionProbe.last("INVITE");
        check(initial.startsWith("INVITE tel:+33199000123 SIP/2.0"),"BASE global target");
        String expected=fixed?wanted:previous;

        fixture.accept(PreconditionProbe.response(initial,183,"R",PreconditionProbe.answer(true),
                "Require: 100rel, precondition\r\nRSeq: 1\r\n"+recordRoutes));
        String prack=PreconditionProbe.last("PRACK");
        check(prack!=null && prack.startsWith("PRACK sip:remote@[2001:db8::2]:5060"),"early remote target");
        check(expected.equals(routes(prack)),"PRACK routes "+routes(prack)+" expected "+expected);
        fixture.accept(PreconditionProbe.response(prack,200,"R","",""));
        String update=PreconditionProbe.last("UPDATE");
        check(update!=null && expected.equals(routes(update)),"early UPDATE routes="+(update==null?"none":routes(update)));

        fixture.accept(PreconditionProbe.response(initial,200,"R",PreconditionProbe.answer(true),recordRoutes));
        String ack=PreconditionProbe.last("ACK");
        check(ack!=null && ack.startsWith("ACK sip:remote@[2001:db8::2]:5060"),"final 2xx remote target");
        check(expected.equals(routes(ack)),"ACK routes "+routes(ack)+" expected "+expected);
        check(PreconditionProbe.count("CANCEL")==0,"no local cancellation");
        return routes(ack);
    }
    public static void main(String[] args) throws Exception {
        boolean fixed=args[0].equals("fixed");
        android.content.res.AssetManager.root=Paths.get(args[1]);
        Class.forName("fj5").getField("d").set(null,new android.content.Context());
        SipForkProbe.msg=Class.forName("kb4"); SipForkProbe.dialog=Class.forName("ma4");
        SipForkProbe.manager=Class.forName("cb4"); SipForkProbe.direction=Class.forName("ga4");
        SipForkProbe.state=Class.forName("la4"); SipForkProbe.helper=Class.forName("cc.forserein.simhub.internal.SipForkProtection");
        String[][] scenarios={
            {"separate","Record-Route: "+FAR+"\r\nRecord-Route: "+NEAR+"\r\n",NEAR+", "+FAR,NEAR+", "+FAR},
            {"combined","Record-Route: "+FAR+", "+NEAR+"\r\n",NEAR+", "+FAR,NEAR+", "+FAR},
            {"mixed","rEcOrD-rOuTe: "+FAR+", "+MIDDLE+"\r\nRecord-Route: "+QUOTED+"\r\n",
                QUOTED+", "+MIDDLE+", "+FAR,QUOTED+", "+MIDDLE+", "+FAR},
            {"quoted","record-route: "+FAR+", "+QUOTED+"\r\n",QUOTED+", "+FAR,QUOTED+", "+FAR},
            {"escaped-quote","record-route: "+FAR+", "+ESCAPED+"\r\n",ESCAPED+", "+FAR,
                "Edge\" <sip:near.example.invalid;lr>, \"Near\\\"A, "+FAR}
        };
        for(boolean tcp:new boolean[]{true,false})
            for(String[] s:scenarios)
                System.out.println("BASE "+s[0]+" "+(tcp?"TCP":"UDP")+" ACK "+checkCall(tcp,s[1],s[2],s[3],fixed));
        System.out.println("BASE_DIALOG_ROUTE "+args[0]+" checks="+tests+" protected="+PreconditionProbe.protectedPackets);
    }
}
