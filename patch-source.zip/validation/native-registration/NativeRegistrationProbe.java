import java.lang.reflect.*;
import java.util.*;

/** Resume the real shipped registration coroutine at its received-response boundary. */
public final class NativeRegistrationProbe {
 static final sun.misc.Unsafe U;
 static int checks;
 static {try{Field f=sun.misc.Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);U=(sun.misc.Unsafe)f.get(null);}catch(Exception e){throw new RuntimeException(e);}}
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;}
 static void set(Object o,String field,Object value)throws Exception{Field f=o.getClass().getField(field);f.setAccessible(true);f.set(o,value);}
 static o82 session()throws Exception {
  o82 s=(o82)U.allocateInstance(o82.class);
  xi5 config=(xi5)U.allocateInstance(xi5.class);set(config,"t",true);set(config,"z",U.allocateInstance(yj5.class));
  set(s,"b",config);set(s,"c",new ek5("515660000000001","8963660000000000001",2,null,null,null,null,null));
  set(s,"h",new x82(new byte[]{10,0,0,1}));set(s,"j",new x82(new byte[]{10,0,0,2}));set(s,"m",30600);set(s,"g",new g11());
  return s;
 }
 static Object response(o82 s,String expires,String... contacts)throws Exception {
  kb4 response=new kb4(false,"", "",200,"OK",new ArrayList(),new byte[0]);
  if(expires!=null)response.a("Expires",expires);
  for(String contact:contacts)response.a("Contact",contact);
  response.a("P-Associated-URI","<sip:515660000000001@ims.example>");
  j82 continuation=new j82(s,null);set(continuation,"U",qd1.T);continuation.m0=3;continuation.e0=new byte[0];continuation.f0=new byte[0];continuation.g0=new byte[0];
  xq0.task=null;g7.delayMillis=-1;
  return continuation.q(response);
 }
 static String local(o82 s,int seconds){return "<"+s.m()+">;expires="+seconds;}
 static long delay() {
  check(xq0.task instanceof bh1,"actual native registration task is scheduled");
  ((bh1)xq0.task).q(sc5.a);
  check(g7.delayMillis>=0,"actual native task reaches clock fixture");
  return g7.delayMillis;
 }
 static void expect(o82 s,String header,int expected,long expectedDelay,String...contacts)throws Exception {
  Object result=response(s,header,contacts);
  check(result instanceof x72,"actual registration coroutine returns native binding");
  check(s.s==result&&s.s.b==expected,"native registration state honors effective expiry: "+expected);
  check(delay()==expectedDelay,"native refresh delay before actual expiry: "+expectedDelay);
 }
 public static void main(String[]args)throws Exception {
  boolean legacy=args.length>0&&args[0].equals("legacy");
  o82 s=session();
  if(legacy){
   expect(s,"30",60,51000);
   expect(session(),"0",60,51000);
   s=session();expect(s,"600",60,51000,local(s,30));
   System.out.println("NATIVE_REGISTRATION legacy_regression_reproduced=true checks="+checks);return;
  }
  for(int n:new int[]{1,2,15,30,59,60,600,7200,Integer.MAX_VALUE}) expect(session(),String.valueOf(n),n,((long)n)*850);
  s=session();expect(s,"600",30,25500,local(s,30));
  s=session();expect(s,"30",600,510000,local(s,600));
  s=session();expect(s,"120",120,102000,"<sip:another@10.0.0.1:30600>;expires=0");
  s=session();expect(s,null,15,12750,local(s,15));
  expect(session(),null,600,510000);
  for(int n:new int[]{0,-1}) {
   s=session();s.s=new x72(Collections.singletonList("sip:old@ims.example"),600,s.j,s.h,new ArrayList());
   ls4 old=ls4.class.getConstructor(fu0.class,boolean.class).newInstance(qd1.T,true);s.w=old;
   check(old.d(),"old native coroutine job starts active");
   try{response(s,String.valueOf(n));throw new AssertionError("nonpositive expiry reported registered");}
   catch(IllegalStateException expected){check(expected.getMessage().contains("注册未生效"),"failure reason reports expired binding");}
   check(s.s==null,"old binding cleared on zero/negative expiry");check(xq0.task==null,"no immediate retry task for zero/negative expiry");
   check(!old.d()&&s.w==null,"old native refresh job cancelled and detached");
  }
  s=session();
  try{response(s,"600",local(s,0));throw new AssertionError("Contact expiry zero ignored");}
  catch(IllegalStateException expected){check(s.s==null&&xq0.task==null,"matching Contact zero overrides global lifetime");}
  s=session();s.y(0);check(xq0.task==null,"direct timer cancellation does not schedule a refresh");
  System.out.println("NATIVE_REGISTRATION current_passed=true checks="+checks);
 }
}
