/** Explicit coroutine scheduler fixture: capture the actual native task without running clocks. */
public final class xq0 {
 public static kt1 task;
 public static ls4 X(ou0 scope,fu0 context,ru0 start,kt1 block,int flags){task=block;return null;}
}
