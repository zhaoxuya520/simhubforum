/** Explicit clock fixture: record the native task's requested delay. */
public final class g7 {
 public static long delayMillis=-1;
 public static Object J(long millis,ct0 continuation){delayMillis=millis;return pu0.T;}
 public static boolean U(ou0 scope){return true;}
}
