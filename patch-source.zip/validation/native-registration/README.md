# Native IMS registration lifetime probe

This probe executes the actual APK's `o82.v` REGISTER response coroutine, `kb4`/`jb4` header and Contact parser, `x72` registration state, `o82.y` scheduler, `bh1.q` delay request, and `ls4`/`pl2` cancellation.

Synthetic `200 OK` responses are injected at the existing coroutine's post-network resume point (state 3). No native implementation under test is rewritten. `Unsafe` supplies a session whose constructor would otherwise require a live IKE tunnel. Explicit fixtures replace only the scheduling entry (`xq0`), clock (`g7`), and log sink (`g11`). The scheduler captures the actual `bh1` task; invoking that native task records its requested delay without waiting real minutes. A real active `ls4` job verifies old-job cancellation.

The normalized DEX jar is reused only when `native-carrier-runtime.json` matches the input APK SHA-256. R8 constructor bridge/interface normalization is the same generic host compatibility step used by the existing probes. This is host JVM execution, not ART, a real SIM, ePDG authentication, or a live operator registration.

Cases cover 1/2/15/30/59/60/600/7200/max-int second lifetimes, matching Contact precedence, unrelated Contact isolation, absent header fallback, nonpositive lifetime rejection, stale binding clearing and refresh cancellation. The old 23.2 package reproduces 30 seconds becoming 60 seconds with a 51-second refresh, including an invalid zero lifetime incorrectly becoming registered.

Reference: RFC 3261 sections 10.2.4 and 10.3 specify registrar-provided binding lifetime and Contact `expires` precedence. Section 10.2.4 says refreshes should occur before expiration. The 85% policy is the application's existing policy; this repair removes its 60/30-second floors and computes the delay in milliseconds.

## Lifecycle review and scope

Read-only review additionally covered native `zl5` connection generations/retries and shutdown, plus `b72.a` IKE DELETE and pending exchange/key cleanup. No further lifecycle defect has been established by executable evidence; the existing IKE/AKA negotiation and connection worker remain unchanged.

The successful REGISTER response path clears its three temporary EAP key arrays before the added expiry validation. The validation is outside that key-cleanup try. During renewal, existing `o82.b` catches ordinary failures, clears registration and notifies the connection callback. Initial-connect failures retain their existing worker cleanup path.

`protocol-review.json` records external source URLs and SHA-256 hashes, including a pinned AOSP IWLAN commit. AOSP per-session token handling and strongSwan IKE_AUTH/DPD code were comparison material; no external implementation was copied into production. Full third-party sources remain outside this project archive.
