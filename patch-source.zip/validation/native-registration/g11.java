import java.util.*;
/** Explicit log sink fixture; no registration logic. */
public final class g11 {
 public final List<String> messages=new ArrayList<>();
 public Object i(Object value){messages.add(String.valueOf(value));return null;}
}
