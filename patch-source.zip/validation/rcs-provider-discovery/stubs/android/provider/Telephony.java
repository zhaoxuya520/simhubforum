package android.provider;

import android.content.Context;

public class Telephony {
    public static class Sms {
        public static String getDefaultSmsPackage(Context context) { return context.defaultSms; }
    }
}
