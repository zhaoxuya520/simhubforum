package android.content;

import android.content.pm.PackageManager;

public class Context {
    public PackageManager pm;
    public String defaultSms;
    public int grant = PackageManager.PERMISSION_GRANTED;
    public PackageManager getPackageManager() { return pm; }
    public int checkSelfPermission(String permission) {
        if (!"com.gsma.services.permission.RCS".equals(permission)) throw new AssertionError(permission);
        return grant;
    }
}
