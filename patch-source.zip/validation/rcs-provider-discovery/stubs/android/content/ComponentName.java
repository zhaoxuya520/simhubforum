package android.content;

import java.util.Objects;

public final class ComponentName {
    public final String packageName;
    private final String className;
    public ComponentName(String packageName, String className) {
        this.packageName = packageName;
        this.className = className;
    }
    public String getPackageName() { return packageName; }
    public boolean equals(Object other) {
        if (!(other instanceof ComponentName)) return false;
        ComponentName name = (ComponentName) other;
        return packageName.equals(name.packageName) && className.equals(name.className);
    }
    public int hashCode() { return Objects.hash(packageName, className); }
}
