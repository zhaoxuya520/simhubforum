package android.content.pm;

public class ServiceInfo {
    public String packageName, name, permission;
    public boolean enabled, exported;
    public ApplicationInfo applicationInfo;
    public CharSequence loadLabel(PackageManager pm) { return packageName; }
}
