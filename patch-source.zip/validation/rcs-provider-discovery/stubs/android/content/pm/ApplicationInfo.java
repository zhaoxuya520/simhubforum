package android.content.pm;

public class ApplicationInfo {
    public static final int FLAG_SYSTEM = 1, FLAG_UPDATED_SYSTEM_APP = 128, FLAG_SUSPENDED = 0x40000000;
    public String packageName;
    public int uid, flags;
    public boolean enabled;
}
