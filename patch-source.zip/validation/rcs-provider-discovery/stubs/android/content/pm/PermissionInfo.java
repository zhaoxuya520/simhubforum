package android.content.pm;

public class PermissionInfo {
    public String packageName;
}
