package android.content.pm;

import android.content.ComponentName;
import android.content.Intent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PackageManager {
    public static final int MATCH_DISABLED_COMPONENTS = 512, PERMISSION_GRANTED = 0;
    public final List<ResolveInfo> active = new ArrayList<>(), includingDisabled = new ArrayList<>();
    public final Map<ComponentName,ServiceInfo> services = new HashMap<>();
    public final Map<String,ApplicationInfo> apps = new HashMap<>();
    public String permissionOwner;

    public static class NameNotFoundException extends Exception {}
    public List<ResolveInfo> queryIntentServices(Intent intent, int flags) {
        if (!"com.gsma.services.rcs.chat.IChatService".equals(intent.action)) throw new AssertionError(intent.action);
        if (flags == 0) return active;
        if (flags != MATCH_DISABLED_COMPONENTS) throw new AssertionError(flags);
        return includingDisabled;
    }
    public PermissionInfo getPermissionInfo(String name, int flags) throws NameNotFoundException {
        if (!"com.gsma.services.permission.RCS".equals(name)) throw new AssertionError(name);
        if (permissionOwner == null) throw new NameNotFoundException();
        PermissionInfo result = new PermissionInfo();
        result.packageName = permissionOwner;
        return result;
    }
    public ApplicationInfo getApplicationInfo(String name, int flags) throws NameNotFoundException {
        if (!apps.containsKey(name)) throw new NameNotFoundException();
        return apps.get(name);
    }
    public ServiceInfo getServiceInfo(ComponentName name, int flags) throws NameNotFoundException {
        if (!services.containsKey(name)) throw new NameNotFoundException();
        return services.get(name);
    }
}
