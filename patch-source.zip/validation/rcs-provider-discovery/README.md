# RCS provider discovery regression

This JVM test compiles the shipping provider selector against the public Android SDK. It exercises 27 discovery and revalidation cases using synthetic package and SMS-role records. Cases cover the selected default provider, trusted system services, duplicate and ambiguous components, disabled services, and revocation of a role, permission, service or UID.

After compiling the application helpers with `build_from_config2.py`, run:

```sh
python3 validation/rcs-provider-discovery/check_runtime.py --report /tmp/rcs-provider-discovery.json
```

The test records the exact source and fixture hashes. Actual package visibility, Binder, registration, carrier connections and delivery require separate device testing.
