#!/usr/bin/env python3
"""Run the production provider selector against synthetic Android package metadata."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--report', type=Path)
parser.add_argument('--compiled-classes', type=Path, default=PROJECT / 'build-config3/classes',
                    help='Previously compiled application helpers and public GSMA bindings')
args = parser.parse_args()
tools = Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery'))
compiler = ['java', '-jar', tools / 'ecj-3.40.0.jar', '-8', '-warn:none', '-encoding', 'UTF-8']
production = PROJECT / 'src/cc/forserein/simhub/internal'
sources = [production / 'RcsProviderDiscovery.java', production / 'RcsChatTransport.java']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compile_to(directory, classpath, inputs):
    directory.mkdir()
    subprocess.run([*compiler, '-cp', os.pathsep.join(map(str, classpath)),
                    '-d', directory, *inputs], check=True)


with tempfile.TemporaryDirectory(prefix='simhub-rcs-discovery-') as temp:
    root = Path(temp)
    implementation = root / 'production'
    doubles = root / 'fixtures'
    # Compile the actual application against Android, independently of the fake types below.
    compile_to(implementation, [args.compiled_classes, tools / 'sdk/android-35/android.jar'], sources)
    fixtures = sorted(HERE.rglob('*.java'))
    compile_to(doubles, [implementation, args.compiled_classes], fixtures)
    run = subprocess.run(['java', '-cp', os.pathsep.join(map(str, [doubles, implementation])),
                          'cc.forserein.simhub.internal.ProviderDiscoveryTest'],
                         capture_output=True, text=True)
    if run.returncode:
        raise RuntimeError(run.stdout + run.stderr)
    print(run.stdout.strip())
    count = int(re.fullmatch(r'PASS: (\d+) discovery and revalidation checks', run.stdout.strip())[1])
    report = dict(checks=count, status='passed', android_emulator=False,
                  synthetic_package_and_role_metadata=True, binder_or_network=False,
                  source_sha256={p.name: digest(p) for p in sources},
                  fixture_sha256={str(p.relative_to(HERE)): digest(p) for p in [Path(__file__), *fixtures]},
                  production_class_sha256=digest(implementation / 'cc/forserein/simhub/internal/RcsProviderDiscovery.class'))

if args.report:
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + '\n')
