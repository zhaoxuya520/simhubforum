package cc.forserein.simhub.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;

/** Unit tests for SIMHub's Android package selection and revocation policy. No service is bound. */
public final class ProviderDiscoveryTest {
    private static final String PERMISSION = RcsChatTransport.PERMISSION;
    private static int checks;

    private final Context context = new Context();
    private final PackageManager pm = new PackageManager();

    ProviderDiscoveryTest(String permissionOwner, String defaultSms) {
        pm.permissionOwner = permissionOwner;
        context.pm = pm;
        context.defaultSms = defaultSms;
    }

    private ServiceInfo add(String pkg, String name, int flags) {
        ServiceInfo service = new ServiceInfo();
        service.name = name;
        service.packageName = pkg;
        service.exported = true;
        service.enabled = true;
        service.permission = PERMISSION;
        ApplicationInfo app = new ApplicationInfo();
        app.enabled = true;
        app.flags = flags;
        app.uid = 100 + pm.apps.size();
        app.packageName = pkg;
        service.applicationInfo = app;
        ResolveInfo entry = new ResolveInfo();
        entry.serviceInfo = service;
        pm.active.add(entry);
        pm.includingDisabled.add(entry);
        pm.services.put(new ComponentName(pkg, name), service);
        pm.apps.put(pkg, app);
        return service;
    }

    private RcsProviderDiscovery select() { return RcsProviderDiscovery.find(context); }

    private static void check(boolean value) {
        if (!value) throw new AssertionError("Discovery assertion " + (checks + 1));
        checks++;
    }

    private static void rejects(Runnable operation, String reason) {
        try {
            operation.run();
        } catch (RcsChatTransport.UserFailure error) {
            if (!error.getMessage().contains(reason)) throw new AssertionError(error);
            checks++;
            return;
        }
        throw new AssertionError("Unexpectedly allowed: " + reason);
    }

    private static void preferredPackages() {
        ProviderDiscoveryTest system = new ProviderDiscoveryTest("system", "other");
        system.add("system", "Service", ApplicationInfo.FLAG_SYSTEM);
        RcsProviderDiscovery only = system.select();
        check(!only.dependsOnSmsRole);
        only.requireCurrent(system.context);
        check(only.component.getPackageName().equals("system"));

        ProviderDiscoveryTest mixed = new ProviderDiscoveryTest("android", "messaging");
        mixed.add("system", "ChatService", ApplicationInfo.FLAG_SYSTEM);
        mixed.add("messaging", "ChatService", 0);
        RcsProviderDiscovery preferred = mixed.select();
        check(preferred.dependsOnSmsRole && preferred.component.getPackageName().equals("messaging"));
        preferred.requireCurrent(mixed.context);
        mixed.context.defaultSms = "other";
        rejects(() -> preferred.requireCurrent(mixed.context), "默认短信应用已变更");
        check(mixed.select().component.getPackageName().equals("system"));

        ProviderDiscoveryTest components = new ProviderDiscoveryTest("messaging", "messaging");
        components.add("messaging", "ChatService", 0);
        components.pm.active.add(components.pm.active.get(0));
        check(components.select().component.equals(new ComponentName("messaging", "ChatService")));
        components.add("messaging", "OtherChatService", 0);
        rejects(components::select, "多个");

        ProviderDiscoveryTest split = new ProviderDiscoveryTest("vendor", "messaging");
        split.add("messaging", "ChatService", 0);
        ApplicationInfo vendor = new ApplicationInfo();
        vendor.flags = ApplicationInfo.FLAG_UPDATED_SYSTEM_APP;
        split.pm.apps.put("vendor", vendor);
        RcsProviderDiscovery trusted = split.select();
        check(trusted.dependsOnSmsRole);
        trusted.requireCurrent(split.context);
        vendor.flags = 0;
        rejects(() -> trusted.requireCurrent(split.context), "权限已变更");

        ProviderDiscoveryTest systemTie = new ProviderDiscoveryTest("android", "selected");
        systemTie.add("first", "ChatService", ApplicationInfo.FLAG_SYSTEM);
        systemTie.add("selected", "ChatService", ApplicationInfo.FLAG_SYSTEM);
        RcsProviderDiscovery winner = systemTie.select();
        check(winner.dependsOnSmsRole && winner.component.getPackageName().equals("selected"));
        systemTie.context.defaultSms = null;
        rejects(() -> winner.requireCurrent(systemTie.context), "默认短信应用已变更");
        rejects(systemTie::select, "多个");

        ProviderDiscoveryTest updatedSystem = new ProviderDiscoveryTest("system", null);
        updatedSystem.add("system", "ChatService", ApplicationInfo.FLAG_UPDATED_SYSTEM_APP);
        check(!updatedSystem.select().dependsOnSmsRole);
    }

    private static void discoveryFailures() {
        ProviderDiscoveryTest absent = new ProviderDiscoveryTest(null, null);
        rejects(absent::select, "未向 SIMHub 公布");
        absent.add("disabled", "ChatService", 0);
        absent.pm.active.clear();
        rejects(absent::select, "已停用");

        ProviderDiscoveryTest user = new ProviderDiscoveryTest("app", null);
        ServiceInfo service = user.add("app", "ChatService", 0);
        rejects(user::select, "不是系统应用");
        user.context.defaultSms = "app";
        service.applicationInfo.flags = ApplicationInfo.FLAG_SUSPENDED;
        rejects(user::select, "停用或暂停");
        service.applicationInfo.flags = 0;
        service.exported = false;
        rejects(user::select, "未向其他应用开放");
        service.exported = true;
        service.permission = "unrelated.permission";
        rejects(user::select, "未声明兼容");
        service.permission = PERMISSION;
        user.pm.permissionOwner = null;
        rejects(user::select, "无法核实");
        user.pm.permissionOwner = "unrelated.app";
        rejects(user::select, "无法核实");
        user.pm.permissionOwner = "android";
        user.context.grant = -1;
        rejects(user::select, "未授予 SIMHub");
    }

    private static void changesAfterSelection() {
        ProviderDiscoveryTest setup = new ProviderDiscoveryTest("app", "app");
        ServiceInfo service = setup.add("app", "ChatService", 0);
        RcsProviderDiscovery pinned = setup.select();
        setup.context.grant = -1;
        rejects(() -> pinned.requireCurrent(setup.context), "未授予 SIMHub");
        setup.context.grant = 0;
        setup.pm.permissionOwner = "android";
        rejects(() -> pinned.requireCurrent(setup.context), "权限已变更");
        setup.pm.permissionOwner = "app";
        service.applicationInfo.uid++;
        rejects(() -> pinned.requireCurrent(setup.context), "服务已变更");
        service.applicationInfo.uid--;
        service.exported = false;
        rejects(() -> pinned.requireCurrent(setup.context), "服务已变更");
        service.exported = true;
        setup.pm.services.clear();
        rejects(() -> pinned.requireCurrent(setup.context), "停用或移除");
    }

    public static void main(String[] args) {
        preferredPackages();
        discoveryFailures();
        changesAfterSelection();
        System.out.println("PASS: " + checks + " discovery and revalidation checks");
    }
}
