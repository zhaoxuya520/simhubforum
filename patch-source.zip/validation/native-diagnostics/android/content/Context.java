package android.content;
public class Context {public static Intent last;public void startActivity(Intent intent){last=intent;}}
