package android.content;
import java.util.*;
public class Intent {
 public String action,type;public final Map<String,String> extras=new LinkedHashMap<String,String>();
 public Intent(String action){this.action=action;}
 public Intent setType(String type){this.type=type;return this;}
 public Intent putExtra(String key,String value){extras.put(key,value);return this;}
 public static Intent createChooser(Intent intent,CharSequence title){return intent;}
 public Intent addFlags(int flags){return this;}
}
