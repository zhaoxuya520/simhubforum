package android.os;
public class Handler {
 public interface Callback {}
 public Handler(Looper l){} public Handler(Looper l,Callback c,boolean async){}
 public static Handler createAsync(Looper l){return new Handler(l);}
 public boolean post(Runnable r){return true;}
 public Looper getLooper(){return Looper.getMainLooper();}
}
