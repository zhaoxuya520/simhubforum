# Diagnostic share regression

`NativeDiagnosticsProbe` executes the APK's actual `zl5.b` logger, `gl5`/`rt4` state and `ej.a` ACTION_SEND callback. It checks the actual `Intent.EXTRA_TEXT`, including the sanitizer from the tested APK. Only Android scheduling/Intent APIs and the share-title localization lookup are fixtures.

The telephone/URI shapes correspond to existing INVITE/registration diagnostics. Authentication headers use synthetic injected values to test the defensive export boundary; they are not evidence that normal outgoing Authorization credentials were logged. All identifiers are synthetic. No network or real device is used.

`check_native_diagnostics_runtime.py APK DECODED --report result.json` runs the fixed APK; `--legacy` confirms the previous share exposed telephone identities while its existing IMSI mask worked. The converter needs JVM `-noverify`; this is separate from Android DEX/ART validation. Unit tests additionally cover encoded userinfo, short numbers, folded and truncated authentication, route/query preservation, and mixed Call-ID lines.
