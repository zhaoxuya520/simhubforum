import java.lang.reflect.*;
import android.content.*;

/** Executes actual APK logger/state/share callback. All input identifiers are synthetic. */
public final class NativeDiagnosticsProbe {
 static int checks;
 static void check(boolean value,String reason){checks++;if(!value)throw new AssertionError(reason);}
 public static void main(String[] args)throws Exception {
  boolean legacy=args.length>0&&args[0].equals("legacy");
  Class<?> logger=Class.forName("zl5");Method log=logger.getMethod("b",String.class);
  String[] rows={
   "  200 P-Asserted-Identity: <tel:+85255551234>",
   "INVITE sip:1234@ims.example.org;user=phone",
   "IMPU=sips:subscriber%40department@ims.mnc066.mcc515.3gppnetwork.org",
   "IMSI=515660000000001",
   "收到短信 来自 +85255554321",
   "← 来电 INVITE 来自 +85255559876；语音编码：AMR-WB PT 116",
   "来电 synthetic-caller（前提条件 100rel，等待 PRACK）",
   "  WWW-Authenticate: Digest realm=\"ims.example.org\", nonce=\"SYNTHETIC_NONCE\",\r\n    algorithm=AKAv1-MD5, response=\"SYNTHETIC_RESPONSE\"",
   "  Proxy-Authorization: Bearer SYNTHETIC_BEARER",
   "  200 Record-Route: <sip:10.5.236.161:5060;transport=tcp;lr>",
   "Call-ID: correlation-1234@10.5.236.161",
   "媒体：麦克风 94 帧，发 RTP 94，收 RTP 53，PT 116；10.5.236.218:10804 → :44886",
   "a=rtpmap:116 AMR-WB/16000",
   "SIP/2.0 403 Forbidden"
  };
  for(String row:rows)log.invoke(null,row);
  Class<?> share=Class.forName("ej");Object callback=share.getConstructor(Context.class,int.class).newInstance(new Context(),7);
  share.getMethod("a").invoke(callback);
  check(Context.last!=null&&"android.intent.action.SEND".equals(Context.last.action),"actual share action emitted");
  check("text/plain".equals(Context.last.type),"original share format retained");
  String body=Context.last.extras.get("android.intent.extra.TEXT");
  check(body!=null&&body.startsWith("SIMHub VoWiFi SMS log\nPLMN "),"actual native log summary retained");
  check(body.contains("+85255551234")==legacy,"telephone identity removed only by patched share");
  check(body.contains("sip:1234@")==legacy&&body.contains("subscriber%40department")==legacy,"short and encoded SIP user identities removed");
  check(!body.contains("515660000000001")&&body.contains("51566••••••••01"),"existing logger IMSI protection preserved");
  check(body.contains("+85255554321")==legacy,"actual SMS sender diagnostic line redacted without modifying message contents");
  check(body.contains("+85255559876")==legacy&&body.contains("synthetic-caller")==legacy,"actual bare incoming identity diagnostics redacted");
  check(body.contains("；语音编码：AMR-WB PT 116")&&body.contains("（前提条件 100rel，等待 PRACK）"),"incoming codec and precondition diagnostics retained");
  check(body.contains("SYNTHETIC_NONCE")==legacy&&body.contains("SYNTHETIC_RESPONSE")==legacy&&body.contains("SYNTHETIC_BEARER")==legacy,"defensive authentication boundary covers synthetic values and folding");
  check(body.contains("realm=\"ims.example.org\"")&&body.contains("algorithm=AKAv1-MD5"),"authentication realm and algorithm retained");
  for(String fragment:new String[]{"ims.mnc066.mcc515.3gppnetwork.org","sip:10.5.236.161:5060;transport=tcp;lr","Call-ID: correlation-1234@10.5.236.161","收 RTP 53，PT 116","10.5.236.218:10804 → :44886","a=rtpmap:116 AMR-WB/16000","SIP/2.0 403 Forbidden"})check(body.contains(fragment),"diagnostic context retained: "+fragment);
  Object flow=logger.getField("b").get(null),state=flow.getClass().getMethod("getValue").invoke(flow);
  check(state.getClass().getField("p").get(state).toString().contains("+85255551234"),"internal stored diagnostics unchanged");
  System.out.println("NATIVE_DIAGNOSTICS "+(legacy?"legacy_regression_reproduced":"current_passed")+"=true checks="+checks);
 }
}
