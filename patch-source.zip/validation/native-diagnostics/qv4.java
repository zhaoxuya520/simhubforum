/** Localization fixture only: no log, state, sharing or sanitizer behavior is replaced. */
public class qv4 {public static String b(String key){return key;}}
