import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class IncomingLifecycleProbe {
  static int checks;
  static boolean previous;
  static final String ID = "incoming-probe@example.invalid",
      FROM = "<sip:peer@example.invalid>;tag=remote-tag",
      TO = "<sip:local@example.invalid>";

  static void check(boolean b, String m) {
    if (!b) throw new AssertionError(m);
    checks++;
  }

  static Object get(Object o, String f) throws Exception {
    return SipForkProbe.get(o, f);
  }

  static void set(Object o, String f, Object v) throws Exception {
    SipForkProbe.set(o, f, v);
  }

  static Object call(Object o, String m, Class<?>[] t, Object... v) throws Exception {
    return SipForkProbe.call(o, m, t, v);
  }

  static Object parse(String text) throws Exception {
    return Class.forName("jb4")
        .getMethod("c", byte[].class)
        .invoke(null, (Object) text.getBytes(StandardCharsets.UTF_8));
  }

  static class Session {
    final SipForkProbe.Session s = new SipForkProbe.Session(true);
    final t00 events = new t00();
    final String initial;

    Session() throws Exception {
      ((Map) get(s.m, "e")).clear();
      set(s.e, "N", events);
      set(s.e, "y", new LinkedHashMap<Object, Object>());
      Object ip =
          Class.forName("x82")
              .getConstructor(byte[].class)
              .newInstance((Object) new byte[] {(byte) 192, 0, 2, 1});
      Object codecs = Class.forName("vk").getField("c").get(null);
      Object answer =
          Class.forName("pu")
              .getConstructor(Object.class, int.class, Object.class, int.class)
              .newInstance(ip, 45000, codecs, 11);
      set(s.m, "b", answer);
      initial = request("INVITE", 10, null, "z9hG4bK-original", SipForkProbe.A);
    }

    String request(String method, int seq, String tag, String branch, String body) {
      return method
          + " sip:local@example.invalid SIP/2.0\r\nVia: SIP/2.0/UDP 192.0.2.10:5060;branch="
          + branch
          + ";rport\r\nFrom: "
          + FROM
          + "\r\nTo: "
          + TO
          + (tag == null ? "" : ";tag=" + tag)
          + "\r\nCall-ID: "
          + ID
          + "\r\nCSeq: "
          + seq
          + " "
          + method
          + "\r\n"
          + "Contact: <sip:peer@192.0.2.10:5060>\r\n"
          + "Content-Type: application/sdp\r\n"
          + "Content-Length: "
          + body.length()
          + "\r\n\r\n"
          + body;
    }

    void incoming(String wire) throws Exception {
      incoming(wire, null);
    }

    void incoming(String wire, Object transport) throws Exception {
      call(
          s.e,
          "r",
          new Class<?>[] {SipForkProbe.msg, Class.forName("oc2"), String.class},
          parse(wire),
          transport,
          "offline UDP");
    }

    Object dialog() throws Exception {
      return ((Map) get(s.m, "e")).get(ID);
    }

    int count(String type) throws Exception {
      int n = 0;
      for (Object e : events.events) if (type.equals(e.getClass().getName())) n++;
      return n;
    }

    int lastStatus() throws Exception {
      List p = s.packets();
      return (Integer) get(p.get(p.size() - 1), "d");
    }

    void control(int kind) throws Exception {
      control(ID, kind);
    }

    void control(String id, int kind) throws Exception {
      Object task =
          Class.forName("f82")
              .getConstructor(Class.forName("o82"), String.class, Class.forName("ct0"), int.class)
              .newInstance(s.e, id, null, kind);
      call(task, "q", new Class<?>[] {Object.class}, Class.forName("sc5").getField("a").get(null));
    }

    void initial() throws Exception {
      incoming(initial);
      check(
          dialog() != null && count("fb4") == 1 && lastStatus() == 180,
          "ordinary actual incoming call rings exactly once");
    }

    String tag() throws Exception {
      return (String) get(dialog(), "d");
    }
  }

  static Session rejected() throws Exception {
    Session session = new Session();
    session.initial();
    String tag = session.tag();
    session.control(2);
    session.incoming(session.request("ACK", 10, tag, "z9hG4bK-original", ""));
    check(session.dialog() == null, "603 transaction acknowledged and removed");
    return session;
  }

  static void extended() throws Exception {
    for (String distinct : new String[] {"sequence", "branch", "Call-ID"}) {
      Session s = rejected();
      String packet;
      if (distinct.equals("sequence"))
        packet = s.request("INVITE", 11, null, "z9hG4bK-original", SipForkProbe.A);
      else if (distinct.equals("branch"))
        packet = s.request("INVITE", 10, null, "z9hG4bK-new", SipForkProbe.A);
      else packet = s.initial.replace(ID, "new-call@example.invalid");
      s.incoming(packet);
      check(
          s.lastStatus() == 180 && s.count("fb4") == 2,
          "independent new incoming call after " + distinct + " change");
    }
    Session s = new Session();
    s.initial();
    String tag = s.tag();
    s.control(0);
    s.incoming(s.request("ACK", 10, tag, "z9hG4bK-ack", ""));
    Object dialog = s.dialog();
    s.incoming(s.request("INVITE", 11, tag, "z9hG4bK-reinvite", SipForkProbe.B));
    check(
        s.dialog() == dialog && s.count("fb4") == 1 && s.lastStatus() == 200,
        "in-dialog re-INVITE retains accepted call");
    if (!previous) {
      s = rejected();
      String newer = s.initial.replace(ID, "active-new@example.invalid");
      s.incoming(newer);
      Object active = ((Map) get(s.s.m, "e")).get("active-new@example.invalid");
      check(active != null, "new call is ringing");
      SipForkProbe.Snapshot before = new SipForkProbe.Snapshot(active);
      int rings = s.count("fb4");
      s.incoming(s.initial);
      check(
          s.lastStatus() == 603 && s.count("fb4") == rings && s.dialog() == null,
          "old retransmission replays cached rejection without disturbing new call");
      before.unchanged("other active incoming call preserved");
    }
  }

  static void replyTransport() throws Exception {
    Session s = rejected();
    int rings = s.count("fb4");
    Object connection = Class.forName("lb4").getConstructor(int.class).newInstance(9);
    String chain =
        ";rport=44001;received=192.0.2.55\r\n"
            + "Via: SIP/2.0/TCP 192.0.2.40:5060;branch=z9hG4bK-proxy\r\n";
    String received = s.initial.replace(";rport\r\n", chain);
    SipForkProbe.sentBytes = null;
    SipForkProbe.sentContext = null;
    s.incoming(received, connection);
    check(
        SipForkProbe.sentContext == connection && SipForkProbe.sentBytes != null,
        "cached rejection uses current incoming SIP transport");
    Object response = parse(new String(SipForkProbe.sentBytes, StandardCharsets.UTF_8));
    List<String> via = SipForkProbe.headers(response, "Via");
    check(
        (Integer) get(response, "d") == 603
            && via.size() == 2
            && via.get(0).contains("rport=44001;received=192.0.2.55")
            && via.get(1).contains("z9hG4bK-proxy"),
        "replayed response echoes current Via chain and rport");
    check(s.count("fb4") == rings && s.dialog() == null, "no ringing on changed incoming socket");
    ArrayList<Object> flaky =
        new ArrayList<Object>() {
          boolean first = true;

          public boolean add(Object packet) {
            if (first) {
              first = false;
              throw new IllegalStateException("simulated transient send failure");
            }
            return super.add(packet);
          }
        };
    set(s.s.e, "V", flaky);
    s.incoming(s.initial);
    check(
        flaky.isEmpty() && s.count("fb4") == rings && s.dialog() == null,
        "send error cannot re-ring a rejected call");
    s.incoming(s.initial);
    check(
        flaky.size() == 1 && s.lastStatus() == 603 && s.count("fb4") == rings,
        "next retransmission resends final response");
  }

  static Field field(Class<?> type, String name) throws Exception {
    Field f = type.getDeclaredField(name);
    f.setAccessible(true);
    return f;
  }

  static Map<?, ?> cachedReplies(Session s) throws Exception {
    Class<?> helper = Class.forName("cc.forserein.simhub.internal.SipIncomingInvite");
    Map<?, ?> cache = (Map<?, ?>) field(helper, "CACHE").get(null);
    Object bucket = cache.get(s.s.m);
    return (Map<?, ?>) field(bucket.getClass(), "replies").get(bucket);
  }

  static void retention() throws Exception {
    Session s = rejected();
    Map<?, ?> replies = cachedReplies(s);
    check(replies.size() == 1, "one completed transaction");
    Object entry = replies.values().iterator().next();
    Field when = field(entry.getClass(), "created");
    long first = when.getLong(entry);
    s.incoming(s.initial);
    check(when.getLong(entry) == first, "duplicate INVITE does not renew cache lifetime");
    when.setLong(entry, System.nanoTime() - 33_000_000_000L);
    s.incoming(s.initial);
    check(
        s.dialog() != null && s.lastStatus() == 180 && s.count("fb4") == 2 && replies.isEmpty(),
        "expired completed transaction is no longer replayed");

    s = new Session();
    for (int i = 0; i < 65; i++) {
      String id = "capacity-" + i + "@example.invalid", branch = "z9hG4bK-cache-" + i;
      s.incoming(s.request("INVITE", 10, null, branch, SipForkProbe.A).replace(ID, id));
      Object dialog = ((Map<?, ?>) get(s.s.m, "e")).get(id);
      s.control(id, 2);
      s.incoming(s.request("ACK", 10, (String) get(dialog, "d"), branch, "").replace(ID, id));
    }
    check(
        cachedReplies(s).size() == 64 && ((Map<?, ?>) get(s.s.m, "e")).isEmpty(),
        "bounded retained responses, native dialogs removed");
    int rings = s.count("fb4");
    s.incoming(
        s.request("INVITE", 10, null, "z9hG4bK-cache-64", SipForkProbe.A)
            .replace(ID, "capacity-64@example.invalid"));
    check(
        s.lastStatus() == 603 && rings == s.count("fb4"), "most recent transaction still answers");
    s.incoming(
        s.request("INVITE", 10, null, "z9hG4bK-cache-0", SipForkProbe.A)
            .replace(ID, "capacity-0@example.invalid"));
    check(
        s.lastStatus() == 180 && rings + 1 == s.count("fb4"),
        "oldest independent transaction evicted");
  }

  public static void main(String[] args) throws Exception {
    previous = args[0].equals("previous-24-2");
    SipForkProbe.msg = Class.forName("kb4");
    SipForkProbe.dialog = Class.forName("ma4");
    SipForkProbe.manager = Class.forName("cb4");
    SipForkProbe.direction = Class.forName("ga4");
    SipForkProbe.state = Class.forName("la4");
    SipForkProbe.helper = Class.forName("cc.forserein.simhub.internal.SipForkProtection");
    Session s = new Session();
    s.initial();
    Object first = s.dialog();
    String tag = s.tag();
    s.incoming(s.initial);
    check(
        s.dialog() == first && s.count("fb4") == 1 && s.lastStatus() == 180,
        "initial INVITE retransmission while ringing replays180 without ringing again");
    s.control(0);
    check(
        s.lastStatus() == 200 && s.count("db4") == 1, "actual accept sends200 and connected event");
    check(!((List) get(first, "F")).isEmpty(), "actual incoming200 owns ACK retransmission timer");
    s.incoming(s.initial);
    check(
        s.dialog() == first && s.lastStatus() == 200 && s.count("fb4") == 1 && s.count("db4") == 1,
        "repeated originalINVITE after accept replays200 only");
    int sent = s.s.packets().size();
    s.incoming(s.request("ACK", 10, tag, "z9hG4bK-ack", ""));
    check(
        s.s.packets().size() == sent && s.dialog() == first && ((List) get(first, "F")).isEmpty(),
        "matching incoming ACK clears actual200 timer without sending response or ending call");
    s.incoming(s.request("BYE", 11, tag, "z9hG4bK-bye", ""));
    check(
        s.dialog() == null && s.lastStatus() == 200 && s.count("eb4") == 1,
        "normal remoteBYE ends once");
    s.incoming(s.request("BYE", 11, tag, "z9hG4bK-bye", ""));
    check(
        s.dialog() == null && s.lastStatus() == 481 && s.count("eb4") == 1,
        "duplicateBYE responds481 but does not duplicate ending event");
    System.out.println("NORMAL incoming_retransmit_accept_ack_bye=true");
    s = new Session();
    s.initial();
    first = s.dialog();
    tag = s.tag();
    s.control(2);
    check(
        s.lastStatus() == 603 && s.count("eb4") == 1, "actual user decline sends603 and ends once");
    s.incoming(s.initial);
    check(
        s.dialog() == first && s.lastStatus() == 603 && s.count("fb4") == 1,
        "initialINVITE before finalACK replays603 without new ringing");
    s.incoming(s.request("ACK", 10, tag, "z9hG4bK-original", ""));
    check(s.dialog() == null, "actual matching603 ACK removes terminated incoming dialog");
    s.incoming(s.initial);
    check(
        (s.dialog() != null) == previous
            && s.dialog() != first
            && s.count("fb4") == (previous ? 2 : 1)
            && s.lastStatus() == (previous ? 180 : 603),
        "declined call retransmission after final ACK");
    System.out.println(
        "DECLINE late_duplicate_initial_invite_rings_again="
            + previous
            + " rings="
            + s.count("fb4")
            + " ended="
            + s.count("eb4"));
    s = new Session();
    s.initial();
    first = s.dialog();
    tag = s.tag();
    s.incoming(s.request("CANCEL", 10, null, "z9hG4bK-original", ""));
    check(
        s.lastStatus() == 487 && s.count("eb4") == 1, "actual remoteCANCEL sends487 and ends once");
    s.incoming(s.request("ACK", 10, tag, "z9hG4bK-original", ""));
    check(s.dialog() == null, "actual matching487 ACK removes incoming dialog");
    s.incoming(s.initial);
    check(
        (s.dialog() != null) == previous
            && s.count("fb4") == (previous ? 2 : 1)
            && s.lastStatus() == (previous ? 180 : 487),
        "cancelled call retransmission after final ACK");
    System.out.println(
        "CANCEL late_duplicate_initial_invite_rings_again="
            + previous
            + " rings="
            + s.count("fb4")
            + " ended="
            + s.count("eb4"));
    extended();
    if (!previous) {
      replyTransport();
      retention();
    }
    System.out.println("INCOMING_LIFECYCLE mode=" + args[0] + " checks=" + checks);
  }
}
