import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;
import org.jf.dexlib2.*;
import org.jf.dexlib2.iface.*;
import org.jf.dexlib2.iface.instruction.*;
import org.jf.dexlib2.iface.reference.*;
import org.jf.dexlib2.analysis.*;
import org.jf.dexlib2.analysis.reflection.ReflectionClassDef;
import org.jf.dexlib2.dexbacked.DexBackedDexFile;

/** Analyze register types in the shipped DEX, not the Python dispatch simulation. */
public final class VerifySwitchDex {
 static final Map<String,ClassDef> classes=new HashMap<>();
 static ClassProvider provider;
 static int methods,calls,arguments;
 static final List<String> errors=new ArrayList<>();
 static boolean ref(String s){return s.startsWith("L")||s.startsWith("[");}
 static ClassDef def(String type){ClassDef d=classes.get(type);return d!=null?d:provider.getClassDef(type);}
 static boolean assignable(String target,String source,Set<String> seen){
  if(target.equals(source)||target.equals("Ljava/lang/Object;"))return true;
  if(!seen.add(source))return false;
  if(source.startsWith("[")){
   if(target.equals("Ljava/lang/Cloneable;")||target.equals("Ljava/io/Serializable;"))return true;
   return target.startsWith("[")&&ref(target.substring(1))&&ref(source.substring(1))&&assignable(target.substring(1),source.substring(1),seen);
  }
  ClassDef c=def(source);
  if(c==null)throw new IllegalStateException("Missing type hierarchy: "+source);
  for(String it:c.getInterfaces())if(assignable(target,it,new HashSet<>(seen)))return true;
  return c.getSuperclass()!=null&&assignable(target,c.getSuperclass(),seen);
 }
 static void check(Method m,AnalyzedInstruction i,int reg,String expected,String call){
  if(!ref(expected))return;
  arguments++;
  RegisterType actual=i.getPreInstructionRegisterType(reg);
  if(actual.category==RegisterType.NULL)return;
  if(actual.type==null||!assignable(expected,actual.type.getType(),new HashSet<String>()))
   errors.add(m.getDefiningClass()+"->"+m.getName()+" #"+i.getInstructionIndex()+" v"+reg+" "+actual+" is not assignable to "+expected+" for "+call);
 }
 public static void main(String[] args)throws Exception{
  final URLClassLoader sdk=new URLClassLoader(new URL[]{new File(args[1]).toURI().toURL()});
  provider=new ClassProvider(){public ClassDef getClassDef(String type){
   try{return new ReflectionClassDef(Class.forName(type.substring(1,type.length()-1).replace('/','.'),false,sdk));}
   catch(ClassNotFoundException e){return null;}
  }};
  List<DexBackedDexFile> dexes=new ArrayList<>();
  try(ZipFile zip=new ZipFile(args[0])){
   for(ZipEntry entry:Collections.list(zip.entries()))if(entry.getName().matches("classes[0-9]*\\.dex")){
    DexBackedDexFile dex=DexBackedDexFile.fromInputStream(Opcodes.forApi(28),new BufferedInputStream(zip.getInputStream(entry)));
    dexes.add(dex);for(ClassDef c:dex.getClasses())classes.put(c.getType(),c);
   }
  }
  List<ClassProvider> providers=new ArrayList<>();for(DexBackedDexFile d:dexes)providers.add(new DexClassProvider(d));providers.add(provider);
  ClassPath cp=new ClassPath(providers,false,ClassPath.NOT_ART);
  int selected=0;
  Set<String> nativeHooks=new HashSet<>(Arrays.asList("Lb72;","Lda1;","Lrt;","Ldm5;","Li21;","Lfd2;","Lzl5;","Lt10;","Lm10;","Lk7;"));
  Set<String> visualHooks=new HashSet<>(Arrays.asList("Lxq0;","Lz55;"));
  Map<String,List<String>> protocolMethods=new HashMap<>();
  protocolMethods.put("Lhz3;",Arrays.asList("f"));
  protocolMethods.put("Lpg1;",Arrays.asList("q"));
  protocolMethods.put("Lcb4;",Arrays.asList("c","k","sipApplyRefreshResponse"));
  protocolMethods.put("Lo82;",Arrays.asList("a","h","r","v","y"));
  protocolMethods.put("Lbh1;",Arrays.asList("q"));
  protocolMethods.put("Lyz;",Arrays.asList("d","e","f","g"));
  protocolMethods.put("Lsj5;",Arrays.asList("l"));
  protocolMethods.put("Lau0;",Arrays.asList("e"));
  protocolMethods.put("Lk10;",Arrays.asList("b","h"));
  protocolMethods.put("Lcc/forserein/simhub/internal/WifiConfigEditor;",Arrays.asList("finish","stageCallback","smsCenterEntry"));
  protocolMethods.put("Lmc0;",Arrays.asList("d"));
  protocolMethods.put("Lej;",Arrays.asList("a"));
  protocolMethods.put("Liz3;",Arrays.asList("s"));
  protocolMethods.put("Lcc/forserein/simhub/vowifi/calling/CallActionReceiver;",Arrays.asList("onReceive"));
  protocolMethods.put("Lcc/forserein/simhub/ui/call/CallActivity;",Arrays.asList("onCreate","onNewIntent","i"));
  Set<String> protocolHelpers=new HashSet<>(Arrays.asList("Lcc/forserein/simhub/internal/EapIdentityLog;","Lcc/forserein/simhub/internal/EapIdentityReplay;","Lcc/forserein/simhub/internal/AmrFraming;","Lcc/forserein/simhub/internal/RegistrationTiming;","Lcc/forserein/simhub/internal/DiagnosticShareSanitizer;","Lcc/forserein/simhub/internal/ReaderWifiPresentation;","Lcc/forserein/simhub/internal/DitoCarrierProfile;","Lcc/forserein/simhub/internal/CarrierPresets;"));
  Set<String> verifiedProtocolMethods=new HashSet<>();
  for(ClassDef c:classes.values())if(c.getType().startsWith("LInternalSim") || c.getType().startsWith("LInternalEstk") || c.getType().startsWith("Lcc/forserein/simhub/internal/EstkSwitchPlan") || nativeHooks.contains(c.getType()) || visualHooks.contains(c.getType()) || protocolMethods.containsKey(c.getType()) || protocolHelpers.contains(c.getType()) || c.getType().startsWith("Lcc/forserein/simhub/internal/CallNotificationGuard") || c.getType().startsWith("Lcc/forserein/simhub/internal/SipForkProtection") || c.getType().startsWith("Lcc/forserein/simhub/internal/DitoHomeIdentity") || c.getType().startsWith("Lcc/forserein/simhub/internal/IdentityBinding") || c.getType().startsWith("Lcc/forserein/simhub/internal/WifiConfigRuntime")){
   selected++;
   for(Method m:c.getMethods())if(m.getImplementation()!=null){
    boolean protocol=protocolMethods.containsKey(c.getType())&&protocolMethods.get(c.getType()).contains(m.getName());
    if(c.getType().equals("Lfd2;")&&m.getName().equals("readerWifiFlag"))protocol=true;
    if(protocolMethods.containsKey(c.getType())&&!protocol)continue;
    if(protocol)verifiedProtocolMethods.add(c.getType()+"->"+m.getName());
    if(c.getType().equals("Lxq0;")&&!Arrays.asList("a","b","simhubPrimary").contains(m.getName()))continue;
    if(c.getType().equals("Lz55;")&&!m.getName().equals("<clinit>"))continue;
    if(c.getType().equals("Lzl5;")&&!Arrays.asList("b","d","g","q","y","z").contains(m.getName()))continue;
    if(nativeHooks.contains(c.getType())&&!protocol){
     boolean hooked=false;
     for(Instruction ins:m.getImplementation().getInstructions())if(ins instanceof ReferenceInstruction){
      Reference r=((ReferenceInstruction)ins).getReference();
      if(r instanceof MethodReference && ((MethodReference)r).getDefiningClass().startsWith("Lcc/forserein/simhub/internal/"))hooked=true;
     }
     if(!hooked)continue;
    }
    methods++;
    MethodAnalyzer analyzer=new MethodAnalyzer(cp,m,null,false);
    if(analyzer.getAnalysisException()!=null)throw analyzer.getAnalysisException();
    for(AnalyzedInstruction i:analyzer.getAnalyzedInstructions()){
     Instruction ins=i.getInstruction();
     if(!(ins instanceof ReferenceInstruction))continue;
     Reference reference=((ReferenceInstruction)ins).getReference();
     if(!(reference instanceof MethodReference)||!ins.getOpcode().name.startsWith("invoke-"))continue;
     MethodReference method=(MethodReference)reference;
     if(nativeHooks.contains(c.getType()) && !protocol && !method.getDefiningClass().startsWith("Lcc/forserein/simhub/internal/"))continue;
     int[] regs;
     if(ins instanceof FiveRegisterInstruction){FiveRegisterInstruction f=(FiveRegisterInstruction)ins;int[] all={f.getRegisterC(),f.getRegisterD(),f.getRegisterE(),f.getRegisterF(),f.getRegisterG()};regs=Arrays.copyOf(all,f.getRegisterCount());}
     else if(ins instanceof RegisterRangeInstruction){RegisterRangeInstruction f=(RegisterRangeInstruction)ins;regs=new int[f.getRegisterCount()];for(int n=0;n<regs.length;n++)regs[n]=f.getStartRegister()+n;}
     else throw new IllegalStateException("Unsupported invoke instruction");
     boolean isStatic=ins.getOpcode().name.startsWith("invoke-static");
     int n=0;
     if(!isStatic)check(m,i,regs[n++],method.getDefiningClass(),method.toString());
     for(CharSequence p:method.getParameterTypes()){
      String type=p.toString();check(m,i,regs[n],type,method.toString());n+=(type.equals("J")||type.equals("D"))?2:1;
     }
     if(n!=regs.length)throw new IllegalStateException("Argument width mismatch: "+method);
     calls++;
    }
   }
  }
  for(Map.Entry<String,List<String>> entry:protocolMethods.entrySet())for(String method:entry.getValue())
   if(!verifiedProtocolMethods.contains(entry.getKey()+"->"+method))throw new IllegalStateException("Protocol verification target missing: "+entry.getKey()+"->"+method);
  for(String required:Arrays.asList("LInternalSimChannelContinuation;","LInternalSimProfileUi;",
      "LInternalSimReaderTask;","LInternalSimConnectContinuation;","LInternalSimProfileState;",
      "LInternalSimChannelDispatch;","Lrt;","Ldm5;"))
   if(!classes.containsKey(required))throw new IllegalStateException("Patch adapter missing: "+required);
  for(String error:errors)System.out.println("TYPE ERROR: "+error);
  System.out.println("DEX TYPE ANALYSIS: classes="+selected+" methods="+methods+" invokes="+calls+" reference_arguments="+arguments+" errors="+errors.size());
  if(!errors.isEmpty())System.exit(1);
 }
}
