import java.util.List;

/** Exercise overlapping local release operations through the native dialog manager. */
final class HangupIdempotenceProbe {
    private static int checks;

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
        checks++;
    }

    private static List<?> actions(InviteFinalProbe.Call call, String method, double at)
            throws Exception {
        return (List<?>) SipForkProbe.call(call.s.m, method,
                new Class<?>[]{String.class, double.class}, InviteFinalProbe.CALL_ID, at);
    }

    private static void end(InviteFinalProbe.Call call, double at) throws Exception {
        SipForkProbe.call(call.s.e, "k", new Class<?>[]{List.class}, actions(call, "j", at));
    }

    private static String method(InviteFinalProbe.Call call, int index) throws Exception {
        return (String) SipForkProbe.get(call.s.packets().get(index), "b");
    }

    private static void outgoing(boolean previous, boolean provisional, boolean answered)
            throws Exception {
        InviteFinalProbe.Call call = new InviteFinalProbe.Call();
        if (provisional) call.response(180, "Ringing", 11, "INVITE", InviteFinalProbe.BRANCH, "A");
        if (answered) call.selected();
        call.sink.events.clear();
        end(call, 15.0);
        int packets = call.s.packets().size();
        check(packets == (provisional ? 1 : 0), "first local release handled");
        if (provisional) check(method(call, 0).equals(answered ? "BYE" : "CANCEL"), "first method");
        check(call.sink.events.size() == 1, "native end event delivered once");
        end(call, 17.0);
        check(call.sink.events.size() == (previous ? 2 : 1), "duplicate has no new end event");
        check(((Double) SipForkProbe.get(call.s.d, "A")) == (previous ? 17.0 : 15.0),
                "duplicate does not restart cleanup timeout");
        check(call.s.packets().size() == packets + (previous && provisional ? 1 : 0),
                "no extra CANCEL on repeated local release");
        if (previous && provisional) check("CANCEL".equals(method(call, packets)), "old extra CANCEL");
        if (!provisional) {
            call.response(100, "Trying", 11, "INVITE", InviteFinalProbe.BRANCH, null);
            check(call.s.packets().size() == 1 && "CANCEL".equals(method(call, 0)),
                    "original deferred cancellation fires on first provisional");
        }
    }

    private static void decline(boolean previous) throws Exception {
        InviteFinalProbe.Call call = new InviteFinalProbe.Call();
        SipForkProbe.set(call.s.d, "a", SipForkProbe.direction.getField("T").get(null));
        List<?> first = actions(call, "g", 18.0);
        check(first.size() == 2, "first decline sends 603 and emits end event");
        check((Integer) SipForkProbe.get(SipForkProbe.get(first.get(0), "a"), "d") == 603,
                "first decline retains original network status");
        check(actions(call, "g", 19.0).size() == (previous ? 2 : 0), "duplicate explicit decline");
        check(actions(call, "j", 20.0).size() == (previous ? 2 : 0), "hangup after decline");
        check(((Double) SipForkProbe.get(call.s.d, "A")) == (previous ? 20.0 : 18.0),
                "first decline owns cleanup deadline");
    }

    static int run(boolean previous) throws Exception {
        checks = 0;
        outgoing(previous, false, false);
        outgoing(previous, true, false);
        outgoing(previous, true, true);
        decline(previous);
        return checks;
    }
}
