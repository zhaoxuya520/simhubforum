import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/** Replay actual outgoing-call selection, user CANCEL and final INVITE response retransmissions. */
public final class InviteSuccessProbe {
  private static boolean previous;
  private static int checks;

  private static void check(boolean value, String label) {
    if (!value) throw new AssertionError(label);
    checks++;
  }

  static Object get(Object target, String name) throws Exception {
    return SipForkProbe.get(target, name);
  }

  static Object parse(byte[] wire) throws Exception {
    Object message = Class.forName("jb4").getMethod("c", byte[].class).invoke(null, (Object) wire);
    check(message != null, "real SIP parser recognized packet");
    return message;
  }

  static byte[] wire(Object message) throws Exception {
    return (byte[]) SipForkProbe.call(message, "b", new Class<?>[0]);
  }

  static byte[] success(InviteFinalProbe.Call call, String tag) throws Exception {
    Object response =
        call.s.response(
            tag,
            tag.equals("A") ? SipForkProbe.A : SipForkProbe.B,
            "sip:leg-" + tag + "@example.invalid",
            "sip:proxy-" + tag + ".example.invalid;lr",
            false);
    SipForkProbe.header(response, "Via", InviteFinalProbe.via(InviteFinalProbe.BRANCH));
    return wire(response);
  }

  static boolean receive(InviteFinalProbe.Call call, byte[] packet) throws Exception {
    return call.s.accept(parse(packet));
  }

  static boolean reply(InviteFinalProbe.Call call, Object request) throws Exception {
    Object message = SipForkProbe.message(false, "", 200, "");
    for (String header : new String[] {"Via", "Call-ID", "From", "To", "CSeq"}) {
      String value = SipForkProbe.first(request, header);
      if (header.equals("To") && !value.contains(";tag=")) value += ";tag=A";
      SipForkProbe.header(message, header, value);
    }
    return receive(call, wire(message));
  }

  static void hangUp(InviteFinalProbe.Call call, String expectedMethod) throws Exception {
    int start = call.s.packets().size();
    Object actions =
        SipForkProbe.call(
            call.s.m,
            "j",
            new Class<?>[] {String.class, double.class},
            InviteFinalProbe.CALL_ID,
            12.0);
    SipForkProbe.call(call.s.e, "k", new Class<?>[] {List.class}, actions);
    check(
        call.s.packets().size() == start + 1
            && expectedMethod.equals(get(call.s.packets().get(start), "b")),
        "native hangup issues one " + expectedMethod);
  }

  static void packet(Object message, String method, String tag, int cseq) throws Exception {
    check(method.equals(get(message, "b")), method + " method");
    check((cseq + " " + method).equals(SipForkProbe.first(message, "CSeq")), method + " CSeq");
    check(
        (InviteFinalProbe.PEER + ";tag=" + tag).equals(SipForkProbe.first(message, "To")),
        method + " selected tag");
    check(
        InviteFinalProbe.CALL_ID.equals(SipForkProbe.first(message, "Call-ID")),
        method + " dialog reference");
    check(
        ("sip:leg-" + tag + "@example.invalid").equals(get(message, "c")),
        method + " correct leg target");
    check(
        SipForkProbe.first(message, "Route").contains("proxy-" + tag + ".example.invalid"),
        method + " correct leg route");
  }

  static void normal() throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    byte[] selected = success(call, "A");
    check(receive(call, selected) && call.live(), "first 200 establishes the outgoing call");
    check(
        call.s.packets().size() == 1 && get(call.s.d, "D") != null,
        "one native ACK and established timestamps");
    Object first = call.s.packets().get(0);
    packet(first, "ACK", "A", 11);
    int initialEvents = call.sink.events.size();
    check(initialEvents > 0, "connection events sent");
    SipForkProbe.Snapshot active = new SipForkProbe.Snapshot(call.s.d);
    check(receive(call, selected), "duplicate 200 consumed");
    check(
        call.live() && call.s.packets().size() == 2 && call.sink.events.size() == initialEvents,
        "selected-leg retransmission gets one ACK and no new lifecycle event");
    Object second = call.s.packets().get(1);
    packet(second, "ACK", "A", 11);
    boolean same = Arrays.equals(wire(first), wire(second));
    System.out.println("normal retransmission ACK wire identical=" + same);
    check(same != previous, "repeat positive ACK with the original fields");
    if (!previous) active.unchanged("exact duplicate leaves selected dialog untouched");
    int start = call.s.packets().size();
    byte[] fork = success(call, "B");
    check(
        receive(call, fork) && call.s.packets().size() == start + 2,
        "other accepted leg sends ACK and BYE");
    packet(call.s.packets().get(start), "ACK", "B", 11);
    packet(call.s.packets().get(start + 1), "BYE", "B", 12);
    check(call.live() && "A".equals(get(call.s.d, "l")), "other leg cleanup leaves selected A");
  }

  static void duplicateAfterUpdate() throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    byte[] selected = success(call, "A");
    receive(call, selected);
    Object first = call.s.packets().get(0);
    Object local =
        Class.forName("x82")
            .getConstructor(byte[].class)
            .newInstance((Object) new byte[] {(byte) 192, 0, 2, 1});
    Object codecs = Class.forName("vk").getField("c").get(null);
    Object responder =
        Class.forName("pu")
            .getConstructor(Object.class, int.class, Object.class, int.class)
            .newInstance(local, 45000, codecs, 11);
    SipForkProbe.set(call.s.m, "b", responder);
    Object update = SipForkProbe.followup(true, "UPDATE", "A", 0, 99, false);
    SipForkProbe.set(update, "g", SipForkProbe.B.getBytes(StandardCharsets.US_ASCII));
    SipForkProbe.header(update, "Content-Type", "application/sdp");
    SipForkProbe.header(update, "Contact", "<sip:leg-A@example.invalid>");
    SipForkProbe.incoming(call.s, parse(wire(update)));
    boolean revised =
        Arrays.equals(
            (byte[]) get(call.s.d, "p"), SipForkProbe.B.getBytes(StandardCharsets.US_ASCII));
    System.out.println(
        "in-dialog UPDATE provided new SDP=" + revised + " events=" + call.sink.events.size());
    check(revised, "native UPDATE applied revised media");
    int start = call.s.packets().size(), events = call.sink.events.size();
    receive(call, selected);
    boolean stayed =
        Arrays.equals(
            (byte[]) get(call.s.d, "p"), SipForkProbe.B.getBytes(StandardCharsets.US_ASCII));
    System.out.println("old initial 200 after in-dialog UPDATE preserves revised SDP=" + stayed);
    check(
        stayed != previous, "retransmitted original response must not roll back negotiated media");
    check(call.s.packets().size() == start + 1, "one selected ACK after media revision");
    if (!previous)
      check(
          Arrays.equals(wire(first), wire(call.s.packets().get(start)))
              && events == call.sink.events.size(),
          "acknowledge exact initial 200 without repeating media setup");
  }

  static void newForkDuringCancellation() throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    call.response(180, "Ringing", 11, "INVITE", InviteFinalProbe.BRANCH, "A");
    hangUp(call, "CANCEL");
    reply(call, call.s.packets().get(0));
    byte[] selected = success(call, "A");
    receive(call, selected);
    int start = call.s.packets().size();
    receive(call, success(call, "B"));
    String retainedTag = (String) get(call.s.d, "l");
    System.out.println(
        "second 200 with different tag while terminating A retained leg=" + retainedTag);
    check(call.s.packets().size() == start + 2, "late accepted leg B receives ACK and BYE");
    check(
        "ACK".equals(get(call.s.packets().get(start), "b"))
            && SipForkProbe.first(call.s.packets().get(start), "To").endsWith("tag=B")
            && "BYE".equals(get(call.s.packets().get(start + 1), "b"))
            && SipForkProbe.first(call.s.packets().get(start + 1), "To").endsWith("tag=B"),
        "additional ACK and BYE both address B");
    check((previous ? "B" : "A").equals(retainedTag), "preserve terminating selected leg A");
    if (!previous) {
      reply(call, call.s.packets().get(start + 1));
      check(call.live(), "secondary BYE completion leaves selected A pending");
      reply(call, call.s.packets().get(2));
      check(!call.live(), "only selected BYE confirmation removes A");
    }
  }

  static void cancellationRace() throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    call.response(180, "Ringing", 11, "INVITE", InviteFinalProbe.BRANCH, "A");
    hangUp(call, "CANCEL");
    reply(call, call.s.packets().get(0));
    byte[] selected = success(call, "A");
    check(
        receive(call, selected) && call.s.packets().size() == 3,
        "late 200 after CANCEL gets ACK and BYE");
    Object first = call.s.packets().get(1), bye = call.s.packets().get(2);
    packet(first, "ACK", "A", 11);
    packet(bye, "BYE", "A", 12);
    check(call.live(), "awaiting BYE final");
    int events = call.sink.events.size();
    check(receive(call, selected), "pre-removal 200 retransmission consumed");
    int beforeReply = call.s.packets().size();
    System.out.println(
        "cancel race before BYE final sends " + (beforeReply - 3) + " additional requests");
    check(beforeReply == (previous ? 5 : 4), "retransmitted selected 200 before BYE completion");
    packet(call.s.packets().get(3), "ACK", "A", 11);
    if (previous) {
      check("BYE".equals(get(call.s.packets().get(4), "b")), "24.2 repeats BYE");
    } else {
      check(
          Arrays.equals(wire(first), wire(call.s.packets().get(3))),
          "terminating dialog reuses native ACK");
      check(
          events == call.sink.events.size(),
          "no extra lifecycle events while termination is pending");
    }
    reply(call, bye);
    check(!call.live(), "BYE final removed the call");
    events = call.sink.events.size();
    boolean consumed = receive(call, selected);
    System.out.println(
        "removed call consumed retransmitted 200="
            + consumed
            + " additional requests="
            + (call.s.packets().size() - beforeReply));
    check(
        consumed != previous && call.s.packets().size() == beforeReply + (previous ? 0 : 1),
        "after dialog removal the accepted transaction can acknowledge retransmission");
    if (!previous)
      check(
          Arrays.equals(wire(first), wire(call.s.packets().get(beforeReply))),
          "ACK bytes after dialog removal");
    check(
        !call.live() && events == call.sink.events.size(),
        "retransmission leaves call removed and silent");
  }

  static void firstSendFailure(String method) throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    call.response(180, "Ringing", 11, "INVITE", InviteFinalProbe.BRANCH, "A");
    hangUp(call, "CANCEL");
    reply(call, call.s.packets().get(0));
    call.s.packets().clear();
    SipForkProbe.attempts.clear();
    if (method.equals("ACK")) SipForkProbe.failAck = 1;
    else SipForkProbe.failBye = 1;
    byte[] selected = success(call, "A");
    try {
      receive(call, selected);
    } catch (java.lang.reflect.InvocationTargetException expected) {
    }
    int firstSent = call.s.packets().size();
    check(firstSent == (method.equals("ACK") ? 0 : 1), "failed native send observed");
    byte[] firstBye = method.equals("BYE") ? wire(SipForkProbe.attempts.get(1)) : null;
    receive(call, selected);
    int count = 0;
    Object deliveredBye = null;
    for (Object sent : call.s.packets())
      if ("BYE".equals(get(sent, "b"))) {
        count++;
        deliveredBye = sent;
      }
    check(count == 1, "transport recovery delivers one necessary BYE after " + method + " failed");
    if (!previous && firstBye != null)
      check(
          Arrays.equals(firstBye, wire(deliveredBye)),
          "retry keeps the same logical BYE transaction");
    System.out.println("first " + method + " send failure, recovered delivered BYEs=" + count);
  }

  static void repeatedByeFailure() throws Exception {
    InviteFinalProbe.Call c = new InviteFinalProbe.Call();
    c.response(180, "Ringing", 11, "INVITE", InviteFinalProbe.BRANCH, "A");
    hangUp(c, "CANCEL");
    reply(c, c.s.packets().get(0));
    c.s.packets().clear();
    SipForkProbe.attempts.clear();
    c.sink.events.clear();
    SipForkProbe.failBye = 10;
    byte[] selected = success(c, "A");
    for (int i = 0; i < 4; i++) {
      try {
        receive(c, selected);
      } catch (java.lang.reflect.InvocationTargetException expected) {
      }
    }
    int byes = 0;
    Object first = null, last = null;
    for (Object packet : SipForkProbe.attempts)
      if ("BYE".equals(get(packet, "b"))) {
        byes++;
        if (first == null) first = packet;
        last = packet;
      }
    int ended = 0;
    for (Object e : c.sink.events) if ("eb4".equals(e.getClass().getName())) ended++;
    check(
        byes == (previous ? 4 : 2) && c.s.packets().size() == 4,
        "persistent send failure bounds attempts while accepting duplicates");
    check(
        ended == (previous ? 0 : 1),
        "release delivers local termination once after repeated send failure");
    if (!previous) {
      check(first == last, "failed Bye retry keeps exact original request");
      Class<?> helper = Class.forName("cc.forserein.simhub.internal.SipInviteSuccess");
      Map<?, ?> cache = (Map<?, ?>) declared(helper, "CACHE").get(null);
      Object bucket = cache.get(c.s.e);
      Object entry = ((Map<?, ?>) declared(bucket, "acks").get(bucket)).values().iterator().next();
      check(
          declared(entry, "pending").get(entry) == null,
          "original action batch released after exhausting transmissions");
    }
    System.out.println(
        "persistent BYE send failure: attempted=" + byes + " local release events=" + ended);
  }

  static void transactionMismatch(String header, String value) throws Exception {
    InviteFinalProbe.Call c = new InviteFinalProbe.Call();
    c.response(183, "Session Progress", 11, "INVITE", InviteFinalProbe.BRANCH, "A");
    Object old = parse(success(c, "A"));
    SipForkProbe.call(old, "i", new Class<?>[] {String.class, String.class}, header, value);
    receive(c, wire(old));
    boolean confirmed = get(c.s.d, "D") != null;
    System.out.println(
        "earlier 200 with different " + header + " confirmed current call=" + confirmed);
    check(
        confirmed == previous && c.s.packets().size() == (previous ? 1 : 0),
        "unmatched final cannot select current attempt");
    if (!previous) {
      receive(c, success(c, "A"));
      check(
          get(c.s.d, "D") != null && c.s.packets().size() == 1,
          "first matched 200 after 183 still establishes A");
    }
  }

  static Field declared(Object owner, String name) throws Exception {
    Class<?> type = owner instanceof Class ? (Class<?>) owner : owner.getClass();
    Field f = type.getDeclaredField(name);
    f.setAccessible(true);
    return f;
  }

  static void cacheLifetime() throws Exception {
    InviteFinalProbe.Call c = new InviteFinalProbe.Call();
    byte[] selected = success(c, "A");
    receive(c, selected);
    Object first = c.s.packets().get(0);
    byte[] original = wire(first);
    SipForkProbe.header(first, "X-Fixture", "isolated local mutation");
    SipForkProbe.set(first, "g", new byte[] {1});
    receive(c, selected);
    check(
        Arrays.equals(original, wire(c.s.packets().get(1))),
        "downstream packet edits never alter retained ACK");
    Class<?> helper = Class.forName("cc.forserein.simhub.internal.SipInviteSuccess");
    Map<?, ?> cache = (Map<?, ?>) declared(helper, "CACHE").get(null);
    Object bucket = cache.get(c.s.e);
    Map<?, ?> acks = (Map<?, ?>) declared(bucket, "acks").get(bucket);
    Object entry = acks.values().iterator().next();
    Field created = declared(entry, "created");
    long older = System.nanoTime() - 33_000_000_000L;
    created.setLong(entry, older);
    receive(c, selected);
    check(
        Arrays.equals(original, wire(c.s.packets().get(2))) && created.getLong(entry) == older,
        "live dialog retains initial ACK without renewing entry lifetime");
    hangUp(c, "BYE");
    reply(c, c.s.packets().get(3));
    int sent = c.s.packets().size();
    check(
        !receive(c, selected) && c.s.packets().size() == sent && acks.isEmpty(),
        "expired removed transaction is forgotten");
    c = new InviteFinalProbe.Call();
    selected = success(c, "A");
    receive(c, selected);
    hangUp(c, "BYE");
    reply(c, c.s.packets().get(1));
    InviteFinalProbe.Call replacement = new InviteFinalProbe.Call();
    ((Map<?, ?>) get(replacement.s.m, "e")).clear();
    SipForkProbe.set(c.s.e, "J", replacement.s.m);
    sent = c.s.packets().size();
    check(
        !receive(c, selected) && c.s.packets().size() == sent,
        "new registration manager has no old ACKs");
  }

  public static void main(String[] args) throws Exception {
    previous = args[0].equals("previous-24-2");
    SipForkProbe.msg = Class.forName("kb4");
    SipForkProbe.dialog = Class.forName("ma4");
    SipForkProbe.manager = Class.forName("cb4");
    SipForkProbe.direction = Class.forName("ga4");
    SipForkProbe.state = Class.forName("la4");
    SipForkProbe.helper = Class.forName("cc.forserein.simhub.internal.SipForkProtection");
    normal();
    cancellationRace();
    duplicateAfterUpdate();
    newForkDuringCancellation();
    firstSendFailure("ACK");
    firstSendFailure("BYE");
    repeatedByeFailure();
    transactionMismatch("CSeq", "10 INVITE");
    transactionMismatch("Via", InviteFinalProbe.via(InviteFinalProbe.OLD_BRANCH));
    transactionMismatch("From", InviteFinalProbe.LOCAL.replace("local-tag", "earlier-local-tag"));
    if (!previous) cacheLifetime();
    checks += HangupIdempotenceProbe.run(previous);
    System.out.println("NATIVE_INVITE_SUCCESS mode=" + args[0] + " checks=" + checks);
  }
}
