/** Runtime microphone permission boundary. */
public class xz {public static boolean permitted=true;public static boolean a(android.content.Context context){return permitted;}}
