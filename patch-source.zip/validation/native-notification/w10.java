/** Native ringtone side-effect boundary double. */
public class w10 {public static int stops;public static void b(){stops++;}}
