/** Compose theme setup boundary, after native notification dispatch. */
public class he2 {public static eg I(android.content.Context context){return null;}}
