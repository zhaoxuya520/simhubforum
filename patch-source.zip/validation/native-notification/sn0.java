/** Stop before unrelated Compose rendering; actual CallActivity.onCreate dispatch already ran. */
public class sn0 {
 public static class UiBoundary extends RuntimeException {private static final long serialVersionUID=1L;}
 public static void a(rn0 activity,zn0 content){throw new UiBoundary();}
}
