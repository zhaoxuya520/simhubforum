import java.io.*;import java.nio.file.*;import java.util.*;import java.util.zip.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.util.*;
/** JVM-only fixture: bypass Android/coroutine singleton bootstrap; all controller methods stay APK bytecode. */
public final class PrepareNativeController {
 static String fingerprint(ClassNode node){
  StringWriter result=new StringWriter();PrintWriter writer=new PrintWriter(result);
  for(MethodNode m:node.methods)if(Arrays.asList("b","h","j","e","l","p").contains(m.name)){
   writer.println(m.name+m.desc);Textifier text=new Textifier();m.accept(new TraceMethodVisitor(text));text.print(writer);
  }
  writer.flush();return result.toString();
 }
 public static void main(String[] args)throws Exception{
  try(ZipFile input=new ZipFile(args[0]);ZipOutputStream output=new ZipOutputStream(Files.newOutputStream(Paths.get(args[1])))){
   boolean changed=false;
   for(ZipEntry entry:Collections.list(input.entries())){
    byte[] bytes=input.getInputStream(entry).readAllBytes();
    if(entry.getName().equals("k10.class")){
     ClassNode node=new ClassNode();new ClassReader(bytes).accept(node,0);String before=fingerprint(node);
     for(MethodNode m:node.methods)if(m.name.equals("<clinit>")){
      m.instructions.clear();m.instructions.add(new InsnNode(Opcodes.RETURN));m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.maxLocals=0;m.maxStack=0;changed=true;
     }
     if(!changed)throw new AssertionError("native controller initializer not found");
     ClassWriter writer=new ClassWriter(0);node.accept(writer);bytes=writer.toByteArray();
     ClassNode reparsed=new ClassNode();new ClassReader(bytes).accept(reparsed,0);
     if(!before.equals(fingerprint(reparsed)))throw new AssertionError("controller method bytecode changed");
    }
    output.putNextEntry(new ZipEntry(entry.getName()));output.write(bytes);output.closeEntry();
   }
   if(!changed)throw new AssertionError("native controller absent");
  }
  System.out.println("NATIVE_CONTROLLER_ADAPTER only_static_initializer_replaced=true b_h_j_e_l_p_preserved=true");
 }
}
