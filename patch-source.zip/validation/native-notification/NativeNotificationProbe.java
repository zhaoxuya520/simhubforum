import android.content.*;
import cc.forserein.simhub.vowifi.calling.CallActionReceiver;
import cc.forserein.simhub.ui.call.CallActivity;
/** Executes actual receiver bytecode against synthetic call state and Android API fixtures. */
public final class NativeNotificationProbe {
 static int checks;
 static final String PREFIX="cc.forserein.simhub.call.";
 static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
 static u00 call(String id,String token,b10 state,boolean incoming){return new u00(id,"+100","Synthetic call",incoming,state,null,0L,false,"",token,false,false);}
 static Intent intent(String action,u00 call){return new Intent().setAction(PREFIX+action).putExtra("simhub.call.id",call.a).putExtra("simhub.call.token",call.j);}
 static void receiverLegacy(){
  CallActionReceiver receiver=new CallActionReceiver();Context context=new Context();
  u00 first=call("call-A","token-A",z00.a,true),second=call("call-B","token-B",z00.a,true);
  k10.current=first;Intent staleDecline=intent("DECLINE",first),staleHangup=intent("HANGUP",first);
  k10.current=second;k10.reset();receiver.onReceive(context,staleDecline);
  check(k10.declines==1,"legacy receiver executes old decline against current call");
  check("token-B".equals(k10.lastTarget),"old call A decline actually reaches new call B");
  check(w10.stops==1,"legacy stale decline stops current ringtone");
  k10.reset();receiver.onReceive(context,staleHangup);
  check(k10.hangups==1&&"token-B".equals(k10.lastTarget),"old call A hangup actually reaches new call B");
  k10.reset();receiver.onReceive(context,new Intent().setAction(PREFIX+"DECLINE"));
  check(k10.declines==1,"legacy unbound notification also operates current call");
 }
 static CallActivity activity(Intent intent){
  try {
   java.lang.reflect.Field field=sun.misc.Unsafe.class.getDeclaredField("theUnsafe");field.setAccessible(true);
   CallActivity activity=(CallActivity)((sun.misc.Unsafe)field.get(null)).allocateInstance(CallActivity.class);
   field=CallActivity.class.getField("n0");field.setAccessible(true);field.set(activity,new b4());activity.setIntent(intent);return activity;
  } catch(Exception e){throw new AssertionError(e);}
 }
 static void activityLegacy(){
  u00 first=call("call-A","token-A",z00.a,true),second=call("call-B","token-B",z00.a,true);
  Intent staleAnswer=intent("ANSWER",first);k10.current=second;k10.reset();xz.permitted=true;
  CallActivity activity=activity(staleAnswer);activity.onNewIntent(staleAnswer);
  check(k10.answers==1&&"token-B".equals(k10.lastTarget),"native onNewIntent stale A answer reaches B");
  k10.reset();activity=activity(staleAnswer);
  try{activity.onCreate(null);throw new AssertionError("expected Compose boundary");}catch(sn0.UiBoundary expected){}
  check(k10.answers==1&&"token-B".equals(k10.lastTarget),"native onCreate stale A answer reaches B");
  k10.current=first;k10.reset();xz.permitted=false;activity=activity(staleAnswer);activity.onNewIntent(staleAnswer);
  check(activity.o0&&activity.n0.launches==1,"actual native answer launches microphone permission request");
  k10.current=second;
  try {
   java.lang.reflect.Field uf=sun.misc.Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);
   au0 callback=(au0)((sun.misc.Unsafe)uf.get(null)).allocateInstance(au0.class);
   java.lang.reflect.Field field=au0.class.getField("T");field.setAccessible(true);field.setInt(callback,2);
   field=au0.class.getField("U");field.setAccessible(true);field.set(callback,activity);
   callback.e(Boolean.TRUE);
  } catch(Exception e){throw new AssertionError(e);}
  check(k10.answers==1&&"token-B".equals(k10.lastTarget),"deferred old call A microphone result answers new call B");
  xz.permitted=true;
 }
 static Object guard(String method,Class<?>[] signature,Object...arguments){
  try{return Class.forName("cc.forserein.simhub.internal.CallNotificationGuard").getMethod(method,signature).invoke(null,arguments);}
  catch(java.lang.reflect.InvocationTargetException e){Throwable cause=e.getCause();if(cause instanceof Error)throw(Error)cause;throw new AssertionError(cause);}
  catch(Exception e){throw new AssertionError(e);}
 }
 static Intent bound(String action,u00 call){Intent result=new Intent().setAction(PREFIX+action);guard("bind",new Class<?>[]{Intent.class,Object.class},result,call);return result;}
 static boolean allows(Intent intent,u00 call){return(Boolean)guard("allows",new Class<?>[]{Intent.class,Object.class},intent,call);}
 static void callback(CallActivity activity,Boolean granted){
  try {
   java.lang.reflect.Field uf=sun.misc.Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);
   au0 callback=(au0)((sun.misc.Unsafe)uf.get(null)).allocateInstance(au0.class);
   java.lang.reflect.Field field=au0.class.getField("T");field.setAccessible(true);field.setInt(callback,2);
   field=au0.class.getField("U");field.setAccessible(true);field.set(callback,activity);callback.e(granted);
  } catch(Exception e){throw new AssertionError(e);}
 }
 static void receiverCurrent(){
  CallActionReceiver receiver=new CallActionReceiver();Context context=new Context();
  u00 first=call("call-A","token-A",z00.a,true),second=call("call-B","token-B",z00.a,true);
  Intent decline=bound("DECLINE",first),hangup=bound("HANGUP",first);
  k10.current=second;k10.reset();receiver.onReceive(context,decline);
  check(k10.declines==0&&w10.stops==0,"stale decline cannot affect new call or ringtone");
  receiver.onReceive(context,hangup);check(k10.hangups==0,"stale hangup cannot affect new call");
  receiver.onReceive(context,new Intent().setAction(PREFIX+"DECLINE"));check(k10.declines==0&&w10.stops==0,"legacy unbound decline rejected");
  k10.current=first;receiver.onReceive(context,decline);check(k10.declines==1&&"token-A".equals(k10.lastTarget)&&w10.stops==1,"matching incoming decline reaches selected call and stops ringtone once");
  k10.reset();k10.current=call(first.a,first.j,v00.a,true);receiver.onReceive(context,decline);check(k10.declines==0&&w10.stops==0,"incoming decline cannot affect now-active call");
  b10[] hangupStates={x00.a,w00.a,a10.a,v00.a};
  for(b10 state:hangupStates){k10.reset();k10.current=call(first.a,first.j,state,false);receiver.onReceive(context,hangup);check(k10.hangups==1&&first.j.equals(k10.lastTarget),"matching outgoing/active hangup: "+state);}
  for(b10 state:new b10[]{z00.a,new y00("ended")}){k10.reset();k10.current=call(first.a,first.j,state,true);receiver.onReceive(context,hangup);check(k10.hangups==0,"hangup rejected for wrong phase: "+state);}
  k10.current=first;k10.reset();k10.replaceOnCommand=second;receiver.onReceive(context,decline);check(k10.declines==0&&w10.stops==0,"second snapshot validation blocks replacement between dispatch and command");
  k10.reset();k10.current=second;k10.e();check(k10.declines==1&&second.j.equals(k10.lastTarget),"unscoped native control remains enabled after scoped rejection");
 }
 static void identity(){
  u00 first=call("call-A","token-A",z00.a,true);Intent answer=bound("ANSWER",first);
  check(allows(answer,first),"exact call identity allowed");
  check(!allows(answer,call("call-A","token-B",z00.a,true)),"same SIP id with new per-call token rejected");
  check(!allows(answer,call("call-B","token-A",z00.a,true)),"same token with different SIP id rejected");
  check(!allows(answer,call("call-A","token-A",z00.a,false)),"answer rejects outgoing direction");
  check(!allows(answer,call("call-A","token-A",v00.a,true)),"answer rejects already active state");
  check(!allows(answer,null),"answer rejects absent current call");
  Intent missingId=new Intent(answer);missingId.removeExtra("simhub.call.id");check(!allows(missingId,first),"missing id rejected");
  Intent missingToken=new Intent(answer);missingToken.removeExtra("simhub.call.token");check(!allows(missingToken,first),"missing token rejected");
  check(!allows(new Intent(answer).putExtra("simhub.call.id",""),first),"empty id rejected");
  check(!allows(new Intent(answer).putExtra("simhub.call.token",""),first),"empty token rejected");
  Intent invalidated=new Intent(answer);guard("bind",new Class<?>[]{Intent.class,Object.class},invalidated,null);
  check(invalidated.getData()==null&&invalidated.getStringExtra("simhub.call.id")==null&&invalidated.getStringExtra("simhub.call.token")==null,"binding absent call clears any old identity");
  android.app.PendingIntent.reset();Context context=new Context();u00 second=call("call-B","token-B",z00.a,true);k10.current=second;
  Class<?>[] signature={int.class,Context.class,String.class,Object.class};
  android.app.PendingIntent a=(android.app.PendingIntent)guard("activityIntent",signature,21,context,PREFIX+"ANSWER",first);
  android.app.PendingIntent b=(android.app.PendingIntent)guard("activityIntent",signature,21,context,PREFIX+"ANSWER",second);
  check(a!=b&&!a.identity().equals(b.identity()),"same requestCode has distinct PendingIntent identity across calls");
  check(first.a.equals(a.intent().getStringExtra("simhub.call.id"))&&first.j.equals(a.intent().getStringExtra("simhub.call.token")),"rendered call snapshot survives a newer global call and UPDATE_CURRENT");
  check(second.a.equals(b.intent().getStringExtra("simhub.call.id")),"new pending intent binds new call");
  check(a==guard("activityIntent",signature,21,context,PREFIX+"ANSWER",first),"same-call update reuses same pending intent");
  check(a.intent().getData()!=null&&a.intent().getData().toString().startsWith("simhub-call://notification/"),"call identity encoded in PendingIntent data");
  android.app.PendingIntent shown=(android.app.PendingIntent)guard("activityIntent",signature,20,context,null,first);
  check((PREFIX+"SHOW").equals(shown.intent().getAction()),"ordinary notification opening retained");
  Intent oldFormatA=intent("ANSWER",first),oldFormatB=intent("ANSWER",second);
  android.app.PendingIntent oldA=android.app.PendingIntent.getActivity(context,21,oldFormatA,0x0c000000),oldB=android.app.PendingIntent.getActivity(context,21,oldFormatB,0x0c000000);
  check(oldA==oldB&&second.a.equals(oldA.intent().getStringExtra("simhub.call.id")),"fixture captures Android extras-excluded identity collision; extras-only fix would fail");
 }
 static void activityCurrent(){
  u00 first=call("call-A","token-A",z00.a,true),second=call("call-B","token-B",z00.a,true);Intent answer=bound("ANSWER",first);
  k10.current=second;k10.reset();xz.permitted=true;CallActivity activity=activity(answer);activity.onNewIntent(answer);
  check(k10.answers==0&&w10.stops==0,"native onNewIntent rejects stale notification before audio work");
  activity=activity(answer);try{activity.onCreate(null);throw new AssertionError("expected Compose boundary");}catch(sn0.UiBoundary expected){}
  check(k10.answers==0&&w10.stops==0,"native onCreate rejects stale notification before audio work");
  activity.onNewIntent(new Intent().setAction(PREFIX+"ANSWER"));check(k10.answers==0,"legacy unbound answer rejected");
  k10.current=first;activity.onNewIntent(answer);check(k10.answers==1&&first.j.equals(k10.lastTarget),"matching native onNewIntent answer accepted");
  k10.reset();activity=activity(answer);try{activity.onCreate(null);throw new AssertionError("expected Compose boundary");}catch(sn0.UiBoundary expected){}
  check(k10.answers==1&&first.j.equals(k10.lastTarget),"matching native onCreate answer accepted");
  k10.reset();activity=activity(bound("SHOW",first));activity.onNewIntent(bound("SHOW",first));check(k10.answers==0&&!activity.finished,"ordinary SHOW remains non-destructive");
  k10.reset();xz.permitted=false;activity=activity(answer);activity.onNewIntent(answer);check(activity.o0&&activity.n0.launches==1,"matching answer requests missing microphone permission");
  callback(activity,Boolean.TRUE);check(k10.answers==1&&first.j.equals(k10.lastTarget)&&!activity.o0,"matching permission grant answers original call");
  callback(activity,Boolean.TRUE);check(k10.answers==1,"repeated permission callback cannot answer twice");
  k10.reset();activity=activity(answer);activity.onNewIntent(answer);callback(activity,Boolean.FALSE);check(k10.answers==0&&!activity.o0,"permission denial never answers");
  callback(activity,Boolean.TRUE);check(k10.answers==0,"late duplicate grant after denial does not reuse cleared pending action");
  k10.reset();activity=activity(answer);activity.onNewIntent(answer);k10.current=second;callback(activity,Boolean.TRUE);
  check(k10.answers==0&&!activity.o0,"old call permission grant cannot answer replacement call");
  k10.current=first;k10.reset();activity=activity(new Intent().setAction(PREFIX+"SHOW"));activity.i();callback(activity,Boolean.TRUE);
  check(k10.answers==1&&first.j.equals(k10.lastTarget),"same-call direct UI answer and permission path remain enabled");
  k10.current=first;k10.reset();activity=activity(answer);activity.onNewIntent(answer);k10.current=call(first.a,first.j,v00.a,true);callback(activity,Boolean.TRUE);check(k10.answers==0,"late permission grant cannot answer active call");
  xz.permitted=true;
 }
 static void permissionReentry(boolean oldHelper){
  u00 first=call("permission-A","permission-token-A",z00.a,true),second=call("permission-B","permission-token-B",z00.a,true);
  Intent firstAnswer=bound("ANSWER",first),secondAnswer=bound("ANSWER",second);
  k10.current=first;k10.reset();xz.permitted=false;CallActivity activity=activity(firstAnswer);activity.onNewIntent(firstAnswer);
  check(activity.o0&&activity.n0.launches==1,"call A starts exactly one permission request");
  k10.current=second;activity.onNewIntent(secondAnswer);
  check(activity.o0&&activity.n0.launches==(oldHelper?2:1),"call B notification cannot overwrite waiting call A permission request");
  callback(activity,Boolean.TRUE);
  check(k10.answers==(oldHelper?1:0),"old permission grant cannot be reassigned to newly arrived call B");
  check(!activity.o0&&(oldHelper?second.j.equals(k10.lastTarget):k10.lastTarget==null),"old permission request is consumed without acting on B");
  if(!oldHelper){
   activity.onNewIntent(secondAnswer);check(activity.o0&&activity.n0.launches==2,"call B may request permission after old A request is consumed");
   callback(activity,Boolean.TRUE);check(k10.answers==1&&second.j.equals(k10.lastTarget),"fresh B permission grant can answer B normally");
  }
  xz.permitted=true;
 }
 static void answerRingtone(boolean oldHelper){
  u00 first=call("ringtone-A","ringtone-token-A",z00.a,true),second=call("ringtone-B","ringtone-token-B",z00.a,true);
  Intent answer=bound("ANSWER",first);k10.current=first;k10.reset();xz.permitted=true;
  CallActivity activity=activity(answer);final String[] stoppedTarget={null};
  nz3.afterSnapshot=()->k10.current=second;w10.onStop=()->stoppedTarget[0]=k10.current.j;
  try{activity.onNewIntent(answer);}finally{nz3.afterSnapshot=null;w10.onStop=null;}
  check(k10.current==second&&k10.answers==0,"snapshot race does not answer the replacement incoming call");
  check(w10.stops==(oldHelper?1:0),"stale answer snapshot must not stop the replacement call ringtone");
  check(oldHelper?second.j.equals(stoppedTarget[0]):stoppedTarget[0]==null,"ringtone stop belongs only to a finally validated answer");
  k10.current=first;k10.reset();xz.permitted=false;activity=activity(answer);activity.onNewIntent(answer);
  check(activity.o0&&activity.n0.launches==1,"missing microphone permission still launches exactly one request");
  check(w10.stops==(oldHelper?1:0),"incoming ringtone remains while microphone permission is unresolved");
  callback(activity,Boolean.FALSE);
  check(k10.answers==0&&!activity.o0&&w10.stops==(oldHelper?1:0),"denied microphone permission leaves incoming call unanswered and unsilenced");
  k10.reset();activity=activity(answer);activity.onNewIntent(answer);callback(activity,null);
  check(k10.answers==0&&!activity.o0&&w10.stops==(oldHelper?1:0),"cancelled microphone result leaves incoming call unanswered and unsilenced");
  callback(activity,Boolean.TRUE);check(k10.answers==0,"cancelled permission cannot be revived by a later duplicate grant");
  k10.reset();activity=activity(answer);activity.onNewIntent(answer);callback(activity,Boolean.TRUE);
  check(k10.answers==1&&first.j.equals(k10.lastTarget)&&w10.stops==1,"matching granted answer stops ringtone exactly once");
  k10.reset();xz.permitted=true;activity=activity(answer);activity.onNewIntent(answer);
  check(k10.answers==1&&first.j.equals(k10.lastTarget)&&w10.stops==1,"already permitted answer stops ringtone exactly once");
  k10.reset();xz.permitted=false;activity=activity(answer);activity.onNewIntent(answer);k10.current=second;callback(activity,Boolean.TRUE);
  check(k10.answers==0&&w10.stops==(oldHelper?1:0),"stale permission grant has no additional ringtone effect");
  xz.permitted=true;
 }
 public static void main(String[] args){boolean legacy=args.length>0&&"legacy".equals(args[0]);if(args.length>0&&"ringtone-legacy".equals(args[0])){answerRingtone(true);System.out.println("NATIVE_NOTIFICATION ringtone_regression_reproduced=true checks="+checks);return;}if(args.length>0&&"permission-reentry-legacy".equals(args[0])){permissionReentry(true);System.out.println("NATIVE_NOTIFICATION permission_reentry_regression_reproduced=true checks="+checks);return;}if(legacy){receiverLegacy();activityLegacy();}else{receiverCurrent();identity();activityCurrent();permissionReentry(false);answerRingtone(false);}System.out.println("NATIVE_NOTIFICATION "+(legacy?"legacy_regression_reproduced":"current_passed")+"=true checks="+checks);}
}
