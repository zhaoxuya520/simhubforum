/** Flow state read boundary. */
public interface pt4 {Object getValue();}
