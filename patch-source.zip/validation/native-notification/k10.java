/** Native call-controller command boundary double; call objects remain real APK u00/b10. */
public class k10 {
 public static final k10 a=new k10();public static final nz3 c=new nz3();public static u00 current,replaceOnCommand;
 public static int answers,declines,hangups;public static String lastTarget;
 public static u00 j(){return current;}
 private static u00 selected(){
  if(replaceOnCommand!=null){current=replaceOnCommand;replaceOnCommand=null;}
  u00 result=current;
  try {Class<?> guard=Class.forName("cc.forserein.simhub.internal.CallNotificationGuard");
   if(!((Boolean)guard.getMethod("allowSelected",Object.class).invoke(null,result)).booleanValue())return null;
  } catch(ClassNotFoundException oldVersion){}catch(Exception e){throw new AssertionError(e);}
  return result;
 }
 public static void b(){u00 call=selected();if(call!=null&&call.e==z00.a){answers++;lastTarget=call.j;}}
 public static void e(){u00 call=selected();if(call!=null&&call.e==z00.a){declines++;lastTarget=call.j;}}
 public static void l(){u00 call=selected();if(call!=null&&!(call.e instanceof y00)){hangups++;lastTarget=call.j;}}
 public static void reset(){answers=declines=hangups=0;lastTarget=null;replaceOnCommand=null;w10.stops=0;}
}
