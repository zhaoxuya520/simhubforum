/** Flow state boundary backed by actual APK c10/u00 objects. */
public class nz3 {
 public static Runnable afterSnapshot;
 public final pt4 T=new pt4(){public Object getValue(){
  c10 result=new c10(k10.current,false,"","",false);
  Runnable action=afterSnapshot;afterSnapshot=null;if(action!=null)action.run();return result;
 }};
}
