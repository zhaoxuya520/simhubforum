# Notification actions bound to a single call

The observed SIMCAT behavior motivating this change is narrowly scoped:
`E1.a(String)` creates incoming-call notification actions with a per-call identifier,
and `NativeIMS.notificationCommand(String,String)` validates that identifier and
incoming phase before acting. SIMHub's original call lifecycle and SIP/audio engine
remain in use. No SIMCAT source, executable or library is redistributed here.

The regression probe executes the supplied APK's code in two processes:

1. The actual `CallActionReceiver.onReceive`, `CallActivity.onCreate`,
   `onNewIntent`, `i`, and microphone permission callback `au0.e`, plus the actual
   `CallNotificationGuard` and call model classes. Android APIs, state-flow reads,
   audio permission checks and call-command exits are explicit fixtures. Activity
   instances are allocated without Android construction; initial `onCreate` stops
   at a Compose rendering boundary after notification dispatch has executed.
2. The actual native `k10.b/h/j/e/l/p` controller methods and actual `d10`
   constructor that captures the call for the eventual SIP command. A JVM-only
   adapter bypasses `k10`'s singleton/coroutine static initializer, then verifies
   instruction fingerprints of those methods before and after adaptation. State
   flow and the coroutine scheduling exit are explicit fixtures. The latter records
   the real `d10.a0` selected call without sending a SIP command.

The second process deterministically changes call A to B between initial action
validation and the controller's final call selection. It verifies that the bounded
native hook rejects B before it can be captured by a new `d10` command or stop the
new call's ringtone. Matching actions still capture A, while direct unscoped native
controls continue to work.

Other cases cover old/missing identity, both SIP ID and per-call token, call phase
and direction, first/new Activity intents, microphone permission grant and denial,
duplicate or delayed callbacks, and ordinary non-destructive call-page opening.

`PendingIntent` is an explicit platform model implementing Android filter identity
for the fields used here (type, request code, component, action and data; extras are
excluded). It intentionally demonstrates why just replacing extras under a fixed
request code would retain the bug. It verifies that distinct call data keeps old
and new pending intents separate. This is not an Android OS notification delivery
test, and the native Compose notification renderer is covered by bounded patch
integration checks rather than executed by this probe.

Run:

```
python3 tests/check_native_notification_runtime.py APK DECODED --report REPORT
```

Pass `--legacy` to demonstrate the failures in the published 23.3 APK. The report
records the exact APK hash, separate entry/controller assertion counts, and all
fixture limitations. The JVM constructor normalization and static-initializer
adapter never alter a delivered APK; DEX/ART verification is a separate check.
`reference-simcat.json` records the sample hash and AOSP identity semantics used in
this review. No actual phone, carrier call, or native system notification delivery
is asserted by the host probe.
