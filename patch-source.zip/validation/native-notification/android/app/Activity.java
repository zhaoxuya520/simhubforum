package android.app;
import android.content.*;
import android.os.Bundle;
public class Activity extends Context {
 private Intent intent;public boolean finished;
 public Intent getIntent(){return intent;}public void setIntent(Intent intent){this.intent=intent;}
 public void onCreate(Bundle bundle){}public void onNewIntent(Intent intent){}
 public void setShowWhenLocked(boolean value){}public void setTurnScreenOn(boolean value){}
 public void finish(){finished=true;}
}
