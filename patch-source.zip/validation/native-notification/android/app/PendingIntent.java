package android.app;
import android.content.*;
import java.util.*;
/** Models documented PendingIntent filter identity: extras excluded; data included. */
public final class PendingIntent {
 private static final Map<String,PendingIntent> cache=new HashMap<String,PendingIntent>();
 private Intent intent;private final String identity;
 private PendingIntent(String key,Intent value){identity=key;intent=new Intent(value);}
 private static PendingIntent get(String kind,int code,Intent value,int flags){
  String key=kind+"|"+code+"|"+value.component()+"|"+value.getAction()+"|"+value.getData();
  PendingIntent result=cache.get(key);if(result==null){result=new PendingIntent(key,value);cache.put(key,result);}
  else if((flags&0x08000000)!=0)result.intent=new Intent(value);
  return result;
 }
 public static PendingIntent getActivity(Context context,int code,Intent value,int flags){return get("activity",code,value,flags);}
 public static PendingIntent getBroadcast(Context context,int code,Intent value,int flags){return get("broadcast",code,value,flags);}
 public Intent intent(){return new Intent(intent);}public String identity(){return identity;}public static void reset(){cache.clear();}
}
