package android.content;
import java.util.*;
import android.net.Uri;
public class Intent {
 private String action; private Uri data; private Class<?> component;private int flags;
 private final Map<String,Object> extras=new HashMap<String,Object>();
 public Intent(){} public Intent(Context context,Class<?> component){this.component=component;}
 public Intent(Intent other){action=other.action;data=other.data;component=other.component;flags=other.flags;extras.putAll(other.extras);}
 public Intent setAction(String value){action=value;return this;} public String getAction(){return action;}
 public Intent putExtra(String key,String value){extras.put(key,value);return this;}
 public String getStringExtra(String key){Object value=extras.get(key);return value instanceof String?(String)value:null;}
 public void removeExtra(String key){extras.remove(key);}
 public Intent setData(Uri value){data=value;return this;} public Uri getData(){return data;}
 public Intent addFlags(int value){flags|=value;return this;} public int getFlags(){return flags;}
 public Class<?> component(){return component;}
}
