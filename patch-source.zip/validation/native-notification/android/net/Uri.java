package android.net;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
public class Uri {
 private final String value;private Uri(String value){this.value=value;}
 public static Uri parse(String value){return new Uri(value);}
 public static String encode(String value){try{return URLEncoder.encode(value,"UTF-8").replace("+","%20");}catch(UnsupportedEncodingException e){throw new AssertionError(e);}}
 public String toString(){return value;} public boolean equals(Object x){return x instanceof Uri&&value.equals(x.toString());} public int hashCode(){return value.hashCode();}
 public static class Builder {
  private String scheme="",authority="";private final StringBuilder path=new StringBuilder(),query=new StringBuilder();
  public Builder scheme(String value){scheme=value;return this;}public Builder authority(String value){authority=value;return this;}
  public Builder appendPath(String value){path.append('/').append(Uri.encode(value));return this;}
  public Builder appendQueryParameter(String key,String value){if(query.length()>0)query.append('&');query.append(Uri.encode(key)).append('=').append(Uri.encode(value));return this;}
  public Uri build(){return Uri.parse(scheme+"://"+authority+path+(query.length()>0?"?"+query:""));}
 }
}
