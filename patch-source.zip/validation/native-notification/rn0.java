/** Activity platform/library superclass boundary. Native CallActivity methods are not replaced. */
public class rn0 extends android.app.Activity {}
