/** SIP connection presence boundary; no network call is executed. */
public class o82 {}
