/** Coroutine scheduling boundary: capture the actual APK d10 command without executing SIP. */
public class xq0 {
 public static d10 command;
 public static ls4 X(ou0 scope,fu0 context,ru0 start,kt1 task,int mask){command=(d10)task;return null;}
}
