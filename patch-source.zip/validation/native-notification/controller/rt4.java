/** StateFlow boundary with deterministic replacement exactly at a native selection read. */
public class rt4 {
 public c10 value;public int reads,replaceAtRead;public u00 replacement;
 public Object getValue(){reads++;if(reads==replaceAtRead&&replacement!=null)value=new c10(replacement,false,"","",false);return value;}
 public boolean h(Object expected,Object update){if(value!=expected)return false;value=(c10)update;return true;}
}
