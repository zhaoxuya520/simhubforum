/** Unrelated call-state rendering update boundary; selected call stays the same object. */
public class tt implements ws1 {public tt(int variant){}public Object i(Object value){return value;}}
