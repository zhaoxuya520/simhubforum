import android.content.*;
import cc.forserein.simhub.vowifi.calling.CallActionReceiver;
/** Actual APK k10 b/h/j/e/l/p and d10 constructor, with only bootstrap/state/SIP scheduling isolated. */
public final class NativeNotificationControllerProbe {
 static int checks;static final String PREFIX="cc.forserein.simhub.call.";
 static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
 static u00 call(String id,String token,b10 state,boolean incoming){return new u00(id,"+100","Synthetic call",incoming,state,null,0L,false,"",token,false,false);}
 static void staticField(String name,Object value){
  try{java.lang.reflect.Field uf=sun.misc.Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);sun.misc.Unsafe unsafe=(sun.misc.Unsafe)uf.get(null);
   java.lang.reflect.Field field=k10.class.getField(name);unsafe.putObject(unsafe.staticFieldBase(field),unsafe.staticFieldOffset(field),value);
  }catch(Exception e){throw new AssertionError(e);}
 }
 static rt4 state(u00 call){rt4 flow=new rt4();flow.value=new c10(call,false,"","",false);staticField("b",flow);staticField("g",new o82());xq0.command=null;w10.stops=0;return flow;}
 static Object guard(String method,Class<?>[] sig,Object...args){
  try{return Class.forName("cc.forserein.simhub.internal.CallNotificationGuard").getMethod(method,sig).invoke(null,args);}
  catch(java.lang.reflect.InvocationTargetException e){throw new AssertionError(e.getCause());}catch(Exception e){throw new AssertionError(e);}
 }
 static Intent bound(String action,u00 call,boolean legacy){Intent result=new Intent().setAction(PREFIX+action).putExtra("simhub.call.id",call.a).putExtra("simhub.call.token",call.j);if(!legacy)guard("bind",new Class<?>[]{Intent.class,Object.class},result,call);return result;}
 public static class ActivityState {public boolean o0;}
 static void broadcast(boolean legacy){
  CallActionReceiver receiver=new CallActionReceiver();Context context=new Context();
  for(String action:new String[]{"DECLINE","HANGUP"}){
   boolean incoming=action.equals("DECLINE");b10 phase=incoming?z00.a:v00.a;
   u00 first=call("call-A","token-A",phase,incoming),second=call("call-B","token-B",phase,incoming);
   Intent intent=bound(action,first,legacy);state(second);receiver.onReceive(context,intent);
   if(legacy){check(xq0.command!=null&&xq0.command.a0==second,"actual old "+action+" captures replacement B in d10");}
   else check(xq0.command==null&&w10.stops==0,"stale "+action+" rejected before native scheduling");
   rt4 flow=state(first);
   if(!legacy){
    flow.replacement=second;flow.replaceAtRead=3;
    receiver.onReceive(context,intent);
    check(flow.reads==3&&flow.value.a==second,"replacement occurs at actual k10.h selected-call read");
    check(xq0.command==null&&w10.stops==0,"actual k10.h guard rejects new B before d10/ringtone");
    state(first);receiver.onReceive(context,intent);check(xq0.command!=null&&xq0.command.a0==first,"matching "+action+" captures A in actual d10");
    check(xq0.command.X==(incoming?2:3),"native d10 command variant preserved");
   }
  }
 }
 static void answer(){
  u00 first=call("call-A","token-A",z00.a,true),second=call("call-B","token-B",z00.a,true);
  ActivityState activity=new ActivityState();rt4 flow=state(first);
  check((Boolean)guard("prepareAnswer",new Class<?>[]{Object.class,Object.class},activity,first),"answer prepared for actual call A");
  flow.replacement=second;flow.replaceAtRead=2;
  guard("answerPrepared",new Class<?>[]{Object.class},activity);
  check(flow.reads==2&&flow.value.a==second,"replacement occurs at actual k10.b selected-call read");
  check(xq0.command==null,"actual k10.b guard rejects replacement before d10 capture");
  state(first);guard("prepareAnswer",new Class<?>[]{Object.class,Object.class},activity,first);guard("answerPrepared",new Class<?>[]{Object.class},activity);
  check(xq0.command!=null&&xq0.command.a0==first&&xq0.command.X==1,"matching answer captures A in actual d10 answer command");
  state(second);k10.b();check(xq0.command!=null&&xq0.command.a0==second,"unscoped native answer still works for Telecom/headset after guard exits");
  state(second);k10.h();check(xq0.command!=null&&xq0.command.a0==second,"unscoped native end/reject remains enabled");
 }
 public static void main(String[]args){boolean legacy=args.length>0&&"legacy".equals(args[0]);broadcast(legacy);if(!legacy)answer();System.out.println("NATIVE_NOTIFICATION_CONTROLLER "+(legacy?"legacy_regression_reproduced":"current_passed")+"=true checks="+checks);}
}
