/** ActivityResultLauncher platform/library boundary. */
public class b4 {public int launches;public void d0(Object input){launches++;}}
