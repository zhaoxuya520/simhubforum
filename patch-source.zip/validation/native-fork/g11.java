import java.util.*;
/** Android-facing native log sink only; never replaces SIP parsing or dialog behavior. */
public final class g11 {
 public final List<String> messages=new ArrayList<>();
 public Object i(Object value){messages.add(String.valueOf(value));return null;}
}
