import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
/** Replace only the two final socket dispatch boundaries, retaining the shipped h/cb4/helper methods. */
public final class SipForkTransportAdapter {
 public static void main(String[] args)throws Exception {
  int replaced=0;
  try(ZipFile input=new ZipFile(args[0]);ZipOutputStream output=new ZipOutputStream(Files.newOutputStream(Paths.get(args[1])))) {
   for(ZipEntry entry:Collections.list(input.entries())) {
    byte[] data=input.getInputStream(entry).readAllBytes();
    if(entry.getName().equals("o82.class")) {
     ClassNode node=new ClassNode();new ClassReader(data).accept(node,0);
     for(MethodNode m:node.methods)if((m.name.equals("C")&&m.desc.equals("(Lkb4;)V")) || (m.name.equals("x")&&m.desc.equals("([BLoc2;)V"))) {
      m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
      m.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));m.instructions.add(new VarInsnNode(Opcodes.ALOAD,1));
      if(m.name.equals("x")){m.instructions.add(new VarInsnNode(Opcodes.ALOAD,2));m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"SipForkProbe","transportContext","(Ljava/lang/Object;[BLjava/lang/Object;)V",false));}
      else m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"SipForkProbe","transport","(Ljava/lang/Object;Ljava/lang/Object;)V",false));
      m.instructions.add(new InsnNode(Opcodes.RETURN));m.maxStack=3;m.maxLocals=m.name.equals("x")?3:2;replaced++;
     }
     ClassWriter writer=new ClassWriter(0);node.accept(writer);data=writer.toByteArray();
    }
    output.putNextEntry(new ZipEntry(entry.getName()));output.write(data);output.closeEntry();
   }
  }
  if(replaced!=2)throw new AssertionError("transport count="+replaced);
 }
}
