import java.lang.reflect.*;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** Actual APK native dispatcher, dialog/parser/builders and fork helper; transport only is collected. */
@SuppressWarnings({"rawtypes","unchecked"})
public final class SipForkProbe {
 static Class<?> msg,dialog,manager,direction,state,helper;
 static int checks,failAck,failBye;
 static Object sentContext;static byte[] sentBytes;
 static final List<Object> attempts=new ArrayList<>();
 static final String A="v=0\r\no=- 1 1 IN IP4 192.0.2.10\r\ns=call\r\nc=IN IP4 192.0.2.10\r\nt=0 0\r\nm=audio 10000 RTP/AVP 116\r\na=rtpmap:116 AMR-WB/16000\r\na=fmtp:116 octet-align=1\r\na=sendrecv\r\n";
 static final String B=A.replace("192.0.2.10","192.0.2.20").replace("10000","20000");
 static Object get(Object o,String f)throws Exception{return o.getClass().getField(f).get(o);}
 static void set(Object o,String f,Object v)throws Exception{Field field=o.getClass().getField(f);field.setAccessible(true);field.set(o,v);}
 static void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
 static Object call(Object o,String n,Class<?>[] t,Object...v)throws Exception{return o.getClass().getMethod(n,t).invoke(o,v);}
 static Object allocate(Class<?> type)throws Exception{Class<?> u=Class.forName("sun.misc.Unsafe");Field f=u.getDeclaredField("theUnsafe");f.setAccessible(true);return u.getMethod("allocateInstance",Class.class).invoke(f.get(null),type);}
 static Object message(boolean request,String method,int status,String body)throws Exception{return msg.getConstructor(boolean.class,String.class,String.class,int.class,String.class,ArrayList.class,byte[].class).newInstance(request,method,"sip:peer@example.invalid",status,request?"":"OK",new ArrayList<>(),body.getBytes(StandardCharsets.UTF_8));}
 static void header(Object p,String n,String v)throws Exception{call(p,"a",new Class<?>[]{String.class,String.class},n,v);}
 static List<String> headers(Object p,String n)throws Exception{return (List<String>)call(p,"j",new Class<?>[]{String.class},n);}
 static String first(Object p,String n)throws Exception{List<String> hs=headers(p,n);return hs.isEmpty()?null:hs.get(0);}
 static Map cache()throws Exception{Field f=helper.getDeclaredField("CACHE");f.setAccessible(true);return(Map)f.get(null);}
 static Object entry(Object d,String tag)throws Exception{Object b=cache().get(d);Field f=b.getClass().getDeclaredField("forks");f.setAccessible(true);return((Map)f.get(b)).get(tag);}
 static Object hidden(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
 public static void transport(Object engine,Object packet)throws Exception{
  attempts.add(packet);String method=(String)get(packet,"b");
  if("ACK".equals(method)&&failAck-->0)throw new IllegalStateException("test synchronous ACK dispatch failure");
  if("BYE".equals(method)&&failBye-->0)throw new IllegalStateException("test synchronous BYE dispatch failure");
  ((List)get(engine,"V")).add(packet);
 }
 public static void transportContext(Object engine,byte[] bytes,Object context){sentBytes=bytes;sentContext=context;}
 static String deep(Object o)throws Exception{
  if(o==null)return "null";if(o instanceof byte[])return Arrays.toString((byte[])o);
  if(o instanceof List){StringBuilder b=new StringBuilder("[");for(Object x:(List)o)b.append(deep(x)).append(';');return b+"]";}
  if(o instanceof Map)return new TreeMap<>((Map)o).toString();
  if(o.getClass()==msg){StringBuilder b=new StringBuilder();for(Field f:msg.getFields())if(!Modifier.isStatic(f.getModifiers()))b.append(f.getName()).append(':').append(deep(f.get(o))).append(';');return b.toString();}
  return o.toString();
 }
 static final class Snapshot {
  final Object target;final Map<String,Object> refs=new TreeMap<>();final Map<String,String> values=new TreeMap<>();
  Snapshot(Object d)throws Exception{target=d;for(Field f:d.getClass().getFields())if(!Modifier.isStatic(f.getModifiers())){Object v=f.get(d);refs.put(f.getName(),v);values.put(f.getName(),deep(v));}}
  void unchanged(String label)throws Exception{for(String n:refs.keySet()){Object now=get(target,n),old=refs.get(n);check(now==old||now!=null&&(now instanceof Number||now instanceof Boolean||now instanceof Character)&&now.equals(old),label+" reference "+n);check(Objects.equals(values.get(n),deep(now)),label+" content "+n);}}
 }
 static final class Session {
  Object d,m,e;
  Session(boolean tcp)throws Exception{
   cache().clear();failAck=failBye=0;attempts.clear();
   d=dialog.getConstructors()[0].newInstance(direction.getField("U").get(null),"probe@example.invalid",state.getField("T").get(null),"local-tag","sip:local@example.invalid","sip:peer@example.invalid","sip:peer@example.invalid",11,11,message(true,"INVITE",0,"original offer"),0.0);
   Object config=Class.forName("ra4").getConstructors()[0].newInstance("192.0.2.1",5060,"sip:local@example.invalid","urn:uuid:fork-probe","sip:local@example.invalid","probe",new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),tcp,false);
   m=manager.getConstructors()[0].newInstance(config,null,null,null);((Map)get(m,"e")).put("probe@example.invalid",d);e=allocate(Class.forName("o82"));set(e,"J",m);set(e,"V",new ArrayList<>());set(e,"g",new g11());set(e,"K",allocate(Class.forName("ls4")));
  }
  Object response(String tag,String body,String contact,String route,boolean compact)throws Exception{
   Object r=message(false,"INVITE",200,body);header(r,compact?"i":"Call-ID","probe@example.invalid");header(r,"CSeq",get(d,"i")+" INVITE");
   header(r,compact?"t":"To","<sip:peer@example.invalid>"+(tag==null?"":";tag="+tag));header(r,"From","<sip:local@example.invalid>;tag=local-tag");
   if(contact!=null)header(r,compact?"m":"Contact","<"+contact+">");if(route!=null)header(r,"Record-Route","<"+route+">");header(r,"Content-Type","application/sdp");return r;
  }
  Object response(String tag)throws Exception{return response(tag,B,"sip:"+tag+"@example.invalid","sip:proxy-"+tag+".example.invalid;lr",false);}
  boolean accept(Object r)throws Exception{return (Boolean)call(e,"h",new Class<?>[]{msg},r);}
  void selected()throws Exception{check(accept(response("A",A,"sip:A@example.invalid","sip:proxy-A.example.invalid;lr",false)),"select A");check(get(d,"D")!=null&&"A".equals(get(d,"l")),"native A confirmed");packets().clear();attempts.clear();}
  List packets()throws Exception{return (List)get(e,"V");}
 }
 static void packet(Object p,String method,String tag,int cseq)throws Exception{
  check(method.equals(get(p,"b")),"packet method "+method);check(first(p,"To").endsWith(";tag="+tag),"packet To "+tag);check((cseq+" "+method).equals(first(p,"CSeq")),"packet CSeq "+cseq);check("probe@example.invalid".equals(first(p,"Call-ID")),"packet Call-ID");
 }
 static void ordinaryGuards()throws Exception{
  Session s=new Session(true);s.selected();Object r=s.response("B");
  for(String field:new String[]{"D","l"}){Object old=get(s.d,field);set(s.d,field,null);check(!(Boolean)helper.getMethod("handle",Object.class,Object.class).invoke(null,s.e,r),"missing selected "+field);set(s.d,field,old);}
  for(String role:new String[]{"T"}){Object old=get(s.d,"a");set(s.d,"a",direction.getField(role).get(null));check(!(Boolean)helper.getMethod("handle",Object.class,Object.class).invoke(null,s.e,r),"incoming guard");set(s.d,"a",old);}
  Object bad=s.response(null);check(!(Boolean)helper.getMethod("handle",Object.class,Object.class).invoke(null,s.e,bad),"missing tag guard");
  for(String c:new String[]{"10 INVITE","12 INVITE","11 UPDATE"}){bad=s.response("B");   call(bad,"i",new Class<?>[]{String.class,String.class},"CSeq",c);
   check(!(Boolean)helper.getMethod("handle",Object.class,Object.class).invoke(null,s.e,bad),"CSeq guard "+c);}
 }
 static Object followup(boolean request,String method,String remote,int status,int seq,boolean compact)throws Exception {
  Object p=message(request,method,status,"");header(p,compact?"i":"Call-ID","probe@example.invalid");header(p,"CSeq",seq+" "+method);
  header(p,compact?"t":"To",request?"<sip:local@example.invalid>;tag=local-tag":"<sip:peer@example.invalid>;tag="+remote);
  header(p,compact?"f":"From",request?"<sip:peer@example.invalid>;tag="+remote:"<sip:local@example.invalid>;tag=local-tag");
  header(p,compact?"v":"Via","SIP/2.0/TCP 192.0.2.20:5060;branch=z9hG4bK-fork");header(p,compact?"v":"Via","SIP/2.0/TCP 192.0.2.30:5060;branch=z9hG4bK-proxy");return p;
 }
 static void incoming(Session s,Object request)throws Exception {call(s.e,"r",new Class<?>[]{msg,Class.forName("oc2"),String.class},request,null,"fixture");}
 static void closure()throws Exception {
  for(boolean compact:new boolean[]{false,true})for(String selectedState:new String[]{"W","X"}){
   Session s=new Session(true);s.selected();s.accept(s.response("B"));s.packets().clear();set(s.d,"c",state.getField(selectedState).get(null));Snapshot a=new Snapshot(s.d);
   for(int status:new int[]{100,200,202,481,500}){Object r=followup(false,"BYE","B",status,12,compact);Snapshot rs=new Snapshot(r);s.accept(r);a.unchanged("fork BYE response "+selectedState+status);rs.unchanged("fork BYE response immutable");check(((Map)get(s.m,"e")).get("probe@example.invalid")==s.d,"fork BYE response retains A map");}
   for(String method:new String[]{"BYE","BYE","UPDATE","INFO","INVITE","ACK"}){
    Object req=followup(true,method,"B",0,99,compact);if(method.equals("UPDATE"))header(req,"Session-Expires","777;refresher=uas");Snapshot rs=new Snapshot(req);int before=s.packets().size();incoming(s,req);a.unchanged("fork request "+method);rs.unchanged("fork request immutable");check(((Map)get(s.m,"e")).get("probe@example.invalid")==s.d,"fork request retains A map");
    if(method.equals("ACK"))check(s.packets().size()==before,"no ACK response");else{check(s.packets().size()==before+1,"one fork response");check((Integer)get(s.packets().get(before),"d")== (method.equals("BYE")?200:481),"fork response status "+method);Object reply=s.packets().get(before);check(headers(reply,"Via").equals(headers(req,compact?"v":"Via")),"all Via headers retained in order");for(String[] pair:new String[][]{{"From","f"},{"To","t"},{"Call-ID","i"},{"CSeq","CSeq"}})check(headers(reply,pair[0]).equals(headers(req,compact?pair[1]:pair[0])),"reply echoes fork header "+pair[0]);}
   }
   for(String remote:new String[]{"unrecorded","overflow"}){Object req=followup(true,"BYE",remote,0,99,compact);incoming(s,req);check((Integer)get(s.packets().get(s.packets().size()-1),"d")==481,"unknown leg 481");a.unchanged("unknown leg BYE");}
  }
  Session contextual=new Session(true);contextual.selected();contextual.accept(contextual.response("B"));Snapshot intact=new Snapshot(contextual.d);Object transport=Class.forName("lb4").getConstructor(int.class).newInstance(7);
  sentContext=null;sentBytes=null;Object req=followup(true,"BYE","B",0,99,true);call(contextual.e,"r",new Class<?>[]{msg,Class.forName("oc2"),String.class},req,transport,"TCP fixture");
  check(sentContext==transport,"native reply preserves exact inbound transport context");String serialized=new String(sentBytes,StandardCharsets.UTF_8);check(serialized.startsWith("SIP/2.0 200 OK")&&serialized.contains("z9hG4bK-fork")&&serialized.contains("z9hG4bK-proxy"),"native serialized response retains all Via headers");intact.unchanged("non-null transport reply");
  Object mixed=followup(true,"BYE","B",0,99,true);header(mixed,"Via","SIP/2.0/TCP 192.0.2.40:5060;branch=z9hG4bK-third");Snapshot mixedBefore=new Snapshot(mixed);contextual.packets().clear();incoming(contextual,mixed);check(headers(contextual.packets().get(0),"Via").size()==3,"direct mixed Via full stack");check(headers(contextual.packets().get(0),"Via").get(2).contains("third"),"direct mixed Via order");mixedBefore.unchanged("mixed request unchanged");
  String raw="BYE sip:local@example.invalid SIP/2.0\r\nv: SIP/2.0/TCP 192.0.2.20:5060;branch=z9hG4bK-first\r\nVia: SIP/2.0/TCP 192.0.2.30:5060;branch=z9hG4bK-second\r\nf: <sip:peer@example.invalid>;tag=B\r\nt: <sip:local@example.invalid>;tag=local-tag\r\ni: probe@example.invalid\r\nCSeq: 99 BYE\r\nContent-Length: 0\r\n\r\n";
  Object parsed=Class.forName("jb4").getMethod("c",byte[].class).invoke(null,(Object)raw.getBytes(StandardCharsets.US_ASCII));contextual.packets().clear();incoming(contextual,parsed);List<String> vias=headers(contextual.packets().get(0),"Via");check(vias.size()==2&&vias.get(0).contains("first")&&vias.get(1).contains("second"),"actual raw parser compact/full Via order");intact.unchanged("raw parser request");
  Session s=new Session(true);s.selected();s.accept(s.response("B"));s.packets().clear();
  for(boolean request:new boolean[]{false,true})for(String local:new String[]{"wrong",""}){
   Object p=followup(request,request?"BYE":"INVITE","B",200,request?99:11,false);call(p,"i",new Class<?>[]{String.class,String.class},request?"To":"From","<sip:local@example.invalid>"+(local.isEmpty()?"":";tag="+local));
   boolean handled=request?(Boolean)helper.getMethod("handleRequest",Object.class,Object.class,Object.class).invoke(null,s.e,p,null):(Boolean)helper.getMethod("handle",Object.class,Object.class).invoke(null,s.e,p);
   check(handled,"invalid local tag isolated "+request+local);
   Snapshot a=new Snapshot(s.d);if(request)incoming(s,p);else s.accept(p);a.unchanged("invalid local tag actual entry");
   if(request)check((Integer)get(s.packets().get(s.packets().size()-1),"d")==481,"invalid local tag 481");
  }
  for(String remote:new String[]{"A",null})for(String method:new String[]{"BYE","UPDATE","ACK"}){Object wrong=followup(true,method,remote,0,99,false);call(wrong,"i",new Class<?>[]{String.class,String.class},"To","<sip:local@example.invalid>;tag=wrong");Snapshot before=new Snapshot(s.d);int packets=s.packets().size();incoming(s,wrong);before.unchanged("wrong local selected remote "+method);check(s.packets().size()==packets+(method.equals("ACK")?0:1),"wrong local ACK silence");if(!method.equals("ACK"))check((Integer)get(s.packets().get(packets),"d")==481,"wrong local selected remote 481");}
  s.packets().clear();
  Object selected=followup(true,"UPDATE","A",0,99,false);check(!(Boolean)helper.getMethod("handleRequest",Object.class,Object.class,Object.class).invoke(null,s.e,selected,null),"A UPDATE retains native path");incoming(s,selected);check((Integer)get(s.packets().get(0),"d")==200,"A UPDATE native success");check(((Map)get(s.m,"e")).get("probe@example.invalid")==s.d,"A UPDATE retains dialog");
  selected=followup(true,"BYE","A",0,100,false);incoming(s,selected);check(((Map)get(s.m,"e")).isEmpty()&&get(s.d,"c")==state.getField("Y").get(null),"A own remote BYE native termination");
  s=new Session(true);s.selected();s.accept(s.response("B"));set(s.d,"c",state.getField("X").get(null));s.accept(followup(false,"BYE","A",200,12,false));check(((Map)get(s.m,"e")).isEmpty(),"A own BYE response native completion");
 }
 static WeakReference<Object> cachedWeakDialog()throws Exception{
  Session s=new Session(true);s.selected();s.accept(s.response("B"));WeakReference<Object>w=new WeakReference<>(s.d);((Map)get(s.m,"e")).clear();return w;
 }
 public static void main(String[] args)throws Exception{
  msg=Class.forName("kb4");dialog=Class.forName("ma4");manager=Class.forName("cb4");direction=Class.forName("ga4");state=Class.forName("la4");helper=Class.forName("cc.forserein.simhub.internal.SipForkProtection");
  for(boolean tcp:new boolean[]{true,false}){
   Session s=new Session(tcp);s.selected();Snapshot a=new Snapshot(s.d);Object b=s.response("B");Snapshot response=new Snapshot(b);check(s.accept(b),"B consumed");a.unchanged("first fork");response.unchanged("response immutable");
   List ps=s.packets();check(ps.size()==2,"ACK+BYE");packet(ps.get(0),"ACK","B",11);packet(ps.get(1),"BYE","B",12);check("sip:B@example.invalid".equals(get(ps.get(0),"c")),"B target");check(first(ps.get(0),"Route").contains("proxy-B"),"B route");
   Object fork=hidden(entry(s.d,"B"),"fork");for(String f:new String[]{"m","F","v","j"})check(get(fork,f)!=get(s.d,f),"independent fork "+f);check(get(get(fork,"j"),"g")!=get(get(s.d,"j"),"g"),"independent invite body");
   for(int i=0;i<3;i++)s.accept(b);check(ps.size()==5,"retransmit ACK every time without new BYE");a.unchanged("repeated B");
   s.accept(s.response("C"));check(ps.size()==7,"second fork ACK+BYE");packet(ps.get(5),"ACK","C",11);packet(ps.get(6),"BYE","C",12);a.unchanged("multi fork");
   int before=ps.size();s.accept(s.response("A",A,"sip:A@example.invalid","sip:proxy-A.example.invalid;lr",false));check(ps.size()==before+1,"same tag native ACK");check("A".equals(get(s.d,"l"))&&A.equals(new String((byte[])get(s.d,"p"),StandardCharsets.UTF_8)),"same-tag native selected content retained");
  }
  Session rawSession=new Session(true);rawSession.selected();Snapshot rawBefore=new Snapshot(rawSession.d);Object wire=rawSession.response("B");byte[] encoded=(byte[])call(wire,"b",new Class<?>[0]);Object parsedResponse=Class.forName("jb4").getMethod("c",byte[].class).invoke(null,(Object)encoded);rawSession.accept(parsedResponse);check(rawSession.packets().size()==2,"raw SIP parser to native h fork cleanup");rawBefore.unchanged("raw SIP fork response");
  for(boolean compact:new boolean[]{true,false})for(String scheme:new String[]{"sip:","SIP:","sIpS:"}){
   Session s=new Session(true);s.selected();Snapshot a=new Snapshot(s.d);Object r=s.response("B",B,scheme+"B@example.invalid",null,compact);Snapshot rs=new Snapshot(r);s.accept(r);check(s.packets().size()==2,"compact/scheme fork handled "+compact+scheme);check(first(s.packets().get(0),"Route")==null,"B with no route does not borrow A route");a.unchanged("compact scheme");rs.unchanged("compact original response");
  }
  Session upper=new Session(true);upper.selected();Object compactUpper=upper.response("B",B,"sip:B@example.invalid",null,false);for(String[] names:new String[][]{{"To","T"},{"Contact","M"},{"Call-ID","I"},{"From","F"}}){String value=first(compactUpper,names[0]);((List)get(compactUpper,"f")).removeIf(x->{try{return names[0].equals(get(x,"T"));}catch(Exception ignored){return false;}});header(compactUpper,names[1],value);}Snapshot us=new Snapshot(upper.d);upper.accept(compactUpper);check(upper.packets().size()==2,"uppercase compact headers");us.unchanged("uppercase compact");
  Session s=new Session(true);s.selected();Snapshot a=new Snapshot(s.d);s.accept(s.response("bad",B,null,null,false));check(s.packets().isEmpty(),"missing Contact sends nothing to A");a.unchanged("invalid fork");
  s=new Session(true);s.selected();set(s.d,"c",state.getField("X").get(null));a=new Snapshot(s.d);s.accept(s.response("B"));check(s.packets().size()==2,"terminating selected keeps fork cleanup");a.unchanged("terminating selected A");
  s=new Session(true);set(s.d,"c",state.getField("X").get(null));s.accept(s.response("late",A,"sip:late@example.invalid",null,false));check(s.packets().size()==2,"unselected CANCEL late 200 native ACK/BYE");packet(s.packets().get(0),"ACK","late",11);packet(s.packets().get(1),"BYE","late",12);
  s=new Session(true);s.selected();a=new Snapshot(s.d);failAck=1;Object b=s.response("B");s.accept(b);check(s.packets().isEmpty()&&attempts.size()==1,"ACK failure suppresses BYE");s.accept(b);check(s.packets().size()==2&&attempts.size()==3,"ACK retry then BYE");a.unchanged("ACK send failure");
  s=new Session(true);s.selected();a=new Snapshot(s.d);Object config=get(s.m,"a");set(s.m,"a",null);b=s.response("B");s.accept(b);check(s.packets().isEmpty(),"ACK builder failure sends nothing");set(s.m,"a",config);s.accept(b);check(s.packets().size()==2,"ACK builder recovery reuses isolated fork");a.unchanged("builder failure/retry");
  for(int failures:new int[]{1,3}){s=new Session(true);s.selected();a=new Snapshot(s.d);failBye=failures;b=s.response("B");s.accept(b);Object firstBye=attempts.get(1);s.accept(b);check(attempts.get(3)==firstBye,"BYE retry reuses exact cached request");s.accept(b);check(attempts.size()==5,"BYE bounded to two sends");a.unchanged("BYE send failure");}
  for(int h:new int[]{Integer.MAX_VALUE,-1,2}){s=new Session(true);s.selected();set(s.d,"h",h);a=new Snapshot(s.d);s.accept(s.response("B"));int count=h<0?0:h==Integer.MAX_VALUE?1:2;check(s.packets().size()==count,"CSeq boundary "+h);if(h==2)packet(s.packets().get(1),"BYE","B",12);a.unchanged("CSeq boundary");}
  s=new Session(true);s.selected();a=new Snapshot(s.d);for(int i=0;i<64;i++)s.accept(s.response("fork"+i));check(s.packets().size()==128,"64 forks cleaned");for(int i=64;i<68;i++)s.accept(s.response("fork"+i));check(s.packets().size()==128,"overflow consumed");s.accept(s.response("fork0"));check(s.packets().size()==129,"cached fork still ACK after cap");a.unchanged("cache cap");incoming(s,followup(true,"BYE","fork64",0,99,true));check((Integer)get(s.packets().get(s.packets().size()-1),"d")==481,"actual capped leg BYE 481");a.unchanged("capped leg request");
  ordinaryGuards();
  closure();
  WeakReference<Object>w=cachedWeakDialog();attempts.clear();for(int i=0;i<30&&w.get()!=null;i++){System.gc();byte[]pressure=new byte[1024*1024];Thread.sleep(10);}check(w.get()==null,"weak dialog is collectable");check(cache().isEmpty(),"weak cache expunged");
  System.out.println("SIP_FORK_PROBE checks="+checks+" passed=true");
 }
}
