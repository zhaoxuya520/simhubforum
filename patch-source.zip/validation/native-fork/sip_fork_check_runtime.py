#!/usr/bin/env python3
"""Execute shipped fork/dispatcher/builders, adapting only final transport C(kb4)."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,zipfile
p=argparse.ArgumentParser();p.add_argument('jar',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];source=Path(__file__).parent
tools=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
lib=Path(os.environ.get('SIMHUB_DEX2JAR_TOOLS','/workspace/tools/dex2jar-v2.4'))/'dex-tools-v2.4/lib'
work=a.report.parent/'native-fork';classes=work/'classes';classes.mkdir(parents=True,exist_ok=True)
asm=os.pathsep.join(str(lib/n)for n in ['asm-9.5.jar','asm-tree-9.5.jar']);adapted=work/'transport-adapted.jar';logs=[]
def run(*args):
 r=subprocess.run(list(map(str,args)),cwd=root,capture_output=True,text=True);logs.append(r.stdout+r.stderr)
 if r.returncode:
  a.report.with_suffix('.log').write_text('\n'.join(logs));print(r.stdout+r.stderr);raise SystemExit(r.returncode)
 return r.stdout
run('java','-jar',tools/'ecj-3.40.0.jar','-17','-proc:none','-cp',asm,'-d',classes,source/'SipForkTransportAdapter.java',source/'SipForkProbe.java',source/'g11.java')
run('java','-cp',str(classes)+os.pathsep+asm,'SipForkTransportAdapter',a.jar,adapted)
with zipfile.ZipFile(a.jar)as original,zipfile.ZipFile(adapted)as result:
 assert set(original.namelist())==set(result.namelist())
 changed=[n for n in original.namelist()if original.read(n)!=result.read(n)]
 assert changed==['o82.class'],changed
 assert not any(p.name in {'o82.class','kb4.class','ma4.class','cb4.class','SipForkProtection.class'}for p in classes.rglob('*.class'))
out=run('java','-noverify','-cp',os.pathsep.join(map(str,[classes,adapted,tools/'sdk/android-35/android.jar'])),'SipForkProbe')
match=re.search(r'SIP_FORK_PROBE checks=(\d+) passed=true',out);assert match,out
report=dict(apk_translated_jar_sha256=hashlib.sha256(a.jar.read_bytes()).hexdigest(),checks=int(match[1]),native_dispatcher_executed=True,native_dialog_parser_and_builders_executed=True,shipped_fork_helper_executed=True,protocol_methods_mocked=False,transport_boundary_collected=True,log_sink_fixture=True,unused_timer_preseeded=True,transport_failure_injection=True,engine_constructor_bypassed_to_avoid_network=True,device_tested=False,art_execution=False,real_carrier_tested=False)
a.report.write_text(json.dumps(report,indent=2)+'\n');a.report.with_suffix('.log').write_text('\n'.join(logs));print(out.strip())
