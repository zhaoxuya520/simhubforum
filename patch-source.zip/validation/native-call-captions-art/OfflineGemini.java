package captionprobe;

import android.util.Base64;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.*;

/** Test-process URL transport. It has no socket and returns a deliberately labelled example. */
final class OfflineGemini {
    static final String FIRST = "示例字幕：您好，这里是预约中心。";
    static final String EXAMPLE = "示例字幕：您的预约已确认。请提前十分钟到达，并在前台出示预约编号。";
    static final String LONG = "示例字幕：请先确认您的预约时间。Appointment ID BK-2048 已发到您的邮箱。"
            + "如需改期，请在周五下午五点前联系前台，并提供新的日期和时间。工作人员会再次与您确认。"
            + "到达后请在二楼服务台出示预约编号，保留确认邮件以便核对。最后请带上身份证件。";
    static final String ARABIC = "مثال توضيحي: موعدك يوم الثلاثاء الساعة 10:30. رقم الحجز BK-2048.";
    static final String KEY = "synthetic-caption-art-key";
    static final AtomicInteger requests = new AtomicInteger();
    static volatile String error;
    private OfflineGemini() {}
    static void install() { install(false); }
    static void install(boolean reading) {
        final String[] replies = reading ? new String[]{FIRST,LONG,LONG,ARABIC,null} : new String[]{FIRST,EXAMPLE};
        final String[] locales = reading ? new String[]{"zh-Hans","zh-Hans","zh-Hans","ar","ar"} : new String[]{"zh-Hans","zh-Hans"};
        URL.setURLStreamHandlerFactory(protocol -> {
            if (!"https".equals(protocol)) return null;
            return new URLStreamHandler() {
                @Override protected URLConnection openConnection(URL url) throws IOException {
                    if (!"generativelanguage.googleapis.com".equals(url.getHost())
                            || !url.getPath().endsWith(":generateContent"))
                        throw new IOException("Offline fixture blocks other connections");
                    return new HttpURLConnection(url) {
                        int sequence;
                        final ByteArrayOutputStream body=new ByteArrayOutputStream();
                        public void connect() {}
                        public void disconnect() {}
                        public boolean usingProxy() { return false; }
                        public OutputStream getOutputStream() { return body; }
                        public int getResponseCode() throws IOException {
                            try {
                                if (!KEY.equals(getRequestProperty("x-goog-api-key"))) throw new AssertionError("synthetic credential");
                                if (!"POST".equals(getRequestMethod())) throw new AssertionError("method");
                                JSONObject data = new JSONObject(new String(body.toByteArray(),StandardCharsets.UTF_8));
                                sequence=requests.get();
                                if (sequence>=locales.length || !data.getJSONObject("systemInstruction").toString().contains(locales[sequence]))
                                    throw new AssertionError("target");
                                JSONArray parts=data.getJSONArray("contents").getJSONObject(0).getJSONArray("parts");
                                boolean previous=sequence>0 && locales[sequence-1].equals(locales[sequence]);
                                if (parts.length()!=(previous?2:1) || (previous && !parts.getJSONObject(0).getString("text").contains(replies[sequence-1])))
                                    throw new AssertionError("only prior translated utterance used for context");
                                JSONObject audio=parts.getJSONObject(parts.length()-1).getJSONObject("inlineData");

                                byte[] wav=Base64.decode(audio.getString("data"),Base64.DEFAULT);
                                if (!"audio/wav".equals(audio.getString("mimeType")) || wav.length<600
                                        || wav[0]!='R' || wav[8]!='W' || wav[24]!=(byte)0x80 || wav[25]!=(byte)0x3e)
                                    throw new AssertionError("16 kHz WAV");
                                boolean voiced=false;
                                for(int at=44;at+1<wav.length;at+=2){
                                    short sample=(short)((wav[at]&255)|(wav[at+1]<<8));
                                    if (sample!=0 && sample!=2600 && sample!=-2600) throw new AssertionError("unexpected PCM source");
                                    if (sample!=0) voiced=true;
                                }
                                if (!voiced) throw new AssertionError("utterance missing");
                                requests.incrementAndGet();
                                return replies[sequence]==null?403:200;
                            } catch(Throwable failure) {error=failure.toString();throw new IOException(error);}
                        }
                        public InputStream getInputStream() throws IOException {
                            try {
                                JSONObject text=new JSONObject().put("caption",replies[sequence]);
                                JSONObject content=new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",text.toString())));
                                JSONObject candidate=new JSONObject().put("content",content).put("finishReason","STOP");
                                String answer=new JSONObject().put("candidates",new JSONArray().put(candidate)).toString();
                                return new ByteArrayInputStream(answer.getBytes(StandardCharsets.UTF_8));
                            } catch(JSONException failure) {throw new IOException(failure);}
                        }
                    };
                }
            };
        });
    }
}
