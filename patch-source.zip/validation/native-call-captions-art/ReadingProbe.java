package captionprobe;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.Layout;
import android.view.View;
import android.view.MotionEvent;
import android.view.InputDevice;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.ScrollView;
import android.widget.TextView;

/** Checks actual rendered lines, reading position and native control bounds on a narrow phone. */
final class ReadingProbe {
    private final CaptionsArt test;
    private final Object owner=new Object(),stale=new Object();
    private static final Class<?>[] NONE=new Class<?>[]{};
    ReadingProbe(CaptionsArt test) {this.test=test;}
    private String coreText(String method)throws Exception {return (String)test.core(method,NONE);}
    private TextView matching(View root,String exact) {
        if(root instanceof TextView && root.isShown() && exact.contentEquals(((TextView)root).getText()))return (TextView)root;
        if(root instanceof ViewGroup){
            ViewGroup g=(ViewGroup)root;
            for(int i=0;i<g.getChildCount();i++){
                TextView match=matching(g.getChildAt(i),exact);
                if(match!=null)return match;
            }
        }
        return null;
    }
    private TextView text(String exact)throws Exception {
        TextView[] result={null};
        test.onUi(()->result[0]=matching(test.activity.getWindow().getDecorView(),exact));
        return result[0];
    }
    private ScrollView scroller(TextView body) {
        for(ViewParent p=body.getParent();p!=null;p=p.getParent()) if(p instanceof ScrollView)return (ScrollView)p;
        throw new AssertionError("subtitle text has no scroll container");
    }
    private static final class Lines {
        int count,scroll,firstTop,lastBottom,visibleTop,visibleBottom,direction,completeLines;
        boolean first,last,clippedTopInk,clippedBottomInk,alignedAfterLine;
    }
    private Lines lines(TextView body)throws Exception{
        Lines p=new Lines();
        test.onUi(()->{
            Layout layout=body.getLayout();
            Rect visible=new Rect();
            if(layout==null||!body.getLocalVisibleRect(visible))return;
            int pad=body.getTotalPaddingTop();
            p.count=layout.getLineCount();p.firstTop=pad+layout.getLineTop(0);
            p.lastBottom=pad+layout.getLineBottom(p.count-1);
            p.visibleTop=visible.top;p.visibleBottom=visible.bottom;
            p.first=visible.top<=p.firstTop+1 && visible.bottom>=pad+layout.getLineBottom(0)-1;
            p.last=visible.top<=pad+layout.getLineTop(p.count-1)+1 && visible.bottom>=p.lastBottom-1;
            p.direction=layout.getParagraphDirection(0);p.scroll=scroller(body).getScrollY();
            String content=body.getText().toString();
            Rect ink=new Rect();
            for(int i=0;i<p.count;i++) {
                if(Math.abs(visible.bottom-(pad+layout.getLineBottom(i)))<=1)p.alignedAfterLine=true;
                int start=layout.getLineStart(i),end=layout.getLineVisibleEnd(i);
                if(end<=start)continue;
                body.getPaint().getTextBounds(content,start,end,ink);
                int inkTop=pad+layout.getLineBaseline(i)+ink.top;
                int inkBottom=pad+layout.getLineBaseline(i)+ink.bottom;
                if(inkTop>=visible.top-1 && inkBottom<=visible.bottom+1)p.completeLines++;
                if(visible.top>inkTop+1 && visible.top<inkBottom-1)p.clippedTopInk=true;
                if(visible.bottom>inkTop+1 && visible.bottom<inkBottom-1)p.clippedBottomInk=true;
            }
        });
        return p;
    }
    private void swipeInside(ScrollView view,boolean towardsEnd)throws Exception{
        Rect viewport=new Rect();int[] rootOnScreen=new int[2];int[] offset=new int[1];
        test.onUi(()->{
            // Global visible bounds are in the window root, independent of a ScrollView's content offset.
            if(!view.getGlobalVisibleRect(viewport))throw new AssertionError("caption viewport is offscreen");
            view.getRootView().getLocationOnScreen(rootOnScreen);
            viewport.offset(rootOnScreen[0],rootOnScreen[1]);offset[0]=view.getScrollY();
        });
        float x=viewport.centerX(),y1=towardsEnd?viewport.bottom-8:viewport.top+8,y2=towardsEnd?viewport.top+8:viewport.bottom-8;
        long start=SystemClock.uptimeMillis();
        for(int i=0;i<=8;i++){
            int action=i==0?MotionEvent.ACTION_DOWN:i==8?MotionEvent.ACTION_UP:MotionEvent.ACTION_MOVE;
            MotionEvent event=MotionEvent.obtain(start,SystemClock.uptimeMillis(),action,x,y1+(y2-y1)*i/8,0);
            event.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            test.getUiAutomation().injectInputEvent(event,true);event.recycle();
            SystemClock.sleep(45);
        }
        SystemClock.sleep(450);
        int[] after=new int[1];test.onUi(()->after[0]=view.getScrollY());
        Bundle fingerprint=new Bundle();
        fingerprint.putString("touch_path",viewport.toShortString()+" x="+(int)x+" y="+(int)y1+".."+(int)y2+
                " scroll="+offset[0]+".."+after[0]);test.sendStatus(2,fingerprint);
    }
    private int muteTop() throws Exception {
        test.await(()->test.button(null,"静音")!=null||test.button(null,"Mute")!=null,"native mute control accessible in narrow portrait");
        AccessibilityNodeInfo node=test.button(null,"静音");
        if(node==null)node=test.button(null,"Mute");
        Rect b=new Rect();node.getBoundsInScreen(b);return b.top;
    }
    private void publish(String expected)throws Exception{
        test.utterance(owner,stale);
        test.await(()->expected.equals(coreText("subtitle"))&&text(expected)!=null,"translated fixture visible in production UI");
        SystemClock.sleep(600);
    }
    private void prepared()throws Exception {
        Context c=test.activity;
        test.core("setKey",new Class<?>[]{Context.class,String.class},c,OfflineGemini.KEY);
        test.core("setTarget",new Class<?>[]{Context.class,String.class},c,"zh-Hans");
        test.core("setEnabled",new Class<?>[]{Context.class,boolean.class},c,true);
        OfflineGemini.install(true);
        test.core("mediaStarted",new Class<?>[]{Object.class,Context.class,int.class},owner,c,16000);
        test.await(()->coreText("status").contains("等待"),"production service ready");
        test.render("call");
        test.await(()->text(coreText("status"))!=null,"idle status visible in rendered call");
    }
    private void retire()throws Exception {
        test.core("mediaStopped",new Class<?>[]{Object.class},owner);
        test.core("setEnabled",new Class<?>[]{Context.class,boolean.class},test.activity,false);
        test.core("setKey",new Class<?>[]{Context.class,String.class},test.activity,"");
    }
    void run(boolean old)throws Exception {
        prepared();
        try {
            if(!old)test.snapshot("idle");
            publish(OfflineGemini.FIRST);
            int shortTop=old?0:muteTop();
            publish(OfflineGemini.LONG);
            TextView body=text(OfflineGemini.LONG);
            Lines initial=lines(body);
            test.require(initial.count>=5,"translated fixture spans at least five actual rendered lines");
            test.require(OfflineGemini.FIRST.equals(coreText("previousSubtitle")),"previous translation retained behind long utterance");
            if(old) {
                test.require(!initial.first && initial.last,"25.2 regression reproduced: clipped first line with tail already visible");
                test.snapshot("old-long-tail");
                return;
            }
            Bundle initialGeometry=new Bundle();
            initialGeometry.putString("visible_first","viewport="+initial.visibleTop+".."+initial.visibleBottom+", complete_lines="+initial.completeLines+", clipped_bottom="+initial.clippedBottomInk);
            test.sendStatus(2,initialGeometry);
            test.require(initial.first&&!initial.last,"long mixed Chinese/English utterance begins at its complete first line");
            int longTop=muteTop();test.require(Math.abs(shortTop-longTop)<=2,"native mute button remains still between short and long sentence");
            test.snapshot("long-start");
            test.require(initial.completeLines>=3&&!initial.clippedBottomInk&&initial.alignedAfterLine,
                    "first viewport ends at a rendered line boundary with three complete lines and no truncated glyphs");
            TextView history=text(OfflineGemini.FIRST);
            test.require(history!=null,"previous sentence appears beneath the current translation");
            test.onUi(()->{
                Rect currentRect=new Rect(),historyRect=new Rect();
                body.getGlobalVisibleRect(currentRect);history.getGlobalVisibleRect(historyRect);
                int gap=Math.round(2*body.getResources().getDisplayMetrics().density);
                test.require(historyRect.top>=currentRect.bottom+gap,"previous sentence separated from current viewport");
            });
            ScrollView scroll=scroller(body);
            for(int i=0;i<10&&!lines(body).last;i++) {
                swipeInside(scroll,true);
            }
            Lines end=lines(body);
            test.require(end.last&&!end.first&&end.scroll>initial.scroll,"touch swipe inside long caption reaches complete final line");
            SystemClock.sleep(1200);
            test.require(lines(body).scroll==end.scroll,"UI refresh preserves manual reading position");
            test.snapshot("long-end");
            Bundle endGeometry=new Bundle();
            endGeometry.putString("visible_end","viewport="+end.visibleTop+".."+end.visibleBottom+", complete_lines="+end.completeLines+", clipped_top="+end.clippedTopInk);test.sendStatus(2,endGeometry);
            test.require(!end.clippedTopInk && end.completeLines>=3,"settled final viewport starts on complete glyphs");
            for(int i=0;i<10&&!lines(body).first;i++)swipeInside(scroll,false);
            test.require(lines(body).first,"reverse touch swipes return to complete first line");
            // Start partway down again to distinguish a genuine repeat from a UI refresh.
            swipeInside(scroll,true);
            test.require(!lines(body).first,"reader scrolled below first line before repeated utterance");
            test.utterance(owner,stale);
            test.await(()->OfflineGemini.requests.get()==3 && OfflineGemini.LONG.equals(coreText("previousSubtitle"))
                    && lines(body).first,"identical consecutive utterance resets to its first line");
            test.core("setTarget",new Class<?>[]{Context.class,String.class},test.activity,"ar");
            test.await(()->coreText("status").contains("等待") && coreText("subtitle").isEmpty(),"switching target clears previous language");
            publish(OfflineGemini.ARABIC);
            TextView arabic=text(OfflineGemini.ARABIC);Lines rtl=lines(arabic);
            test.require(rtl.direction<0 && rtl.first,"Arabic with Latin booking reference uses RTL paragraph layout");
            test.snapshot("rtl");
            test.utterance(owner,stale);
            test.await(()->coreText("status").contains("拒绝") && text(coreText("status"))!=null,"403 error shown alongside last available translation");
            test.require(text(OfflineGemini.ARABIC)!=null,"last translated sentence remains available during provider error");
            test.snapshot("error");
            Bundle data=new Bundle();
            data.putString("reading_geometry","lines="+initial.count+", initial="+initial.scroll+", end="+end.scroll+", mute_short="+shortTop+", mute_long="+longTop+", rtl_direction="+rtl.direction);
            test.sendStatus(2,data);
        } finally {retire();}
    }
}
