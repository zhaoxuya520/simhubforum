package captionprobe;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;

/** Exercises the installed dial pad, settings composable and synthetic active-call composable on Android. */
public final class CaptionsArt extends Instrumentation {
    private static final String PKG = "cc.forserein.simhub";
    Activity activity;
    private ClassLoader loader;
    private Bundle options;
    private int checks;
    private final List<String> evidence = new ArrayList<>();
    interface Work { void run() throws Exception; }
    interface Check { boolean passes() throws Exception; }

    @Override public void onCreate(Bundle args) { super.onCreate(args); options = args; start(); }
    void require(boolean value, String label) {
        if (!value) throw new AssertionError(label);
        checks++;
        evidence.add(label);
    }
    void onUi(Work work) throws Exception {
        Throwable[] error = {null};
        runOnMainSync(() -> { try { work.run(); } catch (Throwable e) { error[0] = e; } });
        if (error[0] != null) throw new Exception(error[0]);
    }
    private Class<?> cls(String name) throws Exception { return Class.forName(name, true, loader); }
    private Object call(String clazz, String method, Class<?>[] args, Object... values) throws Exception {
        return cls(clazz).getMethod(method,args).invoke(null, values);
    }
    Object core(String method, Class<?>[] args, Object... values) throws Exception {
        return call(PKG+".internal.CallCaptions",method,args,values);
    }
    private Object unit() throws Exception { return cls("sc5").getField("a").get(null); }
    private interface Body { Object run(Object[] args) throws Exception; }
    private Object callback(String name, Body body) throws Exception {
        return Proxy.newProxyInstance(loader, new Class<?>[]{cls(name)}, (proxy, method, args) -> {
            if (method.getDeclaringClass() == Object.class) {
                if (method.getName().equals("equals")) return proxy == args[0];
                if (method.getName().equals("hashCode")) return System.identityHashCode(proxy);
                return "caption probe";
            }
            return body.run(args);
        });
    }
    private Object compose(int key, Object callback) throws Exception {
        return cls("zn0").getConstructor(int.class,boolean.class,cls("gt1")).newInstance(key,true,callback);
    }
    void render(String screen) throws Exception {
        if (screen.equals("wifi")) fixtureWifiCard();
        Object idle=callback("us1",args->unit());
        Object scope=cls("em0").getField("a").get(null);
        Object settings=activity.getApplication().getClass().getMethod("a").invoke(activity.getApplication());
        Object padding=cls("ik3").getConstructor(float.class,float.class,float.class,float.class).newInstance(0f,0f,0f,0f);
        Object active=cls("v00").getField("a").get(null);
        long now=System.currentTimeMillis();
        Object model=cls("u00").getConstructor(String.class,String.class,String.class,boolean.class,cls("b10"),Long.class,long.class,
                boolean.class,String.class,String.class,boolean.class,boolean.class).newInstance(
                "offline-call","00123","字幕测试",false,active,Long.valueOf(now),now,false,"测试线路","fixture",false,false);
        Object body=callback("kt1",args->{
            if (screen.equals("wifi")) {
                call("yd2","j",new Class<?>[]{cls("us1"),cls("lu1"),int.class},idle,args[0],0);
            } else if (screen.equals("dialer")) {
                call("f2","a",new Class<?>[]{cls("em0"),String.class,boolean.class,cls("us1"),cls("lu1"),int.class,int.class},
                        scope,"",true,idle,args[0],0,0);
            } else if (screen.equals("settings")) {
                call("r75","j",new Class<?>[]{cls("eg"),cls("ik3"),cls("lu1"),int.class},
                        settings,padding,args[0],0);
            } else {
                call("d20","c",new Class<?>[]{cls("u00"),boolean.class,String.class,cls("us1"),cls("us1"),cls("lu1"),int.class},
                        model,false,null,idle,idle,args[0],0);
            }
            return unit();
        });
        Object inner=compose(2510001,body);
        Object theme=callback("kt1",args->{
            call("z55","a",new Class<?>[]{cls("zn0"),cls("lu1"),int.class},inner,args[0],0);
            return unit();
        });
        Object content=compose(2510002,theme);
        onUi(()->{
            // The full reader normally supplies the system bar insets around these child screens.
            View decor=activity.getWindow().getDecorView();
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            if(android.os.Build.VERSION.SDK_INT>=30)activity.getWindow().setDecorFitsSystemWindows(true);
            activity.getWindow().setStatusBarColor(android.graphics.Color.WHITE);
            activity.getWindow().setNavigationBarColor(android.graphics.Color.WHITE);
            call("sn0","a",new Class<?>[]{cls("rn0"),cls("zn0")},activity,content);
        });
    }
    private void fixtureWifiCard() throws Exception {
        cls("zl5").getField("f").set(null,getTargetContext());
        Object flow=cls("zl5").getField("b").get(null);
        Object old=flow.getClass().getMethod("getValue").invoke(flow);
        Object card=cls("ek5").getConstructors()[0].newInstance("515660000000001","8963660000000000001",2,"","","+639980000001","",null);
        Object config=call(PKG+".internal.DitoCarrierProfile","defaults",new Class<?>[]{Object.class},card);
        Object[] args=new Object[20];
        for(int i=0;i<20;i++) args[i]=old.getClass().getField(String.valueOf((char)('a'+i))).get(old);
        args[4]=card;args[5]=config;args[6]=false;args[7]=null;args[8]="+639980000001";args[11]=false;args[17]=false;
        Object updated=old.getClass().getConstructors()[0].newInstance(args);
        flow.getClass().getMethod("i",Object.class).invoke(flow,updated);
    }
    private String storedDomain() throws Exception {
        Object snap=call(PKG+".internal.WifiConfigRuntime","snapshot",new Class<?>[]{});
        return (String)((java.util.Map<?,?>)snap.getClass().getField("values").get(snap)).get("domain");
    }
    private void wifiSettings() throws Exception {
        render("wifi");
        click(null,"Domain");
        await(()->button("EditText",null)!=null,"editable Wi-Fi domain");
        snapshot("wifi-domain");
        Bundle text=new Bundle();
        text.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,"ui-test.example.org");
        require(button("EditText",null).performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,text),"edit domain");
        click(null,"保存");
        await(()->"ui-test.example.org".equals(storedDomain()),"save persisted through Wi-Fi editor");
        click(null,"Domain");
        click(null,"重置为内置");
        await(()->storedDomain()==null,"restore built-in domain");
    }
    void snapshot(String name) throws Exception {
        // Accessibility callbacks precede the compositor by a frame on some Android versions.
        try { getUiAutomation().waitForIdle(300,3000); }
        catch(java.util.concurrent.TimeoutException ignored) {}
        SystemClock.sleep(350);
        Bitmap bitmap=getUiAutomation().takeScreenshot();
        require(bitmap!=null,name+" screenshot available");
        try {
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG,100,bytes);
            Bundle result=new Bundle();
            result.putString("capture",name);
            result.putString("png_base64",Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP));
            sendStatus(1,result);
        } finally { bitmap.recycle(); }
    }
    private AccessibilityNodeInfo root() { return getUiAutomation().getRootInActiveWindow(); }
    private void collect(AccessibilityNodeInfo node,int depth,StringBuilder out) {
        if (node==null||depth>35) return;
        if (node.isVisibleToUser()) {
            CharSequence text=node.getText(), label=node.getContentDescription();
            if (text!=null||label!=null) {
                Rect bounds=new Rect();node.getBoundsInScreen(bounds);
                out.append(text).append('|').append(label).append('|').append(bounds).append('\n');
            }
        }
        for(int i=0;i<node.getChildCount();i++)collect(node.getChild(i),depth+1,out);
    }
    private String tree() {StringBuilder out=new StringBuilder();collect(root(),0,out);return out.toString();}
    void await(Check check,String what) throws Exception {
        long end=SystemClock.uptimeMillis()+45000;
        do {if(check.passes()){require(true,what);return;} SystemClock.sleep(200);} while(SystemClock.uptimeMillis()<end);
        throw new AssertionError(what+"\n"+tree());
    }
    private AccessibilityNodeInfo find(AccessibilityNodeInfo node,String type,String label) {
        if(node==null)return null;
        String clazz=String.valueOf(node.getClassName());
        String text=String.valueOf(node.getText()), description=String.valueOf(node.getContentDescription());
        if(node.isVisibleToUser() && (type==null||clazz.endsWith(type)) && (label==null||text.contains(label)||description.contains(label)))return node;
        for(int i=0;i<node.getChildCount();i++){
            AccessibilityNodeInfo match=find(node.getChild(i),type,label);
            if(match!=null)return match;
        }
        return null;
    }
    AccessibilityNodeInfo button(String type,String label) { return find(root(),type,label); }
    void click(String type,String label)throws Exception {
        await(()->button(type,label)!=null,"visible "+label);
        AccessibilityNodeInfo node=button(type,label);
        while(node!=null&&!node.isClickable())node=node.getParent();
        require(node!=null&&node.performAction(AccessibilityNodeInfo.ACTION_CLICK),"clicked "+label);
    }
    private void type(String label,String value)throws Exception{
        await(()->button("EditText",label)!=null,"field "+label);
        Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,value);
        require(button("EditText",label).performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b),"field input "+label);
    }
    private void choose(String code,String name)throws Exception{
        type("搜索字幕语言",code);
        click("TextView",name);
    }
    private boolean enabled() throws Exception {return (Boolean)core("enabled",new Class<?>[]{Context.class},activity);}
    private String target() throws Exception {return (String)core("target",new Class<?>[]{Context.class},activity);}
    private void configureDialer() throws Exception {
        Context c=activity;
        core("setEnabled",new Class<?>[]{Context.class,boolean.class},c,false);
        core("setTarget",new Class<?>[]{Context.class,String.class},c,"zh-Hans");
        core("setKey",new Class<?>[]{Context.class,String.class},c,"");
        render("dialer");
        click("Switch","通话翻译");
        await(()->button("EditText","服务器配对链接")!=null,"first-use setup");
        require(!enabled(),"unconfigured switch remains off");
        type("服务器配对链接",OfflineGemini.KEY);
        click("Button","保存");
        await(this::enabled,"enabled after user save");
        await(()->button("TextView","字幕语言，")!=null,"dialer target selector available");
        click("TextView","字幕语言，");
        choose("en","英语");
        await(()->"en".equals(target()),"language changed in dialer");
        await(()->button("TextView","字幕语言，英语")!=null,"dialer renders English selection");
        snapshot("dialer");
    }
    private void revealSettings()throws Exception {
        for(int i=0;i<8&&button("TextView","通话翻译")==null;i++){
            android.os.SystemClock.sleep(750);
            if(button("TextView","通话翻译")!=null)return;
            android.util.DisplayMetrics d=activity.getResources().getDisplayMetrics();
            float startX=d.widthPixels/2f,startY=d.heightPixels*0.78f,endY=d.heightPixels*0.28f;
            long now=SystemClock.uptimeMillis();
            android.view.MotionEvent down=android.view.MotionEvent.obtain(now,now,0,startX,startY,0);
            down.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN); getUiAutomation().injectInputEvent(down,true);down.recycle();
            for(int step=1;step<=6;step++){
                SystemClock.sleep(35);
                android.view.MotionEvent move=android.view.MotionEvent.obtain(now,SystemClock.uptimeMillis(),2,startX,startY+(endY-startY)*step/6,0);
                move.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);getUiAutomation().injectInputEvent(move,true);move.recycle();
            }
            android.view.MotionEvent up=android.view.MotionEvent.obtain(now,SystemClock.uptimeMillis(),1,startX,endY,0);
            up.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);getUiAutomation().injectInputEvent(up,true);up.recycle();
        }
    }
    private void configureSettings()throws Exception{
        require(enabled()&&"en".equals(target()),"selection survives application restart");
        render("settings");
        revealSettings();
        click("TextView","通话翻译");
        await(()->button("Switch","通话字幕")!=null,"native settings form");
        click(null,"字幕语言，");
        choose("zh-Hans","简体中文");
        await(()->button(null,"字幕语言，简体中文")!=null,"settings renders selected Chinese target");
        snapshot("settings");
        click("Button","保存");
        await(()->"zh-Hans".equals(target()),"settings and dialer share target preference");
    }
    private void swipePage(boolean forward) {
        android.util.DisplayMetrics d=activity.getResources().getDisplayMetrics();
        // Start outside the inner caption ScrollView so this gesture drives the whole page.
        float x=d.widthPixels*.13f, y1=d.heightPixels*(forward?.81f:.24f), y2=d.heightPixels*(forward?.24f:.81f);
        long down=SystemClock.uptimeMillis();
        for(int i=0;i<=9;i++){
            int action=i==0?android.view.MotionEvent.ACTION_DOWN:i==9?android.view.MotionEvent.ACTION_UP:android.view.MotionEvent.ACTION_MOVE;
            android.view.MotionEvent e=android.view.MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,x,y1+(y2-y1)*i/9,0);
            e.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);
            getUiAutomation().injectInputEvent(e,true);
            e.recycle();
            SystemClock.sleep(36);
        }
        SystemClock.sleep(280);
    }
    private boolean clickableAt(AccessibilityNodeInfo n,int x,int y) {
        if(n==null)return false;
        Rect b=new Rect();n.getBoundsInScreen(b);
        if(n.isVisibleToUser()&&n.isClickable()&&b.contains(x,y))return true;
        for(int i=0;i<n.getChildCount();i++)if(clickableAt(n.getChild(i),x,y))return true;
        return false;
    }
    private Rect hangupBounds() {
        Bitmap shot=getUiAutomation().takeScreenshot();
        if(shot==null)return null;
        try {
            int width=shot.getWidth(),height=shot.getHeight();
            int min=Math.round(activity.getResources().getDisplayMetrics().density*36);
            int[] row=new int[width];
            Rect red=null;
            for(int y=0;y<height;y+=3) {
                shot.getPixels(row,0,width,0,y,width,1);
                int start=0;
                for(int x=0;x<width;x++){
                    int pixel=row[x];
                    if(android.graphics.Color.red(pixel)>210&&android.graphics.Color.green(pixel)<115&&android.graphics.Color.blue(pixel)<110)continue;
                    if(x-start>=min && start+min<width*.75f && x>width*.25f) {
                        if(red==null)red=new Rect(start,y,x,y+1);
                        else red.union(start,y,x,y+1);
                    }
                    start=x+1;
                }
            }
            if(red==null||red.height()<min||!clickableAt(root(),red.centerX(),red.centerY()))return null;
            return red;
        } finally {shot.recycle();}
    }
    private void revealOnShortScreen(String label) throws Exception {
        for(int i=0;i<6 && button(null,label)==null;i++)swipePage(true);
        await(()->button(null,label)!=null,"can scroll to "+label);
    }
    void utterance(Object owner,Object stale)throws Exception {
        short[] other=new short[320],sound=new short[320],silence=new short[320];
        java.util.Arrays.fill(other,(short)9100);
        for(int i=0;i<sound.length;i++)sound[i]=(short)((i/20)%2==0?2600:-2600);
        Method input=cls(PKG+".internal.CallCaptions").getMethod("remotePcm",Object.class,short[].class);
        for(int i=0;i<16;i++){
            input.invoke(null,stale,other);input.invoke(null,owner,sound);SystemClock.sleep(20);
        }
        for(int i=0;i<34;i++){input.invoke(null,owner,silence);SystemClock.sleep(20);}
    }
    private void showCaption(boolean landscape)throws Exception{
        if(landscape) {
            core("setKey",new Class<?>[]{Context.class,String.class},activity,OfflineGemini.KEY);
            core("setTarget",new Class<?>[]{Context.class,String.class},activity,"zh-Hans");
            core("setEnabled",new Class<?>[]{Context.class,boolean.class},activity,true);
            require(activity.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE,
                    "real landscape configuration");
        }
        require(enabled()&&"zh-Hans".equals(target()),"settings target persists in call process");
        OfflineGemini.install();
        Object owner=new Object(),stale=new Object();
        core("mediaStarted",new Class<?>[]{Object.class,Context.class,int.class},owner,activity,16000);
        await(()->((String)core("status",new Class<?>[]{})).contains("等待"),"remote caption backend ready");
        render("call");
        if (!landscape) {
            await(()->button(null,"通话翻译设置")!=null,"gear available");
            Rect gear=new Rect(); button(null,"通话翻译设置").getBoundsInScreen(gear);
            require(gear.centerX()>activity.getResources().getDisplayMetrics().widthPixels*.7f,"gear at right side");
            click(null,"通话翻译设置");
            click(null,"译音语言，");
            type("搜索译音语言","ja");
            click("TextView","日语");
            click(null,"测试密钥");
            await(()->button(null,"授权失败")!=null,"separate model test results");
            snapshot("gear-settings");
            click("Button","保存");
            require(target().equals("zh-Hans") && "ja".equals(core("voiceTarget",new Class<?>[]{Context.class},activity)),
                    "voice language saved independently");
        }
        if(landscape)revealOnShortScreen("通话字幕");
        await(()->button("TextView","通话字幕")!=null,"native call shows subtitle controls");
        for(String expected:new String[]{OfflineGemini.FIRST,OfflineGemini.EXAMPLE}) {
            utterance(owner,stale);
            await(()->expected.equals(core("subtitle",new Class<?>[]{})),"fixture response passes production parser");
        }
        require(OfflineGemini.FIRST.equals(core("previousSubtitle",new Class<?>[]{})),"previous utterance retained");
        if(landscape)revealOnShortScreen(OfflineGemini.EXAMPLE);
        await(()->button("TextView",OfflineGemini.EXAMPLE)!=null,"translated fixture text visible in call");
        require(OfflineGemini.error==null&&OfflineGemini.requests.get()==2,"two individually requested utterances, current owner PCM only");
        Rect currentBounds=new Rect();
        button("TextView",OfflineGemini.EXAMPLE).getBoundsInScreen(currentBounds);
        if(landscape) {
            snapshot("call-landscape");
            revealOnShortScreen("静音");
            require(button(null,"扬声器")!=null && button(null,"拨号键盘")!=null,"native speaker and keypad reachable");
            for(int i=0;i<6&&hangupBounds()==null;i++)swipePage(true);
            Rect end=hangupBounds();
            require(end!=null,"native hangup is visible and hit-testable");
            Bundle geometry=new Bundle();geometry.putString("hangup",end.toShortString());
            geometry.putString("subtitle",currentBounds.toShortString());sendStatus(2,geometry);
            snapshot("landscape-controls");
            for(int i=0;i<6&&button(null,"字幕测试")==null;i++)swipePage(false);
            await(()->button(null,"字幕测试")!=null,"caller details reachable again by scrolling back");
        } else {
            AccessibilityNodeInfo mute=button(null,"Mute");
            if(mute==null)mute=button(null,"静音");
            require(mute!=null,"native mute control visible");
            Rect muteBounds=new Rect();mute.getBoundsInScreen(muteBounds);
            require(currentBounds.height()>0 && currentBounds.bottom<=muteBounds.top,"subtitles clear native mute control");
            snapshot("call");
        }
        core("mediaStopped",new Class<?>[]{Object.class},stale);
        require(OfflineGemini.EXAMPLE.equals(core("subtitle",new Class<?>[]{})),"stale hangup preserves current call");
        core("mediaStopped",new Class<?>[]{Object.class},owner);
        await(()->"".equals(core("subtitle",new Class<?>[]{})),"hangup clears subtitles");
        core("setEnabled",new Class<?>[]{Context.class,boolean.class},activity,false);
        await(()->button("TextView","通话字幕")==null,"disabled captions disappear");
        core("setKey",new Class<?>[]{Context.class,String.class},activity,"");
    }
    private void test(String mode)throws Exception {
        if ("true".equals(options.getString("baseline","false"))) {
            render(mode);
            await(()->!tree().isEmpty(),"native screen "+mode+" visible");
            SystemClock.sleep(1500);
            Bundle dump=new Bundle();dump.putString("screen",mode);dump.putString("hierarchy",tree());sendStatus(2,dump);
            snapshot(mode);
        } else if(mode.equals("reading")||mode.equals("reading-baseline"))new ReadingProbe(this).run(mode.equals("reading-baseline"));
        else if(mode.equals("wifi"))wifiSettings();
        else if(mode.equals("dialer"))configureDialer();
        else if(mode.equals("settings"))configureSettings();
        else showCaption(mode.equals("landscape"));
    }
    @Override public void onStart() {
        Bundle result=new Bundle();Throwable error=null;
        try {
            loader=getTargetContext().getClassLoader();
            activity=startActivitySync(new Intent().setClassName(PKG,PKG+".MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            waitForIdleSync();
            test(options.getString("screen","dialer"));
        } catch(Throwable e){error=e;}
        result.putString("status",error==null?"passed":"failed");
        result.putInt("checks",checks);result.putString("evidence",evidence.toString());
        if(error!=null)result.putString("error",android.util.Log.getStackTraceString(error));
        finish(error==null?0:1,result);
    }
}
