import android.content.SharedPreferences;
import cc.forserein.simhub.internal.WifiConfigModel;
import cc.forserein.simhub.internal.WifiConfigRuntime;
import cc.forserein.simhub.internal.WifiConfigValues;
import java.lang.reflect.Field;
import java.nio.file.Paths;
import java.util.*;

public final class ConfigStoreProbe {
    static final String DOMAIN = "ims.fixture.example.invalid", APN = "ims-fixture";
    static final String DEST = "+447700900123", BODY = "offline fixture";
    static final String SAVED = "+8613800100500", CARD_CENTER = "+447700900456";
    static final String RAW = "v1\ndomain\t"+DOMAIN+"\napn\t"+APN+"\nsmsc\t"+SAVED+"\nsmsc_list\t"+SAVED+" +8613800200500";
    static final String EMPTY = "v1\nsmsc_list\t[]";
    static final String INDENT = "\n    ";
    static int checks, sends;
    static String actualDest, actualBody, actualCenter;

    static void check(boolean b, String what) {
        if (!b) throw new AssertionError(what);
        checks++;
    }

    public static final class Prefs implements SharedPreferences {
        final Map<String, String> values = new HashMap<>();
        public String getString(String key, String fallback) {return values.getOrDefault(key, fallback);}
        public Editor edit() {
            return new Editor() {
                public Editor putString(String key, String value) {values.put(key,value);return this;}
                public Editor remove(String key) {values.remove(key);return this;}
                public boolean commit() {return true;}
            };
        }
    }

    public static final class Context extends android.content.Context {
        final Map<String, Prefs> prefs = new HashMap<>();
        public Prefs getSharedPreferences(String name, int mode) {
            return prefs.computeIfAbsent(name, ignored -> new Prefs());
        }
    }

    static Object create(String name, int arity, Object... args) throws Exception {
        return WifiConfigModel.constructor(Class.forName(name), arity).newInstance(args);
    }

    static Object get(Object o, String name) throws Exception {return WifiConfigModel.get(o,name);}

    static void set(Object o, String name, Object value) throws Exception {
        Field field=o.getClass().getField(name); field.setAccessible(true); field.set(o,value);
    }

    static Object instance(Class<?> c) throws Exception {
        Class<?> u = Class.forName("sun.misc.Unsafe");
        Field f = u.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        return u.getMethod("allocateInstance",Class.class).invoke(f.get(null),c);
    }

    static Object card(String iccid) throws Exception {
        return create("ek5",8,"234330000000001",iccid,2,null,null,CARD_CENTER,"+447700900002",null);
    }

    static Object newState(Object card, Object builtIn) throws Exception {
        Object phase = Class.forName("tk5").getField("g").get(null);
        return create("gl5",20,"SIM","offline",false,null,card,builtIn,false,"","",
                "490154203237518",phase,false,null,null,null,new ArrayList<>(),new ArrayList<>(),false,null,0L);
    }

    public static Object capture(String dest, String body, String center) throws Exception {
        sends++; actualDest=dest;actualBody=body;actualCenter=center;
        return Class.forName("pu0").getField("T").get(null);
    }

    static void runCase(Context context, String name, String record, boolean expectCustom,
                        String expectedError, String expectedCenter, boolean changedCard) throws Exception {
        Object card = card("8944000000000000001");
        Prefs prefs = context.getSharedPreferences("wifi_config_overrides_v1",0);
        String key=WifiConfigRuntime.cardKey(card);
        if(record==null)prefs.values.remove(key);else prefs.values.put(key,record);
        Object nativeConfig=WifiConfigModel.builtIn(card);
        Object effective=WifiConfigRuntime.resolve(card,nativeConfig);
        check("234".equals(get(nativeConfig,"d"))&&"33".equals(get(nativeConfig,"e")),name+" CTExcel UK MCC/MNC");
        check(!DOMAIN.equals(get(nativeConfig,"g"))&&!APN.equals(get(nativeConfig,"h")),name+" built-in distinct");
        check((expectCustom?DOMAIN:get(nativeConfig,"g")).equals(get(effective,"g")),name+" effective domain "+get(effective,"g"));
        check((expectCustom?APN:get(nativeConfig,"h")).equals(get(effective,"h")),name+" effective APN "+get(effective,"h"));
        Class<?> service=Class.forName("zl5");
        Object flow=service.getField("b").get(null);
        Object state=newState(card,nativeConfig);
        Object before=flow.getClass().getMethod("getValue").invoke(flow);
        check((Boolean)flow.getClass().getMethod("h",Object.class,Object.class).invoke(flow,before,state),name+" state publication");
        Object engine=instance(Class.forName("o82"));
        set(engine,"c",changedCard?card("8944000000000000002"):card);
        service.getField("n").set(null,engine);
        sends=0;actualDest=null;actualBody=null;actualCenter=null;
        service.getMethod("w",String.class,String.class,Class.forName("dt0")).invoke(service.getField("a").get(null),DEST,BODY,null);
        Object after=WifiConfigRuntime.state();
        if(expectedError!=null) {
            check(sends==0,name+" must stop before o82.D");
            check(expectedError.equals(get(after,"s")),name+" error="+get(after,"s"));
        } else {
            check(sends==1,name+" exactly one o82.D, state error="+get(after,"s"));
            check(DEST.equals(actualDest)&&BODY.equals(actualBody),name+" destination/body preserved");
            check(Objects.equals(expectedCenter,actualCenter),name+" center="+actualCenter);
        }
        System.out.println(name+" template="+get(nativeConfig,"c")+" builtin_domain="+get(nativeConfig,"g")
                +" domain="+get(effective,"g")+" apn="+get(effective,"h")+" send_calls="+sends
                +" smsc="+actualCenter+" error="+get(after,"s"));
    }

    /** Install the app's already-open preference handle via its real lazy container. */
    static void attachAuthorPreferences(Prefs prefs) throws Exception {
        Object settings=instance(Class.forName("ck5"));
        set(settings,"a",prefs);
        Object lazy=create("pz4",1,(Object)null);
        set(lazy,"U",settings);
        Object container=instance(Class.forName("eg"));
        set(container,"l",lazy);
        Object app=instance(Class.forName("cc.forserein.simhub.SimHubApp"));
        set(app,"T",container);
        Object provider=create("cg",2,app,6);
        Class<?> service=Class.forName("zl5");
        service.getField("h").set(null,provider);
        check(service.getMethod("j").invoke(null)==settings,"real legacy storage lookup");
    }

    public static void main(String[] args) throws Exception {
        boolean old=args[0].equals("previous-24-3");
        android.content.res.AssetManager.root=Paths.get(args[1]);
        Context context=new Context();
        Class.forName("zl5").getField("f").set(null,context);
        Class.forName("fj5").getField("d").set(null,context);
        runCase(context,"valid-saved",RAW,true,null,SAVED,false);
        runCase(context,"cold-saved",RAW+INDENT,!old,old?"配置记录损坏":null,SAVED,false);
        runCase(context,"valid-empty",EMPTY,false,"请先添加短信中心",null,false);
        runCase(context,"cold-empty",EMPTY+INDENT,false,old?"配置记录损坏":"请先添加短信中心",null,false);
        runCase(context,"builtin",null,false,null,old?null:CARD_CENTER,false);
        runCase(context,"card-changed",RAW,true,old?null:"卡片已切换，请重新连接 Wi-Fi 通话后发送短信",SAVED,true);
        Prefs author=context.getSharedPreferences("vowifi_sms",0);
        attachAuthorPreferences(author);
        String authorKey="vowifi_sms_smsc_8944000000000000001", oldNumber="+447700900789";
        author.values.put(authorKey," +44 (7700) 900789 ");
        runCase(context,"author-per-ICCID",null,false,null,old?null:oldNumber,false);
        runCase(context,"managed-over-author",RAW,true,null,SAVED,false);
        runCase(context,"managed-clear-over-author",EMPTY,false,"请先添加短信中心",null,false);
        runCase(context,"managed-domain-only","v1\ndomain\t"+DOMAIN+"\napn\t"+APN,true,null,old?null:CARD_CENTER,false);
        author.values.put(authorKey,"invalid");
        runCase(context,"invalid-author",null,false,null,old?null:CARD_CENTER,false);
        author.values.remove(authorKey);
        author.values.put("vowifi_sms_smsc_8944000000000000002",oldNumber);
        runCase(context,"other-card-author",null,false,null,old?null:CARD_CENTER,false);
        try {
            WifiConfigValues.decode("v1\ndomain\t"+DOMAIN+"\nmissing-separator\napn\t"+APN);
            throw new AssertionError("interior malformed entry silently accepted");
        } catch(IllegalArgumentException invalid) {check("配置记录损坏".equals(invalid.getMessage()),"genuine malformed entry");}
        System.out.println("NATIVE_CONFIG_STORE mode="+args[0]+" checks="+checks);
    }
}
