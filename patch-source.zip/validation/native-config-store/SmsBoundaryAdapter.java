import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Isolate database history and outgoing SMS I/O while preserving the complete native sender. */
public final class SmsBoundaryAdapter {
    public static void main(String[] args) throws Exception {
        int count=0;
        try(ZipFile in=new ZipFile(args[0]); ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Paths.get(args[1])))) {
            for(ZipEntry e:Collections.list(in.entries())) {
                byte[] bytes=in.getInputStream(e).readAllBytes();
                boolean send=e.getName().equals("o82.class"), history=e.getName().equals("xq0.class");
                if(send||history) {
                    ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);
                    for(MethodNode m:c.methods) {
                        String desc=send?"(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lvl5;)Ljava/lang/Object;":"(Lfu0;Lkt1;Lct0;)Ljava/lang/Object;";
                        if(!m.name.equals(send?"D":"g0")||!m.desc.equals(desc))continue;
                        m.instructions.clear();m.tryCatchBlocks.clear();
                        if(m.localVariables!=null)m.localVariables.clear();
                        if(send) {
                            for(int i=1;i<=3;i++)m.instructions.add(new VarInsnNode(Opcodes.ALOAD,i));
                            m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"ConfigStoreProbe","capture","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;",false));
                        } else m.instructions.add(new FieldInsnNode(Opcodes.GETSTATIC,"sc5","a","Lsc5;"));
                        m.instructions.add(new InsnNode(Opcodes.ARETURN));m.maxStack=send?3:1;count++;
                    }
                    ClassWriter w=new ClassWriter(0);c.accept(w);bytes=w.toByteArray();
                }
                out.putNextEntry(new ZipEntry(e.getName()));out.write(bytes);out.closeEntry();
            }
        }
        if(count!=2)throw new AssertionError("unexpected boundary count "+count);
    }
}
