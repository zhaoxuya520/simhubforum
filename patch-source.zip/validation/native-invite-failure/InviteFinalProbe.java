import java.lang.reflect.*;
import java.util.*;

/**
 * Normal outgoing call, user cancellation, and delayed final responses from an earlier transaction.
 */
public final class InviteFinalProbe {
  static int checks;
  static boolean legacy;
  static final String CALL_ID = "probe@example.invalid";
  static final String LOCAL = "<sip:local@example.invalid>;tag=local-tag";
  static final String PEER = "<sip:peer@example.invalid>";
  static final String ROUTE = "<sip:edge.example.invalid;lr>";
  static final String BRANCH = "z9hG4bK-invite-current";
  static final String OLD_BRANCH = "z9hG4bK-invite-earlier";

  static void check(boolean value, String label) {
    if (!value) throw new AssertionError(label);
    checks++;
  }

  static Object get(Object o, String f) throws Exception {
    return SipForkProbe.get(o, f);
  }

  static String first(Object m, String n) throws Exception {
    return SipForkProbe.first(m, n);
  }

  static void header(Object m, String n, String v) throws Exception {
    SipForkProbe.header(m, n, v);
  }

  static String via(String branch) {
    return "SIP/2.0/TCP 192.0.2.1:5060;branch=" + branch;
  }

  static class Call {
    final SipForkProbe.Session s = new SipForkProbe.Session(true);
    final t00 sink = new t00();

    Call() throws Exception {
      SipForkProbe.set(s.e, "N", sink);
      Object invite = get(s.d, "j");
      header(invite, "Via", via(BRANCH));
      header(invite, "Max-Forwards", "70");
      header(invite, "Route", ROUTE);
      header(invite, "Call-ID", CALL_ID);
      header(invite, "From", LOCAL);
      header(invite, "To", PEER);
      header(invite, "CSeq", "11 INVITE");
    }

    boolean response(int status, String reason, int seq, String method, String branch, String tag)
        throws Exception {
      Object response =
          SipForkProbe.msg
              .getConstructor(
                  boolean.class,
                  String.class,
                  String.class,
                  int.class,
                  String.class,
                  ArrayList.class,
                  byte[].class)
              .newInstance(false, method, "", status, reason, new ArrayList<>(), new byte[0]);
      header(response, "Via", via(branch));
      header(response, "Call-ID", CALL_ID);
      header(response, "From", LOCAL);
      header(response, "To", PEER + (tag == null ? "" : ";tag=" + tag));
      header(response, "CSeq", seq + " " + method);
      byte[] bytes = (byte[]) SipForkProbe.call(response, "b", new Class<?>[0]);
      Object parsed =
          Class.forName("jb4").getMethod("c", byte[].class).invoke(null, (Object) bytes);
      check(!"INVITE".equals(get(parsed, "b")), "native wire response carries its method in CSeq");
      return s.accept(parsed);
    }

    void selected() throws Exception {
      Object r =
          s.response(
              "A",
              SipForkProbe.A,
              "sip:A@example.invalid",
              "sip:proxy-A.example.invalid;lr",
              false);
      header(r, "Via", via(BRANCH));
      check(s.accept(r), "leg A selected by real 200");
      check(get(s.d, "D") != null, "actual selected ACK cached");
      sink.events.clear();
      s.packets().clear();
    }

    boolean live() throws Exception {
      return ((Map<?, ?>) get(s.m, "e")).get(CALL_ID) == s.d;
    }

    int failures() throws Exception {
      int count = 0;
      for (Object event : sink.events)
        if (event.getClass().getName().equals("eb4")) {
          Object reason = get(event, "b");
          if (reason.getClass().getName().equals("ta4") && ((Integer) get(reason, "l")) == 487)
            count++;
        }
      return count;
    }

    void expectWireAck(int index, String tag) throws Exception {
      Object ack = s.packets().get(index), invite = get(s.d, "j");
      check("ACK".equals(get(ack, "b")), "actual non-2xx ACK sent");
      check("11 ACK".equals(first(ack, "CSeq")), "ACK CSeq matches current outgoing INVITE");
      check(Objects.equals(get(ack, "c"), get(invite, "c")), "ACK uses original request URI");
      check(via(BRANCH).equals(first(ack, "Via")), "ACK reuses original Via branch");
      check(ROUTE.equals(first(ack, "Route")), "ACK retains original route");
      check((PEER + ";tag=" + tag).equals(first(ack, "To")), "ACK uses the final response To-tag");
      check(
          CALL_ID.equals(first(ack, "Call-ID")) && LOCAL.equals(first(ack, "From")),
          "ACK preserves dialog identity");
    }
  }

  static void remote() throws Exception {
    Call c = new Call();
    c.response(180, "Ringing", 11, "INVITE", BRANCH, "A");
    check(c.response(487, "Request Terminated", 11, "INVITE", BRANCH, "A"), "remote 487 consumed");
    check(
        !c.live() && c.failures() == 1,
        "true pending network termination ends once with original status");
    check(c.s.packets().size() == 1, "one ACK for the first final");
    c.expectWireAck(0, "A");
    boolean second = c.response(487, "Request Terminated", 11, "INVITE", BRANCH, "A");
    check(
        second != legacy && c.s.packets().size() == (legacy ? 1 : 2) && c.failures() == 1,
        "duplicate 487 repeats ACK only and never notifies failure twice");
    if (!legacy) {
      c.expectWireAck(1, "A");
      check(
          Arrays.equals(wire(c.s.packets().get(0)), wire(c.s.packets().get(1))),
          "replayed native ACK bytes identical");
    }
    System.out.println(
        "pending 487 duplicate: consumed="
            + second
            + ",packets="
            + c.s.packets().size()
            + ",failures="
            + c.failures());
  }

  static byte[] wire(Object message) throws Exception {
    return (byte[]) SipForkProbe.call(message, "b", new Class<?>[0]);
  }

  static void delayedAfterCancel() throws Exception {
    Call c = new Call();
    c.response(180, "Ringing", 11, "INVITE", BRANCH, "A");
    Object actions =
        SipForkProbe.call(c.s.m, "j", new Class<?>[] {String.class, double.class}, CALL_ID, 13.0);
    SipForkProbe.call(c.s.e, "k", new Class<?>[] {List.class}, actions);
    c.s.packets().clear();
    Object success = c.s.response("A", SipForkProbe.A, "sip:A@example.invalid", null, false);
    header(success, "Via", via(BRANCH));
    c.s.accept(success);
    check(
        c.s.packets().size() == 2
            && "ACK".equals(get(c.s.packets().get(0), "b"))
            && "BYE".equals(get(c.s.packets().get(1), "b")),
        "real success racing local cancellation retains ACK + BYE");
    check(c.failures() == 0, "CANCEL vs late 200 cannot fabricate 487");
  }

  static void unaffected() throws Exception {
    Call c = new Call();
    c.selected();
    c.response(487, "Request Terminated", 12, "UPDATE", "z9hG4bK-update", "A");
    check(
        c.live() && c.failures() == 0 && c.s.packets().isEmpty(),
        "UPDATE 487 stays on the native non-INVITE path");
    c = new Call();
    c.response(486, "Busy Here", 11, "INVITE", BRANCH, "A");
    check(
        !c.live() && c.s.packets().size() == 1 && c.failures() == 0,
        "other INVITE rejection preserved with original cause");
    c.expectWireAck(0, "A");
  }

  static void cacheLifetime() throws Exception {
    Call c = new Call();
    c.response(487, "Request Terminated", 11, "INVITE", BRANCH, "A");
    Class<?> helper = Class.forName("cc.forserein.simhub.internal.SipInviteFailure");
    Field cacheField = helper.getDeclaredField("CACHE");
    cacheField.setAccessible(true);
    Map<?, ?> cache = (Map<?, ?>) cacheField.get(null);
    Object bucket = cache.get(c.s.e);
    Field acksField = bucket.getClass().getDeclaredField("acks");
    acksField.setAccessible(true);
    Map<?, ?> acks = (Map<?, ?>) acksField.get(bucket);
    check(acks.size() == 1, "one per-engine cached ACK");
    Object entry = acks.values().iterator().next();
    Field created = entry.getClass().getDeclaredField("created");
    created.setAccessible(true);
    long original = created.getLong(entry);
    c.response(487, "Request Terminated", 11, "INVITE", BRANCH, "A");
    check(created.getLong(entry) == original, "retransmissions do not renew the deadline");
    created.setLong(entry, System.nanoTime() - 33_000_000_000L);
    int count = c.s.packets().size();
    check(
        !c.response(487, "Request Terminated", 11, "INVITE", BRANCH, "A")
            && c.s.packets().size() == count
            && acks.isEmpty(),
        "expired ACK removed after virtual elapsed lifetime");
    c = new Call();
    c.response(487, "Request Terminated", 11, "INVITE", BRANCH, "A");
    Call newer = new Call();
    ((Map<?, ?>) get(newer.s.m, "e")).clear();
    SipForkProbe.set(c.s.e, "J", newer.s.m);
    check(
        !c.response(487, "Request Terminated", 11, "INVITE", BRANCH, "A")
            && c.s.packets().size() == 1,
        "new registration manager has no old ACKs");
  }

  static void cancelled() throws Exception {
    Call c = new Call();
    c.response(180, "Ringing", 11, "INVITE", BRANCH, "A");
    Object actions =
        SipForkProbe.call(c.s.m, "j", new Class<?>[] {String.class, double.class}, CALL_ID, 12.0);
    SipForkProbe.call(c.s.e, "k", new Class<?>[] {List.class}, actions);
    check("CANCEL".equals(get(c.s.packets().get(0), "b")), "real local hangup issues CANCEL");
    check(
        "11 CANCEL".equals(first(c.s.packets().get(0), "CSeq")),
        "CANCEL targets the pending INVITE");
    c.response(200, "OK", 11, "CANCEL", BRANCH, "A");
    c.response(487, "Request Terminated", 11, "INVITE", BRANCH, "A");
    check(
        !c.live() && c.failures() == 0,
        "user cancellation completes without network-failure event");
    c.expectWireAck(1, "A");
  }

  static void delayedSelected() throws Exception {
    Call c = new Call();
    c.selected();
    c.response(487, "Request Terminated", 11, "INVITE", BRANCH, "B");
    System.out.println(
        "confirmed A followed by late 487 of B: live="
            + c.live()
            + ",failures="
            + c.failures()
            + ",packets="
            + c.s.packets().size());
    check(c.live() != legacy, "confirmed selected call survives delayed final for another leg");
    check(c.failures() == (legacy ? 1 : 0), "no failure event for the active call");
    check(c.s.packets().size() == 1, "acknowledge late non-2xx on actual original transaction");
    c.expectWireAck(0, "B");
  }

  static void staleTransaction() throws Exception {
    Call c = new Call();
    c.response(180, "Ringing", 11, "INVITE", BRANCH, "A");
    c.response(487, "Request Terminated", 10, "INVITE", OLD_BRANCH, "Old");
    System.out.println(
        "earlier CSeq10 followed by active CSeq11: live="
            + c.live()
            + ",failures="
            + c.failures()
            + ",packets="
            + c.s.packets().size());
    check(c.live() != legacy, "earlier INVITE response does not end the active outgoing INVITE");
    check(
        c.failures() == (legacy ? 1 : 0),
        "stale transaction cannot report failure of current transaction");
    check(
        c.s.packets().size() == (legacy ? 1 : 0),
        "cannot send present transaction's ACK for older INVITE");
    if (legacy) c.expectWireAck(0, "Old");
  }

  public static void main(String[] args) throws Exception {
    legacy = args[0].equals("legacy");
    SipForkProbe.msg = Class.forName("kb4");
    SipForkProbe.dialog = Class.forName("ma4");
    SipForkProbe.manager = Class.forName("cb4");
    SipForkProbe.direction = Class.forName("ga4");
    SipForkProbe.state = Class.forName("la4");
    SipForkProbe.helper = Class.forName("cc.forserein.simhub.internal.SipForkProtection");
    remote();
    cancelled();
    delayedAfterCancel();
    delayedSelected();
    staleTransaction();
    unaffected();
    if (!legacy) cacheLifetime();
    System.out.println("NATIVE_INVITE_FINAL mode=" + args[0] + " checks=" + checks);
  }
}
