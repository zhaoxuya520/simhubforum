import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

/**
 * Replays ordinary SIP final responses against the outgoing call dispatcher in the supplied APK.
 */
public final class InviteFailureStatusesProbe {
  static boolean previous;

  static class Failure {
    final int status;
    final String reason;
    final String extraHeader;

    Failure(int status, String reason, String extraHeader) {
      this.status = status;
      this.reason = reason;
      this.extraHeader = extraHeader;
    }
  }

  static final Failure BUSY = new Failure(486, "Busy Here", null);
  static final Failure UNAVAILABLE = new Failure(480, "Temporarily Unavailable", null);
  static final Failure DECLINED = new Failure(603, "Decline", null);
  static final Failure[] PENDING = {
    new Failure(302, "Moved Temporarily", "Contact: <sip:redirect@example.invalid>"),
    new Failure(
        401,
        "Unauthorized",
        "WWW-Authenticate: Digest realm=\"example.invalid\", nonce=\"fixture\""),
    new Failure(
        407,
        "Proxy Authentication Required",
        "Proxy-Authenticate: Digest realm=\"example.invalid\", nonce=\"fixture\""),
    new Failure(422, "Session Interval Too Small", "Min-SE: 1800"),
    UNAVAILABLE,
    BUSY,
    new Failure(491, "Request Pending", null),
    new Failure(500, "Server Internal Error", null),
    new Failure(503, "Service Unavailable", "Retry-After: 30"),
    DECLINED
  };

  static boolean deliver(
      InviteFinalProbe.Call call,
      Failure failure,
      String method,
      int sequence,
      String viaValue,
      String tag,
      boolean compact)
      throws Exception {
    return deliverWire(
        call,
        failure,
        method,
        sequence,
        compact ? "v" : "Via",
        viaValue,
        InviteFinalProbe.LOCAL,
        tag,
        "");
  }

  static boolean deliverWire(
      InviteFinalProbe.Call call,
      Failure failure,
      String method,
      int sequence,
      String viaHeader,
      String viaValue,
      String from,
      String tag,
      String body)
      throws Exception {
    boolean compact = viaHeader.equals("v");
    String packet =
        String.join(
            "\r\n",
            "SIP/2.0 " + failure.status + " " + failure.reason,
            viaHeader + ": " + viaValue,
            (compact ? "f" : "From") + ": " + from,
            (compact ? "t" : "To") + ": " + InviteFinalProbe.PEER + ";tag=" + tag,
            (compact ? "i" : "Call-ID") + ": " + InviteFinalProbe.CALL_ID,
            "CSeq: " + sequence + " " + method,
            (failure.extraHeader == null ? "" : failure.extraHeader + "\r\n")
                + "Content-Length: "
                + body.getBytes(StandardCharsets.US_ASCII).length,
            "",
            body);
    Object response =
        Class.forName("jb4")
            .getMethod("c", byte[].class)
            .invoke(null, (Object) packet.getBytes(StandardCharsets.US_ASCII));
    InviteFinalProbe.check(response != null, "native parser reads " + failure.status);
    return call.s.accept(response);
  }

  static boolean deliver(InviteFinalProbe.Call call, Failure failure, String tag) throws Exception {
    return deliver(
        call, failure, "INVITE", 11, InviteFinalProbe.via(InviteFinalProbe.BRANCH), tag, false);
  }

  static int verifyFailureEvents(InviteFinalProbe.Call call, Failure failure) throws Exception {
    int events = 0;
    for (Object event : call.sink.events) {
      if (!event.getClass().getName().equals("eb4")) continue;
      Object reason = InviteFinalProbe.get(event, "b");
      if (!reason.getClass().getName().equals("ta4")) continue;
      InviteFinalProbe.check(
          ((Integer) InviteFinalProbe.get(reason, "l")) == failure.status
              && failure.reason.equals(InviteFinalProbe.get(reason, "m")),
          "original status and reason reach the app");
      events++;
    }
    return events;
  }

  static void genuinePending(Failure failure) throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    call.response(180, "Ringing", 11, "INVITE", InviteFinalProbe.BRANCH, "A");
    InviteFinalProbe.check(
        deliver(call, failure, "A") && !call.live(), "current rejection ends attempt");
    InviteFinalProbe.check(verifyFailureEvents(call, failure) == 1, "one genuine network failure");
    InviteFinalProbe.check(call.s.packets().size() == 1, "native ACK without redial");
    call.expectWireAck(0, "A");
    boolean consumed = deliver(call, failure, "A");
    InviteFinalProbe.check(
        consumed != previous
            && call.s.packets().size() == (previous ? 1 : 2)
            && verifyFailureEvents(call, failure) == 1,
        "duplicate final and its single event");
    if (!previous) {
      InviteFinalProbe.check(
          Arrays.equals(
              InviteFinalProbe.wire(call.s.packets().get(0)),
              InviteFinalProbe.wire(call.s.packets().get(1))),
          "retransmitted ACK bytes");
    }
  }

  static void delayedAfter200(Failure failure, String tag) throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    call.selected();
    SipForkProbe.Snapshot established = new SipForkProbe.Snapshot(call.s.d);
    deliver(call, failure, tag);
    int failures = verifyFailureEvents(call, failure);
    InviteFinalProbe.check(
        call.live() != previous && failures == (previous ? 1 : 0),
        "late final cannot end confirmed dialog");
    InviteFinalProbe.check(call.s.packets().size() == 1, "one original-transaction ACK");
    call.expectWireAck(0, tag);
    if (!previous) established.unchanged("confirmed dialog " + failure.status);
    System.out.println(
        "confirmed + "
            + failure.status
            + " ("
            + tag
            + "): live="
            + call.live()
            + ", failures="
            + failures);
  }

  static void staleWhileRinging(Failure failure, int seq, String branch) throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    call.response(180, "Ringing", 11, "INVITE", InviteFinalProbe.BRANCH, "A");
    deliver(call, failure, "INVITE", seq, InviteFinalProbe.via(branch), "old", false);
    int failures = verifyFailureEvents(call, failure);
    InviteFinalProbe.check(
        call.live() != previous && failures == (previous ? 1 : 0),
        "late final from previous INVITE leaves current attempt intact");
    InviteFinalProbe.check(
        call.s.packets().size() == (previous ? 1 : 0),
        "earlier transaction cannot use current ACK fields");
    System.out.println(
        "earlier INVITE "
            + failure.status
            + " with active CSeq 11: live="
            + call.live()
            + ", ACKs="
            + call.s.packets().size());
  }

  static void cancelled(Failure failure) throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    call.response(180, "Ringing", 11, "INVITE", InviteFinalProbe.BRANCH, "A");
    Object actions =
        SipForkProbe.call(
            call.s.m,
            "j",
            new Class<?>[] {String.class, double.class},
            InviteFinalProbe.CALL_ID,
            12.0);
    SipForkProbe.call(call.s.e, "k", new Class<?>[] {List.class}, actions);
    InviteFinalProbe.check(
        "CANCEL".equals(InviteFinalProbe.get(call.s.packets().get(0), "b")),
        "local cancel requested");
    call.response(200, "OK", 11, "CANCEL", InviteFinalProbe.BRANCH, "A");
    deliver(call, failure, "A");
    InviteFinalProbe.check(
        !call.live() && verifyFailureEvents(call, failure) == 0,
        "local cancellation completes without a network-failure event");
    call.expectWireAck(1, "A");
  }

  static void nonInvite(Failure failure) throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    call.selected();
    deliver(call, failure, "UPDATE", 12, InviteFinalProbe.via("z9hG4bK-update"), "A", false);
    InviteFinalProbe.check(
        call.live() && verifyFailureEvents(call, failure) == 0 && call.s.packets().isEmpty(),
        "non-INVITE final continues through native handling");
  }

  static void responseViaList(String header, boolean quoted) throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    Failure failure = new Failure(487, "Request Terminated", null);
    String top = InviteFinalProbe.via(InviteFinalProbe.BRANCH);
    if (quoted) top = top.replace(";branch=", ";note=\"hop, one\";branch=");
    String list = top + ", SIP/2.0/TCP 192.0.2.80:5060;branch=z9hG4bK-other-hop";
    deliverWire(call, failure, "INVITE", 11, header, list, InviteFinalProbe.LOCAL, "A", "");
    System.out.println(
        "487 multi-value "
            + header
            + (quoted ? " quoted" : "")
            + ": live="
            + call.live()
            + ", ACKs="
            + call.s.packets().size());
    boolean oldParsing = previous && (!header.equals("v") || quoted);
    InviteFinalProbe.check(
        call.live() == oldParsing && verifyFailureEvents(call, failure) == (oldParsing ? 0 : 1),
        "multi-value Via parsing uses the first hop for transaction matching");
    if (!oldParsing) call.expectWireAck(0, "A");
  }

  static void differentLocalTag() throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    call.response(180, "Ringing", 11, "INVITE", InviteFinalProbe.BRANCH, "A");
    String otherFrom = InviteFinalProbe.LOCAL.replace("local-tag", "previous-local-tag");
    deliverWire(
        call,
        UNAVAILABLE,
        "INVITE",
        11,
        "Via",
        InviteFinalProbe.via(InviteFinalProbe.BRANCH),
        otherFrom,
        "old",
        "");
    InviteFinalProbe.check(
        call.live() != previous && call.s.packets().size() == (previous ? 1 : 0),
        "response with another originating dialog tag cannot end current call");
  }

  static void delayedProvisional(int code, boolean reliable, boolean ending) throws Exception {
    InviteFinalProbe.Call call = new InviteFinalProbe.Call();
    call.selected();
    if (ending) {
      Object actions =
          SipForkProbe.call(
              call.s.m,
              "j",
              new Class<?>[] {String.class, double.class},
              InviteFinalProbe.CALL_ID,
              13.0);
      SipForkProbe.call(call.s.e, "k", new Class<?>[] {List.class}, actions);
      InviteFinalProbe.check(
          "BYE".equals(InviteFinalProbe.get(call.s.packets().get(0), "b")),
          "actual local BYE starts ending the selected call");
      call.s.packets().clear();
      call.sink.events.clear();
    }
    SipForkProbe.Snapshot before = new SipForkProbe.Snapshot(call.s.d);
    String body = code == 183 ? SipForkProbe.B : "";
    String extra =
        "Contact: <sip:B@example.invalid>\r\nRecord-Route: <sip:edge-B.example.invalid;lr>";
    if (!body.isEmpty()) extra += "\r\nContent-Type: application/sdp";
    if (reliable) extra += "\r\nRequire: 100rel\r\nRSeq: 1";
    Failure provisional = new Failure(code, code == 180 ? "Ringing" : "Session Progress", extra);
    deliverWire(
        call,
        provisional,
        "INVITE",
        11,
        "Via",
        InviteFinalProbe.via(InviteFinalProbe.BRANCH),
        InviteFinalProbe.LOCAL,
        "B",
        body);
    String state = String.valueOf(InviteFinalProbe.get(call.s.d, "c"));
    System.out.println(
        "confirmed + "
            + code
            + " ending="
            + ending
            + " reliable="
            + reliable
            + ": state="
            + state
            + ", tag="
            + InviteFinalProbe.get(call.s.d, "l")
            + ", events="
            + call.sink.events.size()
            + ", packets="
            + call.s.packets().size());
    InviteFinalProbe.check(call.live(), "initial INVITE remains in the manager");
    if (previous) {
      InviteFinalProbe.check(
          "B".equals(InviteFinalProbe.get(call.s.d, "l")),
          "previous APK rewrites the established leg with the delayed provisional");
    } else {
      before.unchanged("no mutation after confirmed call received late " + code);
      InviteFinalProbe.check(
          call.sink.events.isEmpty() && call.s.packets().isEmpty(),
          "no extra media event or PRACK for a post-final provisional");
    }
  }

  public static void main(String[] args) throws Exception {
    previous = args[0].equals("previous-24-1");
    InviteFinalProbe.main(new String[] {"fixed"});
    int start = InviteFinalProbe.checks;
    for (Failure failure : PENDING) genuinePending(failure);
    delayedAfter200(BUSY, "A");
    for (Failure failure : PENDING) delayedAfter200(failure, "B");
    staleWhileRinging(UNAVAILABLE, 10, InviteFinalProbe.OLD_BRANCH);
    staleWhileRinging(DECLINED, 11, InviteFinalProbe.OLD_BRANCH);
    cancelled(BUSY);
    cancelled(DECLINED);
    nonInvite(UNAVAILABLE);
    responseViaList("v", false);
    responseViaList("via", false);
    responseViaList("Via", true);
    differentLocalTag();
    delayedProvisional(180, false, false);
    delayedProvisional(183, false, false);
    delayedProvisional(180, true, false);
    delayedProvisional(183, true, false);
    delayedProvisional(183, true, true);
    int progressChecks = ReliableProgressProbe.run(previous);
    System.out.println(
        "NATIVE_INVITE_STATUSES mode="
            + args[0]
            + " checks="
            + (InviteFinalProbe.checks - start + progressChecks));
  }
}
