#!/usr/bin/env python3
"""Replay normal outgoing SIP call events through the APK's dispatcher and dialog manager."""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, tempfile, zipfile

here = Path(__file__).resolve().parent
fork = here.parent / 'native-fork'
parser = argparse.ArgumentParser()
parser.add_argument('apk', type=Path)
parser.add_argument('--carrier-report', type=Path, required=True)
parser.add_argument('--unsigned-apk', type=Path)
parser.add_argument('--jar', type=Path)
versions = parser.add_mutually_exclusive_group()
versions.add_argument('--legacy', action='store_true', help='expect the 24.0 INVITE 487 behavior')
versions.add_argument('--previous-24-1', action='store_true', help='expect 24.1 behavior for other INVITE finals')
parser.add_argument('--report', type=Path, required=True)
a = parser.parse_args()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
carrier = json.loads(a.carrier_report.read_text())
jar = a.jar or a.carrier_report.parent / 'native-carrier-current' / 'probe.jar'
original_apk = a.unsigned_apk or a.apk
assert sha(original_apk) == carrier['apk_sha256']
assert sha(jar) == carrier['apk_translated_jar_sha256']
with zipfile.ZipFile(original_apk) as unsigned, zipfile.ZipFile(a.apk) as tested:
    dexes = {name for name in tested.namelist() if re.fullmatch(r'classes\d*\.dex',name)}
    assert dexes and dexes == {name for name in unsigned.namelist() if re.fullmatch(r'classes\d*\.dex',name)}
    dex_hashes = {}
    for name in sorted(dexes):
        data = tested.read(name)
        assert unsigned.read(name) == data
        dex_hashes[name] = hashlib.sha256(data).hexdigest()
kit = Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
lib = Path(os.environ.get('SIMHUB_DEX2JAR_TOOLS','/workspace/tools/dex2jar-v2.4')) / 'dex-tools-v2.4/lib'
asm = os.pathsep.join(str(lib / n) for n in ('asm-9.5.jar','asm-tree-9.5.jar'))
logs = []
a.report.parent.mkdir(parents=True,exist_ok=True)
def run(*args):
    result = subprocess.run(list(map(str,args)),capture_output=True,text=True)
    logs.append(result.stdout+result.stderr)
    a.report.with_suffix('.log').write_text('\n'.join(logs))
    if result.returncode:
        print(logs[-1]);raise SystemExit(result.returncode)
    return result.stdout
with tempfile.TemporaryDirectory(prefix='native-invite-',dir=a.report.parent) as work:
    work=Path(work)
    classes=work/'classes';classes.mkdir()
    fixture_sources=[fork/'g11.java',fork/'SipForkProbe.java',fork/'SipForkTransportAdapter.java',here/'InviteFinalProbe.java',here/'t00.java']
    if not a.legacy:
        fixture_sources.extend([here/'InviteFailureStatusesProbe.java', here/'ReliableProgressProbe.java'])
    run('java','-jar',kit/'ecj-3.40.0.jar','-17','-warn:none','-proc:none','-cp',asm,'-d',classes,*fixture_sources)
    adapted=work/'sip-fixture.jar'
    run('java','-cp',str(classes)+os.pathsep+asm,'SipForkTransportAdapter',jar,adapted)
    with zipfile.ZipFile(jar) as before,zipfile.ZipFile(adapted) as after:
        assert set(before.namelist())==set(after.namelist())
        assert sorted(n for n in before.namelist() if before.read(n)!=after.read(n))==['o82.class']
    assert all(p.stem.split('$')[0] in {q.stem for q in fixture_sources} for p in classes.rglob('*.class'))
    mode='legacy' if a.legacy else ('previous-24-1' if a.previous_24_1 else 'fixed')
    entry='InviteFinalProbe' if a.legacy else 'InviteFailureStatusesProbe'
    out=run('java','-noverify','-cp',os.pathsep.join(map(str,[classes,adapted,kit/'sdk/android-35/android.jar'])),entry,mode)
match=re.search(r'NATIVE_INVITE_FINAL mode=(legacy|fixed) checks=(\d+)',out)
assert match and match[1] == ('legacy' if a.legacy else 'fixed'), out
statuses = re.search(r'NATIVE_INVITE_STATUSES mode=([\w-]+) checks=(\d+)',out)
assert a.legacy or (statuses and statuses[1] == mode), out
extended = int(statuses[2]) if statuses else 0
result = dict(apk_sha256=sha(a.apk),dex_sha256=dex_hashes,apk_translated_jar_sha256=sha(jar),carrier_report_sha256=sha(a.carrier_report),
              mode=mode,checks=int(match[2]) + extended,invite_487_checks=int(match[2]),other_final_checks=extended,diagnostic_observations=[line for line in out.strip().splitlines() if not line.startswith('NATIVE_INVITE_')],
              real_sip_response_dispatcher=True,real_dialog_state_and_ack_builder=True,real_sip_parser_and_request_serialization=True,
              fixture_boundaries=['o82.C(kb4)/x(byte[],context) socket sends collected','Android log and event sinks','SIP engine constructed without a live socket or SIM'],
              dex_to_jvm_constructor_adapters=True,jvm_verification_disabled_for_translated_dex=True,
              real_carrier_tested=False,network_calls_placed=False,android_art_tested=False,
              fixture_sources={str(q.relative_to(here.parents[1])):sha(q) for q in fixture_sources})
a.report.write_text(json.dumps(result,indent=2)+'\n')
print(out.strip())
