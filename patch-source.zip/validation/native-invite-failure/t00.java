import java.util.ArrayList;
import java.util.List;

/** Records the event that the SIP dispatcher delivers to the Android call controller. */
public final class t00 {
  public final List<Object> events = new ArrayList<>();

  public Object i(Object event) {
    events.add(event);
    return null;
  }
}
