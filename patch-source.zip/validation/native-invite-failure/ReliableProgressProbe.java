import java.nio.charset.StandardCharsets;
import java.util.Map;

/** Feed wire responses to the real SIP dispatcher and observe PRACKs and early-media callbacks. */
final class ReliableProgressProbe {
    private static int checks;

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
        checks++;
    }

    private static void deliver(InviteFinalProbe.Call call, String tag, int sequence,
            String sdp, boolean reliable) throws Exception {
        String extra = "RSeq: " + sequence + "\r\n"
                + (reliable ? "Require: precondition, 100rel\r\n" : "")
                + "Contact: <sip:leg" + tag + "@example.invalid>\r\nContent-Type: application/sdp";
        InviteFailureStatusesProbe.Failure progress =
                new InviteFailureStatusesProbe.Failure(183, "Session Progress", extra);
        check(InviteFailureStatusesProbe.deliverWire(call, progress, "INVITE", 11, "Via",
                InviteFinalProbe.via(InviteFinalProbe.BRANCH), InviteFinalProbe.LOCAL, tag, sdp),
                "dispatcher handles provisional response");
    }

    private static String sdp(InviteFinalProbe.Call call) throws Exception {
        return new String((byte[]) InviteFinalProbe.get(call.s.d, "p"), StandardCharsets.US_ASCII);
    }

    private static void lastPrack(InviteFinalProbe.Call call, int number, String tag)
            throws Exception {
        Object packet = call.s.packets().get(call.s.packets().size() - 1);
        check("PRACK".equals(InviteFinalProbe.get(packet, "b")), "PRACK sent");
        check((number + " 11 INVITE").equals(InviteFinalProbe.first(packet, "RAck")),
                "PRACK acknowledges the accepted sequence");
        check(InviteFinalProbe.first(packet, "To").endsWith(";tag=" + tag),
                "PRACK targets the correct early dialog");
    }

    static int run(boolean previous) throws Exception {
        checks = 0;
        InviteFinalProbe.Call call = new InviteFinalProbe.Call();
        deliver(call, "A", 47, SipForkProbe.A, true);
        check(call.s.packets().size() == 1 && call.sink.events.size() == 1, "first reliable SDP");
        lastPrack(call, 47, "A");

        deliver(call, "A", 47, SipForkProbe.A, true);
        check(call.s.packets().size() == 1, "duplicate does not generate a new PRACK");
        check(call.sink.events.size() == (previous ? 2 : 1), "duplicate SDP is delivered once");
        int events = call.sink.events.size();
        deliver(call, "A", 49, SipForkProbe.B, true);
        check(call.sink.events.size() == events + (previous ? 1 : 0), "gap cannot replace media");
        check(sdp(call).equals(previous ? SipForkProbe.B : SipForkProbe.A), "current media after gap");
        check(call.s.packets().size() == (previous ? 2 : 1), "gap is not acknowledged");

        deliver(call, "A", 48, SipForkProbe.A, true);
        if (!previous) lastPrack(call, 48, "A");
        deliver(call, "A", 49, SipForkProbe.B, true);
        lastPrack(call, 49, "A");
        check(sdp(call).equals(SipForkProbe.B), "retransmitted next SDP takes effect in order");
        deliver(call, "A", 48, SipForkProbe.A, true);
        check(sdp(call).equals(previous ? SipForkProbe.A : SipForkProbe.B),
                "old response cannot roll back negotiated media");

        deliver(call, "B", 12, SipForkProbe.A, true);
        lastPrack(call, 12, "B");
        Map<?, ?> sequenceByTag = (Map<?, ?>) InviteFinalProbe.get(call.s.d, "v");
        check(Integer.valueOf(49).equals(sequenceByTag.get("A"))
                && Integer.valueOf(12).equals(sequenceByTag.get("B")), "independent fork sequence");
        int sent = call.s.packets().size();
        deliver(call, "A", 46, SipForkProbe.B, false);
        check(call.s.packets().size() == sent && sdp(call).equals(SipForkProbe.B),
                "provisional response without Require 100rel follows native media handling");
        System.out.println("Reliable progress: mode=" + (previous ? "24.1" : "fixed")
                + ", checks=" + checks);
        return checks;
    }
}
