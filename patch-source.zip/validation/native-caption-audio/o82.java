/** IMS transport boundary, no packets are transmitted. */
public final class o82 {
    public final g11 g = new g11();
    public x9 O;
    public int outgoingVoice;
    public void B(byte[] packet, x82 address, int port, boolean rtcp) { if (!rtcp) outgoingVoice++; }
}
