import android.content.Context;

/** The hardware playout sink captures the exact PCM passed by the real media controller. */
public final class yz {
    public final Context a;
    public final int b;
    public boolean d, f, x, q, stopped;
    public g11 e;
    public n0 c;
    public int g, h;
    public short[] played;
    public yz(Context context, int rate) { a = context; b = rate; }
    public void a() {}
    public void b(short[] samples) { played = samples; h += samples.length; }
    public void d() { q = true; }
    public void g() { q = false; stopped = true; }
}
