"""Exercise the exact signed or unsigned DEX via its pinned native-carrier translation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
from zipfile import ZipFile

here = Path(__file__).resolve().parent
project = here.parents[1]
android = Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery'))
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('apk', type=Path)
parser.add_argument('--carrier-report', type=Path, required=True)
parser.add_argument('--unsigned-apk', type=Path)
parser.add_argument('--report', type=Path, required=True)
parser.add_argument('--previous', action='store_true', help='Expect 25.0, with no caption listener callbacks')
args = parser.parse_args()


def digest(data):
    return hashlib.sha256(data).hexdigest()


carrier = json.loads(args.carrier_report.read_text())
jar = args.carrier_report.parent / 'native-carrier-current/probe.jar'
unsigned = args.unsigned_apk or args.apk
assert carrier['apk_sha256'] == digest(unsigned.read_bytes())
assert carrier['apk_translated_jar_sha256'] == digest(jar.read_bytes())
with ZipFile(unsigned) as base, ZipFile(args.apk) as candidate:
    dex = {name for name in base.namelist() if re.fullmatch(r'classes\d*\.dex', name)}
    assert dex and dex == {name for name in candidate.namelist() if re.fullmatch(r'classes\d*\.dex', name)}
    assert all(base.read(name) == candidate.read(name) for name in dex)

amr = project / 'validation/native-amr'
sources = sorted(here.glob('*.java')) + [
    amr / 'g11.java', amr / 'android/media/MediaCodec.java', amr / 'android/media/MediaFormat.java',
    project / 'tests/AmrFramingTest.java', project / 'tests/android/content/Context.java',
    project / 'tests/android/content/SharedPreferences.java'
]
args.report.parent.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(dir=args.report.parent, prefix='caption-boundary-') as tmp:
    android_jar = android / 'sdk/android-35/android.jar'
    classpath = os.pathsep.join(map(str, (jar, android_jar)))
    subprocess.run(['java', '-jar', android / 'ecj-3.40.0.jar', '-8', '-warn:none', '-proc:none',
                    '-cp', classpath, '-d', tmp, *sources], check=True)
    assert not any((Path(tmp) / (name + '.class')).exists() for name in ('t10', 'm10', 'k7', 'bl2'))
    result = subprocess.check_output(['java', '-noverify', '-cp', tmp + os.pathsep + classpath,
                                      'CaptionMediaProbe', 'previous' if args.previous else 'current'], text=True)
match = re.search(r'CAPTION_MEDIA (\d+) checks, previous=(true|false)', result)
assert match and (match[2] == 'true') == args.previous
report = dict(apk_sha256=digest(args.apk.read_bytes()), apk_translated_jar_sha256=carrier['apk_translated_jar_sha256'],
              checks=int(match[1]), previous=args.previous, verified_call_controller='t10.e/b/f',
              verified_rtp_receive='m10.run', verified_uplink='k7.run',
              assertions=['8 and 16 kHz', 'real microphone path omitted', 'telephone event omitted',
                          'decoded samples retain owner and content', 'packet loss represented as silence',
                          'old and new session identities stay distinct', 'repeated stop and stale tick',
                          'caption linkage failure cannot interrupt playback, startup or cleanup'],
              hardware_codec='synthetic', recognizer='recording listener', real_call_placed=False)
args.report.write_text(json.dumps(report, indent=2) + '\n')
print(result.strip())
