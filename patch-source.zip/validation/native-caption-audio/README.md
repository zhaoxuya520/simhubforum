# Remote caption audio boundary

Run `python3 validation/native-caption-audio/check_runtime.py SIGNED_APK --unsigned-apk UNSIGNED_APK --carrier-report build-config3/native-carrier-runtime.json --report caption-media.json` against the build being validated. For a 25.0 negative control add `--previous` and point at the matching 25.0 build artifacts.

Each media session receives one playback owner. The native AMR receiver sends a decoded frame to captions after enqueuing it for playback, and sends a null marker for a 20 ms concealment interval. A new media object supplies its own owner and negotiated sample rate. The caption engine must match callbacks by object identity and discard results after the owner changes. Caption callbacks must return before performing inference. The actual decoder can reuse buffers, so the receiver must copy any data it retains before returning.

The test runs the APK media controller, jitter buffer, RTP parser and outbound RTP builder with a deterministic scheduler, synthetic codecs, playout, transport and caption listener. It verifies which samples reach the caption boundary and that playback survives a failing listener. It does not evaluate transcription or translation accuracy.
