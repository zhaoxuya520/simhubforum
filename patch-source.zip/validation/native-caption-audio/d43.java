import java.util.Arrays;

/** Distinguish a decoded synthetic packet from decoder packet-loss concealment. */
public final class d43 {
    public Object b, c, g = new th();
    public int d;
    public long f;
    public d43(n format, int mode) { b = format; }
    public void d(int mode) { d = mode; c = android.media.MediaCodec.createEncoderByType("audio/amr"); }
    public void f(android.media.MediaCodec codec) {}
    public short[] e(byte[] frame) {
        short[] pcm = new short[((n)b).b()];
        Arrays.fill(pcm, (short)(frame == null ? -901 : 1703));
        return pcm;
    }
}
