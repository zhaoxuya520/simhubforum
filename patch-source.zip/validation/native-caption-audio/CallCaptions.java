package cc.forserein.simhub.internal;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;

/** Recording listener replacing just the recognition side of the native PCM boundary. */
public final class CallCaptions {
    public static final List<Object> owners = new ArrayList<>();
    public static final List<String> kinds = new ArrayList<>();
    public static short[] audio;
    public static Context context;
    public static int rate;
    public static boolean fail;

    private static void record(Object owner, String kind) {
        owners.add(owner);
        kinds.add(kind);
        if (fail) throw new NoClassDefFoundError("simulated unavailable recognizer");
    }
    public static void mediaStarted(Object owner, Context value, int hz) {
        context = value;
        rate = hz;
        record(owner, "start");
    }
    public static void remotePcm(Object owner, short[] frame) {
        audio = frame;
        record(owner, frame == null ? "gap" : "decoded");
    }
    public static void render(Object owner, short[] frame) {}
    public static void mediaStopped(Object owner) { record(owner, "stop"); }
}
