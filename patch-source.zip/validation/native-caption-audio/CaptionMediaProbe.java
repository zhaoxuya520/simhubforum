import android.content.Context;
import cc.forserein.simhub.internal.CallCaptions;
import java.util.Collections;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/** Actual native t10 lifecycle, m10 RTP ingress and jitter playout; synthetic media endpoints. */
public final class CaptionMediaProbe {
    static int checks;
    static boolean legacy;

    static void check(boolean valid, String title) {
        if (!valid) throw new AssertionError(title);
        checks++;
    }

    static void event(int offset, String type, Object owner) {
        if (legacy) {
            check(CallCaptions.kinds.isEmpty(), "no native caption event in previous release");
            return;
        }
        check(CallCaptions.kinds.size() == offset + 1, "exactly one callback for " + type);
        check(CallCaptions.kinds.get(offset).equals(type), "event " + type);
        check(CallCaptions.owners.get(offset) == owner, "exact session object for " + type);
    }

    static t10 open(Context context, boolean wide) throws Exception {
        q93 config = new q93("192.0.2.2", 10804, 10805, wide ? 116 : 97, wide ? xk.U : xk.V,
                wide ? 16000 : 8000, true, Collections.<Integer>emptyList(), 20, Integer.valueOf(20),
                Integer.valueOf(wide ? 100 : 101), Integer.valueOf(wide ? 16000 : 8000), y84.T);
        t10 media = new t10(new o82(), config, false, context, false, false);
        // Control the jitter ticks, while retaining the native teardown executor task and ordering.
        media.h.shutdownNow();
        ScheduledThreadPoolExecutor clock = new ScheduledThreadPoolExecutor(1) {
            @Override public ScheduledFuture<?> scheduleAtFixedRate(Runnable task, long delay, long period, TimeUnit unit) {
                return super.schedule(task, 1, TimeUnit.DAYS);
            }
        };
        java.lang.reflect.Field executor = t10.class.getField("h");
        executor.setAccessible(true);
        executor.set(media, clock);
        int count = CallCaptions.kinds.size();
        media.e();
        event(count, "start", media.e);
        if (!legacy) {
            check(CallCaptions.context == context, "start context");
            check(CallCaptions.rate == config.f, "negotiated PCM rate");
        }
        return media;
    }

    static void packet(t10 media, int pt, int sequence, long timestamp, byte[] payload) throws Exception {
        byte[] data = new hx3(pt, sequence, timestamp, 7, false, payload).a();
        Runnable input = (Runnable)m10.class.getConstructor(t10.class, byte[].class, x82.class, int.class, int.class)
                .newInstance(media, data, null, 10804, 44886);
        input.run();
    }

    static void speech(t10 media, boolean wide, int sequence) throws Exception {
        int before = CallCaptions.kinds.size();
        byte[] payload = AmrFramingTest.packet(wide, true, new int[]{2}, sequence);
        packet(media, wide ? 116 : 97, sequence, (long)sequence * (wide ? 320 : 160), payload);
        media.i.d = true; // release once buffered without waiting for wall clock
        media.b();
        check(media.e.played != null && media.e.played[0] == 1703, "decoded packet reached playout");
        event(before, "decoded", media.e);
        if (!legacy) {
            check(media.e.played == CallCaptions.audio, "caption PCM is exactly the native playback frame");
            check(CallCaptions.audio.length == (wide ? 320 : 160), "20 ms PCM length");
        }
    }

    static void stop(t10 media) {
        int before = CallCaptions.kinds.size();
        media.f();
        event(before, "stop", media.e);
        check(media.e.stopped && media.h.isShutdown(), "native audio and executor cleaned up");
        before = CallCaptions.kinds.size();
        media.f();
        media.b();
        check(before == CallCaptions.kinds.size(), "idempotent stop and stale tick ignored");
    }

    public static void main(String[] args) throws Exception {
        legacy = args.length > 0 && "previous".equals(args[0]);
        Context context = new Context();
        t10 nb = open(context, false);
        t10 wb = null;
        try {
            int before = CallCaptions.kinds.size();
            byte[] speech = AmrFramingTest.speech(false, nb.d, 27);
            byte[] encoded = new byte[1 + speech.length];
            encoded[0] = (byte)((nb.d << 3) | 4);
            System.arraycopy(speech, 0, encoded, 1, speech.length);
            ((th)nb.f.g).add(encoded);
            Runnable microphone = (Runnable)k7.class.getConstructor(int.class, Object.class, Object.class)
                    .newInstance(4, nb, new short[160]);
            microphone.run();
            check(nb.a.outgoingVoice == 1, "native microphone callback -> RTP reaches transport fixture");
            check(CallCaptions.kinds.size() == before, "microphone produces no caption event");
            packet(nb, 101, 20, 3200, new byte[]{0, 0, 0, 0});
            nb.b();
            check(CallCaptions.kinds.size() == before, "no caption from DTMF");
            speech(nb, false, 21);
            before = CallCaptions.kinds.size();
            nb.b();
            check(nb.e.played[0] == -901, "native concealment still reaches speaker");
            event(before, "gap", nb.e);
            if (!legacy) check(CallCaptions.audio == null, "concealment treated as silence by captions");
            wb = open(context, true);
            check(nb.e != wb.e, "different media lifetimes have separate owner objects");
            stop(nb);
            CallCaptions.fail = true;
            speech(wb, true, 22);
            stop(wb);
            // Fatal linkage errors in an optional engine also cannot break media startup.
            t10 noProvider = open(context, true);
            try { stop(noProvider); }
            finally { noProvider.h.shutdownNow(); }
        } finally {
            nb.h.shutdownNow();
            if (wb != null) wb.h.shutdownNow();
        }
        System.out.println("CAPTION_MEDIA " + checks + " checks, previous=" + legacy);
    }
}
