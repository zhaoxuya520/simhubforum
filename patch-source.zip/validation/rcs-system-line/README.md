# Optional Android subscription line evidence

`RcsSystemLine.query(fullIccid)` returns `Match{subId, number}` or null. It reads
the existing application context and public Android 33+ subscription APIs.
The caller must compare both fields again and require the RCS provider's own
registered number to match. This adapter never enables RCS or selects a SIM.

It requires exactly one active complete ICCID match, inspects only the explicit
`PHONE_NUMBER_SOURCE_CARRIER` and `PHONE_NUMBER_SOURCE_IMS` sources, and accepts
strict `+E164` strings. A missing source can use the other; conflicting or
malformed sources cannot. An identical number on any other active subscription
is ambiguous. Active identity membership and the selected number are read again
before returning. Invalid/default subscription IDs are never passed to the API.

No permissions are requested. Android enforces the caller's existing
READ_PHONE_NUMBERS/privileged grants or carrier privileges. The existing app
does not request READ_PHONE_NUMBERS; therefore availability can be limited even
where READ_PHONE_STATE is granted. In particular, **all active subscriptions'
identities and numbers must be readable** for this conservative fallback. An
unreadable second SIM returns null rather than claiming a unique match.

The one-argument `getPhoneNumber` may fall back to UICC; it is deliberately not
used. Neither EF_MSISDN, user-entered numbers, Android default SMS/data/voice
subscriptions, activation settings nor hidden APIs are used. System metadata
does not replace provider registration or constitute cryptographic ownership
proof. A missing line means unavailable, not that a particular operator lacks
RCS support.

`RcsSystemLineTest` runs the actual adapter with explicit Android boundary
stubs and synthetic ICCIDs/numbers. It covers API 32 rejection / API 33 success,
permission and service failures, missing/redacted data, exact-card matching,
conflicting sources, duplicated IDs/ICCIDs, another subscription with the same
number, a card/subscription change during enumeration and repeated lookup.
The public implementation separately compiles against the actual Android 35
SDK jar. These are host tests, not modem/service/device registration tests.
`validation.json` records the source and SDK hashes and test count.
