/** Session/platform double only; card, carrier parser, config and quirk models come from the APK. */
public class zl5 {public static android.content.Context f;public static final NativeCarrierProbe.Flow b=new NativeCarrierProbe.Flow();public static void b(String message){}public static void x(boolean value){}}
