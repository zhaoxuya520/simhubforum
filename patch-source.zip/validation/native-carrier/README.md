# Native carrier path probe

Run `python3 tests/check_native_carrier_runtime.py APK DECODED_APK --report REPORT.json`. Add `--legacy` for the previous DITO identity release as a negative control.

The probe loads the real carrier JSON parser, preset selection, card/config/state/IMS-quirk models and helper methods from the supplied APK's DEX. The Java fixtures replace Android assets/preferences/logging and the session state holder only. They do not replace `ek5`, `xi5`, `gl5`, `yj5`, `fj5` or `zl3`.

The pinned dex2jar distribution is recorded in `toolchain.json`; keep its ZIP and extracted `dex-tools-v2.4` folder under `SIMHUB_DEX2JAR_TOOLS` (default `/workspace/tools/dex2jar-v2.4`). The runner verifies the archive hash and all extracted dependency JARs. Android SDK and ECJ locations follow `SIMHUB_TOOLS`.

R8 can remove a child constructor and directly invoke its superclass constructor, which Java bytecode cannot represent. The probe adds forwarding constructors and corrects Java interface method references after translation. It does not alter carrier business logic. JVM stack-map verification is disabled for this translated probe; shipped DEX register types are checked independently with `check_dex_types.py`. This is a host regression test, not Android ART, phone, APDU or network execution.


## Genuine current-identity authentication inputs (23.7)

The normal runner also starts a separate authentication-input process. This
process removes the `ac5` EF-read fixture from its classpath and loads the APK's
real `ac5`, `s01`, `hm0`, `b72`, `da1`, and `o82` classes. Its physical `qg0`
transport is an inert proxy: every method fails, and the call count must stay zero.

The test uses the actual effective configuration and the two-argument
`DitoHomeIdentity.connection(card, config)` policy. It exercises automatic and
manual DITO without history, other valid current PLMNs/MNC lengths, explicit
identity overrides, observed same-card home preference, another-card isolation,
non-DITO manual selection, and malformed actual identities.

For EAP, an empty response is supplied at the native `w62` IKE_AUTH continuation
boundary. The actual `b72.e` reads `xi5.y`, falling back to `xi5.r`, constructs
`da1` with those exact identity bytes and the same physical AKA adapter, then
rejects the missing network EAP challenge. Native `s62.a` supplies the outer
identity formatting. No successful EAP response or key material is supplied.

For IMS, the real `o82` constructor and `n/v` methods build the initial REGISTER.
A JVM-only adapter replaces only `o82.K`, the request transport/wait boundary,
with capture and suspension. Every other `o82` method's instruction fingerprint
is compared before and after adaptation. Assertions inspect the actual generated
Authorization IMPI/realm and From/To identities, including the still-empty digest
response awaiting the carrier challenge. The original config, actual identity,
and card AKA adapter remain attached to both workers.

`--identity-policy-legacy` runs the old 23.6 missing-home rejection as a negative
control. Existing `--legacy` and `--recognition-legacy` modes keep their earlier
version-specific expectations. `authentication-input-review.json` records the
pre-build probe evidence; the regular final runtime report binds all these tests
to the rebuilt APK hash. None of these host checks establishes carrier acceptance,
UICC challenge success, ePDG connectivity, or a completed Wi-Fi registration.
