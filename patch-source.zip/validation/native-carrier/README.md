# Native carrier path probe

Run `python3 tests/check_native_carrier_runtime.py APK DECODED_APK --report REPORT.json`. Add `--legacy` for the previous DITO identity release as a negative control.

The probe loads the real carrier JSON parser, preset selection, card/config/state/IMS-quirk models and helper methods from the supplied APK's DEX. The Java fixtures replace Android assets/preferences/logging and the session state holder only. They do not replace `ek5`, `xi5`, `gl5`, `yj5`, `fj5` or `zl3`.

The pinned dex2jar distribution is recorded in `toolchain.json`; keep its ZIP and extracted `dex-tools-v2.4` folder under `SIMHUB_DEX2JAR_TOOLS` (default `/workspace/tools/dex2jar-v2.4`). The runner verifies the archive hash and all extracted dependency JARs. Android SDK and ECJ locations follow `SIMHUB_TOOLS`.

R8 can remove a child constructor and directly invoke its superclass constructor, which Java bytecode cannot represent. The probe adds forwarding constructors and corrects Java interface method references after translation. It does not alter carrier business logic. JVM stack-map verification is disabled for this translated probe; shipped DEX register types are checked independently with `check_dex_types.py`. This is a host regression test, not Android ART, phone, APDU or network execution.
