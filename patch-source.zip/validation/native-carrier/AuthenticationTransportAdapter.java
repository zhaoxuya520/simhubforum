import java.io.*;import java.nio.file.*;import java.util.*;import java.util.zip.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.util.*;
/** Probe-only outgoing REGISTER boundary; native construction/authentication methods are untouched. */
public final class AuthenticationTransportAdapter {
 static boolean boundary(MethodNode m){return m.name.equals("K")&&m.desc.equals("(Lkb4;ZIILjava/lang/String;Ldt0;)Ljava/lang/Object;");}
 static String fingerprint(ClassNode node){StringWriter out=new StringWriter();PrintWriter writer=new PrintWriter(out);for(MethodNode m:node.methods)if(!boundary(m)){writer.println(m.name+m.desc);Textifier text=new Textifier();m.accept(new TraceMethodVisitor(text));text.print(writer);}writer.flush();return out.toString();}
 public static void main(String[] args)throws Exception {
  int changed=0;
  try(ZipFile input=new ZipFile(args[0]);ZipOutputStream output=new ZipOutputStream(Files.newOutputStream(Paths.get(args[1])))){
   for(ZipEntry entry:Collections.list(input.entries())){byte[] bytes=input.getInputStream(entry).readAllBytes();
    if(entry.getName().equals("o82.class")){ClassNode node=new ClassNode();new ClassReader(bytes).accept(node,0);String before=fingerprint(node);
     for(MethodNode m:node.methods)if(boundary(m)){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));m.instructions.add(new VarInsnNode(Opcodes.ALOAD,1));m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"NativeAuthenticationInputsProbe","captureRegister","(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",false));m.instructions.add(new InsnNode(Opcodes.ARETURN));m.maxLocals=7;m.maxStack=2;changed++;}
     ClassWriter writer=new ClassWriter(0);node.accept(writer);bytes=writer.toByteArray();ClassNode after=new ClassNode();new ClassReader(bytes).accept(after,0);if(!before.equals(fingerprint(after)))throw new AssertionError("non-boundary native IMS method changed");
    }
    output.putNextEntry(new ZipEntry(entry.getName()));output.write(bytes);output.closeEntry();
   }
  }
  if(changed!=1)throw new AssertionError("REGISTER boundary count="+changed);
  System.out.println("AUTH_INPUT_ADAPTER only_o82_K_transport_boundary=true all_other_methods_preserved=true");
 }
}
