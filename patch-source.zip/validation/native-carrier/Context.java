package android.content;
public class Context {
 public android.content.res.AssetManager getAssets(){return new android.content.res.AssetManager();}
    public static final int MODE_PRIVATE=0;
    public SharedPreferences getSharedPreferences(String name,int mode) {throw new UnsupportedOperationException();}
    public Context getApplicationContext() { return this; }
    public <T> T getSystemService(Class<T> type) { return null; }
}
