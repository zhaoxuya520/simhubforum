import cc.forserein.simhub.internal.CarrierPresets;
import cc.forserein.simhub.internal.WifiConfigModel;
import cc.forserein.simhub.internal.WifiConfigRuntime;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/** Exercise the editor-save and read-card entry points against the APK's real carrier/card models. */
public final class NativeAttImsProbe {
    static int checks;

    private static void equal(Object expected, Object value, String field) {
        if (!Objects.equals(expected, value)) throw new AssertionError(field + ": expected " + expected + ", got " + value);
        checks++;
    }

    private static Object card(String imsi, Object isim) throws Exception {
        return WifiConfigModel.constructor(Class.forName("ek5"), 8).newInstance(imsi,
                NativeCarrierProbe.nextId(), 3, null, null, null, null, isim);
    }

    private static Object isim(String privateId, String domain, String publicId) throws Exception {
        return WifiConfigModel.constructor(Class.forName("z82"), 3).newInstance(privateId, domain, publicId);
    }

    private static Object save(Object card, Object original, Map<String, String> settings) throws Exception {
        NativeCarrierProbe.state(card, original);
        WifiConfigRuntime.Snapshot editor = WifiConfigRuntime.snapshot();
        WifiConfigRuntime.save(editor.key, editor.record, settings);
        return WifiConfigRuntime.resolve(card, original);
    }

    private static void identities(Object config, String domain, String impi, String impu) throws Exception {
        equal(domain, WifiConfigModel.get(config, "g"), "IMS domain");
        equal(impi, WifiConfigModel.get(config, "s"), "IMPI");
        equal(impu, WifiConfigModel.get(config, "A"), "IMPU");
    }

    public static void main(String[] args) throws Exception {
        android.content.res.AssetManager.root = Paths.get(args[0]);
        NativeCarrierProbe.fresh();
        String sub = "310410123456789";
        String fallback = "sip:" + sub + "@one.att.net";
        Object[] records = {
            null,
            isim("other@elsewhere.example", "elsewhere.example", "tel:+19995550101"),
            isim("impostor@evilatt.net", "evilatt.net", "tel:+19995550101"),
            isim("actual@private.att.net", " Voice.ATT.NET. ", "tel:+19995550102"),
            isim("invalid", "voice.att.net", "sip:invalid format")
        };
        for (int index = 0; index < records.length; index++) {
            Object card = card(sub, records[index]);
            Object original = WifiConfigModel.builtIn(card);
            Object effective = WifiConfigRuntime.resolve(card, original);
            if (index < 3) identities(effective, "one.att.net", sub + "@private.att.net", fallback);
            if (index == 3) identities(effective, "voice.att.net", "actual@private.att.net", "tel:+19995550102");
            if (index == 4) identities(effective, "voice.att.net", sub + "@voice.att.net", "sip:" + sub + "@voice.att.net");
            for (String field : new String[]{"r", "y", "f", "t", "i"})
                equal(WifiConfigModel.get(original, field), WifiConfigModel.get(effective, field), "original " + field);
        }
        String physical = "234330123456789";
        Object card = card(physical, records[1]);
        Object original = WifiConfigModel.builtIn(card);
        Map<String, String> settings = new LinkedHashMap<>();
        settings.put(CarrierPresets.KEY, "310410|apple_att_us");
        Object manual = save(card, original, settings);
        identities(manual, "one.att.net", physical + "@private.att.net", "sip:" + physical + "@one.att.net");
        equal(physical, WifiConfigModel.get(card, "a"), "physical subscription");
        Object outer = WifiConfigModel.get(manual, "r");
        settings.put("domain", "custom.example.org");
        settings.put("impi", "private@custom.example.org");
        settings.put("impu", "sip:user@custom.example.org");
        Object custom = save(card, original, settings);
        identities(custom, "custom.example.org", "private@custom.example.org", "sip:user@custom.example.org");
        equal(outer, WifiConfigModel.get(custom, "r"), "manual outer IKE identity");
        Object firstNet = card("312670123456789", null);
        Object firstNetNative = WifiConfigModel.builtIn(firstNet);
        equal(firstNetNative, WifiConfigRuntime.resolve(firstNet, firstNetNative), "FirstNet");
        Object[] fields = WifiConfigModel.fields(original, 27);
        fields[1] = "apple_not_att";
        fields[3] = "310";
        fields[4] = "410";
        Object other = WifiConfigModel.constructor(original.getClass(), 27).newInstance(fields);
        Object cleanCard = card(sub, null);
        equal(other, WifiConfigRuntime.resolve(cleanCard, other), "other preset sharing AT&T PLMN");
        System.out.println("NATIVE_ATT_IMS checks=" + checks);
    }
}
