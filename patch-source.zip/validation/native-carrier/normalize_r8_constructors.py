from pathlib import Path
import re,sys
root=Path(sys.argv[1])
rows=[]
for p in root.rglob('*.smali'):
 s=p.read_text();owner=re.search(r'^\.class (?:[^\n]* )?(L[^;]+;)$',s,re.M)[1][1:-1]
 method=None;new={}
 for line in s.splitlines():
  t=line.strip()
  if t.startswith('.method '):method=t.rsplit(' ',1)[-1];new={}
  if not method:continue
  match=re.fullmatch(r'new-instance ([vp]\d+), L([^;]+);',t)
  if match:new[match[1]]=match[2];continue
  match=re.fullmatch(r'move-object(?:/from16|/16)? ([vp]\d+), ([vp]\d+)',t)
  if match:
   if match[2] in new:new[match[1]]=new[match[2]]
   else:new.pop(match[1],None)
   continue
  match=re.match(r'invoke-direct(?:/range)? \{([vp]\d+)[^}]*\}, L([^;]+);-><init>(\([^)]*\)V)',t)
  if match and match[1] in new:
   child=new[match[1]];rows.append((owner,method,match[2],match[3],child));new={k:v for k,v in new.items() if v!=child};continue
  # Constants, loads, arithmetic, call results and most other instructions overwrite their first register.
  if not t.startswith(('invoke-','if-','iput','sput','aput','return','throw','monitor','check-cast',':','.','#')):
   dst=re.match(r'[^ ]+ ([vp]\d+)(?:,|$)',t)
   if dst:new.pop(dst[1],None)
  if t=='.end method':method=None
mismatch={(r[0],r[1],r[2],r[3]) for r in rows if r[2]!=r[4]}
rows=[r for r in rows if (r[0],r[1],r[2],r[3]) in mismatch]
p=Path(sys.argv[2]);p.write_text('\n'.join('\t'.join(r) for r in rows)+'\n')
print('R8 constructor bridge sites:',len(rows),'mismatches:',sum(r[2]!=r[4] for r in rows))
