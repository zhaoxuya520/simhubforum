import java.io.*;import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
/** JVM probe glue only: replace DEX new-Child/Parent.<init> optimization with forwarding constructors. */
public class NormalizeR8Constructors {
 public static void main(String[]args)throws Exception {
  Map<String,ClassNode> classes=new LinkedHashMap<>();Map<String,byte[]> other=new LinkedHashMap<>();
  try(ZipFile z=new ZipFile(args[0])){for(ZipEntry e:Collections.list(z.entries())){byte[] bytes=z.getInputStream(e).readAllBytes();if(e.getName().endsWith(".class")){ClassNode n=new ClassNode();new ClassReader(bytes).accept(n,0);classes.put(n.name,n);}else other.put(e.getName(),bytes);}}
  Map<String,Map<String,Deque<String>>> specs=new HashMap<>();
  for(String line:Files.readAllLines(Paths.get(args[1]))){String[] p=line.split("\t");if(p.length!=5)continue;specs.computeIfAbsent(p[0]+"->"+p[1],k->new HashMap<>()).computeIfAbsent(p[2]+p[3],k->new ArrayDeque<>()).add(p[4]);}
  Map<String,Map<String,String>> bridges=new LinkedHashMap<>();int patched=0;
  for(ClassNode n:classes.values())for(MethodNode m:new ArrayList<>(n.methods)){
   Map<String,Deque<String>> methods=specs.get(n.name+"->"+m.name+m.desc);if(methods==null)continue;
   List<TypeInsnNode> pending=new ArrayList<>();
   for(AbstractInsnNode ins:m.instructions){
    if(ins.getOpcode()==Opcodes.NEW)pending.add((TypeInsnNode)ins);
    if(!(ins instanceof MethodInsnNode)||!((MethodInsnNode)ins).name.equals("<init>"))continue;
    MethodInsnNode call=(MethodInsnNode)ins;Deque<String> q=methods.get(call.owner+call.desc);if(q==null||q.isEmpty())continue;
    String child=q.peekFirst();TypeInsnNode allocation=null;
    for(int i=pending.size()-1;i>=0;i--){TypeInsnNode a=pending.get(i);if(a.desc.equals(call.owner)||a.desc.equals(child)){allocation=a;pending.remove(i);break;}}
    if(allocation==null)continue;q.removeFirst();if(child.equals(call.owner))continue;
    bridges.computeIfAbsent(child,k->new LinkedHashMap<>()).put(call.desc,call.owner);allocation.desc=child;call.owner=child;patched++;
   }
  }
  int interfaces=0;
  for(ClassNode n:classes.values())for(MethodNode m:n.methods)for(AbstractInsnNode ins:m.instructions)if(ins instanceof MethodInsnNode){
   MethodInsnNode call=(MethodInsnNode)ins;
   if(call.owner.startsWith("java/"))try{boolean itf=Class.forName(call.owner.replace('/','.'),false,NormalizeR8Constructors.class.getClassLoader()).isInterface();if(itf!=call.itf){call.itf=itf;interfaces++;}}catch(ClassNotFoundException ignored){}
  }
  int added=0;
  for(Map.Entry<String,Map<String,String>> e:bridges.entrySet()){
   ClassNode child=classes.get(e.getKey());if(child==null)throw new IllegalStateException(e.getKey());
   for(Map.Entry<String,String> bridge:e.getValue().entrySet()){
    String desc=bridge.getKey();boolean exists=false;for(MethodNode m:child.methods)if(m.name.equals("<init>")&&m.desc.equals(desc))exists=true;if(exists)continue;
    MethodNode method=new MethodNode(Opcodes.ACC_PUBLIC,"<init>",desc,null,null);method.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));int local=1;
    for(Type t:Type.getArgumentTypes(desc)){method.instructions.add(new VarInsnNode(t.getOpcode(Opcodes.ILOAD),local));local+=t.getSize();}
    method.instructions.add(new MethodInsnNode(Opcodes.INVOKESPECIAL,bridge.getValue(),"<init>",desc,false));method.instructions.add(new InsnNode(Opcodes.RETURN));method.maxLocals=local;method.maxStack=local;child.methods.add(method);added++;
   }
  }
  try(ZipOutputStream z=new ZipOutputStream(Files.newOutputStream(Paths.get(args[2])))){
   for(ClassNode n:classes.values()){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(w);z.putNextEntry(new ZipEntry(n.name+".class"));z.write(w.toByteArray());z.closeEntry();}
   for(Map.Entry<String,byte[]> e:other.entrySet()){z.putNextEntry(new ZipEntry(e.getKey()));z.write(e.getValue());z.closeEntry();}
  }
  System.out.println("JVM-only R8 constructor bridge normalization: calls="+patched+" added="+added+" interface_flags="+interfaces);
 }
}
