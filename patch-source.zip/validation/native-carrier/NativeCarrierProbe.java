import java.util.*;
import android.content.*;
import cc.forserein.simhub.internal.*;

/** Execute the APK's real parser, preset builder, identity/config/quirk constructors and helpers. */
public final class NativeCarrierProbe {
 static int checks;static boolean fallbackPolicy;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
 public static final class Flow {
  public Object value;
  public Object getValue(){return value;}
  public boolean h(Object previous,Object next){if(value!=previous)return false;value=next;return true;}
 }
 public static class Prefs implements SharedPreferences {
  final Map<String,String> values=new HashMap<>();
  public String getString(String key,String fallback){return values.containsKey(key)?values.get(key):fallback;}
  public Editor edit(){return new Editor(){public Editor putString(String k,String v){values.put(k,v);return this;}public Editor remove(String k){values.remove(k);return this;}public boolean commit(){return true;}};}
 }
 public static class Context extends android.content.Context {
  final Map<String,Prefs> values=new HashMap<>();
  public SharedPreferences getSharedPreferences(String name,int mode){if(!values.containsKey(name))values.put(name,new Prefs());return values.get(name);}
 }
 static Object get(Object object,String name)throws Exception{return WifiConfigModel.get(object,name);}
 static Object card(String imsi,String iccid)throws Exception {return card(imsi,iccid,2);}
 static Object card(String imsi,String iccid,int mnc)throws Exception {
  return WifiConfigModel.constructor(Class.forName("ek5"),8).newInstance(imsi,iccid,mnc,null,null,"+639123456789","+639000000000",null);
 }
 static void state(Object card,Object config)throws Exception {state(card,config,null);}
 static void state(Object card,Object config,String epdg)throws Exception {
  Object phase=Class.forName("tk5").getField("g").get(null);
  zl5.b.value=WifiConfigModel.constructor(Class.forName("gl5"),20).newInstance("SIM","test",false,null,card,config,false,epdg,null,"490154203237518",phase,false,null,null,null,new ArrayList<>(),new ArrayList<>(),false,null,0L);
 }
 static int recognitionCard=8000;
 static String nextId(){return "890123450012345"+(++recognitionCard);}
 static final String ROAM="204049876543210",POLAND="260019876543210",HOME="515660123456789";
 static void fresh()throws Exception {zl5.f=new Context();Class.forName("fj5").getField("d").set(null,zl5.f);}
 static boolean blocked(Object card)throws Exception {try{DitoHomeIdentity.connection(card);return false;}catch(IllegalStateException expected){return true;}}
 static String effectiveCarrier(Object card)throws Exception {return (String)get(WifiConfigRuntime.resolve(card,WifiConfigModel.builtIn(card)),"c");}
 static Prefs overrides(){return (Prefs)zl5.f.getSharedPreferences("wifi_config_overrides_v1",0);}
 static void record(Object card,Map<String,String> values)throws Exception{overrides().values.put(WifiConfigRuntime.cardKey(card),WifiConfigValues.encode(values));}
 public static final class Transport {public String f="native probe";}
 public static final class Controller {
  public List<Object> chips;public String selected="chip-A";
  public Controller(List<Object> chips){this.chips=chips;}
  public String r(){return selected;}public List<Object> l(){return chips;}
 }
 static Object profile(String iccid,String provider,String nickname,boolean enabled)throws Exception{
  return WifiConfigModel.constructor(Class.forName("qy3"),7).newInstance(iccid,enabled,nickname,provider,nickname,null,null);
 }
 static Object chip(String eid,List<Object> profiles)throws Exception{
  return WifiConfigModel.constructor(Class.forName("xx3"),6).newInstance(new byte[]{1},eid,null,profiles,null,null);
 }
 static Controller controller(Object...profiles)throws Exception{return new Controller(new ArrayList<Object>(Arrays.asList(chip("chip-A",new ArrayList<Object>(Arrays.asList(profiles))))));}
 static void providerCase(boolean previous,String label,String actual,String provider,String nickname,String profileIccid,boolean expected)throws Exception{
  String beforeActual=actual;if(!actual.isEmpty())actual=nextId();profileIccid=profileIccid.equals(beforeActual)?actual:nextId();
  fresh();Object card=card(ROAM,actual),transport=new Transport(),auth=new Object();Controller c=controller(profile(profileIccid,provider,nickname,false));
  IdentityBinding.track(transport,c);IdentityBinding.begin(transport,auth);IdentityBinding.read(transport,auth,card);
  check(DitoHomeIdentity.isDito(card)==(!previous&&expected),label+" classification");
  String carrier=effectiveCarrier(card),nativeCarrier=(String)get(WifiConfigModel.builtIn(card),"c");check(carrier.equals(!previous&&expected?"DITO":nativeCarrier),label+" actual native template observed="+carrier);
  if(!previous&&expected)check(blocked(card)==!fallbackPolicy,label+" provider recognition never invents home credentials");
  check(get(card,"a").equals(ROAM)&&get(card,"b").equals(actual),label+" physical read unchanged");
 }
 static void providerRecognition(boolean previous)throws Exception {
  String id="8901234500123457001";
  for(String provider:new String[]{"DITO","DITO Telecommunity","DITO Telecommunity Corporation"})providerCase(previous,provider,id,provider,"unrelated",id,true);
  providerCase(previous,"nickname only",id,"Vodafone","DITO",id,false);
  providerCase(previous,"other ICCID",id,"DITO","DITO","8901234500123457002",false);
  providerCase(previous,"missing physical ICCID","","DITO","DITO",id,false);
  providerCase(previous,"DITO substring rejected",id,"Not DITO operator","DITO",id,false);
  id=nextId();fresh();Object card=card(ROAM,id),transport=new Transport(),auth=new Object();Controller conflict=controller(profile(id,"DITO",null,true),profile(id,"Vodafone",null,true));
  IdentityBinding.track(transport,conflict);IdentityBinding.begin(transport,auth);IdentityBinding.read(transport,auth,card);check(!DitoHomeIdentity.isDito(card),"conflicting provider records cannot identify card");
  id=nextId();fresh();card=card(ROAM,id);transport=new Transport();auth=new Object();Controller old=controller(profile(id,"Vodafone",null,true));
  IdentityBinding.track(transport,old);IdentityBinding.begin(transport,auth);old.chips=controller(profile(id,"DITO",null,true)).chips;IdentityBinding.track(transport,old);IdentityBinding.read(transport,auth,card);check(!DitoHomeIdentity.isDito(card),"read uses provider evidence captured before async APDU");
  id=nextId();fresh();card=card(ROAM,id);transport=new Transport();auth=new Object();Controller trusted=controller(profile(id,"DITO",null,false));
  trusted.selected="other-chip";IdentityBinding.track(transport,trusted);IdentityBinding.begin(transport,auth);trusted.chips.clear();IdentityBinding.read(transport,auth,card);check(DitoHomeIdentity.isDito(card)==!previous,"immutable provider snapshot covers physical card independently of selected/active chip");
  id=nextId();fresh();card=card(ROAM,id);transport=new Transport();auth=new Object();IdentityBinding.track(transport,controller(profile(id,"DITO",null,true)));IdentityBinding.begin(transport,auth);IdentityBinding.begin(transport,new Object());boolean stale=false;
  try{IdentityBinding.read(transport,auth,card);}catch(IllegalStateException expected){stale=true;}check(stale&&!DitoHomeIdentity.isDito(card),"stale generation cannot teach provider");
  id=nextId();fresh();card=card(ROAM,id);transport=new Transport();auth=new Object();IdentityBinding.track(transport,controller(profile(id,"DITO",null,true)));IdentityBinding.begin(transport,auth);
  try{IdentityBinding.read(new Transport(),auth,card);}catch(IllegalStateException expected){}check(!DitoHomeIdentity.isDito(card),"different transport cannot reuse provider read snapshot");
 }
 static byte[] digits(String text){byte[] out=new byte[(text.length()+1)/2];for(int i=0;i<out.length;i++){int low=text.charAt(i*2)-'0',high=i*2+1<text.length()?text.charAt(i*2+1)-'0':15;out[i]=(byte)(low|(high<<4));}return out;}
 static byte[] encodedImsi(String text){byte[] b=digits("9"+text),out=new byte[b.length+1];out[0]=(byte)b.length;System.arraycopy(b,0,out,1,b.length);return out;}
 static void actualUsimRead()throws Exception {
  for(boolean hasIccid:new boolean[]{true,false})for(boolean hasAd:new boolean[]{true,false}){
   fresh();ac5 transport=new ac5();transport.b=zl5.f;transport.files.put(0x6f07,encodedImsi(ROAM));if(hasIccid)transport.files.put(0x2fe2,digits("8963668800123455526"));if(hasAd)transport.files.put(0x6fad,new byte[]{0,0,0,2});
   Object card=Class.forName("vb5").getConstructor(ac5.class,Class.forName("ct0")).newInstance(transport,null);
   card=card.getClass().getMethod("q",Object.class).invoke(card,Class.forName("sc5").getField("a").get(null));
   check(card.getClass().getName().equals("ek5")&&get(card,"a").equals(ROAM),"actual vb5 coroutine decodes physical IMSI");
   check(get(card,"b").equals(hasIccid?"8963668800123455526":""),"actual EF_ICCID absence remains absent");
   check(transport.reads.contains(0x2fe2),"actual reader attempted EF_ICCID");
   check(effectiveCarrier(card).equals(hasIccid?"DITO":"Vodafone nl"),"missing ICCID has no sufficient DITO evidence; no management substitution");
  }
 }
 static void savedRecordRecognition(boolean previous)throws Exception {
  for(boolean corrupt:new boolean[]{false,true}){
   fresh();Object card=card(ROAM,corrupt?"8963668800123457001":"8963668800123457002");String key=WifiConfigRuntime.cardKey(card);
   Map<String,String> invalid=new LinkedHashMap<>();invalid.put(CarrierPresets.KEY,"51566|missing_saved_template");invalid.put("smsc","+639111111111");String stored=corrupt?"v1\nunknown\tbad\n":WifiConfigValues.encode(invalid);overrides().values.put(key,stored);
   Object original=WifiConfigModel.builtIn(card);check(get(original,"c").equals("Vodafone nl"),"native raw card still selects roaming Vodafone");
   check(effectiveCarrier(card).equals(previous?"Vodafone nl":"DITO"),"invalid record must not send known DITO back to native Vodafone");
   check(blocked(card)==!fallbackPolicy,"invalid override retains genuine-current-identity authentication policy");
   check(WifiConfigRuntime.epdg(card,"stale.vodafone.invalid").equals(previous&&corrupt?"stale.vodafone.invalid":""),"invalid known DITO override cannot preserve stale carrier ePDG");
   state(card,original,"stale.vodafone.invalid");check(get(get(zl5.b.value,"f"),"c").equals(previous?"Vodafone nl":"DITO"),"actual native gl5 publishes protected effective config");check(java.util.Objects.equals(get(zl5.b.value,"h"),previous&&corrupt?"stale.vodafone.invalid":""),"actual native gl5 rejects stale ePDG on invalid known DITO config");WifiConfigRuntime.Snapshot snapshot=null;boolean failed=false;try{snapshot=WifiConfigRuntime.snapshot();}catch(IllegalArgumentException expected){failed=true;}
   if(previous&&!corrupt)check(failed,"23.4 missing preset key prevents editor recovery");
   else{check(!failed&&snapshot.warning!=null,"invalid saved record opens warning recovery editor");check(snapshot.record.equals(stored)&&overrides().values.get(key).equals(stored),"opening recovery editor does not rewrite stored record");if(!previous){check(snapshot.values.isEmpty(),"invalid record has safe empty recovery draft");WifiConfigRuntime.save(snapshot.key,snapshot.record,snapshot.values);check(effectiveCarrier(card).equals("DITO"),"explicit recovery save restores DITO automatic template");}}
  }
  fresh();Object card=card(ROAM,"8963668800123457010");Map<String,String> manual=new LinkedHashMap<>();manual.put(CarrierPresets.KEY,"20404|apple_vodafone_nl");manual.put("domain","custom.example.org");record(card,manual);
  Object config=WifiConfigRuntime.resolve(card,WifiConfigModel.builtIn(card));check(((String)get(config,"c")).startsWith("Vodafone")&&get(config,"g").equals("custom.example.org"),"valid explicit operator and custom fields preserved");
 }
 static void classificationMigration(boolean previous)throws Exception {
  for(boolean manual:new boolean[]{false,true}){
   fresh();String id=nextId();Object card=card(ROAM,id);Map<String,String> edits=new LinkedHashMap<>();edits.put("domain","kept.example.org");edits.put("smsc","+639111111111");if(manual)edits.put(CarrierPresets.KEY,"20404|apple_vodafone_nl");String oldKey=WifiConfigRuntime.cardKey(card);record(card,edits);String oldRecord=overrides().values.get(oldKey);
   check(get(WifiConfigRuntime.resolve(card,WifiConfigModel.builtIn(card)),"g").equals("kept.example.org"),"pre-identification custom record loaded into native config");
   Object transport=new Transport(),auth=new Object();IdentityBinding.track(transport,controller(profile(id,"DITO",null,true)));IdentityBinding.begin(transport,auth);IdentityBinding.read(transport,auth,card);
   Object resolved=WifiConfigRuntime.resolve(card,WifiConfigModel.builtIn(card));check(get(resolved,"g").equals("kept.example.org"),"recognition keeps currently cached same-card custom fields");
   String stable=WifiConfigRuntime.cardKey(card);check(stable.equals(oldKey)==previous,"provider recognition moves only known same ICCID to stable key");check(oldRecord.equals(overrides().values.get(oldKey)),"legacy recovery record remains intact");
   if(!previous)check(oldRecord.equals(overrides().values.get(stable)),"stable migration copies original exact record");
   Object reread=card(POLAND,id);Object config=WifiConfigRuntime.resolve(reread,WifiConfigModel.builtIn(reread));
   if(!previous){check(get(config,"g").equals("kept.example.org"),"custom field survives later IMSI change");check(WifiConfigRuntime.smsc(reread,"").equals("+639111111111"),"SMSC survives later IMSI change");check(((String)get(config,"c")).startsWith(manual?"Vodafone":"DITO"),"valid explicit selection retains priority after new classification");}
  }
 }
 static void recognition(boolean previous)throws Exception {
  fresh();Object card=card(POLAND,"8963668800123457100");check(get(WifiConfigModel.builtIn(card),"c").equals("Polkomtel pl"),"actual native non-20404 roaming selector");
  check(DitoHomeIdentity.isDito(card)==!previous,"known DITO issuer recognition independent of roaming PLMN");check(effectiveCarrier(card).equals(previous?"Polkomtel pl":"DITO"),"Polish roaming DITO uses dedicated profile");check(blocked(card)==(!previous&&!fallbackPolicy),"non-20404 valid current identity follows authentication policy without inventing home");
  fresh();String id="8901234500123457101";DitoHomeIdentity.observe(card(HOME,id));Object roaming=card(POLAND,id);check(DitoHomeIdentity.isDito(roaming)==!previous,"same-card home evidence independent of roaming PLMN");Object auth=DitoHomeIdentity.connection(roaming);check(get(auth,"a").equals(previous?POLAND:HOME),"actual native card copy restores same-card home on new roaming PLMN");check(get(roaming,"a").equals(POLAND),"original card never rewritten");
  fresh();Object missingIccid=card(HOME,"");check(DitoHomeIdentity.isDito(missingIccid)==!previous,"real home IMSI can identify DITO without readable ICCID");check(DitoHomeIdentity.connection(missingIccid)==missingIccid,"real current home IMSI remains usable without manufactured ICCID");check(!WifiConfigRuntime.cardKey(missingIccid).equals(WifiConfigRuntime.cardKey(card("515660123456788",""))),"missing ICCID home identities do not share override key");DitoHomeIdentity.observe(missingIccid);check(!DitoHomeIdentity.isDito(card(ROAM,"8901234500123457102")),"missing ICCID does not teach another card");
  fresh();id="8963668800123457103";DitoHomeIdentity.observe(card(HOME,id));Object ambiguous=card(HOME,id,3);check(blocked(ambiguous)==!previous,"home-prefix with different MNC length cannot authenticate under DITO template");check(DitoHomeIdentity.settings(ambiguous)==ambiguous,"MNC3 current home-prefix identity must not be overwritten by saved history");check(get(ambiguous,"a").equals(HOME)&&get(ambiguous,"c").equals(3),"ambiguous physical card stays untouched");
  fresh();id="8963668800123457104";DitoHomeIdentity.observe(card(HOME,id,3));check(blocked(card(ROAM,id))==!fallbackPolicy,"ambiguous MNC does not teach home identity");if(fallbackPolicy)check(get(DitoHomeIdentity.connection(card(ROAM,id)),"a").equals(ROAM),"ambiguous read leaves genuine current credentials intact");
  fresh();Object manual=card(POLAND,"8901234500123457105");record(manual,Collections.singletonMap(CarrierPresets.KEY,DitoCarrierProfile.KEY));check(blocked(manual)==(!previous&&!fallbackPolicy),"manual DITO template does not invent credentials for other roaming PLMN");
  providerRecognition(previous);classificationMigration(previous);actualUsimRead();savedRecordRecognition(previous);
 }
 public static void main(String[]args)throws Exception {
  boolean legacy=args.length>1&&args[1].equals("legacy");boolean recognitionLegacy=args.length>1&&args[1].equals("recognition-legacy");boolean policyLegacy=args.length>1&&args[1].equals("identity-policy-legacy");fallbackPolicy=!legacy&&!recognitionLegacy&&!policyLegacy;
  android.content.res.AssetManager.root=java.nio.file.Paths.get(args[0]);zl5.f=new Context();
  Object library=Class.forName("fj5").getField("a").get(null);Class.forName("fj5").getField("d").set(null,zl5.f);
  Object file=library.getClass().getMethod("b").invoke(library);
  check(((List<?>)get(file,"a")).size()==3607,"actual shipped JSON parser loads full catalogue");
  check(CarrierPresets.all().size()==3607,"actual native directory and parsed presets match helper index");
  String roaming="204049876543210",home="515660123456789",iccid="8963668800123455526";
  Object raw=card(roaming,iccid),nativeConfig=WifiConfigModel.builtIn(raw),effective=WifiConfigRuntime.resolve(raw,nativeConfig);
  check(get(nativeConfig,"c").equals("Vodafone nl"),"actual native selector reproduces Vodafone on roaming identity");
  if(legacy){
   check(get(effective,"c").equals("Vodafone nl"),"previous shipped helper misses another DITO IIN batch");
   check(DitoHomeIdentity.connection(raw)==raw,"previous shipped helper lets missed DITO use roaming authentication");
   DitoHomeIdentity.observe(card(home,iccid));
   check(DitoHomeIdentity.settings(raw)==raw,"previous shipped helper does not remember other DITO batches");
   System.out.println("NATIVE_PROBE legacy_regression_reproduced=true checks="+checks);return;
  }
  check(get(effective,"c").equals("DITO")&&get(effective,"b").equals("apple_dito_ph"),"actual DEX helper automatically selects dedicated DITO profile");
  check(get(effective,"d").equals("515")&&get(effective,"e").equals("66"),"actual config has DITO home PLMN");
  check(get(get(effective,"i"),"T").equals("ipv4"),"actual native IP enum is IPv4");
  check(get(effective,"j").equals(Arrays.asList("aes128"))&&get(effective,"k").equals(Arrays.asList("sha1"))&&get(effective,"l").equals(Arrays.asList("sha1"))&&get(effective,"m").equals(Arrays.asList("modp1024")),"actual IKE algorithm fields match reference");
  check(get(effective,"n").equals(Arrays.asList("aes128"))&&get(effective,"o").equals(Arrays.asList("sha1")),"actual ESP algorithm fields match reference");
  check(get(effective,"x").equals(Arrays.asList(20,21,16384,16386)),"actual P-CSCF attributes include standard and vendor requests");
  check(get(get(effective,"z"),"q").equals(7200),"actual pinned native quirk constructor enables REGISTER expiry 7200");
  check(get(effective,"p").equals(20)&&get(effective,"u").equals(1300)&&Boolean.TRUE.equals(get(effective,"t")),"actual keepalive, UDP size and IPsec values match reference");
  if(fallbackPolicy)check(DitoHomeIdentity.connection(raw)==raw,"actual connection forwards genuine current identity without requiring historical home");
  else{try{DitoHomeIdentity.connection(raw);throw new AssertionError("legacy missing home identity unexpectedly connected");}
  catch(IllegalStateException expected){check(expected.getMessage().contains("51566"),"legacy connection rejects missing home record");}}
  DitoHomeIdentity.observe(card(home,iccid));Object restored=WifiConfigRuntime.resolve(raw,nativeConfig);
  check(((String)get(restored,"r")).startsWith("0"+home+"@"),"actual cached raw card is rebuilt when home identity becomes available");
  check(((String)get(restored,"s")).startsWith(home+"@"),"actual IMS and IKE identities use same saved home subscriber");
  Object auth=DitoHomeIdentity.connection(raw);
  check(get(auth,"a").equals(home)&&get(raw,"a").equals(roaming)&&auth!=raw,"actual immutable native card constructor supplies home authentication copy");
  check(get(auth,"b").equals(iccid)&&get(auth,"f").equals(get(raw,"f"))&&get(auth,"g").equals(get(raw,"g")),"actual cloned identity preserves ICCID, SMSC and phone number");
  check(WifiConfigRuntime.cardKey(raw).equals(WifiConfigRuntime.cardKey(card(home,iccid))),"actual DEX settings key is stable across home/roaming identities");
  check(CarrierPresets.find("51566|standard_plmn_51566").key.equals("51566|apple_dito_ph"),"actual index resolves legacy saved DITO key");
  Object selected=CarrierPresets.defaults(raw,Collections.singletonMap(CarrierPresets.KEY,"51566|standard_plmn_51566"));
  check(get(selected,"b").equals("apple_dito_ph")&&get(get(selected,"z"),"q").equals(7200),"actual legacy choice gains dedicated profile and registration expiry");
  state(raw,restored);WifiConfigRuntime.Snapshot snapshot=WifiConfigRuntime.snapshot();
  Map<String,String> edits=new LinkedHashMap<>(snapshot.values);edits.put("smsc","+639111111111");edits.put("smsc_list","+639111111111\n+639222222222");
  WifiConfigRuntime.saveSmsCenter(snapshot.key,snapshot.record,edits);
  check(get(zl5.b.value,"i").equals("+639111111111"),"actual native state constructor publishes SMSC save");
  state(card(home,iccid),CarrierPresets.defaults(card(home,iccid),null));
  check(WifiConfigRuntime.snapshot().values.get("smsc").equals("+639111111111"),"actual SMSC record survives return to home identity");
  Object reread=card(roaming,iccid);state(reread,WifiConfigModel.builtIn(reread));
  check(get(get(zl5.b.value,"f"),"c").equals("DITO")&&WifiConfigRuntime.displaySmsCenter(reread).equals("+639111111111"),"actual native state restores DITO and saved SMSC on new roaming read");
  Object other=card(roaming,"8948011234567890123");
  check(!DitoHomeIdentity.isDito(other)&&DitoHomeIdentity.connection(other)==other,"actual ordinary Vodafone identity remains untouched");
  check(get(CarrierPresets.defaults(other,null),"c").equals("Vodafone nl"),"actual ordinary Vodafone automatic profile retained");
  Object anotherDito=card(roaming,"8963668800123450001");
  if(fallbackPolicy)check(DitoHomeIdentity.connection(anotherDito)==anotherDito,"another DITO card uses its own actual identity instead of someone else's saved home");
  else{try{DitoHomeIdentity.connection(anotherDito);throw new AssertionError("used another card's home identity");}
  catch(IllegalStateException expected){check(expected.getMessage().contains("同卡"),"actual store never restores another DITO profile's identity");}}
  recognition(recognitionLegacy);
  System.out.println("NATIVE_PROBE "+(recognitionLegacy?"recognition_legacy_regression_reproduced":policyLegacy?"identity_policy_legacy_regression_reproduced":"current_passed")+"=true checks="+checks+" catalogue=3607 register_expires=7200");
 }
}

/** APDU transport fixture only; the native vb5 coroutine and EF parsers are executed unchanged. */
final class ac5 {
 public android.content.Context b;public byte[] i;public final Map<Integer,byte[]> files=new HashMap<>();public final List<Integer> reads=new ArrayList<>();
 public Object m(dt0 continuation){return sc5.a;}
 public java.io.Serializable g(int id,boolean mf,dt0 continuation){reads.add(id);byte[] value=files.get(id);if(value==null)throw new IllegalStateException("synthetic EF read failure "+Integer.toHexString(id));return value.clone();}
 public static java.io.Serializable b(ac5 transport,int file,int unused,dt0 continuation){throw new IllegalStateException("synthetic optional record absent");}
 public Object h(dt0 continuation){return Boolean.FALSE;}
}
