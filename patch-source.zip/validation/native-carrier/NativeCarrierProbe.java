import java.util.*;
import android.content.*;
import cc.forserein.simhub.internal.*;

/** Execute the APK's real parser, preset builder, identity/config/quirk constructors and helpers. */
public final class NativeCarrierProbe {
 static int checks;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
 public static final class Flow {
  public Object value;
  public Object getValue(){return value;}
  public boolean h(Object previous,Object next){if(value!=previous)return false;value=next;return true;}
 }
 public static class Prefs implements SharedPreferences {
  final Map<String,String> values=new HashMap<>();
  public String getString(String key,String fallback){return values.containsKey(key)?values.get(key):fallback;}
  public Editor edit(){return new Editor(){public Editor putString(String k,String v){values.put(k,v);return this;}public Editor remove(String k){values.remove(k);return this;}public boolean commit(){return true;}};}
 }
 public static class Context extends android.content.Context {
  final Map<String,Prefs> values=new HashMap<>();
  public SharedPreferences getSharedPreferences(String name,int mode){if(!values.containsKey(name))values.put(name,new Prefs());return values.get(name);}
 }
 static Object get(Object object,String name)throws Exception{return WifiConfigModel.get(object,name);}
 static Object card(String imsi,String iccid)throws Exception {
  return WifiConfigModel.constructor(Class.forName("ek5"),8).newInstance(imsi,iccid,2,null,null,"+639123456789","+639000000000",null);
 }
 static void state(Object card,Object config)throws Exception {
  Object phase=Class.forName("tk5").getField("g").get(null);
  zl5.b.value=WifiConfigModel.constructor(Class.forName("gl5"),20).newInstance("SIM","test",false,null,card,config,false,null,null,"490154203237518",phase,false,null,null,null,new ArrayList<>(),new ArrayList<>(),false,null,0L);
 }
 public static void main(String[]args)throws Exception {
  boolean legacy=args.length>1&&args[1].equals("legacy");
  android.content.res.AssetManager.root=java.nio.file.Paths.get(args[0]);zl5.f=new Context();
  Object library=Class.forName("fj5").getField("a").get(null);Class.forName("fj5").getField("d").set(null,zl5.f);
  Object file=library.getClass().getMethod("b").invoke(library);
  check(((List<?>)get(file,"a")).size()==3607,"actual shipped JSON parser loads full catalogue");
  check(CarrierPresets.all().size()==3607,"actual native directory and parsed presets match helper index");
  String roaming="204049876543210",home="515660123456789",iccid="8963668800123455526";
  Object raw=card(roaming,iccid),nativeConfig=WifiConfigModel.builtIn(raw),effective=WifiConfigRuntime.resolve(raw,nativeConfig);
  check(get(nativeConfig,"c").equals("Vodafone nl"),"actual native selector reproduces Vodafone on roaming identity");
  if(legacy){
   check(get(effective,"c").equals("Vodafone nl"),"previous shipped helper misses another DITO IIN batch");
   check(DitoHomeIdentity.connection(raw)==raw,"previous shipped helper lets missed DITO use roaming authentication");
   DitoHomeIdentity.observe(card(home,iccid));
   check(DitoHomeIdentity.settings(raw)==raw,"previous shipped helper does not remember other DITO batches");
   System.out.println("NATIVE_PROBE legacy_regression_reproduced=true checks="+checks);return;
  }
  check(get(effective,"c").equals("DITO")&&get(effective,"b").equals("apple_dito_ph"),"actual DEX helper automatically selects dedicated DITO profile");
  check(get(effective,"d").equals("515")&&get(effective,"e").equals("66"),"actual config has DITO home PLMN");
  check(get(get(effective,"i"),"T").equals("ipv4"),"actual native IP enum is IPv4");
  check(get(effective,"j").equals(Arrays.asList("aes128"))&&get(effective,"k").equals(Arrays.asList("sha1"))&&get(effective,"l").equals(Arrays.asList("sha1"))&&get(effective,"m").equals(Arrays.asList("modp1024")),"actual IKE algorithm fields match reference");
  check(get(effective,"n").equals(Arrays.asList("aes128"))&&get(effective,"o").equals(Arrays.asList("sha1")),"actual ESP algorithm fields match reference");
  check(get(effective,"x").equals(Arrays.asList(20,21,16384,16386)),"actual P-CSCF attributes include standard and vendor requests");
  check(get(get(effective,"z"),"q").equals(7200),"actual pinned native quirk constructor enables REGISTER expiry 7200");
  check(get(effective,"p").equals(20)&&get(effective,"u").equals(1300)&&Boolean.TRUE.equals(get(effective,"t")),"actual keepalive, UDP size and IPsec values match reference");
  try{DitoHomeIdentity.connection(raw);throw new AssertionError("missing home identity connected");}
  catch(IllegalStateException expected){check(expected.getMessage().contains("51566"),"actual connection rejects missing home record");}
  DitoHomeIdentity.observe(card(home,iccid));Object restored=WifiConfigRuntime.resolve(raw,nativeConfig);
  check(((String)get(restored,"r")).startsWith("0"+home+"@"),"actual cached raw card is rebuilt when home identity becomes available");
  check(((String)get(restored,"s")).startsWith(home+"@"),"actual IMS and IKE identities use same saved home subscriber");
  Object auth=DitoHomeIdentity.connection(raw);
  check(get(auth,"a").equals(home)&&get(raw,"a").equals(roaming)&&auth!=raw,"actual immutable native card constructor supplies home authentication copy");
  check(get(auth,"b").equals(iccid)&&get(auth,"f").equals(get(raw,"f"))&&get(auth,"g").equals(get(raw,"g")),"actual cloned identity preserves ICCID, SMSC and phone number");
  check(WifiConfigRuntime.cardKey(raw).equals(WifiConfigRuntime.cardKey(card(home,iccid))),"actual DEX settings key is stable across home/roaming identities");
  check(CarrierPresets.find("51566|standard_plmn_51566").key.equals("51566|apple_dito_ph"),"actual index resolves legacy saved DITO key");
  Object selected=CarrierPresets.defaults(raw,Collections.singletonMap(CarrierPresets.KEY,"51566|standard_plmn_51566"));
  check(get(selected,"b").equals("apple_dito_ph")&&get(get(selected,"z"),"q").equals(7200),"actual legacy choice gains dedicated profile and registration expiry");
  state(raw,restored);WifiConfigRuntime.Snapshot snapshot=WifiConfigRuntime.snapshot();
  Map<String,String> edits=new LinkedHashMap<>(snapshot.values);edits.put("smsc","+639111111111");edits.put("smsc_list","+639111111111\n+639222222222");
  WifiConfigRuntime.saveSmsCenter(snapshot.key,snapshot.record,edits);
  check(get(zl5.b.value,"i").equals("+639111111111"),"actual native state constructor publishes SMSC save");
  state(card(home,iccid),CarrierPresets.defaults(card(home,iccid),null));
  check(WifiConfigRuntime.snapshot().values.get("smsc").equals("+639111111111"),"actual SMSC record survives return to home identity");
  Object reread=card(roaming,iccid);state(reread,WifiConfigModel.builtIn(reread));
  check(get(get(zl5.b.value,"f"),"c").equals("DITO")&&WifiConfigRuntime.displaySmsCenter(reread).equals("+639111111111"),"actual native state restores DITO and saved SMSC on new roaming read");
  Object other=card(roaming,"8948011234567890123");
  check(!DitoHomeIdentity.isDito(other)&&DitoHomeIdentity.connection(other)==other,"actual ordinary Vodafone identity remains untouched");
  check(get(CarrierPresets.defaults(other,null),"c").equals("Vodafone nl"),"actual ordinary Vodafone automatic profile retained");
  Object anotherDito=card(roaming,"8963668800123450001");
  try{DitoHomeIdentity.connection(anotherDito);throw new AssertionError("used another card's home identity");}
  catch(IllegalStateException expected){check(expected.getMessage().contains("同卡"),"actual store never restores another DITO profile's identity");}
  System.out.println("NATIVE_PROBE current_passed=true checks="+checks+" catalogue=3607 register_expires=7200");
 }
}
