import java.util.*;
import java.lang.reflect.*;
import cc.forserein.simhub.internal.*;

/** Actual APK worker inputs; only the post-IKE response and outgoing SIP transport are fixture boundaries. */
public final class NativeAuthenticationInputsProbe {
 static int checks,transportCalls;static Object capturedManager,capturedRegister;static String lastWireIdentity;
 static final String ROAM="204049876543210",HOME="515660123456789",IIN="8963668800123455526",UNKNOWN="8901234500123455526";
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
 static Map<String,String> values(String... pairs){Map<String,String> result=new LinkedHashMap<>();for(int i=0;i<pairs.length;i+=2)result.put(pairs[i],pairs[i+1]);return result;}
 static ek5 card(String imsi,String iccid,int mnc)throws Exception{return(ek5)NativeCarrierProbe.card(imsi,iccid,mnc);}
 static xi5 config(ek5 card,Map<String,String> values)throws Exception {if(values!=null)NativeCarrierProbe.record(card,values);return(xi5)WifiConfigRuntime.resolve(card,WifiConfigModel.builtIn(card));}
 static ek5 connection(ek5 card,xi5 config)throws Exception {
  try{return(ek5)DitoHomeIdentity.class.getMethod("connection",Object.class,Object.class).invoke(null,card,config);}
  catch(InvocationTargetException e){Throwable cause=e.getCause();if(cause instanceof Exception)throw(Exception)cause;throw(Error)cause;}
 }
 static void blocked(ek5 card,xi5 config,String label)throws Exception {try{connection(card,config);throw new AssertionError("invalid identity accepted: "+label);}catch(IllegalStateException expected){check(true,label);}}
 /** Adapter returns suspension at the actual K() transport boundary before any socket send. */
 public static Object captureRegister(Object manager,Object request){capturedManager=manager;capturedRegister=request;return pu0.T;}
 static String permanent(ek5 card){String mnc=card.c();while(mnc.length()<3)mnc="0"+mnc;return "0"+card.a+"@nai.epc.mnc"+mnc+".mcc"+card.b()+".3gppnetwork.org";}
 static int word(byte[] data,int offset){return((data[offset]&255)<<8)|(data[offset+1]&255);}
 /** Independent RFC 4187 sections 8.1/10.5 byte checks, not the native decoder validating itself. */
 static void akaIdentity(da1 engine,String identity)throws Exception {
  akaIdentity(engine,identity,10,0x87); // User's AT_PERMANENT_ID_REQ.
  akaIdentity(engine,identity,13,0x88); // AT_ANY_ID_REQ remains compatible.
 }
 static void akaIdentity(da1 engine,String identity,int requestAttribute,int identifier)throws Exception {
  byte[] request={1,(byte)identifier,0,12,23,5,0,0,(byte)requestAttribute,1,0,0};
  Object result=engine.b(request,null);check(result instanceof z91,"real EAP-AKA worker answers Identity Request without authenticating");
  byte[] response=((z91)result).a,expected=identity.getBytes("UTF-8");int attributeLength=((4+expected.length+3)/4)*4;
  check(response.length==8+attributeLength&&word(response,2)==response.length,"EAP big-endian total length includes padded AT_IDENTITY");
  check((response[0]&255)==2&&(response[1]&255)==identifier,"EAP Response echoes unsigned Request Identifier");
  check(response[4]==23&&response[5]==5&&response[6]==0&&response[7]==0,"EAP-AKA type, Identity subtype and reserved bytes");
  check(response[8]==14&&(response[9]&255)*4==attributeLength,"AT_IDENTITY length is measured in four-byte words");
  check(word(response,10)==expected.length,"AT_IDENTITY actual identity length excludes zero padding");
  check(Arrays.equals(Arrays.copyOfRange(response,12,12+expected.length),expected),"actual wire identity equals permanent input bytes without changed subscriber digits");
  boolean zeros=true;for(int i=12+expected.length;i<response.length;i++)zeros&=response[i]==0;
  check(zeros,"AT_IDENTITY alignment padding contains only zeros");
  lastWireIdentity=new String(response,12,expected.length,"UTF-8");
  check(engine.c==null&&engine.f==null,"identity exchange still has no authentication key material");
 }
 static void workers(ek5 physical,ek5 effective,xi5 config,String expectedImsi)throws Exception {
  check(effective.a.equals(expectedImsi),"connection uses expected actually read subscriber digits");
  check(config.r!=null&&!config.r.isEmpty(),"effective config supplies an outer identity to the native worker");
  qg0 transport=(qg0)Proxy.newProxyInstance(qg0.class.getClassLoader(),new Class<?>[]{qg0.class},(proxy,method,args)->{transportCalls++;throw new AssertionError("unexpected physical transport call: "+method.getName());});
  // Construct the APK's real AKA transport owner; no ac5 test double is on this process's classpath.
  ac5 auth=new ac5(transport,zl5.f);s01 adapter=new s01(auth);
  hm0 job=new hm0(auth,config,effective,37,null);
  check(job.a0==auth&&job.b0==config&&job.c0==effective,"actual native connection job captures same auth, config and identity");
  check(adapter.U==auth&&auth.a==transport,"actual AKA adapter retains this physical transport");
  ws1 logger=new ws1(){public Object i(Object ignored){return sc5.a;}};
  b72 ike=new b72(config,adapter,logger);
  check(ike.a==config&&ike.b==adapter,"actual IKE constructor receives effective config and same card adapter");
  String outer=s62.a(b72.Companion,null,config.r);
  check(outer.equals(config.r),"native IKE identity selection preserves configured outer NAI");
  w62 response=new w62(ike,null);response.f0=Integer.MIN_VALUE|1;response.W=outer;response.Y=outer;response.d0=Collections.emptyList();
  boolean noChallenge=false;
  try{ike.e(null,null,null,null,response);}catch(Throwable failure){if(failure instanceof u52)noChallenge=true;else throw new AssertionError("unexpected native post-IKE reply failure",failure);}
  check(noChallenge&&ike.v!=null,"actual IKE_AUTH response path creates EAP then rejects absent network challenge");
  String permanent=config.y==null?config.r:config.y;
  check(new String(ike.v.b,"UTF-8").equals(permanent),"actual b72.e reads configured permanent y or fallback r into da1 bytes");
  check(ike.v.a==adapter&&ike.v.a.U==auth,"actual EAP AKA engine retains original physical card adapter");
  check(!ike.v.d&&ike.v.c==null,"no EAP success or key material fabricated by input probe");
  akaIdentity(ike.v,permanent);
  x82 local=new x82(new byte[]{(byte)192,0,2,1}),proxy=new x82(new byte[]{(byte)192,0,2,2});
  e72 tunnel=new e72("synthetic-tunnel",local,null,new ArrayList<x82>(Arrays.asList(proxy)),new ArrayList<x82>());
  o82 ims=new o82(ike,tunnel,config,effective,adapter,logger);
  check(ims.a==ike&&ims.b==config&&ims.c==effective&&ims.d==adapter,"actual IMS constructor retains same config, identity and AKA adapter");
  String impu=config.A==null?"sip:"+expectedImsi+"@"+config.g:config.A;
  check(ims.n().equals(impu),"actual IMS public identity uses current/saved real IMSI or explicit override");
  check(ims.p.startsWith(effective.b()+effective.c()),"native PLMN-derived information keeps actual effective identity PLMN");
  capturedManager=null;capturedRegister=null;
  Object result=ims.v(null);
  check(result==pu0.T&&capturedManager==ims&&capturedRegister instanceof kb4,"actual REGISTER builder suspends at isolated transport boundary");
  kb4 request=(kb4)capturedRegister;String authorization=request.j("Authorization").toString();
  check(authorization.contains("username=\""+config.s+"\""),"actual REGISTER authorization reads configured IMPI s");
  check(authorization.contains("realm=\""+config.c()+"\"")&&authorization.contains("uri=\"sip:"+config.c()+"\""),"actual REGISTER uses configured realm");
  check(request.j("From").toString().contains(impu)&&request.j("To").toString().contains(impu),"native REGISTER public identities follow effective identity");
  check(authorization.contains("response=\"\"")&&ike.F==null,"REGISTER still awaits genuine carrier challenge and USIM result");
  check(transportCalls==0,"no APDU or physical card method called by offline input validation");
  check(physical.b.equals(effective.b),"physical ICCID preserved across actual worker input chain");
 }
 static void current()throws Exception {
  // Genuine current credentials, including another roaming PLMN, are never relabelled as 51566.
  for(String[] sample:new String[][]{{ROAM,"2"},{"260019876543210","2"},{"310260123456789","3"},{"20404123456789","2"}}){
   NativeCarrierProbe.fresh();ek5 raw=card(sample[0],IIN,Integer.parseInt(sample[1]));xi5 config=config(raw,null);ek5 effective=connection(raw,config);
   check(effective==raw&&config.c.equals("DITO"),"automatic DITO without history uses untouched current identity");
   check(config.r.equals(permanent(raw))&&config.y.equals(permanent(raw)),"automatic DITO outer/permanent EAP identity uses actual IMSI and actual MNC length");
   check(config.s.equals(raw.a+"@ims.mnc066.mcc515.3gppnetwork.org")&&config.f.equals(Arrays.asList("epdg.epc.mnc066.mcc515.pub.3gppnetwork.org")),"DITO IMS realm and ePDG remain selected independently of EAP subscriber realm");
   workers(raw,effective,config,raw.a);
  }
  NativeCarrierProbe.fresh();ek5 manual=card(ROAM,UNKNOWN,2);xi5 selected=config(manual,values(CarrierPresets.KEY,DitoCarrierProfile.KEY));
  check(!DitoHomeIdentity.isDito(manual)&&selected.c.equals("DITO"),"manual preset is effective without being learned as physical carrier evidence");
  workers(manual,connection(manual,selected),selected,ROAM);
  NativeCarrierProbe.fresh();ek5 outerOnly=card(ROAM,IIN,2);xi5 outerConfig=config(outerOnly,values("nai","outer@operator.example.org"));
  check(outerConfig.r.equals("outer@operator.example.org")&&outerConfig.y.equals(permanent(outerOnly)),"outer-only override does not replace built-in permanent EAP identity");
  workers(outerOnly,connection(outerOnly,outerConfig),outerConfig,ROAM);
  check(lastWireIdentity.equals(permanent(outerOnly))&&!lastWireIdentity.equals(outerConfig.r),"actual AKA-Identity response ignores outer-only override");
  NativeCarrierProbe.fresh();ek5 custom=card(ROAM,IIN,2);xi5 overrides=config(custom,values("nai","outer@operator.example.org","eap","permanent@operator.example.org","impi","private@ims.example.org","impu","sip:public@ims.example.org","domain","ims.example.org"));
  check(overrides.r.equals("outer@operator.example.org")&&overrides.y.equals("permanent@operator.example.org")&&overrides.s.equals("private@ims.example.org"),"explicit NAI, permanent EAP and IMPI survive automatic DITO resolution");
  workers(custom,connection(custom,overrides),overrides,ROAM);
  check(lastWireIdentity.equals("permanent@operator.example.org"),"explicit permanent EAP override wins in actual wire response");
  NativeCarrierProbe.fresh();ek5 raw=card(ROAM,IIN,2);DitoHomeIdentity.observe(card(HOME,IIN,2));xi5 restored=config(raw,null);ek5 effective=connection(raw,restored);
  check(effective!=raw&&raw.a.equals(ROAM)&&restored.r.contains(HOME)&&restored.s.contains(HOME),"recorded actual same-card home remains preferred for DITO");workers(raw,effective,restored,HOME);
  NativeCarrierProbe.fresh();DitoHomeIdentity.observe(card(HOME,IIN,2));ek5 other=card(ROAM,"8963668800123455527",2);xi5 otherConfig=config(other,null);
  check(connection(other,otherConfig)==other&&!otherConfig.r.contains(HOME),"another card's home record cannot change fallback credentials");workers(other,connection(other,otherConfig),otherConfig,ROAM);
  NativeCarrierProbe.fresh();DitoHomeIdentity.observe(card(HOME,IIN,2));ek5 foreignSelected=card(ROAM,IIN,2);xi5 foreign=config(foreignSelected,values(CarrierPresets.KEY,"20404|apple_vodafone_nl"));
  check(foreign.c.startsWith("Vodafone")&&connection(foreignSelected,foreign)==foreignSelected,"explicit non-DITO carrier is respected despite DITO issuer and home history");
  workers(foreignSelected,connection(foreignSelected,foreign),foreign,ROAM);
  // Native presets also match ICCID, so one arbitrary unknown IIN cannot be assumed to mean Vodafone.
  for(String ordinaryIccid:new String[]{"8948011234567890123",UNKNOWN}){
   NativeCarrierProbe.fresh();ek5 ordinary=card(ROAM,ordinaryIccid,2);xi5 nativeConfig=(xi5)WifiConfigModel.builtIn(ordinary),ordinaryConfig=config(ordinary,null);
   check(!DitoHomeIdentity.isDito(ordinary)&&Objects.equals(ordinaryConfig.c,nativeConfig.c)&&Objects.equals(ordinaryConfig.r,nativeConfig.r)&&Objects.equals(ordinaryConfig.y,nativeConfig.y)&&Objects.equals(ordinaryConfig.s,nativeConfig.s),"ordinary non-DITO carrier keeps native carrier/outer/permanent/IMS identities");
   if(ordinaryIccid.startsWith("894801"))check(ordinaryConfig.c.startsWith("Vodafone"),"ordinary Vodafone control retains actual native template");
   workers(ordinary,connection(ordinary,ordinaryConfig),ordinaryConfig,ROAM);
  }
  // Malformed subscriber data is rejected before native worker construction.
  NativeCarrierProbe.fresh();xi5 dito=config(card(ROAM,IIN,2),null);
  for(ek5 invalid:new ek5[]{card("20404",IIN,2),card("20404987654321x",IIN,2),card("2040498765432100",IIN,2),card(ROAM,IIN,0),card(ROAM,IIN,4),card(HOME,IIN,3)})blocked(invalid,dito,"invalid actual identity/MNC rejected");
 }
 static void realmLegacy()throws Exception {
  NativeCarrierProbe.fresh();ek5 raw=card(ROAM,IIN,2);xi5 config=config(raw,null);ek5 effective=connection(raw,config);
  check(effective==raw&&config.c.equals("DITO"),"23.7 reaches native worker with genuine roaming identity");
  check(config.r.equals("0"+raw.a+"@nai.epc.mnc066.mcc515.3gppnetwork.org")&&config.y==null,"23.7 generated EAP realm follows selected DITO template");
  workers(raw,effective,config,ROAM);
  check(lastWireIdentity.equals(config.r)&&!lastWireIdentity.equals(permanent(raw)),"23.7 actual AKA Identity sends template realm instead of actual subscriber PLMN");
  NativeCarrierProbe.fresh();raw=card(ROAM,IIN,2);config=config(raw,values("nai","outer@operator.example.org"));
  check(config.y==null,"23.7 has no separate built-in permanent identity");
  workers(raw,connection(raw,config),config,ROAM);
  check(lastWireIdentity.equals("outer@operator.example.org"),"23.7 outer-only override also changes actual permanent identity response");
 }
 public static void main(String[]args)throws Exception {
  android.content.res.AssetManager.root=java.nio.file.Paths.get(args[0]);
  boolean legacy=args.length>1&&args[1].equals("identity-policy-legacy");
  if(args.length>1&&args[1].equals("identity-realm-legacy")){realmLegacy();System.out.println("NATIVE_AUTH_INPUTS identity_realm_legacy_regression_reproduced=true checks="+checks);return;}
  if(legacy){for(boolean manual:new boolean[]{false,true}){NativeCarrierProbe.fresh();ek5 raw=card(ROAM,manual?UNKNOWN:IIN,2);xi5 config=config(raw,manual?values(CarrierPresets.KEY,DitoCarrierProfile.KEY):null);check(config.c.equals("DITO"),"old helper already selected DITO template");boolean rejected=false;try{DitoHomeIdentity.connection(raw);}catch(IllegalStateException expected){rejected=true;}check(rejected,"23.6 locally rejects genuine current identity before native worker");}System.out.println("NATIVE_AUTH_INPUTS legacy_regression_reproduced=true checks="+checks);return;}
  current();System.out.println("NATIVE_AUTH_INPUTS current_passed=true checks="+checks+" no_apdu=true no_socket=true");
 }
}
