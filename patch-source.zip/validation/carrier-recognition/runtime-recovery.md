# DITO 模板选择与坏记录恢复复核

23.4 中，已知 DITO IIN、完整 ICCID 与 20404 漫游 IMSI 的正常自动配置会生成 DITO，内置原始 PLMN 选择器则是 Vodafone nl。模板库没有 Vodafone pl 这一实体。不能仅凭正常合成用例推断用户手机没有问题。

已直接执行 23.4 的 vb5.q：EF_ICCID 读失败会被原生读取流程吞掉，继续返回空 ICCID 的卡对象；同一次 IMSI 成功时，旧 helper 最终显示 Vodafone nl。12 项读取边界断言通过。这里仅替换 APDU 传输，实际 parser/模型/选择器执行；尚无用户日志证明其设备正发生此故障。

另确认持久化模板 key 失效会使已识别 DITO 回退 Vodafone，同时 snapshot 抛异常导致无法进入配置恢复。有效手动 Vodafone 选择则是明确用户覆盖，需保留。独立旧 APK 复现共 22 项。

Runtime 修复在加载时校验 key，失效/损坏记录沿现有警告恢复草稿；已确认 DITO 的 live fallback 使用干净 DITO 配置并清空有效 state.h ePDG 覆盖，防止只改名称却继续连旧端点。原磁盘记录保留至用户明确保存。有效手动选择、实际 IMSI 和归属身份认证检查保持。

兼容性处理限定为：完整数字 ICCID 才用稳定 DITO 存储键；缺 ICCID 的真实归属卡按实际 IMSI 分离。首次归属读取改变配置 key 时，只可从之前已加载、完整同 ICCID 的旧缓存身份所对应的磁盘记录复制；已有 destination/current/home 记录优先，旧记录保留，无扫描、持久化索引或猜测 IMSI。

专项 55 项和五个现有配置套件共 301 项 host 断言通过；主修独立 actual 23.4 模型加候选 Runtime 63 项及迁移扩展 29 项通过，生产文件已冻结。最终 APK/ART/真实运营商网络验证由对应代理另行执行。报告与源码哈希见同名 JSON。
