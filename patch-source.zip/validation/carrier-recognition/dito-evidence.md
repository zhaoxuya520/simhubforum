# DITO evidence and home-identity validation

Production scope: `DitoHomeIdentity.java`. Dedicated regressions: `DitoRecognitionEvidenceTest.java`; two prior negative classification expectations in `DitoHomeIdentityTest.java` now recognize trusted issuer evidence without learning a home identity.

- Valid current `51566` with two-digit MNC identifies DITO even when ICCID is unavailable. That read can supply its actual current credentials, but cannot create or restore a same-card record without a complete ICCID.
- Other valid current IMSIs require a complete 19–20 digit ICCID and a known DITO issuer, an actual same-card home read, or an exact matched provider name. Classification no longer depends on current `20404`.
- `observeProvider(Object, String)` accepts only normalized exact DITO / DITO Telecommunity / DITO Telecommunity Corporation. IdentityBinding owns fresh generation, transport and complete physical ICCID matching. Provider markers use a separate hashed-key preference store and contain no IMSI.
- A provider commit failure remains visible; the exact already verified read retains transient evidence through weak references compared by object identity. A separate value-equal native identity cannot inherit it. Native `ek5.equals` made a conventional WeakHashMap unsuitable, which was reproduced before correction.
- Learning still requires an actual `51566` / two-digit MNC read. A current `51566` / three-digit MNC is neither learned nor replaced with history and produces a specific connection error. Other identified or manually selected DITO identities need actual same-card home credentials before authentication.
- Existing read logs explain the evidence, current PLMN and missing credentials without full IMSI/ICCID. An unverified `20404` reports missing DITO evidence while keeping native carrier matching. Missing ICCID reports unverified ownership without borrowing a management selection.

Validation: 183 dedicated assertions and 88 existing home-identity assertions pass. The previous compiled helper fails the known-issuer/non-20404 regression. The initial WeakHashMap candidate fails a distinct value-equal read regression; the corrected helper passes. An independent probe using the actual APK native `ek5` model confirms that failed persistence identifies only the verified first object, not a distinct value-equal object. Source hashes and exact outputs are in `dito-evidence.json`.

These checks use Android preference/platform fixtures. They do not prove live DITO network registration, AKA authorization, or this user's physical card contents. No home IMSI is derived from a roaming IMSI or selected template. APK/native integration and final ART checks are recorded separately by the build.
