# DITO recognition regression evidence (23.5)

`native-baseline.json` records **107 assertions against the signed 23.4 APK**, SHA-256 `77774c46dbf8d828c7daa7f895306f172fa96e30f630ac83c95c5dd4a11d0eac`. It includes the existing 25 carrier checks and new assertions that reproduce the old behavior. This is not a claim of 107 distinct defects.

The old APK genuinely misses known DITO on non-20404 roaming identities, ignores verified same-ICCID provider metadata, falls back to the native roaming template when a saved preset key is no longer present, and cannot open that missing-preset record for recovery. A corrupt record can retain a legacy ePDG. A selected DITO template on another roaming PLMN also bypasses the old missing-home guard. New mode expectations check those behaviors explicitly; current mode checks their corrected counterparts and preserves valid manual selections.

The native directory names are taken from actual parsed assets. `20404` selects `Vodafone nl`; `26001` selects `Polkomtel pl`. The synthetic unknown issuer beginning `890123` can select `CellularSouth LTE US` through the native ICCID rule. Tests do not relabel these results as the user's reported `Vodafone pl`.

Execution boundaries:

- Actual APK `fj5` JSON parser, carrier catalogue, native preset builder, `ek5`, `xi5`, `yj5`, `gl5`, `qy3`, `xx3` and shipped helpers execute on the host JVM after the existing generic R8 DEX/JVM adaptation.
- Actual `vb5.q` coroutine and EF decoders read synthetic EF_IMSI / EF_ICCID / EF_AD bytes. Only `ac5` APDU transport is replaced; optional EF reads fail explicitly. EF_ICCID failure must remain an empty physical ICCID: with a roaming IMSI and no reliable evidence, the test does **not** manufacture DITO ownership.
- The `IdentityBinding` provider tests construct actual profile/chip models, but the controller, transport identity, async read generation and `SharedPreferences` are fixtures. They separately exercise exact ICCID matching, immutable pre-read snapshots, conflicting providers, stale reads, and wrong transports. This is not a live UICC read through an Android reader.
- Actual `gl5` construction verifies published effective config and ePDG. Recovery tests check that opening an invalid-record editor does not rewrite preferences; only the explicit save commits the recovery.
- Existing manual operator choices, Domain/SMSC edits, same-card migration and native MNC length remain covered. A 51566-prefix card reporting a 3-digit MNC cannot silently replace its current identity with saved history.

Run the full baseline independently with:

```
python tests/check_native_carrier_runtime.py PREVIOUS_23_4.apk PREVIOUS_DECODED --recognition-legacy --report native-recognition-baseline.json
```

The original `--legacy` mode remains available for the earlier IIN regression. The final 23.5 build uses the default current mode. Fixture compilation now uses the tested APK's normalized jar rather than `build-config3/classes`; the report records source and translated-jar hashes. Final positive results must come from the final APK runner, not the temporary source-helper overlay used while developing these cases.

These are host JVM regressions, not ART, a real SIM, successful ePDG authentication, or a carrier call.
