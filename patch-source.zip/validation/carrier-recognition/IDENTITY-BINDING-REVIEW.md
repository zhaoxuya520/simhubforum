# Exact-card provider evidence review

`IdentityBinding` now captures an immutable profile provider snapshot for each transport and binds it to the read generation. Provider evidence is accepted only after the real USIM ICCID is complete and exactly equals a profile ICCID in that snapshot. Conflicting duplicate providers, missing ICCIDs, wrong transports, stale reads and metadata arriving after the read starts cannot provide evidence. Selected EID, enabled status, nickname and profile name are not identity evidence.

The native metadata model is `qy3`: `a` is full ICCID, `d` is serviceProviderName. The actual `if1.h(byte[])` parser obtains these from tags `0x5A` and `0x91`; tags `0x90` and `0x92` are the separate nickname/profileName fields. `iz3.l()` supplies chip records (`xx3`) whose `d` field contains those profiles. The physical USIM identity remains `ek5`; no parser, APDU or switch path was changed.

The dedicated host test passes 73 assertions. The same new test fails against the 23.4 helper at the first expected provider recognition assertion, confirming that the added case previously failed. These are host tests with explicit Android/model fixtures, not physical card reads. Fixture carrier labels are not claims about the actual native catalogue: different ICCID selectors can choose different real carrier presets.

Independent review of the recognition/config changes found and closed one additional issue: native `ek5` uses structural equality, so a WeakHashMap could transfer volatile provider evidence to a distinct but equal read object after persistence failed. A real native-model probe reproduced this, then passed after identity-based weak references replaced the map. The verified original object remains recognized; the unverified equal object does not inherit evidence.

The reviewed candidate preserves exact-card configuration keys, bounded migration from a previously observed same-card key, the missing-home-identity connection block, and the refusal to overwrite a current 51566 read with inconsistent MNC length. Invalid saved settings recover to clean DITO defaults without silently deleting the stored record. No remaining blocker was observed in these reviewed paths. Final APK/ART/device results are recorded separately.

Hashes and structured results: `identity-binding-evidence.json`. No decompiled original code or user identification numbers are included.
