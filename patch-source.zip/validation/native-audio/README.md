# Native Android audio lifecycle regression probe

The probe translates the candidate APK DEX and executes its own `yz` audio controller,
`xz` permission/route functions, and the native `wz` / `k7` capture/playback workers.
Only Android hardware/system APIs are replaced with explicit Java test doubles. The
shared R8 constructor/interface adaptation is JVM-only; it does not alter the APK.

The released 23.2 APK reproduces these failures:

- `AudioTrack.play()` throws after construction: the track is never stored, so the
  existing startup rollback cannot release it.
- Audio-focus acquisition throws after setting communication mode: it is outside
  the startup rollback, leaving the previous mode unrestored.
- An optional audio effect is created but `setEnabled()` throws: the error handler
  discards the created object without releasing it.
- A release/abandon operation throws: later independent cleanup is skipped, leaving
  other audio objects or the previous audio mode unrestored.

The bounded `yz.d/e/f/g` patch registers ownership before fallible operations,
rolls back all startup steps, releases failed optional effects, and isolates each
cleanup step. Existing sample rates, microphone source, routing selection, effect
policy, native codecs and Telecom ownership are unchanged.

Run `tests/check_native_audio_runtime.py APK DECODED --report REPORT` for the
candidate; pass `--legacy` for the published 23.2 regression. The test also executes
a normal acquisition/start/stop cycle with both real worker methods, checks all
optional effect failure branches, independent cleanup failures, repeated cleanup,
and preservation of Telecom-owned system mode/focus/route.

This is a hardware failure-injection regression test, not evidence of working
microphones/speakers, OEM audio policy, actual decoded voice or a carrier call.
The standalone DEX analyzer and Android emulator checks cover separate verifier
and startup risks.

`protocol-review.json` records the exact AOSP Android 15 API sources inspected,
including hashes and links. AOSP `AudioTrack.play()` and `AudioEffect.setEnabled()`
can throw when the underlying audio object is no longer initialized; release is
therefore required even when audio startup or an optional effect fails.
