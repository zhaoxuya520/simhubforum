package android.os;
public class Process {public static void setThreadPriority(int priority){}public static int myPid(){return 42;} public static int myUid(){return 42;}}
