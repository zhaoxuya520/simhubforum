package android.media;
public class AudioManager {
 public interface OnAudioFocusChangeListener {void onAudioFocusChange(int n);}
 public int mode,focusRequests,focusAbandons,routeClears; public RuntimeException requestFailure,abandonFailure;
 public int getMode(){return mode;} public void setMode(int n){mode=n;}
 public int requestAudioFocus(AudioFocusRequest r){focusRequests++;if(requestFailure!=null)throw requestFailure;return 1;}
 public int abandonAudioFocusRequest(AudioFocusRequest r){focusAbandons++;if(abandonFailure!=null)throw abandonFailure;return 1;}
 public void setSpeakerphoneOn(boolean b){} public void clearCommunicationDevice(){routeClears++;}
 public java.util.List<AudioDeviceInfo> getAvailableCommunicationDevices(){return java.util.Collections.emptyList();}
 public boolean setCommunicationDevice(AudioDeviceInfo d){return true;}
}
