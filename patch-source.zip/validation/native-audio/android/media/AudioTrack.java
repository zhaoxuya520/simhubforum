package android.media;
public class AudioTrack {
 public static AudioTrack last; public static RuntimeException playFailure,defaultReleaseFailure;
 public volatile int writeCalls; public int releases,pauses,flushes,stops; public RuntimeException releaseFailure;
 public static int getMinBufferSize(int rate,int mask,int format){return 2048;}
 public int getState(){return 1;} public void play(){if(playFailure!=null)throw playFailure;}
 public int write(short[] data,int offset,int count){writeCalls++;try{Thread.sleep(20);}catch(InterruptedException e){Thread.currentThread().interrupt();}return count;}
 public void pause(){pauses++;} public void flush(){flushes++;} public void stop(){stops++;}
 public void release(){releases++;if(releaseFailure!=null)throw releaseFailure;}
 public static class Builder {
  public Builder setAudioAttributes(AudioAttributes a){return this;} public Builder setAudioFormat(AudioFormat a){return this;}
  public Builder setBufferSizeInBytes(int n){return this;} public Builder setTransferMode(int n){return this;}
  public AudioTrack build(){last=new AudioTrack();last.releaseFailure=defaultReleaseFailure;return last;}
 }
}
