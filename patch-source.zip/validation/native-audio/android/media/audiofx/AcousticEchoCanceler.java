package android.media.audiofx;
public class AcousticEchoCanceler extends AudioEffect {public static AcousticEchoCanceler last;public static boolean isAvailable(){return true;} public static AcousticEchoCanceler create(int session){return last=new AcousticEchoCanceler();}}
