package android.media.audiofx;
public class AudioEffect {public int releases;public RuntimeException releaseFailure;
 public static String failEnableClass; public boolean enabled;
 public int setEnabled(boolean value){if(getClass().getSimpleName().equals(failEnableClass))throw new IllegalStateException("injected effect enable failure");enabled=value;return 0;} public boolean getEnabled(){return enabled;}
 public void release(){releases++;if(releaseFailure!=null)throw releaseFailure;}
}
