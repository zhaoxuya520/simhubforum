package android.media.audiofx;
public class AutomaticGainControl extends AudioEffect {public static AutomaticGainControl last;public static boolean isAvailable(){return true;} public static AutomaticGainControl create(int session){return last=new AutomaticGainControl();}}
