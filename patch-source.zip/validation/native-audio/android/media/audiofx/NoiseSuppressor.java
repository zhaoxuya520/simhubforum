package android.media.audiofx;
public class NoiseSuppressor extends AudioEffect {public static NoiseSuppressor last;public static boolean isAvailable(){return true;} public static NoiseSuppressor create(int session){return last=new NoiseSuppressor();}}
