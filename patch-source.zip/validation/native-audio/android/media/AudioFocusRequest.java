package android.media;
public class AudioFocusRequest {public static class Builder {
 public Builder(int n){} public Builder setAudioAttributes(AudioAttributes a){return this;}
 public Builder setOnAudioFocusChangeListener(AudioManager.OnAudioFocusChangeListener l){return this;}
 public AudioFocusRequest build(){return new AudioFocusRequest();}
}}
