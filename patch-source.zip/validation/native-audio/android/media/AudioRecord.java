package android.media;
public class AudioRecord {
 public volatile int readCalls; public int releases,stops; public RuntimeException releaseFailure;
 public AudioRecord(){}
 public static AudioRecord last; public static RuntimeException startFailure; public boolean recording;
 public AudioRecord(int source,int rate,int mask,int format,int size){last=this;}
 public static int getMinBufferSize(int rate,int mask,int format){return 2048;}
 public int getState(){return 1;} public int getAudioSessionId(){return 42;}
 public void startRecording(){if(startFailure!=null)throw startFailure;recording=true;}
 public int getRecordingState(){return recording?3:1;}
 public int read(short[] data,int offset,int count){readCalls++;try{Thread.sleep(20);}catch(InterruptedException e){Thread.currentThread().interrupt();}return count;}
 public void stop(){stops++;}
 public void release(){releases++;if(releaseFailure!=null)throw releaseFailure;}
}
