package android.media;
public class AudioDeviceInfo {public int getType(){return 2;}}
