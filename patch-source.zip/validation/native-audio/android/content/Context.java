package android.content;
public class Context {
 public final android.media.AudioManager manager;
 public Context(android.media.AudioManager manager){this.manager=manager;}
 public <T> T getSystemService(Class<T> type){return type.cast(manager);}
 public int checkPermission(String permission,int pid,int uid){return 0;}
}
