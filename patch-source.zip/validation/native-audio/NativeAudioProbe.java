import android.content.Context;
import android.media.*;
import android.media.audiofx.*;
/** Executes actual APK yz/xz/py3 bytecode; only Android hardware/system APIs are doubles. */
public final class NativeAudioProbe {
 static int checks;
 static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
 static RuntimeException run(yz audio){try{audio.d();return null;}catch(RuntimeException e){return e;}}
 static RuntimeException close(yz audio){try{audio.g();return null;}catch(RuntimeException e){return e;}}
 static yz create(AudioManager manager){return new yz(new Context(manager),16000);}
 static void startup(boolean legacy){
  AudioManager manager=new AudioManager();manager.mode=0;yz audio=create(manager);
  RuntimeException failure=new IllegalStateException("injected AudioTrack.play failure");AudioTrack.playFailure=failure;
  check(run(audio)==failure,"original playback failure propagates");
  check(AudioTrack.last!=null,"native f() built an actual fixture track");
  check(AudioTrack.last.releases==(legacy?0:1),"created track released on failed playback");
  check(audio.k==null,"player reference cleared");check(manager.mode==0,"previous mode restored after playback failure");
  check(manager.focusAbandons==1,"focus abandoned after playback failure");
  manager=new AudioManager();audio=create(manager);
  AudioTrack.defaultReleaseFailure=new IllegalStateException("injected secondary release failure");
  check(run(audio)==failure,"cleanup failure does not replace original playback error");
  check(AudioTrack.last.releases==(legacy?0:1),"failing player release attempted once");
  check(manager.mode==0&&manager.focusAbandons==1,"system state restored after combined start and cleanup failure");
  check(audio.k==null,"player reference cleared after combined failure");
  AudioTrack.defaultReleaseFailure=null;
  AudioTrack.playFailure=null;
  manager=new AudioManager();audio=create(manager);
  failure=new IllegalStateException("injected focus acquisition failure");manager.requestFailure=failure;
  check(run(audio)==failure,"original focus failure propagates");
  check(manager.mode==(legacy?3:0),"previous mode restored after focus exception");
  check(manager.focusAbandons==(legacy?0:1),"partly acquired focus abandoned after exception");
  check(audio.r==(legacy?Integer.valueOf(0):null),"mode restoration reference cleared");
  check(audio.s==null,"focus request reference cleared");check(!audio.q,"no worker run state after failed startup");
 }
 static void cleanup(boolean legacy){
  AudioManager manager=new AudioManager();manager.mode=3;yz audio=create(manager);
  audio.r=0;audio.s=new AudioFocusRequest();audio.u=5;audio.v=10;audio.q=true;
  AudioRecord record=new AudioRecord();record.releaseFailure=new IllegalStateException("injected recorder release failure");audio.j=record;
  AudioTrack track=new AudioTrack();audio.k=track;
  AcousticEchoCanceler echo=new AcousticEchoCanceler();audio.l=echo;
  NoiseSuppressor noise=new NoiseSuppressor();audio.m=noise;
  AutomaticGainControl gain=new AutomaticGainControl();audio.n=gain;
  RuntimeException error=close(audio);
  check((error!=null)==legacy,"cleanup keeps proceeding through release errors");
  check(record.releases==1,"record release attempted");check(track.releases==(legacy?0:1),"track release independent of recorder failure");
  check(echo.releases==(legacy?0:1),"echo released");check(noise.releases==(legacy?0:1),"noise released");check(gain.releases==(legacy?0:1),"gain released");
  check(manager.mode==(legacy?3:0),"mode restored despite cleanup failure");
  check(manager.focusAbandons==(legacy?0:1),"focus abandoned despite cleanup failure");
  check(!audio.q,"run state stopped");
  check((audio.j!=null)==legacy,"record reference cleared despite failure");
  if(!legacy){
   check(audio.k==null&&audio.l==null&&audio.m==null&&audio.n==null,"all media handles cleared");
   check(audio.r==null&&audio.s==null&&audio.u==0&&audio.v==0,"focus and buffered audio cleared");
   check(close(audio)==null,"repeated close succeeds");check(record.releases==1&&track.releases==1,"repeated close does not release twice");
  }
  manager=new AudioManager();manager.mode=3;manager.abandonFailure=new IllegalStateException("injected focus release failure");audio=create(manager);audio.r=0;audio.s=new AudioFocusRequest();
  error=close(audio);check((error!=null)==legacy,"focus release errors contained");
  check(manager.mode==(legacy?3:0),"previous mode restored if focus release fails");
  if(!legacy)check(audio.s==null&&audio.r==null,"focus and mode handles cleared if release fails");
  manager=new AudioManager();manager.mode=3;audio=create(manager);audio.f=true;audio.r=0;audio.s=new AudioFocusRequest();
  track=new AudioTrack();audio.k=track;check(close(audio)==null,"Telecom managed media cleanup succeeds");
  check(manager.mode==3&&manager.focusAbandons==0&&manager.routeClears==0,"Telecom owned mode/focus/route unchanged");
  check(track.releases==1,"Telecom managed local track released");
 }
 static void enableFailures(boolean legacy){
  String[] effects={"AcousticEchoCanceler","NoiseSuppressor","AutomaticGainControl"};
  for(int failed=0;failed<effects.length;failed++){
   AudioEffect.failEnableClass=effects[failed];AudioManager manager=new AudioManager();yz audio=create(manager);
   audio.e();AudioRecord record=audio.j;
   AudioEffect allocated=failed==0?AcousticEchoCanceler.last:failed==1?NoiseSuppressor.last:AutomaticGainControl.last;
   check(allocated!=null,"optional effect allocated before enable failure");
   check((failed==0?audio.l:failed==1?audio.m:audio.n)==null,"failed optional effect remains disabled");
   check(close(audio)==null,"optional effect failure does not prevent close");
   check(allocated.releases==(legacy?0:1),"failed optional effect released once");
   check(record.releases==1,"record still released after optional effect failure");
  }
  AudioEffect.failEnableClass=null;
 }
 static void normal(){
  AudioManager manager=new AudioManager();yz audio=create(manager);
  java.util.List<Throwable> threadErrors=java.util.Collections.synchronizedList(new java.util.ArrayList<Throwable>());
  Thread.UncaughtExceptionHandler previous=Thread.getDefaultUncaughtExceptionHandler();
  Thread.setDefaultUncaughtExceptionHandler((thread,error)->threadErrors.add(error));
  try {
   check(run(audio)==null,"normal native startup succeeds");
   Thread capture=audio.o,playback=audio.p;
   AudioRecord record=audio.j;AudioTrack track=audio.k;
   AcousticEchoCanceler echo=audio.l;NoiseSuppressor noise=audio.m;AutomaticGainControl gain=audio.n;
   check(audio.q&&capture!=null&&playback!=null,"both native audio workers created");
   check(record!=null&&track!=null&&echo!=null&&noise!=null&&gain!=null,"native acquisition stores all hardware handles");
   audio.b(new short[320]);
   long deadline=System.nanoTime()+1000000000L;
   while((record.readCalls==0||track.writeCalls==0)&&System.nanoTime()<deadline){
    try{Thread.sleep(5);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new AssertionError(e);}
   }
   check(record.readCalls>0,"actual capture worker reads PCM from platform API");
   check(track.writeCalls>0,"actual playback worker writes buffered PCM to platform API");
   check(close(audio)==null,"normal native stop succeeds");
   check(!capture.isAlive()&&!playback.isAlive(),"audio workers exit before cleanup returns");
   check(threadErrors.isEmpty(),"worker paths resolve actual native bytecode against complete API doubles: "+threadErrors);
   check(record.releases==1&&track.releases==1&&echo.releases==1&&noise.releases==1&&gain.releases==1,"normal native stop releases all handles");
   check(manager.mode==0&&manager.focusAbandons==1,"normal native stop restores mode and focus");
  } finally {audio.g();Thread.setDefaultUncaughtExceptionHandler(previous);}
 }
 static void isolatedReleaseFailures(){
  for(int failed=0;failed<4;failed++){
   AudioManager manager=new AudioManager();manager.mode=3;yz audio=create(manager);audio.r=0;audio.s=new AudioFocusRequest();
   AudioRecord record=new AudioRecord();audio.j=record;AudioTrack track=new AudioTrack();audio.k=track;
   AcousticEchoCanceler echo=new AcousticEchoCanceler();audio.l=echo;NoiseSuppressor noise=new NoiseSuppressor();audio.m=noise;AutomaticGainControl gain=new AutomaticGainControl();audio.n=gain;
   RuntimeException failure=new IllegalStateException("injected cleanup stage "+failed);
   if(failed==0)track.releaseFailure=failure;else if(failed==1)echo.releaseFailure=failure;else if(failed==2)noise.releaseFailure=failure;else gain.releaseFailure=failure;
   check(close(audio)==null,"cleanup stage failure contained: "+failed);
   check(record.releases==1&&track.releases==1&&echo.releases==1&&noise.releases==1&&gain.releases==1,"every cleanup attempted despite stage failure: "+failed);
   check(manager.mode==0&&manager.focusAbandons==1&&audio.k==null&&audio.l==null&&audio.m==null&&audio.n==null,"system and handles restored after stage failure: "+failed);
  }
 }
 public static void main(String[] args){boolean legacy=args.length>0&&args[0].equals("legacy");startup(legacy);cleanup(legacy);enableFailures(legacy);normal();if(!legacy)isolatedReleaseFailures();System.out.println("NATIVE_AUDIO "+(legacy?"legacy_regression_reproduced":"current_passed")+"=true checks="+checks);}
}
