# Native EAP-AKA Identity replay validation

Run after the native carrier validation:

```
python3 tests/check_native_eap_runtime.py APK DECODED --report BUILD/native-eap-runtime.json
```

The runner reuses `BUILD/native-carrier-current/auth-probe.jar`, verifies the
carrier report's APK and translated-jar hashes, and checks that the transport
adapter left `da1`, `ma1`, `la1`, `z91`, and the replay/log helpers byte-identical
to the original translated APK classes. It does not translate the APK again.
`--carrier-report` and `--native-dir` support an explicitly retained baseline;
`--legacy` requires the original unpatched native `da1` and reproduces its
transcript duplication.

The production patch gives each native `da1` its own replay entry. Only a
successfully generated subtype 5 Identity response is cached. The key includes
all bytes inside EAP Length, including Identifier, Type, attributes and their
padding, plus the recorded native transcript size. Bytes outside EAP Length are
lower-layer padding. An exact consecutive retransmission returns a copied
original response before the native transcript append. Request and response
arrays are copied independently. Any nonmatching input retires the old entry
and takes the original native path. A native transcript reset also invalidates
the entry; another session owns a separate cache.

`NativeEapReplayProbe` executes the actual native `da1.b` and serializers. It
covers EAP-AKA and AKA-prime, repeated replies, Identifier wraparound, identical
Identifiers with changed content, A/B/A ordering, caller mutation of arrays,
outer padding, transcript reset, and session isolation. Ordinary Type 1 Identity
and terminal EAP results retain their native behavior. A well-framed synthetic
Challenge with RAND/AUTN/MAC stops at the original absent-adapter boundary; this
checks dispatch/cache invalidation without a card or successful authentication.
The replay probe uses no APDU transport, socket, Android runtime, or carrier.

The actual generated Identity responses also enter the production realm-log
helper: the expected text includes only the fixed public `mnc004.mcc204` realm,
never the subscriber identity, and the packet bytes remain unchanged.

This is a bounded fix for ordinary consecutive valid retransmissions. It does
not introduce a history cache, rewrite the existing RFC 4187 pending-pair state
machine, or change malformed-packet handling. JVM verification is disabled for
the existing DEX-to-JVM R8 normalization; the final build separately verifies
shipped DEX method/register types. The final runtime report binds the probe to
the exact candidate APK hash, while Android ART validation is separate.

References: [RFC 3748 §4.1](https://www.rfc-editor.org/rfc/rfc3748.html#section-4.1)
for duplicate Request handling and
[RFC 4187 §10.13](https://www.rfc-editor.org/rfc/rfc4187.html#section-10.13)
for recording retransmitted identity pairs only once.
