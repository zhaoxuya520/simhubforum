import java.util.*;
import java.io.*;

/** Actual APK da1.b; identity exchanges never need an AKA transport or socket. */
public final class NativeEapReplayProbe {
 static int checks;
 static final String IDENTITY="0204049876543210@nai.epc.mnc004.mcc204.3gppnetwork.org";
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;}
 static byte[] request(int id,int type,int attribute){return new byte[]{1,(byte)id,0,12,(byte)type,5,0,0,(byte)attribute,1,0,0};}
 static byte[] join(byte[]...parts)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();for(byte[]part:parts)out.write(part);return out.toByteArray();}
 static byte[] reply(da1 engine,byte[] request)throws Exception{
  Object result=engine.b(request,null);check(result instanceof z91,"native identity request returns a packet");
  byte[] response=((z91)result).a;
  check(response[0]==2&&response[1]==request[1]&&response[4]==request[4]&&response[5]==5,"native response preserves identifier/type/subtype");
  check(engine.c==null&&engine.f==null,"identity response never fabricates authentication key material");
  return response;
 }
 static void transcript(da1 engine,byte[] expected,String label){check(Arrays.equals(engine.e.toByteArray(),expected),label);}
 static void replay(da1 engine,byte[] request,byte[] expected,byte[] transcript)throws Exception{
  byte[] result=reply(engine,request);check(Arrays.equals(result,expected),"replayed bytes equal original native response");
  transcript(engine,transcript,"exact duplicate does not append either request or response");
 }
 static void identityLog(byte[] response,int type)throws Exception{
  byte[] original=response.clone();String summary="EAP Response "+response.length+"B";
  String text=(String)Class.forName("cc.forserein.simhub.internal.EapIdentityLog")
      .getMethod("describe",String.class,byte[].class).invoke(null,summary,response);
  check(text.equals(summary+"（"+(type==23?"AKA":"AKA′")+" 身份域 mnc004.mcc204）"),"native-generated identity log includes only the fixed standard public realm");
  check(!text.contains(IDENTITY)&&!text.contains("204049876543210"),"identity log never exposes the subscriber identity");
  check(Arrays.equals(response,original),"identity diagnostic leaves actual response bytes unchanged");
 }
 static void current()throws Exception{
  for(int type:new int[]{23,50}){
   da1 engine=new da1(IDENTITY,null);byte[] a=request(255,type,10),originalA=a.clone();
   byte[] first=reply(engine,a),originalReply=first.clone(),one=join(originalA,originalReply);
   identityLog(first,type);
   transcript(engine,one,"first successful native identity records one request/response pair");
   for(int n=0;n<3;n++)replay(engine,originalA,originalReply,one);
   first[12]^=1;a[1]=3;
   replay(engine,originalA,originalReply,one);
   byte[] externallyMutated=reply(engine,originalA);externallyMutated[12]^=1;
   replay(engine,originalA,originalReply,one);
   byte[] outsidePadding=Arrays.copyOf(originalA,15);outsidePadding[12]=99;outsidePadding[14]=1;
   replay(engine,outsidePadding,originalReply,one);
   byte[] b=request(0,type,10),responseB=reply(engine,b);byte[] two=join(one,b,responseB);
   transcript(engine,two,"new identifier, including wraparound, records a new native pair");
   replay(engine,b,responseB,two);
   byte[] changed=request(0,type,13),changedReply=reply(engine,changed);byte[] three=join(two,changed,changedReply);
   transcript(engine,three,"same identifier with different request content is not replayed");
   replay(engine,changed,changedReply,three);
   byte[] again=reply(engine,originalA),four=join(three,originalA,again);
   transcript(engine,four,"old identifier after another request takes original native path");
   replay(engine,originalA,again,four);
   engine.e.reset();byte[] afterReset=reply(engine,originalA);byte[] resetPair=join(originalA,afterReset);
   transcript(engine,resetPair,"native transcript reset invalidates previous replay cache");
   replay(engine,originalA,afterReset,resetPair);
   da1 fresh=new da1(IDENTITY.replace("9876543210","9876543211"),null);byte[] freshReply=reply(fresh,originalA);
   check(!Arrays.equals(freshReply,originalReply),"fresh session uses its own native identity bytes");
   transcript(fresh,join(originalA,freshReply),"fresh session records independently");
   transcript(engine,resetPair,"second session cannot change first session transcript");
  }
  // A well-framed non-Identity request enters the unchanged native challenge
  // path. The null AKA adapter is an explicit stop before any physical transport.
  da1 challenge=new da1(IDENTITY,null);byte[] a=request(7,23,10),first=reply(challenge,a),one=join(a,first);
  byte[] packet=new byte[68];packet[0]=1;packet[1]=8;packet[3]=68;packet[4]=23;packet[5]=1;
  for(int i=0;i<3;i++){int offset=8+i*20;packet[offset]=(byte)(i==0?1:i==1?2:11);packet[offset+1]=5;}
  boolean adapterReached=false;
  try{challenge.b(packet,null);}catch(NullPointerException expected){adapterReached=true;}
  check(adapterReached,"new challenge reaches the original absent-AKA-adapter boundary");
  transcript(challenge,one,"challenge does not duplicate the prior identity transcript");
  byte[] afterChallenge=reply(challenge,a);
  transcript(challenge,join(one,a,afterChallenge),"new challenge invalidates previous identity replay");
  // Basic Identity is still handled by the original native Type 1 branch.
  da1 basic=new da1(IDENTITY,null);first=reply(basic,a);one=join(a,first);
  Object plain=basic.b(new byte[]{1,9,0,5,1},null);check(plain instanceof z91&&((z91)plain).a[4]==1,"ordinary EAP Identity response remains native");
  transcript(basic,one,"basic Identity does not alter AKA checkcode transcript");
  byte[] afterBasic=reply(basic,a);transcript(basic,join(one,a,afterBasic),"another EAP request invalidates old identity reply");
  // Terminal EAP packets retain the native result and retire this replay entry.
  for(byte code:new byte[]{3,4}){
   da1 ended=new da1(IDENTITY,null);first=reply(ended,a);one=join(a,first);
   Object result=ended.b(new byte[]{code,7,0,4},null);
   check(result==y91.a,"terminal packet without key material retains native unsuccessful result");
   transcript(ended,one,"terminal result does not rewrite native transcript");
   byte[] afterEnd=reply(ended,a);transcript(ended,join(one,a,afterEnd),"terminal packet retires old identity reply cache");
  }
 }
 public static void main(String[] args)throws Exception{
  if(args.length>0&&args[0].equals("legacy")){
   da1 engine=new da1(IDENTITY,null);byte[] a=request(7,23,10),first=reply(engine,a);byte[] one=join(a,first);
   transcript(engine,one,"old first pair");byte[] again=reply(engine,a);
   check(Arrays.equals(first,again),"old native duplicate sends same bytes");
   transcript(engine,join(one,a,again),"old native duplicates the transcript pair");
   System.out.println("NATIVE_EAP_REPLAY legacy_regression_reproduced=true checks="+checks);return;
  }
  current();System.out.println("NATIVE_EAP_REPLAY current_passed=true checks="+checks+" no_apdu=true no_socket=true");
 }
}
