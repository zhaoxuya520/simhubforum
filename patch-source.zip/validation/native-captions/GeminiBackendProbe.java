package cc.forserein.simhub.internal;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** Sends only synthetic PCM to a loopback HTTP server. No public provider or SIM is contacted. */
public final class GeminiBackendProbe {
    private static final String KEY = "local.fixture.key";
    private static int checks;
    private static void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
        checks++;
    }
    private static String reply(String caption) throws Exception {
        JSONArray parts = new JSONArray().put(new JSONObject().put("thought", true).put("text", "hidden"))
                .put(new JSONObject().put("text", new JSONObject().put("caption", caption).toString()));
        return new JSONObject().put("candidates", new JSONArray().put(new JSONObject().put("finishReason","STOP")
                .put("content",new JSONObject().put("parts",parts)))).toString();
    }
    private static class Events implements CaptionBackend.Listener {
        final CountDownLatch ready = new CountDownLatch(1);
        final BlockingQueue<String> text = new LinkedBlockingQueue<>(), errors = new LinkedBlockingQueue<>();
        public void onReady() { ready.countDown(); }
        public void onText(String value) { text.add(value); }
        public void onError(String value) { errors.add(value); }
    }
    private static class Response {
        final int code;
        final String body;
        final boolean wait;
        Response(int code, String body, boolean wait) { this.code=code;this.body=body;this.wait=wait; }
    }
    private static class Server implements AutoCloseable {
        final BlockingQueue<Response> scripted = new LinkedBlockingQueue<>();
        final BlockingQueue<String> bodies = new LinkedBlockingQueue<>();
        final BlockingQueue<String> credentials = new LinkedBlockingQueue<>();
        final CountDownLatch hold = new CountDownLatch(1);
        final AtomicInteger redirects = new AtomicInteger();
        final HttpServer server;
        final URL url;
        Server() throws Exception {
            server=HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(),0),0);
            url=new URL("http",server.getAddress().getAddress().getHostAddress(),server.getAddress().getPort(),"/model:generateContent");
            server.createContext("/model:generateContent",this::receive);
            server.createContext("/redirect",x -> {redirects.incrementAndGet();x.sendResponseHeaders(200,-1);x.close();});
            server.start();
        }
        void receive(HttpExchange e) throws IOException {
            try {
                bodies.add(new String(e.getRequestBody().readAllBytes(),StandardCharsets.UTF_8));
                credentials.add(e.getRequestMethod()+" "+e.getRequestURI()+" "+e.getRequestHeaders().getFirst("x-goog-api-key")
                        +" "+e.getRequestHeaders().getFirst("Content-Type"));
                Response response=scripted.poll(4,TimeUnit.SECONDS);
                if(response==null) throw new AssertionError("unexpected request");
                if(response.wait)hold.await(5,TimeUnit.SECONDS);
                if(response.code==302)e.getResponseHeaders().set("Location","/redirect");
                byte[] bytes=response.body.getBytes(StandardCharsets.UTF_8);
                e.sendResponseHeaders(response.code,bytes.length);
                try{e.getResponseBody().write(bytes);}catch(IOException clientCancelled){}
            } catch(InterruptedException exc) {Thread.currentThread().interrupt();}
            finally{e.close();}
        }
        CaptionBackend client(Events events, int rate, String target) {
            return new CaptionBackend(KEY,target,rate,events,() -> (HttpURLConnection)url.openConnection());
        }
        public void close(){hold.countDown();server.stop(0);}
        String body() throws Exception {
            String value=bodies.poll(5,TimeUnit.SECONDS);
            check(value!=null,"request arrived"); return value;
        }
    }
    private static short[] frame(int rate, boolean speech) {
        short[] pcm = new short[rate/50];
        if(speech)for(int i=0;i<pcm.length;i++)pcm[i] = (short)(i%2==0?1800:-1800);
        return pcm;
    }
    private static void speak(CaptionBackend backend,int rate) {
        short[] speech=frame(rate,true);
        for(int i=0;i<8;i++)backend.offer(speech,0,speech.length);
        Arrays.fill(speech,(short)0);
        for(int i=0;i<23;i++)backend.offer(null,0,0);
    }
    private static void inspect(String body, String previous, int rate) throws Exception {
        JSONObject req=new JSONObject(body);
        check(!body.contains(KEY),"no key in body");
        String system=req.getJSONObject("systemInstruction").getJSONArray("parts").getJSONObject(0).getString("text");
        check(system.contains("zh-Hant") && system.contains("Automatically identify") && system.contains("do not answer"),"trusted instruction");
        JSONArray parts=req.getJSONArray("contents").getJSONObject(0).getJSONArray("parts");
        check(parts.length()==(previous==null?1:2),"bounded single preceding caption");
        if(previous!=null) {
            check(parts.getJSONObject(0).getString("text").equals("Previous subtitle: "+previous),"previous caption in separate content");
            check(!system.contains(previous),"no untrusted context in instruction");
        }
        JSONObject inline=parts.getJSONObject(parts.length()-1).getJSONObject("inlineData");
        check(inline.getString("mimeType").equals("audio/wav"),"inline WAV");
        byte[] data=Base64.getDecoder().decode(inline.getString("data"));
        ByteBuffer header=ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        check(new String(data,0,4,StandardCharsets.US_ASCII).equals("RIFF") && header.getInt(4)==data.length-8,"RIFF length");
        check(header.getShort(20)==1 && header.getShort(22)==1 && header.getShort(34)==16,"mono linear 16-bit");
        check(header.getInt(24)==rate && header.getInt(28)==rate*2 && header.getInt(40)==data.length-44,"rate and data length");
        boolean copied=false;
        for(int i=44;i<data.length;i+=2)if(header.getShort(i)==1800)copied=true;
        check(copied,"reusable decoder buffer copied before mutation");
        JSONObject generation=req.getJSONObject("generationConfig");
        check(generation.getJSONObject("responseSchema").getJSONArray("required").getString(0).equals("caption"),"typed JSON response");
        check(!generation.has("temperature") && !generation.has("topP") && !generation.has("topK"),
                "current model receives no deprecated sampling controls");
    }
    private static void gate(int rate) {
        CaptionBackend.PhraseDetector gate=new CaptionBackend.PhraseDetector(rate);
        short[] quiet=frame(rate,false), voice=frame(rate,true);
        short[] latest=null; int emitted=0,total=0;
        for(int i=0;i<250;i++) if(gate.feed(quiet)!=null)emitted++;
        check(emitted==0 && !gate.hasSpeech(),"silence not uploaded");
        for(int i=0;i<2;i++) gate.feed(voice);
        for(int i=0;i<30;i++)if(gate.feed(quiet)!=null)emitted++;
        check(emitted==0,"isolated click suppressed");
        for(int i=0;i<170;i++) gate.feed(voice);
        for(int i=0;i<10;i++){short[] p=gate.feed(quiet);if(p!=null)latest=p;}
        check(latest!=null && !gate.hasSpeech(), "natural short pause for longer phrase");
        for(int i=0;i<650;i++) {
            short[] p=gate.feed(voice);
            if(p!=null){check(p.length<=rate*5,"hard bounded continuous segment");emitted++;total+=p.length;}
        }
        for(int i=0;i<30;i++) {short[] p=gate.feed(quiet);if(p!=null){emitted++;total+=p.length;}}
        check(emitted==3 && total>=650*voice.length,"continuous speech cut without discarding frames");
    }
    public static void main(String[] args)throws Exception {
        check(CaptionBackend.ENDPOINT.equals("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent"),"fixed official TLS endpoint");
        gate(8000);gate(16000);
        String first="這是第一句", second="第二句的譯文";
        check(CaptionBackend.caption(reply("")).isEmpty(),"silent model output suppressed");
        check(CaptionBackend.caption("{\"promptFeedback\":{\"blockReason\":\"SAFETY\"}}").isEmpty(),"safety feedback suppressed");
        check(CaptionBackend.caption("{\"candidates\":[{\"finishReason\":\"MAX_TOKENS\"}]}").isEmpty(),"truncated result suppressed");
        for(int rate:new int[]{8000,16000}) {
            Events e=new Events();
            try(Server server=new Server();CaptionBackend backend=server.client(e,rate,"zh-Hant")) {
                server.scripted.add(new Response(200,reply(first),false));
                server.scripted.add(new Response(200,reply(second),false));
                backend.start();check(e.ready.await(2,TimeUnit.SECONDS),"ready local");
                for(int i=0;i<25;i++)backend.offer(null,0,0);
                Thread.sleep(120);check(server.bodies.isEmpty(),"no silent request");
                speak(backend,rate);inspect(server.body(),null,rate);
                check(server.credentials.take().equals("POST /model:generateContent "+KEY+" application/json; charset=UTF-8"),"header auth + fixed POST path");
                check(first.equals(e.text.poll(3,TimeUnit.SECONDS)),"first subtitle");
                speak(backend,rate);inspect(server.body(),first,rate);
                check(second.equals(e.text.poll(3,TimeUnit.SECONDS)) && e.errors.isEmpty(),"ordered translated subtitle");
            }
        }
        Events retry=new Events();
        try(Server server=new Server();CaptionBackend backend=server.client(retry,8000,"de")) {
            server.scripted.add(new Response(503,"",false));server.scripted.add(new Response(200,reply("Gut"),false));
            backend.start();speak(backend,8000);
            String a=server.body(),b=server.body();
            check(a.equals(b) && a.contains("German (de)") && !a.contains("zh-Hant"),"one 503 retry with selected language");
            check("Gut".equals(retry.text.poll(2,TimeUnit.SECONDS)) && retry.errors.isEmpty(),"retry result");
        }
        for(int code:new int[]{302,401,429,503}){
            Events e=new Events();
            try(Server server=new Server();CaptionBackend backend=server.client(e,16000,"fr")){
                server.scripted.add(new Response(code,"private provider text",false));
                if(code==503)server.scripted.add(new Response(code,"private provider text",false));
                backend.start();speak(backend,16000);server.body();
                String error=e.errors.poll(4,TimeUnit.SECONDS);
                check(error!=null && !error.contains(KEY) && !error.contains("private"),"safe mapped error");
                if(code==503)server.body();
                speak(backend,16000);Thread.sleep(120);
                check(server.redirects.get()==0 && server.bodies.isEmpty() && e.text.isEmpty(),"no extra requests after error");
            }
        }
        Events cancel=new Events();
        try(Server server=new Server();CaptionBackend backend=server.client(cancel,16000,"en")){
            server.scripted.add(new Response(200,reply("late"),true));backend.start();
            speak(backend,16000);server.body();speak(backend,16000);
            long before=System.nanoTime();backend.close();check(System.nanoTime()-before<TimeUnit.MILLISECONDS.toNanos(250),"close independent from network");
            server.hold.countDown();speak(backend,16000);Thread.sleep(150);
            check(cancel.text.isEmpty() && cancel.errors.isEmpty() && server.bodies.isEmpty(),"in-flight response and queued speech discarded");
        }
        System.out.println("PASS "+checks+" caption backend assertions; synthetic PCM and loopback provider only");
    }
}
