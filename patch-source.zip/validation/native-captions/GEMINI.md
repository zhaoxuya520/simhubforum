# 通话字幕的 Gemini 连接与验证

默认关闭通话翻译。在 Google AI Studio 创建自己的 Gemini API 密钥，确认该项目有权调用 Gemini Developer API 的 Gemini 3.5 Flash-Lite，然后在应用的通话翻译设置中保存。开启后，应用把对方的通话音频按短句发送到 Google 进行翻译。费用、额度及音频处理政策由该 Google 项目决定。使用者可随时关闭或删除密钥。[创建或管理密钥](https://aistudio.google.com/apikey) · [官方 API 密钥说明](https://ai.google.dev/gemini-api/docs/api-key)

后端使用固定的 Google HTTPS 主机，调用 generateContent。音频作为单声道 WAV 内联发送。系统指令告知模型自动识别说话语言、按目标语言生成自然字幕、保留语气和关键信息。当上下句连续时请求附带上一句译文末尾最多 180 个字符。关闭或切换通话、语言后会丢弃旧请求和缓存。稳定版模型支持音频输入和结构化 JSON 输出。服务未公开保证每种语言、方言或音质的翻译准确率。[模型说明](https://ai.google.dev/gemini-api/docs/models/gemini-3.5-flash-lite) · [音频输入](https://ai.google.dev/gemini-api/docs/audio) · [接口格式](https://ai.google.dev/api/generate-content)

开发者可用以下命令检查 APK 中的实际字幕后端。该验证使用人工 PCM 和本机 HTTP 服务，无需 Gemini 凭据。它核对请求格式、目标语言、翻译结果投递、重试和取消。测试专用的 Android JSON JAR 来自 Maven Central，脚本校验固定摘要。
 
```sh
curl -fsSL https://repo.maven.apache.org/maven2/com/vaadin/external/google/android-json/0.0.20131108.vaadin1/android-json-0.0.20131108.vaadin1.jar -o /tmp/caption-android-json.jar
python3 validation/native-captions/check_backend.py --apk "$SIGNED_APK" --unsigned-apk "$UNSIGNED_APK" --carrier-report build-config3/native-carrier-runtime.json --json-jar /tmp/caption-android-json.jar --report /tmp/signed-caption-backend.json
```
