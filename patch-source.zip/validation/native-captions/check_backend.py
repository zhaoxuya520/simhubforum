#!/usr/bin/env python3
"""Execute the shipped caption backend on synthetic downlink audio against a loopback HTTP provider."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
from zipfile import ZipFile

here = Path(__file__).resolve().parent
project = here.parents[1]
kit = Path(os.environ.get("SIMHUB_TOOLS", "/workspace/tools/android-recovery"))
cli = argparse.ArgumentParser(description=__doc__)
cli.add_argument("--apk", type=Path)
cli.add_argument("--unsigned-apk", type=Path)
cli.add_argument("--carrier-report", type=Path)
cli.add_argument("--json-jar", type=Path, required=True)
cli.add_argument("--report", type=Path, required=True)
args = cli.parse_args()
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
assert digest(args.json_jar) == "dfb7bae2f404cfe0b72b4d23944698cb716b7665171812a0a4d0f5926c0fac79"
sources = [here / "GeminiBackendProbe.java"]
classpath = [args.json_jar]
evidence = {}
if args.apk:
    if not args.carrier_report:
        cli.error("The APK fixture requires its carrier translation manifest")
    info = json.loads(args.carrier_report.read_text())
    jar = args.carrier_report.parent / "native-carrier-current" / "probe.jar"
    assert info["apk_translated_jar_sha256"] == digest(jar)
    unsigned = args.unsigned_apk or args.apk
    assert info["apk_sha256"] == digest(unsigned)
    with ZipFile(unsigned) as before, ZipFile(args.apk) as after:
        dex_files = sorted(name for name in before.namelist() if re.fullmatch(r'classes(?:\d+)?\.dex', name))
        assert set(dex_files) == {name for name in after.namelist() if re.fullmatch(r'classes(?:\d+)?\.dex', name)}
        assert dex_files and all(before.read(name) == after.read(name) for name in dex_files)
        evidence["dex_sha256"] = {name: sha256(after.read(name)).hexdigest() for name in dex_files}
    classpath.append(jar)
    evidence.update(apk_sha256=digest(args.apk), translated_jar_sha256=digest(jar), actual_apk_classes=True)
else:
    sources.append(project / "src/cc/forserein/simhub/internal/CaptionBackend.java")
    evidence.update(actual_apk_classes=False)

args.report.parent.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(dir=args.report.parent) as temporary:
    cp = os.pathsep.join(map(str, classpath))
    subprocess.run(["java", "-jar", kit / "ecj-3.40.0.jar", "-17", "-proc:none", "-warn:none",
                    "-encoding", "UTF-8", "-cp", cp, "-d", temporary, *sources], check=True)
    out = subprocess.check_output(["java","-noverify", "-cp", temporary + os.pathsep + cp,
                "cc.forserein.simhub.internal.GeminiBackendProbe"], text=True, timeout=50)
evidence.update(checks=int(re.search(r"PASS (\d+) caption backend assertions",out)[1]), passed=True,
                endpoint="https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent",
                media="synthetic signed PCM, 8 kHz and 16 kHz", transport="loopback HTTP, class-internal connection fixture",
                tested=["no request on silence","copy before decoder buffer reuse","valid mono PCM WAV payload", "target locale and tone instructions",
                        "one bounded preceding subtitle separated from the instruction", "ordered output and silence filtering",
                        "HTTP key is not in URL or body", "redirects refused", "bounded 503 retry", "prompt feedback, quota and auth errors",
                        "cancel a real in-flight HTTP read without waiting, discard queued audio and late output"],
                live_provider_tested=False, physical_call_tested=False, cloud_audio_sent=False,
                json_test_library_sha256=digest(args.json_jar), fixture_sha256=digest(sources[0]))
args.report.write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+"\n")
print(out.strip())
