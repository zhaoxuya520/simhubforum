#!/usr/bin/env python3
"""Prepare a two-class prebuild test overlay. Does not build, install or sign an APK."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys, zipfile

project = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(project))
from international_dialing_patch import apply_international_dialing
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--jar', type=Path, required=True)
parser.add_argument('--smali', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
kit = Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery'))
dexkit = Path(os.environ.get('SIMHUB_DEX2JAR_TOOLS', '/workspace/tools/dex2jar-v2.4'))/'dex-tools-v2.4/lib'
w=args.out;w.mkdir(parents=True,exist_ok=True);(w/'smali').mkdir(exist_ok=True);(w/'classes').mkdir(exist_ok=True)
def run(*command): subprocess.run(list(map(str,command)),check=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source=project/'src/cc/forserein/simhub/internal/DialingSupport.java'
(w/'smali/f82.smali').write_bytes((args.smali/'f82.smali').read_bytes())
apply_international_dialing(w/'smali')
run('java','-jar',kit/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-d',w/'classes',source)
run('java','-cp',str(dexkit/'*'),'com.googlecode.d2j.smali.SmaliCmd','-o',w/'f82.dex',w/'smali/f82.smali')
run('java','-cp',str(dexkit/'*'),'com.googlecode.dex2jar.tools.Dex2jarCmd','-f','-o',w/'f82.jar',w/'f82.dex')
with zipfile.ZipFile(w/'f82.jar') as z:f82=z.read('f82.class')
helper=(w/'classes/cc/forserein/simhub/internal/DialingSupport.class').read_bytes()
with zipfile.ZipFile(args.jar) as src,zipfile.ZipFile(w/'candidate-overlay.jar','w') as dst:
    for name in src.namelist():
        dst.writestr(name,f82 if name=='f82.class' else helper if name=='cc/forserein/simhub/internal/DialingSupport.class' else src.read(name))
report={'base_jar_sha256':sha(args.jar),'base_f82_smali_sha256':sha(args.smali/'f82.smali'),
        'helper_source_sha256':sha(source),'patch_sha256':sha(project/'international_dialing_patch.py'),
        'assembled_f82_dex_sha256':sha(w/'f82.dex'),'overlay_jar_sha256':sha(w/'candidate-overlay.jar'),
        'scope':'Prebuild candidate only. Assembled new f82 hook plus Java helper; all remaining native classes retained. Not a signed APK or ART test.'}
(w/'overlay-provenance.json').write_text(json.dumps(report,indent=2)+'\n')
print(w/'candidate-overlay.jar')
