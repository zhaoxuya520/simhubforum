# Explicit optional trunk notation in voice calls

The old signed 24.5 app turns `+49 (0)30 23125 000` into
`tel:+4903023125000`, through either raw `f82.q` or common UI `u10.c` then
`f82.q`. The corrected target is `tel:+493023125000`. The same explicit
notation is recognized for +44 and the existing 0049/0044 access prefixes.

`DialingSupport.callInput` converts Unicode digits/fullwidth plus as before,
then deletes only the bracketed zero immediately following these two country
codes. Whitespace, hyphens and fullwidth brackets are recognized. Other
formatting remains for the existing native parser. A nonzero all-digit national
part of a plausible length must follow: DE 4–15 digits, GB 7–10. These bounds
are a conservative parsing guard, not proof of number allocation or complete
number-plan validation. Extension syntax, repeated markers, an additional
leading zero and incomplete numbers do not trigger this rewrite.

No country inference is performed. In particular Italy's significant zero,
other country codes, bare `+490...`, domestic numbers and emergency codes stay
under the previous rules. Existing incorrectly imported contacts/history which
already lost their parentheses are deliberately not guessed back into shape.

## Real entry points and SMS separation

- `u10.c -> DialingSupport.normalize` now applies `callInput` before punctuation
  is lost. This covers dialpad `f2.G`, fallback `d3.q`, call-contact import
  `yk.y -> wr0.b`, system call picker `b00.i`, and contact-page picker
  `ye3.i(T=7)` created by `py3.d`. The reader's `bf0 -> zf0 -> px3` callback
  forwards this contact result into the same call launcher.
- `f82.q` changes only its existing outgoing-string call from `ascii` to
  `callInput`. Both this overlay and the preceding CTExcel overlay must reverse
  exactly to the pinned original coroutine. Call IDs, answer/hangup/decline,
  emergency checks, permissions and destination policy instructions are intact.
- `ascii` keeps its old contract. `smsDestination` explicitly retains the old
  ASCII/digits filter, including the old interpretation of `(0)`. SMSC uses
  this same unchanged-semantics path.
- SMS's actual contact picker is separate: `pk5` constructs
  `mu4(Context, recipientState, fp1, 5)` and `mc0`'s
  `vowifi_sms_pick_contact` button invokes that launcher. `mu4.i` reads `data1`
  and performs its original digits/leading-plus filter without `u10.c`.
  `mc0`, `pk5`, `mu4`, `ub4` and all common call/contact entry classes are pinned
  unchanged by the static integration check. This does not claim unrelated
  contact display/name matching behavior was exercised on a physical phone.

## Build integration

Apply `apply_international_dialing(smali)` from
`international_dialing_patch.py` **after** the existing CTExcel overlay and
its original verification. The new integration check reverses both overlays
and checks complete native classes:

```sh
python3 tests/check_international_dialing_integration.py decoded --report integration.json
python3 validation/native-international-dialing/check_runtime.py candidate.apk \
  --carrier-report native-carrier-runtime.json --report native-international-dialing-runtime.json
```

The runtime check reuses the hash-verified translated APK JAR from the existing
carrier report. It runs actual `u10.c`, `f82.q`, `o82.s/C`, native SIP builders,
183/PRACK handling and native Gm ESP. Final TCP/tunnel writes are collected;
Android logging/event and model/environment fixtures are synthetic. No calls,
SMS, APDUs, microphone or carrier network are used. JVM verification is disabled
only for the existing DEX-to-JVM translation; this is not an ART/device test.

`--legacy` reproduces the previous behavior. For prebuild development only,
`prepare_overlay.py` builds an assembled `f82` plus the new Java helper onto
the old JAR; supply its output with `--candidate-overlay`. Such a report is
explicitly marked `signed_apk_runtime=false` and cannot replace final APK tests.

## Reference

The small allowlist is independently corroborated by libphonenumber v9.0.18
metadata: DE country code 49 and GB code 44 have national prefix 0; IT code 39
does not, and its general number pattern includes significant leading zeros.
`reference.json` records the public source URL/hash and selected attributes.
No third-party parsing implementation or full numbering database is bundled.
