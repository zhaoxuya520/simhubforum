# Explicit optional trunk notation in voice calls

The signed 24.9 app sends `+32 (0)2 555 01 23` as `tel:+32025550123`.
Both the raw call entry and the dialpad/contact path discard the parentheses
and retain the domestic prefix. With the correction, both paths generate
`tel:+3225550123`. Belgian mobile numbers such as `0032 (0)470 12 34 56`
produce `tel:+32470123456`.

The destination's explicit international code and bracketed zero select a
numbering plan. For 96 calling codes, every sharing territory uses the
domestic prefix 0 and has no prefix transformation rule. The remaining
digits must match a general national-number pattern, fit E.164, and become
invalid when the zero is reinserted. A possible significant leading zero
therefore survives. Formatting includes spaces, hyphens, Unicode digits
and fullwidth parentheses. Existing DE and GB rules retain their original
length bounds. Domestic and short codes, service/extension syntax and
already canonical numbers pass through to the original voice parser.

The supplied reference APK (23.52(1), SHA-256
`27b14b7bd73787380b955456bbc09d4fc3a9410363be1e2e1f8ac9f742e67615`)
also skips parentheses in its native call builder (`r92`) before constructing
an international destination URI. Its loop preserves the digit inside
`(0)`. This project applies the numbering-plan check before that information
is lost.

## Real entry points and SMS separation

- `u10.c -> DialingSupport.normalize` now applies `callInput` before punctuation
  is lost. This covers dialpad `f2.G`, fallback `d3.q`, call-contact import
  `yk.y -> wr0.b`, system call picker `b00.i`, and contact-page picker
  `ye3.i(T=7)` created by `py3.d`. The reader's `bf0 -> zf0 -> px3` callback
  forwards this contact result into the same call launcher.
- `f82.q` changes only its existing outgoing-string call from `ascii` to
  `callInput`. Both this overlay and the preceding CTExcel overlay must reverse
  exactly to the pinned original coroutine. Call IDs, answer/hangup/decline,
  emergency checks, permissions and destination policy instructions are intact.
- `ascii` keeps its old contract. `smsDestination` explicitly retains the old
  ASCII/digits filter, including the old interpretation of `(0)`. SMSC uses
  this same unchanged-semantics path.
- SMS's actual contact picker is separate: `pk5` constructs
  `mu4(Context, recipientState, fp1, 5)` and `mc0`'s
  `vowifi_sms_pick_contact` button invokes that launcher. `mu4.i` reads `data1`
  and performs its original digits/leading-plus filter without `u10.c`.
  `mc0`, `pk5`, `mu4`, `ub4` and all common call/contact entry classes are pinned
  unchanged by the static integration check. This does not claim unrelated
  contact display/name matching behavior was exercised on a physical phone.

## Build integration

Apply `apply_international_dialing(smali)` from
`international_dialing_patch.py` **after** the existing CTExcel overlay and
its original verification. The new integration check reverses both overlays
and checks complete native classes:

```sh
python3 tests/check_international_dialing_integration.py decoded --report integration.json
python3 validation/native-international-dialing/check_runtime.py candidate.apk \
  --carrier-report native-carrier-runtime.json --report native-international-dialing-runtime.json
```

The runtime check reuses the hash-verified translated APK JAR from the existing
carrier report. It runs actual `u10.c`, `f82.q`, `o82.s/C`, native SIP builders,
183/PRACK handling and native Gm ESP. Final TCP/tunnel writes are collected;
Android logging/event and model/environment fixtures are synthetic. No calls,
SMS, APDUs, microphone or carrier network are used. JVM verification is disabled
only for the existing DEX-to-JVM translation; this is not an ART/device test.

`--legacy` reproduces the original 24.5 behavior. `--before-expansion` exercises the 24.9 DE/GB-only baseline. For prebuild development only,
`prepare_overlay.py` builds an assembled `f82` plus the new Java helper onto
the old JAR; supply its output with `--candidate-overlay`. Such a report is
explicitly marked `signed_apk_runtime=false` and cannot replace final APK tests.

## Reference

The generated Java patterns come from Google libphonenumber v9.0.18.
The source URL and SHA-256 are in `reference.json`. The table generator
uses every territory sharing each international calling code. Its input is
the full upstream `PhoneNumberMetadata.xml` at the pinned hash.

```sh
python3 validation/native-international-dialing/numbering_plans.py PhoneNumberMetadata.xml
```

Pass `--write` to regenerate the checked-in Java table. The metadata is
Copyright (C) 2009 The Libphonenumber Authors and distributed under the
Apache License 2.0. [License](LICENSE-libphonenumber.txt)
