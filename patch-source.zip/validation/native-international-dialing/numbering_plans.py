"""Regenerate or check the optional international trunk rules using pinned public metadata."""
import argparse
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
import re
from xml.etree import ElementTree

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1] / 'src/cc/forserein/simhub/internal/DialingSupport.java'
BEGIN = '    // BEGIN GENERATED NUMBERING PLANS\n'
END = '    // END GENERATED NUMBERING PLANS\n'


def plans(metadata):
    by_code = defaultdict(list)
    for territory in ElementTree.fromstring(metadata).iter('territory'):
        by_code[int(territory.get('countryCode'))].append(territory)
    for code, territories in sorted(by_code.items()):
        if code in (44, 49):  # existing compatibility paths
            continue
        if not all(t.get('nationalPrefix') == '0' and not t.get('nationalPrefixTransformRule')
                   for t in territories):
            continue
        patterns = {re.sub(r'\s+', '', t.findtext('generalDesc/nationalNumberPattern')) for t in territories}
        yield code, '|'.join(sorted(patterns)), ', '.join(t.get('id') for t in territories)


def render(metadata):
    lines = [
        '    // Derived from Google libphonenumber v9.0.18 (Apache License 2.0).',
        '    // Copyright (C) 2009 The Libphonenumber Authors.',
        '    // See validation/native-international-dialing/numbering_plans.py.',
        '    private static String nationalPattern(int code) {',
        '        switch (code) {',
    ]
    for code, pattern, regions in plans(metadata):
        lines.append(f'            case {code}: // {regions}')
        lines.append(f'                return {json.dumps(pattern)};')
    lines.extend(['            default: return null;', '        }', '    }'])
    return '\n'.join(lines) + '\n'


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('metadata', type=Path)
    parser.add_argument('--write', action='store_true', help='Update the checked-in Java table')
    args = parser.parse_args()
    metadata = args.metadata.read_bytes()
    if sha256(metadata).hexdigest() != json.loads((HERE / 'reference.json').read_text())['sha256']:
        parser.error('Unexpected PhoneNumberMetadata.xml digest')
    source = SOURCE.read_text()
    before, body = source.split(BEGIN)
    _, after = body.split(END)
    result = before + BEGIN + render(metadata) + END + after
    if args.write:
        SOURCE.write_text(result)
    elif result != source:
        parser.error('The checked-in rules differ from the pinned metadata')
    print(f'{len(list(plans(metadata)))} generated calling-code rules, plus GB and DE')
