import java.util.*;
import java.nio.file.Paths;

/** Installed/native UI normalizer and outgoing INVITE builder, collected at the transport boundary. */
public final class OptionalTrunkProbe {
  static boolean previous, beforeExpansion;
  static int checks, entries;
  static void check(boolean ok,String label) { if(!ok)throw new AssertionError(label);checks++; }
  static void one(String raw,String before,String after) throws Exception {
    String global = before.startsWith("00") ? "+" + before.substring(2) : before;
    boolean priorPlan = global.startsWith("+44") || global.startsWith("+49");
    String expected = previous || (beforeExpansion && !priorPlan) ? before : after;
    String ui=(String)Class.forName("u10").getMethod("c",String.class).invoke(null,raw);
    check(expected.equals(ui),"actual common UI/contact normalizer: "+raw+" -> "+ui);
    String sms=(String)Class.forName("cc.forserein.simhub.internal.DialingSupport")
        .getMethod("smsDestination",String.class).invoke(null,raw);
    check((before.startsWith("00")?"+"+before.substring(2):before).equals(sms),"prior SMS recipient/SMSC semantics preserved");
    String target="tel:"+(expected.startsWith("00")?"+"+expected.substring(2):expected);
    for(String input:new String[]{raw,ui}) {
      CtExcelOriginationProbe.verify("optional-trunk-"+(entries++),"23433",
          Arrays.asList(CtExcelOriginationProbe.TEL,CtExcelOriginationProbe.SIP),input,target,
          CtExcelOriginationProbe.SIP,true,false);
      Object message=PreconditionProbe.parse(PreconditionProbe.wires.get(0));
      check(target.equals(PreconditionProbe.get(message,"c")),"raw and normalized paths agree on native Request-URI");
    }
  }
  public static void main(String[] args) throws Exception {
    previous="previous".equals(args[0]);
    beforeExpansion="before-expansion".equals(args[0]);
    SipForkProbe.msg=Class.forName("kb4");SipForkProbe.dialog=Class.forName("ma4");
    SipForkProbe.manager=Class.forName("cb4");SipForkProbe.direction=Class.forName("ga4");
    SipForkProbe.state=Class.forName("la4");SipForkProbe.helper=Class.forName("cc.forserein.simhub.internal.SipForkProtection");
    android.content.res.AssetManager.root=Paths.get(args[1]);
    Class.forName("fj5").getField("d").set(null,new android.content.Context());
    for(String[] row:new String[][] {
      {"+32 (0)2 555 01 23","+32025550123","+3225550123"},
      {"0032 (0)470 12 34 56","00320470123456","0032470123456"},
      {"＋３２（０）４７０１２３４５６","+320470123456","+32470123456"},
      {"+32 2 555 01 23","+3225550123","+3225550123"},
      {"+32025550123","+32025550123","+32025550123"},
      {"+32 (0)2 5550 1234","+320255501234","+320255501234"},
      {"+49 (0)30 23125 000","+4903023125000","+493023125000"},
      {"0049 (0)30 23125 000","004903023125000","00493023125000"},
      {"+44 (0)1632 960123","+4401632960123","+441632960123"},
      {"0044 (0)1632 960123","004401632960123","00441632960123"},
      {"＋４９（０）３０ ２３１２５ ０００","+4903023125000","+493023125000"},
      {"００４４（０）１６３２ ９６０１２３","004401632960123","00441632960123"},
      {" + 4 9\u00a0( 0 ) 30-23125-000 ","+4903023125000","+493023125000"},
      {"00 49 - (0) - 30 23125 000","004903023125000","00493023125000"},
      {"+49 30 23125 000","+493023125000","+493023125000"},
      {"+44 1632 960123","+441632960123","+441632960123"},
      {"0049 30 23125 000","00493023125000","00493023125000"},
      {"0044 1632 960123","00441632960123","00441632960123"},
      {"+49 (30) 23125 000","+493023125000","+493023125000"},
      {"+39 (0)6 123456","+3906123456","+3906123456"},
      {"0039 06 123456","003906123456","003906123456"},
      {"+33 (0)1 99000123","+330199000123","+33199000123"},
      {"+86 (0)10 0000 0123","+8601000000123","+861000000123"},
      {"00353 (0)1 234 5678","00353012345678","0035312345678"},
      {"+63 (0)917 123 4567","+6309171234567","+639171234567"},
      {"+225 (0)7 12 34 56 78","+2250712345678","+2250712345678"},
      {"+4903023125000","+4903023125000","+4903023125000"},
      {"004903023125000","004903023125000","004903023125000"},
      {"+4401632960123","+4401632960123","+4401632960123"},
      {"+49 (0)03023125000","+49003023125000","+49003023125000"},
      {"+49 (00)3023125000","+49003023125000","+49003023125000"},
      {"+49 ((0))3023125000","+4903023125000","+4903023125000"},
      {"+49 (0)","+490","+490"},
      {"+44 (0)123","+440123","+440123"}
    }) one(row[0],row[1],row[2]);
    String local="03023125000";
    CtExcelOriginationProbe.verify("domestic-retained","23433",Arrays.asList(CtExcelOriginationProbe.SIP),
        local,"tel:"+local+";phone-context="+CtExcelOriginationProbe.CT_REALM,CtExcelOriginationProbe.SIP,true,true);
    // The correction belongs to destination notation, not the originating SIM's operator.
    CtExcelOriginationProbe.verify("foreign-origin-corrected","20404",Arrays.asList(CtExcelOriginationProbe.TEL),
        "+49 (0)30 23125000",previous?"tel:+4903023125000":"tel:+493023125000",CtExcelOriginationProbe.TEL,false,true);
    String baseCaller = "tel:+32470123456";
    String[][] baseCases = {
        {"+32 (0)2 555 01 23", previous || beforeExpansion ? "tel:+32025550123" : "tel:+3225550123"},
        {"0032 (0)470 12 34 56", previous || beforeExpansion ? "tel:+320470123456" : "tel:+32470123456"},
        {"+3225550123", "tel:+3225550123"},
        {"025550123", "sip:025550123@ims.mnc020.mcc206.3gppnetwork.org"},
        {"+39 06 123456", "tel:+3906123456"}
    };
    for (String[] entry : baseCases)
      CtExcelOriginationProbe.verify("BASE-destination","20620",Collections.singletonList(baseCaller),
          entry[0],entry[1],baseCaller,false,true);
    for(String shortCode:new String[]{"110","112","999","911"})
      check(shortCode.equals(Class.forName("u10").getMethod("c",String.class).invoke(null,shortCode)),"emergency digit normalization preserved without originating calls");
    System.out.println("NATIVE_OPTIONAL_TRUNK mode="+args[0]+" checks="+(checks+CtExcelOriginationProbe.checks)
        +" protected="+PreconditionProbe.protectedPackets+" input_paths="+entries);
  }
}
