import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Keep native C/A and fallback; collect only TCP payload and final tunnel packet. */
public final class TransportBoundaryAdapter {
  public static void main(String[] a) throws Exception {
    int count = 0;
    try (ZipFile in = new ZipFile(a[0]);
        ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(Paths.get(a[1])))) {
      for (ZipEntry e : Collections.list(in.entries())) {
        byte[] bytes = in.getInputStream(e).readAllBytes();
        if (e.getName().equals("o82.class") || e.getName().equals("b72.class")) {
          ClassNode n = new ClassNode();
          new ClassReader(bytes).accept(n, 0);
          for (MethodNode m : n.methods) {
            boolean tcp =
                e.getName().equals("o82.class") && m.name.equals("E") && m.desc.equals("(I[B)V");
            boolean tunnel =
                e.getName().equals("b72.class") && m.name.equals("r") && m.desc.equals("([B)V");
            if (!tcp && !tunnel) continue;
            m.instructions.clear();
            m.tryCatchBlocks.clear();
            if (m.localVariables != null) m.localVariables.clear();
            m.instructions.add(new VarInsnNode(Opcodes.ALOAD, tcp ? 2 : 1));
            m.instructions.add(
                new MethodInsnNode(
                    Opcodes.INVOKESTATIC,
                    "OutboundTransportProbe",
                    tcp ? "tcp" : "tunnel",
                    "([B)V",
                    false));
            m.instructions.add(new InsnNode(Opcodes.RETURN));
            m.maxStack = 1;
            m.maxLocals = tcp ? 3 : 2;
            count++;
          }
          ClassWriter w = new ClassWriter(0);
          n.accept(w);
          bytes = w.toByteArray();
        }
        out.putNextEntry(new ZipEntry(e.getName()));
        out.write(bytes);
        out.closeEntry();
      }
    }
    if (count != 2) throw new AssertionError("boundary count " + count);
  }
}
