import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class OutboundTransportProbe {
  static int checks;
  static boolean previous;
  static final List<String> transports = new ArrayList<String>(), wires = new ArrayList<String>();

  static void check(boolean b, String m) {
    if (!b) throw new AssertionError(m);
    checks++;
  }

  static Object get(Object o, String f) throws Exception {
    return SipForkProbe.get(o, f);
  }

  static void set(Object o, String f, Object v) throws Exception {
    SipForkProbe.set(o, f, v);
  }

  static Object call(Object o, String n, Class<?>[] t, Object... v) throws Exception {
    return SipForkProbe.call(o, n, t, v);
  }

  static Object alloc(String n) throws Exception {
    return SipForkProbe.allocate(Class.forName(n));
  }

  public static void tcp(byte[] p) {
    transports.add("TCP");
    wires.add(new String(p, StandardCharsets.UTF_8));
  }

  public static void tunnel(byte[] p) {
    int offset = (p[0] >>> 4 & 15) == 6 ? 48 : 28;
    check((p[0] >>> 4 & 15) == 6 && (p[6] & 255) == 17, "actual IPv6 tunnel contains UDP");
    transports.add("UDP");
    wires.add(new String(p, offset, p.length - offset, StandardCharsets.UTF_8));
  }

  static String header(String text, String name) throws Exception {
    Object parsed =
        Class.forName("jb4")
            .getMethod("c", byte[].class)
            .invoke(null, (Object) text.getBytes(StandardCharsets.UTF_8));
    return SipForkProbe.first(parsed, name);
  }

  static Object address(int end) throws Exception {
    byte[] a = {0x20, 1, 0x0d, (byte) 0xb8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (byte) end};
    return Class.forName("x82").getConstructor(byte[].class).newInstance((Object) a);
  }

  static SipForkProbe.Session outgoing(boolean tcp, boolean established) throws Exception {
    transports.clear();
    wires.clear();
    SipForkProbe.Session s = new SipForkProbe.Session(tcp);
    ((Map) get(s.m, "e")).clear();
    Object config = alloc("xi5");
    set(config, "g", "example.invalid");
    set(config, "z", alloc("yj5"));
    set(s.e, "b", config);
    set(s.e, "s", alloc("x72"));
    set(s.e, "a", alloc("b72"));
    set(s.e, "h", address(1));
    set(s.e, "j", address(2));
    set(s.e, "k", 5060);
    set(s.e, "l", 40000);
    set(s.e, "m", 40001);
    set(s.e, "S", new HashMap<Object, Object>());
    set(
        s.e,
        "R",
        Class.forName("jf2").getConstructor(byte[].class).newInstance((Object) new byte[16]));
    set(s.e, "W", !tcp);
    if (tcp) {
      set(s.e, "T", 7);
      set(s.e, "U", established);
    }
    set(s.e, "I", true);
    set(get(s.e, "s"), "a", Arrays.asList("sip:local@example.invalid"));
    set(get(s.e, "s"), "e", new ArrayList<Object>());
    Object card = alloc("ek5");
    set(card, "a", "999990000000001");
    set(s.e, "c", card);
    set(s.e, "n", "urn:uuid:offline-probe");
    call(s.e, "s", new Class<?>[0]);
    check(
        Boolean.valueOf(tcp).equals(get(get(s.m, "a"), "j")),
        "real o82.s selects ra4 transport from R/W");
    Object codec = Class.forName("vk").getField("c").get(null);
    Object offer =
        Class.forName("wv1")
            .getConstructor(Object.class, int.class, Object.class, int.class)
            .newInstance(get(s.e, "h"), 45000, codec, 2);
    set(s.m, "c", offer);
    Object task =
        Class.forName("f82")
            .getConstructor(Class.forName("o82"), String.class, Class.forName("ct0"), int.class)
            .newInstance(s.e, "+12025550123", null, 4);
    Object id =
        call(
            task, "q", new Class<?>[] {Object.class}, Class.forName("sc5").getField("a").get(null));
    check(id instanceof String, "actual f82 outgoing call ID returned");
    s.d = ((Map) get(s.m, "e")).get(id);
    check(s.d != null && wires.size() == 1, "actual native INVITE sent once");
    return s;
  }

  static Object response(SipForkProbe.Session s, String wire, int code) throws Exception {
    String phrase =
        code == 180 ? "Ringing" : code == 183 ? "Session Progress" : "Request Terminated";
    StringBuilder b = new StringBuilder("SIP/2.0 " + code + " " + phrase + "\r\n");
    for (String n : new String[] {"Via", "From", "Call-ID", "CSeq"})
      b.append(n).append(": ").append(header(wire, n)).append("\r\n");
    b.append("To: ").append(header(wire, "To")).append(";tag=remote\r\nContent-Length: 0\r\n\r\n");
    return Class.forName("jb4")
        .getMethod("c", byte[].class)
        .invoke(null, (Object) b.toString().getBytes(StandardCharsets.UTF_8));
  }

  static void fallback(SipForkProbe.Session s) throws Exception {
    Object closed =
        Class.forName("a82").getConstructor(Class.forName("o82"), int.class).newInstance(s.e, 2);
    Object reasons = Class.forName("qe2").getMethod("values").invoke(null);
    call(closed, "f", new Class<?>[] {Object.class, Object.class}, 7, Array.get(reasons, 0));
  }

  static void tick(SipForkProbe.Session s) throws Exception {
    s.e.getClass().getMethod("a", s.e.getClass()).invoke(null, s.e);
  }

  static void timerAndIsolation() throws Exception {
    SipForkProbe.Session s = outgoing(true, false);
    Object stored = get(s.d, "j");
    List<?> timers = (List<?>) get(s.d, "F");
    check(timers.size() == 1, "one transaction timer created by the TCP INVITE");
    Object timer = timers.get(0);
    double deadline = (Double) get(timer, "e");
    check(
        Double.isInfinite((Double) get(timer, "c")) && Double.isInfinite((Double) get(timer, "d")),
        "TCP transaction starts without UDP retransmission");
    fallback(s);
    check(
        get(s.d, "j") == stored
            && timers.size() == 1
            && timers.get(0) == timer
            && get(timer, "a") == stored,
        "fallback retains the original request and existing INVITE timer");
    check((Double) get(timer, "e") == deadline, "original completion deadline retained");
    double interval = (Double) get(timer, "c"), next = (Double) get(timer, "d");
    check(
        previous
            ? Double.isInfinite(next) && Double.isInfinite(interval)
            : interval == 0.5 && Double.isFinite(next) && next <= deadline,
        "UDP Timer A activation");
    if (!previous) set(timer, "d", 0.0);
    tick(s);
    check(wires.size() == (previous ? 2 : 3), "real timer tick only retransmits a due UDP INVITE");
    if (!previous)
      check(
          wires.get(1).equals(wires.get(2)) && "UDP".equals(transports.get(2)),
          "exact UDP INVITE retransmitted at transport boundary");
    System.out.println(
        "FALLBACK original_deadline_retained=true udp_timer_armed="
            + Double.isFinite(interval)
            + " udp_invite_retried="
            + (!previous));

    s = outgoing(true, false);
    String original = wires.get(0);
    check(s.accept(response(s, original, 180)), "provisional received on original TCP transaction");
    fallback(s);
    int afterFallback = wires.size();
    for (Object t : (List<?>) get(s.d, "F")) {
      if ("INVITE".equals(get(get(t, "a"), "b")))
        check(
            Double.isInfinite((Double) get(t, "d")),
            "provisional keeps INVITE retransmission disabled");
    }
    tick(s);
    check(
        wires.size() == afterFallback,
        "a later TCP close cannot start retransmission after ringing");

    s = outgoing(true, false);
    Object queued = ((List<?>) get(s.e, "V")).get(0);
    stored = get(s.d, "j");
    String via = SipForkProbe.first(stored, "Via");
    int originalSeq = (Integer) get(s.d, "i");
    String differentSeq = (originalSeq == 1 ? 2 : 1) + " INVITE";
    call(queued, "i", new Class<?>[] {String.class, String.class}, "CSeq", differentSeq);
    fallback(s);
    check(
        via.equals(SipForkProbe.first(stored, "Via")),
        "fallback of separate request cannot change original transaction Via");
    timer = ((List<?>) get(s.d, "F")).get(0);
    check(
        Double.isInfinite((Double) get(timer, "c")), "separate request cannot arm original timer");
  }

  public static void main(String[] a) throws Exception {
    previous = a[0].equals("previous-24-1");
    SipForkProbe.msg = Class.forName("kb4");
    SipForkProbe.dialog = Class.forName("ma4");
    SipForkProbe.manager = Class.forName("cb4");
    SipForkProbe.direction = Class.forName("ga4");
    SipForkProbe.state = Class.forName("la4");
    SipForkProbe.helper = Class.forName("cc.forserein.simhub.internal.SipForkProtection");
    for (boolean tcp : new boolean[] {false, true}) {
      SipForkProbe.Session s = outgoing(tcp, true);
      String invite = wires.get(0);
      Object stored = get(s.d, "j");
      for (String n : new String[] {"Via", "From", "Call-ID", "CSeq"})
        check(
            Objects.equals(header(invite, n), SipForkProbe.first(stored, n)),
            "native outgoing stored and wire " + n);
      check(invite.contains("IN IP6"), "native IPv6 SDP generated");
      check(transports.get(0).equals(tcp ? "TCP" : "UDP"), "native send transport selection");
      check(s.accept(response(s, invite, 487)), "real wire-correlated487 processed");
      check(wires.size() == 2 && wires.get(1).startsWith("ACK "), "normal487 ACK produced");
      check(transports.get(1).equals(transports.get(0)), "normal ACK uses initial transport");
      check(
          Objects.equals(header(invite, "Via"), header(wires.get(1), "Via")),
          "normal ACK reuses initial Via branch");
      check(((Map) get(s.m, "e")).isEmpty(), "real pending487 ends correctly");
      System.out.println("NORMAL " + transports + " stored_wire_match=true guard_match=true");
    }
    SipForkProbe.Session s = outgoing(true, false);
    String tcpInvite = wires.get(0);
    Object stored = get(s.d, "j");
    check(
        ((List) get(s.e, "V")).size() == 1,
        "native C clones unconfirmed TCP request into fallback queue");
    fallback(s);
    check(
        wires.size() == 2 && "UDP".equals(transports.get(1)),
        "actual TCP failure callback resends through native UDP A");
    String udpInvite = wires.get(1);
    check(header(udpInvite, "Via").startsWith("SIP/2.0/UDP"), "fallback INVITE advertises UDP");
    check(
        SipForkProbe.first(stored, "Via").equals(header(previous ? tcpInvite : udpInvite, "Via")),
        "stored INVITE Via after actual native fallback");
    check(
        header(tcpInvite, "Via")
            .replace("SIP/2.0/TCP", "SIP/2.0/UDP")
            .equals(header(udpInvite, "Via")),
        "fallback retains branch and sent-by");
    check(
        Boolean.FALSE.equals(get(get(s.m, "a"), "j")),
        "actual fallback o82.s selects UDP for subsequent newly built requests");

    Object provisional = response(s, udpInvite, 183);
    SipForkProbe.header(provisional, "Require", "100rel");
    SipForkProbe.header(provisional, "RSeq", "1");
    check(s.accept(provisional), "normal reliable183 after fallback handled");
    check(
        wires.size() == 3
            && wires.get(2).startsWith("PRACK ")
            && header(wires.get(2), "Via").startsWith("SIP/2.0/UDP"),
        "fresh PRACK after actual fallback correctly advertises UDP");
    Object cancel =
        Class.forName("f82")
            .getConstructor(Class.forName("o82"), String.class, Class.forName("ct0"), int.class)
            .newInstance(s.e, get(s.d, "b"), null, 3);
    call(cancel, "q", new Class<?>[] {Object.class}, Class.forName("sc5").getField("a").get(null));
    check(
        wires.size() == 4
            && wires.get(3).startsWith("CANCEL ")
            && transports.get(3).equals("UDP")
            && header(wires.get(3), "Via").equals(header(previous ? tcpInvite : udpInvite, "Via")),
        "CANCEL after fallback uses the stored transaction Via");
    check(
        s.accept(response(s, udpInvite, 487)), "24.1 guard matches actual fallback wire487 branch");
    check(wires.size() == 5 && wires.get(4).startsWith("ACK "), "fallback487 ACK generated");
    check("UDP".equals(transports.get(4)), "fallback ACK actually uses UDP");
    check(
        header(wires.get(4), "Via").equals(header(previous ? tcpInvite : udpInvite, "Via")),
        "fallback ACK matches stored transaction Via");
    check(((Map) get(s.m, "e")).isEmpty(), "fallback real487 not mistaken as stale");
    System.out.println(
        "FALLBACK transports="
            + transports
            + " initial_via="
            + header(tcpInvite, "Via")
            + " fallback_via="
            + header(udpInvite, "Via")
            + " ack_via="
            + header(wires.get(4), "Via"));
    Object newTask =
        Class.forName("f82")
            .getConstructor(Class.forName("o82"), String.class, Class.forName("ct0"), int.class)
            .newInstance(s.e, "+12025550124", null, 4);
    Object newId =
        call(
            newTask,
            "q",
            new Class<?>[] {Object.class},
            Class.forName("sc5").getField("a").get(null));
    check(
        newId instanceof String
            && wires.size() == 6
            && wires.get(5).startsWith("INVITE ")
            && header(wires.get(5), "Via").startsWith("SIP/2.0/UDP"),
        "new native outgoing call after fallback starts with consistent UDP Via");
    timerAndIsolation();
    System.out.println("OUTBOUND_TRANSPORT mode=" + a[0] + " checks=" + checks);
  }
}
