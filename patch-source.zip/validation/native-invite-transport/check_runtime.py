#!/usr/bin/env python3
"""Exercise the outbound TCP/UDP dispatch and retransmission scheduler from the supplied APK."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

here = Path(__file__).resolve().parent
shared = here.parent / "native-fork"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("apk", type=Path)
parser.add_argument("--carrier-report", type=Path, required=True)
parser.add_argument("--report", type=Path, required=True)
parser.add_argument("--unsigned-apk", type=Path)
parser.add_argument("--jar", type=Path)
parser.add_argument("--previous-24-1", "--legacy", action="store_true")
args = parser.parse_args()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


carrier = json.loads(args.carrier_report.read_text())
jar = args.jar or args.carrier_report.parent / "native-carrier-current" / "probe.jar"
unsigned = args.unsigned_apk or args.apk
assert carrier["apk_sha256"] == digest(unsigned), "unexpected unsigned APK"
assert carrier["apk_translated_jar_sha256"] == digest(jar), "unexpected translated JAR"
with zipfile.ZipFile(unsigned) as original, zipfile.ZipFile(args.apk) as signed:
    dex_pattern = re.compile(r"classes\d*\.dex")
    names = set(filter(dex_pattern.fullmatch, original.namelist()))
    assert names and names == set(filter(dex_pattern.fullmatch, signed.namelist())), "DEX set mismatch"
    dex_hashes = {}
    for name in sorted(names):
        content = signed.read(name)
        assert original.read(name) == content, name
        dex_hashes[name] = hashlib.sha256(content).hexdigest()

kit = Path(os.environ.get("SIMHUB_TOOLS", "/workspace/tools/android-recovery"))
dexkit = Path(os.environ.get("SIMHUB_DEX2JAR_TOOLS", "/workspace/tools/dex2jar-v2.4"))
lib = dexkit / "dex-tools-v2.4/lib"
asm = os.pathsep.join(str(lib / name) for name in ("asm-9.5.jar", "asm-tree-9.5.jar"))
sources = [shared / "g11.java", shared / "SipForkProbe.java", here / "OutboundTransportProbe.java", here / "TransportBoundaryAdapter.java"]
mode = "previous-24-1" if args.previous_24_1 else "fixed"
args.report.parent.mkdir(parents=True, exist_ok=True)
log = []


def run(*command):
    result = subprocess.run(list(map(str, command)), capture_output=True, text=True)
    log.append(result.stdout + result.stderr)
    args.report.with_suffix(".log").write_text("\n".join(log))
    if result.returncode:
        print(log[-1])
        raise SystemExit(result.returncode)
    return result.stdout


with tempfile.TemporaryDirectory(dir=args.report.parent, prefix="native-transport-") as tmp:
    work = Path(tmp)
    classes = work / "classes"
    classes.mkdir()
    run("java", "-jar", kit / "ecj-3.40.0.jar", "-17", "-warn:none", "-proc:none", "-cp", asm, "-d", classes, *sources)
    adapted = work / "transport.jar"
    run("java", "-cp", os.pathsep.join([str(classes), asm]), "TransportBoundaryAdapter", jar, adapted)
    with zipfile.ZipFile(jar) as before, zipfile.ZipFile(adapted) as after:
        assert set(before.namelist()) == set(after.namelist())
        changed = {name for name in before.namelist() if before.read(name) != after.read(name)}
        assert changed == {"b72.class", "o82.class"}, changed
    cp = os.pathsep.join(map(str, [classes, adapted, kit / "sdk/android-35/android.jar"]))
    output = run("java", "-noverify", "-cp", cp, "OutboundTransportProbe", mode)

match = re.search(r"OUTBOUND_TRANSPORT mode=([\w-]+) checks=(\d+)", output)
assert match and match[1] == mode, output
report = {
    "apk_sha256": digest(args.apk), "dex_sha256": dex_hashes,
    "apk_translated_jar_sha256": digest(jar), "carrier_report_sha256": digest(args.carrier_report),
    "mode": mode, "checks": int(match[2]),
    "real_outgoing_invite_cancel_ack": True, "real_tcp_fallback_callback": True,
    "real_udp_ip_packet_serialization": True, "real_invite_timer_and_scheduler": True,
    "fixture_boundaries": ["o82.E receives outgoing TCP payload", "b72.r receives the final tunnel packet", "Android log sink and in-memory engine state"],
    "network_calls_placed": False, "real_carrier_tested": False, "android_art_tested": False,
    "dex_to_jvm_constructor_adapters": True, "jvm_verification_disabled_for_translated_dex": True,
    "diagnostic_observations": [s for s in output.splitlines() if not s.startswith("OUTBOUND_TRANSPORT")],
    "fixture_sources": {str(source.relative_to(here.parents[1])): digest(source) for source in sources},
}
args.report.write_text(json.dumps(report, indent=2) + "\n")
print(output.strip())
