import java.lang.reflect.*;
import java.util.*;

/** Calls actual APK SIP methods; no socket, SIM, or protocol-method doubles. */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class sip_protocol_probe {
 static Class<?> msg, dialog, manager, direction, state;
 static int checks;
 static boolean fixed,requestHeadersFixed;
 static Object get(Object o,String field)throws Exception{return o.getClass().getField(field).get(o);}
 static void set(Object o,String field,Object value)throws Exception{o.getClass().getField(field).set(o,value);}
 static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
 static Object message(boolean request,String method,int status,byte[]body)throws Exception{
  return msg.getConstructor(boolean.class,String.class,String.class,int.class,String.class,ArrayList.class,byte[].class)
    .newInstance(request,method,"sip:peer@example.invalid",status,request?"":"OK",new ArrayList<>(),body);
 }
 static void header(Object m,String name,String value)throws Exception{msg.getMethod("a",String.class,String.class).invoke(m,name,value);}
 static Object newDialog(boolean incoming)throws Exception{
  return dialog.getConstructors()[0].newInstance(direction.getField(incoming?"T":"U").get(null),"probe@example.invalid",state.getField("W").get(null),"local-tag","sip:local@example.invalid","sip:peer@example.invalid","sip:peer@example.invalid",11,11,message(true,"INVITE",0,new byte[0]),0.0);
 }
 static Object newManager(boolean tcp)throws Exception{
  Object config=Class.forName("ra4").getConstructors()[0].newInstance("192.0.2.1",5060,"sip:local@example.invalid","urn:uuid:sip-probe","sip:local@example.invalid","probe",new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),tcp,false);
  return manager.getConstructors()[0].newInstance(config,null,null,null);
 }
 static Object allocate(Class<?> type)throws Exception{
  Class<?> unsafeClass=Class.forName("sun.misc.Unsafe");Field f=unsafeClass.getDeclaredField("theUnsafe");f.setAccessible(true);
  return unsafeClass.getMethod("allocateInstance",Class.class).invoke(f.get(null),type);
 }
 static final class Session {
  Object d,m,e;
  Session(boolean incoming,boolean tcp)throws Exception{
   d=newDialog(incoming);m=newManager(tcp);((Map)get(m,"e")).put("probe@example.invalid",d);
   set(d,"B",1800);set(d,"C",true);set(d,"E",123.0);e=allocate(Class.forName("o82"));set(e,"J",m);
  }
  int send(String method)throws Exception{
   Object request=manager.getMethod("k",String.class,dialog,byte[].class).invoke(m,method,d,null);
   return(Integer)get(msg.getMethod("e").invoke(request),"a");
  }
  boolean response(int status,int cseq,String key,String value,boolean body)throws Exception{
   Object r=message(false,"UPDATE",status,body?new byte[]{1,2}:new byte[0]);
   header(r,"Call-ID","probe@example.invalid");header(r,"CSeq",cseq+" UPDATE");if(value!=null)header(r,key,value);
   return(Boolean)e.getClass().getMethod("h",msg).invoke(e,r);
  }
  void timer(Integer interval,boolean local,boolean changed,String label)throws Exception{
   check(Objects.equals(get(d,"B"),interval),"interval "+label);
   check((Boolean)get(d,"C")==local,"refresher "+label);
   check(changed?((Double)get(d,"E"))!=123.0:((Double)get(d,"E"))==123.0,"receipt time "+label);
  }
 }
 public static void main(String[]args)throws Exception{
  fixed=args.length>0&&!args[0].equals("baseline");
  requestHeadersFixed=args.length>0&&args[0].equals("fixed");
  msg=Class.forName("kb4");dialog=Class.forName("ma4");manager=Class.forName("cb4");direction=Class.forName("ga4");state=Class.forName("la4");
  for(boolean incoming:new boolean[]{false,true})for(String method:new String[]{"UPDATE","INVITE"})for(String key:new String[]{"Session-Expires","x","X"})for(String refresher:new String[]{"uac","uas","UAC","UAS","uAc","UaS",null}){
   Object d=newDialog(incoming),request=message(true,method,0,new byte[0]),response=message(false,method,200,new byte[0]);
   header(request,key,"1800"+(refresher==null?"":";refresher="+refresher));manager.getMethod("c",msg,msg,dialog).invoke(null,response,request,d);
   boolean actual=(Boolean)get(d,"C"),correct="uas".equalsIgnoreCase(refresher);
   boolean parsed=requestHeadersFixed||key.equals("Session-Expires");
   boolean oldCase="uas".equals(refresher),expected=parsed&&(requestHeadersFixed?correct:(fixed?oldCase:(incoming?oldCase:!oldCase)));
   String label=incoming+"/"+method+"/"+key+"/"+refresher;
   check(Objects.equals(get(d,"B"),parsed?Integer.valueOf(1800):null),"request interval "+label);
   check(actual==expected,"request role "+label+" got="+actual+" expected="+expected);
   List echoed=(List)msg.getMethod("j",String.class).invoke(response,"Session-Expires");
   check(parsed?echoed.equals(Arrays.asList("1800;refresher="+(refresher==null?"uac":refresher))):echoed.isEmpty(),"existing negotiation/echo policy "+label);
   if(incoming&&method.equals("UPDATE")&&(key.equals("x")||"UAS".equals(refresher)))
    System.out.println("REQUEST key="+key+" refresher="+refresher+" interval="+get(d,"B")+" localRefresh="+actual+" expectedInterval=1800 expectedLocal="+correct);
  }
  for(boolean incoming:new boolean[]{false,true})for(int status:new int[]{200,202})for(boolean body:new boolean[]{false,true})for(String key:new String[]{"Session-Expires","x","X"})for(String value:new String[]{"90;refresher=uac","120;refresher=uas",null,"180;refresher=UAS","240","0;refresher=uac","89;refresher=uac","-1;refresher=uas","2147483648;refresher=uac","invalid","300;refresher=unknown"}){
   Session s=new Session(incoming,true);int cseq=s.send("UPDATE");check(cseq==12,"native UPDATE generation increments CSeq");
   check(s.response(status,cseq,key,value,body),"UPDATE response handled");
   Integer interval=1800;boolean local=true,changed=false;
   if(fixed){
    if(value==null){interval=null;local=false;changed=true;}
    else if(value.startsWith("90;")){interval=90;local=true;changed=true;}
    else if(value.startsWith("120;")){interval=120;local=false;changed=true;}
    else if(value.startsWith("180;")){interval=180;local=false;changed=true;}
    else if(value.equals("240")){interval=240;local=true;changed=true;}
   }
   s.timer(interval,local,changed,key+":"+value);
   check(!body||Arrays.equals((byte[])get(s.d,"p"),new byte[]{1,2}),"existing SDP event delivery preserved");
  }
  for(boolean tcp:new boolean[]{false,true}){
   Session s=new Session(false,tcp);int first=s.send("UPDATE");s.send("INFO");
   s.response(100,first,"Session-Expires","90;refresher=uas",false);s.timer(1800,true,false,"provisional");
   s.response(200,first+8,"Session-Expires","90;refresher=uas",false);s.timer(1800,true,false,"unsolicited future CSeq");
   s.response(200,first,"Session-Expires","90;refresher=uas",false);s.timer(fixed?90:1800,!fixed,fixed,"UPDATE then INFO");
   Object savedTime=get(s.d,"E");
   s.response(200,first,"Session-Expires","600;refresher=uac",false);s.timer(fixed?90:1800,!fixed,fixed,"duplicate successful UPDATE");
   check(Objects.equals(get(s.d,"E"),savedTime),"duplicate must not extend expiration");
   int next=s.send("UPDATE");check(next==14,"INFO retains native CSeq sequence");
   s.response(200,first,"Session-Expires","600;refresher=uac",false);s.timer(fixed?90:1800,!fixed,fixed,"stale after next UPDATE");
   check(Objects.equals(get(s.d,"E"),savedTime),"stale response must not extend expiration");
   s.response(200,next,"Session-Expires","180;refresher=uac",false);s.timer(fixed?180:1800,true,fixed,"next matching UPDATE");
  }
  System.out.println("SIP_PROTOCOL_PROBE mode="+(requestHeadersFixed?"fixed":(fixed?"pre_request_headers":"baseline"))+" checks="+checks+" passed=true");
 }
}
