#!/usr/bin/env python3
"""Run timer assertions against a normalized real-APK JVM jar, without SIP sockets."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
p=argparse.ArgumentParser();p.add_argument('jar',type=Path);p.add_argument('--report',type=Path,required=True);p.add_argument('--baseline',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parents[2]
tools=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
classes=a.report.parent/'native-sip-classes';classes.mkdir(parents=True,exist_ok=True)
commands=[['java','-jar',tools/'ecj-3.40.0.jar','-17','-proc:none','-d',classes,Path(__file__).with_name('sip_protocol_probe.java')],
 ['java','-noverify','-cp',os.pathsep.join(map(str,[classes,a.jar,tools/'sdk/android-35/android.jar'])),'sip_protocol_probe','baseline'if a.baseline else'fixed']]
logs=[]
for command in commands:
 r=subprocess.run(list(map(str,command)),cwd=root,capture_output=True,text=True);logs.append(r.stdout+r.stderr)
 if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
match=re.search(r'SIP_PROTOCOL_PROBE mode=(baseline|fixed) checks=(\d+) passed=true',logs[-1]);assert match,logs[-1]
report={'apk_translated_jar_sha256':hashlib.sha256(a.jar.read_bytes()).hexdigest(),'checks':int(match[2]),'mode':match[1],
 'native_request_timer_function_executed':True,'native_update_response_dispatcher_executed':True,
 'protocol_methods_mocked':False,'engine_constructor_bypassed_to_avoid_network':True,
 'body_event_delivery_preserved':True,'real_carrier_tested':False,'device_tested':False,'art_execution':False}
a.report.write_text(json.dumps(report,indent=2)+'\n');a.report.with_suffix('.log').write_text('\n'.join(logs));print(logs[-1].strip())
