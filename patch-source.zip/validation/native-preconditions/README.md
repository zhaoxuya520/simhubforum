# Native IMS precondition verification

The probe executes the supplied APK's outgoing call builder, accepted provisional-response path, native resource-confirmation callback and UPDATE builder. It uses the actual CTExcel UK policy at `zi5.a[23433].d`, synthetic IPv6 endpoints and the reserved UK example number `+441632960123`.

The relevant rule is **3GPP TS 24.229 §5.1.3.1**:

- An initial IMS INVITE advertises `precondition` in `Supported`; it must not require it through `Require`.
- After an SDP response requires `precondition`, subsequent requests with SDP in the same early dialog must include `Require: precondition`.
- An SDP response without that requirement must not cause the option to be added to subsequent requests in that dialog.

The baseline 24.3 package omits the negotiated requirement from its SDP UPDATE. `--previous-24-3` records that negative control. Fixed mode requires the actual hooked native UPDATE to carry the negotiated option. Neither mode changes or bypasses destination policy, authentication, registration or carrier authorization.

```sh
python3 validation/native-preconditions/check_runtime.py APK \
  --carrier-report build-config3/native-carrier-runtime.json \
  --report build-config3/native-preconditions-runtime.json
```

For a signed APK, use `--unsigned-apk` with the unsigned APK from the carrier report. The runner verifies that all DEX files are identical. It reuses the carrier probe's translated JAR, with an optional explicit `--jar` for a pinned snapshot.

The main cases cover TCP and protected UDP with AES-CBC or NULL encryption. For UDP, native `o82.C/A`, `w72.b` and `eb1.b` produce complete IPv6 ESP packets. The fixture independently verifies HMAC-SHA1-96, decrypts using fixed synthetic keys, and checks the SIP messages and negotiated UDP ports. TCP payloads are captured at `o82.E` before the native TCP stack; TCP encryption is not tested.

Additional cases cover a response without SDP, a newer SDP without the requirement, a different early-dialog To-tag, established-call refreshes, bodyless PRACK and a real network-status 487 response. Option-preservation tests call the APK helper with an actual native request preloaded with `sec-agree` and `timer`; these are explicitly helper-level cases. The main negotiation cases always execute the actual hooked native response and request paths.

The only modified translated methods are the final TCP-payload and tunnel-packet output boundaries. Android log and call-controller event sinks are fixtures. The engine uses an in-memory registered-session shape; no SIM authentication, network connection, real telephone call or Android audio occurs. DEX-to-JVM probes use `-noverify`; device ART verification is a separate report.

This proves a specific negotiated-header interoperability defect and the bounds of its correction. It does **not** prove that the user's CTExcel 487 was caused by that defect. That requires the real INVITE-to-final-response exchange.

Reference: https://www.etsi.org/deliver/etsi_ts/124200_124299/124229/17.09.00_60/ts_124229v170900p.pdf
