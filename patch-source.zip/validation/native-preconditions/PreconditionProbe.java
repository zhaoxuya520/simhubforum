import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

/** Real CTExcel call builders/dispatch and Gm ESP; collect only final transport and UI events. */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class PreconditionProbe {
  static boolean previous;
  static int checks, protectedPackets;
  static final List<String> wires = new ArrayList<>();
  static final byte[] IK = new byte[20], CK = new byte[16];
  static String encryption = "aes-cbc";
  static {
    for (int i = 0; i < IK.length; i++) IK[i] = (byte) (0x10 + i);
    for (int i = 0; i < CK.length; i++) CK[i] = (byte) (0x70 + i);
  }

  static void check(boolean value, String label) {
    if (!value) throw new AssertionError(label);
    checks++;
  }
  static Object get(Object object, String field) throws Exception { return SipForkProbe.get(object, field); }
  static void set(Object object, String field, Object value) throws Exception { SipForkProbe.set(object, field, value); }
  static Object alloc(String name) throws Exception { return SipForkProbe.allocate(Class.forName(name)); }
  static Object call(Object object, String method, Class<?>[] types, Object... values) throws Exception {
    return SipForkProbe.call(object, method, types, values);
  }
  static String first(Object message, String name) throws Exception { return SipForkProbe.first(message, name); }
  static Object parse(String wire) throws Exception {
    Object message = Class.forName("jb4").getMethod("c", byte[].class)
        .invoke(null, (Object) wire.getBytes(StandardCharsets.UTF_8));
    check(message != null, "native SIP parser accepts fixture");
    return message;
  }
  static boolean option(Object message, String header, String token) throws Exception {
    for (String value : SipForkProbe.headers(message, header))
      for (String part : value.split(",")) if (token.equalsIgnoreCase(part.trim())) return true;
    return false;
  }
  static String body(Object message) throws Exception {
    return new String((byte[]) get(message, "g"), StandardCharsets.UTF_8);
  }
  public static void tcp(byte[] payload) { wires.add(new String(payload, StandardCharsets.UTF_8)); }
  static int u16(byte[] bytes, int offset) { return ((bytes[offset] & 255) << 8) | (bytes[offset + 1] & 255); }
  static long u32(byte[] bytes, int offset) { return ((long) u16(bytes, offset) << 16) | u16(bytes, offset + 2); }

  /** Independently authenticate/decrypt the real native Gm packet using public, synthetic keys. */
  public static void tunnel(byte[] packet) {
    try {
      check(packet.length > 60 && (packet[0] >>> 4 & 15) == 6 && (packet[6] & 255) == 50,
          "native Gm request emits IPv6 ESP");
      check(u16(packet, 4) == packet.length - 40, "native IPv6 payload length");
      check(packet[23] == 1 && packet[39] == 2, "protected source and peer IPv6 addresses");
      byte[] esp = Arrays.copyOfRange(packet, 40, packet.length);
      check(u32(esp, 0) == 0x20002, "protected request uses negotiated peer server SPI");
      Mac mac = Mac.getInstance("HmacSHA1");
      mac.init(new SecretKeySpec(IK, "HmacSHA1"));
      byte[] authentication = mac.doFinal(Arrays.copyOf(esp, esp.length - 12));
      check(Arrays.equals(Arrays.copyOf(authentication, 12), Arrays.copyOfRange(esp, esp.length - 12, esp.length)),
          "native ESP authentication independently validates");
      byte[] plain;
      if (encryption.equals("aes-cbc")) {
        Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(CK, "AES"), new IvParameterSpec(Arrays.copyOfRange(esp, 8, 24)));
        plain = cipher.doFinal(Arrays.copyOfRange(esp, 24, esp.length - 12));
      } else plain = Arrays.copyOfRange(esp, 8, esp.length - 12);
      check((plain[plain.length - 1] & 255) == 17, "ESP next header is UDP");
      int padding = plain[plain.length - 2] & 255;
      byte[] udp = Arrays.copyOf(plain, plain.length - 2 - padding);
      check(u16(udp, 0) == 40000 && u16(udp, 2) == 50001, "registered client-to-peer-server ports preserved");
      check(u16(udp, 4) == udp.length, "protected UDP length");
      wires.add(new String(udp, 8, udp.length - 8, StandardCharsets.UTF_8));
      protectedPackets++;
    } catch (Exception failure) { throw new RuntimeException(failure); }
  }

  static Object address(int end) throws Exception {
    byte[] bytes = {0x20, 1, 0x0d, (byte) 0xb8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (byte) end};
    return Class.forName("x82").getConstructor(byte[].class).newInstance((Object) bytes);
  }
  static Object security(long clientSpi, long serverSpi, int clientPort, int serverPort) throws Exception {
    return Class.forName("z72").getConstructor(String.class, String.class, long.class, long.class, int.class, int.class)
        .newInstance("hmac-sha-1-96", encryption, clientSpi, serverSpi, clientPort, serverPort);
  }

  static final class Call {
    final SipForkProbe.Session nativeSession;
    final t00 sink = new t00();
    final String initial;
    final boolean tcp;
    Call(boolean tcp) throws Exception {
      this.tcp = tcp;
      wires.clear();
      nativeSession = new SipForkProbe.Session(tcp);
      Object engine = nativeSession.e, manager = nativeSession.m;
      ((Map) get(manager, "e")).clear();
      Object config = alloc("xi5");
      set(config, "g", "ims.mnc033.mcc234.3gppnetwork.org");
      Object policy = ((Map) Class.forName("zi5").getField("a").get(null)).get("23433");
      check(policy != null, "real CTExcel UK policy exists");
      set(config, "z", get(policy, "d"));
      set(config, "t", true);
      set(engine, "b", config);
      set(engine, "s", alloc("x72"));
      set(engine, "a", alloc("b72"));
      set(engine, "h", address(1)); set(engine, "j", address(2));
      set(engine, "k", 5060); set(engine, "l", 40000); set(engine, "m", 40001);
      set(engine, "S", new HashMap<>());
      set(engine, "R", Class.forName("jf2").getConstructor(byte[].class).newInstance((Object) new byte[16]));
      set(engine, "W", !tcp);
      if (tcp) { set(engine, "T", 7); set(engine, "U", true); }
      set(engine, "I", true);
      set(get(engine, "s"), "a", Arrays.asList("sip:local@example.invalid"));
      set(get(engine, "s"), "e", new ArrayList<>());
      Object card = alloc("ek5"); set(card, "a", "999990000000001"); set(engine, "c", card);
      set(engine, "n", "urn:uuid:precondition-offline");
      Object gm = Class.forName("w72").getConstructor(Class.forName("z72"), Class.forName("z72"),
          Class.forName("x82"), Class.forName("x82"), byte[].class, byte[].class)
          .newInstance(security(0x10001, 0x10002, 40000, 40001), security(0x20001, 0x20002, 50000, 50001),
              get(engine, "h"), get(engine, "j"), IK.clone(), CK.clone());
      set(engine, "q", gm);
      set(engine, "Q", Arrays.asList("ipsec-3gpp;alg=hmac-sha-1-96;ealg=" + encryption
          + ";spi-c=131073;spi-s=131074;port-c=50000;port-s=50001"));
      call(engine, "s", new Class<?>[0]);
      Object offer = Class.forName("wv1").getConstructor(Object.class, int.class, Object.class, int.class)
          .newInstance(get(engine, "h"), 45000, Class.forName("vk").getField("c").get(null), 2);
      set(manager, "c", offer);
      set(manager, "d", Class.forName("qa1").getConstructor(int.class).newInstance(29));
      set(engine, "N", sink);
      Object task = Class.forName("f82").getConstructor(Class.forName("o82"), String.class, Class.forName("ct0"), int.class)
          .newInstance(engine, "+441632960123", null, 4);
      Object id = call(task, "q", new Class<?>[] {Object.class}, Class.forName("sc5").getField("a").get(null));
      nativeSession.d = ((Map) get(manager, "e")).get(id);
      check(nativeSession.d != null && wires.size() == 1, "real native f82 creates and sends one initial INVITE");
      initial = wires.get(0);
      Object invite = parse(initial);
      check("tel:+441632960123".equals(get(invite, "c")), "CTExcel tel URI preserves international destination");
      check(body(invite).contains("c=IN IP6 2001:db8::1") && body(invite).contains("a=curr:qos local sendrecv"),
          "native IPv6 offer preserves current local resource status");
      check(option(invite, "Supported", "precondition") && !option(invite, "Require", "precondition"),
          "IMS initial INVITE advertises support without requiring preconditions");
    }
    Object dialog() { return nativeSession.d; }
    void accept(Object response) throws Exception { check(nativeSession.accept(response), "native response dispatcher handled response"); }
  }

  static String answer(boolean confirmation) {
    return "v=0\r\no=- 1 1 IN IP6 2001:db8::2\r\ns=call\r\nc=IN IP6 2001:db8::2\r\nt=0 0\r\n"
        + "m=audio 10000 RTP/AVP 116\r\na=rtpmap:116 AMR-WB/16000\r\na=fmtp:116 octet-align=1\r\n"
        + "a=curr:qos local none\r\na=curr:qos remote sendrecv\r\na=des:qos mandatory local sendrecv\r\n"
        + "a=des:qos mandatory remote sendrecv\r\n" + (confirmation ? "a=conf:qos remote sendrecv\r\n" : "") + "a=sendrecv\r\n";
  }
  static Object response(String requestWire, int status, String tag, String body, String extra) throws Exception {
    Object request = parse(requestWire);
    StringBuilder wire = new StringBuilder("SIP/2.0 " + status + " " + (status == 487 ? "Request Terminated" : status == 183 ? "Session Progress" : "OK") + "\r\n");
    for (String name : new String[] {"Via", "From", "Call-ID", "CSeq"}) wire.append(name + ": " + first(request, name) + "\r\n");
    String to = first(request, "To");
    wire.append("To: " + to + (to.contains(";tag=") ? "" : ";tag=" + tag) + "\r\n");
    wire.append("Contact: <sip:remote@[2001:db8::2]:5060>\r\n" + extra);
    if (!body.isEmpty()) wire.append("Content-Type: application/sdp\r\n");
    wire.append("Content-Length: " + body.getBytes(StandardCharsets.UTF_8).length + "\r\n\r\n" + body);
    return parse(wire.toString());
  }
  static String last(String method) throws Exception {
    for (int i = wires.size() - 1; i >= 0; i--) if (method.equals(get(parse(wires.get(i)), "b"))) return wires.get(i);
    return null;
  }
  static int count(String method) throws Exception {
    int count = 0; for (String wire : wires) if (method.equals(get(parse(wire), "b"))) count++; return count;
  }
  static Object update(Call call) throws Exception {
    return call(call.nativeSession.m, "k", new Class<?>[] {String.class, Class.forName("ma4"), byte[].class},
        "UPDATE", call.dialog(), get(call.dialog(), "o"));
  }
  static void progress(Call call, String tag, int rseq, boolean require, String body) throws Exception {
    call.accept(response(call.initial, 183, tag, body, "Require: 100rel" + (require ? ", PrEcOnDiTiOn" : "") + "\r\nRSeq: " + rseq + "\r\n"));
  }
  static void prack200(Call call) throws Exception {
    String request = last("PRACK"); check(request != null, "native reliable provisional creates PRACK");
    Object parsed = parse(request);
    check(body(parsed).isEmpty() && !option(parsed, "Require", "precondition"), "bodyless PRACK unchanged");
    call.accept(response(request, 200, "unused", "", ""));
  }

  static void normal(boolean tcp, boolean required) throws Exception {
    Call call = new Call(tcp);
    progress(call, "A", 1, required, answer(true));
    Object prack = parse(last("PRACK"));
    String originalSequence = first(parse(call.initial), "CSeq").split(" ")[0];
    check(("1 " + originalSequence + " INVITE").equals(first(prack, "RAck")), "native RAck uses original INVITE CSeq and RSeq");
    prack200(call);
    check(count("UPDATE") == 1, "native PRACK response generates one resource confirmation UPDATE");
    Object update = parse(last("UPDATE"));
    check(option(update, "Require", "precondition") == (required && !previous), "negotiated requirement propagated only in fixed package");
    check("application/sdp".equals(first(update, "Content-Type")), "native UPDATE has SDP content type");
    check(body(update).contains("a=curr:qos local sendrecv") && body(update).contains("a=curr:qos remote none"), "UPDATE retains actual resource status");
    check(first(update, "To").endsWith(";tag=A"), "UPDATE stays in negotiated early dialog");
    for (String wire : wires) {
      Object message = parse(wire);
      check(first(message, "Via").startsWith("SIP/2.0/" + (tcp ? "TCP" : "UDP") + " [2001:db8::1]:40001"), "protected registered Via preserved");
      check(first(message, "Security-Verify") != null, "Gm security agreement retained");
    }
    check(count("CANCEL") == 0, "normal precondition exchange never cancels locally");
    call.accept(response(call.initial, 487, "A", "", ""));
    check(count("CANCEL") == 0 && count("ACK") == 1, "remote 487 acknowledged without fabricated local cancellation");
    int ended = 0;
    for (Object event : call.sink.events) if (event.getClass().getName().equals("eb4")) {
      Object reason = get(event, "b");
      check(reason.getClass().getName().equals("ta4") && Integer.valueOf(487).equals(get(reason, "l")), "real 487 error code is not rewritten"); ended++;
    }
    check(ended == 1, "one final termination event");
    System.out.println("NORMAL tcp=" + tcp + " required=" + required + " update_require=" + option(update, "Require", "precondition"));
  }

  static void isolation() throws Exception {
    Call call = new Call(true);
    progress(call, "A", 1, true, "");
    prack200(call);
    check(count("UPDATE") == 0, "no SDP response cannot negotiate SDP confirmation");
    check(!option(update(call), "Require", "precondition"), "header-only provisional cannot add requirement");
    for (boolean differentTag : new boolean[] {false, true}) {
      call = new Call(true);
      progress(call, "A", 1, true, answer(true));
      progress(call, differentTag ? "B" : "A", differentTag ? 9 : 2, false, answer(true));
      prack200(call);
      Object message = parse(last("UPDATE"));
      check(!option(message, "Require", "precondition"), "new accepted SDP without requirement does not inherit old proof");
      check(first(message, "To").endsWith(";tag=" + (differentTag ? "B" : "A")), "current early dialog receives UPDATE");
    }
    call = new Call(true);
    progress(call, "A", 1, true, answer(true));
    call.accept(response(call.initial, 200, "A", answer(false), ""));
    check(get(call.dialog(), "D") != null, "native 200 establishes dialog");
    check(!option(update(call), "Require", "precondition"), "early-session rule does not change established refreshes");
  }

  /** Actual APK helper with native request objects; this case intentionally preloads other options. */
  static void optionPreservation() throws Exception {
    if (previous) return;
    Call call = new Call(true);
    progress(call, "A", 1, true, answer(true));
    Object request = update(call);
    List pairs = (List) get(request, "f");
    for (Iterator it = pairs.iterator(); it.hasNext();) {
      Object pair = it.next(); if ("Require".equalsIgnoreCase((String) get(pair, "T"))) it.remove();
    }
    SipForkProbe.header(request, "rEqUiRe", "sec-agree, TiMeR");
    Class<?> helper = Class.forName("cc.forserein.simhub.internal.SipEarlyPrecondition");
    Method decorate = helper.getMethod("decorate", Object.class, Object.class);
    decorate.invoke(null, call.dialog(), request);
    List<String> values = SipForkProbe.headers(request, "Require");
    check(option(request, "Require", "precondition") && option(request, "Require", "sec-agree") && option(request, "Require", "timer"), "negotiated option coexists with sec-agree and timer");
    String before = SipForkProbe.deep(request);
    decorate.invoke(null, call.dialog(), request);
    check(before.equals(SipForkProbe.deep(request)), "duplicate decorator call does not duplicate option or mutate message");
    check(values.toString().contains("sec-agree"), "other Require value retained");
  }

  public static void main(String[] args) throws Exception {
    previous = args.length > 0 && args[0].equals("previous-24-3");
    SipForkProbe.msg = Class.forName("kb4"); SipForkProbe.dialog = Class.forName("ma4");
    SipForkProbe.manager = Class.forName("cb4"); SipForkProbe.direction = Class.forName("ga4");
    SipForkProbe.state = Class.forName("la4");
    SipForkProbe.helper = Class.forName("cc.forserein.simhub.internal.SipForkProtection");
    normal(true, true); normal(true, false);
    for (String algorithm : new String[] {"aes-cbc", "null"}) {
      encryption = algorithm; normal(false, true); normal(false, false);
    }
    isolation(); optionPreservation();
    System.out.println("PRECONDITION_PROBE mode=" + (previous ? "previous-24-3" : "fixed")
        + " checks=" + checks + " protected_packets=" + protectedPackets + " no_network=true");
  }
}
