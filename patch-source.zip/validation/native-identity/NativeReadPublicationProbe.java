import java.lang.reflect.*;import java.util.*;import android.content.*;import cc.forserein.simhub.internal.*;
/** Resumes the real APK nl5 -> zl5.q from its last asynchronous phase. No APDU/network mock executes. */
public final class NativeReadPublicationProbe {
 static sun.misc.Unsafe unsafe;static int checks;static final List<String> logs=new ArrayList<>();
 static {try{Field f=sun.misc.Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);unsafe=(sun.misc.Unsafe)f.get(null);}catch(Exception e){throw new RuntimeException(e);}}
 public static void log(String s){logs.add(s);}
 static void check(boolean b,String message){if(!b)throw new AssertionError(message);checks++;}
 static Class<?> type(String n)throws Exception{return Class.forName(n);}
 static Object raw(String n)throws Exception{return unsafe.allocateInstance(type(n));}
 static Object get(Object o,String n)throws Exception{return o.getClass().getField(n).get(o);}
 static void set(Object o,String n,Object v)throws Exception{Field f=o.getClass().getField(n);f.setAccessible(true);f.set(o,v);}
 static void global(String n,Object v)throws Exception{Field f=type("zl5").getField(n);unsafe.putObject(unsafe.staticFieldBase(f),unsafe.staticFieldOffset(f),v);}
 static Object global(String n)throws Exception{return type("zl5").getField(n).get(null);}
 public static final class Ctx extends Context {
  public SharedPreferences getSharedPreferences(String name,int mode){return new SharedPreferences(){public String getString(String k,String f){return f;}public Editor edit(){return new Editor(){public Editor putString(String k,String v){return this;}public Editor remove(String k){return this;}public boolean commit(){return true;}};}};}
 }
 static Object transport()throws Exception{return Proxy.newProxyInstance(NativeReadPublicationProbe.class.getClassLoader(),new Class[]{type("qg0")},(o,m,args)->{if(m.getName().equals("hashCode"))return System.identityHashCode(o);if(m.getName().equals("equals"))return o==args[0];if(m.getName().equals("toString"))return "synthetic-reader";throw new AssertionError("No transport/APDU method should execute: "+m);});}
 static Object card(String id)throws Exception{return WifiConfigModel.constructor(type("ek5"),8).newInstance("204049876543210",id,2,null,null,null,null,null);}
 static Object state(Object card,Object config)throws Exception{return WifiConfigModel.constructor(type("gl5"),20).newInstance("SIM","synthetic",false,null,card,config,false,"","","490154203237518",type("tk5").getField("g").get(null),false,null,null,null,new ArrayList<>(),new ArrayList<>(),false,null,0L);}
 static Object continuation(Object manager,Object transport,Object auth,Object card,Object config)throws Exception{
 Object c=raw("nl5"),box=raw("t14");set(box,"T",config);set(c,"e0",manager);set(c,"W",transport);set(c,"X",auth);set(c,"Y",card);set(c,"Z",null);set(c,"a0","");set(c,"b0",box);set(c,"f0",3);return c;
 }
 public static void main(String[]args)throws Exception{
 boolean fixed=args[0].equals("fixed");android.content.res.AssetManager.root=java.nio.file.Paths.get(args[1]);global("f",new Ctx());Object manager=raw("zl5");global("a",manager);
 Object A=transport(),B=transport(),authA=raw("ac5"),authB=raw("ac5"),cardA=card("8912345678901234501"),cardB=card("8912345678901234502");Object configA=WifiConfigModel.builtIn(cardA),configB=WifiConfigModel.builtIn(cardB);
 Object stateB=state(cardB,configB),flow=type("rt4").getConstructor(Object.class).newInstance(stateB);global("b",flow);
 // A already passed the physical-read j==A check and suspended in config work.
 IdentityBinding.begin(A,authA);Object resumedA=continuation(manager,A,authA,cardA,configA);
 // B wins selection while A waits; the UI state now belongs to B.
 global("j",B);global("l",authB);IdentityBinding.begin(B,authB);
 check(global("j")==B&&global("l")==authB,"current auth belongs to B before A resumes");
 Object result=type("nl5").getMethod("q",Object.class).invoke(resumedA,Collections.emptyList());
 check(result==type("sc5").getField("a").get(null),"native continuation completes");Object observed=flow.getClass().getMethod("getValue").invoke(flow);
 boolean stale=get(observed,"e")==cardA;check(stale!=fixed,"cross-transport late native success overwrote B="+stale);
 check(global("j")==B&&global("l")==authB,"native selection/auth still B after A completion");
 System.out.println("ACTUAL_NATIVE_Q fixed="+fixed+" stale_A_overwrote_B="+stale+" checks="+checks+" completion_logs="+logs.size());
 // The real disconnect entry clears j/l/state, then the old continuation returns.
 IdentityBinding.begin(A,authA);global("j",A);global("l",authA);flow=type("rt4").getConstructor(Object.class).newInstance(state(cardA,configA));global("b",flow);
 Object disconnectedA=continuation(manager,A,authA,cardA,configA);
 type("zl5").getMethod("g").invoke(null);check(global("j")==null&&global("l")==null,"actual native disconnect clears selected transport/auth");
 check(get(flow.getClass().getMethod("getValue").invoke(flow),"e")==null,"actual native disconnect clears physical card");
 type("nl5").getMethod("q",Object.class).invoke(disconnectedA,Collections.emptyList());
 boolean resurrected=get(flow.getClass().getMethod("getValue").invoke(flow),"e")==cardA;
 check(resurrected!=fixed,"late success repopulated disconnected state="+resurrected);
 System.out.println("ACTUAL_NATIVE_DISCONNECT fixed="+fixed+" stale_card_resurrected="+resurrected+" checks="+checks);
 // Current success/error still complete, while already stale errors remain silent.
 Object error=type("o54").getConstructor(Throwable.class).newInstance(new IllegalStateException("synthetic config error"));
 for(boolean fail:new boolean[]{false,true}){
  IdentityBinding.begin(A,authA);global("j",A);global("l",authA);flow=type("rt4").getConstructor(Object.class).newInstance(stateB);global("b",flow);int before=logs.size();
  type("nl5").getMethod("q",Object.class).invoke(continuation(manager,A,authA,cardA,configA),fail?error:Collections.emptyList());
  Object value=flow.getClass().getMethod("getValue").invoke(flow);
  check(get(value,"e")== (fail?null:cardA),"current native result still publishes");
  check(get(value,"k").getClass().getName().equals(fail?"vk5":"tk5"),"current native phase remains correct");
  check(logs.size()==before+1,"current native result logged once");
 }
 for(boolean disconnect:new boolean[]{false,true}){
  IdentityBinding.begin(A,authA);global("j",A);global("l",authA);flow=type("rt4").getConstructor(Object.class).newInstance(stateB);global("b",flow);
  Object old=continuation(manager,A,authA,cardA,configA);
  if(disconnect)type("zl5").getMethod("g").invoke(null);else{global("j",B);global("l",authB);IdentityBinding.begin(B,authB);}
  Object before=flow.getClass().getMethod("getValue").invoke(flow);int count=logs.size();
  type("nl5").getMethod("q",Object.class).invoke(old,error);
  check(flow.getClass().getMethod("getValue").invoke(flow)==before,"late error cannot change switched/disconnected state");
  check(logs.size()==count,"late error does not report stale failure");
 }
 System.out.println("ACTUAL_NATIVE_READ_LIFECYCLE checks="+checks+" passed=true fixed="+fixed);
 }
}
