import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
/** JVM-only platform boundaries; leaves zl5.q/nl5.q/rt4/gl5/ac5 unchanged. */
public final class ReadPublicationAdapter {
 public static void main(String[] args)throws Exception{
 int count=0;try(ZipFile input=new ZipFile(args[0]);ZipOutputStream output=new ZipOutputStream(Files.newOutputStream(Paths.get(args[1])))){
 for(ZipEntry e:Collections.list(input.entries())){byte[] data=input.getInputStream(e).readAllBytes();
 if(e.getName().equals("zl5.class")||e.getName().equals("wn4.class")||e.getName().equals("qv4.class")){
 ClassNode c=new ClassNode();new ClassReader(data).accept(c,0);boolean touched=false;
 for(MethodNode m:c.methods){boolean init=(c.name.equals("zl5")||c.name.equals("qv4"))&&m.name.equals("<clinit>");boolean log=c.name.equals("zl5")&&m.name.equals("b")&&m.desc.equals("(Ljava/lang/String;)V");boolean imei=c.name.equals("wn4")&&m.name.equals("b")&&m.desc.equals("(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;");
 boolean text=c.name.equals("qv4")&&((m.name.equals("a")&&m.desc.equals("(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;"))||(m.name.equals("b")&&m.desc.equals("(Ljava/lang/String;)Ljava/lang/String;")));
 if(init||log||imei||text){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
 if(text){m.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));m.instructions.add(new InsnNode(Opcodes.ARETURN));m.maxStack=1;}else if(imei){m.instructions.add(new LdcInsnNode("490154203237518"));m.instructions.add(new InsnNode(Opcodes.ARETURN));m.maxStack=1;}else{if(log){m.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"NativeReadPublicationProbe","log","(Ljava/lang/String;)V",false));}m.instructions.add(new InsnNode(Opcodes.RETURN));m.maxStack=1;}
 touched=true;count++;}}
 if(touched){ClassWriter out=new ClassWriter(0);c.accept(out);data=out.toByteArray();}}
 output.putNextEntry(new ZipEntry(e.getName()));output.write(data);output.closeEntry();}}
 if(count!=6)throw new AssertionError("changed boundaries="+count);
 }
}
