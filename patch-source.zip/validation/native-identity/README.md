# Read publication regression

23.5 used a separate `latest auth` map per transport, although native Wi-Fi Calling uses one `zl5.b` state, one `zl5.j` selected transport and one `zl5.l` auth. `zl5.q` checks the selected transport after the physical read, then suspends twice during configuration work. An earlier transport's state-3 continuation could overwrite a newer card/config. The native `zl5.g()` disconnect also cleared the state but did not invalidate that continuation, allowing its card to reappear.

23.6 binds publication to the most recent transport/auth **instance pair**. `current`, `read`, `publish` and `publishError` reject every other pair. `invalidate()` runs before native `d` changes the selected transport and before `g` clears it. Each hook adds one static call without changing registers, branches, APDU, authentication, transport closing or profile enable/disable commands. Profile/provider metadata still comes from the original immutable per-read snapshot and full physical ICCID match.

This is ownership of one shared Wi-Fi Calling result, not a global APDU mutex and not a fix for physical cross-chip profile exclusion. All already-suspended native q states resume after its initial `begin` block; they cannot execute `begin` again. The initial selected-transport capture, auth construction and begin block has no coroutine suspension. The tests establish these normal coroutine paths, not arbitrary concurrent Java-thread execution of the entire native selection API.

## Run against a built APK

Run the existing native carrier check first, then:

```sh
python3 validation/native-identity/identity_check_runtime.py \
  build-config3/SIMHub-23.1-config3-unsigned.apk build-config3/apktool \
  --carrier-report build-config3/native-carrier-runtime.json \
  --report build-config3/native-identity-runtime.json
```

The checker rejects mismatched APK/JAR hashes and decoded assets. It consumes the same build's `native-carrier-current/probe.jar`, retaining the shipped IdentityBinding, native `nl5.q`, `zl5.q/g`, auth/model classes and actual `rt4` state flow. It seeds a synthetic state-3 continuation after the last config suspension, without invoking an APDU or modem. `--legacy` is only for reproducing both wrong outcomes on 23.5.

There are 17 assertions: late cross-transport success, real native disconnect followed by late success, current success/error behavior, and silent rejection of old errors after selection/disconnect. The host IdentityBinding suite separately checks wrong/authless pairs, CAS failures, selection metadata refresh, new generations when returning to the same transport, invalidation, provider evidence isolation and authentication guards.

The JVM adapter changes six environment boundaries only: manager initialization, log output, IMEI lookup, localization initialization and two localization lookup methods. It does not replace the q/g methods, native state/flow, or IdentityBinding. Native constructors are bypassed only to supply a suspended coroutine and auth without opening hardware. The carrier suite's existing Android API fixtures are copied without its fake zl5/ac5. DEX-to-JVM execution uses `-noverify` because the translation does not rebuild stack maps; the shipped DEX must still pass the separate DEX type check. This is not a physical-card, Android ART, network or real-carrier test.
