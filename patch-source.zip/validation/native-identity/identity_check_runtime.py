#!/usr/bin/env python3
"""Run the shipped read-publication lifecycle using this APK's carrier-verified JVM translation."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,zipfile
p=argparse.ArgumentParser()
p.add_argument('apk',type=Path);p.add_argument('decoded',type=Path)
p.add_argument('--carrier-report',type=Path,required=True)
p.add_argument('--report',type=Path,required=True);p.add_argument('--legacy',action='store_true')
a=p.parse_args();root=Path(__file__).resolve().parents[2];source=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
carrier=json.loads(a.carrier_report.read_text());base=a.carrier_report.parent/'native-carrier-current';jar=base/'probe.jar'
assert carrier['apk_sha256']==sha(a.apk),'Carrier report belongs to a different APK'
assert carrier['apk_translated_jar_sha256']==sha(jar),'Carrier JVM translation changed since its validation'
assert carrier['actual_apk_helpers_executed'] and not carrier['legacy_regression_reproduced'],'Need current-mode carrier translation'
assert not carrier.get('recognition_legacy_regression_reproduced',False),'Need current-mode carrier translation'
# The parser uses these files. Match every decoded asset to the actual APK before execution.
with zipfile.ZipFile(a.apk)as z:
 assets=[n for n in z.namelist()if n.startswith('assets/') and not n.endswith('/')]
 for n in assets:assert (a.decoded/n).read_bytes()==z.read(n),'Decoded asset differs from APK: '+n
work=a.report.parent/('native-identity-legacy'if a.legacy else'native-identity-current')
classes=work/'classes';fixtures=work/'android-fixtures';classes.mkdir(parents=True,exist_ok=True)
if fixtures.exists():shutil.rmtree(fixtures)
shutil.copytree(base/'classes/android',fixtures/'android')
assert not any(f.suffix=='.class' for f in fixtures.iterdir()),'Only Android API fixtures may override APK classes'
tools=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
lib=Path(os.environ.get('SIMHUB_DEX2JAR_TOOLS','/workspace/tools/dex2jar-v2.4'))/'dex-tools-v2.4/lib'
asm=os.pathsep.join(str(lib/n)for n in ['asm-9.5.jar','asm-tree-9.5.jar']);logs=[]
def run(*args):
 r=subprocess.run(list(map(str,args)),cwd=root,capture_output=True,text=True);logs.append(r.stdout+r.stderr)
 a.report.with_suffix('.log').write_text('\n'.join(logs))
 if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
 return r.stdout
run('java','-jar',tools/'ecj-3.40.0.jar','-17','-proc:none','-cp',asm,'-d',classes,source/'ReadPublicationAdapter.java')
adapted=work/'platform-adapted.jar'
run('java','-cp',str(classes)+os.pathsep+asm,'ReadPublicationAdapter',jar,adapted)
with zipfile.ZipFile(jar)as original,zipfile.ZipFile(adapted)as changed:
 assert set(original.namelist())==set(changed.namelist())
 modified=sorted(n for n in original.namelist()if original.read(n)!=changed.read(n))
 assert modified==['qv4.class','wn4.class','zl5.class'],modified
run('java','-jar',tools/'ecj-3.40.0.jar','-17','-proc:none','-cp',os.pathsep.join(map(str,[fixtures,jar])),'-d',classes,source/'NativeReadPublicationProbe.java')
assert not any((classes/n).exists()for n in ['zl5.class','nl5.class','rt4.class','gl5.class','ac5.class','cc/forserein/simhub/internal/IdentityBinding.class'])
out=run('java','-noverify','-cp',os.pathsep.join(map(str,[classes,fixtures,adapted,tools/'sdk/android-35/android.jar'])),'NativeReadPublicationProbe','legacy'if a.legacy else'fixed',a.decoded/'assets')
match=re.search(r'ACTUAL_NATIVE_READ_LIFECYCLE checks=(\d+) passed=true fixed=(true|false)',out)
assert match and (match[2]=='false')==a.legacy,out
report=dict(apk_sha256=sha(a.apk),apk_translated_jar_sha256=sha(jar),carrier_report_sha256=sha(a.carrier_report),checks=int(match[1]),legacy_regression_reproduced=a.legacy,
 native_read_continuation_executed=True,native_disconnect_executed=True,native_flow_and_state_models_executed=True,actual_apk_identity_helper_executed=True,
 native_q_g_method_instructions_unmodified_by_probe=True,synthetic_continuation_state=3,synthetic_identifiers=True,
 platform_boundaries_adapted=['zl5.<clinit>','zl5.b(String) log sink','wn4.b(Context,String) IMEI lookup','qv4.<clinit>','qv4.a(String,Object[]) localized text','qv4.b(String) localized text'],
 physical_read_or_apdu_executed=False,device_tested=False,art_execution=False,real_carrier_tested=False,
 source_sha256={f.name:sha(f)for f in source.glob('*.java')},android_fixture_sha256={str(f.relative_to(fixtures)):sha(f)for f in fixtures.rglob('*.class')},decoded_assets_verified=len(assets))
a.report.write_text(json.dumps(report,indent=2)+'\n');print(out.strip())
