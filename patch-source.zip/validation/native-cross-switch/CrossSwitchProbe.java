import java.lang.reflect.*;
import java.util.*;

/** Executes the APK's switch worker, per-chip cache updates, ES10c encoder and parser. */
public final class CrossSwitchProbe {
  static final String[] EID = {
    "89010000000000000000000000000001", "89010000000000000000000000000002"
  };
  static final String[] AID = {
    "A06573746B6D65FFFF4953442D522030", "A06573746B6D65FFFF4953442D522031"
  };
  static final String[] ICC = {"89123456789000100001", "89123456789000200002"};
  static final List<String> writes = new ArrayList<>();
  private static final String EXTRA_ICCID = "89123456789000200003";
  static boolean extraTargetPresent, extraTargetEnabled;
  static boolean[] enabled = new boolean[2];

  enum Fault {
    NONE,
    ALREADY_CLOSED_ON_WRITE,
    ALREADY_ENABLED_ON_WRITE,
    CODE_2_BUT_ENABLED,
    SOURCE_POLICY,
    TARGET_POLICY,
    SOURCE_REPLY_LOST,
    WRONG_SOURCE_EID,
    TAB_DURING_TARGET_WRITE,
    EID_CHANGED_AFTER_SOURCE_WRITE
  }

  static Fault fault = Fault.NONE;
  static iz3 controller;
  static final List<String> trace = new ArrayList<>();
  static int checks, opens, closes;

  private static Object raw(Class<?> c) throws Exception {
    Field u = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
    u.setAccessible(true);
    return ((sun.misc.Unsafe) u.get(null)).allocateInstance(c);
  }

  private static void field(Object o, String key, Object value) throws Exception {
    Field f = o.getClass().getField(key);
    f.setAccessible(true);
    f.set(o, value);
  }

  static void check(boolean condition, String label) {
    if (!condition) throw new AssertionError(label + " writes=" + writes);
    checks++;
  }

  static byte[] bytes(String h) {
    byte[] out = new byte[h.length() / 2];
    for (int i = 0; i < out.length; i++)
      out[i] = (byte) Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
    return out;
  }

  static String hex(byte[] b) {
    StringBuilder text = new StringBuilder();
    for (byte v : b) text.append(String.format(Locale.ROOT, "%02X", v));
    return text.toString();
  }

  static String tlv(String t, String v) {
    return t + String.format(Locale.ROOT, "%02X", v.length() / 2) + v;
  }

  static String bcd(String iccid) {
    StringBuilder b = new StringBuilder();
    for (int i = 0; i < iccid.length(); i += 2)
      b.append(iccid.charAt(i + 1)).append(iccid.charAt(i));
    return b.toString();
  }

  static qy3 profile(int chip, boolean active) {
    return new qy3(ICC[chip], active, "Test", null, null, null, null);
  }

  static String record(int chip) {
    String main = profileRecord(ICC[chip], enabled[chip]);
    return chip == 1 && extraTargetPresent
        ? main + profileRecord(EXTRA_ICCID, extraTargetEnabled)
        : main;
  }

  static String profileRecord(String iccid, boolean active) {
    return tlv("E3", tlv("5A", bcd(iccid)) + tlv("9F70", active ? "01" : "00"));
  }

  static byte[] transmit(int chip, byte[] apdu) {
    String command = hex(apdu);
    if (command.length() < 14 || !command.substring(2, 4).equals("E2"))
      throw new AssertionError("Unhandled synthetic APDU " + command);
    String op = command.substring(10, 14);
    String body;
    trace.add(chip + "/" + op);
    if (op.equals("BF3E")) {
      boolean wrongSource =
          chip == 0
              && (fault == Fault.WRONG_SOURCE_EID
                  || fault == Fault.EID_CHANGED_AFTER_SOURCE_WRITE && !enabled[0]);
      body = tlv("5A", EID[wrongSource ? 1 : chip]);
    } else if (op.equals("BF2D")) body = tlv("A0", record(chip));
    else if (op.equals("BF28")) body = tlv("A0", "");
    else if (op.equals("BF31") || op.equals("BF32")) {
      String id = tlv("5A", bcd(ICC[chip]));
      check(command.contains(id), "command ICCID belongs to addressed chip");
      boolean on = op.equals("BF31");
      if (chip == 1 && on && fault == Fault.TAB_DURING_TARGET_WRITE) controller.D(EID[0]);
      if (!on && fault == Fault.ALREADY_CLOSED_ON_WRITE) enabled[chip] = false;
      if (on && fault == Fault.ALREADY_ENABLED_ON_WRITE) enabled[chip] = true;
      int result = enabled[chip] == on ? 2 : 0;
      if (!on && fault == Fault.CODE_2_BUT_ENABLED) result = 2;
      if (!on && fault == Fault.SOURCE_POLICY || on && fault == Fault.TARGET_POLICY) result = 3;
      if (result == 0) {
        enabled[chip] = on;
        if (chip == 1 && on)
          extraTargetEnabled = false; // Same-chip activation replaces the old profile on-card.
      }
      writes.add((on ? "enable" : "disable") + chip + "=" + result);
      if (!on && fault == Fault.SOURCE_REPLY_LOST)
        throw new IllegalStateException("Synthetic reader lost the reply after updating its state");
      body = tlv("80", String.format(Locale.ROOT, "%02X", result));
    } else throw new AssertionError("Unhandled synthetic operation " + command);
    return bytes(tlv(op, body) + "9000");
  }

  /** Replace only the OS's open-logical-channel operation, retaining native vf1 transport. */
  public static vf1 open(hh1 manager, byte[] aid) {
    final int chip = Arrays.asList(AID).indexOf(hex(aid));
    if (chip < 0) throw new AssertionError("Unknown logical AID " + hex(aid));
    opens++;
    uz2 channel =
        (uz2)
            Proxy.newProxyInstance(
                CrossSwitchProbe.class.getClassLoader(),
                new Class[] {uz2.class},
                (o, m, a) -> {
                  switch (m.getName()) {
                    case "a":
                      return transmit(chip, (byte[]) a[0]);
                    case "b":
                      return true;
                    case "c":
                      return 1;
                    case "close":
                      closes++;
                      return null;
                    default:
                      throw new AssertionError(m.toString());
                  }
                });
    return new vf1(manager, channel, manager.a);
  }

  static iz3 setup(boolean first, boolean second, boolean uiFirst, boolean uiSecond)
      throws Exception {
    writes.clear();
    trace.clear();
    fault = Fault.NONE;
    extraTargetPresent = false;
    extraTargetEnabled = false;
    opens = 0;
    closes = 0;
    enabled = new boolean[] {first, second};
    s4 reader =
        (s4)
            Proxy.newProxyInstance(
                CrossSwitchProbe.class.getClassLoader(),
                new Class[] {s4.class},
                (o, m, a) -> {
                  switch (m.getName()) {
                    case "a":
                      return 240;
                    case "f":
                      return true;
                    case "g":
                      return "Synthetic dual reader";
                    case "hashCode":
                      return System.identityHashCode(o);
                    case "equals":
                      return o == a[0];
                    case "toString":
                      return "Synthetic dual reader";
                    default:
                      throw new AssertionError(m.toString());
                  }
                });
    iz3 c = (iz3) raw(iz3.class);
    hh1 manager = (hh1) raw(hh1.class);
    field(manager, "a", reader);
    field(manager, "k", Collections.emptyMap());
    field(manager, "l", new Object());
    c.d = manager;
    for (Field f : iz3.class.getFields())
      if (f.getType() == xl3.class) field(c, f.getName(), qd2.D(null));
    c.c.setValue(reader);
    List<xx3> chips = new ArrayList<>();
    chips.add(
        new xx3(
            bytes(AID[0]),
            EID[0],
            null,
            Collections.singletonList(profile(0, uiFirst)),
            null,
            null));
    chips.add(
        new xx3(
            bytes(AID[1]),
            EID[1],
            null,
            Collections.singletonList(profile(1, uiSecond)),
            null,
            null));
    c.k.setValue(chips);
    c.D(EID[0]);
    controller = c;
    return c;
  }

  static Object tap(iz3 c, int chip, boolean turnOn, String entry) throws Exception {
    c.D(EID[chip]);
    qy3 target = (qy3) ((xx3) c.l().get(chip)).d.get(0);
    Class<?> action = Class.forName(entry);
    Object frame =
        action
            .getConstructor(iz3.class, qy3.class, boolean.class, ct0.class)
            .newInstance(c, target, turnOn, null);
    ct0 completion =
        new ct0() {
          public fu0 h() {
            return qd1.T;
          }

          public void s(Object value) {
            throw new AssertionError("unexpected asynchronous completion");
          }
        };
    try {
      return action.getMethod("f", Object.class, Object.class).invoke(frame, c.d, completion);
    } catch (InvocationTargetException ex) {
      Throwable cause = ex.getCause();
      if (cause instanceof Exception) throw (Exception) cause;
      throw (Error) cause;
    }
  }

  static boolean cached(iz3 c, int chip) {
    return ((qy3) ((xx3) c.l().get(chip)).d.get(0)).b;
  }

  private static boolean attempt(iz3 c, int chip, boolean on, String entry) throws Exception {
    try {
      tap(c, chip, on, entry);
      return true;
    } catch (ze0 | IllegalStateException rejected) {
      return false;
    }
  }

  private static void failureAndRaceScenarios(String entry) throws Exception {
    // An independent switcher closes the source between preflight and command.
    iz3 c = setup(true, true, true, true);
    fault = Fault.ALREADY_CLOSED_ON_WRITE;
    check(
        attempt(c, 0, false, entry),
        "native code 2 reconciles only after original chip reports disabled");
    check(
        writes.equals(Arrays.asList("disable0=2")) && !cached(c, 0) && enabled[1],
        "no rewrite or mutation on the other chip");
    check(opens == closes, "code 2 releases logical channels");
    c = setup(true, false, true, false);
    fault = Fault.CODE_2_BUT_ENABLED;
    check(!attempt(c, 1, true, entry), "contradictory code 2 on source stops the switch");
    check(
        writes.equals(Arrays.asList("disable0=2")) && enabled[0] && !enabled[1],
        "target untouched while source remains enabled");
    c = setup(false, false, false, false);
    fault = Fault.ALREADY_ENABLED_ON_WRITE;
    check(
        attempt(c, 1, true, entry),
        "enable result 2 accepted only with same-chip enabled readback");
    check(
        writes.equals(Arrays.asList("enable1=2")) && enabled[1] && cached(c, 1),
        "already-enabled target does not get another enable command");
    c = setup(false, false, false, false);
    extraTargetPresent = true;
    extraTargetEnabled = true;
    check(attempt(c, 1, true, entry), "switch to a different profile on the same eUICC");
    check(
        writes.equals(Arrays.asList("enable1=0")) && !extraTargetEnabled && cached(c, 1),
        "same-chip owner performs the replacement");
    check(
        !((qy3) ((xx3) c.l().get(1)).d.get(1)).b,
        "previous same-chip profile shown disabled in fresh list");
    c = setup(true, false, true, false);
    fault = Fault.SOURCE_POLICY;
    check(!attempt(c, 1, true, entry), "real card policy rejection propagates");
    check(
        writes.equals(Arrays.asList("disable0=3")) && enabled[0] && !enabled[1],
        "policy error is not retried");
    c = setup(true, false, true, false);
    fault = Fault.TARGET_POLICY;
    check(!attempt(c, 1, true, entry), "target failure is visible after source was disabled");
    check(!enabled[1] && !cached(c, 1), "failed target is never shown as enabled");
    check(
        !enabled[0] && !cached(c, 0),
        "confirmed source disable is retained after target rejection");
    fault = Fault.NONE;
    writes.clear();
    check(
        attempt(c, 1, true, entry) && writes.equals(Arrays.asList("enable1=0")),
        "an explicit retry resumes from the actual per-chip states");
    c = setup(true, false, true, false);
    fault = Fault.SOURCE_REPLY_LOST;
    check(!attempt(c, 1, true, entry), "uncertain write fails the transaction");
    check(
        writes.equals(Arrays.asList("disable0=0")) && !enabled[1],
        "lost reply never causes another write");
    fault = Fault.NONE;
    writes.clear();
    check(
        attempt(c, 0, false, entry) && writes.isEmpty() && !cached(c, 0),
        "next manual off recovers actual state using reads only");
    c = setup(true, false, true, false);
    fault = Fault.WRONG_SOURCE_EID;
    check(!attempt(c, 1, true, entry), "wrong physical EID rejected");
    check(writes.isEmpty() && enabled[0] && !enabled[1], "no mutation on wrong EID");
    c = setup(true, false, false, false);
    check(attempt(c, 1, true, entry), "cold stale chip summaries do not hide enabled source");
    check(
        writes.equals(Arrays.asList("disable0=0", "enable1=0")) && !cached(c, 0) && cached(c, 1),
        "plan used fresh lists for both chips");
    c = setup(true, false, true, false);
    fault = Fault.TAB_DURING_TARGET_WRITE;
    tap(c, 1, true, entry);
    check(
        EID[0].equals(c.r()) && !((qy3) c.q().get(0)).b,
        "tab changed during I/O still displays the selected source list");
    check(cached(c, 1) && !cached(c, 0), "late target readback goes into target chip only");
    c = setup(true, false, true, false);
    fault = Fault.EID_CHANGED_AFTER_SOURCE_WRITE;
    check(
        !attempt(c, 1, true, entry),
        "changed endpoint identity during confirmation stops the switch");
    check(
        writes.equals(Arrays.asList("disable0=0")) && !enabled[1],
        "unconfirmed source never enables target");
    c = setup(true, true, true, true);
    check(attempt(c, 0, false, entry), "already-dual-enabled state can be repaired via normal off");
    check(
        writes.equals(Arrays.asList("disable0=0")) && !cached(c, 0) && cached(c, 1),
        "manual off only targets selected chip");
  }

  public static void main(String[] args) throws Exception {
    boolean legacy = args[0].equals("legacy");
    String entry = args[1];
    iz3 c = setup(true, false, true, false);
    Object result = tap(c, 1, true, entry);
    check(result == sc5.a, "worker completes after hardware readback");
    check(enabled[1], "target becomes enabled");
    check(enabled[0] == legacy, "previous physical profile state");
    check(cached(c, 0) == legacy && cached(c, 1), "real controller cache matches card state");
    check(opens == closes, "all logical channels released");
    List<String> forward = new ArrayList<>(writes), forwardTrace = new ArrayList<>(trace);
    if (legacy) check(writes.equals(Arrays.asList("enable1=0")), "legacy only enables B");
    else {
      check(
          writes.equals(Arrays.asList("disable0=0", "enable1=0")), "source disabled before target");
      writes.clear();
      tap(c, 0, true, entry);
      check(
          writes.equals(Arrays.asList("disable1=0", "enable0=0")) && enabled[0] && !enabled[1],
          "reverse switch");
      check(cached(c, 0) && !cached(c, 1), "both chip snapshots published after reverse switch");
    }
    c = setup(false, true, true, true);
    Throwable failure = null;
    try {
      tap(c, 0, false, entry);
    } catch (Exception e) {
      failure = e;
    }
    if (legacy) {
      check(
          failure != null && writes.equals(Arrays.asList("disable0=2")),
          "old manual disable returns documented code 2");
      check(cached(c, 0), "old UI still marks disabled profile enabled after code 2");
    } else {
      check(failure == null && !cached(c, 0), "manual stale disable reconciles from card");
      check(enabled[1] && cached(c, 1), "manual disable leaves other active card alone");
    }
    check(opens == closes, "manual off releases channels");
    List<String> manual = new ArrayList<>(writes);
    if (!legacy) {
      int disabledAt = forwardTrace.indexOf("0/BF32"), enabledAt = forwardTrace.indexOf("1/BF31");
      check(
          disabledAt >= 0
              && enabledAt > disabledAt
              && forwardTrace.subList(disabledAt + 1, enabledAt).contains("0/BF2D"),
          "card-level source list confirmed between disable and target enable");
      failureAndRaceScenarios(entry);
    }
    System.out.println(
        "CROSS_SWITCH mode="
            + args[0]
            + " checks="
            + checks
            + " forward="
            + forward
            + " manual="
            + manual
            + " forward_trace="
            + forwardTrace);
  }
}
