# Dual-chip profile-switch regression

The test runs the APK’s `hz3.f` switch operation, native `iz3` controller, profile and per-chip models, and ES10c command encoding and result parsing. Two synthetic chips expose the eSTK SE0/SE1 management AIDs. Each chip has its own profile state. The synthetic reader accepts only the EID, profile-list, notification-list and profile enable/disable commands used by these tests.

On the JVM the fixture adapts the logical channel factory `hh1.x` to return a normal `vf1` bound to the addressed synthetic chip. The dispatcher and delays run synchronously. Resource lookups return message keys. The probe initializes the reader/controller state directly, as if discovery had just finished. Actual `hz3`, `iz3`, `pg1`, `vf1`, the native parser and all eSTK coordinator classes retain their APK method implementations. The tests use the carrier probe's constructor-normalized DEX translation. Real Android scheduling, modem refresh and card behavior require separate device testing.

The 23.9 regression demonstrates two independent cases. Enabling a profile on chip 1 sends only `BF31` to that chip and leaves chip 0 physically enabled. If chip 0 has already disabled the profile but its UI snapshot remains green, manually disabling it returns `BF32` result 2 and the snapshot stays green.

Run this after the existing native carrier probe, using the same APK.

```sh
python3 validation/native-cross-switch/check_runtime.py "$APK" \
  --carrier-report "$BUILD/native-carrier-runtime.json" \
  --report "$BUILD/native-cross-switch-runtime.json"
```

For the 23.9 negative control use `--legacy`. For the signed APK use `--unsigned-apk` with the corresponding carrier-tested unsigned artifact. The runner checks that every DEX entry is identical between the two APKs and that the translated JAR belongs to that build.
