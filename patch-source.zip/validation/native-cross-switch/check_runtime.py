#!/usr/bin/env python3
"""Run the actual APK switch, card-command serializer/parser and cache on a synthetic dual reader."""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, tempfile, zipfile

source = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('apk', type=Path)
p.add_argument('--carrier-report', type=Path, required=True)
p.add_argument('--jar', type=Path, help='defaults to the validated carrier translation alongside the report')
p.add_argument('--unsigned-apk', type=Path, help='byte-for-byte DEX comparison when validating a signed release')
p.add_argument('--report', type=Path, required=True)
p.add_argument('--legacy', action='store_true')
a = p.parse_args()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
carrier = json.loads(a.carrier_report.read_text())
jar = a.jar or a.carrier_report.parent / 'native-carrier-current' / 'probe.jar'
unsigned = a.unsigned_apk or a.apk
assert sha(unsigned) == carrier['apk_sha256']
assert sha(jar) == carrier['apk_translated_jar_sha256']
with zipfile.ZipFile(unsigned) as original, zipfile.ZipFile(a.apk) as tested:
    dexes = {n for n in tested.namelist() if re.fullmatch(r'classes\d*\.dex', n)}
    assert dexes and dexes == {n for n in original.namelist() if re.fullmatch(r'classes\d*\.dex', n)}
    dex_sha256 = {}
    for name in dexes:
        data = tested.read(name)
        assert original.read(name) == data
        dex_sha256[name] = hashlib.sha256(data).hexdigest()

a.report.parent.mkdir(parents=True,exist_ok=True)
kit = Path(os.getenv('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
lib = Path(os.getenv('SIMHUB_DEX2JAR_TOOLS','/workspace/tools/dex2jar-v2.4'))/'dex-tools-v2.4/lib'
asm = os.pathsep.join(str(lib / n) for n in ('asm-9.5.jar','asm-tree-9.5.jar'))
logs = []
def run(*args):
    r = subprocess.run(list(map(str,args)),capture_output=True,text=True)
    logs.append(r.stdout+r.stderr)
    a.report.with_suffix('.log').write_text('\n'.join(logs))
    if r.returncode:
        print(logs[-1]);raise SystemExit(r.returncode)
    return r.stdout
with tempfile.TemporaryDirectory(dir=a.report.parent, prefix='cross-switch-') as work:
    classes = Path(work)/'classes';classes.mkdir()
    run('java','-jar',kit/'ecj-3.40.0.jar','-17','-cp',asm,'-d',classes,source/'CrossSwitchAdapter.java')
    adapted = Path(work)/'fixture.jar'
    run('java','-cp',str(classes)+os.pathsep+asm,'CrossSwitchAdapter',jar,adapted)
    with zipfile.ZipFile(jar) as original, zipfile.ZipFile(adapted) as changed:
        assert set(original.namelist()) == set(changed.namelist())
        modified = sorted(n for n in original.namelist() if original.read(n) != changed.read(n))
        assert modified == ['g7.class','hh1.class','qv4.class','xq0.class']
        method_classes=['hz3','iz3','pg1','ng1','vf1','if1','qy3','xx3','rf1']
        if not a.legacy:
            method_classes+=['cc/forserein/simhub/internal/EstkSwitchPlan','InternalEstkSwitch','InternalEstkAccess']
        for name in method_classes:assert original.read(name+'.class')==changed.read(name+'.class')
    cp=os.pathsep.join(map(str,[adapted,kit/'sdk/android-35/android.jar']))
    run('java','-jar',kit/'ecj-3.40.0.jar','-8','-warn:none','-cp',cp,'-d',classes,source/'CrossSwitchProbe.java')
    assert all(f.stem.startswith(('CrossSwitchProbe','CrossSwitchAdapter')) for f in classes.rglob('*.class'))
    out=run('java','-noverify','-cp',str(classes)+os.pathsep+cp,'CrossSwitchProbe','legacy' if a.legacy else 'fixed','hz3')
match=re.search(r'CROSS_SWITCH mode=(legacy|fixed) checks=(\d+) forward=(\[[^]]*\]) manual=(\[[^]]*\]) forward_trace=(\[[^]]*\])',out)
assert match and (match[1]=='legacy')==a.legacy,out
report=dict(apk_sha256=sha(a.apk),carrier_report_sha256=sha(a.carrier_report),native_jar_sha256=sha(jar),dex_sha256=dex_sha256,
            mode=match[1],checks=int(match[2]),forward_write_sequence=match[3],stale_manual_disable_sequence=match[4],forward_es10c_trace=match[5],
            actual_switch_worker_and_per_chip_cache=True,actual_es10c_encoder_parser=True,synthetic_logical_channels_at_hh1_x=True,
            scheduler_and_delays_synchronous=True,resource_localization_stub=True,physical_card_tested=False,android_art_tested=False,
            translated_dex_jvm_verification_disabled=True,exact_unchanged_tested_classes=method_classes,
            fixture_sources={p.name:sha(p) for p in source.glob('*.java')})
a.report.write_text(json.dumps(report,indent=2)+'\n');print(out.strip())
