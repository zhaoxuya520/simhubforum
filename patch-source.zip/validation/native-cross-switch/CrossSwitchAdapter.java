import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** JVM-only logical channel factory, virtual scheduler and Android string resources. */
public final class CrossSwitchAdapter implements Opcodes {
  private static void load(MethodNode m, int... slots) {
    for (int i : slots) m.instructions.add(new VarInsnNode(ALOAD, i));
  }

  private static void call(
      MethodNode m, String owner, String name, String signature, boolean iface) {
    m.instructions.add(
        new MethodInsnNode(iface ? INVOKEINTERFACE : INVOKESTATIC, owner, name, signature, iface));
  }

  private static boolean adapt(String name, MethodNode m) {
    String key = name + "." + m.name + m.desc;
    List<String> boundaries =
        Arrays.asList(
            "hh1.x([BLdt0;)Ljava/lang/Object;",
            "hh1.s(Lws1;Ldt0;)Ljava/lang/Object;",
            "xq0.g0(Lfu0;Lkt1;Lct0;)Ljava/lang/Object;",
            "g7.J(JLct0;)Ljava/lang/Object;",
            "qv4.<clinit>()V",
            "qv4.a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;",
            "qv4.b(Ljava/lang/String;)Ljava/lang/String;");
    if (!boundaries.contains(key)) return false;
    m.instructions.clear();
    m.tryCatchBlocks.clear();
    m.localVariables = null;
    if (key.startsWith("hh1.x")) {
      load(m, 0, 1);
      call(m, "CrossSwitchProbe", "open", "(Lhh1;[B)Lvf1;", false);
    } else if (key.startsWith("hh1.s")) {
      load(m, 0, 1);
      call(m, "ws1", "i", "(Ljava/lang/Object;)Ljava/lang/Object;", true);
    } else if (key.startsWith("xq0.g0")) {
      load(m, 1);
      m.instructions.add(new InsnNode(ACONST_NULL));
      load(m, 2);
      call(m, "kt1", "f", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", true);
    } else if (key.startsWith("g7.J"))
      m.instructions.add(new FieldInsnNode(GETSTATIC, "sc5", "a", "Lsc5;"));
    else if (m.name.equals("<clinit>")) {
      m.instructions.add(new InsnNode(RETURN));
      return true;
    } else load(m, 0);
    m.instructions.add(new InsnNode(ARETURN));
    m.maxStack = 4;
    return true;
  }

  public static void main(String[] args) throws Exception {
    int count = 0;
    try (ZipFile input = new ZipFile(args[0]);
        ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(Paths.get(args[1])))) {
      for (ZipEntry e : Collections.list(input.entries())) {
        byte[] data = input.getInputStream(e).readAllBytes();
        if (Arrays.asList("hh1.class", "xq0.class", "g7.class", "qv4.class")
            .contains(e.getName())) {
          ClassNode cl = new ClassNode();
          new ClassReader(data).accept(cl, 0);
          for (MethodNode m : cl.methods) if (adapt(cl.name, m)) count++;
          ClassWriter writer = new ClassWriter(0);
          cl.accept(writer);
          data = writer.toByteArray();
        }
        output.putNextEntry(new ZipEntry(e.getName()));
        output.write(data);
        output.closeEntry();
      }
    }
    if (count != 7) throw new AssertionError("Unexpected adapted method count " + count);
  }
}
