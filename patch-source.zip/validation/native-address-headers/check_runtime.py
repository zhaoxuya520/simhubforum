#!/usr/bin/env python3
"""Exercise incoming IMS registration headers and outgoing BASE calls in the APK under test."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

here = Path(__file__).resolve().parent
validation = here.parent
project = validation.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('apk', type=Path)
parser.add_argument('--carrier-report', required=True, type=Path)
parser.add_argument('--report', required=True, type=Path)
parser.add_argument('--unsigned-apk', type=Path)
parser.add_argument('--jar', type=Path)
parser.add_argument('--previous-24-9', action='store_true')
args = parser.parse_args()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


jar = args.jar or args.carrier_report.parent / 'native-carrier-current/probe.jar'
unsigned = args.unsigned_apk or args.apk
carrier = json.loads(args.carrier_report.read_text())
assert carrier['apk_sha256'] == digest(unsigned)
assert carrier['apk_translated_jar_sha256'] == digest(jar)
with zipfile.ZipFile(args.apk) as signed, zipfile.ZipFile(unsigned) as verified:
    entries = ['classes.dex', 'assets/vowifi/carrier_presets.json', 'assets/vowifi/global_standard_catalogue.json']
    for name in entries:
        assert signed.read(name) == verified.read(name), name

tools = Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery'))
ecj = tools / 'ecj-3.40.0.jar'
sdk = tools / 'sdk/android-35/android.jar'
asm_lib = Path(os.environ.get('SIMHUB_DEX2JAR_TOOLS', '/workspace/tools/dex2jar-v2.4')) / 'dex-tools-v2.4/lib'
asm = os.pathsep.join(str(asm_lib / name) for name in ('asm-9.5.jar', 'asm-tree-9.5.jar'))
log = []
args.report.parent.mkdir(parents=True, exist_ok=True)


def run(*command):
    result = subprocess.run(list(map(str, command)), text=True, capture_output=True)
    log.append(result.stdout + result.stderr)
    args.report.with_suffix('.log').write_text('\n'.join(log))
    if result.returncode:
        raise RuntimeError(log[-1])
    return result.stdout


with tempfile.TemporaryDirectory(dir=args.report.parent) as tmp:
    work = Path(tmp)
    register = work / 'register'
    call = work / 'call'
    register.mkdir()
    call.mkdir()
    reg_source = validation / 'native-registration'
    compile = ['java', '-jar', ecj, '-warn:none', '-proc:none']
    reg_classpath = os.pathsep.join(map(str, [register, jar, sdk]))
    run(*compile, '-8', '-cp', reg_classpath, '-d', register, *sorted(reg_source.glob('*.java')), here / 'RegisterAddressProbe.java')
    mode = 'previous' if args.previous_24_9 else 'current'
    output = run('java', '-noverify', '-cp', reg_classpath, 'RegisterAddressProbe', mode)
    identities = dict((case, values.split()) for case, values in re.findall(r'^ASSOCIATED (\w+) (.+)$', output, re.M))
    assert len(identities) == 3
    checks = int(re.search(r'REGISTER_ADDRESS_CHECKS (\d+)', output)[1])

    ct = validation / 'native-ctexcel-call'
    sources = [ct / 'CtExcelTransportAdapter.java', ct / 'CtExcelOriginationProbe.java',
               validation / 'native-preconditions/PreconditionProbe.java', validation / 'native-fork/SipForkProbe.java',
               validation / 'native-fork/g11.java', validation / 'native-invite-failure/t00.java',
               validation / 'native-carrier/AssetManager.java', validation / 'native-carrier/Context.java',
               project / 'tests/android/content/SharedPreferences.java', project / 'tests/android/util/Log.java',
               validation / 'native-diagnostics/android/os/Looper.java', validation / 'native-diagnostics/android/os/Handler.java',
               here / 'AddressInviteProbe.java']
    run(*compile, '-17', '-cp', asm, '-d', call, *sources)
    adapted = work / 'capture.jar'
    run('java', '-cp', os.pathsep.join(map(str, [call, asm])), 'CtExcelTransportAdapter', jar, adapted)
    with zipfile.ZipFile(args.apk) as supplied:
        for asset in entries[1:]:
            supplied.extract(asset, work)
    for case, values in identities.items():
        expected = 'sip:alias@ims.example.test' if args.previous_24_9 and case != 'canonical' else 'tel:+3225550101'
        captured = run('java', '-noverify', '-cp', os.pathsep.join(map(str, [call, adapted, sdk])),
                       'AddressInviteProbe', work / 'assets', case, expected, *values)
        checks += int(re.search(r'INVITE_ADDRESS_CHECKS (\d+)', captured)[1])

args.report.write_text(json.dumps({
    'apk_sha256': digest(args.apk), 'normalized_apk_jar_sha256': digest(jar), 'previous_24_9': args.previous_24_9,
    'checks': checks, 'registered_public_identities': identities, 'uses_native_registration_parser_and_binding': True,
    'uses_native_BASE_registration_identity_selection_and_INVITE': True, 'fields_checked': ['From', 'P-Preferred-Identity', 'Service-Route'],
    'physical_SIM_or_network_tested': False,
    'boundaries': ['synthetic REGISTER response delivered to native continuation', 'registered URI list carried to call fixture',
                   'native serialized INVITE captured at transport boundary'],
}, indent=2) + '\n')
print(f'BASE registration / INVITE: {checks} checks passed ({mode})')
