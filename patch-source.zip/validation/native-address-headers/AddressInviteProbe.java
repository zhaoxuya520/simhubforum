import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

public final class AddressInviteProbe {
    public static void main(String[] args) throws Exception {
        SipForkProbe.msg = Class.forName("kb4");
        SipForkProbe.dialog = Class.forName("ma4");
        SipForkProbe.manager = Class.forName("cb4");
        SipForkProbe.direction = Class.forName("ga4");
        SipForkProbe.state = Class.forName("la4");
        SipForkProbe.helper = Class.forName("cc.forserein.simhub.internal.SipForkProtection");
        android.content.res.AssetManager.root = Paths.get(args[0]);
        Class.forName("fj5").getField("d").set(null, new android.content.Context());
        List<String> identities = Arrays.asList(args).subList(3, args.length);
        CtExcelOriginationProbe.verify("BASE-" + args[1], "20620", identities, "+49305550123",
                "tel:+49305550123", args[2], false, true);
        System.out.println("INVITE_ADDRESS_CHECKS " + CtExcelOriginationProbe.checks);
    }
}
