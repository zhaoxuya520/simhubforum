import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Parse REGISTER 200 from wire and resume the APK's registration coroutine at its response boundary. */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class RegisterAddressProbe {
    static final String ALIAS = "sip:alias@ims.example.test";
    static final String TEL = "tel:+3225550101";
    static final String SIP = "sip:other@ims.example.test";
    static final String FIRST = "<sip:pcscf.example.test;lr>";
    static final String SECOND = "<sip:scscf.example.test;lr>";
    static final String THIRD = "<sip:app.example.test;lr>";
    static int checks;
    static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
        checks++;
    }
    static kb4 parse(String headers) {
        String wire = "SIP/2.0 200 OK\r\n" + headers + "Content-Length: 0\r\n\r\n";
        return jb4.c(wire.getBytes(StandardCharsets.UTF_8));
    }
    static void registration(boolean baseline, String name, String header) throws Exception {
        String fields = header + "\r\nP-Associated-URI: <" + SIP + ">\r\n"
                + "service-route: " + FIRST + ", " + SECOND + "\r\n"
                + "Service-Route: " + THIRD + "\r\nExpires: 1200\r\n";
        kb4 response = parse(fields);
        o82 engine = NativeRegistrationProbe.session();
        j82 task = new j82(engine, null);
        NativeRegistrationProbe.set(task, "U", qd1.T);
        task.m0 = 3;
        task.e0 = new byte[0];
        task.f0 = new byte[0];
        task.g0 = new byte[0];
        Object binding = task.q(response);
        check(binding == engine.s, name + " returned active IMS binding");
        boolean joined = !name.equals("canonical");
        List<String> expected = baseline && joined ? Arrays.asList(ALIAS, SIP) : Arrays.asList(ALIAS, TEL, SIP);
        check(expected.equals(engine.s.a), name + " identities " + engine.s.a);
        check((baseline ? Arrays.asList(FIRST + ", " + SECOND, THIRD) : Arrays.asList(FIRST, SECOND, THIRD))
                .equals(engine.s.e), name + " registered service route order " + engine.s.e);
        System.out.println("ASSOCIATED " + name + " " + String.join(" ", (List<String>) engine.s.a));
    }
    static void addressLists() {
        String display = "\"East, \\\"West\\\"\" <sip:a@example.test>, <sip:b@example.test>";
        String uriComma = "<sip:a,b@example.test>, <sip:c@example.test>";
        String[] names = {"P-Associated-URI", "service-route", "ReCoRd-RoUtE", "Route", "m", "M"};
        for (String name : names) {
            String canonical = name.equalsIgnoreCase("m") ? "Contact" : name;
            List values = parse(name + ": " + display + "\r\n" + name + ": " + uriComma + "\r\n").j(canonical);
            check(values.equals(Arrays.asList("\"East, \\\"West\\\"\" <sip:a@example.test>", "<sip:b@example.test>",
                    "<sip:a,b@example.test>", "<sip:c@example.test>")), "retain order and protected commas for " + name + " " + values);
            String malformed = "<sip:good@example.test>, \"unterminated, address";
            check(parse(name + ": " + malformed + "\r\n").j(canonical).equals(Collections.singletonList(malformed)),
                    "no partial routing on a broken list " + name);
        }
        check(parse("User-Agent: phone, simulator\r\n").j("User-Agent")
                .equals(Collections.singletonList("phone, simulator")), "unrelated headers untouched");
    }
    public static void main(String[] args) throws Exception {
        boolean baseline = args[0].equals("previous");
        registration(baseline, "lowercase", "p-associated-uri: <" + ALIAS + ">, <" + TEL + ">");
        registration(baseline, "quoted", "P-Associated-URI: \"West, Team\" <" + ALIAS + ">, <" + TEL + ">");
        registration(baseline, "canonical", "P-Associated-URI: <" + ALIAS + ">, <" + TEL + ">");
        if (!baseline) addressLists();
        System.out.println("REGISTER_ADDRESS_CHECKS " + checks);
    }
}
