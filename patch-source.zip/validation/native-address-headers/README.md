# BASE 注册身份与外呼验证

此用例把合成的 SIP REGISTER 200 响应交给 APK 的 SIP 解析器和注册协程。用例将注册协程实际保存的公开身份列表传入外呼测试，在 BASE 模板（PLMN 20620）下拨同一个 +49 测试号码，检查序列化 INVITE 的 From 和 P-Preferred-Identity。三个响应分别覆盖规范拼写、小写头名及带引号的显示名。额外检查覆盖重复行的顺序、带逗号的 URI、转义引号、紧凑形式 Contact 和损坏的列表。

使用构建生成的原生验证报告及其中记录的转换 JAR。以下命令从 phone-slot-patch 目录运行，四个环境变量指向对应的 Android 安装包、已验证的未签名包、原生验证报告和输出目录。

```bash
python validation/native-address-headers/check_runtime.py "$apk" \
    --unsigned-apk "$unsigned_apk" --carrier-report "$carrier_report" \
    --report "$report_dir/signed-base-registration-headers.json"
```

复现旧版时传入 24.9 对应的文件并追加 `--previous-24-9`。若验证 JAR 独立存储，使用 `--jar` 指定文件。脚本核验包内 DEX、运营商资产与 JAR 摘要。注册刷新调度、SIM、网络套接字和系统音频使用测试替身，测试期间不会连接运营商。

列表处理遵循 SIP 头域大小写与列表顺序、引号及 name-addr 语法。P-Associated-URI 与 Service-Route 的标准分别规定了每项地址的含义。[RFC 3261 §§ 7.3.1、12、25.1](https://www.rfc-editor.org/rfc/rfc3261.html) · [RFC 3455 § 4.1](https://www.rfc-editor.org/rfc/rfc3455.html#section-4.1) · [RFC 3608 § 6](https://www.rfc-editor.org/rfc/rfc3608.html#section-6)
