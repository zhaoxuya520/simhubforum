# Wi-Fi 通话配置与身份审查

基线：23.2；日期：2026-11-17。此次只读审查未发现新增可复现故障，未修改配置逻辑、身份逻辑或界面。“未发现”不等于没有其他问题。

检查范围：`WifiConfigRuntime`、`WifiConfigValues`、`WifiConfigModel`、`WifiConfigDraft`、`WifiConfigPresentation`、`WifiConfigListDraft`、`CarrierPresets`、`DitoCarrierProfile`、`DitoHomeIdentity`、`IdentityBinding`，以及原生读卡与配置构造的衔接。

- 检查保存、重置、多条 ePDG/SMSC、保存失败回滚和过期页面覆盖保护。
- 检查手动运营商替换、自动恢复、原生 ISIM 策略、SMSC 来源与真实卡片身份的区分。
- 检查换卡缓存失效、DITO 同卡真实归属身份恢复、旧配置迁移及缺失身份时的连接拦截。没有编造 IMSI 或短信中心号码。
- 检查已连接时单独修改 SMSC 保留当前 IMS 配置，以及重读卡片后恢复持久化配置。

重新编译以上当前生产类后，7 套既有 Java 回归全部通过，共 343 条断言。原始输出位于 `/workspace/recovery/wifi-audit23/config/results.json`；本目录的 `wifi-config-audit.json` 保存可随源码携带的结果摘要。

验证使用 Android 与原生配置模型替身，另对读卡衔接做静态核对。未通过真实手机、SIM、运营商服务器或重启后的网络重连验证；不包含本轮 SIP、音频生命周期补丁的验证结果。
