"""Expand the bundled global PLMN catalogue using explicitly UNVERIFIED standard templates.
No existing carrier-specific preset or selector is changed. Never guesses a SIM identity.
"""
import copy
import hashlib
import json
from pathlib import Path

VERSION=1
STANDARD={
    'epdgAddress':None, 'imsDomain':None, 'apn':'ims', 'ipStack':'dual',
    'ikeEncryption':['aes256','aes128'], 'ikeIntegrity':['sha256','sha512','sha1'],
    'ikePRF':['sha256','sha512','sha1'], 'ikeDH':['modp2048','modp1024'],
    'childEncryption':['aes256','aes128'], 'childIntegrity':['sha256','sha512','sha1'],
    'childPFS':None, 'natKeepaliveSeconds':20, 'dpdEnabled':False,
    'localIdentifier':'0$imsi@nai.epc.mnc$mnc.mcc$mcc.3gppnetwork.org',
    'useIPsec':True, 'maxUDPMessageSize':1300, 'impiFormat':'imsi@carrierDomain',
    'impuFormat':None, 'includeCellularNetworkInfo':False, 'pcscfAttrs':[]
}

def domains(mcc,mnc):
    if not (isinstance(mcc,str) and isinstance(mnc,str) and mcc.isascii() and mnc.isascii() and mcc.isdigit() and mnc.isdigit() and len(mcc)==3 and len(mnc) in (2,3)):
        raise ValueError('Invalid MCC/MNC')
    realm='mnc'+mnc.zfill(3)+'.mcc'+mcc
    return {'epdg':'epdg.epc.'+realm+'.pub.3gppnetwork.org',
            'ims':'ims.'+realm+'.3gppnetwork.org',
            'naiRealm':'nai.epc.'+realm+'.3gppnetwork.org'}

def expand(original,rows):
    result=copy.deepcopy(original)
    if result.get('globalStandardTemplatesVersion') is not None:
        raise ValueError('Refusing to expand an already modified preset library')
    ids={p['id'] for p in original['presets']}
    covered={p['plmn'] for p in original['presets']}
    # A selector referring to a missing preset is not safe to silently replace.
    rules={p['plmn'] for p in original['selectorRules']}
    records={}
    for row in rows:
        if len(row)<5:continue
        mcc,mnc=row[:2]
        try:domain=domains(mcc,mnc)
        except (ValueError,TypeError):continue
        plmn=mcc+mnc
        if plmn in records:continue
        name=(row[4] or row[3] or 'PLMN '+plmn).strip().replace('\n',' ').replace('\r',' ')
        entry={'plmn':plmn,'mcc':mcc,'mnc':mnc,'country':row[2],'name':name,
               'status':'existing-preset' if plmn in covered else 'standard-template-unverified',
               'standardDomains':domain,'wifiCallingSupported':None,'deviceVerified':False}
        records[plmn]=entry
        if plmn in covered:continue
        if plmn in rules:
            entry['status']='existing-selector-without-preset';continue
        preset_id='standard_plmn_'+plmn
        if preset_id in ids:raise ValueError('Preset ID collision')
        ids.add(preset_id)
        template=copy.deepcopy(STANDARD)
        template.update(id=preset_id,plmn=plmn,bundleName=name+' · 标准模板（未实测）')
        result['presets'].append(template)
        result['selectorRules'].append({'plmn':plmn,'presetID':preset_id,'generic':True,
                                       'gid1Prefix':None,'gid2Prefix':None,'iccidPrefix':None})
        entry['presetID']=preset_id
    result['globalStandardTemplatesVersion']=VERSION
    catalogue={'version':VERSION,'basis':'Bundled MCC/MNC directory; original SIMHub standard fallback; 3GPP domain naming',
               'notice':'Generated templates are not carrier-confirmed settings or proof of Wi-Fi Calling support. Identity always comes from the actual USIM.',
               'entries':[records[k] for k in sorted(records)]}
    return result,catalogue

def apply_carrier_presets(decoded):
    root=Path(decoded)/'assets'
    path=root/'vowifi/carrier_presets.json'
    directory=root/'data/mcc_mnc.json'
    raw=path.read_bytes();rows_raw=directory.read_bytes()
    expanded,catalogue=expand(json.loads(raw),json.loads(rows_raw))
    catalogue['inputPresetSHA256']=hashlib.sha256(raw).hexdigest()
    catalogue['inputDirectorySHA256']=hashlib.sha256(rows_raw).hexdigest()
    path.write_text(json.dumps(expanded,ensure_ascii=False,separators=(',',':'))+'\n')
    (root/'vowifi/global_standard_catalogue.json').write_text(json.dumps(catalogue,ensure_ascii=False,separators=(',',':'))+'\n')
    print('Carrier library:',len(expanded['presets']),'presets;',len(catalogue['entries']),'catalogue PLMNs; standard templates are unverified',flush=True)
    return expanded,catalogue
