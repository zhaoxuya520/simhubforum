# 长期签名交付（2026-11-11）

当前版本改用新的个人长期签名。旧版需先导出应用内数据备份，卸载后安装新版；不承诺直接覆盖旧签名版本。eSTK ARA-M 需添加新证书授权。卡片配置管理、DITO 注册及双芯片切换仍需要实机验证。

别名：simhub-longterm

证书 SHA-1：CAEAEE369CA8933EC6A80050ECAF22D87B155006

证书 SHA-256：50FE8B357EFB2F2397B1F822012A5D7E48A4FC1CAF5A0F8A4F0239FFADAB3C7E

RSA 3072 / SHA256withRSA，有效期至 2056-11-11。PKCS#12 使用 PBES2/PBKDF2-HMAC-SHA256/AES-256-CBC，密钥、证书加密与 MAC 均采用 600000 次迭代。密钥库含私钥，密码单独交付，不包含在源码、APK、发行说明或 GitHub 中。

signing/local-test-certificate.pem 这个历史路径现在保存新长期公开证书；signing/legacy-test-certificate.pem 仅保留旧公开证书。signing_policy.py 只替换固定基线的本地测试证书 SHA-256，保留原应用的其他证书条目和校验逻辑。

重建：python3 build_from_config2.py

签名：python3 sign_from_config2.py --keystore /private/simhub-longterm-2026.p12 --alias simhub-longterm --password-file /private/password-file --out /path/to/signed.apk

签名前检查固定基线、源码哈希和未签名产物哈希；签名后检查实际证书、v2/v3 签名、DEX 内签名白名单、签名前后 ZIP 内容一致和 16 KB 对齐。旧本地签名包已验证无法通过新签名交付检查。357 项 JVM 断言、16 项协程流程模拟、9 项预设数据检查和 4 项签名策略回归通过；没有实机 ART 或运营商通信验证。
