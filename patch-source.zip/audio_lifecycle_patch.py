"""Keep Android audio acquisition and cleanup paired when a platform call fails.

No codec, sampling, volume, route selection or Telecom ownership policy changes.
The native controller still owns all resources; the edits only widen its existing
startup rollback and ensure a failed cleanup step cannot skip later resources.
"""
from pathlib import Path


def replace_once(value, old, new):
    assert value.count(old) == 1, (old,value.count(old))
    return value.replace(old,new,1)


def startup(body):
    changes = [
        ('    :cond_1\n', '    :cond_1\n    :simhub_audio_startup_try\n'),
        ('    invoke-virtual {v2, v0}, Landroid/media/AudioManager;->requestAudioFocus(Landroid/media/AudioFocusRequest;)I',
         '    iput-object v0, p0, Lyz;->s:Landroid/media/AudioFocusRequest;\n\n    invoke-virtual {v2, v0}, Landroid/media/AudioManager;->requestAudioFocus(Landroid/media/AudioFocusRequest;)I'),
        ('    :cond_2\n    iput-object v0, p0, Lyz;->s:Landroid/media/AudioFocusRequest;', '    :cond_2'),
        ('    :try_start_0\n', ''),
        ('    :try_end_0\n    .catchall {:try_start_0 .. :try_end_0} :catchall_0\n', ''),
        ('    iget-object p0, p0, Lyz;->p:Ljava/lang/Thread;', '    iget-object v0, p0, Lyz;->p:Ljava/lang/Thread;'),
        ('    if-eqz p0, :cond_5', '    if-eqz v0, :cond_5'),
        ('    invoke-virtual {p0}, Ljava/lang/Thread;->start()V', '    invoke-virtual {v0}, Ljava/lang/Thread;->start()V'),
        ('    :cond_5\n', '    :cond_5\n    :simhub_audio_startup_end\n    .catchall {:simhub_audio_startup_try .. :simhub_audio_startup_end} :catchall_0\n'),
    ]
    for old,new in changes: body=replace_once(body,old,new)
    return body


def effects(body):
    # Optional processing still fails open. Only dispose an effect that was
    # allocated before its setEnabled call failed, retaining the original cause.
    for number,(kind,field) in enumerate([('AcousticEchoCanceler','l'),('NoiseSuppressor','m'),('AutomaticGainControl','n')]):
        descriptor='Landroid/media/audiofx/'+kind+';'
        create='    invoke-static {v2}, '+descriptor+'->create(I)'+descriptor
        assert body.count(create)==1
        after=body.index('    move-result-object v0',body.index(create))+len('    move-result-object v0')
        body=body[:after]+'\n    iput-object v0, p0, Lyz;->'+field+':'+descriptor+body[after:]
        old='    :catchall_'+str(number)+'\n    move-exception v0'
        label='simhub_effect_'+str(number)
        new=old+f"""
    iget-object v7, p0, Lyz;->{field}:{descriptor}
    if-eqz v7, :{label}_done
    :{label}_release
    invoke-virtual {{v7}}, Landroid/media/audiofx/AudioEffect;->release()V
    :{label}_released
    .catchall {{:{label}_release .. :{label}_released}} :{label}_done
    :{label}_done
    const/4 v7, 0x0
    iput-object v7, p0, Lyz;->{field}:{descriptor}
"""
        body=replace_once(body,old,new)
    return body


def playback(body):
    # Remove first, then install before play: rollback owns the allocated player
    # even if AudioTrack.play() throws. All sampling/format policy stays native.
    store='    iput-object v3, p0, Lyz;->k:Landroid/media/AudioTrack;'
    play='    invoke-virtual {v3}, Landroid/media/AudioTrack;->play()V'
    body=replace_once(body,store,'')
    return replace_once(body,play,store+'\n\n'+play)


def cleanup(body):
    import re
    calls = [
        'invoke-virtual {v2}, Landroid/media/AudioRecord;->release()V',
        'invoke-virtual {v2}, Landroid/media/AudioTrack;->release()V',
        'invoke-virtual {v2}, Landroid/media/audiofx/AudioEffect;->release()V',
        'invoke-static {v3, v0}, Lxz;->b(Landroid/content/Context;Z)Z',
        'invoke-virtual {v3, v2}, Landroid/media/AudioManager;->abandonAudioFocusRequest(Landroid/media/AudioFocusRequest;)I',
        'invoke-virtual {v3, v2}, Landroid/media/AudioManager;->setMode(I)V',
    ]
    for i,call in enumerate(calls):
        expected=3 if 'AudioEffect;' in call else 1
        assert body.count(call)==expected,(call,body.count(call))
        count=0
        def protect(match):
            nonlocal count
            label=str(i)+'_'+str(count);count+=1
            return ('    :simhub_audio_cleanup_try_'+label+'\n'+match[0]+'\n'
                +'    :simhub_audio_cleanup_end_'+label+'\n'
                +'    .catchall {:simhub_audio_cleanup_try_'+label+' .. :simhub_audio_cleanup_end_'+label+'} :simhub_audio_cleanup_resume_'+label+'\n'
                +'    :simhub_audio_cleanup_resume_'+label)
        body=re.sub(re.escape('    '+call),protect,body)
        assert count==expected
    return body


def transform(value):
    for method,change in [('d',startup),('e',effects),('f',playback),('g',cleanup)]:
        start=value.index('.method public final '+method+'()V\n')
        end=value.index('.end method',start)
        value=value[:start]+change(value[start:end])+value[end:]
    return value


def apply_audio_lifecycle(smali:Path):
    path=smali/'yz.smali'
    path.write_text(transform(path.read_text()))
