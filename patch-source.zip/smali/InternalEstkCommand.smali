.class public final LInternalEstkCommand;
.super Ljava/lang/Object;
.implements Lws1;

.field private final delegate:Lrf1;
.field public result:I

.method public constructor <init>(Lhh1;I)V
    .locals 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    const/4 v0, -0x1
    iput v0, p0, LInternalEstkCommand;->result:I
    if-ltz p2, :bad
    const/4 v0, 0x1
    if-gt p2, v0, :bad
    new-instance v0, Lrf1;
    invoke-direct {v0, p1, p2}, Lrf1;-><init>(Lhh1;I)V
    iput-object v0, p0, LInternalEstkCommand;->delegate:Lrf1;
    return-void
    :bad
    new-instance v0, Ljava/lang/IllegalArgumentException;
    const-string v1, "Invalid eSTK profile operation"
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v0
.end method

.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1
    iget-object v0, p0, LInternalEstkCommand;->delegate:Lrf1;
    invoke-virtual {v0, p1}, Lrf1;->i(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

# Only the explicit-AID transaction can defer a state-mismatch rejection for
# verified same-channel readback. Other native callers retain their exact path.
.method public static record(Ljava/lang/Object;I)Z
    .locals 1
    instance-of v0, p0, LInternalEstkCommand;
    if-eqz v0, :no
    check-cast p0, LInternalEstkCommand;
    iput p1, p0, LInternalEstkCommand;->result:I
    const/4 v0, 0x2
    if-ne p1, v0, :no
    const/4 v0, 0x1
    return v0
    :no
    const/4 v0, 0x0
    return v0
.end method
