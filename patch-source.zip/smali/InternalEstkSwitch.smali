.class public final LInternalEstkSwitch;
.super Lcz4;
.implements Lkt1;

.field public final plan:Lcc/forserein/simhub/internal/EstkSwitchPlan;
.field public final backend:Lhh1;

.method public constructor <init>(Lcc/forserein/simhub/internal/EstkSwitchPlan;Lhh1;Lct0;)V
    .locals 1
    const/4 v0, 0x2
    invoke-direct {p0, v0, p3}, Lcz4;-><init>(ILct0;)V
    iput-object p1, p0, LInternalEstkSwitch;->plan:Lcc/forserein/simhub/internal/EstkSwitchPlan;
    iput-object p2, p0, LInternalEstkSwitch;->backend:Lhh1;
    return-void
.end method

.method public final o(Lct0;Ljava/lang/Object;)Lct0;
    .locals 3
    new-instance v0, LInternalEstkSwitch;
    iget-object v1, p0, LInternalEstkSwitch;->plan:Lcc/forserein/simhub/internal/EstkSwitchPlan;
    iget-object v2, p0, LInternalEstkSwitch;->backend:Lhh1;
    invoke-direct {v0, v1, v2, p1}, LInternalEstkSwitch;-><init>(Lcc/forserein/simhub/internal/EstkSwitchPlan;Lhh1;Lct0;)V
    return-object v0
.end method

.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0
    check-cast p2, Lct0;
    invoke-virtual {p0, p2, p1}, LInternalEstkSwitch;->o(Lct0;Ljava/lang/Object;)Lct0;
    move-result-object p0
    check-cast p0, LInternalEstkSwitch;
    sget-object p1, Lsc5;->a:Lsc5;
    invoke-virtual {p0, p1}, LInternalEstkSwitch;->q(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p0
    return-object p0
.end method

.method public final q(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10
    sget-object v0, Lpu0;->T:Lpu0;
    iget-object v1, p0, LInternalEstkSwitch;->plan:Lcc/forserein/simhub/internal/EstkSwitchPlan;
    iget-object v2, p0, LInternalEstkSwitch;->backend:Lhh1;
    :advance
    :try_start
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    invoke-virtual {v1, p1}, Lcc/forserein/simhub/internal/EstkSwitchPlan;->next(Ljava/lang/Object;)V
    :dispatch
    iget v3, v1, Lcc/forserein/simhub/internal/EstkSwitchPlan;->kind:I
    if-eqz v3, :done
    const/4 v4, 0x4
    if-eq v3, v4, :wait
    # hh1.s retains the original serialized reader IO dispatch. Every request
    # captures its explicit AID and target EID before a coroutine can suspend.
    add-int/lit8 v8, v3, -0x1
    new-instance v3, LInternalEstkRequest;
    move-object v4, v2
    iget-object v5, v1, Lcc/forserein/simhub/internal/EstkSwitchPlan;->aid:[B
    iget-object v6, v1, Lcc/forserein/simhub/internal/EstkSwitchPlan;->eid:Ljava/lang/String;
    iget-object v7, v1, Lcc/forserein/simhub/internal/EstkSwitchPlan;->iccid:Ljava/lang/String;
    invoke-direct/range {v3 .. v8}, LInternalEstkRequest;-><init>(Lhh1;[BLjava/lang/String;Ljava/lang/String;I)V
    invoke-static {v3, p0}, Lhh1;->s(Lws1;Ldt0;)Ljava/lang/Object;
    move-result-object p1
    if-eq p1, v0, :suspend
    goto :advance
    :wait
    iget-wide v3, v1, Lcc/forserein/simhub/internal/EstkSwitchPlan;->delayMs:J
    invoke-static {v3, v4, p0}, Lg7;->J(JLct0;)Ljava/lang/Object;
    move-result-object p1
    if-eq p1, v0, :suspend
    goto :advance
    :done
    sget-object v0, Lsc5;->a:Lsc5;
    :suspend
    return-object v0
    :try_end
    .catchall {:try_start .. :try_end} :failed
    :failed
    move-exception v3
    invoke-virtual {v1, v3}, Lcc/forserein/simhub/internal/EstkSwitchPlan;->retryRead(Ljava/lang/Throwable;)Z
    move-result v4
    if-nez v4, :dispatch
    invoke-virtual {v1, v3}, Lcc/forserein/simhub/internal/EstkSwitchPlan;->failure(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    move-result-object v3
    throw v3
.end method
