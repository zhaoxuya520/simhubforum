.class public final LInternalSimChipRead;
.super Lcz4;
.implements Lkt1;
.field public final backend:Lhh1;
.field public final eid:Ljava/lang/String;
.field public channel:Lvf1;
.field public state:I

.method public constructor <init>(Lhh1;Ljava/lang/String;Lct0;)V
    .locals 1
    const/4 v0, 0x2
    invoke-direct {p0, v0, p3}, Lcz4;-><init>(ILct0;)V
    iput-object p1, p0, LInternalSimChipRead;->backend:Lhh1;
    iput-object p2, p0, LInternalSimChipRead;->eid:Ljava/lang/String;
    return-void
.end method

.method public final o(Lct0;Ljava/lang/Object;)Lct0;
    .locals 3
    new-instance v0, LInternalSimChipRead;
    iget-object v1, p0, LInternalSimChipRead;->backend:Lhh1;
    iget-object v2, p0, LInternalSimChipRead;->eid:Ljava/lang/String;
    invoke-direct {v0, v1, v2, p1}, LInternalSimChipRead;-><init>(Lhh1;Ljava/lang/String;Lct0;)V
    check-cast p2, Lvf1;
    iput-object p2, v0, LInternalSimChipRead;->channel:Lvf1;
    return-object v0
.end method

.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0
    check-cast p2, Lct0;
    invoke-virtual {p0, p2, p1}, LInternalSimChipRead;->o(Lct0;Ljava/lang/Object;)Lct0;
    move-result-object p0
    check-cast p0, LInternalSimChipRead;
    sget-object p1, Lsc5;->a:Lsc5;
    invoke-virtual {p0, p1}, LInternalSimChipRead;->q(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p0
    return-object p0
.end method

.method public final q(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    sget-object v0, Lpu0;->T:Lpu0;
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    iget v1, p0, LInternalSimChipRead;->state:I
    const/4 v2, 0x2
    if-eq v1, v2, :done
    const/4 v3, 0x1
    if-eq v1, v3, :eid_ready
    if-nez v1, :bad_state
    iput v3, p0, LInternalSimChipRead;->state:I
    iget-object v1, p0, LInternalSimChipRead;->backend:Lhh1;
    iget-object v4, p0, LInternalSimChipRead;->channel:Lvf1;
    invoke-virtual {v1, v4, p0}, Lhh1;->z(Lvf1;Ldt0;)Ljava/lang/Object;
    move-result-object p1
    if-eq p1, v0, :suspended
    :eid_ready
    check-cast p1, Ljava/lang/String;
    iget-object v1, p0, LInternalSimChipRead;->eid:Ljava/lang/String;
    invoke-static {v1, p1}, Lcc/forserein/simhub/internal/MultiChipSwitch;->verifyEid(Ljava/lang/String;Ljava/lang/String;)V
    iput v2, p0, LInternalSimChipRead;->state:I
    iget-object v1, p0, LInternalSimChipRead;->backend:Lhh1;
    new-instance v2, Lg0;
    const/4 v3, 0x0
    const/16 v4, 0x19
    invoke-direct {v2, v1, v3, v4}, Lg0;-><init>(Ljava/lang/Object;Lct0;I)V
    iget-object v1, p0, LInternalSimChipRead;->channel:Lvf1;
    invoke-virtual {v2, v1, p0}, Lg0;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p1
    if-eq p1, v0, :suspended
    :done
    return-object p1
    :suspended
    return-object v0
    :bad_state
    new-instance v0, Ljava/lang/IllegalStateException;
    const-string v1, "Invalid EID-checked read coroutine state"
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    throw v0
.end method
