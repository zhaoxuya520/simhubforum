.class public final LInternalEstkAccess;
.super Lcz4;
.implements Lkt1;

.field private final backend:Lhh1;
.field private final aid:[B
.field private final expectedEid:Ljava/lang/String;
.field private final iccid:Ljava/lang/String;
.field private final kind:I
.field private state:I
.field private channel:Lvf1;
.field private eid:Ljava/lang/String;
.field private command:LInternalEstkCommand;

.method public constructor <init>(Lhh1;[BLjava/lang/String;Ljava/lang/String;ILct0;)V
    .locals 1
    const/4 v0, 0x2
    invoke-direct {p0, v0, p6}, Lcz4;-><init>(ILct0;)V
    iput-object p1, p0, LInternalEstkAccess;->backend:Lhh1;
    array-length v0, p2
    invoke-static {p2, v0}, Ljava/util/Arrays;->copyOf([BI)[B
    move-result-object v0
    iput-object v0, p0, LInternalEstkAccess;->aid:[B
    iput-object p3, p0, LInternalEstkAccess;->expectedEid:Ljava/lang/String;
    iput-object p4, p0, LInternalEstkAccess;->iccid:Ljava/lang/String;
    iput p5, p0, LInternalEstkAccess;->kind:I
    return-void
.end method

.method public static start(Lhh1;[BLjava/lang/String;Ljava/lang/String;ILdt0;)Ljava/lang/Object;
    .locals 7
    invoke-static {p0, p2}, Lcc/forserein/simhub/internal/EstkSwitchPlan;->checkActive(Ljava/lang/Object;Ljava/lang/String;)V
    new-instance v0, LInternalEstkAccess;
    move-object v1, p0
    move-object v2, p1
    move-object v3, p2
    move-object v4, p3
    move v5, p4
    const/4 v6, 0x0
    invoke-direct/range {v0 .. v6}, LInternalEstkAccess;-><init>(Lhh1;[BLjava/lang/String;Ljava/lang/String;ILct0;)V
    iget-object v1, v0, LInternalEstkAccess;->aid:[B
    invoke-virtual {p0, p5, v0, v1}, Lhh1;->C(Ldt0;Lkt1;[B)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public final o(Lct0;Ljava/lang/Object;)Lct0;
    .locals 7
    new-instance v0, LInternalEstkAccess;
    iget-object v1, p0, LInternalEstkAccess;->backend:Lhh1;
    iget-object v2, p0, LInternalEstkAccess;->aid:[B
    iget-object v3, p0, LInternalEstkAccess;->expectedEid:Ljava/lang/String;
    iget-object v4, p0, LInternalEstkAccess;->iccid:Ljava/lang/String;
    iget v5, p0, LInternalEstkAccess;->kind:I
    move-object v6, p1
    invoke-direct/range {v0 .. v6}, LInternalEstkAccess;-><init>(Lhh1;[BLjava/lang/String;Ljava/lang/String;ILct0;)V
    check-cast p2, Lvf1;
    iput-object p2, v0, LInternalEstkAccess;->channel:Lvf1;
    return-object v0
.end method

.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1
    check-cast p2, Lct0;
    invoke-virtual {p0, p2, p1}, LInternalEstkAccess;->o(Lct0;Ljava/lang/Object;)Lct0;
    move-result-object v0
    check-cast v0, LInternalEstkAccess;
    sget-object p1, Lsc5;->a:Lsc5;
    invoke-virtual {v0, p1}, LInternalEstkAccess;->q(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public final q(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    iget v0, p0, LInternalEstkAccess;->state:I
    packed-switch v0, :states
    new-instance v0, Ljava/lang/IllegalStateException;
    const-string v1, "Invalid eSTK access continuation"
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    throw v0

    :initial
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    iget v0, p0, LInternalEstkAccess;->kind:I
    if-ltz v0, :bad_kind
    const/4 v1, 0x2
    if-gt v0, v1, :bad_kind
    iget-object v1, p0, LInternalEstkAccess;->backend:Lhh1;
    iget-object v2, p0, LInternalEstkAccess;->channel:Lvf1;
    const/4 v0, 0x1
    iput v0, p0, LInternalEstkAccess;->state:I
    invoke-virtual {v1, v2, p0}, Lhh1;->z(Lvf1;Ldt0;)Ljava/lang/Object;
    move-result-object p1
    sget-object v0, Lpu0;->T:Lpu0;
    if-eq p1, v0, :suspended

    :eid_before
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    check-cast p1, Ljava/lang/String;
    iget-object v0, p0, LInternalEstkAccess;->expectedEid:Ljava/lang/String;
    invoke-static {v0, p1}, Lcc/forserein/simhub/internal/EstkSwitchPlan;->verifyEid(Ljava/lang/String;Ljava/lang/String;)V
    iput-object p1, p0, LInternalEstkAccess;->eid:Ljava/lang/String;
    iget-object v0, p0, LInternalEstkAccess;->backend:Lhh1;
    invoke-static {v0, p1}, Lcc/forserein/simhub/internal/EstkSwitchPlan;->checkActive(Ljava/lang/Object;Ljava/lang/String;)V
    const/4 v0, 0x2
    iput v0, p0, LInternalEstkAccess;->state:I
    goto/16 :read_profiles

    :profiles_before
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    check-cast p1, Ljava/util/List;
    iget v0, p0, LInternalEstkAccess;->kind:I
    if-eqz v0, :read_result
    iget-object v1, p0, LInternalEstkAccess;->iccid:Ljava/lang/String;
    const/4 v2, 0x0
    invoke-static {p1, v1, v2}, LInternalSimProfileState;->matches(Ljava/util/List;Ljava/lang/String;Z)Z
    move-result v2
    if-nez v2, :unique_profile
    const/4 v2, 0x1
    invoke-static {p1, v1, v2}, LInternalSimProfileState;->matches(Ljava/util/List;Ljava/lang/String;Z)Z
    move-result v2
    if-eqz v2, :bad_profile
    :unique_profile
    iget-object v3, p0, LInternalEstkAccess;->backend:Lhh1;
    iget-object v2, p0, LInternalEstkAccess;->expectedEid:Ljava/lang/String;
    invoke-static {v3, v2}, Lcc/forserein/simhub/internal/EstkSwitchPlan;->checkActive(Ljava/lang/Object;Ljava/lang/String;)V
    const/4 v2, 0x0
    iput-boolean v2, v3, Lhh1;->g:Z
    add-int/lit8 v0, v0, -0x1
    new-instance v4, LInternalEstkCommand;
    invoke-direct {v4, v3, v0}, LInternalEstkCommand;-><init>(Lhh1;I)V
    iput-object v4, p0, LInternalEstkAccess;->command:LInternalEstkCommand;
    const v1, 0xbf31
    add-int/2addr v1, v0
    const/4 v2, 0x0
    iget-object v5, p0, LInternalEstkAccess;->iccid:Ljava/lang/String;
    new-instance v0, Lpg1;
    invoke-direct/range {v0 .. v5}, Lpg1;-><init>(ILct0;Lhh1;Lws1;Ljava/lang/String;)V
    const/4 v1, 0x3
    iput v1, p0, LInternalEstkAccess;->state:I
    iget-object v1, p0, LInternalEstkAccess;->channel:Lvf1;
    invoke-virtual {v0, v1, p0}, Lpg1;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p1
    sget-object v0, Lpu0;->T:Lpu0;
    if-eq p1, v0, :suspended

    :command_done
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    iget-object v0, p0, LInternalEstkAccess;->command:LInternalEstkCommand;
    iget v1, v0, LInternalEstkCommand;->result:I
    if-nez v1, :verify_rejected_state
    # Successful REFRESH may invalidate this channel. The owner reopens the
    # captured AID for the delayed readback; never resend the write here.
    const/4 p1, 0x0
    goto/16 :command_result
    :verify_rejected_state
    iget-object v1, p0, LInternalEstkAccess;->backend:Lhh1;
    iget-object v2, p0, LInternalEstkAccess;->channel:Lvf1;
    const/4 v0, 0x4
    iput v0, p0, LInternalEstkAccess;->state:I
    invoke-virtual {v1, v2, p0}, Lhh1;->z(Lvf1;Ldt0;)Ljava/lang/Object;
    move-result-object p1
    sget-object v0, Lpu0;->T:Lpu0;
    if-eq p1, v0, :suspended

    :eid_after
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    check-cast p1, Ljava/lang/String;
    iget-object v0, p0, LInternalEstkAccess;->expectedEid:Ljava/lang/String;
    invoke-static {v0, p1}, Lcc/forserein/simhub/internal/EstkSwitchPlan;->verifyEid(Ljava/lang/String;Ljava/lang/String;)V
    iput-object p1, p0, LInternalEstkAccess;->eid:Ljava/lang/String;
    iget-object v0, p0, LInternalEstkAccess;->backend:Lhh1;
    invoke-static {v0, p1}, Lcc/forserein/simhub/internal/EstkSwitchPlan;->checkActive(Ljava/lang/Object;Ljava/lang/String;)V
    const/4 v0, 0x5
    iput v0, p0, LInternalEstkAccess;->state:I

    :read_profiles
    new-instance v0, Lg0;
    iget-object v1, p0, LInternalEstkAccess;->backend:Lhh1;
    const/4 v2, 0x0
    const/16 v3, 0x19
    invoke-direct {v0, v1, v2, v3}, Lg0;-><init>(Ljava/lang/Object;Lct0;I)V
    iget-object v1, p0, LInternalEstkAccess;->channel:Lvf1;
    invoke-virtual {v0, v1, p0}, Lg0;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p1
    sget-object v0, Lpu0;->T:Lpu0;
    if-eq p1, v0, :suspended
    iget v0, p0, LInternalEstkAccess;->state:I
    const/4 v1, 0x2
    if-eq v0, v1, :profiles_before

    :profiles_after
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    check-cast p1, Ljava/util/List;
    iget-object v0, p0, LInternalEstkAccess;->command:LInternalEstkCommand;
    iget v1, v0, LInternalEstkCommand;->result:I
    const/4 v0, 0x2
    if-ne v1, v0, :command_result
    iget v2, p0, LInternalEstkAccess;->kind:I
    const/4 v3, 0x1
    if-eq v2, v3, :desired_ready
    const/4 v3, 0x0
    :desired_ready
    iget-object v2, p0, LInternalEstkAccess;->iccid:Ljava/lang/String;
    invoke-static {p1, v2, v3}, LInternalSimProfileState;->matches(Ljava/util/List;Ljava/lang/String;Z)Z
    move-result v2
    if-nez v2, :command_result
    sget-object v2, Lhh1;->Companion:Lsf1;
    invoke-static {v2, v1}, Lsf1;->a(Lsf1;I)Lze0;
    move-result-object v0
    throw v0

    :read_result
    const/4 v1, -0x1
    :command_result
    new-instance v0, Lcc/forserein/simhub/internal/EstkSwitchPlan$IoResult;
    iget-object v2, p0, LInternalEstkAccess;->eid:Ljava/lang/String;
    invoke-direct {v0, v1, p1, v2}, Lcc/forserein/simhub/internal/EstkSwitchPlan$IoResult;-><init>(ILjava/util/List;Ljava/lang/String;)V
    return-object v0

    :suspended
    sget-object v0, Lpu0;->T:Lpu0;
    return-object v0
    :bad_kind
    new-instance v0, Ljava/lang/IllegalArgumentException;
    const-string v1, "Invalid eSTK access kind"
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v0
    :bad_profile
    new-instance v0, Ljava/lang/IllegalStateException;
    const-string v1, "所选芯片中未找到唯一目标配置，请重新读取卡片"
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    throw v0
    :states
    .packed-switch 0x0
        :initial
        :eid_before
        :profiles_before
        :command_done
        :eid_after
        :profiles_after
    .end packed-switch
.end method
