.class public final Lcc/forserein/simhub/internal/CaptionCompose;
.super Ljava/lang/Object;
.implements Lws1;

.field private final placement:I
.field private static final DIALER:Lcc/forserein/simhub/internal/CaptionCompose;
.field private static final SETTINGS:Lcc/forserein/simhub/internal/CaptionCompose;
.field private static final CALL:Lcc/forserein/simhub/internal/CaptionCompose;

.method static constructor <clinit>()V
    .locals 2
    new-instance v0, Lcc/forserein/simhub/internal/CaptionCompose;
    const/4 v1, 0x0
    invoke-direct {v0, v1}, Lcc/forserein/simhub/internal/CaptionCompose;-><init>(I)V
    sput-object v0, Lcc/forserein/simhub/internal/CaptionCompose;->DIALER:Lcc/forserein/simhub/internal/CaptionCompose;
    new-instance v0, Lcc/forserein/simhub/internal/CaptionCompose;
    const/4 v1, 0x1
    invoke-direct {v0, v1}, Lcc/forserein/simhub/internal/CaptionCompose;-><init>(I)V
    sput-object v0, Lcc/forserein/simhub/internal/CaptionCompose;->SETTINGS:Lcc/forserein/simhub/internal/CaptionCompose;
    new-instance v0, Lcc/forserein/simhub/internal/CaptionCompose;
    const/4 v1, 0x2
    invoke-direct {v0, v1}, Lcc/forserein/simhub/internal/CaptionCompose;-><init>(I)V
    sput-object v0, Lcc/forserein/simhub/internal/CaptionCompose;->CALL:Lcc/forserein/simhub/internal/CaptionCompose;
    return-void
.end method

.method private constructor <init>(I)V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput p1, p0, Lcc/forserein/simhub/internal/CaptionCompose;->placement:I
    return-void
.end method

.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    check-cast p1, Landroid/content/Context;
    iget v0, p0, Lcc/forserein/simhub/internal/CaptionCompose;->placement:I
    if-eqz v0, :dialer
    const/4 v1, 0x1
    if-eq v0, v1, :settings
    invoke-static {p1}, Lcc/forserein/simhub/internal/CaptionUi;->callView(Landroid/content/Context;)Landroid/view/View;
    move-result-object v0
    return-object v0
    :settings
    invoke-static {p1}, Lcc/forserein/simhub/internal/CaptionUi;->settingsView(Landroid/content/Context;)Landroid/view/View;
    move-result-object v0
    return-object v0
    :dialer
    invoke-static {p1}, Lcc/forserein/simhub/internal/CaptionUi;->dialerView(Landroid/content/Context;)Landroid/view/View;
    move-result-object v0
    return-object v0
.end method

.method private static mount(Lws1;Llu1;)V
    .locals 3
    sget-object v0, Lo53;->b:Lo53;
    const/high16 v1, 0x3f800000
    invoke-static {v0, v1}, Loo4;->c(Lr53;F)Lr53;
    move-result-object v0
    const/4 v1, 0x0
    const/16 v2, 0x30
    invoke-static {p0, v0, v1, p1, v2}, Lfi2;->b(Lws1;Lr53;Lws1;Llu1;I)V
    return-void
.end method

.method public static dialer(Llu1;)V
    .locals 1
    sget-object v0, Lcc/forserein/simhub/internal/CaptionCompose;->DIALER:Lcc/forserein/simhub/internal/CaptionCompose;
    invoke-static {v0, p0}, Lcc/forserein/simhub/internal/CaptionCompose;->mount(Lws1;Llu1;)V
    return-void
.end method

.method public static settings(Llu1;)V
    .locals 1
    sget-object v0, Lcc/forserein/simhub/internal/CaptionCompose;->SETTINGS:Lcc/forserein/simhub/internal/CaptionCompose;
    invoke-static {v0, p0}, Lcc/forserein/simhub/internal/CaptionCompose;->mount(Lws1;Llu1;)V
    return-void
.end method

.method public static call(Llu1;)V
    .locals 1
    sget-object v0, Lcc/forserein/simhub/internal/CaptionCompose;->CALL:Lcc/forserein/simhub/internal/CaptionCompose;
    invoke-static {v0, p0}, Lcc/forserein/simhub/internal/CaptionCompose;->mount(Lws1;Llu1;)V
    return-void
.end method

# On short displays the existing peer details and controls alone can exceed the
# viewport. Keep both inside one bounded scroll container, including the caption.
.method public static callViewport(Lr53;Llu1;)Lr53;
    .locals 3
    sget-object v0, Lh7;->a:Ltp0;
    invoke-virtual {p1, v0}, Llu1;->k(Lrv3;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/content/res/Configuration;
    iget v1, v0, Landroid/content/res/Configuration;->screenHeightDp:I
    const/16 v2, 0x2bc    # 700dp
    if-lt v1, v2, :scroll
    iget v0, v0, Landroid/content/res/Configuration;->fontScale:F
    const/high16 v2, 0x3fa00000    # 1.25
    cmpl-float v0, v0, v2
    if-lez v0, :fixed
    :scroll
    const v0, 0x49ae0701
    invoke-virtual {p1, v0}, Llu1;->c0(I)V
    invoke-static {p1}, Lpx3;->Z(Llu1;)Lcf4;
    move-result-object v0
    const/4 v1, 0x1
    invoke-static {p0, v0, v1}, Lpx3;->b0(Lr53;Lcf4;Z)Lr53;
    move-result-object p0
    const/4 v0, 0x0
    invoke-virtual {p1, v0}, Llu1;->q(Z)V
    :fixed
    return-object p0
.end method
