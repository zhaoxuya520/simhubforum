.class public final LInternalSimSwitchRequest;
.super Lcz4;
.implements Lkt1;
.field public backend:Lhh1;
.field public iccid:Ljava/lang/String;
.field public operation:I
.field public command:Lws1;
.field public state:I

.method public constructor <init>(Lhh1;Ljava/lang/String;ILws1;Lct0;)V
    .locals 1
    const/4 v0, 0x2
    invoke-direct {p0, v0, p5}, Lcz4;-><init>(ILct0;)V
    iput-object p1, p0, LInternalSimSwitchRequest;->backend:Lhh1;
    iput-object p2, p0, LInternalSimSwitchRequest;->iccid:Ljava/lang/String;
    iput p3, p0, LInternalSimSwitchRequest;->operation:I
    iput-object p4, p0, LInternalSimSwitchRequest;->command:Lws1;
    return-void
.end method
.method public static start(Lhh1;Ljava/lang/String;ILws1;Lcz4;)Ljava/lang/Object;
    .locals 6
    new-instance v0, LInternalSimSwitchRequest;
    move-object v1, p0
    move-object v2, p1
    move v3, p2
    move-object v4, p3
    move-object v5, p4
    invoke-direct/range {v0 .. v5}, LInternalSimSwitchRequest;-><init>(Lhh1;Ljava/lang/String;ILws1;Lct0;)V
    sget-object v1, Lsc5;->a:Lsc5;
    invoke-virtual {v0, v1}, LInternalSimSwitchRequest;->q(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method
.method public final o(Lct0;Ljava/lang/Object;)Lct0;
    .locals 6
    new-instance v0, LInternalSimSwitchRequest;
    iget-object v1, p0, LInternalSimSwitchRequest;->backend:Lhh1;
    iget-object v2, p0, LInternalSimSwitchRequest;->iccid:Ljava/lang/String;
    iget v3, p0, LInternalSimSwitchRequest;->operation:I
    iget-object v4, p0, LInternalSimSwitchRequest;->command:Lws1;
    move-object v5, p1
    invoke-direct/range {v0 .. v5}, LInternalSimSwitchRequest;-><init>(Lhh1;Ljava/lang/String;ILws1;Lct0;)V
    return-object v0
.end method
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0
    check-cast p2, Lct0;
    invoke-virtual {p0, p2, p1}, LInternalSimSwitchRequest;->o(Lct0;Ljava/lang/Object;)Lct0;
    move-result-object p0
    check-cast p0, LInternalSimSwitchRequest;
    sget-object p1, Lsc5;->a:Lsc5;
    invoke-virtual {p0, p1}, LInternalSimSwitchRequest;->q(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p0
    return-object p0
.end method
.method public final q(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    sget-object v0, Lpu0;->T:Lpu0;
    iget-object v1, p0, LInternalSimSwitchRequest;->backend:Lhh1;
    iget-object v2, p0, LInternalSimSwitchRequest;->iccid:Ljava/lang/String;
    iget v3, p0, LInternalSimSwitchRequest;->operation:I
    :try_start
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    iget v4, p0, LInternalSimSwitchRequest;->state:I
    if-nez v4, :completed
    const/4 v4, 0x1
    iput v4, p0, LInternalSimSwitchRequest;->state:I
    iget-object v4, p0, LInternalSimSwitchRequest;->command:Lws1;
    invoke-virtual {v1, v2, v3, v4, p0}, Lhh1;->v(Ljava/lang/String;ILws1;Lcz4;)Ljava/lang/Object;
    move-result-object p1
    if-eq p1, v0, :suspended
    :completed
    sget-object v0, Lsc5;->a:Lsc5;
    :try_end
    .catchall {:try_start .. :try_end} :failed
    :suspended
    return-object v0
    :failed
    move-exception v4
    iget-object v5, v1, Lhh1;->a:Lqg0;
    instance-of v5, v5, Ls4;
    iget v6, p0, LInternalSimSwitchRequest;->state:I
    invoke-static {v4, v5, v6}, Lcc/forserein/simhub/internal/ProfileRefresh;->retryWithoutRefresh(Ljava/lang/Throwable;ZI)Z
    move-result v5
    if-eqz v5, :throw
    const/4 v5, 0x2
    iput v5, p0, LInternalSimSwitchRequest;->state:I
    const-string v4, "[切卡] 卡片拒绝带刷新的请求，改用 refreshFlag=false 重试一次；仍须读回确认状态。若手机未刷新，请切换飞行模式。"
    invoke-virtual {v1, v4}, Lhh1;->u(Ljava/lang/String;)V
    const v4, 0xbf31
    const/4 v5, 0x0
    if-eq v3, v4, :callback
    const/4 v5, 0x1
    :callback
    new-instance v4, LInternalSimNoRefreshCommand;
    invoke-direct {v4, v5}, LInternalSimNoRefreshCommand;-><init>(I)V
    invoke-virtual {v1, v2, v3, v4, p0}, Lhh1;->v(Ljava/lang/String;ILws1;Lcz4;)Ljava/lang/Object;
    move-result-object p1
    if-eq p1, v0, :suspended
    sget-object v0, Lsc5;->a:Lsc5;
    return-object v0
    :throw
    throw v4
.end method
