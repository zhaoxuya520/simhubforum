.class public final LInternalSimNoRefreshCommand;
.super Ljava/lang/Object;
.implements Lws1;
.field public final action:I
.method public constructor <init>(I)V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput p1, p0, LInternalSimNoRefreshCommand;->action:I
    return-void
.end method
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    check-cast p1, [B
    iget v0, p0, LInternalSimNoRefreshCommand;->action:I
    const/4 v1, 0x0
    invoke-static {p1, v0, v1}, Lcc/forserein/simhub/internal/ProfileRefresh;->command([BIZ)[B
    move-result-object p1
    return-object p1
.end method
