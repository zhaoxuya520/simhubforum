.class public final LInternalEstkRequest;
.super Ljava/lang/Object;
.implements Lws1;

.field public final backend:Lhh1;
.field public final aid:[B
.field public final eid:Ljava/lang/String;
.field public final iccid:Ljava/lang/String;
.field public final kind:I

.method public constructor <init>(Lhh1;[BLjava/lang/String;Ljava/lang/String;I)V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, LInternalEstkRequest;->backend:Lhh1;
    invoke-virtual {p2}, [B->clone()Ljava/lang/Object;
    move-result-object p1
    check-cast p1, [B
    iput-object p1, p0, LInternalEstkRequest;->aid:[B
    iput-object p3, p0, LInternalEstkRequest;->eid:Ljava/lang/String;
    iput-object p4, p0, LInternalEstkRequest;->iccid:Ljava/lang/String;
    iput p5, p0, LInternalEstkRequest;->kind:I
    return-void
.end method

.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    iget-object v0, p0, LInternalEstkRequest;->backend:Lhh1;
    iget-object v1, p0, LInternalEstkRequest;->aid:[B
    iget-object v2, p0, LInternalEstkRequest;->eid:Ljava/lang/String;
    iget-object v3, p0, LInternalEstkRequest;->iccid:Ljava/lang/String;
    iget v4, p0, LInternalEstkRequest;->kind:I
    check-cast p1, Ldt0;
    move-object v5, p1
    invoke-static/range {v0 .. v5}, LInternalEstkAccess;->start(Lhh1;[BLjava/lang/String;Ljava/lang/String;ILdt0;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method
