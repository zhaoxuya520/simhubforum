.class public final LInternalSimCheckedRead;
.super Ljava/lang/Object;
.implements Lws1;
.field public final backend:Lhh1;
.field public final eid:Ljava/lang/String;

.method public constructor <init>(Lhh1;Ljava/lang/String;)V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, LInternalSimCheckedRead;->backend:Lhh1;
    iput-object p2, p0, LInternalSimCheckedRead;->eid:Ljava/lang/String;
    return-void
.end method

.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    check-cast p1, Lct0;
    iget-object v0, p0, LInternalSimCheckedRead;->backend:Lhh1;
    iget-object v1, p0, LInternalSimCheckedRead;->eid:Ljava/lang/String;
    new-instance v2, LInternalSimChipRead;
    const/4 v3, 0x0
    invoke-direct {v2, v0, v1, v3}, LInternalSimChipRead;-><init>(Lhh1;Ljava/lang/String;Lct0;)V
    iget-object v1, v0, Lhh1;->c:[B
    invoke-virtual {v0, p1, v2, v1}, Lhh1;->C(Ldt0;Lkt1;[B)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method
