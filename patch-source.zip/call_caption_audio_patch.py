"""Isolate Wi-Fi call captions at the decoded, mono remote-audio boundary."""
from hashlib import sha256
from pathlib import Path

CAPTION_AUDIO_CLASSES = {'t10.smali'}
BEFORE = '7501b6663366b0478079fd9a36f2aa78f196289840d87158a57b8d1510a8c025'
CORE = 'Lcc/forserein/simhub/internal/CallCaptions;'
PLAY = '    invoke-virtual {p0, v0}, Lyz;->b([S)V'
START = '    iput-object v0, p0, Lt10;->l:Ljava/util/concurrent/ScheduledFuture;'
STOP = '    iput-boolean v1, p0, Lt10;->v:Z'
# These anchors distinguish actual decoded network audio and decoder concealment.
DECODED = '    .line 162\n' + PLAY
CONCEALED = '    .line 183\n' + PLAY
EDITS = [
    (DECODED, DECODED + '\n    invoke-static {p0, v0}, Lt10;->captionPlayout(Lyz;[S)V'),
    (CONCEALED, CONCEALED + '\n    const/4 v1, 0x0\n    invoke-static {p0, v1}, Lt10;->captionPlayout(Lyz;[S)V'),
    (START, START + '\n    iget-object v0, p0, Lt10;->e:Lyz;\n    invoke-static {v0}, Lt10;->captionStart(Lyz;)V'),
    (STOP, STOP + '\n    iget-object v2, p0, Lt10;->e:Lyz;\n    invoke-static {v2}, Lt10;->captionStop(Lyz;)V'),
]


def _bridge(signature, instructions):
    # The media executor and its startup/cleanup lock must survive a missing
    # optional engine or a failed caption callback. Never swallow VM errors.
    return (f'.method private static {signature}\n    .locals 2\n'
            '    :try_start\n' + instructions +
            '\n    :try_end\n'
            '    .catch Ljava/lang/RuntimeException; {:try_start .. :try_end} :unavailable\n'
            '    .catch Ljava/lang/LinkageError; {:try_start .. :try_end} :unavailable\n'
            '    return-void\n'
            '    :unavailable\n    move-exception v0\n    return-void\n.end method\n')


BRIDGES = '\n' + '\n'.join((
    _bridge('captionStart(Lyz;)V',
            '    iget-object v0, p0, Lyz;->a:Landroid/content/Context;\n'
            '    iget v1, p0, Lyz;->b:I\n'
            f'    invoke-static {{p0, v0, v1}}, {CORE}->mediaStarted(Ljava/lang/Object;Landroid/content/Context;I)V'),
    _bridge('captionPlayout(Lyz;[S)V',
            f'    invoke-static {{p0, p1}}, {CORE}->remotePcm(Ljava/lang/Object;[S)V'),
    _bridge('captionStop(Lyz;)V',
            f'    invoke-static {{p0}}, {CORE}->mediaStopped(Ljava/lang/Object;)V'),
))


def _digest(text):
    return sha256(text.encode()).hexdigest()


def reverse_caption_audio(name, text):
    if name not in CAPTION_AUDIO_CLASSES:
        return text
    if _digest(text) == BEFORE:
        return text
    assert text.endswith(BRIDGES), 'incomplete or altered caption audio bridges'
    restored = text[:-len(BRIDGES)]
    for old, new in reversed(EDITS):
        assert restored.count(new) == 1, 'caption media hook missing or duplicated'
        restored = restored.replace(new, old)
    assert _digest(restored) == BEFORE, 'unexpected media or decoder edits'
    return restored


def apply_caption_audio(smali):
    path = Path(smali) / 't10.smali'
    original = path.read_text()
    assert _digest(original) == BEFORE, 'caption hook requires the verified 25.0 media path'
    patched = original
    for old, new in EDITS:
        assert patched.count(old) == 1, 'ambiguous caption hook anchor'
        patched = patched.replace(old, new)
    patched += BRIDGES
    assert reverse_caption_audio(path.name, patched) == original
    path.write_text(patched)


def verify_caption_audio(smali):
    text = (Path(smali) / 't10.smali').read_text()
    assert text.endswith(BRIDGES) and all(text.count(new) == 1 for _, new in EDITS)
    assert _digest(reverse_caption_audio('t10.smali', text)) == BEFORE
    return {'hooks': ['t10.e', 't10.b', 't10.f'], 'previous_t10_sha256': BEFORE,
            'input': 'remote AMR decoder PCM after native playout enqueue',
            'loss': '20 ms gap (null); native packet concealment remains audible only',
            'sample_rates_hz': [8000, 16000], 'session_key': 'per-media-session playback object'}
