"""Replace only the native missing-SMSC inline input with the explicit list editor.

The original branch wrote settings on each keystroke. Both of its complete
Compose branches are removed; the new Java entry owns its balanced group.
All native call/SMS transport methods remain outside this transform.
"""
from pathlib import Path
import hashlib

TARGET='mc0.smali'
SIGNATURE='public final d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;'
METHOD_SHA256='2e7b7378b656872b3e5e7b02442fa7767d258e34155bd851d73a9c389c1a701b'
ORIGINAL_SHA256='b0caa7012d19263dfcbca70e31816b28c0c05bb4f67cd93ff598b437aef2003c'
METHOD_PINS={(TARGET,SIGNATURE):METHOD_SHA256}
HOOK='Lcc/forserein/simhub/internal/WifiConfigEditor;->smsCenterEntry(Ljava/lang/String;Ljava/lang/Object;)V'
# Keep the exact removed instructions/debug lines for a strict byte-for-byte reverse.
ORIGINAL_REGION=r'''    :goto_e
    if-nez v0, :cond_15

    .line 1039
    .line 1040
    const v0, -0x18f9539b

    .line 1041
    .line 1042
    .line 1043
    invoke-virtual {v10, v0}, Llu1;->c0(I)V

    .line 1044
    .line 1045
    .line 1046
    move-object/from16 v54, v6

    .line 1047
    .line 1048
    const/4 v0, 0x2

    .line 1049
    const/4 v13, 0x0

    .line 1050
    const/high16 v14, 0x41800000    # 16.0f

    .line 1051
    .line 1052
    invoke-static {v3, v14, v13, v0}, Lei0;->a0(Lr53;FFI)Lr53;

    .line 1053
    .line 1054
    .line 1055
    move-result-object v6

    .line 1056
    const/high16 v0, 0x3f800000    # 1.0f

    .line 1057
    .line 1058
    invoke-static {v6, v0}, Loo4;->c(Lr53;F)Lr53;

    .line 1059
    .line 1060
    .line 1061
    move-result-object v6

    .line 1062
    const/high16 v0, 0x42300000    # 44.0f

    .line 1063
    .line 1064
    invoke-static {v6, v0}, Loo4;->e(Lr53;F)Lr53;

    .line 1065
    .line 1066
    .line 1067
    move-result-object v0

    .line 1068
    move-object/from16 v6, v70

    .line 1069
    .line 1070
    invoke-static {v0, v6}, Lg7;->E(Lr53;Lim4;)Lr53;

    .line 1071
    .line 1072
    .line 1073
    move-result-object v0

    .line 1074
    move-object/from16 v60, v7

    .line 1075
    .line 1076
    move-wide/from16 v6, v68

    .line 1077
    .line 1078
    invoke-static {v0, v6, v7, v15}, Lv95;->o(Lr53;JLim4;)Lr53;

    .line 1079
    .line 1080
    .line 1081
    move-result-object v0

    .line 1082
    const/4 v6, 0x2

    .line 1083
    invoke-static {v0, v14, v13, v6}, Lei0;->a0(Lr53;FFI)Lr53;

    .line 1084
    .line 1085
    .line 1086
    move-result-object v0

    .line 1087
    new-instance v6, Lph;

    .line 1088
    .line 1089
    new-instance v7, Lo5;

    .line 1090
    .line 1091
    const/16 v13, 0x14

    .line 1092
    .line 1093
    invoke-direct {v7, v13}, Lo5;-><init>(I)V

    .line 1094
    .line 1095
    .line 1096
    const/high16 v13, 0x41000000    # 8.0f

    .line 1097
    .line 1098
    const/4 v14, 0x1

    .line 1099
    invoke-direct {v6, v13, v14, v7}, Lph;-><init>(FZLo5;)V

    .line 1100
    .line 1101
    .line 1102
    const/16 v7, 0x36

    .line 1103
    .line 1104
    invoke-static {v6, v5, v10, v7}, Lb84;->a(Loh;Lgp;Llu1;I)Ld84;

    .line 1105
    .line 1106
    .line 1107
    move-result-object v5

    .line 1108
    iget-wide v6, v10, Llu1;->T:J

    .line 1109
    .line 1110
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 1111
    .line 1112
    .line 1113
    move-result v6

    .line 1114
    invoke-virtual {v10}, Llu1;->m()Lho3;

    .line 1115
    .line 1116
    .line 1117
    move-result-object v7

    .line 1118
    invoke-static {v10, v0}, Lgi2;->S(Llu1;Lr53;)Lr53;

    .line 1119
    .line 1120
    .line 1121
    move-result-object v0

    .line 1122
    invoke-virtual {v10}, Llu1;->g0()V

    .line 1123
    .line 1124
    .line 1125
    iget-boolean v13, v10, Llu1;->S:Z

    .line 1126
    .line 1127
    if-eqz v13, :cond_f

    .line 1128
    .line 1129
    invoke-virtual {v10, v1}, Llu1;->l(Lus1;)V

    .line 1130
    .line 1131
    .line 1132
    goto :goto_f

    .line 1133
    :cond_f
    invoke-virtual {v10}, Llu1;->p0()V

    .line 1134
    .line 1135
    .line 1136
    :goto_f
    invoke-static {v9, v10, v5}, Lic2;->z(Lkt1;Llu1;Ljava/lang/Object;)V

    .line 1137
    .line 1138
    .line 1139
    invoke-static {v12, v10, v7}, Lic2;->z(Lkt1;Llu1;Ljava/lang/Object;)V

    .line 1140
    .line 1141
    .line 1142
    invoke-static {v6, v10, v11, v10}, Lbu0;->v(ILlu1;Leo0;Llu1;)V

    .line 1143
    .line 1144
    .line 1145
    invoke-static {v2, v10, v0}, Lic2;->z(Lkt1;Llu1;Ljava/lang/Object;)V

    .line 1146
    .line 1147
    .line 1148
    invoke-static {}, Lfd2;->N()Lqb2;

    .line 1149
    .line 1150
    .line 1151
    move-result-object v19

    .line 1152
    iget-wide v5, v4, Ljj2;->g:J

    .line 1153
    .line 1154
    const/high16 v0, 0x41900000    # 18.0f

    .line 1155
    .line 1156
    invoke-static {v3, v0}, Loo4;->i(Lr53;F)Lr53;

    .line 1157
    .line 1158
    .line 1159
    move-result-object v21

    .line 1160
    const/16 v25, 0x1b0

    .line 1161
    .line 1162
    const/16 v26, 0x0

    .line 1163
    .line 1164
    const/16 v20, 0x0

    .line 1165
    .line 1166
    move-wide/from16 v22, v5

    .line 1167
    .line 1168
    move-object/from16 v24, v10

    .line 1169
    .line 1170
    invoke-static/range {v19 .. v26}, Lf92;->a(Lqb2;Ljava/lang/String;Lr53;JLlu1;II)V

    .line 1171
    .line 1172
    .line 1173
    const/high16 v13, 0x3f800000    # 1.0f

    .line 1174
    .line 1175
    float-to-double v5, v13

    .line 1176
    cmpl-double v0, v5, v71

    .line 1177
    .line 1178
    if-lez v0, :cond_10

    .line 1179
    .line 1180
    goto :goto_10

    .line 1181
    :cond_10
    invoke-static/range {v74 .. v74}, Lzd2;->a(Ljava/lang/String;)V

    .line 1182
    .line 1183
    .line 1184
    :goto_10
    new-instance v0, Lnr2;

    .line 1185
    .line 1186
    cmpl-float v5, v13, v65

    .line 1187
    .line 1188
    if-lez v5, :cond_11

    .line 1189
    .line 1190
    move/from16 v13, v65

    .line 1191
    .line 1192
    :goto_11
    const/4 v7, 0x1

    .line 1193
    goto :goto_12

    .line 1194
    :cond_11
    const/high16 v13, 0x3f800000    # 1.0f

    .line 1195
    .line 1196
    goto :goto_11

    .line 1197
    :goto_12
    invoke-direct {v0, v13, v7}, Lnr2;-><init>(FZ)V

    .line 1198
    .line 1199
    .line 1200
    move-object/from16 v13, v73

    .line 1201
    .line 1202
    const/4 v14, 0x0

    .line 1203
    invoke-static {v13, v14}, Lxv;->d(Lhp;Z)Lw33;

    .line 1204
    .line 1205
    .line 1206
    move-result-object v5

    .line 1207
    iget-wide v6, v10, Llu1;->T:J

    .line 1208
    .line 1209
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 1210
    .line 1211
    .line 1212
    move-result v6

    .line 1213
    invoke-virtual {v10}, Llu1;->m()Lho3;

    .line 1214
    .line 1215
    .line 1216
    move-result-object v7

    .line 1217
    invoke-static {v10, v0}, Lgi2;->S(Llu1;Lr53;)Lr53;

    .line 1218
    .line 1219
    .line 1220
    move-result-object v0

    .line 1221
    invoke-virtual {v10}, Llu1;->g0()V

    .line 1222
    .line 1223
    .line 1224
    iget-boolean v13, v10, Llu1;->S:Z

    .line 1225
    .line 1226
    if-eqz v13, :cond_12

    .line 1227
    .line 1228
    invoke-virtual {v10, v1}, Llu1;->l(Lus1;)V

    .line 1229
    .line 1230
    .line 1231
    goto :goto_13

    .line 1232
    :cond_12
    invoke-virtual {v10}, Llu1;->p0()V

    .line 1233
    .line 1234
    .line 1235
    :goto_13
    invoke-static {v9, v10, v5}, Lic2;->z(Lkt1;Llu1;Ljava/lang/Object;)V

    .line 1236
    .line 1237
    .line 1238
    invoke-static {v12, v10, v7}, Lic2;->z(Lkt1;Llu1;Ljava/lang/Object;)V

    .line 1239
    .line 1240
    .line 1241
    invoke-static {v6, v10, v11, v10}, Lbu0;->v(ILlu1;Leo0;Llu1;)V

    .line 1242
    .line 1243
    .line 1244
    invoke-static {v2, v10, v0}, Lic2;->z(Lkt1;Llu1;Ljava/lang/Object;)V

    .line 1245
    .line 1246
    .line 1247
    invoke-virtual/range {v54 .. v54}, Ljava/lang/String;->length()I

    .line 1248
    .line 1249
    .line 1250
    move-result v0

    .line 1251
    if-nez v0, :cond_13

    .line 1252
    .line 1253
    const v0, 0x103c1815

    .line 1254
    .line 1255
    .line 1256
    invoke-virtual {v10, v0}, Llu1;->c0(I)V

    .line 1257
    .line 1258
    .line 1259
    const-string v0, "vowifi_sms_smsc_override"

    .line 1260
    .line 1261
    invoke-static {v0}, Lqv4;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 1262
    .line 1263
    .line 1264
    move-result-object v29

    .line 1265
    iget-wide v5, v4, Ljj2;->h:J

    .line 1266
    .line 1267
    const/16 v49, 0x0

    .line 1268
    .line 1269
    const v50, 0x1fffa

    .line 1270
    .line 1271
    .line 1272
    const/16 v30, 0x0

    .line 1273
    .line 1274
    const-wide/16 v33, 0x0

    .line 1275
    .line 1276
    const/16 v35, 0x0

    .line 1277
    .line 1278
    const/16 v36, 0x0

    .line 1279
    .line 1280
    const-wide/16 v37, 0x0

    .line 1281
    .line 1282
    const/16 v39, 0x0

    .line 1283
    .line 1284
    const-wide/16 v40, 0x0

    .line 1285
    .line 1286
    const/16 v42, 0x0

    .line 1287
    .line 1288
    const/16 v43, 0x0

    .line 1289
    .line 1290
    const/16 v44, 0x0

    .line 1291
    .line 1292
    const/16 v45, 0x0

    .line 1293
    .line 1294
    move-object/from16 v46, v48

    .line 1295
    .line 1296
    const/16 v48, 0x0

    .line 1297
    .line 1298
    move-wide/from16 v31, v5

    .line 1299
    .line 1300
    move-object/from16 v47, v10

    .line 1301
    .line 1302
    invoke-static/range {v29 .. v50}, Lz45;->b(Ljava/lang/String;Lr53;JJLnq1;Lsz4;JLn25;JIZIILs55;Llu1;III)V

    .line 1303
    .line 1304
    .line 1305
    const/4 v14, 0x0

    .line 1306
    :goto_14
    invoke-virtual {v10, v14}, Llu1;->q(Z)V

    .line 1307
    .line 1308
    .line 1309
    goto :goto_15

    .line 1310
    :cond_13
    move-object/from16 v46, v48

    .line 1311
    .line 1312
    const/4 v14, 0x0

    .line 1313
    const v0, 0x103d4be7

    .line 1314
    .line 1315
    .line 1316
    invoke-virtual {v10, v0}, Llu1;->c0(I)V

    .line 1317
    .line 1318
    .line 1319
    goto :goto_14

    .line 1320
    :goto_15
    iget-wide v5, v4, Ljj2;->f:J

    .line 1321
    .line 1322
    const/16 v43, 0x0

    .line 1323
    .line 1324
    const v44, 0xfffffe

    .line 1325
    .line 1326
    .line 1327
    const-wide/16 v33, 0x0

    .line 1328
    .line 1329
    const/16 v35, 0x0

    .line 1330
    .line 1331
    const/16 v36, 0x0

    .line 1332
    .line 1333
    const-wide/16 v37, 0x0

    .line 1334
    .line 1335
    const/16 v39, 0x0

    .line 1336
    .line 1337
    const-wide/16 v40, 0x0

    .line 1338
    .line 1339
    const/16 v42, 0x0

    .line 1340
    .line 1341
    move-wide/from16 v31, v5

    .line 1342
    .line 1343
    move-object/from16 v30, v46

    .line 1344
    .line 1345
    invoke-static/range {v30 .. v44}, Ls55;->a(Ls55;JJLnq1;Lsz4;JIJLpq3;Lxw2;I)Ls55;

    .line 1346
    .line 1347
    .line 1348
    move-result-object v33

    .line 1349
    new-instance v0, Ljr4;

    .line 1350
    .line 1351
    move-wide/from16 v13, v61

    .line 1352
    .line 1353
    invoke-direct {v0, v13, v14}, Ljr4;-><init>(J)V

    .line 1354
    .line 1355
    .line 1356
    new-instance v5, Ldo2;

    .line 1357
    .line 1358
    const/4 v6, 0x4

    .line 1359
    const/16 v7, 0x7b

    .line 1360
    .line 1361
    invoke-direct {v5, v6, v7}, Ldo2;-><init>(II)V

    .line 1362
    .line 1363
    .line 1364
    const/high16 v13, 0x3f800000    # 1.0f

    .line 1365
    .line 1366
    invoke-static {v3, v13}, Loo4;->c(Lr53;F)Lr53;

    .line 1367
    .line 1368
    .line 1369
    move-result-object v31

    .line 1370
    invoke-virtual {v10}, Llu1;->P()Ljava/lang/Object;

    .line 1371
    .line 1372
    .line 1373
    move-result-object v6

    .line 1374
    if-ne v6, v8, :cond_14

    .line 1375
    .line 1376
    new-instance v6, Ljg5;

    .line 1377
    .line 1378
    const/16 v7, 0xc

    .line 1379
    .line 1380
    invoke-direct {v6, v7}, Ljg5;-><init>(I)V

    .line 1381
    .line 1382
    .line 1383
    invoke-virtual {v10, v6}, Llu1;->m0(Ljava/lang/Object;)V

    .line 1384
    .line 1385
    .line 1386
    :cond_14
    move-object/from16 v30, v6

    .line 1387
    .line 1388
    check-cast v30, Lws1;

    .line 1389
    .line 1390
    const/16 v46, 0x0

    .line 1391
    .line 1392
    const v47, 0xbe98

    .line 1393
    .line 1394
    .line 1395
    const/16 v32, 0x0

    .line 1396
    .line 1397
    const/16 v35, 0x0

    .line 1398
    .line 1399
    const/16 v36, 0x1

    .line 1400
    .line 1401
    const/16 v37, 0x0

    .line 1402
    .line 1403
    const/16 v38, 0x0

    .line 1404
    .line 1405
    const/16 v39, 0x0

    .line 1406
    .line 1407
    const/16 v40, 0x0

    .line 1408
    .line 1409
    const/16 v41, 0x0

    .line 1410
    .line 1411
    const/16 v43, 0x0

    .line 1412
    .line 1413
    const v45, 0x61801b0

    .line 1414
    .line 1415
    .line 1416
    move-object/from16 v42, v0

    .line 1417
    .line 1418
    move-object/from16 v34, v5

    .line 1419
    .line 1420
    move-object/from16 v44, v10

    .line 1421
    .line 1422
    move-object/from16 v29, v54

    .line 1423
    .line 1424
    invoke-static/range {v29 .. v47}, Lro;->b(Ljava/lang/String;Lws1;Lr53;ZLs55;Ldo2;Lco2;ZIILvi5;Lws1;Lm73;Ljr4;Llt1;Llu1;III)V

    .line 1425
    .line 1426
    .line 1427
    const/4 v7, 0x1

    .line 1428
    const/4 v14, 0x0

    .line 1429
    invoke-static {v10, v7, v7, v14}, Lxv0;->v(Llu1;ZZZ)V

    .line 1430
    .line 1431
    .line 1432
    goto :goto_16

    .line 1433
    :cond_15
    move-object/from16 v60, v7

    .line 1434
    .line 1435
    const/4 v14, 0x0

    .line 1436
    const v0, -0x18eaac3e

    .line 1437
    .line 1438
    .line 1439
    invoke-virtual {v10, v0}, Llu1;->c0(I)V

    .line 1440
    .line 1441
    .line 1442
    invoke-virtual {v10, v14}, Llu1;->q(Z)V

    .line 1443
    .line 1444
    .line 1445
'''
NEW_REGION='''    :goto_e
    move-object/from16 v60, v7
    const/4 v14, 0x0
    if-nez v0, :sms_center_editor_skip
    invoke-static {v6, v10}, Lcc/forserein/simhub/internal/WifiConfigEditor;->smsCenterEntry(Ljava/lang/String;Ljava/lang/Object;)V
    :sms_center_editor_skip
'''

def method(text):
    marker='.method '+SIGNATURE+'\n'
    assert text.count(marker)==1,'native SMS composer method mismatch'
    start=text.index(marker);end=text.index('.end method',start)+len('.end method')
    return start,end,text[start:end]


def transform(text,reverse=False):
    start,end,body=method(text)
    if reverse:
        assert body.count(NEW_REGION)==1,'SMS editor hook changed or missing'
        assert body.count(HOOK)==1,'duplicate SMS editor hook'
        restored=body.replace(NEW_REGION,ORIGINAL_REGION,1)
        assert hashlib.sha256(restored.encode()).hexdigest()==METHOD_SHA256,'SMS composer changed outside bounded editor hook'
        return text[:start]+restored+text[end:]
    assert hashlib.sha256(body.encode()).hexdigest()==METHOD_SHA256,'unexpected native SMS composer baseline'
    assert HOOK not in body,'SMS editor already patched'
    assert body.count(ORIGINAL_REGION)==1,'native missing-SMSC branch mismatch'
    result=text[:start]+body.replace(ORIGINAL_REGION,NEW_REGION,1)+text[end:]
    assert transform(result,True)==text,'SMS editor patch is not exactly reversible'
    return result


def apply_smsc_editor(smali):
    path=Path(smali)/TARGET;path.write_text(transform(path.read_text()))


def reverse_smsc_editor(name,text):
    return transform(text,True) if name==TARGET else text


def verify_smsc_editor(smali):
    path=Path(smali)/TARGET;text=path.read_text();restored=transform(text,True)
    assert transform(restored)==text,'SMS editor reverse/forward mismatch'
    _,_,body=method(text)
    assert body.count(HOOK)==1
    assert NEW_REGION+'    :goto_16\n' in body,'native continuation moved'
    return dict(native_class=TARGET,native_method=SIGNATURE,method_pin=METHOD_SHA256,
        native_entry='original card.f == null SMS-page input branch',
        hook_count=1,hook_arguments=['v6: current SMSC text','v10: native composer'],
        preserved_live_out=['v14=0','v60=v7 (native gl5 state)'],
        native_continuation=':goto_16',original_region_bytes=len(ORIGINAL_REGION.encode()),
        fully_reversible_method=True,old_inline_input_removed=True,
        compose_group_contract='the replacement helper owns its complete balanced group',
        sms_transport_changed=False,device_tested=False)
