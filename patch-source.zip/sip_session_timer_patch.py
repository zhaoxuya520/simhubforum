"""Bounded RFC4028 timer repair. Does not replace SIP transactions or media code."""
from pathlib import Path
import hashlib,json
SIP_CLASSES={'cb4.smali','o82.smali','ma4.smali'}
EDITS=[('cb4.smali', 'public static c(Lkb4;Lkb4;Lma4;)V', '    .line 75\n    iget-object v5, p2, Lma4;->a:Lga4;\n\n    .line 76\n    .line 77\n    sget-object v6, Lga4;->T:Lga4;\n\n    .line 78\n    .line 79\n    if-ne v5, v6, :cond_2\n\n    .line 80\n    .line 81\n    move v5, v1\n\n    .line 82\n    goto :goto_0\n\n    .line 83\n    :cond_2\n    move v5, v4\n\n    .line 84\n    :goto_0\n    if-ne v2, v5, :cond_3\n\n    .line 85\n    .line 86\n    goto :goto_1\n\n    .line 87\n    :cond_3\n    move v1, v4\n\n    .line 88\n    :goto_1\n    iput-boolean v1, p2, Lma4;->C:Z\n\n', '    # Received UPDATE/re-INVITE: local endpoint is UAS for this transaction.\n    iput-boolean v2, p2, Lma4;->C:Z\n\n'), ('o82.smali', 'public static final a(Lo82;)Z', '    .line 606\n    sget-object v4, Lga4;->U:Lga4;\n\n    .line 607\n    .line 608\n    if-ne v15, v4, :cond_f\n\n    .line 609\n    .line 610\n    const-string v4, "uac"\n\n    .line 611\n    .line 612\n    goto :goto_9\n\n    .line 613\n    :cond_f\n    const-string v4, "uas"\n\n    .line 614\n    .line 615\n    :goto_9\n', '    # This endpoint sends the refresh UPDATE and is therefore its UAC.\n    const-string v4, "uac"\n\n'), ('o82.smali', 'public final h(Lkb4;)Z', '    if-ne v0, v10, :cond_16\n\n    .line 540', '    if-ne v0, v10, :cond_16\n\n    invoke-static {v1, v3, v8, v9}, Lcb4;->sipApplyRefreshResponse(Lkb4;Lma4;D)V\n\n    .line 540'), ('cb4.smali', 'public final k(Ljava/lang/String;Lma4;[B)Lkb4;', '    iput v1, p2, Lma4;->h:I', '    iput v1, p2, Lma4;->h:I\n\n    const-string v3, "UPDATE"\n    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z\n    move-result v3\n    if-eqz v3, :sip_pending_cseq_ready\n    iput v1, p2, Lma4;->sipPendingRefreshCSeq:I\n    :sip_pending_cseq_ready'), ('cb4.smali', 'public static c(Lkb4;Lkb4;Lma4;)V', '    invoke-virtual {p1, v0}, Lkb4;->j(Ljava/lang/String;)Ljava/util/ArrayList;\n\n    .line 4\n    .line 5\n    .line 6\n    move-result-object p1\n\n    .line 7\n    invoke-static {p1}, Lyk0;->C0(Ljava/util/List;)Ljava/lang/Object;\n\n    .line 8\n    .line 9\n    .line 10\n    move-result-object p1\n\n    .line 11\n', '    invoke-virtual {p1, v0}, Lkb4;->j(Ljava/lang/String;)Ljava/util/ArrayList;\n    move-result-object v5\n    invoke-static {v5}, Lyk0;->C0(Ljava/util/List;)Ljava/lang/Object;\n    move-result-object v5\n    if-nez v5, :sip_request_timer_header_ready\n    const-string v6, "x"\n    invoke-virtual {p1, v6}, Lkb4;->j(Ljava/lang/String;)Ljava/util/ArrayList;\n    move-result-object v5\n    invoke-static {v5}, Lyk0;->C0(Ljava/util/List;)Ljava/lang/Object;\n    move-result-object v5\n    :sip_request_timer_header_ready\n    move-object p1, v5\n\n'), ('cb4.smali', 'public static c(Lkb4;Lkb4;Lma4;)V', '    invoke-virtual {p1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z', '    invoke-virtual {p1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z')]
METHOD_PINS={('cb4.smali', 'public static c(Lkb4;Lkb4;Lma4;)V'): '4c861e4e208e1cd2ada5466fc77dbce2909272a2faabf5dee2ad8b0705c6afc5', ('o82.smali', 'public static final a(Lo82;)Z'): '4075f7501c8aab28fa0a86999c5df697a3e6d4b9f7675975161b5defb892bb20', ('o82.smali', 'public final h(Lkb4;)Z'): '74d6ee0df50c7a4b88af529456f9d6cdf983e110745c45a8938c1027fb465ba7', ('cb4.smali', 'public final k(Ljava/lang/String;Lma4;[B)Lkb4;'): '0dc7d2f5fe8e9a5d72f66751a9837ff2e39fce10d5b5eec4d5a6dd6a072ec70f'}
RESPONSE_HELPER='\n.method public static sipApplyRefreshResponse(Lkb4;Lma4;D)V\n    .locals 4\n    iget v0, p1, Lma4;->sipPendingRefreshCSeq:I\n    if-lez v0, :sip_timer_done\n    invoke-virtual {p0}, Lkb4;->e()Lfa4;\n    move-result-object v1\n    if-eqz v1, :sip_timer_done\n    iget v1, v1, Lfa4;->a:I\n    if-ne v0, v1, :sip_timer_done\n    const-string v0, "Session-Expires"\n    invoke-virtual {p0, v0}, Lkb4;->j(Ljava/lang/String;)Ljava/util/ArrayList;\n    move-result-object v0\n    invoke-static {v0}, Lyk0;->C0(Ljava/util/List;)Ljava/lang/Object;\n    move-result-object v0\n    check-cast v0, Ljava/lang/String;\n    if-nez v0, :sip_timer_present\n    const-string v0, "x"\n    invoke-virtual {p0, v0}, Lkb4;->j(Ljava/lang/String;)Ljava/util/ArrayList;\n    move-result-object v0\n    invoke-static {v0}, Lyk0;->C0(Ljava/util/List;)Ljava/lang/Object;\n    move-result-object v0\n    check-cast v0, Ljava/lang/String;\n    if-nez v0, :sip_timer_present\n    # RFC 4028 sections 7.2/9: no header in latest 2xx disables expiration.\n    const/4 v0, 0x0\n    iput-object v0, p1, Lma4;->B:Ljava/lang/Integer;\n    iput-boolean v0, p1, Lma4;->C:Z\n    goto :sip_timer_time\n    :sip_timer_present\n    const/16 v1, 0x3b\n    invoke-virtual {v0, v1}, Ljava/lang/String;->indexOf(I)I\n    move-result v1\n    if-ltz v1, :sip_timer_no_params\n    const/4 v2, 0x0\n    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;\n    move-result-object v1\n    goto :sip_timer_parse\n    :sip_timer_no_params\n    move-object v1, v0\n    :sip_timer_parse\n    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;\n    move-result-object v1\n    invoke-static {v1}, Lyv4;->f0(Ljava/lang/String;)Ljava/lang/Integer;\n    move-result-object v1\n    if-eqz v1, :sip_timer_done\n    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I\n    move-result v2\n    const/16 v3, 0x5a\n    if-lt v2, v3, :sip_timer_done\n    const-string v2, "refresher"\n    invoke-static {v2, v0}, Ljb4;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;\n    move-result-object v0\n    if-nez v0, :sip_timer_role_present\n    # Match PJSIP\'s fallback for a peer omitting the mandatory response role.\n    const-string v0, "uac"\n    :sip_timer_role_present\n    const-string v2, "uac"\n    invoke-virtual {v2, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z\n    move-result v2\n    if-nez v2, :sip_timer_commit\n    const-string v3, "uas"\n    invoke-virtual {v3, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z\n    move-result v3\n    if-eqz v3, :sip_timer_done\n    :sip_timer_commit\n    iput-object v1, p1, Lma4;->B:Ljava/lang/Integer;\n    iput-boolean v2, p1, Lma4;->C:Z\n    :sip_timer_time\n    const/4 v0, 0x0\n    iput v0, p1, Lma4;->sipPendingRefreshCSeq:I\n    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;\n    move-result-object v0\n    iput-object v0, p1, Lma4;->E:Ljava/lang/Double;\n    :sip_timer_done\n    return-void\n.end method\n'
PENDING_FIELD='.field public sipPendingRefreshCSeq:I\n\n'

def _method(text,signature):
 start=text.index('.method '+signature)
 end=text.index('.end method',start)+len('.end method')
 return start,end,text[start:end]

def _edit(text,signature,old,new):
 start,end,body=_method(text,signature)
 assert body.count(old)==1,signature+' expected unique hook'
 return text[:start]+body.replace(old,new)+text[end:]

def reverse_sip_session_timer(name,text):
 if name=='ma4.smali':
  assert text.count(PENDING_FIELD)==1
  text=text.replace(PENDING_FIELD,'')
 if name=='cb4.smali':
  assert text.endswith(RESPONSE_HELPER),'timer helper changed'
  text=text[:-len(RESPONSE_HELPER)]
 for target,sig,old,new in reversed(EDITS):
  if target==name:text=_edit(text,sig,new,old)
 for (target,sig),digest in METHOD_PINS.items():
  if target==name:assert hashlib.sha256(_method(text,sig)[2].encode()).hexdigest()==digest,sig+' native code changed beyond bounded hook'
 return text

def apply_sip_session_timer(smali):
 for name in SIP_CLASSES:
  p=Path(smali)/name;text=p.read_text()
  for (target,sig),digest in METHOD_PINS.items():
   if target==name:assert hashlib.sha256(_method(text,sig)[2].encode()).hexdigest()==digest,sig+' unexpected baseline'
  for target,sig,old,new in EDITS:
   if target==name:text=_edit(text,sig,old,new)
  if name=='ma4.smali':text=text.replace('# instance fields',PENDING_FIELD+'# instance fields',1)
  if name=='cb4.smali':text+=RESPONSE_HELPER
  p.write_text(text)

def verify_sip_session_timer(smali):
 for name in SIP_CLASSES:reverse_sip_session_timer(name,(Path(smali)/name).read_text())
 return {'native_methods':['cb4.c','cb4.k','o82.a','o82.h'], 'helper':'cb4.sipApplyRefreshResponse',
  'incoming_refresh_role':'local UAS regardless of initial call direction',
  'outgoing_refresh_role':'local UAC regardless of initial call direction',
  'successful_update':'apply interval/refresher/receipt time even without SDP; absent header disables timer',
  'transaction_matching':'latest locally generated UPDATE CSeq; consume once, unaffected by INFO',
  'compact_header':'Session-Expires and x/X accepted for received requests and UPDATE responses',
  'request_refresher':'case-insensitive uas/uac; existing default/response echo preserved',
  'malformed_response':'ignored without changing existing timer state',
  'ui_changed':False,'media_changed':False,'device_carrier_verified':False}

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('smali',type=Path);p.add_argument('--verify-only',action='store_true');p.add_argument('--report',type=Path)
 a=p.parse_args()
 if not a.verify_only:apply_sip_session_timer(a.smali)
 result=verify_sip_session_timer(a.smali)
 if a.report:a.report.write_text(json.dumps(result,indent=2)+'\n')
 print('PASS: bounded RFC4028 timer role/response hooks; remaining native methods restored exactly')
