"""Make local hangup and decline idempotent while the native dialog is terminating."""
import hashlib
from pathlib import Path

# Each method already returns an empty action list for a finished (Y) dialog.
# Reuse that return for a terminating (X) dialog before rewriting its timer or emitting events.
METHODS = {
    "j": ("v1", "v2", "cc0bc624ca22c8400b8498bbc181dbf3d16c73fdcda54b58f100a1f2ba01851f"),
    "g": ("v0", "v1", "283a9a5ea4873a6fa8b9eeb87758064f27f09820bec939736f8ad5ade062aa90"),
}


def transform(text, restore):
    for name, (state, constant, digest) in METHODS.items():
        start = text.index(f".method public final {name}(Ljava/lang/String;D)Ljava/util/List;")
        end = text.index(".end method", start) + len(".end method")
        body = text[start:end]
        old = f"    sget-object {constant}, Lla4;->Y:Lla4;"
        added = (f"    sget-object {constant}, Lla4;->X:Lla4;\n"
                 f"    if-eq {state}, {constant}, :goto_0\n\n")
        if restore:
            assert body.count(added + old) == 1
            body = body.replace(added + old, old)
        assert hashlib.sha256(body.encode()).hexdigest() == digest, f"native cb4.{name} changed"
        if not restore:
            assert body.count(old) == 1
            body = body.replace(old, added + old)
        text = text[:start] + body + text[end:]
    return text


def apply_local_end(smali):
    path = Path(smali) / "cb4.smali"
    path.write_text(transform(path.read_text(), restore=False))


def reverse_local_end(text):
    return transform(text, restore=True)
