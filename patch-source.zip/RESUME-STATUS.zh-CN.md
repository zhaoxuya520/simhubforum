## 最新交付状态：长期签名已重新生成

用户明确授权生成新签名、更新应用自检并将强密码加密的 PKCS#12 上传到其公开 GitHub 仓库，密码单独交付。新 SHA-1：CAEAEE369CA8933EC6A80050ECAF22D87B155006；别名 simhub-longterm。新签名包已通过 v2/v3、应用内信任、内容一致性和对齐检查。以下“缺少旧密钥”的记录为历史情况；本次按卸载旧版后安装处理。详见 LONGTERM-SIGNING.zh-CN.md。

# 接续状态（2026-11-11）

已核验恢复 fix2-config2 源码 ZIP 和已交付 APK，下载哈希均与交接一致。

## 当前源码变更（尚未实机验证）

- 配置弹窗继续使用原渲染器，补充内置默认值、用户覆盖值、校验归一化后的保存生效预览。非法输入明确不可保存；取消、恢复本组、页面完成的草稿语义保留。
- 新增 MultiChipSwitch 与 InternalSimMultiChipSwitch：在原控制器 C 的忙碌保护内依次扫描所有已识别芯片，再禁用除目标以外的启用配置（复用原 hz3 并等待确认），最后启用目标，并重新读取全部芯片核实只有目标启用。禁用操作不互斥其他芯片。读取失败、取消和变更失败停止，不重发变更命令；失败恢复目标芯片的界面选择，不自动回滚卡内状态。USB/蓝牙仍走原 hz3。
- IdentityBinding 将管理控制器与读取身份关联，记录 reader、可获得时的通道号、EID/ICCID 尾号、IMSI 前五位、NAI/EAP 脱敏值及覆盖来源。实际 ICCID 与所选芯片的启用 Profile 不匹配时，经原读卡失败路径停止，避免把错误卡片当作所选配置。普通实体 SIM 没有 Profile 时不作运营商推断。
- 本机卡槽不再命中 zl5.d 中同 transport 的旧身份快速返回，重新读卡。已确认代码存在该缓存机制，但尚未确认它就是 DITO 20404 身份的实机根因。通用 USIM AID 仍交由 Android OMAPI 选择；如果物理激活状态和通道身份不一致，补丁会报告错误，不会伪造 51566 身份。

## 验证

- 351 项 JVM 断言通过，含 36 项跨芯片事务、8 项身份绑定/脱敏，以及原配置/UI/OMAPI 等检查。
- 原 hz3 的 10 项流程模拟通过；新包装协程的 6 项模拟覆盖同步、挂起、失败、取消、USB 回退。
- 新调用的 10 个辅助方法描述符与生成 Smali 定义一致。
- 恢复官方 Android API 35 / Build Tools 35.0.0，下载哈希与原 tool-provenance.json 相符。
- build_from_config2.py 固定校验上一交付 APK，生产源码使用真实 android.jar 编译，经 D8、Smali 重建、16 KB 对齐及 ZIP 完整性检查。已有原应用类仅 cg0、iz3、zl5 改变（辅助补丁类除外），所有非 DEX 内容与固定基线相同。
- 未签名候选 APK SHA-256：a3dc3420ffd89fdc6f8182732ad6b9b8451c02fb4896d11c9c4e8771166bbdc1
- 尚无 Android ART、一加手机实测、实际 AKA 或运营商注册验证。测试替身未进入 APK。

## 构建与剩余工作

固定交付基线重建入口：python3 build_from_config2.py。原 build.py 仍要求固定哈希的原始 APK；apply_patch.py 已接入新补丁，verify.py 已同步新类/变更范围，尚因原始文件缺失不能执行原包对比验证。

缺少原始 SIMHub-Android-23.1.apk 与 /workspace/simhub-signing/simhub-local-test.p12、keystore-password。签名必须继续使用 SHA-1 6F92BF00AF155C4ADA27936451F95ED2F703039C 对应的私钥，不可另造签名。没有发布、上传或生成新签名包。

后续先通过环境安全文件恢复签名，再增加候选包签名验证；实机核实跨芯片来回切换、失败/取消状态、DITO 所选 Profile 与读卡日志身份一致性。DITO 网络注册不应标记为已解决。

## 全球标准模板扩充（随后完成）

已接入 carrier_presets_patch.py，完整保留原预设/规则，增加 2264 个未验证的 PLMN 标准模板。APK 合计 3607 条预设、4133 条规则、3117 个不同 PLMN，包含 DITO 51566。九组数据测试及 APK 内资产比对通过；重新完成生产编译、重建与对齐。非 DEX 变化现在额外包含 carrier_presets.json 和新增 global_standard_catalogue.json。标准模板不代表运营商已确认或支持 Wi-Fi 通话；详见 GLOBAL-PRESETS.zh-CN.md。仍未签名或发布。

## 当前编辑逻辑澄清

内置不可改写，自定义覆盖输入与当前已保存/本次预览分开。按钮改为暂存修改、恢复本项/本组内置；原内联应用按钮只暂存提示，右上角完成统一保存。145 项配置/UI 回调断言通过；生产重建、对齐及 APK 中中文提示和 stageCallback 描述符核验通过。新增 dm5 Smali 调整，中文占位及 IMEI 帮助更新；原布局不变。详细交互见 CONFIG-REVIEW.zh-CN.md。未签名、未发布、未实机验证。
