#!/usr/bin/env python3
"""Sign only the validated, pinned-config2 rebuild; verify signer, payload and self-check."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,zipfile
from signing_policy import expected_allowlist,test_signer_digest,ORIGINAL_ALLOWLIST,DELIVERED_CONFIG2_SIGNER
from verify_signed import dex_strings
ROOT=Path(__file__).resolve().parent
TOOLS=Path('/workspace/tools/android-recovery')
B=ROOT/'build-config3'

def verify_candidate():
    report=json.loads((B/'candidate-validation.json').read_text())
    unsigned=B/'SIMHub-23.1-config3-unsigned.apk'
    assert report['base_apk_sha256']=='cdd748532360f5632dc5661c0e8d9c9907967a0a136be16dfde118de43ad81c2'
    assert hashlib.sha256(unsigned.read_bytes()).hexdigest()==report['unsigned_apk_sha256'],'Unsigned candidate changed after validation'
    for name,digest in report['source_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,'Source changed after build: '+name
    assert report['signer_sha256']==test_signer_digest()
    with zipfile.ZipFile(unsigned)as z:
        strings=set(dex_strings(z.read('classes.dex')))
        assert expected_allowlist().encode() in strings,'Self-check does not include new signer'
        assert (ORIGINAL_ALLOWLIST+','+DELIVERED_CONFIG2_SIGNER).encode() not in strings,'Old local signer still accepted'
        assert z.testzip() is None
    return unsigned,report

def verify_signed(signed,unsigned,report):
    output=subprocess.check_output(['java','-jar',str(TOOLS/'sdk/android-15/lib/apksigner.jar'),'verify','--verbose','--print-certs',str(signed)],text=True)
    signers=re.findall(r'^Signer #\d+ certificate SHA-256 digest: ([0-9a-f]{64})$',output,re.M)
    assert signers==[test_signer_digest()],'Actual signer does not match new public certificate'
    for scheme in ('v2','v3'):
        assert re.search(r'^Verified using '+scheme+r' scheme .*: true$',output,re.M),'Signature scheme failed: '+scheme
    with zipfile.ZipFile(signed)as z,zipfile.ZipFile(unsigned)as base:
        assert z.testzip() is None
        assert set(z.namelist())==set(base.namelist())
        for name in base.namelist():assert z.read(name)==base.read(name),'Signed payload changed: '+name
        assert expected_allowlist().encode() in set(dex_strings(z.read('classes.dex')))
    subprocess.run([str(TOOLS/'sdk/android-15/zipalign'),'-c','-P','16','4',str(signed)],check=True)
    report.update(signed_apk_sha256=hashlib.sha256(signed.read_bytes()).hexdigest(),signer_sha1=re.search(r'^Signer #1 certificate SHA-1 digest: ([0-9a-f]{40})$',output,re.M)[1].upper(),signature_v2=True,signature_v3=True,self_check_trusts_actual_signer=True,signed_payload_unchanged=True)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--keystore',type=Path,required=True);p.add_argument('--alias',required=True);p.add_argument('--password-file',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    unsigned,report=verify_candidate()
    a.out.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(['java','-jar',str(TOOLS/'sdk/android-15/lib/apksigner.jar'),'sign','--v1-signing-enabled','false','--v2-signing-enabled','true','--v3-signing-enabled','true','--v4-signing-enabled','false','--ks',str(a.keystore),'--ks-key-alias',a.alias,'--ks-pass','file:'+str(a.password_file),'--out',str(a.out),str(unsigned)],check=True)
    result=verify_signed(a.out,unsigned,report)
    (B/'longterm-signed-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='source_sha256' and k!='changed_existing_classes'},indent=2))
