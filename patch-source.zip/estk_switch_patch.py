"""Coordinate the discovered eSTK SE0/SE1 pair; preserve ordinary switch routes."""
from pathlib import Path
import hashlib
from estk_io_patch import apply_estk_io, restore_estk_pg1, verify_estk_io

ROOT = Path(__file__).resolve().parent
HZ3_SHA256 = 'b8cd737d588eec6e5b02d89d14fad6f22d3ba78e7a3a214d4e1a936e45e84905'
SIGNATURE = '.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;\n'
ORIGINAL = '''    .locals 0

    .line 1
    check-cast p1, Lhh1;

    .line 2
    .line 3
    check-cast p2, Lct0;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, Lhz3;->o(Lct0;Ljava/lang/Object;)Lct0;
'''
PATCHED = '''    .locals 3

    .line 1
    check-cast p1, Lhh1;

    .line 2
    .line 3
    check-cast p2, Lct0;

    # ESTK_BOUND_SWITCH_BEGIN
    iget-object v0, p0, Lhz3;->b0:Liz3;
    iget-object v1, p0, Lhz3;->c0:Lqy3;
    iget-boolean v2, p0, Lhz3;->d0:Z
    invoke-static {v0, p1, v1, v2}, Lcc/forserein/simhub/internal/EstkSwitchPlan;->tryCreate(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Lcc/forserein/simhub/internal/EstkSwitchPlan;
    move-result-object v0
    if-eqz v0, :native_switch
    new-instance v1, LInternalEstkSwitch;
    invoke-direct {v1, v0, p1, p2}, LInternalEstkSwitch;-><init>(Lcc/forserein/simhub/internal/EstkSwitchPlan;Lhh1;Lct0;)V
    sget-object v2, Lsc5;->a:Lsc5;
    invoke-virtual {v1, v2}, LInternalEstkSwitch;->q(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
    :native_switch
    # ESTK_BOUND_SWITCH_END
    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, Lhz3;->o(Lct0;Ljava/lang/Object;)Lct0;
'''
FILES = ('InternalEstkAccess.smali', 'InternalEstkCommand.smali',
         'InternalEstkRequest.smali', 'InternalEstkSwitch.smali')


def restore_estk_hz3(text):
    if PATCHED in text:
        assert text.count(PATCHED) == 1
        text = text.replace(PATCHED, ORIGINAL)
    assert 'ESTK_BOUND_SWITCH' not in text
    assert hashlib.sha256(text.encode()).hexdigest() == HZ3_SHA256, 'hz3 changed outside eSTK entry dispatch'
    return text


def apply_estk_switch(smali):
    smali = Path(smali)
    path = smali / 'hz3.smali'
    text = path.read_text()
    restore_estk_hz3(text)
    if PATCHED not in text:
        start = text.index(SIGNATURE)
        end = text.index('.end method', start)
        assert text[start:end].count(ORIGINAL) == 1, 'native switch entry changed'
        path.write_text(text[:start] + text[start:end].replace(ORIGINAL, PATCHED) + text[end:])
    apply_estk_io(smali)
    for name in FILES:
        (smali / name).write_bytes((ROOT / 'smali' / name).read_bytes())
    verify_estk_switch(smali)


def verify_estk_switch(smali):
    smali = Path(smali)
    text = (smali / 'hz3.smali').read_text()
    assert text.count(PATCHED) == 1
    restore_estk_hz3(text)
    io = verify_estk_io(smali)
    for name in FILES:
        assert (smali / name).read_bytes() == (ROOT / 'smali' / name).read_bytes(), name
    return {'native_classes': ['hz3.smali', 'pg1.smali'], 'new_classes': list(FILES),
            'hz3_restored_sha256': HZ3_SHA256, 'io': io,
            'scope': 'one captured reader exposing exactly eSTK SE0 and SE1 management AIDs',
            'native_non_estk_and_hz3_q_unchanged': True,
            'commands': 'fresh both SEs before enable; disable sibling first; one target BF31; manual off target only',
            'readback': 'explicit immutable AID and verified EID; code2 accepted only after matching fresh state',
            'writes_never_retried': True, 'logical_channel_policy_flags_unchanged': True,
            'physical_card_tested': False}
