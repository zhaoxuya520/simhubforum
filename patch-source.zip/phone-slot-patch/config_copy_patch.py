"""Clarify the existing inline override placeholders without changing layout."""
from pathlib import Path
import re

def apply_config_copy(decoded):
    path=Path(decoded)/'assets/i18n/zh-Hans.strings'
    text=path.read_text()
    labels={'vowifi_sms_imei_hint':'',
            'vowifi_sms_custom_epdg':'ePDG',
            'vowifi_sms_imei':'IMEI',
            'vowifi_sms_smsc_override':'短信中心',
            'vowifi_sms_smsc_override_hint':''}
    for key,value in labels.items():
        text,count=re.subn(r'^"'+re.escape(key)+r'" = ".*";$','"'+key+'" = "'+value+'";',text,flags=re.M)
        if count==0 and key.endswith("_hint"):text+='\n"'+key+'" = "'+value+'";\n'
        else:assert count==1,key
    path.write_text(text)

    # Remove the obsolete mismatch card, including its icon/container, at the render branch.
    path=Path(decoded)/'smali/fd2.smali'
    text=path.read_text()
    marker='    const-string v3, "vowifi_sms_profile_mismatch"'
    assert text.count(marker)==1
    end=text.index(marker)
    start=text.rfind('    if-eqz v25, :cond_14',0,end)
    assert start>=0 and end-start<7000
    text=text[:start]+text[start:].replace('    if-eqz v25, :cond_14','    goto/16 :cond_14',1)
    path.write_text(text)
    for locale in ('zh-Hans','zh-Hant'):
        path=Path(decoded)/('assets/i18n/'+locale+'.strings')
        text=path.read_text()
        text,count=re.subn(r'^"vowifi_sms_profile_mismatch" = ".*";$','"vowifi_sms_profile_mismatch" = "";',text,flags=re.M)
        assert count==1
        path.write_text(text)
