from pathlib import Path
import re

def _edit_method_with(smali, filename, anchor, edit):
    path=Path(smali)/filename;text=path.read_text()
    assert text.count(anchor)==1,(filename,anchor)
    at=text.index(anchor);start=text.rfind('.method ',0,at);end=text.index('.end method',at)
    body='\n'.join(line for line in text[start:end].splitlines() if not line.strip().startswith('.line'))+'\n'
    path.write_text(text[:start]+edit(body)+text[end:])

def patch_effective_smsc(smali):
    # These details renderers used card.f directly even while the sender used an override.
    def detail(body):
        old='''    iget-object v3, v8, Lek5;->f:Ljava/lang/String;

    if-eqz v3, :cond_9

    const-string v4, "+"

    invoke-virtual {v4, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3'''
        pattern=r'    iget-object v3, v8, Lek5;->f:Ljava/lang/String;\s+if-eqz v3, :cond_9\s+const-string v4, "\+"\s+invoke-virtual \{v4, v3\}, Ljava/lang/String;->concat\(Ljava/lang/String;\)Ljava/lang/String;\s+move-result-object v3'
        body,n=re.subn(pattern,'    invoke-static {v8}, Lcc/forserein/simhub/internal/WifiConfigRuntime;->displaySmsCenter(Ljava/lang/Object;)Ljava/lang/String;\n    move-result-object v3\n    if-eqz v3, :cond_9',body)
        assert n==1;return body
    _edit_method_with(smali,'fd2.smali','    iget-object v3, v8, Lek5;->f:Ljava/lang/String;',detail)
    def subtitle(body):
        pattern=r'    iget-object v2, v2, Lek5;->f:Ljava/lang/String;\s+if-eqz v2, :cond_1\s+const-string v3, "\+"\s+invoke-virtual \{v3, v2\}, Ljava/lang/String;->concat\(Ljava/lang/String;\)Ljava/lang/String;\s+move-result-object v2'
        body,n=re.subn(pattern,'    invoke-static {v2}, Lcc/forserein/simhub/internal/WifiConfigRuntime;->displaySmsCenter(Ljava/lang/Object;)Ljava/lang/String;\n    move-result-object v2\n    if-eqz v2, :cond_1',body)
        assert n==1;return body
    _edit_method_with(smali,'i21.smali','    iget-object v2, v2, Lek5;->f:Ljava/lang/String;',subtitle)

def patch_owned_alert_buttons(smali):
    path=Path(smali)/'xq0.smali';text=path.read_text()
    signature='.method public static final b(Lcj2;Lr53;Llu1;I)V'
    start=text.index(signature);local_end=text.index('\n',text.index('    .locals ',start))
    hook='''
    move-object/from16 v0, p0
    move-object/from16 v1, p1
    move-object/from16 v2, p2
    move/from16 v3, p3
    invoke-static {v0, v1, v2, v3}, Lcc/forserein/simhub/internal/WifiConfigEditor;->renderButton(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)Z
    move-result v4
    if-eqz v4, :original_alert_button
    return-void
    :original_alert_button
'''
    assert ':original_alert_button'not in text
    path.write_text(text[:local_end]+hook+text[local_end:])

def patch_editor_flow(text):
    old='    move-object v3, v0'
    assert text.count(old)==1
    return text.replace(old,old+'\n    invoke-static {v3}, Lcc/forserein/simhub/internal/WifiConfigEditor;->stageCallback(Ljava/lang/Object;)Ljava/lang/Object;\n    move-result-object v3\n    check-cast v3, Lus1;')

def apply_editor_flow(smali):
    p=Path(smali)/'dm5.smali'
    p.write_text(patch_editor_flow(p.read_text()))

    # Replace inline network/device editors with the same compact field/list popup.
    p=Path(smali)/'rt.smali'
    text=p.read_text()
    signature='.method public final d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;'
    start=text.index(signature)
    locals_end=text.index('\n',text.index('    .locals ',start))
    hook='\n    move-object/from16 v0, p0\n    iget v0, v0, Lrt;->T:I\n    move-object/from16 v1, p2\n    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/WifiConfigEditor;->listSection(ILjava/lang/Object;)Z\n    move-result v2\n    if-eqz v2, :compact_config_original\n    sget-object v0, Lsc5;->a:Lsc5;\n    return-object v0\n    :compact_config_original\n'
    text=text[:locals_end]+hook+text[locals_end:]
    p.write_text(text)
    p=Path(smali)/'dm5.smali'
    text=p.read_text()
    signature='.method public final d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;'
    start=text.index(signature)
    locals_end=text.index('\n',text.index('    .locals ',start))
    hook='\n    move-object/from16 v0, p0\n    iget v0, v0, Ldm5;->T:I\n    if-nez v0, :compact_epdg_original\n    const/16 v0, 0x14\n    move-object/from16 v1, p2\n    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/WifiConfigEditor;->listSection(ILjava/lang/Object;)Z\n    move-result v2\n    if-eqz v2, :compact_epdg_original\n    sget-object v0, Lsc5;->a:Lsc5;\n    return-object v0\n    :compact_epdg_original\n'
    text=text[:locals_end]+hook+text[locals_end:]
    anchor='    if-ne v0, v1, :cond_6'
    assert text.count(anchor)==1
    p.write_text(text.replace(anchor,'    goto/16 :cond_6'))
    # An explicitly emptied SMSC list must not re-add a deleted card default when sending.
    p=Path(smali)/'zl5.smali'
    text=p.read_text()
    start=text.index('.method public final w(Ljava/lang/String;Ljava/lang/String;Ldt0;)Ljava/lang/Object;')
    end=text.index('.end method',start)
    body=text[start:end]
    anchor='    :try_start_1\n'
    assert body.count(anchor)==1
    body=body.replace(anchor,anchor+'    invoke-static {}, Lcc/forserein/simhub/internal/WifiConfigRuntime;->requireSmsCenter()V\n',1)
    p.write_text(text[:start]+body+text[end:])
    patch_effective_smsc(smali)
    patch_owned_alert_buttons(smali)
