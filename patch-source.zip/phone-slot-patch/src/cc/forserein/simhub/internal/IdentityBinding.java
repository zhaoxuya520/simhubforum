package cc.forserein.simhub.internal;

import java.util.*;
import java.lang.ref.WeakReference;
import android.util.Log;

/** Keeps USIM read generations separate; management selections are diagnostic only. */
public final class IdentityBinding {
    private static final class Selection {
        final String eid,iccid;final boolean managed;
        Selection(String eid,String iccid,boolean managed){this.eid=eid;this.iccid=iccid;this.managed=managed;}
    }
    private static final Map<Object,Selection> selections=new WeakHashMap<>();
    private static final Map<Object,Selection> reads=new WeakHashMap<>();
    private static final Map<Object,WeakReference<Object>> latest=new WeakHashMap<>();
    public static synchronized void track(Object transport,Object controller){
        if(transport==null)return;
        try {
            String eid=String.valueOf(call(controller,"r")),expected=null;
            List<?> chips=(List<?>)call(controller,"l");
            for(Object chip:chips)if(eid.equals(get(chip,"b"))) {
                for(Object p:(List<?>)get(chip,"d"))if(Boolean.TRUE.equals(get(p,"b"))) {
                    expected=String.valueOf(get(p,"a"));
                }
            }
            selections.put(transport,new Selection(eid,expected,!chips.isEmpty()));
        }catch(Exception e){selections.put(transport,new Selection(null,null,true));}
    }
    /** Copy values, not a weak controller reference, before the first asynchronous APDU. */
    public static synchronized void begin(Object transport,Object auth){
        Selection selection=selections.get(transport);
        reads.put(auth,selection);latest.put(transport,new WeakReference<>(auth));
    }
    public static synchronized boolean current(Object transport,Object auth){
        WeakReference<Object> ref=latest.get(transport);return ref==null||ref.get()==auth;
    }
    public static synchronized boolean publish(Object transport,Object auth,Object flow,Object expected,Object updated)throws Exception {
        if(!current(transport,auth))return false;
        return Boolean.TRUE.equals(flow.getClass().getMethod("h",Object.class,Object.class).invoke(flow,expected,updated));
    }
    public static synchronized boolean publishError(Object transport,Object auth,Object flow,Object expected,Object updated)throws Exception {
        if(!current(transport,auth))return false;
        return Boolean.TRUE.equals(flow.getClass().getMethod("h",Object.class,Object.class).invoke(flow,expected,updated));
    }
    public static synchronized boolean needsRead(Object transport){Selection s=selections.get(transport);return s!=null&&s.managed;}
    private static Object get(Object o,String name)throws Exception{return o.getClass().getField(name).get(o);}
    private static Object call(Object o,String name)throws Exception{return o.getClass().getMethod(name).invoke(o);}
    public static String tail(String value){if(value==null)return "unknown";return "…"+value.substring(Math.max(0,value.length()-4));}
    public static void read(Object transport,Object auth,Object card)throws Exception {
        Selection selection;
        synchronized(IdentityBinding.class){if(!current(transport,auth))throw new IllegalStateException("该次读卡已过期，请使用最新读卡结果");selection=reads.containsKey(auth)?reads.get(auth):selections.get(transport);}
        String actual=String.valueOf(get(card,"b"));
        String imsi=String.valueOf(get(card,"a"));
        String expected=selection==null?null:selection.iccid,eid=selection==null?null:selection.eid;
        String reader="unknown";try{reader=String.valueOf(get(transport,"f"));}catch(Exception ignored){}
        String channel="unknown";try{Object logical=get(auth,"e");Object omapi=get(logical,"a");channel=String.valueOf(call(omapi,"getChannelNumber"));}catch(Exception ignored){}
        String prefix=imsi.matches("[0-9]{5,15}")?imsi.substring(0,5):"invalid";
        Log.e("SIMHubIdentity","USIM read reader="+reader+" channel="+channel+" EID="+tail(eid)+" selectedICCID="+tail(expected)+" actualICCID="+tail(actual)+" IMSI-prefix="+prefix);
        // A management page can select an inactive chip or retain a stale profile list.
        // The actual USIM read supplies the identity used by the native authentication path.
    }
    /** Keep identities private: retain only identity type, PLMN prefix and realm. */
    public static String identity(String value) {
        if(value==null||value.isEmpty())return "builtin";
        int at=value.indexOf('@');String user=at<0?value:value.substring(0,at);
        String prefix=user.matches("[0-9]{6,}")?user.substring(0,6)+"…":"masked";
        return prefix+(at<0?"":"@"+value.substring(at+1));
    }
    public static void config(Object card,Object config,Map<String,String> overrides) {
        try {
        Log.e("SIMHubIdentity","effective ICCID="+tail(String.valueOf(get(card,"b")))+" PLMN="+call(card,"d")
            +" NAI="+identity((String)get(config,"r"))+" EAP="+identity((String)get(config,"y"))
            +" NAI-source="+(overrides!=null&&overrides.containsKey("nai")?"override":"builtin")
            +" EAP-source="+(overrides!=null&&overrides.containsKey("eap")?"override":"builtin"));
        } catch(Exception ignored) {Log.e("SIMHubIdentity","Identity diagnostic unavailable");}
    }
}
