package cc.forserein.simhub.internal;

import java.util.*;

/** Editable ordered entries; their origin does not affect editing, deletion or selection. */
public final class WifiConfigListDraft {
    public static final String EMPTY="[]";
    public final boolean smsc;
    public final List<String> entries=new ArrayList<>();
    public int selected;
    public WifiConfigListDraft(boolean smsc,Map<String,String> values,Map<String,String> defaults) {
        this.smsc=smsc;
        String stored=values.get(smsc?"smsc_list":"epdg");
        if(stored==null || stored.trim().isEmpty())stored=values.get(smsc?"smsc":"epdg");
        if(stored==null || stored.trim().isEmpty())stored=defaults.get(smsc?"smsc":"epdg");
        if(smsc && (values.get("smsc_list")==null || values.get("smsc_list").trim().isEmpty()) && stored!=null && !stored.trim().isEmpty()){
            try{stored=WifiConfigValues.validate(Collections.singletonMap("smsc",stored)).get("smsc");}catch(IllegalArgumentException ignored){}
        }
        entries.addAll(decode(stored));
        String active=values.get("smsc");selected=active==null?0:Math.max(0,entries.indexOf(active));
    }
    public static List<String> decode(String value) {
        if(value==null || value.trim().isEmpty() || value.equals(EMPTY))return Collections.emptyList();
        return new ArrayList<>(Arrays.asList(value.split("\\s+")));
    }
    public void add(){entries.add("");}
    public void remove(int index){entries.remove(index);if(index<selected)selected--;else if(index==selected)selected=0;if(entries.isEmpty())selected=0;}
    public void choose(int index){if(index<0||index>=entries.size())throw new IllegalArgumentException("请选择有效条目");selected=index;}
    public Map<String,String> values() {
        List<String> normalized=new ArrayList<>();
        String active=null,key=smsc?"smsc":"epdg";
        for(int i=0;i<entries.size();i++){
            Map<String,String> value=WifiConfigValues.validate(Collections.singletonMap(key,entries.get(i)));
            String v=value.get(key);
            if(v==null || v.equals(EMPTY))throw new IllegalArgumentException("请填写内容，或删除空条目");
            if(smsc && i==selected)active=v;
            if(smsc)normalized.add(v);else normalized.addAll(decode(v));
        }
        LinkedHashSet<String> unique=new LinkedHashSet<>(normalized);
        if(unique.size()>16)throw new IllegalArgumentException("最多保存 16 条");
        Map<String,String> result=new LinkedHashMap<>();
        result.put(smsc?"smsc_list":"epdg",unique.isEmpty()?EMPTY:WifiConfigValues.join(unique,"\n"));
        if(smsc)result.put("smsc",active==null?"":active);
        return WifiConfigValues.validate(result);
    }
}
