#!/usr/bin/env python3
"""Ensure both switch entries use the restored native path; keep the obsolete banner hidden."""
from pathlib import Path
import sys
r=Path(sys.argv[1])
for name in ('sj.smali','cg0.smali'):
 s=(r/'smali'/name).read_text()
 assert s.count('Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V')==1,name
 assert 'InternalSimMultiChipSwitch' not in s,name
# No UI path may retain the experimental coordinator or its request retry wrapper.
for p in (r/'smali').glob('*.smali'):
 s=p.read_text()
 assert 'LInternalSimMultiChipSwitch;' not in s,p.name
 assert 'LInternalSimSwitchRequest;' not in s,p.name
s=(r/'smali/fd2.smali').read_text();end=s.index('    const-string v3, "vowifi_sms_profile_mismatch"')
assert s.rfind('    goto/16 :cond_14',0,end)>s.rfind('    if-eqz v25, :cond_14',0,end)
for lang in ('zh-Hans','zh-Hant'):
 assert '"vowifi_sms_profile_mismatch" = "";' in (r/f'assets/i18n/{lang}.strings').read_text()
print('PASS: both toggle routes use native switching; no experimental coordinator or retry wrapper; obsolete USIM banner removed')
