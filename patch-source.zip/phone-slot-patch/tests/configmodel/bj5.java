import java.util.*;
/** Native preset record double; actual APK schema is checked separately. */
public class bj5 {
 public final String a,b,c;public String d,e,f="ims",g="dual",q="0$imsi@nai.epc.mnc$mnc.mcc$mcc.3gppnetwork.org";
 public List<String> h=Arrays.asList("aes256","aes128"),i=Arrays.asList("sha256"),j=Arrays.asList("sha256"),k=Arrays.asList("modp2048"),l=Arrays.asList("aes128"),m=Arrays.asList("sha1");
 public int o=25,s=1300;public boolean p=false,r=true,v=false;
 public bj5(String id,String name,String plmn){a=id;b=name;c=plmn;}
}
