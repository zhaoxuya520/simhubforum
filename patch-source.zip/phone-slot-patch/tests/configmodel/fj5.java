import java.util.*;
public class fj5 {
 public static final fj5 a=new fj5();
 public static final bj5 DITO=new bj5("standard_plmn_51566","DITO · 标准模板（未实测）","51566");
 public static final bj5 VODAFONE=new bj5("apple_vodafone_nl","Vodafone_nl","20404");
 public static final bj5 THREE_DIGIT=new bj5("apple_test","Test_operator","310260");
 public static final bj5 VARIANT=new bj5("dito_variant","DITO_variant","51566");
 public static final List<bj5> presets=new ArrayList<>(Arrays.asList(DITO,VODAFONE,THREE_DIGIT,VARIANT));
 static {for(int i=0;i<24;i++)presets.add(new bj5("test_"+i,"Operator_"+i,"999"+String.format("%02d",i)));}
 public ej5 b(){return new ej5(presets);}
 public List<cj5> a(){return Arrays.asList(new cj5("515","66","PH","DITO"),new cj5("204","04","NL","Vodafone"),new cj5("310","260","US","Test"));}
}
