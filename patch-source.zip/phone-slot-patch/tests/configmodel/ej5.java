import java.util.*;
public class ej5 {public final List<bj5> a;public ej5(List<bj5> a){this.a=a;}}
