public class ek5 {public final String a,b;public String f;public Object h;public ek5(String imsi,String iccid){a=imsi;b=iccid;} }
