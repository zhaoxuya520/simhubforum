public class cj5 {public final String a,b,c,d,e;public cj5(String mcc,String mnc,String country,String name){a=mcc;b=mnc;c=country;d=name;e=name;}}
