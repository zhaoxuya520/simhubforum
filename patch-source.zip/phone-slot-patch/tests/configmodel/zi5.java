import java.util.*;
public class zi5 {public static final Map<String,Object> a=new HashMap<>();}
