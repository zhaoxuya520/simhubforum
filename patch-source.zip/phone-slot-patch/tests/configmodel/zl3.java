import java.util.*;
public class zl3 {
 public static int builds;
 public static xi5 r(ek5 card){
  builds++;
  boolean vodafone=card.a.startsWith("20404");
  return new xi5(lj5.U,"test-preset",vodafone?"Vodafone":"Test",vodafone?"204":"001",vodafone?"04":"01",Arrays.asList(vodafone?"epdg.epc.mnc004.mcc204.pub.3gppnetwork.org":"default.epdg.example.org"),
   vodafone?"ims.mnc004.mcc204.3gppnetwork.org":"ims.example.org","ims",ak5.V,Arrays.asList("aes256"),Arrays.asList("sha256"),Arrays.asList("sha256"),
   Arrays.asList("modp2048"),Arrays.asList("aes256"),Arrays.asList("sha256"),20,false,
   "anonymous@nai.example.org",card.a+"@ims.example.org",true,1300,false,null,Arrays.asList(20,21),null,new Object(),null);
 }
 public static xi5 i(bj5 p,ek5 card){
  String mcc=card.a.substring(0,3),mnc=card.a.substring(3,5),realm="mnc0"+mnc+".mcc"+mcc+".3gppnetwork.org";
  return new xi5(lj5.U,p.a,p.b,mcc,mnc,Arrays.asList("epdg.epc.mnc0"+mnc+".mcc"+mcc+".pub.3gppnetwork.org"),
   p.e==null?"ims."+realm:p.e,p.f,p.g.equals("ipv4")?ak5.U:p.g.equals("dual")?ak5.W:ak5.V,p.h,p.i,p.j,p.k,p.l,p.m,p.o,p.p,
   cc.forserein.simhub.internal.CarrierPresets.expand(p.q,card.a,mcc,mnc),card.a+"@ims."+realm,p.r,p.s,p.v,null,Arrays.asList(20,21),null,new Object(),null);
 }
}
