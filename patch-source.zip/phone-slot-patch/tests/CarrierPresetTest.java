import cc.forserein.simhub.internal.*;
import java.util.*;
public class CarrierPresetTest {
 static int passed;static void check(boolean b,String s){if(!b)throw new AssertionError(s);passed++;}
 static Map<String,String> v(String...s){Map<String,String>m=new LinkedHashMap<>();for(int i=0;i<s.length;i+=2)m.put(s[i],s[i+1]);return m;}
 interface Run {void run()throws Exception;}
 static void reject(Run r)throws Exception{try{r.run();throw new AssertionError("accepted invalid selection");}catch(IllegalArgumentException|IllegalStateException e){passed++;}}
 public static class Policy {public String a="Policy name",e="policy.epdg.example.org",f="policy.ims";public Boolean b=true,g=false;public ak5 c=ak5.U;public Profile d=new Profile();}
 public static class Profile {public boolean u=true;}
 public static class Isim {public String a="real@isim.example.org",b="isim.example.org",c="sip:real@isim.example.org";}
 public static void main(String[]args)throws Exception{
  String key="51566|standard_plmn_51566";
  check(CarrierPresets.all().size()==28,"all presets available including variants and paginated results");
  check(CarrierPresets.search("dito").size()==2,"search name finds variants");
  check(CarrierPresets.search("DITO Philippines").size()==2&&CarrierPresets.search("dito 菲律宾").size()==2,"search English/Chinese country and case independent");
  check(CarrierPresets.search("51566").size()==2&&CarrierPresets.search("PH 51566").size()==2,"search PLMN and country code");
  check(CarrierPresets.search("PL").isEmpty(),"country code PL does not accidentally match every apple preset ID");
  check(CarrierPresets.search("Vodafone NL").size()==1,"two-letter country query matches country or bundle token");
  check(CarrierPresets.search("does-not-exist").isEmpty(),"unknown search has no results");
  check(!CarrierPresets.find(key).key.equals(CarrierPresets.find("51566|dito_variant").key),"same PLMN variants have stable distinct identities");
  reject(()->CarrierPresets.find("51566|missing"));
  reject(()->WifiConfigValues.validate(v(CarrierPresets.KEY,"51566|bad\nkey")));
  ek5 card=new ek5("204040123456789","carrier-manual-a");card.f="+441234567890";
  xi5 dito=(xi5)CarrierPresets.defaults(card,v(CarrierPresets.KEY,key));
  check(dito.c.equals("DITO")&&dito.d.equals("515")&&dito.e.equals("66"),"selected preset replaces actual-read operator PLMN in connection config");
  check(dito.g.equals("ims.mnc066.mcc515.3gppnetwork.org")&&dito.f.equals(Arrays.asList("epdg.epc.mnc066.mcc515.pub.3gppnetwork.org")),"domain and endpoint both use selected PLMN, no old fallback");
  check(dito.r.equals("0204040123456789@nai.epc.mnc066.mcc515.3gppnetwork.org")&&dito.s.equals(card.a+"@ims.mnc066.mcc515.3gppnetwork.org"),"identities use actual IMSI with selected realm");
  check(card.a.equals("204040123456789")&&card.b.equals("carrier-manual-a"),"real SIM identity not rewritten");
  check(dito.j.equals(fj5.DITO.h)&&dito.n.equals(fj5.DITO.l)&&dito.p==25&&dito.i==ak5.W,"native algorithms, keepalive and IP settings retained");
  xi5 us=(xi5)CarrierPresets.defaults(card,v(CarrierPresets.KEY,"310260|apple_test"));
  check(us.g.equals("ims.mnc260.mcc310.3gppnetwork.org"),"three-digit MNC not truncated");
  String prior=fj5.DITO.q;fj5.DITO.q="anonymous@nai.epc.mnc$mnc.mcc$mcc.3gppnetwork.org";
  xi5 anonymous=(xi5)CarrierPresets.defaults(card,v(CarrierPresets.KEY,key));
  check(anonymous.r.startsWith("anonymous@")&&anonymous.y.equals("0"+card.a+"@nai.epc.mnc066.mcc515.3gppnetwork.org"),"anonymous IKE identity retains native real-IMSI EAP fallback");fj5.DITO.q=prior;
  WifiConfigTest.Ctx ctx=new WifiConfigTest.Ctx();zl5.f=ctx;zl5.b.value=WifiConfigTest.state(card,zl3.r(card));
  WifiConfigRuntime.save(WifiConfigRuntime.snapshot().key,v("domain","old.vodafone.example.org","epdg","old.epdg.example.org","ike_encr","aes128","imei","490154203237518","smsc_list","+441234567890\n+442222222222","smsc","+442222222222"));
  WifiConfigRuntime.Snapshot before=WifiConfigRuntime.snapshot();Map<String,String> selected=CarrierPresets.selection(before.values,key);
  check(!selected.containsKey("domain")&&!selected.containsKey("epdg")&&!selected.containsKey("ike_encr")&&selected.containsKey("imei")&&selected.containsKey("smsc_list"),"selection replaces carrier overrides and preserves independent saved settings");
  WifiConfigRuntime.save(before.key,before.record,selected);gl5 state=(gl5)zl5.b.value;
  check(state.f.c.equals("DITO")&&state.f.g.equals(dito.g)&&state.f.f.equals(dito.f)&&state.f.j.equals(dito.j),"live config actually replaced, not only its label");
  check(state.i.equals("+442222222222")&&state.j.equals("490154203237518"),"saved SMSC choice and IMEI preserved");
  check(WifiConfigRuntime.snapshot().values.get(CarrierPresets.KEY).equals(key)&&WifiConfigRuntime.snapshot().defaults.get("domain").equals(dito.g),"selection persists and subsequent reset uses chosen defaults");
  check(WifiConfigValues.decode(WifiConfigValues.encode(selected)).equals(selected),"stable selection survives serialization");
  int builds=zl3.builds;for(int i=0;i<20;i++)WifiConfigRuntime.resolve(card,state.f);check(zl3.builds==builds,"recomposition does not rebuild selected preset repeatedly");
  ek5 reread=new ek5(card.a,card.b);reread.f=card.f;zl5.b.value=WifiConfigTest.state(reread,zl3.r(reread));check(((gl5)zl5.b.value).f.c.equals("DITO"),"same SIM reread restores selected carrier");
  ek5 other=new ek5("001010123456789","carrier-manual-b");zl5.b.value=WifiConfigTest.state(other,zl3.r(other));check(((gl5)zl5.b.value).f.c.equals("Test"),"another SIM uses its own automatic config");
  reject(()->WifiConfigRuntime.save(before.key,selected));
  zl5.b.value=WifiConfigTest.state(reread,zl3.r(reread));WifiConfigRuntime.Snapshot current=WifiConfigRuntime.snapshot();
  Map<String,String> automatic=CarrierPresets.selection(current.values,null);WifiConfigRuntime.save(current.key,current.record,automatic);
  check(!WifiConfigRuntime.snapshot().values.containsKey(CarrierPresets.KEY)&&((gl5)zl5.b.value).f.c.equals("Vodafone"),"automatic selection restores native automatic preset");
  current=WifiConfigRuntime.snapshot();ctx.prefs.fail=true;final WifiConfigRuntime.Snapshot failed=current;
  reject(()->WifiConfigRuntime.save(failed.key,failed.record,selected));check(((gl5)zl5.b.value).f.c.equals("Vodafone")&&!WifiConfigRuntime.snapshot().values.containsKey(CarrierPresets.KEY),"failed selection rolls back disk and cached defaults");
  Policy policy=new Policy();zi5.a.put("51566",policy);reread.h=new Isim();
  xi5 special=(xi5)CarrierPresets.apply(CarrierPresets.find(key),reread);
  check(special.c.equals("Policy name")&&special.h.equals("policy.ims")&&special.i==ak5.U&&!special.t&&special.v&&special.z==policy.d,"original per-PLMN transport policy retained");
  check(special.f.get(0).equals(policy.e)&&special.s.equals("real@isim.example.org")&&special.A.equals("sip:real@isim.example.org"),"original policy endpoint and real ISIM credentials retained");
  zi5.a.clear();
  System.out.println("PASS: "+passed+" searchable preset selection, replacement and real-SIM identity assertions");
 }
}
