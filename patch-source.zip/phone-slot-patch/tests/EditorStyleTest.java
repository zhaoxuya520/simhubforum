import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import java.util.*;
public class EditorStyleTest {
 static int passed;static void check(boolean b,String s){if(!b)throw new AssertionError(s);passed++;}
 static EditorModifier find(r53 p,String kind){while(p instanceof EditorModifier){EditorModifier m=(EditorModifier)p;if(m.kind.equals(kind))return m;p=m.parent;}return null;}
 public static void main(String[]args)throws Exception{
  zl5.f=new WifiConfigTest.Ctx();ek5 card=new ek5("001010000000001","styled-ui");card.f="+441234567890";
  zl5.b.value=WifiConfigTest.state(card,zl3.r(card));WifiConfigRuntime.save(WifiConfigRuntime.snapshot().key,Collections.emptyMap());
  Activity owner=new Activity();lu1 c=new lu1();WifiConfigEditor.begin(owner,(us1)()->sc5.a);
  WifiConfigEditor.row("运营商","",c,6);
  check(ak2.lastCardText.startsWith("切换运营商  ›\n"),"carrier is an explicit visible change action with current value");
  check(find(z45.lastModifier,"border")!=null&&find(z45.lastModifier,"background")!=null,"carrier entry has a tinted background and border");
  WifiConfigEditor.row("Domain","",c,6);ak2.click.a();WifiConfigEditor.overlay(c);
  cj2 reset=xq0.buttons.get(0),save=xq0.buttons.get(1);
  check(WifiConfigEditor.renderButton(save,o53.b,c,0),"owned save button rendered");
  check(z45.lastColor==0xffffffff00000000L&&z45.lastAlign.align==3,"save text is white and centered");
  check(z45.lastStyle==mk2.d&&(z45.lastDefaults&0x400)==0,"button uses 17-point title style and preserves alignment");
  EditorModifier fill=find(z45.lastModifier,"background");check(fill!=null&&((Long)fill.args[0])==new jj2().b,"save has solid accent fill");
  check(((o74)fill.args[1]).radius==12f,"buttons have consistent rounded corners");
  check(((Float)find(z45.lastModifier,"minHeight").args[0])>=48f,"touch target minimum is 48 dp");
  check(Boolean.TRUE.equals(find(z45.lastModifier,"click").args[0]),"enabled button is clickable");
  check(WifiConfigEditor.renderButton(reset,o53.b,c,0)&&find(z45.lastModifier,"border")!=null&&z45.lastColor==new jj2().b,"reset has a distinct blue outline and tint");
  cj2 unrelated=new cj2("Other",ij2.T,true,()->sc5.a);
  check(!WifiConfigEditor.renderButton(unrelated,o53.b,c,0),"unrelated dialogs keep their original renderer");
  xq0.press("保存");WifiConfigEditor.overlay(c);save=xq0.buttons.get(1);
  check(!save.c&&WifiConfigEditor.renderButton(save,o53.b,c,0)&&Boolean.FALSE.equals(find(z45.lastModifier,"click").args[0]),"saving state is visibly and functionally disabled");
  long end=System.nanoTime()+2_000_000_000L;while(Handler.tasks.isEmpty()&&System.nanoTime()<end)Thread.sleep(5);Handler.drain();
  check(c.depth==0,"custom button Compose groups balanced");owner.destroy();
  System.out.println("PASS: "+passed+" scoped button style, hierarchy, touch target and disabled-state assertions (Compose doubles)");
 }
}
