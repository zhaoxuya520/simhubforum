public class n25 {public final int align;public n25(int a){align=a;}}
