public class fl0 {public static long b(float alpha,long color){return (color&0x00ffffff00000000L)|((long)Math.round(alpha*255)<<56);}}
