public class v95 {public static r53 o(r53 p,long color,im4 shape){return new EditorModifier(p,"background",color,shape);}}
