public class e23 {public static r53 q(r53 p,boolean enabled,String label,us1 click,int mask){return new EditorModifier(p,"click",enabled,click);}}
