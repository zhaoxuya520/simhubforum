public class ei0 {public static r53 Z(r53 p,float x,float y){return new EditorModifier(p,"padding",x,y);}}
