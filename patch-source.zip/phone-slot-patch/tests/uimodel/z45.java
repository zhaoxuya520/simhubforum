import java.util.*;
public class z45 {
 public static final List<String> text=new ArrayList<>();
 public static r53 lastModifier;public static long lastColor;public static n25 lastAlign;public static s55 lastStyle;public static int lastDefaults;
 public static final List<String> events=new ArrayList<>();
 public static void b(String content,r53 modifier,long color,long fontSize,nq1 fontStyle,sz4 weight,long spacing,n25 align,long lineHeight,int overflow,boolean softWrap,int maxLines,int minLines,s55 style,lu1 c,int flags,int flags2,int defaults){
  lastModifier=modifier;lastColor=color;lastAlign=align;lastStyle=style;lastDefaults=defaults;while(modifier instanceof EditorModifier)modifier=((EditorModifier)modifier).parent;
  if(!(modifier instanceof oo4.Width) || !softWrap || maxLines!=Integer.MAX_VALUE || minLines!=1)throw new AssertionError("full-width wrapping text required");
  events.add("text");text.add(content);String[] parts=content.split("\n",2);yd2.values.put(parts[0],parts.length==2?parts[1]:"");
 }
}
