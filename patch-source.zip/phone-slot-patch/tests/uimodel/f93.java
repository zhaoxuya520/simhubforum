public class f93 {public static r53 o(r53 p,float width,long color,im4 shape){return new EditorModifier(p,"border",width,color,shape);}}
