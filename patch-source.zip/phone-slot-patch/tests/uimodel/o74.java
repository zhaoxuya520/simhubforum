public class o74 implements im4 {public final float radius;public o74(float r){radius=r;}}
