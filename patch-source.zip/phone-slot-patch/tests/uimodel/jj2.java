public class jj2 {public long b=0xff007aff00000000L,e=0xffff3b3000000000L,f=0xff11111100000000L,h=0xff8e8e9300000000L;}
