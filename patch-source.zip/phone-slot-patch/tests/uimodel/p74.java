public class p74 {public static o74 b(float radius){return new o74(radius);}}
