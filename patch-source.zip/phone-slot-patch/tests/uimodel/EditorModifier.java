public class EditorModifier implements r53 {public final r53 parent;public final String kind;public final Object[] args;public EditorModifier(r53 p,String k,Object...a){parent=p;kind=k;args=a;}}
