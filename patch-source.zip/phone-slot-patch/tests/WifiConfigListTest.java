import java.util.*;
import cc.forserein.simhub.internal.*;
public class WifiConfigListTest {
 static int passed;static void check(boolean b,String s){if(!b)throw new AssertionError(s);passed++;}
 static Map<String,String> v(String...x){Map<String,String> m=new LinkedHashMap<>();for(int i=0;i<x.length;i+=2)m.put(x[i],x[i+1]);return m;}
 static void reject(Runnable r){try{r.run();throw new AssertionError("accepted invalid entry");}catch(IllegalArgumentException e){passed++;}}
 public static void main(String[]a){
  Map<String,String> defaults=v("epdg","one.default.example.org\ntwo.default.example.org","smsc","447958879879");
  WifiConfigListDraft epdg=new WifiConfigListDraft(false,Collections.emptyMap(),defaults);
  check(epdg.entries.size()==2,"all builtins prefilled");epdg.entries.set(0,"edited.example.org");epdg.remove(1);epdg.add();epdg.entries.set(1,"added.example.org");
  check(epdg.values().get("epdg").equals("edited.example.org\nadded.example.org"),"edit builtin and add own use same path");
  epdg.remove(0);epdg.remove(0);check(epdg.values().get("epdg").equals("[]"),"deleted all differs from reset");
  check(new WifiConfigListDraft(false,epdg.values(),defaults).entries.isEmpty(),"deleted entries do not reappear on reopen");
  check(new WifiConfigListDraft(false,Collections.emptyMap(),defaults).entries.size()==2,"reset restores full original list");
  WifiConfigListDraft smsc=new WifiConfigListDraft(true,Collections.emptyMap(),defaults);
  check(smsc.entries.equals(Arrays.asList("+447958879879")),"card-read SMSC without plus usable as a real editable value");
  smsc.add();smsc.entries.set(1,"00441234567890");smsc.choose(1);Map<String,String> saved=smsc.values();
  check(saved.get("smsc").equals("+441234567890"),"selected number normalized");
  check(WifiConfigValues.decode(WifiConfigValues.encode(saved)).equals(saved),"multiple numbers and choice roundtrip on disk");
  smsc=new WifiConfigListDraft(true,saved,defaults);check(smsc.selected==1,"active selection survives reload");
  smsc.remove(0);check(smsc.selected==0&&smsc.values().get("smsc").equals("+441234567890"),"removing builtin keeps chosen own number");
  smsc.remove(0);saved=smsc.values();check(!saved.containsKey("smsc")&&saved.get("smsc_list").equals("[]"),"empty list has no active number");
  check(new WifiConfigListDraft(true,saved,defaults).entries.isEmpty(),"empty persisted SMSC list suppresses builtin");
  Map<String,String> original=v("epdg","prior.example.org");WifiConfigListDraft draft=new WifiConfigListDraft(false,original,defaults);draft.entries.set(0,"after.example.org");check(original.get("epdg").equals("prior.example.org"),"typing does not mutate saved input");
  reject(()->{WifiConfigListDraft d=new WifiConfigListDraft(false,Collections.emptyMap(),defaults);d.add();d.values();});
  reject(()->WifiConfigValues.validate(v("smsc_list","+441234567890","smsc","+499999999999")));
  check(WifiConfigValues.validate(v("smsc_list","+441234567890 +441234567890")).get("smsc_list").equals("+441234567890"),"duplicate numbers canonicalized");
  check(WifiConfigValues.validate(v("smsc_list","+441234567890")).get("smsc").equals("+441234567890"),"valid list always has a current number");
  System.out.println("PASS: "+passed+" editable list and deletion persistence assertions");
 }
}
