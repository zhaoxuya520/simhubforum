#!/usr/bin/env python3
"""Pin the real Compose styling contracts and trace effective SMSC display to the SIM read."""
import re,sys,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];r=Path(sys.argv[1]);s=r/'smali';count=0
contracts={'p74':['b(F)Lo74;'],'fl0':['b(FJ)J'],'ei0':['Z(Lr53;FF)Lr53;'],'oo4':['g(Lr53;FFI)Lr53;'],
 'v95':['o(Lr53;JLim4;)Lr53;'],'f93':['o(Lr53;FJLim4;)Lr53;'],'e23':['q(Lr53;ZLjava/lang/String;Lus1;I)Lr53;'],
 'n25':['<init>(I)V'],'xq0':['c(Ljava/util/List;Llu1;I)V']}
for name,signatures in contracts.items():
 text=(s/(name+'.smali')).read_text()
 for sig in signatures:
  assert re.search(r'^\.method public [^\n]* '+re.escape(sig)+r'$',text,re.M),(name,sig)
  count+=1
assert '.implements Lim4;'in(s/'o74.smali').read_text()
for field in 'befh':assert re.search(r'^\.field public final '+field+':J$',(s/'jj2.smali').read_text(),re.M)
assert '.field public static final d:Ls55;'in(s/'mk2.smali').read_text()
for name in ['fd2','i21']:
 text=(s/(name+'.smali')).read_text();assert text.count('WifiConfigRuntime;->displaySmsCenter(Ljava/lang/Object;)Ljava/lang/String;')==1,name
assert 'WifiConfigEditor;->renderButton(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)Z'in(s/'xq0.smali').read_text()
# Auto SMSC is read from EF_SMSP, then assigned to the card model, not carried by bj5 presets.
assert 'const/16 v4, 0x6f42'in(s/'vb5.smali').read_text()
assert 'iput-object p6, p0, Lek5;->f:Ljava/lang/String;'in(s/'ek5.smali').read_text()
asset=json.loads((r/'assets/vowifi/carrier_presets.json').read_text())
assert not any(any('smsc'in k.lower()or'smscenter'in k.lower()for k in p)for p in asset['presets'])
source=(root/'src/cc/forserein/simhub/internal/WifiConfigEditor.java').read_text()
assert '0x1fbf8'in source and (0x1fbf8&0x400)==0 and (0x1fbf8&0x20000)==0
report=dict(reflection_contracts=count,scoped_config_button_renderer=True,unified_effective_smsc_display=True,
 auto_smsc_source='SIM EF_SMSP / card.f',carrier_catalogue_has_smsc=False,device_tested=False)
(r.parent/'editor-style-integration.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: native styling contracts, scoped button hook, effective SMSC display and actual EF_SMSP source')
