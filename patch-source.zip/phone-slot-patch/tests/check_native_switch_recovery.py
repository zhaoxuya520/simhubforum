#!/usr/bin/env python3
"""Ensure switch and APDU implementations exactly match the pinned recovery baseline."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from multichip_patch import verify_native_switch_routes
patched=Path(sys.argv[1]);base=Path(sys.argv[2])
manifest=json.loads((root/'validation/native-switch-baseline.json').read_text())
assert hashlib.sha256(base.read_bytes()).hexdigest()==manifest['base_apk_sha256']
smali=patched/'smali';verify_native_switch_routes(smali)
for name,digest in manifest['class_sha256'].items():
 assert hashlib.sha256((smali/name).read_bytes()).hexdigest()==digest,name
text=(smali/'iz3.smali').read_text()
for signature,digest in manifest['iz3_method_sha256'].items():
 method=text.split(signature+'\n',1)[1].split('.end method',1)[0]
 assert hashlib.sha256(method.encode()).hexdigest()==digest,signature
identity=(smali/'cc/forserein/simhub/internal/IdentityBinding.smali').read_text()
for error in ('尚未确认所选芯片','所选芯片有多个启用配置','无法确认当前配置身份','validateSelection','已停止使用错误身份'):
 # apktool escapes Chinese strings; compare their exact escaped forms too.
 escaped=error.encode('unicode_escape').decode()
 assert error not in identity and escaped not in identity,error
report=dict(native_classes_exact=sorted(manifest['class_sha256']),native_selection_methods_exact=2,
 experimental_adapters_present=False,management_identity_gate_present=False,device_tested=False)
(patched.parent/'native-switch-recovery.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: 15 native switch/channel/USIM classes and both AID selection methods unchanged; experimental switch path and management identity gate absent')
