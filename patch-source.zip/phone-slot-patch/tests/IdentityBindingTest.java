import cc.forserein.simhub.internal.*;
import java.util.*;

public class IdentityBindingTest {
 public static class Flow {public Object value;public boolean h(Object old,Object next){if(value!=old)return false;value=next;return true;}}
 static int passed;static void check(boolean b){if(!b)throw new AssertionError();passed++;}
 public static class Card {public String a,b;Card(String imsi,String iccid){a=imsi;b=iccid;}public String d(){return a.substring(0,5);}}
 public static class Transport {public String f="SIM2";}
 public static class Profile {public String a;public boolean b;Profile(String iccid,boolean enabled){a=iccid;b=enabled;}}
 public static class Chip {public String b;public List<Profile>d;Chip(String eid,Profile...p){b=eid;d=Arrays.asList(p);}}
 public static class Controller {
  public String selected;public List<Chip> chips;
  Controller(Chip...c){chips=Arrays.asList(c);selected=c.length==0?null:c[0].b;}
  public String r(){return selected;}public List<Chip> l(){return chips;}
 }
 public static void main(String[]args)throws Exception {
  Profile dito=new Profile("8963660000005526",true);
  Controller c=new Controller(new Chip("8962",dito));
  Transport t=new Transport();IdentityBinding.track(t,c);
  Card actual=new Card("515660000000001",dito.a);
  IdentityBinding.read(t,new Object(),actual);check(true);
  // The management page may show another profile; only the USIM read owns authentication identity.
  Card other=new Card("204040000000023","8900000000006164");
  IdentityBinding.read(t,new Object(),other);check(other.a.equals("204040000000023"));
  check(other.b.equals("8900000000006164"));
  IdentityBinding.read(new Transport(),new Object(),new Card("204040000000023","plain"));check(true);
  check(IdentityBinding.identity("0204040000000023@nai.epc.mnc004.mcc204.3gppnetwork.org").equals("020404…@nai.epc.mnc004.mcc204.3gppnetwork.org"));
  check(!IdentityBinding.identity("515660000000001@example.org").contains("000000001"));
  check(IdentityBinding.identity("anonymous@example.org").equals("masked@example.org"));
  check(IdentityBinding.tail(dito.a).equals("…5526"));
  Object auth=new Object();IdentityBinding.begin(t,auth);
  // A UI selection change is not a new USIM read and must not invalidate a valid result.
  c.selected="missing";IdentityBinding.track(t,c);
  IdentityBinding.read(t,auth,actual);check(true);
  Object missing=new Object();IdentityBinding.begin(t,missing);
  IdentityBinding.read(t,missing,other);check(true);
  check(IdentityBinding.needsRead(t));check(!IdentityBinding.needsRead(new Transport()));
  // Empty / disabled / multiple-enabled / unavailable management lists must not block Wi-Fi Calling.
  c.selected="8962";dito.b=false;IdentityBinding.track(t,c);
  Object disabled=new Object();IdentityBinding.begin(t,disabled);
  IdentityBinding.read(t,disabled,actual);check(true);
  c.chips=Arrays.asList(new Chip("8962",new Profile("a",true),new Profile("b",true)));
  IdentityBinding.track(t,c);Object ambiguous=new Object();IdentityBinding.begin(t,ambiguous);
  IdentityBinding.read(t,ambiguous,actual);check(true);
  IdentityBinding.track(t,new Controller());Object empty=new Object();IdentityBinding.begin(t,empty);
  IdentityBinding.read(t,empty,actual);check(true);
  IdentityBinding.track(t,new Object());Object unavailable=new Object();IdentityBinding.begin(t,unavailable);
  IdentityBinding.read(t,unavailable,actual);check(true);
  check(IdentityBinding.needsRead(t));
  // A newer read still supersedes late completions from the previous read.
  Object newest=new Object();IdentityBinding.begin(t,newest);
  check(!IdentityBinding.current(t,auth)&&IdentityBinding.current(t,newest));
  try{IdentityBinding.read(t,unavailable,other);throw new AssertionError();}
  catch(IllegalStateException expected){check(expected.getMessage().contains("过期"));}
  Flow flow=new Flow();Object newValue=new Object();
  check(!IdentityBinding.publish(t,unavailable,flow,null,newValue)&&flow.value==null);
  check(!IdentityBinding.publishError(t,unavailable,flow,null,newValue)&&flow.value==null);
  check(IdentityBinding.publish(t,newest,flow,null,newValue)&&flow.value==newValue);
  c.selected="changed";IdentityBinding.track(t,c);
  Object afterSelection=new Object();
  check(IdentityBinding.publish(t,newest,flow,newValue,afterSelection)&&flow.value==afterSelection);
  check(!IdentityBinding.publish(t,newest,flow,newValue,new Object())&&flow.value==afterSelection);
  check(IdentityBinding.publishError(t,newest,flow,afterSelection,null)&&flow.value==null);
  Transport second=new Transport();IdentityBinding.begin(second,new Object());
  check(IdentityBinding.current(t,newest));
  check(actual.a.equals("515660000000001")&&actual.b.equals("8963660000005526"));
  System.out.println("PASS: "+passed+" USIM generation, management-cache regression and redaction assertions");
 }
}
