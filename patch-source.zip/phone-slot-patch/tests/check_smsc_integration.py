#!/usr/bin/env python3
"""Verify retained SMSC fixes and the exact pre-restyling editor source."""
import sys,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1];r=Path(sys.argv[1]);smali=r/'smali'
for name in ['fd2','i21']:
 text=(smali/(name+'.smali')).read_text()
 assert text.count('WifiConfigRuntime;->displaySmsCenter(Ljava/lang/Object;)Ljava/lang/String;')==1,name
assert 'const/16 v4, 0x6f42'in(smali/'vb5.smali').read_text()
assert 'iput-object p6, p0, Lek5;->f:Ljava/lang/String;'in(smali/'ek5.smali').read_text()
asset=json.loads((r/'assets/vowifi/carrier_presets.json').read_text())
assert not any(any('smsc'in k.lower()or'smscenter'in k.lower()for k in p)for p in asset['presets'])
source=root/'src/cc/forserein/simhub/internal/WifiConfigEditor.java'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='7797f9609107bf97f3be274c039803c69a691ba577815c910006ff2ec52024a5'
assert 'WifiConfigEditor;->renderButton'not in(smali/'xq0.smali').read_text()
assert 'paintAction'not in(smali/'cc/forserein/simhub/internal/WifiConfigEditor.smali').read_text()
report=dict(editor_matches_previous_source=True,custom_button_style_hook_removed=True,unified_effective_smsc_display=True,
 auto_smsc_source='SIM EF_SMSP / card.f',carrier_catalogue_has_smsc=False,device_tested=False)
(r.parent/'smsc-integration.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: exact previous editor restored; effective SMSC display and SIM default source retained')
