#!/usr/bin/env python3
"""Analyze actual built DEX adapter register types, with a known-bad APK regression mode."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('apk',type=Path)
p.add_argument('--report',type=Path,required=True)
p.add_argument('--expect-checked-read-error',action='store_true')
a=p.parse_args()
tools=Path(os.environ.get('SIMHUB_DEX_VERIFIER_TOOLS','/workspace/tools/dex-verifier'))
android=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
manifest=json.loads((ROOT/'validation/dex/toolchain.json').read_text())
for artifact in manifest['artifacts']:
 f=tools/artifact['file']
 assert f.is_file(),f"Missing verifier dependency: {f}; obtain from {artifact['url']}"
 assert hashlib.sha256(f.read_bytes()).hexdigest()==artifact['sha256'],f"Verifier dependency changed: {f}"
classes=a.report.parent/'dex-verifier-classes';classes.mkdir(parents=True,exist_ok=True)
cp=os.pathsep.join(str(tools/e['file']) for e in manifest['artifacts'])
subprocess.run(['java','-jar',str(android/'ecj-3.40.0.jar'),'-8','-encoding','UTF-8','-cp',cp,'-d',str(classes),str(ROOT/'validation/dex/VerifySwitchDex.java')],check=True)
r=subprocess.run(['java','-cp',str(classes)+os.pathsep+cp,'VerifySwitchDex',str(a.apk),str(android/'sdk/android-35/android.jar')],capture_output=True,text=True)
print(r.stdout,end='');print(r.stderr,end='')
summary=re.search(r'DEX TYPE ANALYSIS: classes=(\d+) methods=(\d+) invokes=(\d+) reference_arguments=(\d+) errors=(\d+)',r.stdout)
assert summary,'DEX analysis did not finish'
counts={k:int(v) for k,v in zip(['adapter_classes','methods','invokes','reference_arguments','errors'],summary.groups())}
errors=[line for line in r.stdout.splitlines() if line.startswith('TYPE ERROR:')]
if a.expect_checked_read_error:
 assert hashlib.sha256(a.apk.read_bytes()).hexdigest()=='bcf1a20e936548f56965eb33e000e9a35f8303e9d60a963b190b339cc6b46cc0','Regression input is not the pinned last release'
 assert r.returncode==1 and counts['errors']==1 and len(errors)==1
 assert 'LInternalSimCheckedRead;->i' in errors[0] and '(Reference,Lct0;)' in errors[0] and 'not assignable to Ldt0;' in errors[0]
else:
 assert r.returncode==0 and counts['errors']==0 and not errors,'Built adapter DEX has incompatible invoke argument types'
report=dict(counts,apk_sha256=hashlib.sha256(a.apk.read_bytes()).hexdigest(),expected_bad_release=a.expect_checked_read_error,diagnostics=errors,device_tested=False,art_execution=False)
a.report.write_text(json.dumps(report,indent=2)+'\n')
