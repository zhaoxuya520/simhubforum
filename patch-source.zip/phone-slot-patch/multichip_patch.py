"""Guard the restored native switch route; the experimental coordinator is disabled."""
from pathlib import Path


def verify_native_switch_routes(smali):
    smali = Path(smali)
    constructor = 'Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V'
    for name in ('cg0.smali', 'sj.smali'):
        text = (smali / name).read_text()
        assert text.count(constructor) == 1, name
        assert 'InternalSimMultiChipSwitch' not in text, name
    assert 'MultiChipSwitch;->allowSelection' not in (smali / 'iz3.smali').read_text()
    assert 'InternalSimSwitchRequest;->start' not in (smali / 'hz3.smali').read_text()
    assert 'ProfileRefresh;->checkResult' not in (smali / 'pg1.smali').read_text()
    for name in ('InternalSimMultiChipSwitch', 'InternalSimCheckedRead', 'InternalSimChipRead',
                 'InternalSimSwitchRequest', 'InternalSimNoRefreshCommand'):
        assert not (smali / (name + '.smali')).exists(), name
