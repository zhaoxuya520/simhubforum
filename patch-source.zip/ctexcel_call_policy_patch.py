"""CTExcel UK initial INVITE policy, preserving native registration and other call paths."""
from pathlib import Path
import hashlib

SIGNATURE = 'public final q(Ljava/lang/Object;)Ljava/lang/Object;'
BASE_CLASS_SHA256 = '38b9a092fcf33d352d73c24977f5750c848f70ab63e140c74bf2e4420f0a3413'
BASE_SHA256 = 'b4513e19e8ddeba438b92ef4ebb6de15e57852fa8d2a63ef086899cdcfee22f3'
HELPER = 'Lcc/forserein/simhub/internal/CtExcelCallPolicy;'
URI = '    :goto_5\n    sget-object v2, Lkb4;->Companion:Ljb4;\n'
URI_NEW = '    :goto_5\n    # ctexcel_call_policy_destination\n    invoke-static {v0, v1}, ' + HELPER + '->destination(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;\n    move-result-object v1\n\n    sget-object v2, Lkb4;->Companion:Ljb4;\n'
IDENTITY = '    iget-object v2, v2, Lra4;->e:Ljava/lang/String;\n\n    .line 362\n'
IDENTITY_NEW = '    iget-object v2, v2, Lra4;->e:Ljava/lang/String;\n\n    # ctexcel_call_policy_identity\n    invoke-static {v0, v2}, ' + HELPER + '->callerIdentity(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;\n    move-result-object v2\n\n    .line 362\n'
FROM = '    iget-object v6, v6, Lra4;->e:Ljava/lang/String;\n\n    .line 460\n'
FROM_NEW = '    # ctexcel_call_policy_from_snapshot\n    iget-object v6, v13, Lma4;->e:Ljava/lang/String;\n\n    .line 460\n'
PREFERRED = '    iget-object v2, v2, Lra4;->e:Ljava/lang/String;\n\n    .line 537\n'
PREFERRED_NEW = '    # ctexcel_call_policy_preferred_snapshot\n    iget-object v2, v13, Lma4;->e:Ljava/lang/String;\n\n    .line 537\n'
SAVE = '    iput-object v3, v13, Lma4;->j:Lkb4;\n'
SAVE_NEW = '    # ctexcel_call_policy_initial_request\n    invoke-static {v0, v3}, ' + HELPER + '->decorate(Ljava/lang/Object;Ljava/lang/Object;)V\n\n' + SAVE
EDITS = [(URI, URI_NEW), (IDENTITY, IDENTITY_NEW), (FROM, FROM_NEW), (PREFERRED, PREFERRED_NEW), (SAVE, SAVE_NEW)]


def _method(text):
    a = text.index('.method ' + SIGNATURE)
    b = text.index('.end method', a) + len('.end method')
    return a, b, text[a:b]


def apply_ctexcel_call_policy(smali):
    p = Path(smali) / 'f82.smali'
    text = p.read_text()
    a, b, body = _method(text)
    assert hashlib.sha256(body.encode()).hexdigest() == BASE_SHA256, 'unexpected native call builder'
    for old, new in EDITS:
        assert body.count(old) == 1, 'ambiguous native call policy anchor'
        body = body.replace(old, new)
    p.write_text(text[:a] + body + text[b:])


def reverse_ctexcel_call_policy(name, text):
    if name != 'f82.smali':
        return text
    if 'CtExcelCallPolicy;->' not in text and 'ctexcel_call_policy_' not in text:
        return text
    a, b, body = _method(text)
    for old, new in reversed(EDITS):
        assert body.count(new) == 1, 'partial or altered CTExcel call policy hook'
        body = body.replace(new, old)
    assert hashlib.sha256(body.encode()).hexdigest() == BASE_SHA256, 'unrelated call instructions changed'
    result = text[:a] + body + text[b:]
    assert 'CtExcelCallPolicy;->' not in result and 'ctexcel_call_policy_' not in result
    return result


def verify_ctexcel_call_policy(smali):
    text = (Path(smali) / 'f82.smali').read_text()
    for old, new in EDITS:
        assert text.count(new) == 1, 'missing CTExcel call policy hook'
    restored = reverse_ctexcel_call_policy('f82.smali', text)
    assert hashlib.sha256(restored.encode()).hexdigest() == BASE_CLASS_SHA256, 'other native coroutine methods changed'
    return {'native_methods': ['f82.q'], 'plmn': '23433',
            'identity_source': 'current registered IMS associated SIP public identity; native fallback retained',
            'identity_consistency': 'one selected immutable dialog identity supplies From and P-Preferred-Identity',
            'local_target': 'tel local-number with effective IMS domain phone-context',
            'international_target_unchanged': True,
            'early_media': 'initial registered INVITE, live negotiated Gm IPsec only; P-Early-Media supported',
            'unsupported_capability_tags_added': False,
            'registration_authentication_media_unchanged': True,
            'native_method_exactly_reversible': True, 'real_carrier_tested': False}
