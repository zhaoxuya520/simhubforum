#!/usr/bin/env python3
"""Local unsigned candidate from the pinned delivered APK. Never signs or publishes."""
from pathlib import Path
import hashlib, os, shutil, subprocess, zipfile
from multichip_patch import apply_multichip
from identity_patch import apply_identity
from carrier_presets_patch import apply_carrier_presets
from config_copy_patch import apply_config_copy
from editor_flow_patch import apply_editor_flow
from signing_policy import patch_delivered_security_policy, test_signer_digest
import json
ROOT=Path(__file__).resolve().parent
TOOLS=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
BASE=Path(os.environ.get('SIMHUB_CONFIG2_APK','/workspace/recovery/config2-signed.apk'))
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='cdd748532360f5632dc5661c0e8d9c9907967a0a136be16dfde118de43ad81c2'
B=ROOT/'build-config3';B.mkdir(exist_ok=True)
def run(*args):subprocess.run(list(map(str,args)),check=True,cwd=ROOT)
for name in ('apktool','classes','dex','module-decoded'):
 p=B/name
 if p.exists():shutil.rmtree(p)
for name in ('classes','dex'):(B/name).mkdir()
run('java','-jar',TOOLS/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-cp',TOOLS/'sdk/android-35/android.jar','-d',B/'classes',*sorted((ROOT/'src').rglob('*.java')))
with zipfile.ZipFile(B/'module.jar','w')as z:
 for p in (B/'classes').rglob('*.class'):z.write(p,p.relative_to(B/'classes'))
run('java','-cp',TOOLS/'sdk/android-15/lib/d8.jar','com.android.tools.r8.D8','--min-api','28','--lib',TOOLS/'sdk/android-35/android.jar','--output',B/'dex',B/'module.jar')
with zipfile.ZipFile(BASE)as src,zipfile.ZipFile(B/'module.apk','w')as z:
 for name in ('AndroidManifest.xml','resources.arsc'):z.writestr(name,src.read(name))
 z.write(B/'dex/classes.dex','classes.dex')
for name,apk in [('module-decoded',B/'module.apk'),('apktool',BASE)]:
 run('java','-jar',TOOLS/'apktool_3.0.3.jar','d','-r','-j','2','-o',B/name,apk)
smali=B/'apktool/smali'
baseline={str(p.relative_to(smali)):p.read_bytes() for p in smali.rglob('*.smali')}
security=smali/'mg.smali'
security.write_text(patch_delivered_security_policy(security.read_text()))
apply_multichip(smali);apply_identity(smali);apply_editor_flow(smali)
apply_carrier_presets(B/'apktool')
apply_config_copy(B/'apktool')
helper=smali/'cc/forserein/simhub/internal'
shutil.rmtree(helper)
shutil.copytree(B/'module-decoded/smali/cc/forserein/simhub/internal',helper)
run('python3',ROOT/'tests/check_refresh_flow.py',smali/'hz3.smali')
run('python3',ROOT/'tests/check_switch_request_flow.py',smali/'InternalSimSwitchRequest.smali')
run('python3',ROOT/'tests/check_multichip_flow.py',smali/'InternalSimMultiChipSwitch.smali')
run('python3',ROOT/'tests/check_checked_read_flow.py',smali/'InternalSimChipRead.smali')
changed={name for name,data in baseline.items() if (smali/name).read_bytes()!=data}
assert {name for name in changed if not name.startswith('cc/forserein/simhub/internal/')} == {'cg0.smali','iz3.smali','zl5.smali','dm5.smali','mg.smali','hz3.smali','pg1.smali','sj.smali','fd2.smali'}
assert (smali/'InternalSimMultiChipSwitch.smali').is_file()
print('Pinned-base comparison: all existing app classes unchanged except cg0, iz3, zl5, dm5, hz3, pg1, sj, fd2, the pinned signer allowlist and patch helpers',flush=True)
run('java','-Xmx3g','-jar',TOOLS/'apktool_3.0.3.jar','b','-j','2','-o',B/'candidate-unaligned.apk',B/'apktool')
align=TOOLS/'sdk/android-15/zipalign';align.chmod(0o755)
run(align,'-P','16','-f','4',B/'candidate-unaligned.apk',B/'SIMHub-23.1-config3-unsigned.apk')
run(align,'-c','-P','16','4',B/'SIMHub-23.1-config3-unsigned.apk')
with zipfile.ZipFile(B/'SIMHub-23.1-config3-unsigned.apk')as z:
 assert z.testzip() is None
 with zipfile.ZipFile(BASE) as original:
  for name in original.namelist():
   if name in ('classes.dex','assets/vowifi/carrier_presets.json','assets/i18n/zh-Hans.strings','assets/i18n/zh-Hant.strings') or name.startswith('META-INF/') or name.endswith('/') :continue
   assert original.read(name)==z.read(name),name
 print('Non-DEX app contents preserved except the expanded carrier preset library; new catalogue added')
 assert not any(name.endswith(('.SF','.RSA','.DSA','.EC')) and name.startswith('META-INF/') for name in z.namelist())
print('Unsigned candidate only:',B/'SIMHub-23.1-config3-unsigned.apk')

unsigned=B/'SIMHub-23.1-config3-unsigned.apk'
source_files=list((ROOT/'src').rglob('*.java'))+list((ROOT/'smali').glob('*.smali'))+list(ROOT.glob('*.py'))+[ROOT/'signing/local-test-certificate.pem']
report={'base_apk_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'unsigned_apk_sha256':hashlib.sha256(unsigned.read_bytes()).hexdigest(),'signer_sha256':test_signer_digest(),'changed_existing_classes':sorted(changed),'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source_files)},'apk_zip_integrity':True,'alignment_16kb':True,'device_tested':False}
(B/'candidate-validation.json').write_text(json.dumps(report,indent=2)+'\n')
