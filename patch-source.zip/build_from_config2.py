#!/usr/bin/env python3
"""Local unsigned candidate from the pinned delivered APK. Never signs or publishes."""
from pathlib import Path
import hashlib, os, shutil, subprocess, zipfile
from multichip_patch import verify_native_switch_routes
from estk_switch_patch import apply_estk_switch, restore_estk_hz3, restore_estk_pg1
from eap_identity_replay_patch import apply_eap_identity_replay, verify_eap_identity_replay
from eap_response_log_patch import apply_eap_response_log
from identity_patch import apply_identity
from carrier_presets_patch import apply_carrier_presets
from config_copy_patch import apply_config_copy
from editor_flow_patch import apply_editor_flow
from smsc_editor_patch import apply_smsc_editor, reverse_smsc_editor, verify_smsc_editor
from amr_framing_patch import apply_amr_framing
from registration_timing_patch import apply_registration_timing, restore_native as restore_registration
from sip_session_timer_patch import apply_sip_session_timer, verify_sip_session_timer, reverse_sip_session_timer, SIP_CLASSES
from audio_lifecycle_patch import apply_audio_lifecycle, transform as audio_lifecycle_transform
from notification_action_patch import apply_notification_actions, reverse_notification_actions, EDITS as NOTIFICATION_EDITS
from diagnostic_share_patch import apply_diagnostic_share, reverse_diagnostic_share
from sip_fork_patch import apply_sip_fork, reverse_sip_fork, verify_sip_fork, FORK_CLASSES
from sip_invite_failure_patch import apply_sip_invite_failure, verify_sip_invite_failure
from ui_theme_patch import apply_ui_theme, BASELINE as UI_CLASSES
from reader_wifi_presentation_patch import apply_reader_wifi_presentation
from version_update import apply_version, manifest_version, VERSION_NAME, VERSION_CODE
from signing_policy import patch_delivered_security_policy, test_signer_digest
import json
ROOT=Path(__file__).resolve().parent
TOOLS=Path(os.environ.get('SIMHUB_TOOLS','/workspace/tools/android-recovery'))
BASE=Path(os.environ.get('SIMHUB_CONFIG2_APK','/workspace/recovery/config2-signed.apk'))
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='cdd748532360f5632dc5661c0e8d9c9907967a0a136be16dfde118de43ad81c2'
B=ROOT/'build-config3';B.mkdir(exist_ok=True)
def run(*args):subprocess.run(list(map(str,args)),check=True,cwd=ROOT)
for name in ('apktool','classes','dex','module-decoded','host-regressions','dex-verifier-classes','native-carrier-current','native-eap-current','native-amr-current','native-sip-current','native-registration-current','native-audio-current','native-notification-current','native-diagnostics-current','native-fork-current'):
 p=B/name
 if p.exists():shutil.rmtree(p)
for name in ('candidate-validation.json','longterm-signed-validation.json','SIMHub-23.1-config3-unsigned.apk'):
 (B/name).unlink(missing_ok=True)
for name in ('classes','dex'):(B/name).mkdir()
sources=sorted(p for p in (ROOT/'src').rglob('*.java') if p.name!='MultiChipSwitch.java')
run('java','-jar',TOOLS/'ecj-3.40.0.jar','-8','-encoding','UTF-8','-cp',TOOLS/'sdk/android-35/android.jar','-d',B/'classes',*sources)
with zipfile.ZipFile(B/'module.jar','w')as z:
 for p in (B/'classes').rglob('*.class'):z.write(p,p.relative_to(B/'classes'))
run('java','-cp',TOOLS/'sdk/android-15/lib/d8.jar','com.android.tools.r8.D8','--min-api','28','--lib',TOOLS/'sdk/android-35/android.jar','--output',B/'dex',B/'module.jar')
with zipfile.ZipFile(BASE)as src,zipfile.ZipFile(B/'module.apk','w')as z:
 for name in ('AndroidManifest.xml','resources.arsc'):z.writestr(name,src.read(name))
 z.write(B/'dex/classes.dex','classes.dex')
for name,apk in [('module-decoded',B/'module.apk'),('apktool',BASE)]:
 run('java','-jar',TOOLS/'apktool_3.0.3.jar','d','-r','-j','2','-o',B/name,apk)
smali=B/'apktool/smali'
baseline={str(p.relative_to(smali)):p.read_bytes() for p in smali.rglob('*.smali')}
auth_signature='public final u(Lac5;Lxi5;Lek5;ILdt0;)Ljava/lang/Object;'
auth_method=baseline['zl5.smali'].decode().split('.method '+auth_signature+'\n',1)[1].split('.end method',1)[0]
dito_baseline={'base_apk_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),
 'class_sha256':{name:hashlib.sha256(baseline[name+'.smali']).hexdigest() for name in ['ek5','o82','ac5','vb5','hm0','sl5']},
 'native_worker_sha256':hashlib.sha256(auth_method.encode()).hexdigest()}
(B/'dito-native-baseline.json').write_text(json.dumps(dito_baseline,indent=2)+'\n')
security=smali/'mg.smali'
security.write_text(patch_delivered_security_policy(security.read_text()))
verify_native_switch_routes(smali);apply_identity(smali);apply_editor_flow(smali)
apply_estk_switch(smali)
assert restore_estk_hz3((smali/'hz3.smali').read_text()).encode()==baseline['hz3.smali']
assert restore_estk_pg1((smali/'pg1.smali').read_text()).encode()==baseline['pg1.smali']
apply_smsc_editor(smali)
apply_eap_response_log(smali)
apply_eap_identity_replay(smali)
assert reverse_smsc_editor('mc0.smali',(smali/'mc0.smali').read_text()).encode()==baseline['mc0.smali']
(B/'smsc-editor-integration.json').write_text(json.dumps(verify_smsc_editor(smali),indent=2)+'\n')
apply_amr_framing(smali)
apply_registration_timing(smali)
apply_sip_session_timer(smali)
apply_sip_fork(smali)
apply_sip_invite_failure(smali)
(B/'sip-invite-failure-integration.json').write_text(json.dumps(verify_sip_invite_failure(smali),indent=2)+'\n')
apply_audio_lifecycle(smali)
apply_notification_actions(smali)
apply_diagnostic_share(smali)
assert reverse_diagnostic_share('ej.smali',(smali/'ej.smali').read_text()).encode()==baseline['ej.smali'],'Diagnostic share changed beyond bounded output hook'
(B/'diagnostic-share-integration.json').write_text(json.dumps(dict(native_class='ej',whole_class_restored_exactly=True,hook_count=1,scope='existing diagnostic ACTION_SEND body only',internal_log_changed=False),indent=2)+'\n')
notification_classes={entry[0] for entry in NOTIFICATION_EDITS}
for name in sorted(notification_classes):
 assert reverse_notification_actions(name,(smali/name).read_text()).encode()==baseline[name],name+' changed beyond bounded notification hooks'
for name in sorted(SIP_CLASSES | {'bh1.smali'}):
 restored=(smali/name).read_text()
 if name in FORK_CLASSES:restored=reverse_sip_fork(name,restored)
 if name in SIP_CLASSES:restored=reverse_sip_session_timer(name,restored)
 if name in ('o82.smali','bh1.smali'):restored=restore_registration(name,restored)
 assert restored.encode()==baseline[name],name+' changed beyond bounded timing hooks'
assert (smali/'yz.smali').read_text()==audio_lifecycle_transform(baseline['yz.smali'].decode()),'Audio controller changed beyond bounded lifecycle hooks'
(B/'protocol-preservation.json').write_text(json.dumps(dict(full_classes_compared=sorted({'bh1.smali','cb4.smali','ma4.smali','o82.smali','yz.smali','ej.smali'}|notification_classes),pinned_base_sha256=hashlib.sha256(BASE.read_bytes()).hexdigest(),unrelated_instructions_preserved=True),indent=2)+'\n')
(B/'sip-timer-integration.json').write_text(json.dumps(verify_sip_session_timer(smali,reverse_sip_fork),indent=2)+'\n')
(B/'sip-fork-integration.json').write_text(json.dumps(verify_sip_fork(smali),indent=2)+'\n')
apply_carrier_presets(B/'apktool')
apply_config_copy(B/'apktool')
apply_reader_wifi_presentation(smali)
apply_ui_theme(smali)
apply_version(B/'apktool')
helper=smali/'cc/forserein/simhub/internal'
shutil.rmtree(helper)
shutil.copytree(B/'module-decoded/smali/cc/forserein/simhub/internal',helper)
run('python3',ROOT/'tests/check_toggle_routes.py',B/'apktool')
run('python3',ROOT/'tests/check_compact_editor_integration.py',B/'apktool')
run('python3',ROOT/'tests/check_carrier_picker_integration.py',B/'apktool')
run('python3',ROOT/'tests/check_smsc_integration.py',B/'apktool')
run('python3',ROOT/'tests/check_sms_editor_integration.py',B/'apktool')
verify_eap_identity_replay(smali)
run('python3',ROOT/'tests/check_dito_identity_integration.py',B/'apktool',B/'dito-native-baseline.json')
run('python3',ROOT/'tests/check_refresh_flow.py',smali/'hz3.smali')
run('python3',ROOT/'tests/check_native_switch_recovery.py',B/'apktool',BASE)
run('python3',ROOT/'tests/check_amr_integration.py',B/'apktool',BASE)
run('python3',ROOT/'tests/check_registration_timing_integration.py',B/'apktool')
run('python3',ROOT/'tests/sip_check_integration.py',B/'apktool')
run('python3',ROOT/'tests/sip_fork_check_integration.py',B/'apktool','--report',B/'sip-fork-integration.json')
run('python3',ROOT/'tests/check_notification_integration.py',B/'apktool')
run('python3',ROOT/'tests/check_diagnostic_share_integration.py',smali)
run('python3',ROOT/'tests/check_ui_theme.py',B/'apktool')
run('python3',ROOT/'tests/check_reader_wifi_presentation_integration.py',B/'apktool','--report',B/'reader-presentation-integration.json')
run('python3',ROOT/'tests/run_host_regressions.py','--report',B/'host-test-results.json')
changed={name for name,data in baseline.items() if (smali/name).read_bytes()!=data}
assert {name for name in changed if not name.startswith('cc/forserein/simhub/internal/')} == {'hz3.smali','pg1.smali','b72.smali','da1.smali','mc0.smali','iz3.smali','zl5.smali','dm5.smali','mg.smali','fd2.smali','rt.smali','i21.smali','t10.smali','m10.smali','k7.smali','r75.smali','o82.smali','bh1.smali','yz.smali','ej.smali'} | set(UI_CLASSES) | SIP_CLASSES | notification_classes
print('Pinned-base comparison passed, including the eSTK dual-chip switch entry point',flush=True)
run('java','-Xmx3g','-jar',TOOLS/'apktool_3.0.3.jar','b','-j','2','-o',B/'candidate-unaligned.apk',B/'apktool')
align=TOOLS/'sdk/android-15/zipalign';align.chmod(0o755)
run(align,'-P','16','-f','4',B/'candidate-unaligned.apk',B/'SIMHub-23.1-config3-unsigned.apk')
run(align,'-c','-P','16','4',B/'SIMHub-23.1-config3-unsigned.apk')
with zipfile.ZipFile(B/'SIMHub-23.1-config3-unsigned.apk')as z:
 assert z.testzip() is None
 with zipfile.ZipFile(BASE) as original:
  for name in original.namelist():
   if name=='AndroidManifest.xml':
    updated=z.read(name);expected=manifest_version(original.read(name),True)
    assert updated==expected,'Manifest changed outside versionName or versionCode'
    assert manifest_version(updated)==dict(versionName=VERSION_NAME,versionCode=VERSION_CODE)
    continue
   if name in ('classes.dex','assets/vowifi/carrier_presets.json','assets/i18n/zh-Hans.strings','assets/i18n/zh-Hant.strings') or name.startswith('META-INF/') or name.endswith('/') :continue
   assert original.read(name)==z.read(name),name
 print('Non-DEX app contents preserved except the expanded carrier preset library; new catalogue added')
 assert not any(name.endswith(('.SF','.RSA','.DSA','.EC')) and name.startswith('META-INF/') for name in z.namelist())
print('Unsigned candidate only:',B/'SIMHub-23.1-config3-unsigned.apk')

unsigned=B/'SIMHub-23.1-config3-unsigned.apk'
run('python3',ROOT/'tests/check_dex_types.py',unsigned,'--report',B/'dex-type-validation.json')
run('python3',ROOT/'tests/check_native_carrier_runtime.py',unsigned,B/'apktool','--report',B/'native-carrier-runtime.json')
run('python3',ROOT/'validation/native-invite-failure/check_runtime.py',unsigned,'--carrier-report',B/'native-carrier-runtime.json','--report',B/'native-invite-failure-runtime.json')
run('python3',ROOT/'validation/native-cross-switch/check_runtime.py',unsigned,'--carrier-report',B/'native-carrier-runtime.json','--report',B/'native-cross-switch-runtime.json')
run('python3',ROOT/'tests/check_native_eap_runtime.py',unsigned,B/'apktool','--report',B/'native-eap-runtime.json')
run('python3',ROOT/'validation/native-identity/identity_check_runtime.py',unsigned,B/'apktool','--carrier-report',B/'native-carrier-runtime.json','--report',B/'native-identity-runtime.json')
run('python3',ROOT/'tests/check_native_amr_runtime.py',unsigned,B/'apktool','--report',B/'native-amr-runtime.json')
run('python3',ROOT/'tests/check_native_sip_runtime.py',unsigned,B/'apktool','--report',B/'native-sip-runtime.json')
run('python3',ROOT/'tests/check_native_registration_runtime.py',unsigned,B/'apktool','--report',B/'native-registration-runtime.json')
run('python3',ROOT/'tests/check_native_audio_runtime.py',unsigned,B/'apktool','--report',B/'native-audio-runtime.json')
run('python3',ROOT/'tests/check_native_notification_runtime.py',unsigned,B/'apktool','--report',B/'native-notification-runtime.json')
run('python3',ROOT/'tests/check_native_diagnostics_runtime.py',unsigned,B/'apktool','--report',B/'native-diagnostics-runtime.json')
run('python3',ROOT/'tests/check_native_fork_runtime.py',unsigned,B/'apktool','--report',B/'native-fork-runtime.json')
source_files=list((ROOT/'src').rglob('*.java'))+list((ROOT/'smali').glob('*.smali'))+list(ROOT.glob('*.py'))+[ROOT/'signing/local-test-certificate.pem',ROOT/'tests/check_dex_types.py',ROOT/'tests/check_native_switch_recovery.py',ROOT/'tests/check_smsc_integration.py',ROOT/'tests/check_dito_identity_integration.py',ROOT/'tests/check_native_carrier_runtime.py',ROOT/'validation/native-switch-baseline.json',ROOT/'validation/dito-reference-v29.3.json']+list((ROOT/'validation/dex').glob('*'))+list((ROOT/'validation/native-carrier').glob('*'))
report={'base_apk_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'unsigned_apk_sha256':hashlib.sha256(unsigned.read_bytes()).hexdigest(),'signer_sha256':test_signer_digest(),'changed_existing_classes':sorted(changed),'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source_files) if p.is_file()},'apk_zip_integrity':True,'alignment_16kb':True,'device_tested':False,'dex_type_validation':json.loads((B/'dex-type-validation.json').read_text()),'native_carrier_probe':json.loads((B/'native-carrier-runtime.json').read_text())}
for p in [ROOT/'tests/check_amr_integration.py',ROOT/'tests/check_native_amr_runtime.py',ROOT/'tests/AmrFramingTest.java']+list((ROOT/'validation/native-amr').rglob('*')):
 if p.is_file():report['source_sha256'][str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
report['native_amr_probe']=json.loads((B/'native-amr-runtime.json').read_text())
for kind in ('cross-switch','invite-failure','eap','identity','sip','registration','audio','notification','diagnostics','fork'):
 report['native_'+kind+'_probe']=json.loads((B/('native-'+kind+'-runtime.json')).read_text())
for p in [ROOT/'tests/check_ui_theme.py',ROOT/'tests/run_host_regressions.py',ROOT/'tests/check_compact_editor_integration.py',ROOT/'tests/check_carrier_picker_integration.py']+list((ROOT/'tests').rglob('*.java')):
 if p.is_file():report['source_sha256'][str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
# Pin all protocol probes and fixtures as well as their production hooks. Signing
# must reject a validation script or reference manifest changed after this build.
for folder in ('tests','validation'):
 for p in sorted((ROOT/folder).rglob('*')):
  if p.is_file() and p.suffix in ('.py','.java','.json','.md'):
   report['source_sha256'][str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
report.update(version_name=VERSION_NAME,version_code=VERSION_CODE,ui_theme=json.loads((B/'ui-theme-validation.json').read_text()))
(B/'candidate-validation.json').write_text(json.dumps(report,indent=2)+'\n')
