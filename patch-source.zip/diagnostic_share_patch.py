"""Redact only the existing VoWiFi diagnostic ACTION_SEND body; no global clipboard hook."""
from pathlib import Path
import hashlib,re

ORIGINAL_SHA256='60c104ef78b0578a952508d2a17e9819f0f93f764f3c186f7b74136f0cc21e65'

SIGNATURE='public final a()Ljava/lang/Object;'
ANCHOR='''    const-string v2, "android.intent.extra.TEXT"

    .line 108'''
HOOK='''    invoke-static {v1}, Lcc/forserein/simhub/internal/DiagnosticShareSanitizer;->sanitize(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

'''

def transform(text,reverse=False):
    if not reverse:assert hashlib.sha256(text.encode()).hexdigest()==ORIGINAL_SHA256,'ej baseline changed'
    pattern=re.compile(r'(^\.method '+re.escape(SIGNATURE)+r'\n)(.*?)(^\.end method)',re.M|re.S)
    assert len(pattern.findall(text))==1,'ej.a method mismatch'
    def edit(match):
        body=match[2]
        assert body.count('const-string v2, "SIMHub VoWiFi SMS log"')==1,'share subject changed'
        assert body.count('const-string v1, "android.intent.action.SEND"')==1,'share action changed'
        old,new=(HOOK+ANCHOR,ANCHOR)if reverse else(ANCHOR,HOOK+ANCHOR)
        assert body.count(old)==1,'diagnostic share hook anchor mismatch'
        if not reverse:assert 'DiagnosticShareSanitizer;'not in body,'already patched'
        return match[1]+body.replace(old,new,1)+match[3]
    result=pattern.sub(edit,text)
    if reverse:assert hashlib.sha256(result.encode()).hexdigest()==ORIGINAL_SHA256,'ej reverse mismatch'
    return result

def apply_diagnostic_share(smali):
    path=Path(smali)/'ej.smali';path.write_text(transform(path.read_text()))

def reverse_diagnostic_share(name,text):
    return transform(text,True)if name=='ej.smali'else text
