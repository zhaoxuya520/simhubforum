"""Add per-call framing detection around the unchanged native AMR parser/packetizer."""
from pathlib import Path

TYPE='Lcc/forserein/simhub/internal/AmrFraming;'
FIELD='Lt10;->simhubAmrFraming:'+TYPE

def replacements():
    ctor='    iput-object v0, p0, Lt10;->c:Lw;'
    receive='    iget-boolean v2, v2, Lq93;->g:Z'
    send='    iget-boolean v5, v5, Lq93;->g:Z'
    update='    iput-object v1, v0, Lt10;->b:Lq93;'
    return {
        't10.smali':[
            ('.field public E:Z','.field public E:Z\n\n.field public final simhubAmrFraming:'+TYPE),
            (ctor,ctor+f'''

    new-instance v1, {TYPE}
    invoke-virtual {{v0}}, Lw;->a()I
    move-result v2
    iget-boolean v4, p2, Lq93;->g:Z
    invoke-direct {{v1, v2, v4}}, {TYPE}-><init>(IZ)V
    iput-object v1, p0, {FIELD}
''')],
        'm10.smali':[(receive,f'''    iget-object v4, v1, {FIELD}
    invoke-virtual {{v4, v0}}, {TYPE}->receive([B)I
    move-result v2
    invoke-virtual {{v4}}, {TYPE}->takeNotice()Ljava/lang/String;
    move-result-object v4
    if-eqz v4, :simhub_amr_ready
    iget-object v5, v1, Lt10;->a:Lo82;
    iget-object v5, v5, Lo82;->g:Lg11;
    invoke-virtual {{v5, v4}}, Lg11;->i(Ljava/lang/Object;)Ljava/lang/Object;
    :simhub_amr_ready
    if-ltz v2, :cond_14''')],
        'k7.smali':[
            (send,f'''    iget-object v5, v1, {FIELD}
    invoke-virtual {{v5}}, {TYPE}->isOctetAligned()Z
    move-result v5'''),
            (update,update+f'''
    iget-object v2, v0, {FIELD}
    iget-boolean v3, v1, Lq93;->g:Z
    invoke-virtual {{v2, v3}}, {TYPE}->updateNegotiation(Z)V
''')]
    }

def apply_amr_framing(smali:Path):
    for name,edits in replacements().items():
        path=smali/name;value=path.read_text()
        for old,new in edits:
            assert value.count(old)==1,(name,old)
            value=value.replace(old,new)
        path.write_text(value)

def restore_native(name,value):
    for old,new in reversed(replacements()[name]):
        assert value.count(new)==1,(name,'AMR integration absent or duplicated')
        value=value.replace(new,old)
    return value
