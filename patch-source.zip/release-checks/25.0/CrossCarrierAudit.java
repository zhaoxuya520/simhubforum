import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Exercise the supplied APK's preset resolver and INVITE sender with local transport boundaries. */
public final class CrossCarrierAudit {
    static Object field(Object object, String name) throws Exception {
        return PreconditionProbe.get(object, name);
    }

    static void writeConfig(String kind, String key, Object config) throws Exception {
        List<?> servers = (List<?>) field(config, "f");
        StringBuilder endpoints = new StringBuilder();
        for (Object server : servers) {
            if (endpoints.length() > 0) endpoints.append(',');
            endpoints.append(server);
        }
        System.out.println(String.join("\t", kind, key, String.valueOf(field(config, "b")),
            String.valueOf(field(config, "c")), String.valueOf(field(config, "d")) + field(config, "e"),
            endpoints.toString(), String.valueOf(field(config, "g"))));
    }

    static void wire(String origin, String dial, boolean tcp) throws Exception {
        PreconditionProbe.Call fixture = new PreconditionProbe.Call(tcp);
        Object e = fixture.nativeSession.e, m = fixture.nativeSession.m;
        ((Map<?,?>) field(m, "e")).clear();
        PreconditionProbe.wires.clear();
        String imsi = (origin + "0000000001").substring(0, 15);
        Object card = Class.forName("ek5").getConstructors()[0].newInstance(imsi,
                "8999990000000000001", origin.length() - 3, gid.get(origin), null, null, null, null);
        Class<?> presets = Class.forName("cc.forserein.simhub.internal.CarrierPresets");
        Object config = presets.getMethod("defaults", Object.class, Map.class).invoke(null, card, null);
        PreconditionProbe.set(e, "b", config);
        PreconditionProbe.set(e, "c", card);
        PreconditionProbe.set(e, "n", "urn:uuid:comparison");
        PreconditionProbe.set(e, "o", "020000000001");
        PreconditionProbe.set(e, "p", "00000001");
        PreconditionProbe.set(field(e, "s"), "a", Arrays.asList(CtExcelOriginationProbe.TEL, CtExcelOriginationProbe.SIP));
        PreconditionProbe.set(field(e, "s"), "e", new java.util.ArrayList<>(Arrays.asList("<sip:proxy1.example.invalid;lr>", "<sip:proxy2.example.invalid;lr>")));
        PreconditionProbe.call(e, "s", new Class<?>[0]);
        Object task = Class.forName("f82").getConstructor(Class.forName("o82"), String.class,
                Class.forName("ct0"), int.class).newInstance(e, dial, null, 4);
        Object id = PreconditionProbe.call(task, "q", new Class<?>[]{Object.class}, Class.forName("sc5").getField("a").get(null));
        if (!((Map<?,?>)field(m,"e")).containsKey(id) || PreconditionProbe.wires.size() != 1)
            throw new AssertionError("expected exactly one INVITE and one preserved dialog");
        String wire = PreconditionProbe.wires.get(0);
        Object invite = PreconditionProbe.parse(wire);
        String uri = String.valueOf(field(invite, "c"));
        if (!("<" + uri + ">").equals(PreconditionProbe.first(invite, "To"))) throw new AssertionError("unexpected To");
        String prefix = dial.startsWith("+") ? "E164" : "LOCAL";
        System.out.println(String.join("\t", "RAW", origin, dial, String.valueOf(field(config, "b")),
                java.util.Base64.getEncoder().encodeToString(wire.getBytes(java.nio.charset.StandardCharsets.UTF_8))));
        Object response = PreconditionProbe.response(wire, 183, "branch", "", "Require: 100rel\r\nRSeq: 1\r\n");
        if (!fixture.nativeSession.accept(response) || PreconditionProbe.last("PRACK") == null)
            throw new AssertionError("reliable 183 must generate PRACK");
        System.out.println("DIAL-" + origin + "-" + prefix + " template=" + field(config, "b") + " target=" + uri);
    }

    static final Map<String,String> gid = new LinkedHashMap<>();
    static void readGids(String value) {
        for (String pair : value.split(",")) {
            String[] entry = pair.split(":");
            gid.put(entry[0],entry[1]);
        }
    }
    public static void main(String[] args) throws Exception {
        readGids(args[3]);
        android.content.res.AssetManager.root = Paths.get(args[0]);
        Class.forName("fj5").getField("d").set(null, new android.content.Context());
        Class<?> presets = Class.forName("cc.forserein.simhub.internal.CarrierPresets");
        Class<?> entryClass = Class.forName(presets.getName() + "$Entry");
        Constructor<?> identity = Class.forName("ek5").getConstructors()[0];
        Method apply = presets.getMethod("apply", entryClass, Object.class);
        Map<String, Object> cards = new LinkedHashMap<>();
        for (Object entry : (List<?>) presets.getMethod("all").invoke(null)) {
            String key = (String) field(entry, "key");
            String plmn = (String) field(entry, "plmn");
            Object card = cards.get(plmn);
            if (card == null) {
                String imsi = (plmn + "0000000001").substring(0, 15);
                card = identity.newInstance(imsi, "8999990000000000001", plmn.length() - 3, null, null, null, null, null);
                cards.put(plmn, card);
                writeConfig("AUTO", plmn, presets.getMethod("defaults", Object.class, Map.class).invoke(null, card, null));
            }
            writeConfig("MANUAL", key, apply.invoke(null, entry, card));
        }

        Constructor<?> readCard = Class.forName("ek5").getConstructors()[0];
        Method auto = presets.getMethod("defaults", Object.class, Map.class);
        for (String line : java.nio.file.Files.readAllLines(Paths.get(args[4]))) {
            String[] v = line.split("\\t", -1);
            String imsi = (v[1] + "0000000001").substring(0, 15);
            Object card = readCard.newInstance(imsi, v[2], v[1].length()-3,
                    v[3].isEmpty() ? null : v[3], v[4].isEmpty() ? null : v[4], null, null, null);
            Object selected = auto.invoke(null, card, null);
            System.out.println("RULE\t" + v[0] + "\t" + field(selected, "b"));
        }
        SipForkProbe.msg = Class.forName("kb4");
        SipForkProbe.dialog = Class.forName("ma4");
        SipForkProbe.manager = Class.forName("cb4");
        SipForkProbe.direction = Class.forName("ga4");
        SipForkProbe.state = Class.forName("la4");
        SipForkProbe.helper = Class.forName("cc.forserein.simhub.internal.SipForkProtection");
        String[] origins = args[1].split(",");
        String[] destinations = args[2].split(",");
        for (String origin : origins) {
            for (int i = 0; i < destinations.length; i++)
                wire(origin, destinations[i], (i & 1) == 0);
        }
        System.out.println("WIRES\t" + origins.length * destinations.length + "\t" + PreconditionProbe.checks
                + "\t" + PreconditionProbe.protectedPackets);
    }
}
