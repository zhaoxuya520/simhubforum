import java.lang.reflect.*;
import java.nio.file.Paths;
import java.util.*;

/** Capture the reference APK's completed dialog before live dispatch to any socket or SIM. */
public final class UpstreamInvites {
    static Class<?> cls(String name) throws Exception { return Class.forName(name); }
    static Object field(Object o,String k) throws Exception {return o.getClass().getField(k).get(o);}
    static void set(Object o,String k,Object v) throws Exception {Field f=o.getClass().getField(k);f.setAccessible(true);f.set(o,v);}
    static Object alloc(String name) throws Exception {
        Class<?> u=cls("sun.misc.Unsafe");
        Field field=u.getDeclaredField("theUnsafe");field.setAccessible(true);
        return u.getMethod("allocateInstance",Class.class).invoke(field.get(null),cls(name));
    }
    static class Captured extends RuntimeException {}
    static class Capture extends LinkedHashMap<Object,Object> {
        byte[] wire;
        @Override public Object put(Object key, Object dialog) {
            try {Object invite=field(dialog,"j");wire=(byte[])invite.getClass().getMethod("b").invoke(invite);}
            catch(Exception problem){throw new IllegalStateException(problem);}
            throw new Captured();
        }
    }

    static final Map<String,String> gid = new LinkedHashMap<>();
    static void readGids(String value) {
        for (String pair : value.split(",")) {
            String[] entry = pair.split(":");
            gid.put(entry[0],entry[1]);
        }
    }
    public static void main(String[] args) throws Exception {
        readGids(args[3]);
        android.content.res.AssetManager.root=Paths.get(args[0]);
        cls("tq5").getField("d").set(null,new android.content.Context());
        for (String origin : args[1].split(",")) {
            String imsi=(origin+"0000000001").substring(0,15);
            Object card=cls("ur5").getConstructors()[0].newInstance(imsi,"8999990000000000001",origin.length()-3,gid.get(origin),null,null,null,null,null);
            Object config=cls("uq5").getMethod("e",cls("ur5")).invoke(null,card);
            Object engine=alloc("da2"), manager=alloc("gh4"), reg=alloc("j92");
            set(engine,"S",alloc("rg2"));set(engine,"J",true);set(engine,"K",manager);set(engine,"t",reg);
            set(engine,"b",config);set(engine,"c",card);
            Object address=cls("ma2").getConstructor(byte[].class).newInstance((Object)new byte[]{0x20,1,0xd,(byte)0xb8,0,0,0,0,0,0,0,0,0,0,0,1});
            set(engine,"i",address);set(engine,"n",40001);set(engine,"o","urn:uuid:comparison");
            set(engine,"p","020000000001");set(engine,"q","00000001");
            set(reg,"a",Arrays.asList("tel:+447700900121","sip:+447700900121@registered.example.invalid;user=phone"));set(reg,"e",new ArrayList<>(Arrays.asList("<sip:proxy1.example.invalid;lr>","<sip:proxy2.example.invalid;lr>")));
            set(engine,"r",alloc("i92"));set(engine,"R",Arrays.asList("ipsec-3gpp;alg=hmac-sha-1-96;ealg=aes-cbc;spi-c=131073;spi-s=131074;port-c=50000;port-s=50001"));
            Object offer=cls("h21").getConstructor(cls("ma2"),int.class,List.class,cls("da2")).newInstance(address,45000,cls("fl").getField("c").get(null),engine);
            set(manager,"c",offer);
            for(String destination:args[2].split(",")) {
                boolean tcp=(Arrays.asList(args[2].split(",")).indexOf(destination)%2)==0;
                set(engine,"X",!tcp);
                engine.getClass().getMethod("w").invoke(engine);
                Capture results=new Capture();set(manager,"e",results);
                Object task=cls("r92").getConstructors()[0].newInstance(engine,destination,null,1);
                // Start after the same-card APDU preflight at its normal continuation resume branch.
                set(task,"Z",1);set(task,"Y",manager);
                try {task.getClass().getMethod("q",Object.class).invoke(task,cls("yj5").getField("a").get(null));}
                catch(InvocationTargetException ex){if(!(ex.getCause() instanceof Captured))throw ex;}
                if(results.wire==null)throw new IllegalStateException(origin+" "+destination+" did not reach dialog commit");
                System.out.println("RAW\t"+origin+"\t"+destination+"\t"+field(config,"b")+"\t"+Base64.getEncoder().encodeToString(results.wire));
            }
        }
    }
}
