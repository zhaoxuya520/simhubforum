"""Exercise the two installed releases in ART on a dedicated offline Android emulator."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

root = Path(__file__).resolve().parent
report = root.parent/'android-dialing-validation.json'
base = root.parents[1]/'sms24.9-release/SIMHub-24.9-signed.apk'
signed = root.parents[1]/'call25.0-release/SIMHub-25.0-signed.apk'
old_digest = '34544ca9e4ade1136e438e31ab48055129d59fd355f787a70a7e43005efb625a'
adb = '/workspace/tools/android-preview/sdk/platform-tools/adb'
device='emulator-5582'
app='cc.forserein.simhub'
probe=root/'dial-art-probe.jar'
guest_probe='/data/local/tmp/call25-dial-art.jar'

def dev(*args):
    result = subprocess.run([adb, '-s', device, *map(str,args)], encoding='utf-8', capture_output=True, timeout=160)
    if result.returncode:
        raise RuntimeError(f'{args[0]} failed ({result.returncode}): {result.stdout} {result.stderr}')
    return result.stdout.strip()
def shell(*args):
    return dev('shell',*args)
def install(apk, version):
    staging = '/data/local/tmp/SIMHub-dial-validation-' + version + '.apk'
    if subprocess.run([adb, '-s', device, 'shell', 'test', '-f', staging]).returncode != 0 or shell('sha256sum',staging).split()[0] != digest(apk):
        dev('push',apk,staging)
        assert shell('sha256sum',staging).split()[0] == digest(apk)
    assert 'Success' in shell('pm','install','-r',staging)
def package():
    desc=shell('dumpsys','package',app)
    return {k: re.search(r'^\s*'+k+r'=([^\s\n]+(?: [0-9:]+)?)$', desc,re.M)[1]
            for k in ('versionName','userId','firstInstallTime')}
def installed():
    target=shell('pm','path',app).removeprefix('package:')
    assert re.fullmatch(r'/data/app/[-\w~+={}./]+/base\.apk',target), target
    return target,shell('sha256sum',target).split()[0]
def run_tests(mode, apk_hash, apk_path):
    assert shell('settings','get','global','airplane_mode_on')=='1'
    out=shell('env','CLASSPATH='+guest_probe+':'+apk_path,'app_process','/system/bin','DialArtSmoke',mode)
    expected='24.9' if mode=='baseline' else '25.0'
    assert out.splitlines()[-1]=='PASS 10 '+expected,out
    return dict(installed_apk_sha256=apk_hash, checks=10, package=package())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(file,data):
    file.write_text(json.dumps(data,indent=2)+'\n')
p=argparse.ArgumentParser()
p.add_argument('--baseline',action='store_true')
args=p.parse_args()
assert shell('getprop','ro.kernel.qemu')=='1'
assert 'Service package: found' in shell('service','check','package')
if args.baseline:
    assert digest(base)==old_digest
    shell('cmd','connectivity','airplane-mode','enable')
    shell('svc','wifi','disable')
    try:
        path, got=installed()
    except (AssertionError, RuntimeError):
        path, got='', ''
    if got != old_digest:
        install(base,'24.9')
        path, got=installed()
    assert got==old_digest
    dev('push',probe,guest_probe)
    assert shell('sha256sum',guest_probe).split()[0]==digest(probe)
    row=run_tests('baseline',got,path)
    assert row['package']['versionName']=='24.9'
    write(root/'baseline.json',row)
    print('Android 11 baseline passed',row,flush=True)
else:
    left=json.loads((root/'baseline.json').read_text())
    assert left['installed_apk_sha256']==old_digest
    assert shell('sha256sum',guest_probe).split()[0]==digest(probe)
    install(signed,'25.0')
    path,got=installed()
    assert digest(signed)==got
    right=run_tests('current',got,path)
    assert right['package']['versionName']=='25.0'
    for k in ('firstInstallTime','userId'):
        assert left['package'][k]==right['package'][k]
    launch=shell('am','start','-W','-n',app+'/.MainActivity')
    assert 'Status: ok' in launch,launch
    proc=shell('pidof',app)
    assert proc.strip().isdigit(),proc
    data=dict(passed=True,apk_sha256=got,previous_apk_sha256=old_digest,api=int(shell('getprop','ro.build.version.sdk')),
              android_art=True, same_signature_upgrade=True, launch_succeeded=True,
              preserved_install_time_and_uid=True, baseline_checks=10, current_checks=10,
              probe_sha256=digest(probe), live_carrier_test=False,
              scope='Real Android emulator. Reflection invokes DialingSupport.normalize and smsDestination from the package-manager installed APK in ART. Synthetic Belgian, German, UK, Italian and Chinese numbers. No SIM, SIP transaction or network call.')
    write(report,data)
    print(json.dumps(data,indent=2),flush=True)
