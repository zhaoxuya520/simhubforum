import java.lang.reflect.Method;

public final class DialArtSmoke {
    private static int checks;

    private static void equals(String expected, Object actual, String name) {
        if (!expected.equals(actual)) throw new AssertionError(name + " expected " + expected + ", got " + actual);
        checks++;
    }

    public static void main(String[] args) throws Exception {
        boolean previous = args.length == 1 && args[0].equals("baseline");
        Class<?> type = Class.forName("cc.forserein.simhub.internal.DialingSupport");
        Method normalize = type.getMethod("normalize", String.class);
        Method sms = type.getMethod("smsDestination", String.class);
        equals(previous ? "+32021234567" : "+3221234567", normalize.invoke(null, "+32 (0)2 123 45 67"), "Belgian fixed contact");
        equals(previous ? "00320470123456" : "0032470123456", normalize.invoke(null, "0032 (0)470 12 34 56"), "Belgian mobile contact");
        equals(previous ? "+32021234567" : "+3221234567", normalize.invoke(null, "＋３２ （０）２ １２３ ４５ ６７"), "fullwidth fixed contact");
        equals("+3221234567", normalize.invoke(null, "+32 2 123 45 67"), "international fixed number");
        equals("021234567", normalize.invoke(null, "02 123 45 67"), "national fixed number");
        equals("+390612345678", normalize.invoke(null, "+39 (0)6 1234 5678"), "Italian significant zero");
        equals("+493012345678", normalize.invoke(null, "+49 (0)30 1234 5678"), "German fixed number");
        equals("+442079460123", normalize.invoke(null, "+44 (0)20 7946 0123"), "British fixed number");
        equals("+861061234567", normalize.invoke(null, "+86 10 6123 4567"), "Chinese fixed number");
        equals("+32021234567", sms.invoke(null, "+32 (0)2 123 45 67"), "SMS path preserves 24.9 behavior");
        System.out.println("PASS " + checks + " " + (previous ? "24.9" : "25.0"));
    }
}
