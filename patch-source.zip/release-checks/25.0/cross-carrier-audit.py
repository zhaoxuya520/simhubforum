#!/usr/bin/env python3
"""Audit every bundled carrier locally and serialize cross-carrier INVITEs in the signed APK's code."""
import argparse
import collections
import compare_reference_invites as reference_invites
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

here = Path(__file__).resolve().parent
project = Path("/workspace/simhubforum/android/phone-slot-patch")
build = project / "build-config3"
reference = Path("/workspace/recovery/ctexcel24.4-review/user-reference")
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("apk", type=Path)
parser.add_argument("--baseline",action="store_true",help="Report known differences in previous 24.9")
parser.add_argument("--report", type=Path, required=True)
parser.add_argument("--carrier-report", type=Path, default=build / "native-carrier-runtime.json")
parser.add_argument("--unsigned-apk", type=Path, default=build / "SIMHub-23.1-config3-unsigned.apk")
parser.add_argument("--jar", type=Path, default=build / "native-carrier-current/probe.jar")
args = parser.parse_args()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes())


def valid_host(host):
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return len(host) <= 253 and "." in host and all(
            re.fullmatch(r"[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?", part)
            for part in host.rstrip(".").split("."))


def run(*cmd):
    process = subprocess.run(list(map(str, cmd)), text=True, capture_output=True)
    if process.returncode:
        raise RuntimeError(f"{cmd[0]} failed: {process.stderr[-3500:]}\n{process.stdout[-1800:]}")
    return process.stdout


carrier = json.loads(args.carrier_report.read_text())
assert carrier["apk_sha256"] == digest(args.unsigned_apk)
assert carrier["apk_translated_jar_sha256"] == digest(args.jar)
assets = ["assets/data/mcc_mnc.json", "assets/vowifi/carrier_presets.json", "assets/vowifi/global_standard_catalogue.json"]
validation = project / "validation"
shared = validation / "native-fork"
ct = validation / "native-ctexcel-call"
kit = Path(os.environ.get("SIMHUB_TOOLS", "/workspace/tools/android-recovery"))
dexkit = Path(os.environ.get("SIMHUB_DEX2JAR_TOOLS", "/workspace/tools/dex2jar-v2.4"))
lib = dexkit / "dex-tools-v2.4/lib"
asm = os.pathsep.join(str(lib / name) for name in ["asm-9.5.jar", "asm-tree-9.5.jar"])
sources = [shared / "g11.java", shared / "SipForkProbe.java", validation / "native-invite-failure/t00.java",
           ct / "CtExcelTransportAdapter.java", ct / "CtExcelOriginationProbe.java",
           validation / "native-preconditions/PreconditionProbe.java", validation / "native-carrier/AssetManager.java",
           validation / "native-carrier/Context.java", project / "tests/android/content/SharedPreferences.java",
           project / "tests/android/util/Log.java", validation / "native-diagnostics/android/os/Handler.java",
           validation / "native-diagnostics/android/os/Looper.java", here / "CrossCarrierAudit.java"]
args.report.parent.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(dir=args.report.parent, prefix="catalogue-audit-") as tmp:
    work = Path(tmp)
    with zipfile.ZipFile(args.apk) as apk, zipfile.ZipFile(args.unsigned_apk) as unsigned:
        dex = {n for n in apk.namelist() if re.fullmatch(r"classes\d*\.dex", n)}
        assert dex and dex == {n for n in unsigned.namelist() if re.fullmatch(r"classes\d*\.dex", n)}
        hashes = {}
        for name in sorted(dex | set(assets)):
            assert apk.read(name) == unsigned.read(name), name
            hashes[name] = sha(apk.read(name))
        for asset in assets:
            apk.extract(asset, work)
        current = json.loads(apk.read(assets[1]))
        catalogue = json.loads(apk.read(assets[2]))["entries"]
    classes = work / "classes"
    classes.mkdir()
    run("java", "-jar", kit / "ecj-3.40.0.jar", "-17", "-warn:none", "-proc:none", "-cp", asm, "-d", classes, *sources)
    adapted = work / "transport.jar"
    run("java", "-cp", os.pathsep.join([str(classes), asm]), "CtExcelTransportAdapter", args.jar, adapted)
    with zipfile.ZipFile(args.jar) as before, zipfile.ZipFile(adapted) as after:
        assert set(before.namelist()) == set(after.namelist())
        assert {n for n in before.namelist() if before.read(n) != after.read(n)} == {"o82.class", "b72.class"}
    # Feed one conditional case per distinct row; an overlapping rule cannot prove one unique carrier.
    by_plmn = collections.defaultdict(list)
    for rule in current["selectorRules"]:
        by_plmn[rule["plmn"]].append(rule)
    samples, expected_rules = [], []
    def padded(prefix, suffix):
        return (prefix or "") + suffix if prefix else ""
    for idx, rule in enumerate(current["selectorRules"]):
        plmn = rule["plmn"]
        iccid = (rule.get("iccidPrefix") or "899999") + "9999999999999999999"
        iccid = iccid[:19]
        gid1, gid2 = (padded(rule.get(k), "AB") for k in ("gid1Prefix", "gid2Prefix"))
        samples.append("\t".join([str(idx),plmn,iccid,gid1,gid2]))
        potential = [r for r in by_plmn[plmn] if not r["generic"] and all(not r.get(k) or
              value.casefold().startswith(r[k].casefold()) for k,value in (("gid1Prefix",gid1),("gid2Prefix",gid2),("iccidPrefix",iccid)))]
        if not potential:
            potential = [r for r in by_plmn[plmn] if r["generic"]]
        expected_rules.append({r["presetID"] for r in potential})
    samples_path = work/"identity-cases.tsv"
    samples_path.write_text("\n".join(samples)+"\n")
    output = run("java", "-Xmx1g", "-noverify", "-cp", os.pathsep.join(map(str, [classes, adapted, kit / "sdk/android-35/android.jar"])), "CrossCarrierAudit", work / "assets", ",".join(reference_invites.ORIGINS), ",".join(reference_invites.DESTINATIONS), reference_invites.gid_arg(), samples_path)

pairs = {(p["plmn"], p["id"]): p for p in current["presets"]}
assert len(pairs) == len(current["presets"])
plmns = {k[0] for k in pairs}
rules = current["selectorRules"]
assert all((r["plmn"], r["presetID"]) in pairs for r in rules)
assert all(r["plmn"] in plmns for r in catalogue)
entries = {"AUTO": {}, "MANUAL": {}}
invalid = []
calls = []
wire_checks = esp = 0
rule_output = {}
for line in output.splitlines():
    if line.startswith(("AUTO\t", "MANUAL\t")):
        kind, key, selected, label, plmn, servers, ims = line.split("\t")
        assert key not in entries[kind], key
        item = {"id": selected, "label": label, "plmn": plmn, "epdg": servers.split(","), "ims": ims}
        entries[kind][key] = item
        input_plmn = key.split("|")[0]
        if plmn != input_plmn or not all(valid_host(s) for s in item["epdg"] + [ims]):
            invalid.append({"kind": kind, "key": key, **item})
        if kind == "MANUAL" and key.split("|")[1] != selected:
            invalid.append({"kind": "manual-selection", "key": key, **item})
    elif line.startswith("RULE\t"):
        _, idx, selected = line.split("\t")
        assert int(idx) not in rule_output
        rule_output[int(idx)] = selected
    elif line.startswith("DIAL-"):
        calls.append(line)
    elif line.startswith("WIRES\t"):
        _, total, wire_checks, esp = line.split("\t")
        assert int(total) == len(calls)
assert set(entries["MANUAL"]) == {p + "|" + i for p, i in pairs}
assert set(entries["AUTO"]) == plmns
assert calls and wire_checks and esp
assert len(rule_output) == len(expected_rules)
conditional_mismatches = [
    {"rule":rules[idx], "expected_by_matching_prefixes":sorted(expected), "actual_profile":rule_output[idx]}
    for idx,expected in enumerate(expected_rules) if expected and rule_output[idx] not in expected
]
baseline = entries["AUTO"]["20620"]
assert baseline["id"] == "apple_base_be" and baseline["epdg"][0] == "epdg.telco.telenet-ops.be"
with zipfile.ZipFile(reference / "SIMHub.zip") as upload:
    assert sha(upload.read("SIMHub.apk")) == digest(reference / "SIMHub.apk")
assert digest(reference / "SIMHub.apk") == "27b14b7bd73787380b955456bbc09d4fc3a9410363be1e2e1f8ac9f742e67615"
with zipfile.ZipFile(reference / "SIMHub.apk") as upstream:
    original = json.loads(upstream.read("assets/vowifi/carrier_presets.json"))
orig_pairs = {(p["plmn"], p["id"]): p for p in original["presets"]}
updated_original = [k for k, p in orig_pairs.items() if pairs.get(k) != p]
missing_rules = [r for r in original["selectorRules"] if r not in rules]
observed = reference_invites.observations(output)
upstream_observed = reference_invites.capture(here, reference, project, args.jar, kit, dexkit, asm, run)
comparison = reference_invites.compare(upstream_observed, observed)
generic_rules = collections.defaultdict(list)
for rule in rules:
    generic_rules[rule["plmn"]].append(rule)
no_generic = {
    plmn: {"selected_from_uninformative_card": entries["AUTO"][plmn]["id"], "candidate_count": len({r["presetID"] for r in rows})}
    for plmn, rows in generic_rules.items()
    if not any(r["generic"] for r in rows) and len({r["presetID"] for r in rows}) > 1
}
strict_fields = {"uri","to","caller","preferred_identity","early_media","route","via_transport","security_verify","supported","direction","qos","media"}
strict_findings = [
    {"origin": plmn, "dial": dial, "fields": sorted(strict_fields.intersection(fields))}
    for plmn, rows in comparison["by_origin_differences"].items()
    for dial, fields in rows.items() if strict_fields.intersection(fields)
]
base_findings = comparison["by_origin_differences"].get("20620", {})
report = {
    "passed": not invalid and not conditional_mismatches and not base_findings and (args.baseline or not strict_findings),
    "reference_routing_failures": strict_findings, "neutral_identity_without_a_generic_rule": no_generic, "apk_sha256": digest(args.apk), "signed_io_and_dex_sha256": hashes,
    "translated_jar_sha256": digest(args.jar), "carrier_report_sha256": digest(args.carrier_report),
    "manual_native_configurations": len(entries["MANUAL"]), "automatic_plmns": len(entries["AUTO"]),
    "selector_rules_with_existing_target": len(rules), "rule_identity_cases_executed":len(rule_output),
    "unambiguous_rule_identity_cases":sum(len(row)==1 for row in expected_rules),
    "multiple_matching_profile_identity_cases":sum(len(row)>1 for row in expected_rules),
    "identity_rule_disagreements":conditional_mismatches, "standard_fallback_count": sum(p["id"].startswith("standard_plmn_") for p in pairs.values()),
    "global_directory_entries": len(catalogue), "catalogue_status_counts": dict(collections.Counter(row["status"] for row in catalogue)),
    "findings": invalid, "base_auto_config": baseline,
    "native_invites": len(calls), "origins": sorted({r.split("-")[1] for r in calls}), "call_matrix_gid1_inputs": reference_invites.GID1, "expected_conditioned_profiles": reference_invites.EXPECTED,
    "destinations": sorted({re.search(r" target=(\S+)", c)[1] for c in calls}),
    "wire_checks": int(wire_checks), "fixture_ipsec_packets": int(esp), "wire_observations": calls,
    "reference_zip_sha256": digest(reference / "SIMHub.zip"), "reference_apk_sha256": digest(reference / "SIMHub.apk"),
    "reference_profiles": len(orig_pairs), "reference_profiles_changed_or_missing": updated_original,
    "reference_rules": len(original["selectorRules"]), "reference_rules_missing": missing_rules,
    "base_reference_profile_identical": pairs["20620","apple_base_be"] == orig_pairs["20620","apple_base_be"],
    "official_invite_comparison": comparison, "baseline": args.baseline,
    "audit_sources_sha256": {f.name: digest(f) for f in [Path(__file__), here/"CrossCarrierAudit.java", here/"UpstreamInvites.java", here/"compare_reference_invites.py"]},
    "candidate_session_fixture": "o82.E intercepts serialized TCP bytes; b72.r intercepts actual encrypted UDP/IPsec datagram, authenticated and decrypted with independent keys; 183 response synthetic, PRACK observed. Synthetic registered identities and two ordered Service-Route values supplied to both engines.",
    "live_carrier_test": False, "android_art_tested": False,
    "scope": "Translated DEX with normalized R8 constructors. Every native auto config uses an independent synthetic IMSI with explicit 2/3 digit MNC and an uninformative ICCID. Manual config constructors tested for every template; one synthetic identity per automatic selector rule tests GID and ICCID prefix matching. Multiple matching candidates are reported separately. DNS names checked for syntax only. Official 23.52(1) R8 constructor adapters only; real r92.q starts at the successful APDU preflight resume branch; wire is serialized by oh4.b at dialog insertion; packet transport bypassed. Synthetic registered dialogs validated request-URI/To, From/PPI, contact policy, SDP AMR-WB, PRACK and native transport capture; no DNS queries, packets or actual calls on a carrier network."
}
args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k in {"passed", "apk_sha256", "manual_native_configurations", "automatic_plmns", "native_invites", "base_auto_config", "reference_profiles_changed_or_missing"}}, ensure_ascii=False))
if not report["passed"]:
    raise SystemExit(f"Verification differences, see {args.report}")
