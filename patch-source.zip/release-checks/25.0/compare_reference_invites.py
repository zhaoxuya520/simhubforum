"""Signed reference DEX, constructor bridges and a socket-free SIP capture."""
import base64
from collections import defaultdict
import email
from pathlib import Path
import re
import tempfile
import zipfile

ORIGINS = ["20620", "20601", "20610", "23433", "23415", "26202", "20404", "45403", "51566", "22210",
           "44010", "50501", "72405", "65501", "20801", "23410", "23487", "53024", "23430", "310410",
           "312670", "313100", "310260", "310030", "310150", "310170", "310280", "310560", "310950", "311180"]
DESTINATIONS = ["+3225550123", "+441632960123", "+493023125000", "+861055550123", "+12025550123",
                "+33199000123", "+3906123456", "+81355550123", "+61491570006", "025550123", "00493023125000"]
GID1 = {"310280":"FFFF", "310410":"FFFF", "310560":"FFFF", "310950":"FFFF", "311180":"FFFF", "310260":"54", "23430":"C3"}
EXPECTED = {plmn: "apple_att_us" for plmn, gid in GID1.items() if gid == "FFFF"}
EXPECTED.update({"310260":"apple_tmobile_us","23430":"apple_bt_consumer_uk"})
def gid_arg():
    return ",".join(key + ":" + value for key, value in GID1.items())

COMPACT = {"v":"via","f":"from","t":"to","i":"call-id","m":"contact","k":"supported","c":"content-type","l":"content-length"}


def observations(output):
    result = {}
    for line in output.splitlines():
        if not line.startswith("RAW\t"):
            continue
        _, origin, dial, profile, encoded = line.split("\t")
        raw = base64.b64decode(encoded).decode("utf-8")
        headers, sdp = raw.split("\r\n\r\n")
        start, rest = headers.split("\r\n",1)
        msg = email.message_from_string(rest)
        hdr = defaultdict(list)
        for k,v in msg.items():
            hdr[COMPACT.get(k.lower(),k.lower())].append(v)
        first = lambda k: hdr[k][0] if hdr[k] else ""
        uri = start.split(" ")[1]
        assert start == "INVITE " + uri + " SIP/2.0" and first("to") == "<" + uri + ">"
        assert first("content-type") == "application/sdp"
        assert int(first("content-length")) == len(sdp.encode())
        # Reference and candidate contain random dialog tags, Call-ID, branches and SDP session IDs.
        s_lines = sdp.splitlines()
        result[origin, dial] = {
            "profile": profile, "uri": uri, "to": first("to"),
            "caller": first("from").split(";tag=")[0], "preferred_identity": first("p-preferred-identity"),
            "route": hdr["route"], "via_transport": first("via").split(" ")[0],
            "early_media": hdr["p-early-media"], "security_verify": hdr["security-verify"],
            "require": hdr["require"], "supported": hdr["supported"],
            "contact_capabilities": first("contact").split(">;",1)[-1], "contact_uri": first("contact").split(">;",1)[0].lstrip("<"),
            "pani": hdr["p-access-network-info"],
            "session_expires": first("session-expires"), "min_se": first("min-se"),
            "media": [v for v in s_lines if v.startswith(("m=","a=rtpmap:","a=fmtp:","a=ptime:","a=maxptime:","c="))],
            "qos": [v for v in s_lines if ":qos " in v], "direction": [v for v in s_lines if v in ("a=sendrecv","a=recvonly","a=sendonly","a=inactive")],
            "bandwidth": [v for v in s_lines if v.startswith("b=")]
        }
    assert len(result) == len(ORIGINS)*len(DESTINATIONS)
    assert all(result[plmn, dial]["profile"] == name for plmn, name in EXPECTED.items() for dial in DESTINATIONS), "identity-conditioned profile mismatch"
    return result


def capture(here, reference, sources, jar, kit, dexkit, asm, run):
    adapter = sources / "validation/native-carrier"
    upstream = reference / "SIMHub.apk"
    with tempfile.TemporaryDirectory(dir=here,prefix="upstream-wire-") as temporary:
        tmp = Path(temporary)
        classes = tmp / "classes"
        classes.mkdir()
        with zipfile.ZipFile(upstream) as apk:
            for asset in ("assets/data/mcc_mnc.json","assets/vowifi/carrier_presets.json"):
                apk.extract(asset,tmp)
        run("java","-jar",kit / "ecj-3.40.0.jar","-17","-proc:none","-warn:none","-cp",asm,"-d",classes,
            here / "UpstreamInvites.java",adapter/"NormalizeR8Constructors.java",adapter/"AssetManager.java",
            adapter/"Context.java",sources/"tests/android/content/SharedPreferences.java",sources/"tests/android/util/Log.java",
            sources/"validation/native-diagnostics/android/os/Handler.java",sources/"validation/native-diagnostics/android/os/Looper.java")
        run("sh",dexkit/"dex-tools-v2.4/d2j-dex2jar.sh","-f","-o",tmp/"translated.jar",upstream)
        run("python3",adapter/"normalize_r8_constructors.py",reference/"decoded/smali",tmp/"constructors.tsv")
        run("java","-cp",str(classes)+":"+asm,"NormalizeR8Constructors",tmp/"translated.jar",tmp/"constructors.tsv",tmp/"probe.jar")
        return observations(run("java","-Xmx1g","-noverify","-cp",str(classes)+":"+str(tmp/"probe.jar")+":"+str(kit/"sdk/android-35/android.jar"),
                                "UpstreamInvites",tmp/"assets",",".join(ORIGINS),",".join(DESTINATIONS),gid_arg()))


def compare(original,candidate):
    assert original.keys() == candidate.keys()
    frequencies = defaultdict(int)
    differences = defaultdict(dict)
    critical = []
    for key,ref in original.items():
        cand = candidate[key]
        mismatches = {}
        for field, before in ref.items():
            after = cand[field]
            if before == after:
                continue
            frequencies[field] += 1
            mismatches[field] = {"reference":before, "candidate":after}
        if mismatches:
            differences[key[0]][key[1]] = mismatches
        for field in ("uri","to","caller","preferred_identity","early_media"):
            if field in mismatches:
                critical.append({"plmn":key[0],"dial":key[1],"field":field,**mismatches[field]})
    return {"comparisons":len(original),"mismatches_by_field":dict(frequencies),"routing_or_identity_or_early_media_differences":critical,
            "base_reference_example":original["20620",DESTINATIONS[0]],"base_candidate_example":candidate["20620",DESTINATIONS[0]],
            "by_origin_differences":dict(differences)}
