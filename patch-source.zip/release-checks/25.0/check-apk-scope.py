"""Compare the signed release manifest, ZIP contents and native SMS routes with 24.9."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

review = Path(__file__).resolve().parent
base = review.parent / 'sms24.9-release/SIMHub-24.9-signed.apk'
signed = review.parent / 'call25.0-release/SIMHub-25.0-signed.apk'
source = Path('/workspace/simhubforum/android/phone-slot-patch')
tools = Path('/workspace/tools/android-recovery')
previous = '34544ca9e4ade1136e438e31ab48055129d59fd355f787a70a7e43005efb625a'
assert sha256(base.read_bytes()).hexdigest() == previous
apk_digest = sha256(signed.read_bytes()).hexdigest()
decoded = review / ('decoded-' + apk_digest[:8])
if not (decoded/'apktool.yml').is_file():
    subprocess.run(['java', '-Xmx768m', '-jar', str(tools/'apktool_3.0.3.jar'), 'd', '-r', '-j', '2',
                    '-o', str(decoded), str(signed)], check=True)
routes_path = review/'native-sms-routes.json'
# Existing pins are for the patched Smali passed to the assembler. DEX layout may
# canonicalize its labels. Verify those pins and compare the actual disassembled
# methods independently between two APKs using the same version of Apktool.
subprocess.run([sys.executable, str(source/'tests/check_native_sms_routes.py'), str(source/'build-config3/apktool/smali'), str(signed),
                '--report', str(routes_path)], check=True)
sys.path.append(str(source/'tests'))
from check_native_sms_routes import METHODS
def method_hash(path, name, signature):
    text = (path/'smali'/(name+'.smali')).read_text()
    marker = '.method ' + signature + '\n'
    assert text.count(marker) == 1
    start = text.index(marker)
    end = text.index('\n.end method',start) + len('\n.end method')
    return sha256(text[start:end].encode()).hexdigest()
baseline = review.parent/'sms24.9-review/decoded-24.9'
checks = {}
for name,(signature,_) in METHODS.items():
    old = method_hash(baseline, name, signature)
    assert method_hash(decoded, name, signature) == old, name
    checks[name + '.' + signature] = old
routes = json.loads(routes_path.read_text())
routes['previous_apk_sha256'] = previous
routes['signed_disassembly_unchanged_from_24_9'] = checks
routes_path.write_text(json.dumps(routes,indent=2)+'\n')
def manifest_without_version(path):
    text = subprocess.check_output([str(tools/'sdk/android-15/aapt2'), 'dump', 'xmltree', '--file', 'AndroidManifest.xml', str(path)],text=True)
    return [line for line in text.splitlines() if ':versionCode(' not in line and ':versionName(' not in line]
assert manifest_without_version(base) == manifest_without_version(signed)
with ZipFile(base) as a, ZipFile(signed) as b:
    names = set(a.namelist())
    assert names == set(b.namelist())
    changed = sorted(n for n in names if a.read(n) != b.read(n))
    assert 'classes.dex' in changed and 'AndroidManifest.xml' in changed
report = dict(status='passed', apk_sha256=apk_digest, previous_apk_sha256=previous,
              manifest_unchanged_except_version=True, same_archive_entry_names=True,
              archive_content_changes=changed, unchanged_entries=len(names)-len(changed))
(review/'apk-scope.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
