import java.nio.charset.StandardCharsets;
import java.util.*;
public final class BaseSipHeaderProbe {
 public static void main(String[] args) {
   final String[] variants = {
     "P-Associated-URI: <sip:subscriber@example.test>, <tel:+3225550101>",
     "p-associated-uri: <sip:subscriber@example.test>, <tel:+3225550101>",
     "P-Associated-URI: \"Doe, Jane\" <sip:subscriber@example.test>, <tel:+3225550101>",
     "Record-Route: <sip:p1.example.test;lr>, <sip:p2.example.test;lr>",
     "Service-Route: <sip:p1.example.test;lr>, <sip:p2.example.test;lr>",
     "service-route: <sip:p1.example.test;lr>, <sip:p2.example.test;lr>"
   };
   for (String header: variants) {
     String bytes = "SIP/2.0 200 OK\r\n"+header+"\r\nContent-Length: 0\r\n\r\n";
     kb4 response = jb4.c(bytes.getBytes(StandardCharsets.US_ASCII));
     List<String> values = response.j(header.substring(0,header.indexOf(':')));
     List<String> uris = new ArrayList<>();
     for(String v:values) uris.add(jb4.g(v));
     System.out.println(header + " => n="+values.size()+" uris="+uris);
   }
 }
}
