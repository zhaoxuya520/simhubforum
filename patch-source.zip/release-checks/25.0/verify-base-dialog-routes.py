#!/usr/bin/env python3
"""Verify BASE in-dialog route construction from raw provisional/final SIP replies in a supplied APK."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

here = Path("/workspace/simhubforum/android/phone-slot-patch/validation/native-ctexcel-call")
review = Path(__file__).resolve().parent
project = here.parents[1]
shared = project / "validation/native-fork"
existing = shared.parent / "native-preconditions"
carrier_fixture = shared.parent / "native-carrier"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("apk", type=Path)
parser.add_argument("--carrier-report", type=Path, required=True)
parser.add_argument("--report", type=Path, required=True)
parser.add_argument("--unsigned-apk", type=Path)
parser.add_argument("--jar", type=Path)
parser.add_argument("--previous-24-9", action="store_true")
args = parser.parse_args()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


carrier = json.loads(args.carrier_report.read_text())
jar = args.jar or args.carrier_report.parent / "native-carrier-current" / "probe.jar"
unsigned = args.unsigned_apk or args.apk
assert carrier["apk_sha256"] == digest(unsigned), "unexpected unsigned APK"
assert carrier["apk_translated_jar_sha256"] == digest(jar), "unexpected translated JAR"
with zipfile.ZipFile(unsigned) as original, zipfile.ZipFile(args.apk) as signed:
    dex_pattern = re.compile(r"classes\d*\.dex")
    names = set(filter(dex_pattern.fullmatch, original.namelist()))
    assert names and names == set(filter(dex_pattern.fullmatch, signed.namelist())), "DEX set mismatch"
    dex_hashes = {}
    for name in sorted(names):
        content = signed.read(name)
        assert original.read(name) == content, name
        dex_hashes[name] = hashlib.sha256(content).hexdigest()

kit = Path(os.environ.get("SIMHUB_TOOLS", "/workspace/tools/android-recovery"))
dexkit = Path(os.environ.get("SIMHUB_DEX2JAR_TOOLS", "/workspace/tools/dex2jar-v2.4"))
lib = dexkit / "dex-tools-v2.4/lib"
asm = os.pathsep.join(str(lib / name) for name in ("asm-9.5.jar", "asm-tree-9.5.jar"))
sources = [shared / "g11.java", shared / "SipForkProbe.java", shared.parent / "native-invite-failure" / "t00.java", here / "CtExcelTransportAdapter.java", existing / "PreconditionProbe.java", carrier_fixture / "AssetManager.java", carrier_fixture / "Context.java", project / "tests/android/content/SharedPreferences.java", project / "tests/android/util/Log.java", *[shared.parent / "native-diagnostics/android/os" / n for n in ("Looper.java","Handler.java")], here / "CtExcelOriginationProbe.java", review / "BaseDialogRouteProbe.java"]
mode = "previous-24-9" if args.previous_24_9 else "fixed"
args.report.parent.mkdir(parents=True, exist_ok=True)
log = []


def run(*command):
    result = subprocess.run(list(map(str, command)), capture_output=True, text=True)
    log.append(result.stdout + result.stderr)
    args.report.with_suffix(".log").write_text("\n".join(log))
    if result.returncode:
        print(log[-1])
        raise SystemExit(result.returncode)
    return result.stdout


with tempfile.TemporaryDirectory(dir=args.report.parent, prefix="native-ctexcel-call-") as tmp:
    work = Path(tmp)
    classes = work / "classes"
    classes.mkdir()
    run("java", "-jar", kit / "ecj-3.40.0.jar", "-17", "-warn:none", "-proc:none", "-cp", asm, "-d", classes, *sources)
    adapted = work / "transport.jar"
    run("java", "-cp", os.pathsep.join([str(classes), asm]), "CtExcelTransportAdapter", jar, adapted)
    with zipfile.ZipFile(jar) as before, zipfile.ZipFile(adapted) as after:
        assert set(before.namelist()) == set(after.namelist())
        changed = {name for name in before.namelist() if before.read(name) != after.read(name)}
        assert changed == {"o82.class", "b72.class"}, changed
    cp = os.pathsep.join(map(str, [classes, adapted, kit / "sdk/android-35/android.jar"]))
    with zipfile.ZipFile(args.apk) as source:
        for asset in ("assets/vowifi/carrier_presets.json", "assets/vowifi/global_standard_catalogue.json"):
            source.extract(asset, work)
    output = run("java", "-noverify", "-cp", cp, "BaseDialogRouteProbe", mode, work / "assets")

match = re.search(r"BASE_DIALOG_ROUTE ([\w-]+) checks=(\d+) protected=(\d+)", output)
assert match and match[1] == mode, output
report = {
    "apk_sha256": digest(args.apk), "dex_sha256": dex_hashes,
    "apk_translated_jar_sha256": digest(jar), "carrier_report_sha256": digest(args.carrier_report),
    "mode": mode, "checks": int(match[2]),
    "actual_outgoing_dialog_initializer_and_sender": True, "actual_bundled_carrier_presets": True,
    "initial_and_in_dialog_dispatch_checked": ["INVITE", "PRACK", "UPDATE", "ACK"], "native_gm_esp_packets_verified": int(match[3]),
    "negative_control_reproduced": args.previous_24_9,
    "fixture_boundaries": ["o82.E receives outgoing TCP payload before its TCP stack", "b72.r collects native IPv6 ESP and clear UDP datagrams", "fixed synthetic session keys and registered-session state", "native parser receives synthetic clear SIP responses", "Android log and event sinks"],
    "network_calls_placed": False, "real_carrier_tested": False, "android_art_tested": False,
    "dex_to_jvm_constructor_adapters": True, "jvm_verification_disabled_for_translated_dex": True,
    "diagnostic_observations": [s for s in output.splitlines() if s.startswith("BASE ")],
    "fixture_sources": {str(source): digest(source) for source in sources},
}
args.report.write_text(json.dumps(report, indent=2) + "\n")
print(output.strip())
