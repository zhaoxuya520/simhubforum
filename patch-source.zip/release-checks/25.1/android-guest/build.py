"""Build a separate test APK signed by the matching application key."""
import argparse
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZipFile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--tools', type=Path, required=True)
parser.add_argument('--keystore', type=Path, required=True)
parser.add_argument('--password-file', type=Path, required=True)
parser.add_argument('--alias', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
src = Path(__file__).resolve().parent
tools = args.tools
sdk = tools / 'sdk/android-35/android.jar'
build = tools / 'sdk/android-15'

def run(*command):
    subprocess.run([str(part) for part in command], check=True)

args.output.parent.mkdir(parents=True, exist_ok=True)
with TemporaryDirectory(dir=args.output.parent) as directory:
    work = Path(directory)
    classes = work/'classes'
    classes.mkdir()
    run('java', '-jar', tools/'ecj-3.40.0.jar', '-8', '-warn:none', '-encoding', 'UTF-8',
        '-cp', sdk, '-d', classes, *sorted(src.glob('*.java')))
    jar = work / 'classes.jar'
    with ZipFile(jar, 'w') as archive:
        for entry in classes.rglob('*.class'):
            archive.write(entry, entry.relative_to(classes))
    dex = work / 'dex'
    dex.mkdir()
    run('java', '-cp', build/'lib/d8.jar', 'com.android.tools.r8.D8', '--min-api', '28',
        '--lib', sdk, '--output', dex, jar)
    unsigned = work / 'unsigned.apk'
    run(build / 'aapt2', 'link', '-o', unsigned, '--manifest', src/'AndroidManifest.xml', '-I', sdk)
    with ZipFile(unsigned, 'a') as archive:
        archive.write(dex / 'classes.dex', 'classes.dex')
    run('java', '-jar', build/'lib/apksigner.jar', 'sign', '--ks', args.keystore, '--ks-key-alias',
        args.alias, '--ks-pass', 'file:'+str(args.password_file), '--out', args.output, unsigned)
