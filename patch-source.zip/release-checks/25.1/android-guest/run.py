"""Install on a dedicated emulator and exercise native signed APK screens with instrumentation."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apk',type=Path,required=True)
parser.add_argument('--probe',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--adb',type=Path,required=True)
parser.add_argument('--device',required=True)
parser.add_argument('--baseline',action='store_true')
parser.add_argument('--screens',nargs='+',default=['dialer','settings','call'])
args=parser.parse_args()
app='cc.forserein.simhub'
args.output.mkdir(parents=True,exist_ok=True)
if not re.fullmatch('emulator-[0-9]+',args.device):
    parser.error('requires a dedicated emulator')
def dev(*cmd,timeout=180):
    r=subprocess.run([str(args.adb),'-s',args.device,*map(str,cmd)],capture_output=True,text=True,timeout=timeout)
    if r.returncode: raise RuntimeError(f'{cmd[0]} failed: {r.stderr[:400]} {r.stdout[:400]}')
    return r.stdout.strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def installed(pkg):
    result = subprocess.run([str(args.adb),'-s',args.device,'shell','pm','path',pkg],capture_output=True,text=True,timeout=90)
    if result.returncode and not result.stdout.strip() and not result.stderr.strip():return None
    result.check_returncode()
    path=result.stdout.strip()
    if not re.fullmatch(r'package:/[A-Za-z0-9_./~+=-]+/base\.apk',path):return None
    return dev('shell','sha256sum',path[8:]).split()[0]
def install(file,pkg):
    digest=sha(file)
    if installed(pkg)==digest:return
    stage='/data/local/tmp/caption-test-'+digest[:16]+'.apk'
    dev('push',file,stage)
    assert dev('shell','sha256sum',stage).split()[0]==digest
    assert 'Success' in dev('shell','pm','install','-r',stage,timeout=300)
    assert installed(pkg)==digest
assert dev('shell','getprop','ro.kernel.qemu')=='1'
deadline=time.monotonic()+900
while dev('shell','getprop','sys.boot_completed')!='1':
    if time.monotonic()>deadline:raise RuntimeError('isolated Android guest did not finish booting')
    time.sleep(4)
dev('shell','cmd','connectivity','airplane-mode','enable')
dev('shell','svc','wifi','disable')
assert dev('shell','settings','get','global','airplane_mode_on')=='1'
install(args.apk,app)
print('application installed',sha(args.apk), flush=True)
install(args.probe,'cc.forserein.simhub.captionprobe')
print('test instrumentation installed',sha(args.probe),flush=True)
report=dict(apk_sha256=sha(args.apk),probe_sha256=sha(args.probe),api=int(dev('shell','getprop','ro.build.version.sdk')),
            baseline=args.baseline,live_call=False,live_cloud_translation=False,network_disabled=True,screens={})
for screen in args.screens:
    dev('shell','am','force-stop',app)
    # am instrument waits for the entire test, including screenshot serialization.
    text=dev('shell','am','instrument','-w','-e','screen',screen,
        '-e','baseline',str(args.baseline).lower(),'cc.forserein.simhub.captionprobe/captionprobe.CaptionsArt',timeout=300)
    for match in re.finditer(r'INSTRUMENTATION_STATUS: capture=([^\r\n]+)\s+INSTRUMENTATION_STATUS: png_base64=([A-Za-z0-9+/=]+)',text):
        (args.output/(match[1]+'.png')).write_bytes(base64.b64decode(match[2],validate=True))
    clean=re.sub(r'(?m)^INSTRUMENTATION_STATUS: png_base64=.*$','[PNG extracted]',text)
    (args.output/(screen+'.log')).write_text(clean)
    result=dict(re.findall(r'(?m)^INSTRUMENTATION_RESULT: (\w+)=(.*)$',clean))
    assert result.get('status')=='passed' and 'INSTRUMENTATION_CODE: 0' in clean,(screen,clean[-3500:])
    report['screens'][screen]=result
    print(screen, result, flush=True)
(args.output/'device-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
