"""Compare the signed release manifest, ZIP contents and native SMS routes with 25.0."""
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

review = Path(__file__).resolve().parent
base = Path(os.environ.get('SIMHUB_25_BASELINE', review.parent / 'call25.0-release/SIMHub-25.0-signed.apk'))
signed = Path(os.environ.get('SIMHUB_25_1_APK', review.parent / 'captions25.1-release/SIMHub-25.1-signed.apk'))
source = Path(os.environ.get('SIMHUB_PROJECT', '/workspace/simhubforum/android/phone-slot-patch'))
tools = Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery'))
previous = '6024ee5edc8a402e93734769d994a1012bab9a66c15c281347e09c292f502039'
assert sha256(base.read_bytes()).hexdigest() == previous
apk_digest = sha256(signed.read_bytes()).hexdigest()
def decode(apk, dest):
    if not (dest / 'apktool.yml').is_file():
        dest.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(['java', '-Xmx768m', '-jar', str(tools/'apktool_3.0.3.jar'), 'd', '-r', '-j', '2',
                        '-o', str(dest), str(apk)], check=True)
    return dest
decoded = decode(signed, review / ('decoded-' + apk_digest[:8]))
routes_path = review/'native-sms-routes.json'
# Existing pins are for the patched Smali passed to the assembler. DEX layout may
# canonicalize its labels. Verify those pins and compare the actual disassembled
# methods independently between two APKs using the same version of Apktool.
subprocess.run([sys.executable, str(source/'tests/check_native_sms_routes.py'), str(source/'build-config3/apktool/smali'), str(signed),
                '--report', str(routes_path)], check=True)
sys.path.append(str(source/'tests'))
from check_native_sms_routes import METHODS
def method_hash(path, name, signature):
    text = (path/'smali'/(name+'.smali')).read_text()
    marker = '.method ' + signature + '\n'
    assert text.count(marker) == 1
    start = text.index(marker)
    end = text.index('\n.end method',start) + len('\n.end method')
    return sha256(text[start:end].encode()).hexdigest()
baseline = decode(base, review.parent/'call25.0-review/decoded-6024ee5e')
old_classes = {p.relative_to(baseline/'smali').as_posix():p for p in (baseline/'smali').rglob('*.smali')}
new_classes = {p.relative_to(decoded/'smali').as_posix():p for p in (decoded/'smali').rglob('*.smali')}
assert not (old_classes.keys() - new_classes.keys())
added_classes = sorted(new_classes.keys() - old_classes.keys())
changed_classes = sorted(key for key, previous_file in old_classes.items()
                         if previous_file.read_bytes() != new_classes[key].read_bytes())
sys.path.insert(0, str(source))
from call_caption_audio_patch import CAPTION_AUDIO_CLASSES
from call_caption_ui_patch import CAPTION_UI_CLASSES
expected_hooks = CAPTION_AUDIO_CLASSES | CAPTION_UI_CLASSES
assert set(changed_classes) == expected_hooks | {'r75.smali'}, changed_classes
assert added_classes and all(re.fullmatch(r'cc/forserein/simhub/internal/(?:CallCaption|Caption)[^/]*\.smali', key)
                             for key in added_classes), added_classes
checks = {}
for name,(signature,_) in METHODS.items():
    old = method_hash(baseline, name, signature)
    assert method_hash(decoded, name, signature) == old, name
    checks[name + '.' + signature] = old
routes = json.loads(routes_path.read_text())
routes['previous_apk_sha256'] = previous
routes['signed_disassembly_unchanged_from_25_0'] = checks
routes_path.write_text(json.dumps(routes,indent=2)+'\n')
def manifest_without_version(path):
    text = subprocess.check_output([str(tools/'sdk/android-15/aapt2'), 'dump', 'xmltree', '--file', 'AndroidManifest.xml', str(path)],text=True)
    return [line for line in text.splitlines() if ':versionCode(' not in line and ':versionName(' not in line]
assert manifest_without_version(base) == manifest_without_version(signed)
with ZipFile(base) as a, ZipFile(signed) as b:
    names = set(a.namelist())
    assert names == set(b.namelist())
    changed = sorted(n for n in names if a.read(n) != b.read(n))
    assert changed == ['AndroidManifest.xml', 'classes.dex'], changed
report = dict(status='passed', apk_sha256=apk_digest, previous_apk_sha256=previous,
              manifest_unchanged_except_version=True, same_archive_entry_names=True,
              archive_content_changes=changed, unchanged_entries=len(names)-len(changed),
              updated_classes=changed_classes, added_classes=added_classes,
              untouched_classes=len(old_classes)-len(changed_classes))
(review/'apk-scope.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
