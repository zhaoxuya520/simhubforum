"""Tie each published caption proof and Android screenshot to the signed release."""
from hashlib import sha256
import json
from pathlib import Path

here = Path(__file__).resolve().parent
signed = here.parent / 'captions25.2-release/SIMHub-25.2-signed.apk'
digest = sha256(signed.read_bytes()).hexdigest()
def read(name):
    return json.loads((here/name).read_text())
def sha(path):
    return sha256(path.read_bytes()).hexdigest()
report = {'apk_sha256': digest, 'paid_provider_inference_tested': False, 'live_carrier_call_tested': False}
for kind in ('media', 'state', 'backend', 'art'):
    name = 'signed-caption-' + kind + '.json'
    proof = read(name)
    assert proof.get('apk_sha256') == digest, name
    if kind == 'art':
        assert proof['passed'] is True and proof['check_count'] > 0, name
        assert all(proof['screens'][screen]['status'] == 'passed' for screen in ('call', 'dialer', 'settings')), name
        assert proof['network_disabled'] and not proof['live_call'] and not proof['live_cloud_translation'], name
        for screen in ('call', 'dialer', 'settings'):
            capture = proof['screenshots'][screen]
            assert capture['file'] == 'caption-' + screen + '.png'
            assert capture['sha256'] == sha(here / capture['file'])
    else:
        assert proof['checks'] > 0, name
    report[kind] = proof
report['model_contract'] = read('gemini-public-contract.json')
landscape = read('signed-caption-landscape.json')
assert landscape['apk_sha256'] == digest and landscape['passed'] is True
assert landscape['width'] > landscape['height'] and landscape['network_disabled']
assert landscape['screens']['landscape']['status'] == 'passed'
assert {capture['file'] for capture in landscape['screenshots']} == {'caption-call-landscape.png', 'caption-landscape-controls.png'}
assert all(capture['sha256'] == sha(here / capture['file']) for capture in landscape['screenshots'])
assert set(landscape['bounds_after_scrolling']) == {'subtitle','hangup'}
report['landscape'] = landscape
report['screenshots'] = {name:sha(here/name) for name in ('caption-call.png','caption-dialer.png','caption-settings.png','caption-call-landscape.png','caption-landscape-controls.png')}
report['passed'] = True
(here/'caption-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
