"""Tie each published caption proof and Android screenshot to the signed release."""
from hashlib import sha256
import json
from pathlib import Path

here = Path(__file__).resolve().parent
signed = here.parent / 'captions25.3-release/SIMHub-25.3-signed.apk'
digest = sha256(signed.read_bytes()).hexdigest()
def read(name):
    return json.loads((here/name).read_text())
def sha(path):
    return sha256(path.read_bytes()).hexdigest()
report = {'apk_sha256': digest, 'paid_provider_inference_tested': False, 'live_carrier_call_tested': False}
for kind in ('media', 'state', 'backend', 'art'):
    name = 'signed-caption-' + kind + '.json'
    proof = read(name)
    assert proof.get('apk_sha256') == digest, name
    if kind == 'art':
        assert proof['passed'] is True and proof['check_count'] > 0, name
        assert all(proof['screens'][screen]['status'] == 'passed' for screen in ('call', 'dialer', 'settings')), name
        assert proof['network_disabled'] and not proof['live_call'] and not proof['live_cloud_translation'], name
        for screen in ('call', 'dialer', 'settings'):
            capture = proof['screenshots'][screen]
            assert capture['file'] == 'caption-' + screen + '.png'
            assert capture['sha256'] == sha(here / capture['file'])
    else:
        assert proof['checks'] > 0, name
    report[kind] = proof
report['model_contract'] = read('gemini-public-contract.json')
landscape = read('signed-caption-landscape.json')
assert landscape['apk_sha256'] == digest and landscape['passed'] is True
assert landscape['width'] > landscape['height'] and landscape['network_disabled']
assert landscape['screens']['landscape']['status'] == 'passed'
assert {capture['file'] for capture in landscape['screenshots']} == {'caption-call-landscape.png', 'caption-landscape-controls.png'}
assert all(capture['sha256'] == sha(here / capture['file']) for capture in landscape['screenshots'])
assert set(landscape['bounds_after_scrolling']) == {'subtitle','hangup'}
report['landscape'] = landscape
reading = read('signed-caption-reading.json')
assert reading['apk_sha256'] == digest and reading['passed'] is True
assert reading['network_disabled'] and reading['viewport_dp'] == 320
assert reading['screens']['reading']['status'] == 'passed' and int(reading['screens']['reading']['checks']) > 0
assert reading['old_bug_reproduced'] and reading['old_apk_sha256'] == 'd5f3ec8085e682e1dc0a5f39e8d1120e14fbea45b3c437b219a14bb86d54edbf'
assert set(reading['screenshots']) == {'long-start','long-end','rtl','error','idle'}
for name, capture in reading['screenshots'].items():
    assert capture['file'] == 'caption-' + name + '.png' and capture['sha256'] == sha(here / capture['file'])
geometry = reading['geometry']
assert geometry['initial'] == 0 and geometry['end'] > 0 and geometry['lines'] >= 5
assert geometry['rtl_direction'] == -1 and geometry['mute_short'] == geometry['mute_long']
assert geometry['first_complete_lines'] >= 3 and geometry['end_complete_lines'] >= 3
assert geometry['first_bottom_ink_clipped'] is False and geometry['end_top_ink_clipped'] is False
swipes = geometry['finger_swipes']
assert any(s['before'] < s['after'] == geometry['end'] for s in swipes)
assert any(s['before'] > s['after'] == geometry['initial'] for s in swipes)
report['reading'] = reading
equivalence = read('layout-equivalence.json')
assert equivalence['apk_sha256'] == digest and equivalence['call_dialer_compose_and_state_identical']
assert equivalence['all_caption_view_classes_identical'] > 0
report['approved_layout'] = equivalence
backend_comparison = read('signed-backend-class-comparison.json')
assert backend_comparison['apk_sha256'] == digest and backend_comparison['unchanged_all_backend_classes'] is True
assert backend_comparison['previous_apk_sha256'] == reading['old_apk_sha256']
report['backend_comparison'] = backend_comparison
report['screenshots'] = {name:sha(here/name) for name in ('caption-call.png','caption-dialer.png','caption-settings.png','caption-call-landscape.png','caption-landscape-controls.png',
                                                         'caption-long-start.png','caption-long-end.png','caption-rtl.png','caption-error.png','caption-idle.png')}
report['passed'] = True
(here/'caption-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
