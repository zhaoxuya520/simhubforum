"""Compare the signed release manifest, ZIP contents and native SMS routes with 25.2."""
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

review = Path(__file__).resolve().parent
base = Path(os.environ.get('SIMHUB_25_2_BASELINE', review.parent / 'captions25.2-release/SIMHub-25.2-signed.apk'))
signed = Path(os.environ.get('SIMHUB_25_3_APK', review.parent / 'captions25.3-release/SIMHub-25.3-signed.apk'))
source = Path(os.environ.get('SIMHUB_PROJECT', '/workspace/simhubforum/android/phone-slot-patch'))
tools = Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery'))
previous = 'd5f3ec8085e682e1dc0a5f39e8d1120e14fbea45b3c437b219a14bb86d54edbf'
assert sha256(base.read_bytes()).hexdigest() == previous
apk_digest = sha256(signed.read_bytes()).hexdigest()
def decode(apk, dest):
    if not (dest / 'apktool.yml').is_file():
        dest.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(['java', '-Xmx768m', '-jar', str(tools/'apktool_3.0.3.jar'), 'd', '-r', '-j', '2',
                        '-o', str(dest), str(apk)], check=True)
    return dest
decoded = decode(signed, review / ('decoded-' + apk_digest[:8]))
routes_path = review/'native-sms-routes.json'
# Existing pins are for the patched Smali passed to the assembler. DEX layout may
# canonicalize its labels. Verify those pins and compare the actual disassembled
# methods independently between two APKs using the same version of Apktool.
subprocess.run([sys.executable, str(source/'tests/check_native_sms_routes.py'), str(source/'build-config3/apktool/smali'), str(signed),
                '--report', str(routes_path)], check=True)
sys.path.append(str(source/'tests'))
from check_native_sms_routes import METHODS
def method_hash(path, name, signature):
    text = (path/'smali'/(name+'.smali')).read_text()
    marker = '.method ' + signature + '\n'
    assert text.count(marker) == 1
    start = text.index(marker)
    end = text.index('\n.end method',start) + len('\n.end method')
    return sha256(text[start:end].encode()).hexdigest()
baseline = decode(base, review.parent/'captions25.2-review/decoded-d5f3ec80')
old_classes = {p.relative_to(baseline/'smali').as_posix():p for p in (baseline/'smali').rglob('*.smali')}
new_classes = {p.relative_to(decoded/'smali').as_posix():p for p in (decoded/'smali').rglob('*.smali')}
removed_classes = sorted(old_classes.keys() - new_classes.keys())
added_classes = sorted(new_classes.keys() - old_classes.keys())
changed_classes = sorted(key for key in old_classes.keys() & new_classes.keys()
                         if old_classes[key].read_bytes() != new_classes[key].read_bytes())
prefix = 'cc/forserein/simhub/internal/'
display_or_core = re.compile(re.escape(prefix) + r'(?:CaptionUi(?:\$[^/]*)?|CallCaptions(?:\$(?:Stream|Display|\$ExternalSyntheticLambda[0-9]+))?)\.smali')
assert 'r75.smali' in changed_classes
assert prefix + 'CallCaptions.smali' in changed_classes
assert any(key.startswith(prefix + 'CaptionUi') for key in changed_classes)
assert all(key == 'r75.smali' or display_or_core.fullmatch(key) for key in changed_classes), changed_classes
assert all(display_or_core.fullmatch(key) for key in added_classes + removed_classes), (added_classes, removed_classes)
render_classes = [path for key, path in new_classes.items() if key.startswith(prefix + 'CaptionUi')]
assert render_classes and all('->setFallbackLineSpacing(' not in path.read_text() for path in render_classes)
checks = {}
for name,(signature,_) in METHODS.items():
    old = method_hash(baseline, name, signature)
    assert method_hash(decoded, name, signature) == old, name
    checks[name + '.' + signature] = old
routes = json.loads(routes_path.read_text())
routes['previous_apk_sha256'] = previous
routes['signed_disassembly_unchanged_from_25_2'] = checks
routes_path.write_text(json.dumps(routes,indent=2)+'\n')
def manifest_without_version(path):
    text = subprocess.check_output([str(tools/'sdk/android-15/aapt2'), 'dump', 'xmltree', '--file', 'AndroidManifest.xml', str(path)],text=True)
    return [line for line in text.splitlines() if ':versionCode(' not in line and ':versionName(' not in line]
assert manifest_without_version(base) == manifest_without_version(signed)
with ZipFile(base) as a, ZipFile(signed) as b:
    names = set(a.namelist())
    assert names == set(b.namelist())
    changed = sorted(n for n in names if a.read(n) != b.read(n))
    assert changed == ['AndroidManifest.xml', 'classes.dex'], changed
report = dict(status='passed', apk_sha256=apk_digest, previous_apk_sha256=previous,
              manifest_unchanged_except_version=True, same_archive_entry_names=True,
              android_8_caption_ui_omits_api_28_fallback_line_spacing=True,
              archive_content_changes=changed, unchanged_entries=len(names)-len(changed),
              updated_classes=changed_classes, added_classes=added_classes, removed_classes=removed_classes,
              untouched_classes=len(old_classes)-len(changed_classes)-len(removed_classes))
(review/'apk-scope.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
