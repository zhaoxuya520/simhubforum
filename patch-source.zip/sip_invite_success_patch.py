"""Replay accepted INVITE ACKs before native dialog mutation or repeated local release."""
from pathlib import Path
import hashlib

SIGNATURE = '.method public final h(Lkb4;)Z'
BASE_SHA256 = 'c92dd1ebe7ca941f1e754a7d5cfe5a62d7a7cebd45afb9cad4b14d4a4ee23784'
ENTRY = '    move-object/from16 v1, p1\n'
GUARD = '''
    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/SipInviteSuccess;->handle(Ljava/lang/Object;Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, :sip_invite_success_native_response
    const/4 v2, 0x1
    return v2
    :sip_invite_success_native_response
'''
ACK = '    invoke-direct {v4, v0, v5}, Lpa4;-><init>(Lkb4;Loc2;)V\n'
REMEMBER = '''
    move-object/from16 v5, p0
    invoke-static {v5, v1, v0}, Lcc/forserein/simhub/internal/SipInviteSuccess;->remember(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
'''

DISPATCH = '    invoke-virtual {v0, v12}, Lo82;->k(Ljava/util/List;)V\n'
DISPATCH_NEW = '''    move-object/from16 v1, p1
    invoke-static {v0, v1, v12}, Lcc/forserein/simhub/internal/SipInviteSuccess;->tryDispatch(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/List;)Z
    move-result v1
    if-nez v1, :sip_invite_success_dispatched
    invoke-virtual {v0, v12}, Lo82;->k(Ljava/util/List;)V
    :sip_invite_success_dispatched
'''

def _method(text):
    a = text.index(SIGNATURE)
    b = text.index('.end method', a) + len('.end method')
    return a, b, text[a:b]


def apply_sip_invite_success(smali):
    path = Path(smali) / 'o82.smali'
    text = path.read_text()
    a, b, body = _method(text)
    assert hashlib.sha256(body.encode()).hexdigest() == BASE_SHA256, 'apply after existing SIP fork/failure patches'
    assert body.count(ENTRY) == 1 and body.count(ACK) == 1 and body.count(DISPATCH) == 1
    body = body.replace(ENTRY, ENTRY + GUARD).replace(ACK, ACK + REMEMBER).replace(DISPATCH, DISPATCH_NEW)
    path.write_text(text[:a] + body + text[b:])


def reverse_sip_invite_success(name, text):
    if name != 'o82.smali':
        return text
    if 'SipInviteSuccess;->' not in text and ':sip_invite_success_' not in text:
        return text
    a, b, body = _method(text)
    assert body.count(ENTRY + GUARD) == 1 and body.count(ACK + REMEMBER) == 1 and body.count(DISPATCH_NEW) == 1
    body = body.replace(ENTRY + GUARD, ENTRY).replace(ACK + REMEMBER, ACK).replace(DISPATCH_NEW, DISPATCH)
    assert hashlib.sha256(body.encode()).hexdigest() == BASE_SHA256, 'native response instructions changed'
    return text[:a] + body + text[b:]


def verify_sip_invite_success(smali):
    text = (Path(smali) / 'o82.smali').read_text()
    assert text.count(ENTRY + GUARD) == 1 and text.count(ACK + REMEMBER) == 1 and text.count(DISPATCH_NEW) == 1
    reverse_sip_invite_success('o82.smali', text)
    return dict(status_min=200, status_max=299, method='INVITE',
                first_acceptance='native ACK, SDP and local cancellation handling',
                duplicate='original ACK replay; no dialog mutation or new BYE transaction',
                release_dispatch='original action order; resume unsent actions after synchronous failure',
                maximum_bye_dispatch_attempts=2,
                ack_cache_limit=64, removed_dialog_seconds_from_first_ack=32,
                live_dialog_ack_retained=True, new_cancel_race_fork='existing isolated fork handler',
                device_tested=False)
