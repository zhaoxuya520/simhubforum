"""RCS toggle and existing-send routing in the pinned native SMS conversation.

RCS off retains the complete native SMS path. RCS requested (including errors)
is consumed by the helper before native SMS draft clearing or dispatch.
"""
from pathlib import Path
import hashlib

TARGET = 'pk5.smali'
SIGNATURE = 'public static final j(Lem0;Lgl5;Ljava/lang/String;Ljava/lang/String;Lus1;Llu1;I)V'
SEND_TARGET = 'j51.smali'
SEND_SIGNATURE = 'public final a()Ljava/lang/Object;'
COMPOSE_TARGET = 'mc0.smali'
COMPOSE_SIGNATURE = 'public final d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;'
COMPOSE_SEND_TARGET = 'zz.smali'
METHOD_PINS = {
    (TARGET, SIGNATURE): '835a72455a42ffa4333a8acbbd935e78cd7107f53ccb691a2ab7e055acec1551',
    (SEND_TARGET, SEND_SIGNATURE): '68229828202fa21b44098efce6400ef6723054db5e41960dba8ac7df2e475097',
    # mc0 is pinned AFTER smsc_editor_patch. Reverse RCS before reversing SMSC.
    (COMPOSE_TARGET, COMPOSE_SIGNATURE): '7936a627933ef1c69490d1712db0a18dccefd3e8480b31333d53127a09fc4cc3',
    (COMPOSE_SEND_TARGET, SEND_SIGNATURE): '97fe3422825d5e10fc9648934ca9ab802e07b5fbb56ea0985bb2dbe852f73f03',
}
METHOD_SHA256 = METHOD_PINS[(TARGET, SIGNATURE)]
HELPER = 'Lcc/forserein/simhub/internal/RcsChatUi;'
SMS_HINT = HELPER + '->showSmsHint(Ljava/lang/Object;)Z'
RENDER_HOOK = HELPER + '->render(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V'
ENABLED_HOOK = HELPER + '->sendEnabled(ZLjava/lang/String;Ljava/lang/Object;)Z'
SEND_HOOK = HELPER + '->trySend(Ljava/lang/String;Ljava/lang/Object;)Z'
DRAFT_RENDER_HOOK = HELPER + '->renderDraft(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V'
DRAFT_ENABLED_HOOK = HELPER + '->sendEnabledDraft(ZLjava/lang/Object;Ljava/lang/Object;)Z'
DRAFT_SEND_HOOK = HELPER + '->trySendDraft(Ljava/lang/Object;Ljava/lang/Object;)Z'
RENDER_OLD = '''    :goto_17
    sget-object v3, Lt3;->g0:Lgp;'''
RENDER_INSERTION = '''    move-object/from16 v3, p2
    move-object/from16 v4, v49
    invoke-static {v2, v3, v4, v8}, ''' + RENDER_HOOK + '''
'''
RENDER_NEW = RENDER_OLD.replace('    sget-object v3,', RENDER_INSERTION + '    sget-object v3,', 1)
ENABLED_OLD = '    move/from16 v0, v59\n'
ENABLED_INSERTION = ('    invoke-static {v0, v15, v11}, ' + ENABLED_HOOK + '\n'
                     '    move-result v0\n')
ENABLED_NEW = ENABLED_OLD + ENABLED_INSERTION
SEND_OLD = '''    .line 14
    check-cast p0, Lm83;

    .line 15'''
SEND_INSERTION = '''    invoke-static {v1, p0}, ''' + SEND_HOOK + '''
    move-result v3
    if-eqz v3, :rcs_sms_original
    sget-object v3, Lsc5;->a:Lsc5;
    return-object v3
    :rcs_sms_original

'''
SEND_NEW = SEND_OLD.replace('    .line 15', SEND_INSERTION + '    .line 15', 1)
DRAFT_RENDER_OLD = '''    :goto_19
    iget-object v1, v0, Lmc0;->X:Lm83;
'''
DRAFT_RENDER_INSERTION = '''    move-object/from16 v2, v57
    invoke-static {v7, v2, v1, v10}, ''' + DRAFT_RENDER_HOOK + '''
'''
DRAFT_RENDER_NEW = DRAFT_RENDER_OLD + DRAFT_RENDER_INSERTION
DRAFT_ENABLED_OLD = '    move/from16 v24, v52\n'
DRAFT_ENABLED_INSERTION = '''    move/from16 v4, v24
    move-object/from16 v5, v57
    move-object v6, v1
    invoke-static {v4, v5, v6}, ''' + DRAFT_ENABLED_HOOK + '''
    move-result v4
    move/from16 v24, v4
'''
DRAFT_ENABLED_NEW = DRAFT_ENABLED_OLD + DRAFT_ENABLED_INSERTION
DRAFT_SEND_OLD = '''    .line 22
    check-cast v4, Lm83;

    .line 23'''
DRAFT_SEND_INSERTION = '''    invoke-static {v5, v4}, ''' + DRAFT_SEND_HOOK + '''
    move-result v0
    if-eqz v0, :rcs_sms_original
    return-object v3
    :rcs_sms_original

'''
DRAFT_SEND_NEW = DRAFT_SEND_OLD.replace('    .line 23', DRAFT_SEND_INSERTION + '    .line 23', 1)
# Both branches retain their native compose group open/close calls and all
# register preparation. Only the text node for vowifi_sms_send_hint is optional.
TEXT_NODE = 'Lz45;->b(Ljava/lang/String;Lr53;JJLnq1;Lsz4;JLn25;JIZIILs55;Llu1;III)V'
THREAD_HINT_CALL = '    invoke-static/range {v3 .. v24}, ' + TEXT_NODE
DRAFT_HINT_CALL = '    invoke-static/range {v29 .. v50}, ' + TEXT_NODE
THREAD_HINT_OLD = '    .line 1206\n    .line 1207\n' + THREAD_HINT_CALL
DRAFT_HINT_OLD = '    .line 1588\n    .line 1589\n' + DRAFT_HINT_CALL
HINT_END = '    :rcs_sms_hint_done'
THREAD_HINT_NEW = THREAD_HINT_OLD.replace(THREAD_HINT_CALL,
    '    invoke-static/range {v49 .. v49}, ' + SMS_HINT + '\n'
    '    move-result v25\n    if-eqz v25, :rcs_sms_hint_done\n' + THREAD_HINT_CALL + '\n' + HINT_END)
DRAFT_HINT_NEW = DRAFT_HINT_OLD.replace(DRAFT_HINT_CALL,
    '    move-object/from16 v0, p0\n    iget-object v0, v0, Lmc0;->X:Lm83;\n'
    '    invoke-static {v0}, ' + SMS_HINT + '\n'
    '    move-result v0\n    if-eqz v0, :rcs_sms_hint_done\n' + DRAFT_HINT_CALL + '\n' + HINT_END)
PATCHES = {
    TARGET: (SIGNATURE, ((THREAD_HINT_OLD, THREAD_HINT_NEW), (RENDER_OLD, RENDER_NEW), (ENABLED_OLD, ENABLED_NEW))),
    SEND_TARGET: (SEND_SIGNATURE, ((SEND_OLD, SEND_NEW),)),
    COMPOSE_TARGET: (COMPOSE_SIGNATURE, ((DRAFT_HINT_OLD, DRAFT_HINT_NEW), (DRAFT_RENDER_OLD, DRAFT_RENDER_NEW), (DRAFT_ENABLED_OLD, DRAFT_ENABLED_NEW))),
    COMPOSE_SEND_TARGET: (SEND_SIGNATURE, ((DRAFT_SEND_OLD, DRAFT_SEND_NEW),)),
}
LOCALS = {TARGET: 66, SEND_TARGET: 5, COMPOSE_TARGET: 75, COMPOSE_SEND_TARGET: 7}


def method(text, signature=SIGNATURE):
    marker = '.method ' + signature + '\n'
    assert text.count(marker) == 1, 'native RCS target method missing/duplicated: ' + signature
    start = text.index(marker)
    end = text.index('.end method', start) + len('.end method')
    return start, end, text[start:end]


def transform(text, reverse=False, name=TARGET):
    assert name in PATCHES, 'unknown RCS UI target: ' + name
    signature, regions = PATCHES[name]
    start, end, body = method(text, signature)
    if reverse:
        restored = body
        for old, new in regions:
            assert restored.count(new) == 1, 'RCS UI hook changed/missing: ' + name
            restored = restored.replace(new, old, 1)
        assert HELPER not in restored, 'extra RCS UI hook: ' + name
        assert hashlib.sha256(restored.encode()).hexdigest() == METHOD_PINS[(name, signature)], 'native method changed outside RCS UI hooks: ' + name
        return text[:start] + restored + text[end:]
    assert hashlib.sha256(body.encode()).hexdigest() == METHOD_PINS[(name, signature)], 'unexpected native RCS UI baseline: ' + name
    assert HELPER not in body, 'RCS UI already patched: ' + name
    patched = body
    for old, new in regions:
        assert patched.count(old) == 1, 'native RCS UI anchor mismatch: ' + name
        patched = patched.replace(old, new, 1)
    result = text[:start] + patched + text[end:]
    assert transform(result, True, name) == text, 'RCS UI patch not reversible: ' + name
    return result


def apply_rcs_chat_ui(smali):
    # Validate every source before writing any target.
    paths = {name: Path(smali) / name for name in PATCHES}
    patched = {name: transform(path.read_text(), name=name) for name, path in paths.items()}
    for name, path in paths.items():
        path.write_text(patched[name])


def reverse_rcs_chat_ui(name, text):
    return transform(text, True, name) if name in PATCHES else text


def verify_rcs_chat_ui(smali):
    for name, (signature, regions) in PATCHES.items():
        text = (Path(smali) / name).read_text()
        original = transform(text, True, name)
        assert transform(original, name=name) == text
        _, _, body = method(text, signature)
        assert body.count(HELPER) == len(regions)
        assert '    .locals ' + str(LOCALS[name]) + '\n' in body
    return dict(native_entry=SIGNATURE, native_send=SEND_SIGNATURE,
                method_pins={name + ':' + sig: pin for (name, sig), pin in METHOD_PINS.items()},
                fully_reversible_methods=True, hook_count=sum(len(regions) for _, regions in PATCHES.values()),
                explicit_state_and_peer=True, existing_send_button_used=True,
                rcs_consumed_before_sms_draft_clear=True, original_sms_off_path_preserved=True,
                new_message_composer_covered=True, smsc_editor_precedes_rcs_patch=True,
                register_counts_unchanged=True, device_tested=False)
