"""Retain early TCP transaction deadlines and arm their native UDP timer only on fallback."""
from pathlib import Path
import hashlib

PINS = {
    ('cb4.smali', 'public final p(Lkb4;Lma4;D)V'): '8cda9712ccc7490e08139426c3f1c95a2a499cfd584dd2684e8b9e6f8a741229',
    ('a82.smali', 'public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;'): 'c0c3c0c25b3d3b2eabc967a3045c53fff85066ceddc9e3d15d8c55384b597570',
}
TCP_OLD = '    .locals 10\n\n    .line 1\n'
TCP_NEW = ('    .locals 10\n\n'
           '    # sip_early_transaction_tcp_deadline\n'
           '    invoke-static {p0, p1, p2, p3, p4}, Lcc/forserein/simhub/internal/SipEarlyTransactionTransport;->rememberTcp(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;D)V\n\n'
           '    .line 1\n')
SEND_OLD = '    invoke-static {v6, v2}, Lcc/forserein/simhub/internal/SipInviteTransport;->onFallbackSent(Ljava/lang/Object;Ljava/lang/Object;)V\n'
SEND_NEW = SEND_OLD + ('\n    # sip_early_transaction_udp_fallback\n'
                      '    invoke-static {v6, v2}, Lcc/forserein/simhub/internal/SipEarlyTransactionTransport;->onFallbackSent(Ljava/lang/Object;Ljava/lang/Object;)V\n')
EDITS = {'cb4.smali': (TCP_OLD, TCP_NEW), 'a82.smali': (SEND_OLD, SEND_NEW)}


def _method(text, signature):
    start = text.index('.method ' + signature)
    end = text.index('.end method', start) + len('.end method')
    return start, end, text[start:end]


def apply_sip_early_transaction_transport(smali):
    for (name, signature), pin in PINS.items():
        path = Path(smali) / name
        text = path.read_text()
        start, end, body = _method(text, signature)
        assert hashlib.sha256(body.encode()).hexdigest() == pin, name + ': unexpected native transaction baseline'
        old, new = EDITS[name]
        assert body.count(old) == 1, name + ': non-unique anchor'
        path.write_text(text[:start] + body.replace(old, new) + text[end:])


def reverse_sip_early_transaction_transport(name, text):
    if name not in EDITS or 'SipEarlyTransactionTransport;->' not in text:
        return text
    signature, pin = next((signature, pin) for (target, signature), pin in PINS.items() if target == name)
    start, end, body = _method(text, signature)
    old, new = EDITS[name]
    assert body.count(new) == 1, name + ': changed transaction hook'
    body = body.replace(new, old)
    assert hashlib.sha256(body.encode()).hexdigest() == pin, name + ': unrelated instructions changed'
    result = text[:start] + body + text[end:]
    assert 'SipEarlyTransactionTransport;->' not in result and 'sip_early_transaction_' not in result
    return result


def verify_sip_early_transaction_transport(smali):
    for name, (old, new) in EDITS.items():
        text = (Path(smali) / name).read_text()
        assert text.count(new) == 1, name + ': missing hook'
        reverse_sip_early_transaction_transport(name, text)
    return {'native_methods': ['cb4.p', 'a82.f'], 'helper': 'SipEarlyTransactionTransport',
            'scope': 'correlated outgoing early PRACK and SDP precondition UPDATE',
            'tcp': 'native timer with infinite retransmit interval and original 32s absolute deadline',
            'udp': 'reuse only the still-live exact queued transaction after successful fallback dispatch',
            'first_retry_seconds': 0.5, 'native_retry_cap_seconds': 4, 'max_native_timers_per_dialog': 64,
            'deadline_extended': False, 'timer_created_on_fallback': False,
            'normal_udp_or_other_request_changed': False, 'route_or_destination_changed': False,
            'native_methods_exactly_reversible': True, 'real_carrier_tested': False}
