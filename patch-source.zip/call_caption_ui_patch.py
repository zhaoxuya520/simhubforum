"""Mount native AndroidViews in the dialer, settings list, and in-call Column."""
from hashlib import sha256
from pathlib import Path

BRIDGE = 'cc/forserein/simhub/internal/CaptionCompose'
SOURCE = Path(__file__).with_name('smali') / 'CaptionCompose.smali'
HOOKS = {
    'c00.smali': ('public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;',
                  'f35caab686e64a5051e5d7060d30b977ba2b41483ad1c9944b62e376375b7d75',
                  '    new-instance v9, Lnr2;', 'dialer', 'v11'),
    'rt.smali': ('private final h(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;',
                 'a1e341e5d5b34a4ec5f166ba744f30237abccb2e9745476816da38438d41511d',
                 '    invoke-static {}, Loc2;->A()Lqb2;', 'settings', 'v7'),
    'a20.smali': ('public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;',
                  'c3969d1c581c3fc6ea099ec0f143e6be3b1b278cebc7ea731cdaa7dcb8c2aa12',
                  '    new-instance v1, Lnr2;', 'call', 'v5'),
}
CAPTION_UI_CLASSES = set(HOOKS)

def _method(text, name):
    start = text.index('.method ' + HOOKS[name][0])
    end = text.index('.end method', start) + len('.end method')
    return start, end, text[start:end]

def _hook(name):
    _, _, _, kind, arg = HOOKS[name]
    return f'    invoke-static {{{arg}}}, L{BRIDGE};->{kind}(Llu1;)V\n\n'

def reverse_caption_ui(name, text):
    if name not in HOOKS:
        return text
    anchor = HOOKS[name][2]
    hook = _hook(name)
    start, end, method = _method(text, name)
    assert method.count(hook + anchor) == 1 and text.count('L'+BRIDGE+';->') == 1, name
    method = method.replace(hook + anchor, anchor)
    assert sha256(method.encode()).hexdigest() == HOOKS[name][1], name
    return text[:start] + method + text[end:]

def apply_caption_ui(smali):
    for name, (_, pin, anchor, _, _) in HOOKS.items():
        path = Path(smali) / name
        original = path.read_text()
        start, end, method = _method(original, name)
        assert sha256(method.encode()).hexdigest() == pin and method.count(anchor) == 1, name
        changed = original[:start] + method.replace(anchor, _hook(name) + anchor) + original[end:]
        assert reverse_caption_ui(name, changed) == original
        path.write_text(changed)
    destination = Path(smali) / (BRIDGE + '.smali')
    assert not destination.exists()
    destination.write_bytes(SOURCE.read_bytes())

def verify_caption_ui(smali):
    for name in HOOKS:
        reverse_caption_ui(name, (Path(smali)/name).read_text())
    assert (Path(smali)/(BRIDGE+'.smali')).read_bytes() == SOURCE.read_bytes()
    return {'native_methods': ['c00.f', 'rt.h', 'a20.f'], 'native_methods_exactly_reversible': True,
            'inline_compose_android_view': True, 'factory_interface': 'ws1.i',
            'placements': ['dialer before weighted spacer','settings between notifications and data management',
                           'call after peer details and before weighted spacer and native call controls']}
