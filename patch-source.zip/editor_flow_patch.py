from pathlib import Path

def patch_editor_flow(text):
    old='    move-object v3, v0'
    assert text.count(old)==1
    return text.replace(old,old+'\n    invoke-static {v3}, Lcc/forserein/simhub/internal/WifiConfigEditor;->stageCallback(Ljava/lang/Object;)Ljava/lang/Object;\n    move-result-object v3\n    check-cast v3, Lus1;')

def apply_editor_flow(smali):
    p=Path(smali)/'dm5.smali'
    p.write_text(patch_editor_flow(p.read_text()))
