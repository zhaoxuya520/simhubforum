from pathlib import Path

def patch_editor_flow(text):
    old='    move-object v3, v0'
    assert text.count(old)==1
    return text.replace(old,old+'\n    invoke-static {v3}, Lcc/forserein/simhub/internal/WifiConfigEditor;->stageCallback(Ljava/lang/Object;)Ljava/lang/Object;\n    move-result-object v3\n    check-cast v3, Lus1;')

def apply_editor_flow(smali):
    p=Path(smali)/'dm5.smali'
    p.write_text(patch_editor_flow(p.read_text()))

    # Replace inline network/device editors with the same compact field/list popup.
    p=Path(smali)/'rt.smali'
    text=p.read_text()
    signature='.method public final d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;'
    start=text.index(signature)
    locals_end=text.index('\n',text.index('    .locals ',start))
    hook='\n    move-object/from16 v0, p0\n    iget v0, v0, Lrt;->T:I\n    move-object/from16 v1, p2\n    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/WifiConfigEditor;->listSection(ILjava/lang/Object;)Z\n    move-result v2\n    if-eqz v2, :compact_config_original\n    sget-object v0, Lsc5;->a:Lsc5;\n    return-object v0\n    :compact_config_original\n'
    text=text[:locals_end]+hook+text[locals_end:]
    p.write_text(text)
    p=Path(smali)/'dm5.smali'
    text=p.read_text()
    signature='.method public final d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;'
    start=text.index(signature)
    locals_end=text.index('\n',text.index('    .locals ',start))
    hook='\n    move-object/from16 v0, p0\n    iget v0, v0, Ldm5;->T:I\n    if-nez v0, :compact_epdg_original\n    const/16 v0, 0x14\n    move-object/from16 v1, p2\n    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/WifiConfigEditor;->listSection(ILjava/lang/Object;)Z\n    move-result v2\n    if-eqz v2, :compact_epdg_original\n    sget-object v0, Lsc5;->a:Lsc5;\n    return-object v0\n    :compact_epdg_original\n'
    text=text[:locals_end]+hook+text[locals_end:]
    anchor='    if-ne v0, v1, :cond_6'
    assert text.count(anchor)==1
    p.write_text(text.replace(anchor,'    goto/16 :cond_6'))
    # An explicitly emptied SMSC list must not re-add a deleted card default when sending.
    p=Path(smali)/'zl5.smali'
    text=p.read_text()
    start=text.index('.method public final w(Ljava/lang/String;Ljava/lang/String;Ldt0;)Ljava/lang/Object;')
    end=text.index('.end method',start)
    body=text[start:end]
    anchor='    :try_start_1\n'
    assert body.count(anchor)==1
    body=body.replace(anchor,anchor+'    invoke-static {}, Lcc/forserein/simhub/internal/WifiConfigRuntime;->requireSmsCenter()V\n',1)
    p.write_text(text[:start]+body+text[end:])
