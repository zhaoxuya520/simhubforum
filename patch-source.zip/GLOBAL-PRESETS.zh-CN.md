# 全球运营商标准模板扩充

原包内置 1343 条专用/已有预设、1869 条匹配规则，覆盖 853 个不同 PLMN。本次完整保留这些记录与顺序；依据原包 MCC/MNC 名录，为缺少预设的 2264 个 PLMN 补充标准模板及通用匹配规则。合计 3607 条预设、4133 条匹配规则，覆盖 3117 个不同 PLMN（包含名录的全部 3043 个有效 PLMN）。这不是全球所有在营运营商的穷尽清单。

新增记录名称标注“标准模板（未实测）”，不声称运营商已确认或网络已支持。部分记录可能属于历史分配、专网、MVNO 或没有 Wi-Fi 通话服务的网络。没有从名称猜测运营商专用服务器、私有 APN、SMSC、IMEI、用户 IMSI 或认证密钥。

标准模板沿用原应用通用回退的参数集合，包括 ims APN、双栈候选、20 秒 keepalive、原有 IKE/ESP 兼容算法。epdgAddress 和 imsDomain 留 null，由原程序根据实际 USIM 的 MCC/MNC 生成 3GPP 域名；NAI 保留 $imsi/$mnc/$mcc 占位符，由实际读卡身份替换。两位/三位 MNC 的 PLMN 键不合并，仅域名 MNC 左补零到三位。

DITO 51566 新增的是标准模板，不是已验证的运营商专用配置。实际读到 51566 时应生成 epdg.epc.mnc066.mcc515.pub.3gppnetwork.org 和 ims.mnc066.mcc515.3gppnetwork.org。不会把实际 20404 的身份强行改成 51566；之前的错卡通道及身份诊断继续保留。

新增 assets/vowifi/global_standard_catalogue.json 保存每个名录 PLMN 的名称、状态、标准域名、输入 SHA-256，以及未知的支持状态。已有预设也不因本次整理而自动变为实机验证记录。原库 source/generated 元数据保留，只增加模板版本标记。

用户覆盖值仍优先；清空保存恢复当前卡的内置预设/标准模板。没有更改界面布局，也没有新增运营商选择器。

生成器：carrier_presets_patch.py。apply_patch.py 和 build_from_config2.py 均已接入。九组数据测试检查完整覆盖、已有记录不变、标识不重复、字段结构兼容、DITO 域名、MNC 长度、未验证标记、重复应用拒绝和非法代码拒绝。实际 APK 解析及运营商通信仍需 Android 实机验证。
