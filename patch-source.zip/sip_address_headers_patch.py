"""Use SIP address-list rules at native response/request parsing, before IMS selection."""
import hashlib
from pathlib import Path

SIGNATURE = '.method public static c([B)Lkb4;'
ORIGINAL = '84df67f9cd9329ee9c1c26d1e458e482d023477dbf9989db02932f34b3967c32'
NATIVE = '    sget-object v8, Lkb4;->i:Ljava/util/Set;'
SPLIT = '''    invoke-static {v7}, Lcc/forserein/simhub/internal/SipAddressHeaders;->handles(Ljava/lang/String;)Z
    move-result v8
    if-eqz v8, :native_other_header_values
    iget-object v9, v12, Lkb4;->f:Ljava/util/ArrayList;
    invoke-static {v4}, Lcc/forserein/simhub/internal/SipAddressHeaders;->split(Ljava/lang/String;)Ljava/util/ArrayList;
    move-result-object v4
    goto :parsed_address_values

    :native_other_header_values
''' + NATIVE
LOOP = '    .line 618\n    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I'
RESUME = '    :parsed_address_values\n' + LOOP


def apply_sip_address_headers(smali):
    path = Path(smali) / 'jb4.smali'
    text = path.read_text()
    start = text.index(SIGNATURE)
    end = text.index('.end method', start) + len('.end method')
    body = text[start:end]
    assert hashlib.sha256(body.encode()).hexdigest() == ORIGINAL, 'unexpected native SIP parser'
    assert body.count(NATIVE) == body.count(LOOP) == 1
    changed = body.replace(NATIVE, SPLIT).replace(LOOP, RESUME)
    assert changed.replace(SPLIT, NATIVE).replace(RESUME, LOOP) == body
    path.write_text(text[:start] + changed + text[end:])

    # The dialog builder also accepts response objects assembled by callers. It
    # flattens Record-Route again before reversing the hops for the UAC.
    path = Path(smali) / 'bb4.smali'
    text = path.read_text()
    signature = '.method public static a(Lkb4;Ljava/lang/String;)Ljava/util/ArrayList;'
    start = text.index(signature)
    end = text.index('.end method', start) + len('.end method')
    body = text[start:end]
    assert hashlib.sha256(body.encode()).hexdigest() == '0eab3d0d6ac8fe07603fc9a93b1223745f169a28245f640cd22e29a85683045e'
    locals_before = '    .locals 4'
    locals_after = (
        '    .locals 5\n'
        '    invoke-static {p1}, Lcc/forserein/simhub/internal/SipAddressHeaders;->handles(Ljava/lang/String;)Z\n'
        '    move-result v4'
    )
    split_before = '    invoke-static {v2}, Ljb4;->f(Ljava/lang/String;)Ljava/util/ArrayList;'
    split_after = (
        '    if-eqz v4, :split_other_header\n'
        '    invoke-static {v2}, Lcc/forserein/simhub/internal/SipAddressHeaders;->split(Ljava/lang/String;)Ljava/util/ArrayList;\n'
        '    move-result-object v2\n'
        '    goto :append_header_values\n'
        '    :split_other_header\n' + split_before
    )
    append_before = '    invoke-static {p1, v2}, Ldl0;->q0(Ljava/util/Collection;Ljava/lang/Iterable;)V'
    append_after = '    :append_header_values\n' + append_before
    changed = body
    for before, after in ((locals_before, locals_after), (split_before, split_after), (append_before, append_after)):
        assert changed.count(before) == 1
        changed = changed.replace(before, after)
    path.write_text(text[:start] + changed + text[end:])
