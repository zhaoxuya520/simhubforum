"""Annotate the existing outgoing EAP reply log with its public EPC realm."""
from pathlib import Path

def apply_eap_response_log(smali):
    path = Path(smali) / 'b72.smali'
    original = path.read_text()
    start = original.index('.method public final e(Ljava/lang/String;Lt62;Ljava/lang/String;Ljava/util/ArrayList;Ldt0;)')
    end = original.index('.end method', start)
    method = original[start:end]
    reply = method.index('    iget-object v1, v1, Lz91;->a:[B')
    summary = method.index('    invoke-static {v7, v3, v15, v10, v14}, Ley3;->h(', reply)
    call = method.index('    invoke-interface {v2, v3}, Lws1;->i(Ljava/lang/Object;)Ljava/lang/Object;', summary)
    assert method[summary:call].count('    move-result-object v3') == 1
    assert '    iget-object v2, v0, Lb72;->c:Lws1;' in method[reply:summary]
    hook = '''    invoke-static {v3, v1}, Lcc/forserein/simhub/internal/EapIdentityLog;->describe(Ljava/lang/String;[B)Ljava/lang/String;
    move-result-object v3
'''
    assert hook not in original
    patched = original[:start+call] + hook + original[start+call:]
    assert patched.replace(hook, '', 1) == original
    path.write_text(patched)
