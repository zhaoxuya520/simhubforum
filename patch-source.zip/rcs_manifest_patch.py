"""Declare the GSMA chat API and visibility for chat providers and the default SMS app."""
import struct


PERMISSION = 'com.gsma.services.permission.RCS'
ACTION = 'com.gsma.services.rcs.chat.IChatService'
SMS_DELIVER = 'android.provider.Telephony.SMS_DELIVER'
ANDROID = 'http://schemas.android.com/apk/res/android'
NONE = 0xffffffff


def add_rcs_manifest(data):
    # This build operates on one pinned Android binary manifest. Keep existing
    # resource IDs, original string references, attribute order and XML chunks.
    assert struct.unpack_from('<HHI', data) == (3, 8, len(data))
    kind, header, size, count, styles, flags, start, style_start = struct.unpack_from('<HHIIIIII', data, 8)
    assert (kind, header, styles, flags, start, style_start) == (1, 28, 0, 0, 28 + 4 * count, 0)
    offsets = list(struct.unpack_from('<' + 'I' * count, data, 8 + header))
    pool = bytearray(data[8 + start:8 + size])
    strings = []
    for offset in offsets:
        units = struct.unpack_from('<H', pool, offset)[0]
        assert units < 0x8000
        strings.append(pool[offset+2:offset+2+units*2].decode('utf-16le'))
    assert PERMISSION not in strings and ACTION not in strings

    for value in (PERMISSION, 'intent', ACTION, SMS_DELIVER):
        if value not in strings:
            offsets.append(len(pool))
            strings.append(value)
            pool.extend(struct.pack('<H', len(value)) + value.encode('utf-16le') + b'\0\0')
    pool.extend(b'\0' * (-len(pool) % 4))
    start = header + 4 * len(offsets)
    result = bytearray(data[:8])
    result.extend(struct.pack('<HHIIIIII', kind, header, start + len(pool), len(offsets), 0, 0, start, 0))
    result.extend(struct.pack('<' + 'I' * len(offsets), *offsets))
    result.extend(pool)

    def element(name, line, value=None, children=b''):
        name_id = strings.index(name)
        attribute = b''
        if value is not None:
            value_id = strings.index(value)
            attribute = struct.pack('<IIIHBBI', strings.index(ANDROID), strings.index('name'),
                                    value_id, 8, 0, 3, value_id)
        node = struct.pack('<HHIII', 0x102, 16, 36 + len(attribute), line, NONE)
        node += struct.pack('<IIHHHHHH', NONE, name_id, 20, 20, int(bool(attribute)), 0, 0, 0)
        end = struct.pack('<HHIIIII', 0x103, 16, 24, line, NONE, NONE, name_id)
        return node + attribute + children + end

    pos = 8 + size
    inserted_permissions = inserted_queries = 0
    while pos < len(data):
        tag, _, chunk_size = struct.unpack_from('<HHI', data, pos)
        assert chunk_size >= 8 and pos + chunk_size <= len(data)
        if tag in (0x102, 0x103):
            name = strings[struct.unpack_from('<I', data, pos+20)[0]]
            line = struct.unpack_from('<I', data, pos+8)[0]
            if tag == 0x102 and name == 'queries':
                result.extend(element('uses-permission', line, PERMISSION))
                inserted_permissions += 1
            if tag == 0x103 and name == 'queries':
                for action in (ACTION, SMS_DELIVER):
                    result.extend(element('intent', line, children=element('action', line, action)))
                    inserted_queries += 1
        result.extend(data[pos:pos+chunk_size])
        pos += chunk_size
    assert (inserted_permissions, inserted_queries) == (1, 2)
    struct.pack_into('<I', result, 4, len(result))
    return bytes(result)
