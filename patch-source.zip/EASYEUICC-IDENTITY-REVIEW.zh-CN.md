# EasyEUICC 与 Wi-Fi 通话身份读取对照

参考 estkme-group/openeuicc b79e03bbf42f4d69b9d9dd21cd6132bb1b9314d7，完整源码已核对。

- EuiccManagementFragment 使用 profile.displayName / profile.providerName 显示配置名称与运营商。资料通过绑定 slot / port / seId / ISD-R AID 的 LPA 获取。
- OmapiApduInterface 以 port.logicalSlotIndex + 1 选择 UICC reader，在该接口的 session 上打开指定 AID。DefaultEuiccChannelManager 按 seId 查找芯片通道，重连时关闭并重建通道。
- Vendors 的 eSTK 处理优先 SE0 / SE1 管理 AID。SIMHub 的 nk2 / bp1 已包含该优先顺序和去重，不应重复修复为所谓新增支持。
- EasyEUICC 未提供与 SIMHub 相同的 Wi-Fi 通话 IMSI / EAP 身份读取流程。配置列表名称不能证明 modem / USIM 的实际认证身份，不能直接复制 providerName 当作 IMSI 对应运营商。

SIMHub 当前路径：px3 调用 zl5.d，zl5.q 创建 ac5，通过 vb5 先读 EF_ICCID，再读 EF_IMSI / EF_AD；ac5.m 的内置卡路径经 pf3 打开通用部分 USIM AID A0000000871002。此路径与指定 EID 的管理 AID 读取不同。zl3.r 先精确匹配实读 PLMN，再匹配运营商规则 / 预设。因此需区分实读身份错误和预设匹配错误。

上一版的缓存与异步结果保护已被用户实机反馈证明不足以解决症状，不作为修复完成。当前缺少该次读卡的 PLMN、selectedICCID / actualICCID 尾号及通道日志，尚不能确定是错误 USIM 路由、配置匹配还是卡片实际身份。不得凭配置名或 ICCID 前缀构造 IMSI，不得仅改显示名称后宣称修好。

下一步依据 SIMHubIdentity 的 USIM read 与本次读卡完成 PLMN 行定位，不要求完整 IMSI。此次对照没有再次修改通道算法或发布未经定位的新 APK。
