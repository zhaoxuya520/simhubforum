"""Bound initial INVITE 487 handling and retain native ACKs for normal retransmission."""
from pathlib import Path
import hashlib

SIGNATURE = '.method public final h(Lkb4;)Z'
BASE_SHA256 = '72f561a4aa1349c73a8a55fae146f03786963c65dbea4c6cb0ad8727a446b1df'
ENTRY = '    :sip_fork_native_response\n'
GUARD = '''
    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/SipInviteFailure;->handle(Ljava/lang/Object;Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, :sip_invite_failure_native_response
    const/4 v2, 0x1
    return v2
    :sip_invite_failure_native_response
'''
ACK = '    invoke-virtual {v2, v0}, Lcb4;->a(Lkb4;)V\n'
REMEMBER = '''
    move-object/from16 v9, p0
    move-object/from16 v12, p1
    invoke-static {v9, v12, v0}, Lcc/forserein/simhub/internal/SipInviteFailure;->remember(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
'''


def _method(text):
    a = text.index(SIGNATURE)
    b = text.index('.end method', a) + len('.end method')
    return a, b, text[a:b]


def apply_sip_invite_failure(smali):
    path = Path(smali) / 'o82.smali'
    text = path.read_text()
    a, b, body = _method(text)
    assert hashlib.sha256(body.encode()).hexdigest() == BASE_SHA256, 'apply after existing SIP fork patch'
    assert body.count(ENTRY) == 1 and body.count(ACK) == 1
    body = body.replace(ENTRY, ENTRY + GUARD).replace(ACK, ACK + REMEMBER)
    path.write_text(text[:a] + body + text[b:])


def reverse_sip_invite_failure(name, text):
    if name != 'o82.smali':
        return text
    if 'SipInviteFailure;->' not in text and ':sip_invite_failure_native_response' not in text:
        return text
    a, b, body = _method(text)
    assert body.count(ENTRY + GUARD) == 1 and body.count(ACK + REMEMBER) == 1
    body = body.replace(ENTRY + GUARD, ENTRY).replace(ACK + REMEMBER, ACK)
    assert hashlib.sha256(body.encode()).hexdigest() == BASE_SHA256, 'native response instructions changed'
    return text[:a] + body + text[b:]


def verify_sip_invite_failure(smali):
    text = (Path(smali) / 'o82.smali').read_text()
    assert text.count(ENTRY + GUARD) == 1 and text.count(ACK + REMEMBER) == 1
    reverse_sip_invite_failure('o82.smali', text)
    return dict(status=487, method='INVITE', transaction='original request CSeq, Call-ID, Via branch, From tag',
                native_failure_retained=True, native_ack_retained=True, confirmed_dialog_protected=True,
                ack_cache_limit=64, ack_cache_seconds=32, automatic_redial=False, device_tested=False)
