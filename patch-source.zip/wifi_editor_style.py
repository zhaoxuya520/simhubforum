"""Warm surfaces for the Wi-Fi editor's local Compose palette and native controls."""

LIGHT = ['514532','31865A','955616','AA3C31','302D27','6A6359','716A5F','E8E2D5',
         'FAF8F1','F2EFE6','FAF8F1','FFFEFA','F2EFE6','F5F2EA']
DARK = ['E8D8B8','78CAA0','E4B56E','FFACA1','F5F0E6','BFB8AA','B6AD9E','47433B',
        '24221E','302E29','24221E','302E29','25231F','38352E']
FIELDS = '.field private static wifiLight:Ljj2;\n.field private static wifiDark:Ljj2;\n'
SURFACE_CALL = '    invoke-static/range {v23 .. v34}, Lay2;->i(Lr53;Ljn;Lim4;Lww1;JZZZLlu1;II)Lr53;\n\n    move-result-object v0\n\n    .line 442'
SURFACE_EDIT = SURFACE_CALL.replace('    .line 442','    invoke-static {v0, v3}, Lz55;->wifiSurface(Lr53;Ljj2;)Lr53;\n    move-result-object v0\n\n    .line 442')

def helpers(packed):
    methods = ''
    for name, dark, colors in [('wifiLight',0,LIGHT),('wifiDark',1,DARK)]:
        registers=''.join(f'    const-wide v{2+2*i}, {packed(color)}\n' for i,color in enumerate(colors))
        methods+=f'''
.method private static {name}()Ljj2;
    .locals 30
    sget-object v0, Lz55;->{name}:Ljj2;
    if-nez v0, :ready
    new-instance v0, Ljj2;
    const/4 v1, {dark}
{registers}    invoke-direct/range {{v0 .. v29}}, Ljj2;-><init>(ZJJJJJJJJJJJJJJ)V
    sput-object v0, Lz55;->{name}:Ljj2;
    :ready
    return-object v0
.end method
'''
    return methods+'''
.method public static wifiPalette(Ljj2;)Ljj2;
    .locals 1
    iget-boolean v0,p0,Ljj2;->a:Z
    if-eqz v0,:light
    invoke-static {},Lz55;->wifiDark()Ljj2;
    move-result-object v0
    return-object v0
    :light
    invoke-static {},Lz55;->wifiLight()Ljj2;
    move-result-object v0
    return-object v0
.end method

.method public static wifiDialogContent(Llt1;Llu1;)Llt1;
    .locals 2
    sget-object v0,Lz55;->c:Lhu4;
    invoke-virtual {p1,v0},Llu1;->k(Lrv3;)Ljava/lang/Object;
    move-result-object v0
    sget-object v1,Lz55;->wifiLight:Ljj2;
    if-eq v0,v1,:wrap
    sget-object v1,Lz55;->wifiDark:Ljj2;
    if-ne v0,v1,:done
    :wrap
    invoke-static {p0},Lcc/forserein/simhub/internal/WifiConfigEditor;->sheetContent(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p0
    check-cast p0,Llt1;
    :done
    return-object p0
.end method

.method public static wifiPanel(Lkt1;Llu1;)V
    .locals 3
    sget-object v0, Lz55;->c:Lhu4;
    invoke-virtual {p1,v0}, Llu1;->k(Lrv3;)Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljj2;
    invoke-static {v1},Lz55;->wifiPalette(Ljj2;)Ljj2;
    move-result-object v1
    invoke-virtual {v0,v1}, Lhu4;->a(Ljava/lang/Object;)Ltv3;
    move-result-object v0
    const/4 v2,0x0
    invoke-static {v0,p0,p1,v2}, Lf23;->j(Ltv3;Lkt1;Llu1;I)V
    return-void
.end method

.method public static wifiField(Lr53;Llu1;)Lr53;
    .locals 6
    sget-object v0,Lz55;->c:Lhu4;
    invoke-virtual {p1,v0},Llu1;->k(Lrv3;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0,Ljj2;
    const/high16 v1,0x41500000    # 13dp radius
    invoke-static {v1},Lp74;->b(F)Lo74;
    move-result-object v2
    iget-wide v3,v0,Ljj2;->n:J
    invoke-static {p0,v3,v4,v2},Lv95;->o(Lr53;JLim4;)Lr53;
    move-result-object p0
    const/high16 v5,0x3f800000
    iget-wide v3,v0,Ljj2;->i:J
    invoke-static {p0,v5,v3,v4,v2},Lf93;->o(Lr53;FJLim4;)Lr53;
    move-result-object p0
    const/high16 v2,0x41000000    # 8dp
    invoke-static {p0,v1,v2},Lei0;->Z(Lr53;FF)Lr53;
    move-result-object p0
    return-object p0
.end method

.method public static wifiSurface(Lr53;Ljj2;)Lr53;
    .locals 4
    sget-object v0,Lz55;->wifiLight:Ljj2;
    if-eq v0,p1,:apply
    sget-object v0,Lz55;->wifiDark:Ljj2;
    if-ne v0,p1,:done
    :apply
    const/high16 v0,0x41e00000    # 28dp
    invoke-static {v0},Lp74;->b(F)Lo74;
    move-result-object v1
    iget-wide v2,p1,Ljj2;->j:J
    invoke-static {p0,v2,v3,v1},Lv95;->o(Lr53;JLim4;)Lr53;
    move-result-object p0
    :done
    return-object p0
.end method

.method public static wifiActionInset(Lr53;Ljj2;)Lr53;
    .locals 2
    sget-object v0,Lz55;->wifiLight:Ljj2;
    if-eq v0,p1,:apply
    sget-object v0,Lz55;->wifiDark:Ljj2;
    if-ne v0,p1,:done
    :apply
    const/high16 v0,0x41000000    # 8dp
    const/high16 v1,0x40c00000    # 6dp
    invoke-static {p0,v0,v1},Lei0;->Z(Lr53;FF)Lr53;
    move-result-object p0
    :done
    return-object p0
.end method
'''
