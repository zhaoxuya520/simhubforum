#!/usr/bin/env python3
"""Compile and integrate the OMAPI patch into the exact supplied APK. Does not sign it."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
TOOLS = Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery'))
APK = Path(os.environ.get('SIMHUB_INPUT_APK', '/workspace/attachments/1a70e950-9493-4b5c-a938-703c1461f5a4/SIMHub-Android-23.1.apk'))
BUILD = ROOT / 'build'
BUILD.mkdir(exist_ok=True)
assert hashlib.sha256(APK.read_bytes()).hexdigest() == '3e3666229a71d7f28645f6c728298180a12040ba1c1eb8610d196775f9584572', 'Wrong input APK'
SDK = TOOLS / 'sdk'
ANDROID = SDK / 'android-35/android.jar'
APKTOOL = TOOLS / 'apktool_3.0.3.jar'
ECJ = TOOLS / 'ecj-3.40.0.jar'

def run(*args):
    print('+', ' '.join(map(str, args)), flush=True)
    subprocess.run(list(map(str, args)), cwd=ROOT, check=True)

# These are generated outputs inside this patch directory only.
for name in ('classes', 'test-classes', 'dex', 'module-decoded', 'apktool'):
    path = BUILD / name
    if path.exists(): shutil.rmtree(path)
for name in ('classes', 'test-classes', 'dex'):
    (BUILD / name).mkdir()
run('java', '-jar', ECJ, '-8', '-encoding', 'UTF-8', '-cp', ANDROID,
    '-d', BUILD / 'classes', *sorted((ROOT / 'src').rglob('*.java')))
run('java', '-jar', ECJ, '-8', '-encoding', 'UTF-8', '-cp', BUILD / 'classes',
    '-d', BUILD / 'test-classes', *sorted((ROOT / 'tests').rglob('*.java')))
results = {}
for test in ('SimProtocolTest', 'OmapiSupportTest', 'ConnectionLeaseTest', 'ProfileRefreshTest', 'ChannelLeaseTest', 'ProfileReadStateTest', 'DialingSupportTest', 'WifiConfigTest', 'WifiConfigUiTest', 'MultiChipSwitchTest', 'IdentityBindingTest'):
    output = subprocess.check_output(['java', '-cp', str(BUILD / 'test-classes') + ':' + str(BUILD / 'classes'), test], text=True)
    print(output, end='', flush=True)
    match = re.search(r'PASS: (\d+) ', output)
    assert match, 'Missing test completion result: ' + test
    results[test] = int(match[1])
(BUILD / 'test-results.json').write_text(json.dumps(results, indent=2) + '\n')
with zipfile.ZipFile(BUILD / 'module.jar', 'w', zipfile.ZIP_DEFLATED) as jar:
    for path in sorted((BUILD / 'classes').rglob('*.class')):
        jar.write(path, path.relative_to(BUILD / 'classes'))
run('java', '-cp', SDK / 'android-15/lib/d8.jar', 'com.android.tools.r8.D8',
    '--min-api', '28', '--lib', ANDROID, '--output', BUILD / 'dex', BUILD / 'module.jar')
with zipfile.ZipFile(APK) as original, zipfile.ZipFile(BUILD / 'module.apk', 'w', zipfile.ZIP_DEFLATED) as module:
    for name in ('AndroidManifest.xml', 'resources.arsc'):
        module.writestr(name, original.read(name))
    module.write(BUILD / 'dex/classes.dex', 'classes.dex')
run('java', '-jar', APKTOOL, 'd', '-r', '-j', '2', '-p', TOOLS / 'framework',
    '-o', BUILD / 'module-decoded', BUILD / 'module.apk')
run('java', '-Xmx3g', '-jar', APKTOOL, 'd', '-j', '2', '-p', TOOLS / 'framework',
    '-o', BUILD / 'apktool', APK)
run('python3', ROOT / 'apply_patch.py', BUILD / 'apktool')
run('python3', ROOT / 'tests/check_refresh_flow.py', BUILD / 'apktool/smali/hz3.smali')
run('python3', ROOT / 'tests/check_multichip_flow.py', BUILD / 'apktool/smali/InternalSimMultiChipSwitch.smali')
run('python3', ROOT / 'tests/check_checked_read_flow.py', BUILD / 'apktool/smali/InternalSimChipRead.smali')
run('python3', ROOT / 'tests/check_dialing_integration.py', BUILD / 'apktool/smali')
run('python3', ROOT / 'tests/check_wifi_config_integration.py', BUILD / 'apktool/smali')
for path in (BUILD / 'module-decoded/smali').rglob('*.smali'):
    destination = BUILD / 'apktool/smali' / path.relative_to(BUILD / 'module-decoded/smali')
    assert not destination.exists(), 'Refusing to replace existing class: ' + str(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, destination)
unsigned = BUILD / 'SIMHub-23.1-internal-sim-unsigned.apk'
unaligned = BUILD / 'SIMHub-23.1-internal-sim-unaligned.apk'
run('java', '-Xmx3g', '-jar', APKTOOL, 'b', '-j', '2', '-p', TOOLS / 'framework',
    '-o', unaligned, BUILD / 'apktool')
zipalign = SDK / 'android-15/zipalign'
zipalign.chmod(0o755)
run(zipalign, '-P', '16', '-f', '4', unaligned, unsigned)
run(zipalign, '-c', '-P', '16', '4', unsigned)
with zipfile.ZipFile(unsigned) as archive:
    assert archive.testzip() is None
digest = hashlib.sha256(unsigned.read_bytes()).hexdigest()
unsigned.with_suffix('.apk.sha256').write_text(digest + '  ' + unsigned.name + '\n')
print('Built unsigned APK:', unsigned)
print('SHA-256:', digest)
