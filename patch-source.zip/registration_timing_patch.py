"""Respect native registrar expiry and refresh before even very short bindings expire.

The native Contact matching, AKA, security agreement and IKE code are untouched.
Reverse restoration permits exact whole-class baseline comparison after this patch.
"""
from pathlib import Path
import hashlib

TYPE = 'Lcc/forserein/simhub/internal/RegistrationTiming;'

EDITS = {'o82.smali': [('    new-instance v10, Lx72;', '    if-gtz v9, :simhub_registration_positive\n    const/4 v2, 0x0\n    iput-object v2, v0, Lo82;->s:Lx72;\n    invoke-virtual {v0, v9}, Lo82;->y(I)V\n    :simhub_registration_positive\n    invoke-static {v9}, Lcc/forserein/simhub/internal/RegistrationTiming;->acceptedExpires(I)I\n    move-result v9\n    new-instance v10, Lx72;'), ('    const/16 v1, 0x3c\n\n    .line 2927\n    .line 2928\n    invoke-static {v1, v9}, Ljava/lang/Math;->max(II)I\n\n    .line 2929\n    .line 2930\n    .line 2931\n    move-result v12', '    move v12, v9'), ('    int-to-double v2, p1\n\n    .line 10\n    const-wide v4, 0x3feb333333333333L    # 0.85\n\n    .line 11\n    .line 12\n    .line 13\n    .line 14\n    .line 15\n    mul-double/2addr v2, v4\n\n    .line 16\n    double-to-int p1, v2\n\n    .line 17\n    const/16 v0, 0x1e\n\n    .line 18\n    .line 19\n    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I\n\n    .line 20\n    .line 21\n    .line 22\n    move-result p1', '    iput-object v1, p0, Lo82;->w:Lls4;\n    if-lez p1, :simhub_registration_no_refresh'), ('    iput-object p1, p0, Lo82;->w:Lls4;', '    iput-object p1, p0, Lo82;->w:Lls4;\n    :simhub_registration_no_refresh')], 'bh1.smali': [('    int-to-long v10, v2\n\n    .line 100\n    const-wide/16 v12, 0x3e8\n\n    .line 101\n    .line 102\n    mul-long/2addr v10, v12', '    invoke-static {v2}, Lcc/forserein/simhub/internal/RegistrationTiming;->refreshDelayMillis(I)J\n    move-result-wide v10')]}

METHOD_PINS = {('o82.smali', 'public final v(Ldt0;)Ljava/lang/Object;'): '61c991ebfce3006d90211b850e37db8d6f0fc589515fe14d6dd2c38444c64402', ('o82.smali', 'public final y(I)V'): '4c9efe6ebfd2007c4d5035a7c52d91ee7316cd198ba49d4681ba1d6026d33cae', ('bh1.smali', 'public final q(Ljava/lang/Object;)Ljava/lang/Object;'): '441fc3357de6d1161518f8be8212bfbc23ce6774dead237cf194e66fd9e2e018'}

def method(text, signature):
    return text.split(".method "+signature+"\n", 1)[1].split(".end method", 1)[0]

def replacements():
    return EDITS

def apply_registration_timing(smali: Path):
    for name, edits in replacements().items():
        path = smali / name
        value = path.read_text()
        for old, new in edits:
            assert value.count(old) == 1, (name, old)
            value = value.replace(old, new)
        for (target, sig), digest in METHOD_PINS.items():
            if target == name:
                assert hashlib.sha256(method(path.read_text(), sig).encode()).hexdigest() == digest, (name, sig)
        path.write_text(value)

def restore_native(name, value):
    for old, new in reversed(replacements()[name]):
        assert value.count(new) == 1, (name, 'registration hook absent or duplicated')
        value = value.replace(new, old)
    return value
