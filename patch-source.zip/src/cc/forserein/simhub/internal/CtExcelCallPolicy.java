package cc.forserein.simhub.internal;

import java.util.List;

import static cc.forserein.simhub.internal.SipInviteFailure.call;
import static cc.forserein.simhub.internal.SipInviteFailure.field;
import static cc.forserein.simhub.internal.SipInviteFailure.first;

/** CTExcel UK policy at initial outgoing INVITE construction; no authentication or media changes. */
public final class CtExcelCallPolicy {
    private CtExcelCallPolicy() {}

    /** The effective configuration also represents an explicit user carrier choice. */
    private static Object engine(Object coroutine) throws Exception {
        Object engine = field(coroutine, "Y");
        Object config = field(engine, "b");
        if (!"234".equals(field(config, "d")) || !"33".equals(field(config, "e"))) return null;
        return field(engine, "s") == null ? null : engine;
    }

    /** Only identities actually returned by this registered IMS session are eligible. */
    public static String callerIdentity(Object coroutine, String nativeFallback) {
        try {
            Object engine = engine(coroutine);
            if (engine == null) return nativeFallback;
            Object registration = field(engine, "s");
            for (Object value : (List<?>) field(registration, "a")) {
                if (!(value instanceof String)) continue;
                String identity = (String) value;
                if (!identity.regionMatches(true, 0, "sip:+", 0, 5)) continue;
                int at = identity.indexOf('@');
                if (at <= 5 || at == identity.length() - 1) continue;
                if (at - 5 > 15 || identity.charAt(5) < '1' || identity.charAt(5) > '9') continue;
                boolean clean = true;
                for (int i = 5; i < at; i++) {
                    char digit = identity.charAt(i);
                    if (digit < '0' || digit > '9') { clean = false; break; }
                }
                if (!clean) continue;
                for (int i = 0; i < identity.length(); i++) {
                    char c = identity.charAt(i);
                    if (c <= 0x20 || c == 0x7f || c == '<' || c == '>') { clean = false; break; }
                }
                if (clean) return identity; // Preserve the registered URI and its parameters verbatim.
            }
        } catch (Exception ignored) {
            // Preserve the original selection if session metadata cannot be inspected.
        }
        return nativeFallback;
    }

    /** Run after native number formatting, before Request-URI, To and dialog targets are created. */
    public static String destination(Object coroutine, String nativeUri) {
        try {
            Object engine = engine(coroutine);
            if (engine == null || nativeUri == null || !nativeUri.startsWith("sip:")) return nativeUri;
            String domain = (String) field(field(engine, "b"), "g");
            if (domain == null || !domain.matches("[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?")) return nativeUri;
            String suffix = "@" + domain;
            if (!nativeUri.endsWith(suffix)) return nativeUri;
            String number = nativeUri.substring(4, nativeUri.length() - suffix.length());
            if (number.isEmpty() || number.startsWith("+") || number.startsWith("00")) return nativeUri;
            for (int i = 0; i < number.length(); i++) {
                char c = number.charAt(i);
                if ((c >= '0' && c <= '9') || c == '*') continue;
                if (number.startsWith("%23", i)) { i += 2; continue; }
                return nativeUri;
            }
            return "tel:" + number + ";phone-context=" + domain;
        } catch (Exception ignored) {
            return nativeUri;
        }
    }

    /** RFC5009: an IMS UE can recognize early-media authorization while its trusted proxy gates media. */
    public static void decorate(Object coroutine, Object request) {
        try {
            Object engine = engine(coroutine);
            if (engine == null || field(engine, "q") == null
                    || !Boolean.TRUE.equals(field(field(engine, "b"), "t"))) return;
            if (!Boolean.TRUE.equals(field(request, "a")) || !"INVITE".equals(field(request, "b"))) return;
            // This hook only builds initial INVITEs. Retain an explicit check for isolated/repeated invocation.
            String to = first(request, "To", "t");
            if (SipInviteFailure.parameter(request, to, "tag") != null) return;
            if (first(request, "P-Early-Media", null) == null)
                call(request, "a", new Class<?>[]{String.class, String.class}, "P-Early-Media", "supported");
        } catch (Exception ignored) {
            // Optional policy must not prevent the original call request from being constructed.
        }
    }
}
