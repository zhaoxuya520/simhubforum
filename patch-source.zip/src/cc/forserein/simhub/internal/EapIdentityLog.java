package cc.forserein.simhub.internal;

import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Read only the standard public realm from the native encoder's single AT_IDENTITY reply. */
public final class EapIdentityLog {
    private EapIdentityLog() {}
    private static final String EXAMPLE = "@nai.epc.mnc000.mcc000.3gppnetwork.org";
    private static final Pattern EPC = Pattern.compile("@nai\\.epc\\.(mnc[0-9]{3}\\.mcc[0-9]{3})\\.3gppnetwork\\.org");
    private static int word(byte[] packet, int offset) {
        return (packet[offset] & 255) << 8 | (packet[offset + 1] & 255);
    }
    public static String describe(String summary, byte[] packet) {
        if (packet == null || packet.length < 12 || packet[0] != 2 ||
            (packet[4] != 23 && packet[4] != 50) || packet[5] != 5 || packet[8] != 14) return summary;
        int length = word(packet, 10);
        int attributeBytes = (packet[9] & 255) * 4;
        if (word(packet, 2) != packet.length || 8 + attributeBytes != packet.length ||
            attributeBytes != ((4 + length + 3) & ~3)) return summary;
        String method = packet[4] == 23 ? "AKA" : "AKA′";
        if (length > EXAMPLE.length()) {
            int offset = 12 + length - EXAMPLE.length();
            Matcher realm = EPC.matcher(new String(packet, offset, EXAMPLE.length(), StandardCharsets.US_ASCII));
            if (realm.matches()) return summary + "（" + method + " 身份域 " + realm.group(1) + "）";
        }
        return summary + "（" + method + " 身份）";
    }
}
