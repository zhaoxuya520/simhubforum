package cc.forserein.simhub.internal;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static cc.forserein.simhub.internal.SipInviteFailure.call;
import static cc.forserein.simhub.internal.SipInviteFailure.field;
import static cc.forserein.simhub.internal.SipInviteFailure.first;
import static cc.forserein.simhub.internal.SipInviteFailure.headers;
import static cc.forserein.simhub.internal.SipInviteFailure.parameter;
import static cc.forserein.simhub.internal.SipInviteFailure.topVia;

/** Keep an early PRACK/SDP UPDATE transaction alive across native TCP-to-UDP fallback. */
public final class SipEarlyTransactionTransport {
    private static final String TCP = "SIP/2.0/TCP";
    private static final String UDP = "SIP/2.0/UDP";
    private static final int LIMIT = 64;
    private SipEarlyTransactionTransport() {}

    private static boolean same(Object a, Object b) { return a != null && a.equals(b); }
    private static boolean present(String value) { return value != null && !value.isEmpty(); }
    private static String branch(Object message) throws Exception {
        return parameter(message, topVia(message), "branch");
    }
    private static String tag(Object message, String full, String compact) throws Exception {
        return parameter(message, first(message, full, compact), "tag");
    }
    private static boolean finite(double value) { return !Double.isInfinite(value) && !Double.isNaN(value); }

    private static boolean early(Object manager, Object dialog) throws Exception {
        if (manager == null || dialog == null || field(dialog, "D") != null || Boolean.TRUE.equals(field(dialog, "x"))) return false;
        if (((Map<?, ?>) field(manager, "e")).get(field(dialog, "b")) != dialog) return false;
        Object direction = field(dialog, "a"), state = field(dialog, "c");
        if (direction != direction.getClass().getField("U").get(null)) return false;
        Class<?> states = state.getClass();
        return state == states.getField("T").get(null) || state == states.getField("U").get(null)
                || state == states.getField("V").get(null);
    }

    private static boolean method(Object request) throws Exception {
        if (request == null || !Boolean.TRUE.equals(field(request, "a"))) return false;
        Object method = field(request, "b");
        return "PRACK".equals(method) || "UPDATE".equals(method);
    }

    /** Native cb4.p is reached immediately after the early request has been constructed. */
    private static boolean belongs(Object request, Object dialog) throws Exception {
        if (!method(request)) return false;
        Object invite = field(dialog, "j"), seq = call(request, "e", new Class<?>[0]);
        if (invite == null || !Boolean.TRUE.equals(field(invite, "a")) || !"INVITE".equals(field(invite, "b")) || seq == null) return false;
        Object originalSeq = call(invite, "e", new Class<?>[0]);
        int original = (Integer) field(dialog, "i"), number = (Integer) field(seq, "a");
        if (originalSeq == null || !"INVITE".equals(field(originalSeq, "b"))
                || original != (Integer) field(originalSeq, "a") || number <= original
                || number > (Integer) field(dialog, "h") || !same(field(seq, "b"), field(request, "b"))) return false;
        String id = first(request, "Call-ID", "i"), local = tag(request, "From", "f"), remote = tag(request, "To", "t");
        if (!same(id, field(dialog, "b")) || !same(id, first(invite, "Call-ID", "i"))
                || !present(local) || !same(local, field(dialog, "d")) || !same(local, tag(invite, "From", "f"))
                || !present(remote) || !same(remote, field(dialog, "l")) || !same(field(request, "c"), field(dialog, "g"))) return false;
        if (!headers(request, "Route", null).equals(field(dialog, "m"))) return false;
        if ("PRACK".equals(field(request, "b"))) {
            List<String> racks = headers(request, "RAck", null);
            if (racks.size() != 1) return false;
            String[] rack = racks.get(0).trim().split("\\s+");
            if (rack.length != 3 || !"INVITE".equals(rack[2])) return false;
            long rseq = Long.parseLong(rack[0]), inviteSeq = Long.parseLong(rack[1]);
            Object received = ((Map<?, ?>) field(dialog, "v")).get(remote);
            return rseq > 0 && rseq <= Integer.MAX_VALUE && inviteSeq == original
                    && received instanceof Integer && rseq == ((Integer) received).intValue();
        }
        String type = first(request, "Content-Type", "c");
        byte[] body = (byte[]) field(request, "g");
        return Boolean.TRUE.equals(field(dialog, "q")) && Boolean.TRUE.equals(field(dialog, "y"))
                && type != null && "application/sdp".equalsIgnoreCase(type.split(";", 2)[0].trim())
                && body != null && body.length > 0 && Arrays.equals(body, (byte[]) field(dialog, "o"));
    }

    /** Record native Timer F only: TCP never acquires a retransmit interval here. */
    public static void rememberTcp(Object manager, Object request, Object dialog, double now) {
        try {
            if (!finite(now) || !early(manager, dialog) || !Boolean.TRUE.equals(field(field(manager, "a"), "j"))
                    || !belongs(request, dialog)) return;
            String via = topVia(request), branch = branch(request);
            if (via == null || !via.startsWith(TCP + " ") || !present(branch)) return;
            @SuppressWarnings("unchecked") List<Object> timers = (List<Object>) field(dialog, "F");
            if (timers.size() >= LIMIT) return;
            for (Object timer : timers) {
                Object existing = field(timer, "a");
                if (existing == request || same(branch, branch(existing))) return;
            }
            ClassLoader loader = request.getClass().getClassLoader();
            Class<?> kind = Class.forName("ja4", false, loader);
            Object transaction = kind.getConstructor(String.class).newInstance(branch);
            Object timer = Class.forName("ka4", false, loader).getConstructor(request.getClass(),
                    Class.forName("oc2", false, loader), double.class, double.class, double.class,
                    Class.forName("hc2", false, loader)).newInstance(request, null,
                    Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, now + 32.0, transaction);
            timers.add(timer);
        } catch (Exception ignored) {
            // Optional tracking must not suppress the native request or alter its existing UDP path.
        }
    }

    private static boolean sameQueuedRequest(Object original, Object queued) throws Exception {
        if (!method(original) || !same(field(original, "b"), field(queued, "b"))) return false;
        String via = topVia(original), rewritten = topVia(queued);
        if (via == null || !via.startsWith(TCP + " ") || !same(via.replace(TCP, UDP), rewritten)) return false;
        for (String[] name : new String[][]{{"Call-ID", "i"}, {"From", "f"}, {"To", "t"}, {"CSeq", null}})
            if (!same(first(original, name[0], name[1]), first(queued, name[0], name[1]))) return false;
        return same(field(original, "c"), field(queued, "c"))
                && headers(original, "Route", null).equals(headers(queued, "Route", null))
                && headers(original, "RAck", null).equals(headers(queued, "RAck", null))
                && Arrays.equals((byte[]) field(original, "g"), (byte[]) field(queued, "g"));
    }

    /** Called after native C has accepted the rewritten queued request; never create/revive a timer. */
    public static void onFallbackSent(Object engine, Object queued) {
        try {
            if (engine == null || !method(queued) || !Boolean.TRUE.equals(field(engine, "W"))) return;
            String via = topVia(queued);
            if (via == null || !via.startsWith(UDP + " ")) return;
            Object manager = field(engine, "J");
            if (manager == null) return;
            Object dialog = ((Map<?, ?>) field(manager, "e")).get(first(queued, "Call-ID", "i"));
            if (!early(manager, dialog)) return;
            double now = (Double) engine.getClass().getMethod("p").invoke(null);
            for (Object timer : (List<?>) field(dialog, "F")) {
                Object original = field(timer, "a"), kind = field(timer, "f");
                if (field(timer, "b") != null || kind == null || !"ja4".equals(kind.getClass().getName())
                        || !same(branch(queued), field(kind, "n")) || !sameQueuedRequest(original, queued)) continue;
                double interval = (Double) field(timer, "c"), next = (Double) field(timer, "d");
                double deadline = (Double) field(timer, "e");
                if (interval != Double.POSITIVE_INFINITY || next != Double.POSITIVE_INFINITY
                        || !finite(deadline) || deadline <= now) return;
                call(original, "i", new Class<?>[]{String.class, String.class}, "Via", via);
                timer.getClass().getField("c").setDouble(timer, 0.5);
                timer.getClass().getField("d").setDouble(timer, now + 0.5);
                return;
            }
        } catch (Exception ignored) {
            // No new send, timer or deadline is introduced when correlation is uncertain.
        }
    }
}
