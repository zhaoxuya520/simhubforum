package cc.forserein.simhub.internal;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.Telephony;

/** One explicit draft handoff. Only the receiving app can select the final SIM and delivery mode. */
public final class RcsSystemComposer {
    private static final String NO_SUB = "无法核对当前卡对应的系统 SIM";
    private static final String NO_APP = "默认短信应用未提供草稿入口";
    private static final String CHANGED = "卡片或默认短信应用已切换，请重新打开会话";
    private static final class DraftUnavailable extends IllegalStateException {
        private static final long serialVersionUID = 1L;
        DraftUnavailable(String reason) { super(reason); }
    }

    /** Only our local descriptions may be shown. Platform exceptions can contain private data. */
    static String unavailableReason(Throwable failure) {
        return failure instanceof DraftUnavailable ? failure.getMessage() : "无法打开系统短信草稿";
    }

    private static String checkedPeer(String address) {
        try {
            return RcsChatBinding.peerNumber(address);
        } catch (IllegalArgumentException invalid) {
            throw new DraftUnavailable("请先填写完整的国际号码");
        }
    }

    private static String selectedCard(Object state) throws ReflectiveOperationException {
        try {
            return RcsChatBinding.selectedIccid(state);
        } catch (IllegalStateException invalid) {
            throw new DraftUnavailable(NO_SUB);
        }
    }

    public final String appLabel;
    private final Object reader;
    private final String iccid;
    private final RcsSystemLine.DraftLine subscription;
    private final String peer;
    private final ComponentName component;
    private final int uid;

    private RcsSystemComposer(Object reader, String iccid, RcsSystemLine.DraftLine subscription, String peer,
            ActivityInfo target, PackageManager packages) {
        this.reader = reader;
        this.iccid = iccid;
        this.subscription = subscription;
        this.peer = peer;
        component = new ComponentName(target.packageName, target.name);
        uid = target.applicationInfo.uid;
        CharSequence name = target.applicationInfo.loadLabel(packages);
        String label = name == null ? "" : name.toString().replaceAll("[\\p{Cc}\\p{Cf}\\p{Zl}\\p{Zp}]", "").trim();
        appLabel = label.isEmpty() || label.length() > 80 ? target.packageName : label;
    }

    /** May run off the main thread. Looks up recipient and current target without sharing the body. */
    public static RcsSystemComposer capture(Context context, Object state, String address) {
        String peer = checkedPeer(address);
        try {
            String iccid = selectedCard(state);
            Object reader = RcsChatBinding.localReader();
            if (reader == null) throw new DraftUnavailable(NO_SUB);
            RcsSystemLine.DraftLine line = RcsSystemLine.draftLine(context, iccid, reader, false);
            if (line == null) throw new DraftUnavailable(NO_SUB);
            ActivityInfo info = target(context, peer);
            RcsSystemComposer result = new RcsSystemComposer(reader, iccid, line, peer, info, context.getPackageManager());
            result.checkCard(context, state, address);
            return result;
        } catch (ReflectiveOperationException unavailable) {
            throw new DraftUnavailable(NO_SUB);
        }
    }

    /** User-initiated only. Retains the original draft, never sends and never invokes a package chooser. */
    public void open(Activity activity, Object state, String address, String body) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) {
            throw new DraftUnavailable("页面已关闭，请重新打开短信");
        }
        try {
            checkCard(activity, state, address);
            ActivityInfo target = target(activity, peer);
            if (uid != target.applicationInfo.uid || !component.equals(new ComponentName(target.packageName, target.name))) {
                throw new DraftUnavailable(CHANGED);
            }
            Intent draft = draftIntent(peer).setComponent(component);
            if (body != null && !body.isEmpty()) draft.putExtra("sms_body", body);
            checkCard(activity, state, address);
            if (!component.getPackageName().equals(defaultPackage(activity))) throw new DraftUnavailable(CHANGED);
            try {
                activity.startActivity(draft);
            } catch (RuntimeException unavailable) {
                throw new DraftUnavailable(NO_APP);
            }
        } catch (ReflectiveOperationException unavailable) {
            throw new DraftUnavailable(CHANGED);
        }
    }

    private void checkCard(Context context, Object state, String address) throws ReflectiveOperationException {
        if (!peer.equals(checkedPeer(address))
                || reader != RcsChatBinding.localReader() || !iccid.equals(selectedCard(state))
                || !subscription.stillMatches(RcsSystemLine.draftLine(context, iccid, reader, subscription.slot >= 0))
                || reader != RcsChatBinding.localReader() || !iccid.equals(selectedCard(state))) {
            throw new DraftUnavailable(CHANGED);
        }
    }

    private static Intent draftIntent(String peer) {
        return new Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", peer, null));
    }

    private static String defaultPackage(Context context) {
        try {
            return Telephony.Sms.getDefaultSmsPackage(context);
        } catch (RuntimeException unavailable) {
            throw new DraftUnavailable(NO_APP);
        }
    }

    private static ActivityInfo target(Context context, String peer) {
        String pkg = defaultPackage(context);
        if (pkg == null || pkg.isEmpty() || pkg.equals(context.getPackageName())) throw new DraftUnavailable(NO_APP);
        try {
            ResolveInfo resolved = context.getPackageManager().resolveActivity(draftIntent(peer).setPackage(pkg), PackageManager.MATCH_DEFAULT_ONLY);
            ActivityInfo info = resolved == null ? null : resolved.activityInfo;
            ApplicationInfo app = info == null ? null : info.applicationInfo;
            if (app != null && info.enabled && app.enabled && info.exported
                    && pkg.equals(info.packageName) && pkg.equals(app.packageName) && info.name != null && !info.name.isEmpty()
                    && (info.permission == null || context.checkSelfPermission(info.permission) == PackageManager.PERMISSION_GRANTED)) {
                return info;
            }
        } catch (SecurityException unavailable) {
            throw new DraftUnavailable(NO_APP);
        }
        throw new DraftUnavailable(NO_APP);
    }
}
