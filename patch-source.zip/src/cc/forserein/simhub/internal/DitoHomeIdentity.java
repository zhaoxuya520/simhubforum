package cc.forserein.simhub.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import java.util.Locale;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/** Same-card home identity memory, following the verified SIMHub 29.3 DITO flow. */
public final class DitoHomeIdentity {
    private DitoHomeIdentity() {}
    private static final String PREFS="wifi_calling_dito_identity_v1";
    private static final String PROVIDERS="wifi_calling_dito_provider_v1";
    // Native ek5 has value equality. Transient evidence belongs to this exact read object,
    // not to another equal read, and must not retain it after the session releases it.
    private static final ArrayList<WeakReference<Object>> currentProviders=new ArrayList<WeakReference<Object>>();
    // The reference recovery code names one batch (8963662600). Classification must
    // also cover the DITO IIN already supplied by the user, without inventing an IMSI.
    private static final String ISSUER="896366";
    private static final String MNC_MISMATCH="当前 DITO 身份以 51566 开头，但卡片报告的 MNC 长度不是 2，无法确认正确归属身份。请重新读取卡片；不会用历史记录覆盖本次 IMSI。";

    private static String text(Object card,String field)throws ReflectiveOperationException {
        Object value=WifiConfigModel.get(card,field);return value==null?"":value.toString();
    }
    private static boolean imsi(String value,String prefix){return value.matches("[0-9]{14,15}")&&value.startsWith(prefix);}
    private static boolean iccid(String value){return value.matches("[0-9]{19,20}");}
    private static boolean home(Object card)throws ReflectiveOperationException {
        return imsi(text(card,"a"),"51566")&&Integer.valueOf(2).equals(WifiConfigModel.get(card,"c"));
    }
    public static boolean isDito(Object card)throws ReflectiveOperationException {
        if(card==null||!imsi(text(card,"a"),""))return false;
        if(home(card))return true; // Current home identity does not require an ICCID to identify its PLMN.
        if(!iccid(text(card,"b")))return false;
        if(text(card,"b").startsWith(ISSUER)||currentProvider(card))return true;
        Context context=(Context)Class.forName("zl5").getField("f").get(null);
        return context!=null&&(saved(card)!=null||provider(card)!=null);
    }
    private static String canonicalProvider(String value){
        if(value==null)return null;
        String name=value.trim().replaceAll("\\s+"," ").toUpperCase(Locale.ROOT);
        return name.equals("DITO")||name.equals("DITO TELECOMMUNITY")||name.equals("DITO TELECOMMUNITY CORPORATION")?name:null;
    }
    private static boolean currentProvider(Object card){
        synchronized(currentProviders){
            boolean found=false;
            for(int i=currentProviders.size()-1;i>=0;i--){
                Object current=currentProviders.get(i).get();
                if(current==null)currentProviders.remove(i);else if(current==card)found=true;
            }
            return found;
        }
    }
    private static String providerKey(String iccid){return WifiConfigValues.digest("vowifi.dito.provider."+iccid);}
    private static String provider(Object card)throws ReflectiveOperationException {
        if(card==null||!iccid(text(card,"b")))return null;
        return canonicalProvider(context().getSharedPreferences(PROVIDERS,Context.MODE_PRIVATE).getString(providerKey(text(card,"b")),null));
    }
    /** Only IdentityBinding may supply a fresh, exact-ICCID-matched service provider name. */
    public static synchronized void observeProvider(Object card,String provider)throws ReflectiveOperationException {
        String name=canonicalProvider(provider);
        if(name==null||card==null||!iccid(text(card,"b"))||!imsi(text(card,"a"),""))return;
        synchronized(currentProviders){if(!currentProvider(card))currentProviders.add(new WeakReference<Object>(card));}
        SharedPreferences preferences=context().getSharedPreferences(PROVIDERS,Context.MODE_PRIVATE);
        String key=providerKey(text(card,"b")),previous=preferences.getString(key,null);
        if(name.equals(previous))return;
        boolean committed=preferences.edit().putString(key,name).commit();
        if(!committed||!name.equals(preferences.getString(key,null))){
            SharedPreferences.Editor rollback=preferences.edit();
            if(previous==null)rollback.remove(key);else rollback.putString(key,previous);rollback.commit();
            throw new IllegalStateException("未能保存 DITO 运营商识别信息，请重新读取卡片。");
        }
    }
    private static Context context()throws ReflectiveOperationException {
        Context context=(Context)Class.forName("zl5").getField("f").get(null);
        if(context==null)throw new IllegalStateException("Wi-Fi 通话尚未初始化");return context;
    }
    private static SharedPreferences prefs()throws ReflectiveOperationException {return context().getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    private static String key(String iccid){return WifiConfigValues.digest("vowifi.dito.home_imsi."+iccid);}
    static String saved(Object card)throws ReflectiveOperationException {
        if(card==null||!iccid(text(card,"b")))return null;
        String value=prefs().getString(key(text(card,"b")),null);
        return value!=null&&imsi(value,"51566")?value:null;
    }
    /** Called only at the actual, generation-checked USIM read boundary. Never learns from overrides. */
    public static synchronized void observe(Object card)throws ReflectiveOperationException {
        if(card==null||!iccid(text(card,"b"))||!home(card))return;
        SharedPreferences preferences=prefs();String key=key(text(card,"b")),value=text(card,"a");
        if(value.equals(preferences.getString(key,null)))return;
        String previous=preferences.getString(key,null);
        boolean committed=preferences.edit().putString(key,value).commit();
        if(!committed||!value.equals(preferences.getString(key,null))){
            SharedPreferences.Editor rollback=preferences.edit();
            if(previous==null)rollback.remove(key);else rollback.putString(key,previous);rollback.commit();
            throw new IllegalStateException("未能保存 DITO 归属身份，请重新读取并确认保存成功后，再改变此卡的联网状态。");
        }
        Log.i("SIMHubIdentity","DITO home identity saved for ICCID="+IdentityBinding.tail(text(card,"b")));
    }
    /** An immutable Wi-Fi-only copy; the original USIM result and its transport are untouched. */
    public static synchronized Object settings(Object card)throws ReflectiveOperationException {
        if(card==null||!validRead(card)||imsi(text(card,"a"),"51566")||!isDito(card))return card;
        String home=saved(card);if(home==null)return card;
        Object[] fields=WifiConfigModel.fields(card,8);fields[0]=home;fields[2]=Integer.valueOf(2);
        return WifiConfigModel.constructor(card.getClass(),8).newInstance(fields);
    }
    private static boolean validRead(Object card)throws ReflectiveOperationException {
        Object length=WifiConfigModel.get(card,"c");
        return imsi(text(card,"a"),"")&&(Integer.valueOf(2).equals(length)||Integer.valueOf(3).equals(length));
    }
    private static Object registrationIdentity(Object card)throws ReflectiveOperationException {
        if(!validRead(card))throw new IllegalStateException("卡片的 IMSI 或 MNC 长度无效，请重新读取卡片。");
        if(home(card))return card;
        if(imsi(text(card,"a"),"51566"))throw new IllegalStateException(MNC_MISMATCH);
        // settings returns the exact physical read when this ICCID has no observed home identity.
        return settings(card);
    }
    /** The native job captures this config, this read and its existing USIM transport together. */
    public static Object connection(Object card,Object config)throws ReflectiveOperationException {
        if(card==null||!DitoCarrierProfile.matches(config))return card;
        return registrationIdentity(card);
    }
    /** Compatibility with callers that resolve the subscriber before a carrier config is available. */
    public static Object connection(Object card)throws ReflectiveOperationException {
        if(card==null)return null;
        String issuer=text(card,"b");
        if((iccid(issuer)&&issuer.startsWith(ISSUER))||isDito(card)||WifiConfigRuntime.isDitoSelected(card))
            return registrationIdentity(card);
        return card;
    }
    private static String plmn(Object card)throws ReflectiveOperationException {
        String value=text(card,"a");Object length=WifiConfigModel.get(card,"c");
        if(!imsi(value,""))return "无效（MNC 长度 "+length+"）";
        if(Integer.valueOf(2).equals(length))return value.substring(0,5)+"（MNC 长度 2）";
        if(Integer.valueOf(3).equals(length))return value.substring(0,6)+"（MNC 长度 3）";
        return "未确认（MNC 长度 "+length+"）";
    }
    /** Describe the identity available to the DITO preset without logging the full IMSI. */
    public static void readStatus(Object card){
        try{
            if(card==null)return;
            String identity=text(card,"b"),prefix="当前 PLMN "+plmn(card);
            boolean identified=isDito(card);
            if(!iccid(identity)){
                Class.forName("zl5").getMethod("b",String.class).invoke(null,(identified?"DITO 归属身份已读取；":"")+prefix+"；ICCID 长度 "+identity.length()+"，卡片归属未核实，不能保存或恢复同卡身份");
                return;
            }
            if(!identified){
                if(imsi(text(card,"a"),"20404"))Class.forName("zl5").getMethod("b",String.class).invoke(null,prefix+"；ICCID 已读取，未找到可核实的 DITO 归属依据，按当前身份匹配运营商");
                return;
            }
            String basis=home(card)?"真实 51566 归属身份":identity.startsWith(ISSUER)?"DITO 发卡机构":saved(card)!=null?"同卡真实归属记录":"同卡服务提供商记录";
            String status=home(card)?"归属身份可用":imsi(text(card,"a"),"51566")?"MNC 长度不一致，保留本次 IMSI，暂不可连接":!validRead(card)?"卡片的 IMSI 或 MNC 长度无效，请重新读取":saved(card)==null?"连接时使用当前卡片身份":"已恢复同卡真实 51566 归属记录";
            Class.forName("zl5").getMethod("b",String.class).invoke(null,"DITO 已识别（"+basis+"）："+prefix+"；"+status);
        }catch(Exception ignored){Log.e("SIMHubIdentity","DITO read status unavailable");}
    }
    /** Extend existing identity hiding to the remembered IMSI as well as the physically read one. */
    public static String mask(Object card,String value){
        if(value==null||card==null)return value;
        try{
            if(!isDito(card))return value;
            String home=saved(card);if(home==null)return value;
            StringBuilder hidden=new StringBuilder(home.substring(0,5));
            for(int i=7;i<home.length();i++)hidden.append('•');hidden.append(home.substring(home.length()-2));
            return value.replace(home,hidden.toString());
        }catch(Exception ignored){return value;}
    }
    public static String maskLog(String value){
        try{return mask(WifiConfigModel.get(WifiConfigRuntime.state(),"e"),value);}
        catch(Exception ignored){return value;}
    }
    /** Storage failure must be visible, while the successful physical SIM read remains usable. */
    public static void readError(Exception error){report(error.getMessage());}
    public static void connectionError(Throwable error){
        report(error instanceof IllegalStateException?error.getMessage():"DITO 归属身份载入失败，请重新读取卡片后重试");
        try{Class.forName("zl5").getMethod("x",boolean.class).invoke(null,false);}
        catch(Exception ignored){Log.e("SIMHubIdentity","Could not stop failed Wi-Fi connection");}
    }
    private static void report(String message){
        final String text=message==null?"DITO 归属身份保存失败，请重新读取":message;
        Log.e("SIMHubIdentity",text);
        try{
            Class.forName("zl5").getMethod("b",String.class).invoke(null,text);
        }catch(Exception ignored){}
        try{
            final Context app=context();
            new Handler(Looper.getMainLooper()).post(new Runnable(){public void run(){Toast.makeText(app,text,Toast.LENGTH_LONG).show();}});
        }catch(Exception ignored){}
    }
}
