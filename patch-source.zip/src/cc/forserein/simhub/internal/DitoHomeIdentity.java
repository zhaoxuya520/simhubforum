package cc.forserein.simhub.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

/** Same-card home identity memory, following the verified SIMHub 29.3 DITO flow. */
public final class DitoHomeIdentity {
    private DitoHomeIdentity() {}
    private static final String PREFS="wifi_calling_dito_identity_v1";
    // The reference recovery code names one batch (8963662600). Classification must
    // also cover the DITO IIN already supplied by the user, without inventing an IMSI.
    private static final String ISSUER="896366";
    private static final String REQUIRED="这张 DITO 卡目前使用 20404 漫游身份，尚未保存同卡真实的 51566 归属身份。请在此卡实际处于 51566 时读取一次，再使用 Wi-Fi 通话；不能从漫游 IMSI 推算。";

    private static String text(Object card,String field)throws ReflectiveOperationException {
        Object value=WifiConfigModel.get(card,field);return value==null?"":value.toString();
    }
    private static boolean imsi(String value,String prefix){return value.matches("[0-9]{14,15}")&&value.startsWith(prefix);}
    private static boolean iccid(String value){return value.matches("[0-9]{19,20}");}
    private static boolean home(Object card)throws ReflectiveOperationException {
        return imsi(text(card,"a"),"51566")&&Integer.valueOf(2).equals(WifiConfigModel.get(card,"c"));
    }
    public static boolean isDito(Object card)throws ReflectiveOperationException {
        if(card==null||!iccid(text(card,"b")))return false;
        if(home(card))return true; // A real 51566 read is stronger evidence than an ICCID batch.
        if(!imsi(text(card,"a"),"20404"))return false;
        if(text(card,"b").startsWith(ISSUER))return true;
        Context context=(Context)Class.forName("zl5").getField("f").get(null);
        return context!=null&&saved(card)!=null;
    }
    private static Context context()throws ReflectiveOperationException {
        Context context=(Context)Class.forName("zl5").getField("f").get(null);
        if(context==null)throw new IllegalStateException("Wi-Fi 通话尚未初始化");return context;
    }
    private static SharedPreferences prefs()throws ReflectiveOperationException {return context().getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    private static String key(String iccid){return WifiConfigValues.digest("vowifi.dito.home_imsi."+iccid);}
    static String saved(Object card)throws ReflectiveOperationException {
        if(card==null||!iccid(text(card,"b")))return null;
        String value=prefs().getString(key(text(card,"b")),null);
        return value!=null&&imsi(value,"51566")?value:null;
    }
    /** Called only at the actual, generation-checked USIM read boundary. Never learns from overrides. */
    public static synchronized void observe(Object card)throws ReflectiveOperationException {
        if(card==null||!iccid(text(card,"b"))||!home(card))return;
        SharedPreferences preferences=prefs();String key=key(text(card,"b")),value=text(card,"a");
        if(value.equals(preferences.getString(key,null)))return;
        String previous=preferences.getString(key,null);
        boolean committed=preferences.edit().putString(key,value).commit();
        if(!committed||!value.equals(preferences.getString(key,null))){
            SharedPreferences.Editor rollback=preferences.edit();
            if(previous==null)rollback.remove(key);else rollback.putString(key,previous);rollback.commit();
            throw new IllegalStateException("未能保存 DITO 归属身份，请重新读取并确认保存成功后，再改变此卡的联网状态。");
        }
        Log.i("SIMHubIdentity","DITO home identity saved for ICCID="+IdentityBinding.tail(text(card,"b")));
    }
    /** An immutable Wi-Fi-only copy; the original USIM result and its transport are untouched. */
    public static synchronized Object settings(Object card)throws ReflectiveOperationException {
        if(!isDito(card)||!imsi(text(card,"a"),"20404"))return card;
        String home=saved(card);if(home==null)return card;
        Object[] fields=WifiConfigModel.fields(card,8);fields[0]=home;fields[2]=Integer.valueOf(2);
        return WifiConfigModel.constructor(card.getClass(),8).newInstance(fields);
    }
    /** Used before scheduling the native connection, so IKE/AKA and IMS see the same home IMSI. */
    public static Object connection(Object card)throws ReflectiveOperationException {
        Object effective=settings(card);
        if(imsi(text(card,"a"),"20404")&&effective==card&&(isDito(card)||WifiConfigRuntime.isDitoSelected(card)))throw new IllegalStateException(REQUIRED);
        return effective;
    }
    /** Existing connection log only: classification and missing credentials are separate states. */
    public static void readStatus(Object card){
        try{
            if(!isDito(card))return;
            String status=imsi(text(card,"a"),"51566")?"51566 归属身份已读取":
                saved(card)==null?"20404 漫游身份，尚无同卡 51566 归属记录":"20404 漫游身份，已恢复同卡 51566 归属记录";
            Class.forName("zl5").getMethod("b",String.class).invoke(null,"DITO 已识别："+status);
        }catch(Exception ignored){Log.e("SIMHubIdentity","DITO read status unavailable");}
    }
    /** Extend existing identity hiding to the remembered IMSI as well as the physically read one. */
    public static String mask(Object card,String value){
        if(value==null||card==null)return value;
        try{
            if(!isDito(card))return value;
            String home=saved(card);if(home==null)return value;
            StringBuilder hidden=new StringBuilder(home.substring(0,5));
            for(int i=7;i<home.length();i++)hidden.append('•');hidden.append(home.substring(home.length()-2));
            return value.replace(home,hidden.toString());
        }catch(Exception ignored){return value;}
    }
    public static String maskLog(String value){
        try{return mask(WifiConfigModel.get(WifiConfigRuntime.state(),"e"),value);}
        catch(Exception ignored){return value;}
    }
    /** Storage failure must be visible, while the successful physical SIM read remains usable. */
    public static void readError(Exception error){report(error.getMessage());}
    public static void connectionError(Throwable error){
        report(error instanceof IllegalStateException?error.getMessage():"DITO 归属身份载入失败，请重新读取卡片后重试");
        try{Class.forName("zl5").getMethod("x",boolean.class).invoke(null,false);}
        catch(Exception ignored){Log.e("SIMHubIdentity","Could not stop failed Wi-Fi connection");}
    }
    private static void report(String message){
        final String text=message==null?"DITO 归属身份保存失败，请重新读取":message;
        Log.e("SIMHubIdentity",text);
        try{
            Class.forName("zl5").getMethod("b",String.class).invoke(null,text);
        }catch(Exception ignored){}
        try{
            final Context app=context();
            new Handler(Looper.getMainLooper()).post(new Runnable(){public void run(){Toast.makeText(app,text,Toast.LENGTH_LONG).show();}});
        }catch(Exception ignored){}
    }
}
