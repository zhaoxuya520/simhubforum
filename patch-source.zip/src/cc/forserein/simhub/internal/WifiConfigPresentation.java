package cc.forserein.simhub.internal;

import java.util.*;

/** One interpretation of saved, draft and automatic values for all editor fields. */
public final class WifiConfigPresentation {
    private WifiConfigPresentation(){}
    public static boolean builtin(String value){return value==null || value.trim().isEmpty();}
    public static String defaultText(String key,Map<String,String> defaults){
        String value=defaults.get(key);
        if(!builtin(value))return value;
        if(key.equals("eap") || key.equals("nai") || key.equals("impi") || key.equals("impu"))return "自动生成（使用当前卡身份）";
        if(key.equals("smsc"))return "从当前卡读取";
        return "未设置";
    }
    public static String effective(String key,String override,Map<String,String> defaults){
        if(builtin(override))return defaultText(key,defaults);
        try{return WifiConfigValues.validate(Collections.singletonMap(key,override)).get(key);}
        catch(WifiConfigValues.Invalid e){return "输入无效，无法保存："+e.getMessage();}
    }
    public static String source(String value){return builtin(value)?"内置 / 自动":"自定义";}
}
