package cc.forserein.simhub.internal;

import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.CancellationException;

/** Coordinates only the two explicitly discovered eSTK SEs on one reader. */
public final class EstkSwitchPlan {
    private static final byte[] SE0 = hex("A06573746B6D65FFFF4953442D522030");
    private static final byte[] SE1 = hex("A06573746B6D65FFFF4953442D522031");
    private static final Map<Object,EstkSwitchPlan> ACTIVE = new IdentityHashMap<>();
    private final Object owner, backend, transport;
    private final List<Chip> chips;
    private final Chip target;
    private final String targetIccid;
    private final boolean enable, phoneSlot;
    private final Map<String,List<?>> observed = new LinkedHashMap<>();
    private final List<Change> disabling = new ArrayList<>();
    private static final int SCAN_INITIAL=0, DISABLE_SIBLING=1, RECHECK_TARGET=2,
            PREPARE_FINAL_SCAN=3, SCAN_FINAL=4, CHANGE_TARGET=5;
    private int phase=SCAN_INITIAL, scan, disableIndex, attempts;
    private Change confirmation;
    private boolean confirmingEnabled, oldDisabled, targetConfirmed, closed;
    public int kind; // 0 done, 1 read, 2 enable, 3 disable, 4 wait then read
    public byte[] aid;
    public String eid, iccid;
    public long delayMs;

    public static final class BoundaryFailure extends IllegalStateException {
        private static final long serialVersionUID=1L;
        public BoundaryFailure(String message){super(message);}
        public BoundaryFailure(String message,Throwable cause){super(message,cause);}
    }
    public static final class IoResult {
        public final int result;
        public final List<?> profiles;
        public final String eid;
        public IoResult(int result,List<?> profiles,String eid) {
            this.result=result;this.profiles=profiles==null?null:new ArrayList<Object>(profiles);this.eid=eid;
        }
    }
    private static final class Chip {
        final byte[] aid;final String eid;
        Chip(byte[] aid,String eid){this.aid=aid.clone();this.eid=eid;}
    }
    private static final class Change {
        final Chip chip;final String iccid;
        Change(Chip chip,String iccid){this.chip=chip;this.iccid=iccid;}
    }
    private EstkSwitchPlan(Object owner,Object backend,Object transport,List<Chip> chips,Chip target,String iccid,boolean enable)throws Exception {
        this.owner=owner;this.backend=backend;this.transport=transport;this.chips=chips;this.target=target;
        this.targetIccid=iccid;this.enable=enable;this.phoneSlot=Class.forName("s4").isInstance(transport);
    }
    public static EstkSwitchPlan tryCreate(Object owner,Object backend,Object profile,boolean enable)throws Exception {
        if(owner==null||backend==null||profile==null)return null;
        List<?> rows=(List<?>)call(owner,"l");
        if(rows.size()!=2)return null;
        Object first=rows.get(0),second=rows.get(1);
        byte[] a=(byte[])get(first,"a"),b=(byte[])get(second,"a");
        if(!((Arrays.equals(a,SE0)&&Arrays.equals(b,SE1))||(Arrays.equals(a,SE1)&&Arrays.equals(b,SE0))))return null;
        Object transport=get(backend,"a");
        if(get(owner,"d")!=backend||call(owner,"s")!=transport)throw new BoundaryFailure("读卡器连接已改变，请重新读取配置");
        List<Chip> chips=new ArrayList<>();Chip target=null;
        String wanted=(String)get(profile,"a");
        if(!validIccid(wanted))throw new BoundaryFailure("配置标识无效，请刷新后重试");
        Set<String> ids=new HashSet<>();
        for(Object row:rows){
            String eid=(String)get(row,"b");
            if(eid==null||!eid.matches("[0-9]{32}")||!ids.add(eid))throw new BoundaryFailure("芯片标识未确认，请重新读取配置");
            Chip chip=new Chip((byte[])get(row,"a"),eid);chips.add(chip);
            for(Object candidate:(List<?>)get(row,"d"))if(wanted.equals(get(candidate,"a"))){
                if(target!=null)throw new BoundaryFailure("配置标识重复，无法确定目标芯片");
                target=chip;
            }
        }
        if(target==null)throw new BoundaryFailure("目标配置已变化，请刷新后重试");
        EstkSwitchPlan plan=new EstkSwitchPlan(owner,backend,transport,chips,target,wanted,enable);
        synchronized(ACTIVE){
            if(ACTIVE.containsKey(backend))throw new BoundaryFailure("读卡器正在切换配置");
            ACTIVE.put(backend,plan);
        }
        return plan;
    }
    public static void verifyEid(String expected,String actual){
        if(expected==null||!expected.equals(actual))throw new BoundaryFailure("读回芯片与操作目标不一致，已停止切卡");
    }
    public static void checkActive(Object backend,String expectedEid)throws Exception {
        EstkSwitchPlan plan;
        synchronized(ACTIVE){plan=ACTIVE.get(backend);}
        if(plan==null||plan.closed||!Objects.equals(plan.eid,expectedEid))throw new BoundaryFailure("切卡操作已失效");
        plan.connected();
    }
    private static byte[] hex(String value){byte[] result=new byte[value.length()/2];for(int i=0;i<result.length;i++)result[i]=(byte)Integer.parseInt(value.substring(i*2,i*2+2),16);return result;}
    // SGP.22 ICCIDs contain 19/20 digits; the native profile decoder already
    // strips trailing BCD filler. Inactive unrelated entries are not rejected.
    private static boolean validIccid(String value){return value!=null&&value.matches("[0-9]{19,20}");}
    private static Object get(Object object,String field)throws Exception{return object.getClass().getField(field).get(object);}
    private static Object call(Object object,String method)throws Exception{return call(object,method,new Class<?>[0]);}
    private static Object call(Object object,String method,Class<?>[] types,Object...args)throws Exception{
        try{return object.getClass().getMethod(method,types).invoke(object,args);}
        catch(InvocationTargetException failure){Throwable cause=failure.getCause();if(cause instanceof Exception)throw(Exception)cause;throw(Error)cause;}
    }
    private void connected()throws Exception {
        if(closed||get(owner,"d")!=backend||call(owner,"s")!=transport)throw new BoundaryFailure("读卡器连接已改变，已停止切卡");
        List<?> current=(List<?>)call(owner,"l");
        if(current.size()!=2)throw new BoundaryFailure("芯片列表已变化，已停止切卡");
        for(Chip chip:chips){int found=0;for(Object row:current)if(chip.eid.equals(get(row,"b"))&&Arrays.equals(chip.aid,(byte[])get(row,"a")))found++;
            if(found!=1)throw new BoundaryFailure("芯片列表已变化，已停止切卡");}
    }
    private Chip chip(String wanted){for(Chip chip:chips)if(chip.eid.equals(wanted))return chip;throw new BoundaryFailure("未知芯片读取结果");}
    private Object find(Chip chip,String wanted)throws Exception {
        List<?> list=observed.get(chip.eid);Object found=null;
        if(list!=null)for(Object profile:list)if(wanted.equals(get(profile,"a"))){if(found!=null)throw new BoundaryFailure("芯片配置标识重复");found=profile;}
        if(found==null)throw new BoundaryFailure("目标配置已不存在，请刷新后重试");return found;
    }
    private boolean active(Chip chip,String wanted)throws Exception{return Boolean.TRUE.equals(get(find(chip,wanted),"b"));}
    private void observe(IoResult result)throws Exception {
        verifyEid(eid,result.eid);if(result.profiles==null)return;
        List<?> list=new ArrayList<Object>(result.profiles);observed.put(eid,list);publish(chip(eid),list);
        int enabled=0;for(Object profile:list)if(Boolean.TRUE.equals(get(profile,"b"))){
            enabled++;if(!validIccid((String)get(profile,"a")))throw new BoundaryFailure("启用配置的标识无效，已停止切卡");
        }
        if(enabled>1)throw new BoundaryFailure("同一芯片存在多个启用配置，无法确认端口归属，已停止切卡");
    }
    /** Update the captured EID's row, never the tab currently selected by the UI. */
    private void publish(Chip chip,List<?> profiles)throws Exception {
        connected();List<?> current=(List<?>)call(owner,"l");List<Object> updated=new ArrayList<Object>(current);
        for(int i=0;i<current.size();i++){
            Object row=current.get(i);
            if(!chip.eid.equals(get(row,"b"))||!Arrays.equals(chip.aid,(byte[])get(row,"a")))continue;
            Object[] fields=WifiConfigModel.fields(row,6);fields[3]=profiles;
            updated.set(i,WifiConfigModel.constructor(row.getClass(),6).newInstance(fields));
            connected();call(get(owner,"k"),"setValue",new Class<?>[]{Object.class},updated);
            if(chip.eid.equals(call(owner,"r")))call(owner,"J",new Class<?>[]{List.class},profiles);
            return;
        }
        throw new BoundaryFailure("芯片列表已变化，未覆盖其他芯片状态");
    }
    private void emit(int action,Chip chip,String profile)throws Exception {
        connected();kind=action;aid=chip.aid.clone();eid=chip.eid;iccid=profile;
    }
    private void waitForConfirmation()throws Exception {
        emit(4,confirmation.chip,confirmation.iccid);
        delayMs=phoneSlot?(attempts==0?3000L:1000L):500L;
    }
    private int limit(){return phoneSlot?30:2;}
    private void confirmed()throws Exception {
        if(confirmation.chip!=target&&!confirmingEnabled)oldDisabled=true;
        if(confirmation.chip==target&&confirmingEnabled)targetConfirmed=true;
        confirmation=null;attempts=0;
    }
    /** Called after a suspended native read/write/wait completes. */
    public void next(Object result)throws Exception {
        connected();int completed=kind;
        if(completed==4){emit(1,confirmation.chip,confirmation.iccid);return;}
        if(completed!=0){
            if(!(result instanceof IoResult))throw new BoundaryFailure("切卡返回结果不完整");
            IoResult read=(IoResult)result;observe(read);
            if(completed==2||completed==3){
                if(read.result!=0&&read.result!=2)throw new BoundaryFailure("配置变更未被确认");
                Object notifications=get(backend,"h");backend.getClass().getField("h").set(backend,null);
                if(notifications instanceof List&&eid.equals(call(owner,"r")))call(owner,"H",new Class<?>[]{List.class},notifications);
            }
            if(confirmation!=null){
                if(read.profiles!=null&&active(confirmation.chip,confirmation.iccid)==confirmingEnabled)confirmed();
                else{if(completed==1)attempts++;if(attempts>=limit())throw new BoundaryFailure("配置变更已请求，但尚未确认目标芯片状态，请刷新后重试");waitForConfirmation();return;}
            }
        }
        if(phase==SCAN_INITIAL){
            int needed=enable?chips.size():1;
            if(scan<needed){Chip read=enable?chips.get(scan++):target; if(!enable)scan++;emit(1,read,null);return;}
            find(target,targetIccid);
            if(enable)for(Chip chip:chips)if(chip!=target)for(Object profile:observed.get(chip.eid))if(Boolean.TRUE.equals(get(profile,"b")))disabling.add(new Change(chip,(String)get(profile,"a")));
            phase=DISABLE_SIBLING;
        }
        if(phase==DISABLE_SIBLING){
            if(disableIndex<disabling.size()){
                confirmation=disabling.get(disableIndex++);confirmingEnabled=false;attempts=0;
                emit(3,confirmation.chip,confirmation.iccid);return;
            }
            phase=RECHECK_TARGET;
        }
        if(phase==RECHECK_TARGET){
            phase=CHANGE_TARGET;
            if(enable&&!disabling.isEmpty()){emit(1,target,null);return;}
        }
        if(phase==CHANGE_TARGET){
            phase=PREPARE_FINAL_SCAN;
            if(active(target,targetIccid)!=enable){
                confirmation=new Change(target,targetIccid);confirmingEnabled=enable;attempts=0;
                emit(enable?2:3,target,targetIccid);return;
            }
            targetConfirmed=enable;
        }
        if(phase==PREPARE_FINAL_SCAN){phase=SCAN_FINAL;scan=0;}
        if(enable&&scan<chips.size()){emit(1,chips.get(scan++),null);return;}
        if(active(target,targetIccid)!=enable)throw new BoundaryFailure("目标配置状态尚未确认，请刷新后重试");
        if(enable)for(Chip chip:chips)if(chip!=target)for(Object profile:observed.get(chip.eid))if(Boolean.TRUE.equals(get(profile,"b")))throw new BoundaryFailure("另一芯片仍有启用配置，请刷新确认");
        kind=0;close();
    }
    /** Retry only confirmation reads. Never retry an enable/disable write. */
    public boolean retryRead(Throwable failure){
        if(!(failure instanceof Exception)||failure instanceof CancellationException||failure instanceof BoundaryFailure||confirmation==null||kind!=1)return false;
        try{connected();attempts++;if(attempts>=limit())return false;waitForConfirmation();return true;}catch(Exception ignored){return false;}
    }
    public Throwable failure(Throwable original){
        close();
        if(!(original instanceof CancellationException)&&oldDisabled&&enable&&!targetConfirmed)
            return new BoundaryFailure("旧芯片已关闭，目标配置状态未完成确认："+(original.getMessage()==null?original.getClass().getSimpleName():original.getMessage()),original);
        return original;
    }
    public void close(){closed=true;synchronized(ACTIVE){if(ACTIVE.get(backend)==this)ACTIVE.remove(backend);}}
}
