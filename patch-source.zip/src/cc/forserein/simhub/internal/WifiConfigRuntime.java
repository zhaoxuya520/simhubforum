package cc.forserein.simhub.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;
import java.lang.reflect.*;
import java.util.*;

/** Per-profile overrides, rebuilt from the clean carrier preset, never from a prior override. */
public final class WifiConfigRuntime {
    private WifiConfigRuntime() {}
    private static final String PREFS="wifi_config_overrides_v1";
    private static Object cachedCard, cachedDefault, cachedEffective;
    private static String cachedKey, cachedRecord, cachedHome;
    private static String lastError;
    private static Map<String,String> cachedValues;
    private static String editingSmsKey,editingSmsValue;

    private static SharedPreferences prefs() throws ReflectiveOperationException {
        Context context=(Context)Class.forName("zl5").getField("f").get(null);
        if(context==null) throw new IllegalStateException("Wi-Fi 通话尚未初始化");
        return context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
    }
    public static String cardKey(Object card) throws ReflectiveOperationException {
        if(card==null) throw new IllegalStateException("请先读取卡片");
        if(completeIccid(card)&&DitoHomeIdentity.isDito(card))return WifiConfigValues.digest(String.valueOf(WifiConfigModel.get(card,"b"))+"\nDITO");
        return legacyKey(card,String.valueOf(WifiConfigModel.get(card,"a")));
    }
    private static boolean completeIccid(Object card)throws ReflectiveOperationException {
        return card!=null&&String.valueOf(WifiConfigModel.get(card,"b")).matches("[0-9]{19,20}");
    }
    private static String legacyKey(Object card,String imsi)throws ReflectiveOperationException {
        return WifiConfigValues.digest(String.valueOf(WifiConfigModel.get(card,"b"))+"\n"+imsi);
    }
    /** Keep existing SMSC, device and explicit carrier edits when this SIM changes its roaming IMSI. */
    private static void migrateDito(Object card,String key)throws ReflectiveOperationException {
        SharedPreferences preferences=prefs();
        if(!completeIccid(card)||!DitoHomeIdentity.isDito(card)||preferences.getString(key,null)!=null)return;
        String record=preferences.getString(legacyKey(card,String.valueOf(WifiConfigModel.get(card,"a"))),null);
        String home=DitoHomeIdentity.saved(card);
        if(record==null&&home!=null)record=preferences.getString(legacyKey(card,home),null);
        // An unknown issuer may have had edits under its roaming identity before
        // the first real home read identified it as DITO. Use only the previously
        // loaded, complete same-card identity; never scan or guess an old IMSI.
        if(record==null&&completeIccid(cachedCard)&&cachedKey!=null
                &&WifiConfigModel.get(card,"b").equals(WifiConfigModel.get(cachedCard,"b"))
                &&cachedKey.equals(legacyKey(cachedCard,String.valueOf(WifiConfigModel.get(cachedCard,"a")))))
            record=preferences.getString(cachedKey,null);
        if(record==null)return;
        WifiConfigValues.decode(record);
        if(!preferences.edit().putString(key,record).commit()||!record.equals(preferences.getString(key,null))){
            preferences.edit().remove(key).commit();
            throw new IllegalStateException("DITO 原配置迁移失败，请重新读取卡片");
        }
    }
    private static synchronized Map<String,String> load(Object card) throws ReflectiveOperationException {
        if(card==null) return null;
        String key=cardKey(card);
        // load is synchronized: preserve the old same-card cache until bounded
        // migration has examined it, then install the new physical read.
        migrateDito(card,key);
        if(card!=cachedCard||!key.equals(cachedKey)) {
            editingSmsKey=null;editingSmsValue=null;
            cachedKey=key; cachedCard=card; cachedDefault=null; cachedEffective=null;
            cachedRecord=null; cachedValues=null;cachedHome=null;
        }
        String home=DitoHomeIdentity.isDito(card)?DitoHomeIdentity.saved(card):null;
        if(!Objects.equals(home,cachedHome)){cachedHome=home;cachedDefault=null;cachedEffective=null;}
        String record=prefs().getString(cachedKey,null);
        if(record==null){if(cachedRecord!=null||cachedValues!=null){cachedRecord=null;cachedValues=null;cachedDefault=null;cachedEffective=null;}return null;}
        if(!record.equals(cachedRecord)) {
            Map<String,String> values=WifiConfigValues.decode(record);
            // A syntactically valid record can still reference a removed template.
            // Reject it here so both live resolution and the editor recover alike.
            String selected=values.get(CarrierPresets.KEY);
            if(selected!=null)CarrierPresets.find(selected);
            cachedValues=values;cachedRecord=record;cachedDefault=null;cachedEffective=null;
        }
        return cachedValues;
    }
    private static synchronized Object defaults(Object card) throws ReflectiveOperationException {
        Map<String,String> values=load(card);
        if(cachedDefault==null) cachedDefault=CarrierPresets.defaults(card,values);
        return cachedDefault;
    }
    public static synchronized Object resolve(Object card,Object original) {
        if(card==null || original==null) return original;
        try {
            Map<String,String> values=load(card);
            if(values==null&&!DitoHomeIdentity.isDito(card)) {IdentityBinding.config(card,original,null);return original;}
            if(cachedEffective==null) cachedEffective=WifiConfigModel.merge(defaults(card),values==null?Collections.<String,String>emptyMap():values);
            IdentityBinding.config(card,cachedEffective,values);
            return cachedEffective;
        } catch(Exception e) {
            error(e);
            // Bad saved settings must not reclassify an already identified DITO
            // card as the Vodafone profile selected from its roaming IMSI.
            // Keep the saved record for an explicit repair in the editor.
            try {
                if(DitoHomeIdentity.isDito(card)) {
                    Object clean=DitoCarrierProfile.defaults(card);
                    IdentityBinding.config(card,clean,null);return clean;
                }
            } catch(Exception recoveryError) { error(recoveryError); }
            return original;
        }
    }
    public static synchronized String smsc(Object card,String legacy) {
        if(card!=null)try{load(card);if(editingSmsKey!=null&&editingSmsKey.equals(cardKey(card)))return editingSmsValue;}
        catch(Exception e){error(e);}
        return scalar(card,"smsc",legacy);
    }
    private static String cardSmsCenter(Object card)throws ReflectiveOperationException {
        Object number=WifiConfigModel.get(card,"f");
        if(number==null || number.toString().trim().isEmpty())return "";
        try{return WifiConfigValues.validate(Collections.singletonMap("smsc",number.toString())).get("smsc");}
        catch(IllegalArgumentException ignored){return "";}
    }
    /** Same effective value for details, the editor and the existing sender's override argument. */
    public static synchronized String displaySmsCenter(Object card) {
        if(card==null)return null;
        try {
            Map<String,String> values=load(card);
            if(values!=null && WifiConfigListDraft.EMPTY.equals(values.get("smsc_list")))return null;
            String legacy="";Object state=state();Object active=WifiConfigModel.get(state,"e");
            if(active!=null && cardKey(active).equals(cardKey(card)))legacy=(String)WifiConfigModel.get(state,"i");
            String number=smsc(card,legacy);
            if(number==null || number.trim().isEmpty())number=cardSmsCenter(card);
            return number==null || number.isEmpty()?null:number;
        }catch(Exception e){error(e);return null;}
    }
    public static synchronized String imei(Object card,String legacy) { return scalar(card,"imei",legacy); }
    public static synchronized String epdg(Object card,String legacy) { return scalar(card,"epdg",legacy); }
    public static synchronized boolean isDitoSelected(Object card)throws ReflectiveOperationException {
        Map<String,String> values=load(card);return values!=null&&DitoCarrierProfile.selected(values.get(CarrierPresets.KEY));
    }
    private static String scalar(Object card,String key,String legacy) {
        if(card==null) return legacy;
        try {
            Map<String,String> values=load(card);
            if(values==null) return legacy;
            if(values.containsKey(key)) return WifiConfigListDraft.EMPTY.equals(values.get(key))?"":values.get(key);
            if(key.equals("smsc") && values.containsKey(CarrierPresets.KEY))return cardSmsCenter(card);
            if(key.equals("imei")) {
                Object builtin=WifiConfigModel.get(defaults(card),"w");
                return builtin==null?"":builtin.toString();
            }
            return "";
        } catch(Exception e){
            error(e);
            // The clean DITO preset owns its endpoints during record recovery;
            // a legacy state-level endpoint must not override it with Vodafone.
            if(key.equals("epdg"))try{if(DitoHomeIdentity.isDito(card))return "";}
            catch(Exception recoveryError){error(recoveryError);}
            return legacy;
        }
    }
    public static synchronized void requireSmsCenter() throws ReflectiveOperationException {
        Object card=WifiConfigModel.get(state(),"e");Map<String,String> values=load(card);
        if(card!=null&&editingSmsKey!=null&&editingSmsKey.equals(cardKey(card)))throw new IllegalStateException("请填写完整的短信中心号码");
        if(values!=null && WifiConfigListDraft.EMPTY.equals(values.get("smsc_list")))
            throw new IllegalStateException("请先添加短信中心");
    }
    private static void error(Exception e) {
        lastError="自定义配置未能载入，请重新打开配置并保存。";
        Throwable cause=e;while(cause.getCause()!=null&&cause.getCause()!=cause)cause=cause.getCause();
        Log.e("SIMHubConfig","Override model error: "+e.getClass().getSimpleName()+" / "+cause.getClass().getSimpleName());
    }
    public static Object state() throws ReflectiveOperationException {
        Object flow=Class.forName("zl5").getField("b").get(null);
        return flow.getClass().getMethod("getValue").invoke(flow);
    }
    static void checkIdle(Object state) throws ReflectiveOperationException {
        Object phase=WifiConfigModel.get(state,"k");
        if(Boolean.TRUE.equals(phase.getClass().getMethod("z").invoke(phase)) || Boolean.TRUE.equals(WifiConfigModel.get(state,"l")))
            throw new IllegalStateException("请先关闭 Wi-Fi 通话，再修改配置");
    }
    public static final class Snapshot {
        public final String key, warning, record;
        public final Map<String,String> values, defaults;
        Snapshot(String key,Map<String,String> values,Map<String,String> defaults,String warning,String record){this.key=key;this.values=Collections.unmodifiableMap(new LinkedHashMap<>(values));this.defaults=Collections.unmodifiableMap(new LinkedHashMap<>(defaults));this.warning=warning;this.record=record;}
    }
    public static synchronized Snapshot snapshot() throws ReflectiveOperationException {
        Object state=state();checkIdle(state);
        Object card=WifiConfigModel.get(state,"e");
        if(card==null || WifiConfigModel.get(state,"f")==null) throw new IllegalStateException("请先读取卡片及 Wi-Fi 通话配置");
        Map<String,String> stored;
        String warning=lastError;lastError=null;
        try {stored=load(card);}
        catch(IllegalArgumentException e){stored=Collections.emptyMap();warning="保存的配置记录无法读取，请重新填写；留空保存可恢复内置配置。";}
        Map<String,String> values=new LinkedHashMap<>();
        if(stored!=null) values.putAll(stored);
        else {
            for(String[] pair:new String[][]{{"epdg","h"},{"smsc","i"},{"imei","j"}}) {
                Object v=WifiConfigModel.get(state,pair[1]);
                if(v!=null && !v.toString().trim().isEmpty()) values.put(pair[0],v.toString());
            }
        }
        Map<String,String> hints=WifiConfigModel.display(CarrierPresets.defaults(card,values));
        hints.put("smsc",cardSmsCenter(card));
        return new Snapshot(cardKey(card),values,hints,warning,prefs().getString(cardKey(card),null));
    }
    /** Called from the UI after full validation; single preference record makes save atomic. */
    public static synchronized void save(String expectedKey,Map<String,String> draft) throws ReflectiveOperationException {
        saveInternal(expectedKey,null,false,draft,false);
    }
    public static synchronized void save(String expectedKey,String expectedRecord,Map<String,String> draft) throws ReflectiveOperationException {
        saveInternal(expectedKey,expectedRecord,true,draft,false);
    }
    /** SMSC is passed to each message; changing it must not rebuild or stop the IMS connection. */
    public static synchronized void saveSmsCenter(String expectedKey,String expectedRecord,Map<String,String> draft)throws ReflectiveOperationException {
        saveInternal(expectedKey,expectedRecord,true,draft,true);
    }
    private static Map<String,String> legacyValues(Object state)throws ReflectiveOperationException {
        Map<String,String> values=new LinkedHashMap<>();
        for(String[] pair:new String[][]{{"epdg","h"},{"smsc","i"},{"imei","j"}}){
            Object value=WifiConfigModel.get(state,pair[1]);
            if(value!=null&&!value.toString().trim().isEmpty())values.put(pair[0],value.toString());
        }
        return values;
    }
    private static Map<String,String> withoutSmsCenter(Map<String,String> values){
        Map<String,String> result=new LinkedHashMap<>(values);result.remove("smsc");result.remove("smsc_list");return result;
    }
    /** Both original SMS-page edit callbacks delegate here instead of writing a shadowed legacy value. */
    public static synchronized void updateSmsCenter(String input){
        try{
            Object before=state(),card=WifiConfigModel.get(before,"e");String key=cardKey(card);
            load(card);
            String record=prefs().getString(key,null);
            Map<String,String> values=new LinkedHashMap<>(record==null?WifiConfigValues.validate(withoutSmsCenter(legacyValues(before))):WifiConfigValues.decode(record));
            String number;
            try{number=WifiConfigValues.validate(Collections.singletonMap("smsc",input)).get("smsc");}
            catch(WifiConfigValues.Invalid e){
                // The original SMS-page text field calls this on every keystroke, including '+' and '+6'.
                if(input!=null&&input.length()<=40&&DialingSupport.ascii(input).matches("[+0-9 ()-]+")){
                    editingSmsKey=key;editingSmsValue=input;publishSmsDraft(key);return;
                }
                throw e;
            }
            if(number==null){values.remove("smsc");values.remove("smsc_list");}
            else{
                List<String> numbers=new ArrayList<>(WifiConfigListDraft.decode(values.get("smsc_list")));
                int at=numbers.indexOf(values.get("smsc"));
                if(at>=0)numbers.set(at,number);else numbers.add(0,number);
                values.put("smsc",number);values.put("smsc_list",WifiConfigValues.join(new LinkedHashSet<>(numbers),"\n"));
            }
            saveSmsCenter(key,record,values);
        }catch(Exception e){
            String message=e instanceof IllegalArgumentException||e instanceof IllegalStateException?e.getMessage():"短信中心保存失败，请重新打开后重试";
            try{Context context=(Context)Class.forName("zl5").getField("f").get(null);Toast.makeText(context,message,Toast.LENGTH_LONG).show();}
            catch(Exception ignored){Log.e("SIMHubConfig","SMS center save failed: "+e.getClass().getSimpleName());}
        }
    }
    private static void publishSmsDraft(String key)throws ReflectiveOperationException {
        Object flow=Class.forName("zl5").getField("b").get(null);Method cas=flow.getClass().getMethod("h",Object.class,Object.class);
        for(int attempt=0;attempt<64;attempt++){
            Object current=state(),card=WifiConfigModel.get(current,"e");
            if(!key.equals(cardKey(card)))throw new IllegalStateException("卡片已切换，请重新填写短信中心");
            Object[] args=WifiConfigModel.fields(current,20);cachedEffective=args[5];args[8]=editingSmsValue;
            Object updated=WifiConfigModel.constructor(current.getClass(),20).newInstance(args);
            if(Boolean.TRUE.equals(cas.invoke(flow,current,updated)))return;
        }
        throw new IllegalStateException("状态正在变化，请稍后重试");
    }
    private static void saveInternal(String expectedKey,String expectedRecord,boolean checkRevision,Map<String,String> draft,boolean smsOnly) throws ReflectiveOperationException {
        Map<String,String> values=WifiConfigValues.validate(draft);
        Object before=state();if(!smsOnly)checkIdle(before);
        Object card=WifiConfigModel.get(before,"e");
        if(!expectedKey.equals(cardKey(card))) throw new IllegalStateException("卡片已切换，请重新打开配置");
        SharedPreferences preferences=prefs();
        String previous=preferences.getString(expectedKey,null);
        if(checkRevision && !Objects.equals(previous,expectedRecord)) throw new IllegalStateException("配置已在其他操作中更新，请关闭后重新打开配置，避免覆盖新值");
        if(smsOnly){
            Map<String,String> baseline=previous==null?WifiConfigValues.validate(withoutSmsCenter(legacyValues(before))):WifiConfigValues.decode(previous);
            if(!withoutSmsCenter(baseline).equals(withoutSmsCenter(values)))throw new IllegalStateException("本次包含其他配置修改，请关闭 Wi-Fi 通话后保存");
        }else{
            // Validate reflection and construction before making any persistent change.
            Object clean=CarrierPresets.defaults(card,values);WifiConfigModel.merge(clean,values);
        }
        String record=WifiConfigValues.encode(values);
        if(!preferences.edit().putString(expectedKey,record).commit()) {
            restore(preferences,expectedKey,previous);
            throw new IllegalStateException("保存失败，请检查手机存储空间");
        }
        if(expectedKey.equals(editingSmsKey)){editingSmsKey=null;editingSmsValue=null;}
        try {
            Object flow=Class.forName("zl5").getField("b").get(null);
            Method cas=flow.getClass().getMethod("h",Object.class,Object.class);
            for(int attempt=0;attempt<64;attempt++) {
                Object current=state();if(!smsOnly)checkIdle(current);
                Object currentCard=WifiConfigModel.get(current,"e");
                if(!expectedKey.equals(cardKey(currentCard))) throw new IllegalStateException("卡片已切换，请重新打开配置");
                Object[] args=WifiConfigModel.fields(current,20);
                if(smsOnly){
                    if(cachedCard!=currentCard)cachedDefault=null;
                    cachedCard=currentCard;cachedKey=expectedKey;cachedRecord=record;cachedValues=values;cachedEffective=args[5];
                }else args[5]=resolve(currentCard,args[5]);
                args[7]=epdg(currentCard,(String)args[7]);
                args[8]=smsc(currentCard,(String)args[8]);
                args[9]=imei(currentCard,(String)args[9]);
                Object updated=WifiConfigModel.constructor(current.getClass(),20).newInstance(args);
                if(Boolean.TRUE.equals(cas.invoke(flow,current,updated))) return;
            }
            throw new IllegalStateException("状态正在变化，请稍后重新保存");
        } catch(ReflectiveOperationException | RuntimeException e) {
            restore(preferences,expectedKey,previous);throw e;
        }
    }
    private static void restore(SharedPreferences preferences,String key,String previous) {
        SharedPreferences.Editor editor=preferences.edit();
        if(previous==null) editor.remove(key); else editor.putString(key,previous);
        editor.commit();cachedRecord=null;cachedValues=null;cachedDefault=null;cachedEffective=null;
    }
}
