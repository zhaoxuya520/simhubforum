package cc.forserein.simhub.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import java.lang.reflect.*;
import java.util.*;

/** Per-profile overrides, rebuilt from the clean carrier preset, never from a prior override. */
public final class WifiConfigRuntime {
    private WifiConfigRuntime() {}
    private static final String PREFS="wifi_config_overrides_v1";
    private static Object cachedCard, cachedDefault, cachedEffective;
    private static String cachedKey, cachedRecord;
    private static String lastError;
    private static Map<String,String> cachedValues;

    private static SharedPreferences prefs() throws ReflectiveOperationException {
        Context context=(Context)Class.forName("zl5").getField("f").get(null);
        if(context==null) throw new IllegalStateException("Wi-Fi 通话尚未初始化");
        return context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
    }
    public static String cardKey(Object card) throws ReflectiveOperationException {
        if(card==null) throw new IllegalStateException("请先读取卡片");
        return WifiConfigValues.digest(String.valueOf(WifiConfigModel.get(card,"b"))+"\n"+WifiConfigModel.get(card,"a"));
    }
    private static synchronized Map<String,String> load(Object card) throws ReflectiveOperationException {
        if(card==null) return null;
        if(card!=cachedCard) {
            cachedKey=cardKey(card); cachedCard=card; cachedDefault=null; cachedEffective=null;
            cachedRecord=null; cachedValues=null;
        }
        String record=prefs().getString(cachedKey,null);
        if(record==null){cachedRecord=null;cachedValues=null;cachedEffective=null;return null;}
        if(!record.equals(cachedRecord)) {
            Map<String,String> values=WifiConfigValues.decode(record);
            cachedValues=values;cachedRecord=record;cachedEffective=null;
        }
        return cachedValues;
    }
    private static synchronized Object defaults(Object card) throws ReflectiveOperationException {
        load(card);
        if(cachedDefault==null) cachedDefault=WifiConfigModel.builtIn(card);
        return cachedDefault;
    }
    public static synchronized Object resolve(Object card,Object original) {
        if(card==null || original==null) return original;
        try {
            Map<String,String> values=load(card);
            if(values==null) {IdentityBinding.config(card,original,null);return original;}
            if(cachedEffective==null) cachedEffective=WifiConfigModel.merge(defaults(card),values);
            IdentityBinding.config(card,cachedEffective,values);
            return cachedEffective;
        } catch(Exception e) { error(e);return original; }
    }
    public static synchronized String smsc(Object card,String legacy) { return scalar(card,"smsc",legacy); }
    public static synchronized String imei(Object card,String legacy) { return scalar(card,"imei",legacy); }
    public static synchronized String epdg(Object card,String legacy) { return scalar(card,"epdg",legacy); }
    private static String scalar(Object card,String key,String legacy) {
        if(card==null) return legacy;
        try {
            Map<String,String> values=load(card);
            if(values==null) return legacy;
            if(values.containsKey(key)) return values.get(key);
            if(key.equals("imei")) {
                Object builtin=WifiConfigModel.get(defaults(card),"w");
                return builtin==null?"":builtin.toString();
            }
            return "";
        } catch(Exception e){error(e);return legacy;}
    }
    private static void error(Exception e) {
        lastError="自定义配置未能载入，请重新打开配置并保存。";
        Log.e("SIMHubConfig","Override model error: "+e.getClass().getSimpleName());
    }
    public static Object state() throws ReflectiveOperationException {
        Object flow=Class.forName("zl5").getField("b").get(null);
        return flow.getClass().getMethod("getValue").invoke(flow);
    }
    static void checkIdle(Object state) throws ReflectiveOperationException {
        Object phase=WifiConfigModel.get(state,"k");
        if(Boolean.TRUE.equals(phase.getClass().getMethod("z").invoke(phase)) || Boolean.TRUE.equals(WifiConfigModel.get(state,"l")))
            throw new IllegalStateException("请先关闭 Wi-Fi 通话，再修改配置");
    }
    public static final class Snapshot {
        public final String key, warning, record;
        public final Map<String,String> values, defaults;
        Snapshot(String key,Map<String,String> values,Map<String,String> defaults,String warning,String record){this.key=key;this.values=Collections.unmodifiableMap(new LinkedHashMap<>(values));this.defaults=Collections.unmodifiableMap(new LinkedHashMap<>(defaults));this.warning=warning;this.record=record;}
    }
    public static synchronized Snapshot snapshot() throws ReflectiveOperationException {
        Object state=state();checkIdle(state);
        Object card=WifiConfigModel.get(state,"e");
        if(card==null || WifiConfigModel.get(state,"f")==null) throw new IllegalStateException("请先读取卡片及 Wi-Fi 通话配置");
        Map<String,String> stored;
        String warning=lastError;lastError=null;
        try {stored=load(card);}
        catch(IllegalArgumentException e){stored=Collections.emptyMap();warning="保存的配置记录无法读取，请重新填写；留空保存可恢复内置配置。";}
        Map<String,String> values=new LinkedHashMap<>();
        if(stored!=null) values.putAll(stored);
        else {
            for(String[] pair:new String[][]{{"epdg","h"},{"smsc","i"},{"imei","j"}}) {
                Object v=WifiConfigModel.get(state,pair[1]);
                if(v!=null && !v.toString().trim().isEmpty()) values.put(pair[0],v.toString());
            }
        }
        Map<String,String> hints=WifiConfigModel.display(WifiConfigModel.builtIn(card));
        return new Snapshot(cardKey(card),values,hints,warning,prefs().getString(cardKey(card),null));
    }
    /** Called from the UI after full validation; single preference record makes save atomic. */
    public static synchronized void save(String expectedKey,Map<String,String> draft) throws ReflectiveOperationException {
        saveInternal(expectedKey,null,false,draft);
    }
    public static synchronized void save(String expectedKey,String expectedRecord,Map<String,String> draft) throws ReflectiveOperationException {
        saveInternal(expectedKey,expectedRecord,true,draft);
    }
    private static void saveInternal(String expectedKey,String expectedRecord,boolean checkRevision,Map<String,String> draft) throws ReflectiveOperationException {
        Map<String,String> values=WifiConfigValues.validate(draft);
        Object before=state();checkIdle(before);
        Object card=WifiConfigModel.get(before,"e");
        if(!expectedKey.equals(cardKey(card))) throw new IllegalStateException("卡片已切换，请重新打开配置");
        // Validate reflection and construction before making any persistent change.
        Object clean=WifiConfigModel.builtIn(card);
        WifiConfigModel.merge(clean,values);
        SharedPreferences preferences=prefs();
        String previous=preferences.getString(expectedKey,null);
        if(checkRevision && !Objects.equals(previous,expectedRecord)) throw new IllegalStateException("配置已在其他操作中更新，请关闭后重新打开配置，避免覆盖新值");
        String record=WifiConfigValues.encode(values);
        if(!preferences.edit().putString(expectedKey,record).commit()) {
            restore(preferences,expectedKey,previous);
            throw new IllegalStateException("保存失败，请检查手机存储空间");
        }
        try {
            Object flow=Class.forName("zl5").getField("b").get(null);
            Method cas=flow.getClass().getMethod("h",Object.class,Object.class);
            for(int attempt=0;attempt<64;attempt++) {
                Object current=state();checkIdle(current);
                Object currentCard=WifiConfigModel.get(current,"e");
                if(!expectedKey.equals(cardKey(currentCard))) throw new IllegalStateException("卡片已切换，请重新打开配置");
                Object[] args=WifiConfigModel.fields(current,20);
                args[5]=resolve(currentCard,args[5]);
                args[7]=epdg(currentCard,(String)args[7]);
                args[8]=smsc(currentCard,(String)args[8]);
                args[9]=imei(currentCard,(String)args[9]);
                Object updated=WifiConfigModel.constructor(current.getClass(),20).newInstance(args);
                if(Boolean.TRUE.equals(cas.invoke(flow,current,updated))) return;
            }
            throw new IllegalStateException("状态正在变化，请稍后重新保存");
        } catch(ReflectiveOperationException | RuntimeException e) {
            restore(preferences,expectedKey,previous);throw e;
        }
    }
    private static void restore(SharedPreferences preferences,String key,String previous) {
        SharedPreferences.Editor editor=preferences.edit();
        if(previous==null) editor.remove(key); else editor.putString(key,previous);
        editor.commit();cachedRecord=null;cachedValues=null;cachedEffective=null;
    }
}
