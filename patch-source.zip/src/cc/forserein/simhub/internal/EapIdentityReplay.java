package cc.forserein.simhub.internal;

import java.util.Arrays;

/** One successful AKA-Identity exchange, owned by one native EAP session. */
public final class EapIdentityReplay {
    private byte[] request, response, pending;
    private int transcriptSize = -1;

    /** Called only on initial coroutine entry, before native packet processing. */
    public synchronized byte[] replay(byte[] packet, int currentTranscriptSize) {
        byte[] identityRequest = identityRequest(packet);
        if (response != null && transcriptSize == currentTranscriptSize
                && identityRequest != null && Arrays.equals(request, identityRequest)) {
            pending = null;
            return response.clone();
        }
        // A new exchange or the native transcript reset ends the previous cache.
        // Never keep historical identifiers: the original state machine processes
        // nonmatching packets, including challenges and notifications, unchanged.
        request = null;
        response = null;
        transcriptSize = -1;
        pending = identityRequest;
        return null;
    }

    /** Called only after native subtype 5 has serialized and recorded its reply. */
    public synchronized void record(byte[] reply, int currentTranscriptSize) {
        if (pending != null && reply != null && reply.length >= 8
                && reply[0] == 2 && reply[1] == pending[1]
                && reply[4] == pending[4] && reply[5] == 5
                && length(reply) == reply.length) {
            request = pending;
            response = reply.clone();
            transcriptSize = currentTranscriptSize;
        }
        pending = null;
    }

    private static byte[] identityRequest(byte[] packet) {
        if (packet == null || packet.length < 8 || packet[0] != 1
                || (packet[4] != 23 && packet[4] != 50) || packet[5] != 5) return null;
        int size = length(packet);
        if (size < 8 || size > packet.length) return null;
        // RFC 3748: octets beyond EAP Length are lower-layer padding.
        // Bytes inside EAP Length, including attributes/padding, are all part of
        // the replay key; native parsing decides whether a new request is valid.
        return Arrays.copyOf(packet, size);
    }

    private static int length(byte[] packet) {
        return ((packet[2] & 255) << 8) | (packet[3] & 255);
    }
}
