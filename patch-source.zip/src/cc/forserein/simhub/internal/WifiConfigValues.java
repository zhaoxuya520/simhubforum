package cc.forserein.simhub.internal;

import java.net.IDN;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Typed, Android-independent validation. Absence always means use the carrier default. */
public final class WifiConfigValues {
    private WifiConfigValues() {}
    public static final class Field {
        public final String key, label, section, help;
        public final int index;
        Field(String key, String label, String section, int index, String help) {
            this.key=key; this.label=label; this.section=section; this.index=index; this.help=help;
        }
    }
    public static final Field[] FIELDS = {
        new Field("epdg", "ePDG 服务器", "网络与设备", 5, "多个域名按优先级分行填写；不填 http:// 或端口"),
        new Field("smsc", "短信中心 SMSC", "网络与设备", -1, "完整国际号码，例如 +441234567890；留空读取卡内 EF_SMSP"),
        new Field("imei", "设备标识 IMEI", "网络与设备", 22, "设备自己的 15 位 IMEI；仅保存在本机"),
        new Field("domain", "Domain", "IMS", 6, "IMS 域名，不含 sip: 或端口"),
        new Field("apn", "APN", "IMS", 7, "接入点名称，例如 ims"),
        new Field("ip", "IP", "IMS", 8, "ipv4 / ipv6 / dual；留空使用内置"),
        new Field("ipsec", "IPsec", "IMS", 19, "on / off；留空使用内置"),
        new Field("nai", "NAI", "IMS", 17, "完整身份，例如 anonymous@nai.epc.example.org"),
        new Field("impi", "IMPI（私有身份）", "IMS", 18, "填写完整 user@domain；修改 Domain 后可按运营商要求一起修改"),
        new Field("impu", "IMPU（公共身份）", "IMS", 26, "sip:user@domain 或 tel:+国家码号码；留空按内置方式确定"),
        new Field("eap", "EAP Identity", "IMS", 24, "完整 EAP 身份；留空按内置方式确定"),
        new Field("ike_encr", "IKE 加密", "IKE / ESP", 9, "aes256 / aes192 / aes128；多个值用空格或逗号分隔"),
        new Field("ike_integ", "IKE 完整性", "IKE / ESP", 10, "sha256 / sha384 / sha512 / sha1"),
        new Field("ike_prf", "IKE PRF", "IKE / ESP", 11, "sha256 / sha384 / sha512 / sha1"),
        new Field("ike_dh", "IKE DH", "IKE / ESP", 12, "modp2048 / modp1024 / ecp256"),
        new Field("esp_encr", "ESP 加密", "IKE / ESP", 13, "aes256 / aes192 / aes128"),
        new Field("esp_integ", "ESP 完整性", "IKE / ESP", 14, "sha256 / sha384 / sha512 / sha1"),
        new Field("keepalive", "Keepalive（秒）", "IKE / ESP", 15, "10–3600 秒，例如 20；留空使用内置")
    };
    public static final class Invalid extends IllegalArgumentException {
        private static final long serialVersionUID=1L;
        public final String key;
        Invalid(String key, String message) { super(message); this.key=key; }
    }
    /** Marker survives the original Kotlin config copies; explicit proposals must not expand. */
    public static final class Algorithms extends ArrayList<String> {
        private static final long serialVersionUID=1L;
        public Algorithms(Collection<String> values) { super(values); }
    }
    public static Field field(String key) {
        for (Field f:FIELDS) if(f.key.equals(key)) return f;
        throw new Invalid(key, "未知配置项");
    }
    private static void require(boolean ok, String key, String message) {
        if(!ok) throw new Invalid(key,message);
    }
    static List<String> tokens(String value) { return Arrays.asList(value.split("[\\s,;，；]+")); }
    private static String host(String value, String key) {
        String ascii;
        try { ascii=IDN.toASCII(value, IDN.USE_STD3_ASCII_RULES).toLowerCase(Locale.ROOT); }
        catch(IllegalArgumentException e) { throw new Invalid(key,"请输入有效域名"); }
        require(ascii.length()<=253 && ascii.matches("[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?"),key,"请输入有效域名，不含协议、路径或端口");
        for(String part:ascii.split("\\.",-1))
            require(part.length()>0 && part.length()<=63 && !part.startsWith("-") && !part.endsWith("-"),key,"域名格式错误");
        return ascii;
    }
    public static Map<String,String> validate(Map<String,String> draft) {
        for(String key:draft.keySet()) field(key);
        Map<String,String> out=new LinkedHashMap<>();
        for(Field f:FIELDS) {
            String value=draft.get(f.key);
            if(value==null || value.trim().isEmpty()) continue;
            value=value.trim();
            require(value.length()<=4096,f.key,"内容过长");
            if(f.key.equals("epdg")) {
                LinkedHashSet<String> hosts=new LinkedHashSet<>();
                for(String s:tokens(value)) hosts.add(host(s,f.key));
                require(hosts.size()<=16,f.key,"最多填写 16 个 ePDG 域名");
                value=join(hosts,"\n");
            } else if(f.key.startsWith("ike_") || f.key.startsWith("esp_")) {
                String choices=f.key.endsWith("encr")?"aes128 aes192 aes256":f.key.endsWith("dh")?"modp1024 modp2048 ecp256":"sha1 sha256 sha384 sha512";
                Set<String> allowed=new HashSet<>(Arrays.asList(choices.split(" ")));
                LinkedHashSet<String> values=new LinkedHashSet<>();
                for(String s:tokens(value.toLowerCase(Locale.ROOT))) {
                    require(allowed.contains(s),f.key,"当前引擎支持："+choices); values.add(s);
                }
                require(!values.isEmpty(),f.key,"请填写算法，或清空恢复内置");
                value=join(values," ");
            } else {
                require(!value.matches("(?s).*[\\p{Cntrl}].*"),f.key,"不能包含换行或控制字符");
                if(f.key.equals("domain") || f.key.equals("apn")) value=host(value,f.key);
                else if(f.key.equals("ip")) {
                    value=value.toLowerCase(Locale.ROOT);
                    require(Arrays.asList("ipv4","ipv6","dual").contains(value),f.key,"只能填写 ipv4、ipv6 或 dual");
                } else if(f.key.equals("ipsec")) {
                    value=value.toLowerCase(Locale.ROOT);
                    if(value.equals("true") || value.equals("1")) value="on";
                    if(value.equals("false") || value.equals("0")) value="off";
                    require(value.equals("on") || value.equals("off"),f.key,"只能填写 on 或 off");
                } else if(f.key.equals("keepalive")) {
                    require(value.matches("[0-9]{1,4}"),f.key,"请输入 10–3600 的整数秒数");
                    int seconds=Integer.parseInt(value);
                    require(seconds>=10 && seconds<=3600,f.key,"请输入 10–3600 的整数秒数");
                    value=Integer.toString(seconds);
                } else if(f.key.equals("imei")) {
                    value=DialingSupport.ascii(value).replace(" ","").replace("-","");
                    require(value.matches("[0-9]{15}") && validImei(value),f.key,"请输入设备自己的有效 15 位 IMEI");
                } else if(f.key.equals("smsc")) {
                    require(DialingSupport.ascii(value).matches("[+0-9 ()-]+"),f.key,"短信中心只能包含国际电话号码");
                    value=DialingSupport.smsDestination(value).replace(" ","").replace("-","").replace("(","").replace(")","");
                    require(value.matches("\\+[1-9][0-9]{1,14}"),f.key,"请输入带国家码的完整短信中心号码");
                } else if(f.key.equals("impu")) {
                    require(value.matches("(?i)(sip:[^@<>\\s]+@[^<>\\s]+|tel:\\+[1-9][0-9]{1,14})"),f.key,"请输入 sip:user@domain 或 tel:+国际号码");
                } else {
                    require(value.matches("[^@<>\\s]+@[^@<>\\s]+"),f.key,"请输入完整的 user@domain 身份");
                }
            }
            out.put(f.key,value);
        }
        return Collections.unmodifiableMap(out);
    }
    static boolean validImei(String s) {
        int sum=0;
        for(int i=0;i<s.length();i++){int d=s.charAt(i)-'0';if((i&1)==1)d*=2;sum+=d/10+d%10;}
        return sum%10==0 && !s.matches("0+");
    }
    public static String join(Collection<?> values,String separator) {
        StringBuilder b=new StringBuilder();
        for(Object value:values){if(b.length()>0)b.append(separator);b.append(value);}
        return b.toString();
    }
    /** Deterministic format, values cannot contain tab; ePDG newlines are escaped. */
    public static String encode(Map<String,String> values) {
        StringBuilder b=new StringBuilder("v1\n");
        for(Field f:FIELDS) if(values.containsKey(f.key)) b.append(f.key).append('\t').append(values.get(f.key).replace("\n"," ")).append('\n');
        return b.toString();
    }
    public static Map<String,String> decode(String text) {
        require(text.startsWith("v1\n"),"epdg","配置记录版本不支持");
        Map<String,String> raw=new LinkedHashMap<>();
        for(String line:text.substring(3).split("\n")) if(!line.isEmpty()) {
            int tab=line.indexOf('\t'); require(tab>0,"epdg","配置记录损坏");
            String key=line.substring(0,tab);require(!raw.containsKey(key),key,"配置记录重复");
            raw.put(key,line.substring(tab+1));
        }
        return validate(raw);
    }
    public static String digest(String value) {
        try {
            byte[] bytes=MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder b=new StringBuilder();for(byte x:bytes)b.append(String.format(Locale.ROOT,"%02x",x&255));return b.toString();
        } catch(Exception e) { throw new IllegalStateException(e); }
    }
}
