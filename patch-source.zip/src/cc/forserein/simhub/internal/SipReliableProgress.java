package cc.forserein.simhub.internal;

import java.util.Map;

/** Filter reliable progress before the original handler applies the early SDP and route. */
final class SipReliableProgress {
    private SipReliableProgress() {}

    static boolean shouldDiscard(Object dialog, Object response) throws Exception {
        Map<?, ?> received = (Map<?, ?>) SipInviteFailure.field(dialog, "v");
        if (received.isEmpty()) return false;
        String sequence = SipInviteFailure.first(response, "RSeq", null);
        if (sequence == null) return false;

        // Use the same To-tag and RSeq record as the native PRACK builder. Forks start independently.
        String tag = (String) SipInviteFailure.call(response, "g", new Class<?>[0]);
        Integer previous = (Integer) received.get(tag == null ? "" : tag);
        if (previous == null) return false;
        final int current;
        try {
            current = Integer.parseInt(sequence.trim());
        } catch (NumberFormatException ignored) {
            return false;
        }
        if ((long) current == previous.longValue() + 1) return false;
        for (String require : SipInviteFailure.headers(response, "Require", null)) {
            for (String option : require.split(",")) {
                if ("100rel".equalsIgnoreCase(option.trim())) return true;
            }
        }
        return false;
    }
}
