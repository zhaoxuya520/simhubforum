package cc.forserein.simhub.internal;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.WeakHashMap;

/** Isolate additional accepted legs of an already selected outgoing INVITE. */
public final class SipForkProtection {
    private static final int MAX_FORKS = 64;
    private static final int MAX_BYE_ATTEMPTS = 2;
    // Values never retain the original dialog, engine, or manager.
    private static final WeakHashMap<Object, Bucket> CACHE = new WeakHashMap<Object, Bucket>();
    private SipForkProtection() {}

    private static final class Bucket {
        final LinkedHashMap<String, Entry> forks = new LinkedHashMap<String, Entry>();
        boolean limitReported, invalidReported;
    }
    private static final class Entry {
        Object fork;
        Object bye;
        int byeAttempts;
        boolean byeSucceeded, byeInFlight, failed, reported;
    }
    private static Object field(Object object, String name) throws Exception {
        return object.getClass().getField(name).get(object);
    }
    private static void field(Object object, String name, Object value) throws Exception {
        object.getClass().getField(name).set(object, value);
    }
    private static Object call(Object target, String name, Class<?>[] types, Object... values) throws Exception {
        return target.getClass().getMethod(name, types).invoke(target, values);
    }
    private static void diagnostic(Object engine, String text) {
        try { call(field(engine, "g"), "i", new Class<?>[]{Object.class}, text); }
        catch (Exception ignored) { /* Logging must not return a fork to the selected dialog. */ }
    }
    private static void reportOnce(Object engine, Entry entry, String text) {
        synchronized (CACHE) {
            if (entry.reported) return;
            entry.reported = true;
        }
        diagnostic(engine, text);
    }
    private static Object copyMessage(Object original) throws Exception {
        Class<?> type = original.getClass();
        Constructor<?> ctor = type.getConstructor(boolean.class, String.class, String.class,
                int.class, String.class, ArrayList.class, byte[].class);
        // Native header pairs contain final String values; the list and body are independent.
        Object copy = ctor.newInstance(field(original, "a"), field(original, "b"),
                field(original, "c"), field(original, "d"), field(original, "e"),
                new ArrayList<Object>((List<?>) field(original, "f")), ((byte[]) field(original, "g")).clone());
        field(copy, "h", field(original, "h"));
        return copy;
    }
    @SuppressWarnings("unchecked")
    private static Object standardHeaders(Object response) throws Exception {
        Object normalized = response;
        for (String[] names : new String[][]{{"To", "t"}, {"Contact", "m"}, {"Call-ID", "i"}, {"From", "f"}, {"Via", "v"}}) {
            List<?> full = (List<?>) call(response, "j", new Class<?>[]{String.class}, names[0]);
            if (!full.isEmpty() && !"Via".equals(names[0])) continue;
            List<?> compact = (List<?>) call(response, "j", new Class<?>[]{String.class}, names[1]);
            if (compact.isEmpty()) continue;
            if (normalized == response) normalized = copyMessage(response);
            if ("Via".equals(names[0])) {
                // Preserve order even if direct callers mix long and compact Via names.
                List<Object> headers = (List<Object>) field(normalized, "f");
                for (int index = 0; index < headers.size(); index++) {
                    Object pair = headers.get(index);
                    if ("v".equalsIgnoreCase((String) field(pair, "T")))
                        headers.set(index, pair.getClass().getConstructor(Object.class, Object.class)
                                .newInstance("Via", field(pair, "U")));
                }
            } else for (Object value : compact)
                call(normalized, "a", new Class<?>[]{String.class, String.class}, names[0], value);
        }
        return normalized;
    }
    private static Object createFork(Object manager, Object original, Object response) throws Exception {
        if ((Integer) field(original, "i") < 0 || (Integer) field(original, "h") < 0)
            throw new IllegalArgumentException("Invalid local CSeq");
        Class<?> message = response.getClass();
        @SuppressWarnings("unchecked")
        List<String> contacts = (List<String>) call(response, "j", new Class<?>[]{String.class}, "Contact");
        if (contacts.isEmpty() || contacts.get(0).trim().length() == 0)
            throw new IllegalArgumentException("A forked 2xx requires its own Contact");
        Class<?> direction = field(original, "a").getClass();
        Class<?> state = field(original, "c").getClass();
        Constructor<?> ctor = original.getClass().getConstructor(direction, String.class, state,
                String.class, String.class, String.class, String.class, int.class, int.class, message, double.class);
        Object fork = ctor.newInstance(field(original, "a"), field(original, "b"), state.getField("W").get(null),
                field(original, "d"), field(original, "e"), field(original, "f"), "",
                Math.max((Integer) field(original, "h"), (Integer) field(original, "i")), field(original, "i"), copyMessage(field(original, "j")), field(original, "k"));
        // No selected-leg route, transaction list, timer state or SDP is copied.
        field(fork, "m", new ArrayList<Object>());
        call(manager, "b", new Class<?>[]{message, original.getClass()}, response, fork);
        String target = (String) field(fork, "g");
        if (target == null || !(target.regionMatches(true, 0, "sip:", 0, 4) || target.regionMatches(true, 0, "sips:", 0, 5)))
            throw new IllegalArgumentException("Empty fork Contact target");
        field(fork, "m", new ArrayList<Object>((List<?>) field(fork, "m")));
        return fork;
    }
    private static Object request(Object manager, Object fork, String method) throws Exception {
        return call(manager, "k", new Class<?>[]{String.class, fork.getClass(), byte[].class}, method, fork, null);
    }
    private static void send(Object engine, Object packet) throws Exception {
        call(engine, "C", new Class<?>[]{packet.getClass()}, packet);
    }

    private static Object selectedDialog(Object engine, Object message) throws Exception {
        Object manager = field(engine, "J");
        if (manager == null) return null;
        Object id = call(message, "d", new Class<?>[0]);
        Object original = ((java.util.Map<?, ?>) field(manager, "e")).get(id);
        if (original == null || field(original, "D") == null && !SipInviteSuccess.hasAccepted(engine, original)) return null;
        Object direction = field(original, "a"), state = field(original, "c");
        if (direction != direction.getClass().getField("U").get(null)) return null;
        if (state != state.getClass().getField("W").get(null)
                && state != state.getClass().getField("X").get(null)) return null;
        String selectedTag = (String) field(original, "l");
        return selectedTag == null || selectedTag.length() == 0 ? null : original;
    }
    private static String fromTag(Object message) throws Exception {
        List<?> headers = (List<?>) call(message, "j", new Class<?>[]{String.class}, "From");
        if (headers.isEmpty()) return null;
        Class<?> parser = message.getClass().getField("Companion").getType();
        return (String) parser.getMethod("b", String.class, String.class).invoke(null, "tag", headers.get(0));
    }
    private static boolean differentTag(Object original, String remoteTag) throws Exception {
        return remoteTag != null && remoteTag.length() != 0 && !remoteTag.equals(field(original, "l"));
    }
    private static boolean localTagMatches(Object original, String localTag) throws Exception {
        return localTag != null && localTag.length() != 0 && localTag.equals(field(original, "d"));
    }

    /** Isolate messages addressed to another confirmed leg before native Call-ID-only dispatch. */
    public static boolean handleRequest(Object engine, Object request, Object transport) {
        boolean identifiedFork = false;
        try {
            if (engine == null || request == null || !(Boolean) field(request, "a")) return false;
            request = standardHeaders(request);
            Object original = selectedDialog(engine, request);
            if (original == null) return false;
            String method = (String) field(request, "b");
            if ("CANCEL".equals(method)) return false; // CANCEL matches its INVITE transaction, not a dialog.
            String localTag = (String) call(request, "g", new Class<?>[0]);
            boolean dialogMethod = "INVITE".equals(method) || "BYE".equals(method) || "UPDATE".equals(method)
                    || "INFO".equals(method) || "ACK".equals(method) || "PRACK".equals(method)
                    || "REFER".equals(method) || "NOTIFY".equals(method);
            if (!dialogMethod && (localTag == null || localTag.length() == 0)) return false;
            boolean localMatches = localTagMatches(original, localTag);
            String remoteTag = fromTag(request);
            if (localMatches && field(original, "l").equals(remoteTag)) return false;
            identifiedFork = true;
            if ("ACK".equals(method)) return true; // SIP never responds to ACK.
            boolean known;
            synchronized (CACHE) {
                Bucket bucket = CACHE.get(original);
                known = bucket != null && bucket.forks.containsKey(remoteTag);
            }
            int status = known && localMatches && "BYE".equals(method) ? 200 : 481;
            Object manager = field(engine, "J");
            Class<?> transportType = Class.forName("oc2", false, engine.getClass().getClassLoader());
            Object action = manager.getClass().getMethod("m", manager.getClass(), request.getClass(),
                    int.class, String.class, transportType).invoke(null, manager, request, status,
                    status == 200 ? "OK" : "Call/Transaction Does Not Exist", transport);
            call(engine, "k", new Class<?>[]{List.class}, java.util.Collections.singletonList(action));
            return true;
        } catch (Exception failure) {
            // A malformed extra leg or dispatch failure must never terminate the selected one.
            return identifiedFork;
        }
    }

    /** True means this additional leg was consumed; ordinary responses keep the native path. */
    public static boolean handle(Object engine, Object response) {
        boolean identifiedFork = false;
        try {
            if (engine == null || response == null || (Boolean) field(response, "a")) return false;
            int status = (Integer) field(response, "d");
            Object sequence = call(response, "e", new Class<?>[0]);
            if (sequence == null) return false;
            String method = (String) field(sequence, "b");
            if (!"INVITE".equals(method) && !"BYE".equals(method)) return false;
            response = standardHeaders(response);
            Object original = selectedDialog(engine, response);
            if (original == null) return false;
            String tag = (String) call(response, "g", new Class<?>[0]);
            boolean localMatches = localTagMatches(original, fromTag(response));
            // The native response path dispatches BYE by Call-ID only. Invalid or
            // different dialog tags cannot acknowledge the selected leg's BYE.
            if ("BYE".equals(method)) return !localMatches || !field(original, "l").equals(tag);
            if (status < 200 || status >= 300 || !field(sequence, "a").equals(field(original, "i"))
                    || !differentTag(original, tag)) return false;
            identifiedFork = true;
            if (!localMatches) {
                boolean report;
                synchronized (CACHE) {
                    Bucket bucket = CACHE.get(original);
                    if (bucket == null) { bucket = new Bucket(); CACHE.put(original, bucket); }
                    report = !bucket.invalidReported;
                    bucket.invalidReported = true;
                }
                if (report) diagnostic(engine, "通话：额外分叉响应的本地标识不匹配，已隔离");
                return true;
            }
            Object manager = field(engine, "J");

            Entry entry;
            boolean reportLimit = false;
            synchronized (CACHE) {
                Bucket bucket = CACHE.get(original);
                if (bucket == null) { bucket = new Bucket(); CACHE.put(original, bucket); }
                entry = bucket.forks.get(tag);
                if (entry == null) {
                    if (bucket.forks.size() >= MAX_FORKS) {
                        reportLimit = !bucket.limitReported;
                        bucket.limitReported = true;
                    } else {
                        entry = new Entry();
                        bucket.forks.put(tag, entry);
                        try { entry.fork = createFork(manager, original, response); }
                        catch (Exception failure) { entry.failed = true; }
                    }
                }
            }
            if (entry == null) {
                if (reportLimit) diagnostic(engine, "通话：额外分叉超过处理上限，已保留当前通话");
                return true;
            }
            if (entry.failed) {
                reportOnce(engine, entry, "通话：额外分叉响应缺少有效对话信息，已保留当前通话");
                return true;
            }
            try { send(engine, request(manager, entry.fork, "ACK")); }
            catch (Exception failure) {
                reportOnce(engine, entry, "通话：额外分叉 ACK 发送失败，保留当前通话并等待重传");
                return true;
            }
            Object bye = null;
            boolean buildFailed = false;
            synchronized (CACHE) {
                if (!entry.byeSucceeded && !entry.byeInFlight && entry.byeAttempts < MAX_BYE_ATTEMPTS) {
                    try {
                        if (entry.bye == null) {
                            if ((Integer) field(entry.fork, "h") == Integer.MAX_VALUE)
                                throw new IllegalStateException("No valid next BYE CSeq");
                            entry.bye = request(manager, entry.fork, "BYE");
                        }
                        entry.byeAttempts++;
                        entry.byeInFlight = true;
                        bye = entry.bye;
                    } catch (Exception failure) { entry.byeAttempts = MAX_BYE_ATTEMPTS; buildFailed = true; }
                }
            }
            if (buildFailed) reportOnce(engine, entry, "通话：额外分叉 BYE 构造失败，当前通话保持不变");
            if (bye != null) {
                boolean succeeded = false;
                try { send(engine, bye); succeeded = true; }
                catch (Exception failure) { reportOnce(engine, entry, "通话：额外分叉 BYE 发送失败，当前通话保持不变"); }
                finally {
                    synchronized (CACHE) { entry.byeInFlight = false; entry.byeSucceeded = succeeded; }
                }
            }
            return true;
        } catch (Exception failure) {
            if (identifiedFork) diagnostic(engine, "通话：额外分叉处理失败，已隔离并保留当前通话");
            return identifiedFork;
        }
    }
}
