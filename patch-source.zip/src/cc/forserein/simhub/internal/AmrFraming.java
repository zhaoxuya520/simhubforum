package cc.forserein.simhub.internal;

/** Per-call RFC 4867 framing detection. Never retains speech or changes codec/PT. */
public final class AmrFraming {
    private static final int[] NB_BITS={95,103,118,134,148,159,204,244,39};
    private static final int[] WB_BITS={132,177,253,285,317,365,397,461,477,40};
    private final boolean wide;
    private boolean negotiated;
    private volatile boolean octetAligned;
    private int mismatches;
    private String notice;
    private boolean hasSource,hasSequence;
    private long source;
    private int sequence;

    public AmrFraming(int sampleRate,boolean octetAligned){
        if(sampleRate!=8000&&sampleRate!=16000)throw new IllegalArgumentException("AMR clock rate");
        wide=sampleRate==16000;
        this.negotiated=this.octetAligned=octetAligned;
    }
    public boolean isOctetAligned(){return octetAligned;}

    /** A repeated 183/200 SDP must not undo detection; a changed offer starts fresh. */
    public synchronized void updateNegotiation(boolean value){
        if(value!=negotiated){negotiated=octetAligned=value;mismatches=0;notice=null;hasSource=false;hasSequence=false;}
    }

    /** Repeated/reordered RTP is playable, but is not new evidence for transmit negotiation. */
    public synchronized int receive(byte[] payload,int nextSequence,long nextSource){
        nextSource&=0xffffffffL;nextSequence&=0xffff;
        if(!hasSource||source!=nextSource){
            source=nextSource;hasSource=true;hasSequence=false;
            octetAligned=negotiated;mismatches=0;notice=null;
        }
        int distance=(nextSequence-sequence)&0xffff;
        boolean fresh=!hasSequence||(distance>0&&distance<0x8000);
        if(fresh){
            if(hasSequence&&distance!=1)mismatches=0;
            sequence=nextSequence;hasSequence=true;
        }
        return receivePayload(payload,fresh);
    }

    /** -1 rejects a malformed payload; 0/1 selects the native BE/OA depacketizer. */
    public synchronized int receive(byte[] payload){
        return receivePayload(payload,true);
    }
    private int receivePayload(byte[] payload,boolean fresh){
        if(shape(payload,wide,octetAligned)>=0){if(fresh)mismatches=0;return octetAligned?1:0;}
        int alternative=shape(payload,wide,!octetAligned);
        if(alternative<0){if(fresh)mismatches=0;return -1;}
        boolean selected=!octetAligned;
        // Silence/lost frames alone are not enough evidence to change outgoing speech.
        if(fresh&&alternative>0){
            if(++mismatches>=3){
                octetAligned=selected;mismatches=0;
                notice="媒体：已确认对端 AMR 封装为 "+(selected?"octet-aligned":"bandwidth-efficient")
                    +"，收发已适配（连续 3 个语音包，负载 "+payload.length+"B）";
            }
        }else if(fresh)mismatches=0;
        // Decode the valid alternative immediately, without waiting for the send switch.
        return selected?1:0;
    }
    public synchronized String takeNotice(){String value=notice;notice=null;return value;}

    private static int bits(boolean wide,int type){
        int[] sizes=wide?WB_BITS:NB_BITS;
        if(type<sizes.length)return sizes[type];
        return type==15||(wide&&type==14)?0:-1;
    }
    private static int read(byte[] data,int position,int count){
        int result=0;
        for(int i=0;i<count;i++)result=(result<<1)|((data[(position+i)>>>3]>>>(7-((position+i)&7)))&1);
        return result;
    }
    /** Exact payload size is required: random speech bits must not become a false ToC. */
    public static int shape(byte[] data,boolean wide,boolean aligned){
        if(data==null||data.length<2||data.length>1024)return -1;
        int cursor=aligned?8:4,header=aligned?8:6,body=0,frames=0,speech=0,total=data.length*8;
        boolean more;
        do{
            if(++frames>12||cursor+header>total)return -1;
            more=read(data,cursor,1)!=0;
            int type=read(data,cursor+1,4),size=bits(wide,type);
            if(size<0)return -1;
            if(type<(wide?9:8)&&read(data,cursor+5,1)!=0)speech++;
            body+=aligned?((size+7)/8)*8:size;
            cursor+=header;
        }while(more);
        // RFC 4867 reserved and padding bits are ignored on reception. CMR never
        // selects a codec: it is only a request for the peer's encoder mode.
        return (cursor+body+7)/8==data.length?speech:-1;
    }
}
