package cc.forserein.simhub.internal;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import android.os.Bundle;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import com.gsma.services.rcs.ICommonServiceConfiguration;
import com.gsma.services.rcs.IRcsServiceRegistrationListener;
import com.gsma.services.rcs.chat.IChatMessage;
import com.gsma.services.rcs.chat.IChatService;
import com.gsma.services.rcs.chat.IChatServiceConfiguration;
import com.gsma.services.rcs.chat.IOneToOneChat;
import com.gsma.services.rcs.chat.IOneToOneChatListener;
import com.gsma.services.rcs.contact.ContactId;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/** Foreground, line-bound GSMA TAPI client. This class neither implements RCS nor falls back to SMS. */
public final class RcsChatTransport {
    public static final String SERVICE_ACTION="com.gsma.services.rcs.chat.IChatService";
    public static final String PERMISSION="com.gsma.services.permission.RCS";
    private static final String INCOMING="com.gsma.services.rcs.chat.action.NEW_ONE_TO_ONE_CHAT_MESSAGE";
    private static final int MAX_MESSAGES=200, MAX_TEXT=16384;
    public interface Listener { void onSnapshot(Snapshot value); void onFailure(String error); }
    public interface SendCallback { void onResult(SendResult result); }
    public static final class Snapshot {
        public final boolean registered,canSend;
        public final String status,localContact,providerLabel;
        public final int maxLength;
        public final List<Message> messages;
        Snapshot(boolean registered,boolean canSend,String status,String local,String provider,int max,List<Message> messages){
            this.registered=registered;this.canSend=canSend;this.status=status;this.localContact=local;this.providerLabel=provider;
            this.maxLength=max;this.messages=Collections.unmodifiableList(new ArrayList<Message>(messages));
        }
    }
    public static final class Message {
        public final String id,body,status;
        public final boolean incoming;
        public final long timestamp;
        public final int statusCode,reasonCode;
        Message(String id,String body,boolean incoming,long time,int status,int reason){
            this.id=id;this.body=body;this.incoming=incoming;this.timestamp=time;this.statusCode=status;this.reasonCode=reason;
            this.status=statusName(status);
        }
    }
    public static final class SendResult {
        public final boolean accepted,uncertain;
        public final Message message;
        public final String detail;
        SendResult(boolean accepted,boolean uncertain,Message message,String detail){
            this.accepted=accepted;this.uncertain=uncertain;this.message=message;this.detail=detail;
        }
    }
    private final Context context;
    private final RcsChatBinding binding;
    private final Listener listener;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ThreadPoolExecutor worker=new ThreadPoolExecutor(1,1,15,TimeUnit.SECONDS,
        new ArrayBlockingQueue<Runnable>(64),r->{Thread t=new Thread(r,"SimHub-RCS");t.setDaemon(true);return t;});
    private final Map<String,Message> messages=new LinkedHashMap<String,Message>();
    private volatile boolean closed,connecting,registered,sending,uncertain;
    private volatile long epoch;
    private volatile Session session;
    private String local="",providerLabel="";
    private int maxLength=MAX_TEXT;

    public RcsChatTransport(Context context,RcsChatBinding binding,Listener listener){
        if(context==null||binding==null||listener==null)throw new UserFailure("RCS 会话参数不完整");
        Context app=context.getApplicationContext();this.context=app==null?context:app;this.binding=binding;this.listener=listener;worker.allowCoreThreadTimeOut(true);
    }
    private boolean current(long token){return !closed&&epoch==token;}
    private synchronized long begin(){if(closed||connecting||session!=null)return -1;connecting=true;return ++epoch;}
    private void enqueue(Runnable work){try{worker.execute(work);}catch(RejectedExecutionException ignored){}}

    /** Only user-initiated connect/refresh may bind; there is no automatic rebind or resend. */
    public void connect(){
        final long token=begin();if(token<0)return;
        postSnapshot(token,new Snapshot(false,false,"正在连接设备 RCS 服务","","",MAX_TEXT,Collections.<Message>emptyList()));
        enqueue(()->{
            try{
                binding.validateCurrent();
                messages.clear();local="";providerLabel="";
                PackageManager pm=context.getPackageManager();
                List<ResolveInfo> resolved=pm.queryIntentServices(new Intent(SERVICE_ACTION),0);
                ServiceInfo selected=null;
                for(ResolveInfo candidate:resolved){
                    ServiceInfo info=candidate.serviceInfo;
                    if(!trusted(info))continue;
                    if(selected!=null&&!new ComponentName(selected.packageName,selected.name).equals(new ComponentName(info.packageName,info.name)))
                        throw new UserFailure("设备上有多个可信 RCS 服务，无法确认当前线路");
                    selected=info;
                }
                if(selected==null)throw new UserFailure("设备未提供可供本应用使用的系统 RCS 服务");
                if(context.checkSelfPermission(PERMISSION)!=PackageManager.PERMISSION_GRANTED)
                    throw new UserFailure("设备未授予 RCS 服务访问权限");
                PermissionInfo permission=pm.getPermissionInfo(PERMISSION,0);
                String owner=permission.packageName;
                if(!selected.packageName.equals(owner)&&!"android".equals(owner))
                    throw new UserFailure("RCS 权限的来源与系统服务不匹配");
                final ServiceInfo chosen=selected;
                final String label=String.valueOf(chosen.loadLabel(pm));
                main.post(()->compatibility(token,chosen,label));
            }catch(Exception error){failSession(token,safeError(error,"RCS 服务不可用"));}
        });
        main.postDelayed(()->{if(current(token)&&connecting)failSession(token,"连接 RCS 服务超时，请稍后刷新");},10000);
    }
    private static boolean trusted(ServiceInfo info){
        if(info==null||!info.enabled||!info.exported||!PERMISSION.equals(info.permission)||info.applicationInfo==null||!info.applicationInfo.enabled)return false;
        return (info.applicationInfo.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0;
    }
    private void compatibility(long token,ServiceInfo info,String label){
        if(!current(token))return;
        try{
            binding.validateCurrent();
            Intent query=new Intent("com.gsma.services.rcs.action.GET_COMPATIBILITY").setPackage(info.packageName)
                .addFlags(Intent.FLAG_RECEIVER_FOREGROUND|Intent.FLAG_EXCLUDE_STOPPED_PACKAGES);
            query.putExtra("get_compatibility_service","ChatService");
            query.putExtra("get_compatibility_codename","GSMA");
            query.putExtra("get_compatibility_version",2);
            query.putExtra("get_compatibility_increment",0);
            // Match the public API's compatibility handshake before making version-dependent transactions.
            context.sendOrderedBroadcast(query,null,new BroadcastReceiver(){
                public void onReceive(Context ignored,Intent intent){
                    if(!current(token))return;
                    Bundle result=getResultExtras(false);
                    if(result==null||!result.getBoolean("get_compatibility_response",false)){
                        failSession(token,"系统 RCS 服务与此 GSMA 接口不兼容");return;
                    }
                    bind(token,info,label);
                }
            },main,-1,null,null);
        }catch(Exception error){failSession(token,"无法核对系统 RCS 接口兼容性");}
    }
    private void bind(long token,ServiceInfo info,String label){
        if(!current(token))return;
        try{
            binding.validateCurrent();
            ServiceInfo fresh=context.getPackageManager().getServiceInfo(new ComponentName(info.packageName,info.name),0);
            if(!trusted(fresh)||fresh.applicationInfo.uid!=info.applicationInfo.uid)
                throw new UserFailure("系统 RCS 服务已更换，请刷新");
            Session next=new Session(token,info.applicationInfo.uid,label,new ComponentName(info.packageName,info.name));
            session=next;
            next.bound=context.bindService(new Intent(SERVICE_ACTION).setComponent(next.component),next,Context.BIND_AUTO_CREATE);
            if(!next.bound)throw new UserFailure("系统 RCS 服务拒绝连接");
        }catch(Exception error){failSession(token,safeError(error,"无法连接 RCS 服务"));}
    }
    private final class Session implements ServiceConnection,IBinder.DeathRecipient {
        final long token;final int uid;final String label;final ComponentName component;
        volatile boolean bound,receiverAdded,registrationAdded,messageListenerAdded;
        volatile IChatService api;
        volatile IBinder binder;
        volatile long openedAt;
        String localNumber;
        final IRcsServiceRegistrationListener registrationListener=new IRcsServiceRegistrationListener.Stub(){
            public void onServiceRegistered(){if(current(token))refresh();}
            public void onServiceUnregistered(int reason){failSession(token,"RCS 服务已离线，请重新连接");}
        };
        final IOneToOneChatListener messageListener=new IOneToOneChatListener.Stub(){
            public void onMessageStatusChanged(ContactId contact,String mime,String id,int status,int reason){
                if(contact!=null&&binding.peer.equals(contact.toString())&&validId(id)&&"text/plain".equalsIgnoreCase(mime))
                    enqueue(()->updateKnown(Session.this,id));
            }
            public void onComposingEvent(ContactId contact,boolean composing){}
            public void onMessagesDeleted(ContactId contact,List<String> ids){
                if(contact==null||!binding.peer.equals(contact.toString())||ids==null)return;
                final List<String> copy=new ArrayList<String>(ids.size()>MAX_MESSAGES?ids.subList(0,MAX_MESSAGES):ids);
                enqueue(()->{if(!current(token))return;try{verify(Session.this);for(String id:copy)messages.remove(id);publish(Session.this);}catch(Exception error){failSession(token,safeError(error,"RCS 线路已失效"));}});
            }
        };
        final BroadcastReceiver receiver=new BroadcastReceiver(){
            public void onReceive(Context ignored,Intent intent){
                if(!current(token)||intent==null||!INCOMING.equals(intent.getAction()))return;
                if(Build.VERSION.SDK_INT>=34){int sender=getSentFromUid();if(sender>=0&&sender!=uid)return;}
                String id;
                try{id=intent.getStringExtra("messageId");}catch(RuntimeException badExtra){return;}
                if(validId(id))enqueue(()->incoming(Session.this,id));
            }
        };
        Session(long token,int uid,String label,ComponentName component){this.token=token;this.uid=uid;this.label=label;this.component=component;}
        public void onServiceConnected(ComponentName name,IBinder service){
            if(!current(token)||!component.equals(name))return;
            binder=service;
            enqueue(()->{
                try{
                    if(!current(token))return;
                    if(!SERVICE_ACTION.equals(service.getInterfaceDescriptor()))throw new UserFailure("RCS 服务接口不兼容");
                    api=IChatService.Stub.asInterface(service);
                    if(api==null||api.getServiceVersion()!=2)throw new UserFailure("设备 RCS 服务不支持所需 GSMA 接口版本");
                    service.linkToDeath(this,0);
                    verify(this);
                    openedAt=System.currentTimeMillis();
                    registrationAdded=true;api.addEventListener(registrationListener);
                    messageListenerAdded=true;api.addEventListener2(messageListener);
                    verify(this);
                    connecting=false;registered=true;providerLabel=label;
                    main.post(()->registerReceiver(this));
                    publish(this);
                }catch(Exception error){failSession(token,safeError(error,"RCS 服务未就绪"));}
            });
        }
        public void onServiceDisconnected(ComponentName name){failSession(token,"RCS 服务连接已断开，请刷新");}
        public void onBindingDied(ComponentName name){failSession(token,"RCS 服务已更新，请重新连接");}
        public void onNullBinding(ComponentName name){failSession(token,"设备 RCS 服务未开放连接");}
        public void binderDied(){failSession(token,"RCS 服务连接已断开，请刷新");}
    }
    private void registerReceiver(Session value){
        if(!current(value.token))return;
        try{
            IntentFilter filter=new IntentFilter(INCOMING);
            if(Build.VERSION.SDK_INT>=33)context.registerReceiver(value.receiver,filter,PERMISSION,main,Context.RECEIVER_EXPORTED);
            else context.registerReceiver(value.receiver,filter,PERMISSION,main);
            value.receiverAdded=true;
        }catch(Exception error){failSession(value.token,"无法监听设备 RCS 消息");}
    }
    /** Re-check the selected physical line and the provider's *current registered* public identity. */
    private String verify(Session value)throws Exception{
        if(!current(value.token)||session!=value||value.api==null)throw new UserFailure("RCS 会话已结束");
        binding.validateCurrent();
        if(!value.api.isServiceRegistered())throw new UserFailure("设备 RCS 服务尚未注册");
        ICommonServiceConfiguration common=value.api.getCommonConfiguration();
        if(common==null||!common.isConfigValid())throw new UserFailure("设备 RCS 配置尚未生效");
        ContactId own=common.getMyContactId();String number=own==null?"":own.toString();
        binding.validateProvider(number);
        if(value.localNumber==null)value.localNumber=number;
        else if(!value.localNumber.equals(number))throw new UserFailure("RCS 注册号码已更换，请重新打开会话");
        if(!current(value.token))throw new UserFailure("RCS 会话已结束");
        local=number;return number;
    }
    private IOneToOneChat chat(Session value)throws Exception{
        verify(value);
        IOneToOneChat chat=value.api.getOneToOneChat(contact(binding.peer));
        if(chat==null||chat.getRemoteContact()==null||!binding.peer.equals(chat.getRemoteContact().toString()))
            throw new UserFailure("RCS 服务返回了不匹配的联系人");
        return chat;
    }
    private static ContactId contact(String number){
        Parcel parcel=Parcel.obtain();try{parcel.writeString(number);parcel.setDataPosition(0);return ContactId.CREATOR.createFromParcel(parcel);}finally{parcel.recycle();}
    }
    public void refresh(){
        if(closed)return;
        Session value=session;if(value==null){connect();return;}
        if(connecting)return;
        enqueue(()->{if(!current(value.token))return;try{
            verify(value);
            for(String id:new ArrayList<String>(messages.keySet())){
                IChatMessage remote=value.api.getChatMessage(id);
                Message updated=read(value,remote,id,false);if(updated!=null)messages.put(id,updated);
            }
            publish(value);
        }catch(Exception error){failSession(value.token,safeError(error,"无法刷新 RCS 状态"));}});
    }
    private void publish(Session value)throws Exception{
        verify(value);
        IChatServiceConfiguration config=value.api.getConfiguration();
        int advertised=config==null?0:config.getOneToOneChatMessageMaxLength();
        maxLength=advertised>0?Math.min(advertised,MAX_TEXT):MAX_TEXT;
        boolean allowed=chat(value).isAllowedToSendMessage();
        verify(value);registered=true;
        String text=uncertain?"发送结果未确认；本次会话暂停发送，请先确认对方是否已收到":allowed?"RCS 已连接": "对方或当前服务暂不允许发送 RCS";
        postSnapshot(value.token,new Snapshot(true,allowed&&!sending&&!uncertain,text,local,providerLabel,maxLength,new ArrayList<Message>(messages.values())));
    }
    public void send(String text,SendCallback callback){
        if(callback==null)throw new UserFailure("缺少发送回调");
        final Session value=session;
        synchronized(this){
            if(closed)return;
            if(value==null||connecting||!registered||sending||uncertain){result(epoch,callback,new SendResult(false,uncertain,null,"当前 RCS 会话不能发送"));return;}
            sending=true;
        }
        final long token=value.token;
        try{worker.execute(()->{
            boolean submitted=false;
            SendResult outcome;
            try{
                if(text==null||text.trim().isEmpty())throw new UserFailure("请输入消息内容");
                IOneToOneChat chat=chat(value);
                IChatServiceConfiguration config=value.api.getConfiguration();
                int advertised=config==null?0:config.getOneToOneChatMessageMaxLength();
                int limit=advertised>0?Math.min(advertised,MAX_TEXT):MAX_TEXT;
                if(text.length()>limit||text.getBytes(StandardCharsets.UTF_8).length>limit)
                    throw new UserFailure("消息超出 RCS 服务允许的 UTF-8 字节长度");
                if(!chat.isAllowedToSendMessage())throw new UserFailure("对方或当前服务暂不允许发送 RCS");
                verify(value); // immediately before the only write; no retry follows any ambiguous result
                submitted=true;
                IChatMessage remote=chat.sendMessage(text);
                Message sent=read(value,remote,null,false);
                if(sent==null||sent.incoming||!text.equals(sent.body))throw new UserFailure("RCS 服务没有返回可核对的消息记录");
                remember(sent);
                boolean accepted=sent.statusCode!=0&&sent.statusCode!=4;
                sending=false;
                outcome=new SendResult(accepted,false,sent,accepted?sent.status:"RCS 服务未接受此消息");
            }catch(Exception error){
                sending=false;
                if(submitted)uncertain=true;
                outcome=new SendResult(false,submitted,null,submitted?"消息可能已提交，尚未确认结果；请先确认对方是否已收到，勿重复发送":safeError(error,"RCS 发送失败"));
            }
            // A later status refresh failure cannot turn one known submission into a second send result.
            result(token,callback,outcome);
            try{publish(value);}catch(Exception invalid){failSession(token,safeError(invalid,"RCS 线路已失效"));}
        });}catch(RejectedExecutionException busy){sending=false;result(token,callback,new SendResult(false,false,null,"RCS 操作繁忙，请稍后再试"));}
    }
    private Message read(Session value,IChatMessage remote,String expectedId,boolean incoming)throws Exception{
        if(remote==null)return null;
        verify(value);
        String id=remote.getId();ContactId peer=remote.getContact();String mime=remote.getMimeType();
        int direction=remote.getDirection();long time=remote.getTimestamp();
        if(!validId(id)||(expectedId!=null&&!expectedId.equals(id))||peer==null||!binding.peer.equals(peer.toString())
                ||!"text/plain".equalsIgnoreCase(mime)||(direction!=0&&direction!=1)||time<value.openedAt||time>System.currentTimeMillis()||(incoming&&direction!=0))return null;
        String body=remote.getContent();if(body==null||body.length()>MAX_TEXT)return null;
        int status=remote.getStatus(),reason=remote.getReasonCode();
        if(status<0||status>8||(direction==1&&(status==6||status==7)))return null;
        verify(value);
        return new Message(id,body,direction==0,time,status,reason);
    }
    private void incoming(Session value,String id){
        if(!current(value.token)||messages.containsKey(id))return;
        try{
            verify(value);
            IChatMessage remote;
            try{remote=value.api.getChatMessage(id);}catch(Exception unavailable){return;}
            Message message=read(value,remote,id,true);
            if(message==null)return;
            remember(message);publish(value);
        }catch(Exception error){if(current(value.token))failSession(value.token,safeError(error,"RCS 消息暂不可用"));}
    }
    private void updateKnown(Session value,String id){
        if(!current(value.token)||!messages.containsKey(id))return;
        try{verify(value);Message message=read(value,value.api.getChatMessage(id),id,false);if(message!=null)remember(message);publish(value);}
        catch(Exception error){failSession(value.token,safeError(error,"RCS 消息状态暂不可用"));}
    }
    private void remember(Message message){messages.put(message.id,message);while(messages.size()>MAX_MESSAGES)messages.remove(messages.keySet().iterator().next());}
    private static boolean validId(String id){return id!=null&&!id.isEmpty()&&id.length()<=256&&id.indexOf('\n')<0&&id.indexOf('\r')<0;}
    private void postSnapshot(long token,Snapshot snapshot){main.post(()->{
        if(!current(token))return;
        try{binding.validateCurrent();listener.onSnapshot(snapshot);}catch(IllegalStateException changed){failSession(token,safeError(changed,"卡片已更换"));}
    });}
    private void result(long token,SendCallback callback,SendResult result){main.post(()->{if(current(token)){try{binding.validateCurrent();callback.onResult(result);}catch(IllegalStateException changed){failSession(token,safeError(changed,"卡片已更换"));}}});}
    private void failSession(long token,String reason){
        final Session previous;final long next;
        synchronized(this){if(!current(token))return;next=++epoch;previous=session;session=null;connecting=false;registered=false;sending=false;}
        teardown(previous);
        enqueue(()->{if(!current(next))return;messages.clear();local="";providerLabel="";});
        main.post(()->{if(!current(next))return;listener.onSnapshot(new Snapshot(false,false,reason,"","",MAX_TEXT,Collections.<Message>emptyList()));listener.onFailure(reason);});
    }
    private void teardown(Session previous){
        if(previous==null)return;
        main.post(()->{
            if(previous.receiverAdded){previous.receiverAdded=false;try{context.unregisterReceiver(previous.receiver);}catch(RuntimeException ignored){}}
            if(previous.bound){previous.bound=false;try{context.unbindService(previous);}catch(RuntimeException ignored){}}
        });
        IBinder binder=previous.binder;if(binder!=null)try{binder.unlinkToDeath(previous,0);}catch(RuntimeException ignored){}
        enqueue(()->{IChatService api=previous.api;previous.api=null;if(api!=null){
            if(previous.registrationAdded)try{api.removeEventListener(previous.registrationListener);}catch(Exception ignored){}
            if(previous.messageListenerAdded)try{api.removeEventListener2(previous.messageListener);}catch(Exception ignored){}
        }});
    }
    public void close(){
        Session previous;
        synchronized(this){if(closed)return;closed=true;++epoch;previous=session;session=null;connecting=false;registered=false;sending=false;worker.getQueue().clear();}
        teardown(previous);enqueue(()->messages.clear());worker.shutdown();
    }
    private static final class UserFailure extends IllegalStateException {
        private static final long serialVersionUID=1L;
        UserFailure(String message){super(message);}
    }
    private static String safeError(Exception error,String fallback){
        // A remote exception may include subscriber identifiers or text; only locally owned errors are shown.
        if(error instanceof UserFailure)return error.getMessage();
        String text=error.getMessage();
        if(error instanceof IllegalStateException&&(
            "当前卡尚无可核对的 IMS 注册号码".equals(text)||"未能核对当前卡的系统线路或 IMS 注册号码".equals(text)||"卡片或 IMS 连接已更换，请重新打开 RCS 会话".equals(text)
            ||"请先读取卡片".equals(text)||"请先读取含完整 ICCID 的卡片".equals(text)
            ||"RCS 服务的号码与当前卡已注册的号码不匹配".equals(text)))return text;
        return fallback;
    }
    private static String statusName(int value){switch(value){
        case 0:return "已拒绝";case 1:return "排队中";case 2:return "发送中";case 3:return "已发送";
        case 4:return "发送失败";case 5:return "已送达";case 6:return "已收到";case 7:return "已收到";case 8:return "已读";default:return "状态未知";
    }}
}
