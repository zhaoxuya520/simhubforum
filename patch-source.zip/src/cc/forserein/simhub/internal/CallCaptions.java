package cc.forserein.simhub.internal;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Arrays;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/** Shares the dialer preference and isolates each remote media stream and language selection. */
public final class CallCaptions {
    private static final String DEFAULT_TARGET = "zh-Hans";
    private static final String[] LANGUAGES = {
        DEFAULT_TARGET, "zh-Hant", "en", "ja", "ko", "fr", "de", "es", "it", "pt",
        "nl", "pl", "ru", "uk", "cs", "da", "el", "fi", "hu", "no", "ro", "sv",
        "bg", "ca", "et", "hr", "lt", "lv", "sk", "sl", "sr", "tr",
        "ar", "fa", "he", "hi", "bn", "gu", "kn", "ml", "mr", "ne", "pa", "ta", "te", "ur",
        "fil", "id", "km", "lo", "ms", "my", "th", "vi", "af", "am", "sw", "yue-Hant"
    };
    private static final Object LOCK = new Object();
    private static final Executor SETUP = Executors.newSingleThreadExecutor(r -> {
        Thread worker = new Thread(r, "SIMHub-caption-setup");
        worker.setDaemon(true);
        return worker;
    });
    private static Context application;
    private static Object owner;
    private static int rate;
    private static long revision;
    private static volatile Stream current;
    private static volatile Display display = new Display("", "", "", 0);

    /** One renderable update. The utterance changes even if a speaker repeats the same words. */
    public static final class Display {
        public final String current, previous, status;
        public final long utterance;

        private Display(String current, String previous, String status, long utterance) {
            this.current = current;
            this.previous = previous;
            this.status = status;
            this.utterance = utterance;
        }

        private Display withStatus(String value) {
            return new Display(current, previous, value, utterance);
        }
    }

    private CallCaptions() {}

    public static String[] targetCodes() { return LANGUAGES.clone(); }
    public static Display display() { return display; }
    public static String subtitle() { return display.current; }
    public static String previousSubtitle() { return display.previous; }
    public static String status() { return display.status; }
    public static String privacyNotice() { return "开启后，对方语音经配对服务器发送至 Google。启用同传后，听筒或扬声器将播放所选语言的译音。"; }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences("call_caption_settings", Context.MODE_PRIVATE);
    }
    public static boolean enabled(Context context) {
        return "on".equals(prefs(context).getString("enabled", ""));
    }
    public static String target(Context context) {
        String code = prefs(context).getString("target", DEFAULT_TARGET);
        return Arrays.asList(LANGUAGES).contains(code) ? code : DEFAULT_TARGET;
    }
    public static boolean hasKey(Context context) { return CaptionKeyStore.has(context); }

    public static boolean voice(Context context) {
        return "on".equals(prefs(context).getString("voice", "off"));
    }
    public static void setVoice(Context context, boolean on) {
        if (on == voice(context)) return;
        store(context, "voice", on ? "on" : "off");
        synchronized (LOCK) { restartLocked(); }
    }
    public static void render(Object source, short[] frame) {
        Stream stream = current;
        if (stream!=null && source==stream.owner) stream.backend.render(frame);
    }

    public static void setEnabled(Context context, boolean enable) {
        if (enabled(context) == enable) return;
        store(context, "enabled", enable ? "on" : "off");
        synchronized (LOCK) { restartLocked(); }
    }
    public static void setTarget(Context context, String code) {
        if (!Arrays.asList(LANGUAGES).contains(code)) throw new IllegalArgumentException("请选择字幕语言");
        if (code.equals(target(context))) return;
        store(context, "target", code);
        synchronized (LOCK) { restartLocked(); }
    }
    public static void setKey(Context context, String input) {
        try {
            CaptionKeyStore.write(context, input == null ? "" : input.trim());
        } catch (IllegalArgumentException badKey) {
            throw new IllegalArgumentException("请检查中转配对链接格式");
        } catch (Exception storage) {
            throw new IllegalStateException("无法在此设备安全保存配对链接，请重试");
        }
        synchronized (LOCK) { restartLocked(); }
    }
    private static void store(Context context, String name, String value) {
        if (!prefs(context).edit().putString(name, value).commit())
            throw new IllegalStateException("通话翻译设置保存失败");
    }

    public static void mediaStarted(Object next, Context context, int sampleRate) {
        if (next == null || context == null || (sampleRate != 8000 && sampleRate != 16000)) return;
        synchronized (LOCK) {
            if (owner == next && rate == sampleRate) return;
            owner = next;
            application = context.getApplicationContext();
            rate = sampleRate;
            restartLocked();
        }
    }
    /** Called on playout's real-time thread. The backend copies or drops the frame immediately. */
    public static void remotePcm(Object source, short[] pcm) {
        Stream stream = current;
        if (stream != null && source == stream.owner)
            stream.backend.offer(pcm, 0, pcm == null ? 0 : pcm.length);
    }
    public static void mediaStopped(Object source) {
        synchronized (LOCK) {
            if (owner != source) return;
            owner = null;
            application = null;
            rate = 0;
            restartLocked();
        }
    }

    private static void restartLocked() {
        long ticket = ++revision;
        Stream old = current;
        current = null;
        display = new Display("", "", "", display.utterance);
        if (old != null) old.backend.close();
        Context context = application;
        Object source = owner;
        int sampleRate = rate;
        if (source != null && context != null) SETUP.execute(() -> open(ticket, context, source, sampleRate));
    }

    private static void open(long ticket, Context context, Object source, int sampleRate) {
        try {
            synchronized (LOCK) { if (ticket != revision) return; }
            if (!enabled(context)) return;
            String key = CaptionKeyStore.read(context);
            if (key.isEmpty()) {
                setStatus(ticket, "请在通话翻译设置中填写服务器配对链接");
                return;
            }
            String language = target(context);
            synchronized (LOCK) {
                if (ticket != revision) return;
                Stream stream = new Stream(ticket, source, key, language, sampleRate);
                if (voice(context)) {
                    if (language.equals("yue-Hant")) {
                        display = display.withStatus("粤语暂时只支持字幕，请关闭播放译音或改选其他语言");
                        return;
                    }
                    stream.backend.enableVoice(key,language.equals("pt") ? "pt-PT" : language);
                }
                current = stream;
                stream.backend.start();
            }
        } catch (Exception error) {
            synchronized (LOCK) {
                if (ticket == revision) {
                    Stream failed = current;
                    current = null;
                    if (failed != null) failed.backend.close();
                    display = display.withStatus("字幕服务未能启动，请检查翻译设置和配对链接");
                }
            }
        }
    }

    private static void setStatus(long ticket, String value) {
        synchronized (LOCK) { if (revision == ticket) display = display.withStatus(value); }
    }
    private static final class Stream implements CaptionBackend.Listener {
        final Object owner;
        final long ticket;
        final CaptionBackend backend;
        boolean partial;

        Stream(long ticket, Object owner, String key, String language, int rate) {
            this.ticket = ticket;
            this.owner = owner;
            backend = new CaptionBackend(key, language, rate, this);
        }
        public void onReady() { setStatus(ticket, "等待对方说话…"); }
        public void onPartial(String text) { publish(text,true); }
        public void onText(String text) { publish(text,false); }
        private void publish(String text, boolean more) {
            if (text == null) return;
            String translated = text.trim();
            if (translated.isEmpty()) return;
            synchronized (LOCK) {
                if (current != this) return;
                display = new Display(translated, partial ? display.previous : display.current, "",
                        partial ? display.utterance : display.utterance + 1);
                partial = more;
            }
        }
        public void onError(String safeMessage) {
            synchronized (LOCK) {
                if (current != this) return;
                ++revision;
                current = null;
                display = display.withStatus(safeMessage);
            }
            backend.close();
        }
    }
}
