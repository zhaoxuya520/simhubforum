package cc.forserein.simhub.internal;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Arrays;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/** Shares the dialer preference and isolates each remote media stream and language selection. */
public final class CallCaptions {
    private static final String DEFAULT_TARGET = "zh-Hans";
    private static final String[] LANGUAGES = {
        DEFAULT_TARGET, "zh-Hant", "en", "ja", "ko", "fr", "de", "es", "it", "pt",
        "nl", "pl", "ru", "uk", "cs", "da", "el", "fi", "hu", "no", "ro", "sv",
        "bg", "ca", "et", "hr", "lt", "lv", "sk", "sl", "sr", "tr",
        "ar", "fa", "he", "hi", "bn", "gu", "kn", "ml", "mr", "ne", "pa", "ta", "te", "ur",
        "fil", "id", "km", "lo", "ms", "my", "th", "vi", "af", "am", "sw", "yue-Hant"
    };
    private static final Object LOCK = new Object();
    private static final Executor SETUP = Executors.newSingleThreadExecutor(r -> {
        Thread worker = new Thread(r, "SIMHub-caption-setup");
        worker.setDaemon(true);
        return worker;
    });
    private static Context application;
    private static Object owner;
    private static int rate;
    private static long revision;
    private static volatile Stream current;
    private static volatile String line = "", previous = "", message = "";

    private CallCaptions() {}

    public static String[] targetCodes() { return LANGUAGES.clone(); }
    public static String subtitle() { return line; }
    public static String previousSubtitle() { return previous; }
    public static String status() { return message; }
    public static String privacyNotice() { return "开启后，对方语音将发送至 Google Gemini 生成字幕，费用按你的 API 账户计算。"; }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences("call_caption_settings", Context.MODE_PRIVATE);
    }
    public static boolean enabled(Context context) {
        return "on".equals(prefs(context).getString("enabled", ""));
    }
    public static String target(Context context) {
        String code = prefs(context).getString("target", DEFAULT_TARGET);
        return Arrays.asList(LANGUAGES).contains(code) ? code : DEFAULT_TARGET;
    }
    public static boolean hasKey(Context context) { return CaptionKeyStore.has(context); }

    public static void setEnabled(Context context, boolean enable) {
        if (enabled(context) == enable) return;
        store(context, "enabled", enable ? "on" : "off");
        synchronized (LOCK) { restartLocked(); }
    }
    public static void setTarget(Context context, String code) {
        if (!Arrays.asList(LANGUAGES).contains(code)) throw new IllegalArgumentException("请选择字幕语言");
        if (code.equals(target(context))) return;
        store(context, "target", code);
        synchronized (LOCK) { restartLocked(); }
    }
    public static void setKey(Context context, String input) {
        try {
            CaptionKeyStore.write(context, input == null ? "" : input.trim());
        } catch (IllegalArgumentException badKey) {
            throw new IllegalArgumentException("请检查 Gemini API 密钥格式");
        } catch (Exception storage) {
            throw new IllegalStateException("无法在此设备安全保存密钥，请重试");
        }
        synchronized (LOCK) { restartLocked(); }
    }
    private static void store(Context context, String name, String value) {
        if (!prefs(context).edit().putString(name, value).commit())
            throw new IllegalStateException("通话翻译设置保存失败");
    }

    public static void mediaStarted(Object next, Context context, int sampleRate) {
        if (next == null || context == null || (sampleRate != 8000 && sampleRate != 16000)) return;
        synchronized (LOCK) {
            if (owner == next && rate == sampleRate) return;
            owner = next;
            application = context.getApplicationContext();
            rate = sampleRate;
            restartLocked();
        }
    }
    /** Called on playout's real-time thread. The backend copies or drops the frame immediately. */
    public static void remotePcm(Object source, short[] pcm) {
        Stream stream = current;
        if (stream != null && source == stream.owner)
            stream.backend.offer(pcm, 0, pcm == null ? 0 : pcm.length);
    }
    public static void mediaStopped(Object source) {
        synchronized (LOCK) {
            if (owner != source) return;
            owner = null;
            application = null;
            rate = 0;
            restartLocked();
        }
    }

    private static void restartLocked() {
        long ticket = ++revision;
        Stream old = current;
        current = null;
        line = previous = message = "";
        if (old != null) old.backend.close();
        Context context = application;
        Object source = owner;
        int sampleRate = rate;
        if (source != null && context != null) SETUP.execute(() -> open(ticket, context, source, sampleRate));
    }

    private static void open(long ticket, Context context, Object source, int sampleRate) {
        try {
            synchronized (LOCK) { if (ticket != revision) return; }
            if (!enabled(context)) return;
            String key = CaptionKeyStore.read(context);
            if (key.isEmpty()) {
                setStatus(ticket, "请在通话翻译设置中填写 Gemini API 密钥");
                return;
            }
            String language = target(context);
            synchronized (LOCK) {
                if (ticket != revision) return;
                Stream stream = new Stream(ticket, source, key, language, sampleRate);
                current = stream;
                stream.backend.start();
            }
        } catch (Exception error) {
            synchronized (LOCK) {
                if (ticket == revision) {
                    Stream failed = current;
                    current = null;
                    if (failed != null) failed.backend.close();
                    message = "字幕服务未能启动，请检查翻译设置和密钥";
                }
            }
        }
    }

    private static void setStatus(long ticket, String value) {
        synchronized (LOCK) { if (revision == ticket) message = value; }
    }
    private static final class Stream implements CaptionBackend.Listener {
        final Object owner;
        final long ticket;
        final CaptionBackend backend;

        Stream(long ticket, Object owner, String key, String language, int rate) {
            this.ticket = ticket;
            this.owner = owner;
            backend = new CaptionBackend(key, language, rate, this);
        }
        public void onReady() { setStatus(ticket, "等待对方说话…"); }
        public void onText(String text) {
            if (text == null || text.trim().isEmpty()) return;
            synchronized (LOCK) {
                if (current != this) return;
                previous = line;
                line = text.trim();
                message = "";
            }
        }
        public void onError(String safeMessage) {
            synchronized (LOCK) {
                if (current != this) return;
                ++revision;
                current = null;
                message = safeMessage;
            }
            backend.close();
        }
    }
}
