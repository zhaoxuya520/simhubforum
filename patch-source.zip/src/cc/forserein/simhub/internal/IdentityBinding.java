package cc.forserein.simhub.internal;

import java.util.*;
import java.lang.ref.WeakReference;
import android.util.Log;

/** Binds physical identity evidence and publishes only the newest Wi-Fi Calling read. */
public final class IdentityBinding {
    private static final class Selection {
        final String eid,iccid;final boolean managed;
        final Map<String,String> providers;
        Selection(String eid,String iccid,boolean managed,Map<String,String> providers){
            this.eid=eid;this.iccid=iccid;this.managed=managed;
            this.providers=Collections.unmodifiableMap(new HashMap<>(providers));
        }
    }
    private static final class Read {
        final WeakReference<Object> transport;
        final Selection selection;
        Read(Object transport,Selection selection){this.transport=new WeakReference<>(transport);this.selection=selection;}
    }
    private static final Map<Object,Selection> selections=new WeakHashMap<>();
    private static final Map<Object,Read> reads=new WeakHashMap<>();
    // zl5 has one shared card/config state even when reads use different transports.
    // This is publication ownership, not a lock around APDU or transport operations.
    private static WeakReference<Object> activeTransport=new WeakReference<>(null);
    private static WeakReference<Object> activeAuth=new WeakReference<>(null);
    private static boolean validIccid(String value){return value!=null&&value.matches("[0-9]{19,20}");}
    private static String provider(Object profile)throws Exception {
        Object value=get(profile,"d");
        return value instanceof String?((String)value).trim().replaceAll("\\s+"," ").toLowerCase(Locale.ROOT):null;
    }
    public static synchronized void track(Object transport,Object controller){
        if(transport==null)return;
        try {
            String eid=String.valueOf(call(controller,"r")),expected=null;
            List<?> chips=(List<?>)call(controller,"l");
            Map<String,String> providers=new HashMap<>();Set<String> conflicts=new HashSet<>();
            for(Object chip:chips) {
                boolean selected=eid.equals(get(chip,"b"));
                for(Object p:(List<?>)get(chip,"d")) {
                    Object value=get(p,"a");String iccid=value instanceof String?(String)value:null;
                    if(selected&&Boolean.TRUE.equals(get(p,"b")))expected=iccid;
                    if(!validIccid(iccid))continue;
                    String provider=provider(p);
                    if(providers.containsKey(iccid)&&!Objects.equals(providers.get(iccid),provider))conflicts.add(iccid);
                    else providers.put(iccid,provider);
                }
            }
            for(String iccid:conflicts)providers.remove(iccid);
            selections.put(transport,new Selection(eid,expected,!chips.isEmpty(),providers));
        }catch(Exception e){selections.put(transport,new Selection(null,null,true,Collections.<String,String>emptyMap()));}
    }
    /** Copy values, not a weak controller reference, before the first asynchronous APDU. */
    public static synchronized void begin(Object transport,Object auth){
        Selection selection=selections.get(transport);
        reads.put(auth,new Read(transport,selection));
        activeTransport=new WeakReference<>(transport);activeAuth=new WeakReference<>(auth);
    }
    public static synchronized boolean current(Object transport,Object auth){
        return transport!=null&&auth!=null&&activeTransport.get()==transport&&activeAuth.get()==auth;
    }
    /** Stop an old continuation before native disconnect/selection clears shared state. */
    public static synchronized void invalidate(){activeTransport.clear();activeAuth.clear();}
    public static synchronized boolean publish(Object transport,Object auth,Object flow,Object expected,Object updated)throws Exception {
        if(!current(transport,auth))return false;
        return Boolean.TRUE.equals(flow.getClass().getMethod("h",Object.class,Object.class).invoke(flow,expected,updated));
    }
    public static synchronized boolean publishError(Object transport,Object auth,Object flow,Object expected,Object updated)throws Exception {
        if(!current(transport,auth))return false;
        return Boolean.TRUE.equals(flow.getClass().getMethod("h",Object.class,Object.class).invoke(flow,expected,updated));
    }
    public static synchronized boolean needsRead(Object transport){Selection s=selections.get(transport);return s!=null&&s.managed;}
    private static Object get(Object o,String name)throws Exception{return o.getClass().getField(name).get(o);}
    private static Object call(Object o,String name)throws Exception{return o.getClass().getMethod(name).invoke(o);}
    public static String tail(String value){if(value==null)return "unknown";return "…"+value.substring(Math.max(0,value.length()-4));}
    public static void read(Object transport,Object auth,Object card)throws Exception {
        Selection selection,providerSelection;
        synchronized(IdentityBinding.class){
            if(!current(transport,auth))throw new IllegalStateException("该次读卡已过期，请使用最新读卡结果");
            Read read=reads.get(auth);
            providerSelection=read!=null&&read.transport.get()==transport?read.selection:null;
            selection=read!=null?providerSelection:selections.get(transport);
        }
        String actual=String.valueOf(get(card,"b"));
        String imsi=String.valueOf(get(card,"a"));
        String expected=selection==null?null:selection.iccid,eid=selection==null?null:selection.eid;
        String reader="unknown";try{reader=String.valueOf(get(transport,"f"));}catch(Exception ignored){}
        String channel="unknown";try{Object logical=get(auth,"e");Object omapi=get(logical,"a");channel=String.valueOf(call(omapi,"getChannelNumber"));}catch(Exception ignored){}
        String prefix=imsi.matches("[0-9]{5,15}")?imsi.substring(0,5):"invalid";
        Log.e("SIMHubIdentity","USIM read reader="+reader+" channel="+channel+" EID="+tail(eid)+" selectedICCID="+tail(expected)+" actualICCID="+tail(actual)+" IMSI-prefix="+prefix);
        // A management selection can be stale; it never substitutes for a physical
        // read. Only that fresh read may teach the DITO home identity store.
        synchronized(IdentityBinding.class){
            if(!current(transport,auth))throw new IllegalStateException("该次读卡已过期，请使用最新读卡结果");
            // A provider is evidence only when this read's physical ICCID exactly
            // matches the same transport's captured profile metadata (tag 0x91).
            // Nicknames, selected EIDs and enabled flags never establish this match.
            String provider=validIccid(actual)&&providerSelection!=null?providerSelection.providers.get(actual):null;
            if(provider!=null&&!provider.isEmpty()){
                try{DitoHomeIdentity.observeProvider(card,provider);}catch(Exception e){DitoHomeIdentity.readError(e);}
            }
            try{DitoHomeIdentity.observe(card);}catch(Exception e){DitoHomeIdentity.readError(e);}
            DitoHomeIdentity.readStatus(card);
        }
    }
    /** Keep identities private: retain only identity type, PLMN prefix and realm. */
    public static String identity(String value) {
        if(value==null||value.isEmpty())return "builtin";
        int at=value.indexOf('@');String user=at<0?value:value.substring(0,at);
        String prefix=user.matches("[0-9]{6,}")?user.substring(0,6)+"…":"masked";
        return prefix+(at<0?"":"@"+value.substring(at+1));
    }
    public static void config(Object card,Object config,Map<String,String> overrides) {
        try {
        Log.e("SIMHubIdentity","effective ICCID="+tail(String.valueOf(get(card,"b")))+" PLMN="+call(card,"d")
            +" NAI="+identity((String)get(config,"r"))+" EAP="+identity((String)get(config,"y"))
            +" NAI-source="+(overrides!=null&&overrides.containsKey("nai")?"override":"builtin")
            +" EAP-source="+(overrides!=null&&overrides.containsKey("eap")?"override":"builtin"));
        } catch(Exception ignored) {Log.e("SIMHubIdentity","Identity diagnostic unavailable");}
    }
}
