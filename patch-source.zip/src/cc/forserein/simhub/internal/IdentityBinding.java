package cc.forserein.simhub.internal;

import java.util.*;
import java.lang.ref.WeakReference;
import android.util.Log;

/** Binds a modem-owned USIM read to the management selection without inventing an IMSI. */
public final class IdentityBinding {
    private static final class Selection {
        final String eid,iccid,error;final boolean managed;
        Selection(String eid,String iccid,String error,boolean managed){this.eid=eid;this.iccid=iccid;this.error=error;this.managed=managed;}
    }
    private static final Map<Object,Selection> selections=new WeakHashMap<>();
    private static final Map<Object,Selection> reads=new WeakHashMap<>();
    private static final Map<Object,WeakReference<Object>> latest=new WeakHashMap<>();
    public static synchronized void track(Object transport,Object controller){
        if(transport==null)return;
        try {
            String eid=String.valueOf(call(controller,"r")),expected=null,error=null;
            List<?> chips=(List<?>)call(controller,"l");
            boolean found=false;
            for(Object chip:chips)if(eid.equals(get(chip,"b"))) {
                found=true;
                for(Object p:(List<?>)get(chip,"d"))if(Boolean.TRUE.equals(get(p,"b"))) {
                    if(expected!=null)error="所选芯片有多个启用配置，请重新读卡";
                    expected=String.valueOf(get(p,"a"));
                }
            }
            if(!chips.isEmpty() && (!found||expected==null))error="尚未确认所选芯片的启用配置，请先刷新配置列表";
            selections.put(transport,new Selection(eid,expected,error,!chips.isEmpty()));
        }catch(Exception e){selections.put(transport,new Selection(null,null,"无法确认当前配置身份，请重新选择卡片",true));}
    }
    /** Copy values, not a weak controller reference, before the first asynchronous APDU. */
    public static synchronized void begin(Object transport,Object auth){
        Selection selection=selections.get(transport);
        reads.put(auth,selection);latest.put(transport,new WeakReference<>(auth));
    }
    public static synchronized boolean current(Object transport,Object auth){
        WeakReference<Object> ref=latest.get(transport);return ref==null||ref.get()==auth;
    }
    private static void validateSelection(Object transport,Object auth){
        if(!reads.containsKey(auth))return;
        Selection before=reads.get(auth),now=selections.get(transport);
        if(before!=null&&before.managed&&(now==null||!Objects.equals(before.eid,now.eid)||!Objects.equals(before.iccid,now.iccid)||!Objects.equals(before.error,now.error)))
            throw new IllegalStateException("读卡期间所选配置发生变化，请重新读取当前卡片");
    }
    public static synchronized boolean publish(Object transport,Object auth,Object flow,Object expected,Object updated)throws Exception {
        if(!current(transport,auth))return false;
        validateSelection(transport,auth);
        return Boolean.TRUE.equals(flow.getClass().getMethod("h",Object.class,Object.class).invoke(flow,expected,updated));
    }
    public static synchronized boolean publishError(Object transport,Object auth,Object flow,Object expected,Object updated)throws Exception {
        if(!current(transport,auth))return false;
        return Boolean.TRUE.equals(flow.getClass().getMethod("h",Object.class,Object.class).invoke(flow,expected,updated));
    }
    public static synchronized boolean needsRead(Object transport){Selection s=selections.get(transport);return s!=null&&s.managed;}
    private static Object get(Object o,String name)throws Exception{return o.getClass().getField(name).get(o);}
    private static Object call(Object o,String name)throws Exception{return o.getClass().getMethod(name).invoke(o);}
    public static String tail(String value){if(value==null)return "unknown";return "…"+value.substring(Math.max(0,value.length()-4));}
    private static String iccid(String value){return value==null?"":value.replaceAll("[\\sFf]","");}
    public static void read(Object transport,Object auth,Object card)throws Exception {
        Selection selection;
        synchronized(IdentityBinding.class){if(!current(transport,auth))throw new IllegalStateException("该次读卡已过期，请使用最新读卡结果");validateSelection(transport,auth);selection=reads.containsKey(auth)?reads.get(auth):selections.get(transport);}
        String actual=String.valueOf(get(card,"b"));
        String imsi=String.valueOf(get(card,"a"));
        String expected=selection==null?null:selection.iccid,eid=selection==null?null:selection.eid;
        if(selection!=null&&selection.error!=null)throw new IllegalStateException(selection.error);
        String reader="unknown";try{reader=String.valueOf(get(transport,"f"));}catch(Exception ignored){}
        String channel="unknown";try{Object logical=get(auth,"e");Object omapi=get(logical,"a");channel=String.valueOf(call(omapi,"getChannelNumber"));}catch(Exception ignored){}
        String prefix=imsi.matches("[0-9]{5,15}")?imsi.substring(0,5):"invalid";
        Log.e("SIMHubIdentity","USIM read reader="+reader+" channel="+channel+" EID="+tail(eid)+" selectedICCID="+tail(expected)+" actualICCID="+tail(actual)+" IMSI-prefix="+prefix);
        // Plain SIMs have no management profile list. Never infer their carrier from ICCID.
        if(expected!=null && !iccid(expected).equals(iccid(actual)))
            throw new IllegalStateException("所选配置 ICCID "+tail(expected)+" 与实际 USIM "+tail(actual)+" 不一致，已停止使用错误身份。请关闭 Wi-Fi 通话并重新切卡、读卡。");
    }
    /** Keep identities private: retain only identity type, PLMN prefix and realm. */
    public static String identity(String value) {
        if(value==null||value.isEmpty())return "builtin";
        int at=value.indexOf('@');String user=at<0?value:value.substring(0,at);
        String prefix=user.matches("[0-9]{6,}")?user.substring(0,6)+"…":"masked";
        return prefix+(at<0?"":"@"+value.substring(at+1));
    }
    public static void config(Object card,Object config,Map<String,String> overrides) {
        try {
        Log.e("SIMHubIdentity","effective ICCID="+tail(String.valueOf(get(card,"b")))+" PLMN="+call(card,"d")
            +" NAI="+identity((String)get(config,"r"))+" EAP="+identity((String)get(config,"y"))
            +" NAI-source="+(overrides!=null&&overrides.containsKey("nai")?"override":"builtin")
            +" EAP-source="+(overrides!=null&&overrides.containsKey("eap")?"override":"builtin"));
        } catch(Exception ignored) {Log.e("SIMHubIdentity","Identity diagnostic unavailable");}
    }
}
