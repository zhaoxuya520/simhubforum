package cc.forserein.simhub.internal;

import java.lang.reflect.*;
import java.util.*;

/** Adapter pinned to the supplied 23.1 model. No hidden Android APIs. */
public final class WifiConfigModel {
    private WifiConfigModel() {}
    public static Object get(Object object,String name) throws ReflectiveOperationException {
        return object.getClass().getField(name).get(object);
    }
    public static Constructor<?> constructor(Class<?> type,int count) {
        for(Constructor<?> c:type.getConstructors()) if(c.getParameterTypes().length==count) return c;
        throw new IllegalStateException("配置模型不兼容："+type.getSimpleName());
    }
    static String name(int i) { return i==26?"A":Character.toString((char)('a'+i)); }
    public static Object[] fields(Object object,int count) throws ReflectiveOperationException {
        Object[] result=new Object[count];
        for(int i=0;i<count;i++) result[i]=get(object,name(i));
        return result;
    }
    public static Object builtIn(Object card) throws ReflectiveOperationException {
        return Class.forName("zl3").getMethod("r",Class.forName("ek5")).invoke(null,card);
    }
    public static Object merge(Object defaults,Map<String,String> values) throws ReflectiveOperationException {
        if(values.isEmpty()) return defaults;
        Object[] args=fields(defaults,27);
        for(WifiConfigValues.Field f:WifiConfigValues.FIELDS) {
            String value=values.get(f.key);
            if(value==null || f.index<0) continue;
            Object typed=value;
            if(f.key.equals("epdg")) typed=new ArrayList<>(WifiConfigValues.tokens(value));
            else if(f.key.startsWith("ike_") || f.key.startsWith("esp_")) typed=new WifiConfigValues.Algorithms(WifiConfigValues.tokens(value));
            else if(f.key.equals("keepalive")) typed=Integer.valueOf(value);
            else if(f.key.equals("ipsec")) typed=Boolean.valueOf(value.equals("on"));
            else if(f.key.equals("ip")) {
                typed=null;
                for(Object item:args[8].getClass().getEnumConstants()) if(value.equals(get(item,"T"))) typed=item;
                if(typed==null) throw new IllegalArgumentException("IP 类型不受支持");
            }
            args[f.index]=typed;
        }
        // Config equality must distinguish an explicit list from an identical default list,
        // otherwise StateFlow suppresses the update and restores the engine's extra proposals.
        args[0]=args[0].getClass().getField("W").get(null); // source = custom
        int mask=0;
        for(int i=0;i<WifiConfigValues.FIELDS.length;i++) if(values.containsKey(WifiConfigValues.FIELDS[i].key)) mask|=1<<i;
        args[1]="local:"+Integer.toHexString(mask)+":"+WifiConfigValues.digest(WifiConfigValues.encode(values));
        return constructor(defaults.getClass(),27).newInstance(args);
    }
    public static Map<String,String> display(Object config) throws ReflectiveOperationException {
        Map<String,String> result=new LinkedHashMap<>();
        for(WifiConfigValues.Field f:WifiConfigValues.FIELDS) {
            if(f.index<0){result.put(f.key,"读取卡内短信中心");continue;}
            Object v=get(config,name(f.index));
            if(v instanceof List) v=WifiConfigValues.join((List<?>)v,f.key.equals("epdg")?"\n":" ");
            else if(f.key.equals("ip")) v=get(v,"T");
            else if(v instanceof Boolean) v=((Boolean)v)?"on":"off";
            result.put(f.key,v==null?(f.key.equals("imei")?"未设置":"自动"):v.toString());
        }
        return result;
    }
    public static boolean explicit(Object config,String key) throws ReflectiveOperationException {
        Object id=get(config,"b");
        if(!(id instanceof String) || !((String)id).startsWith("local:")) return false;
        String[] parts=((String)id).split(":");
        if(parts.length!=3) return false;
        int mask;
        try {mask=Integer.parseInt(parts[1],16);} catch(NumberFormatException e){return false;}
        for(int i=0;i<WifiConfigValues.FIELDS.length;i++) if(WifiConfigValues.FIELDS[i].key.equals(key)) return (mask&(1<<i))!=0;
        return false;
    }
    /** Explicit IPv4/IPv6 must not fall back to the other inner address family. */
    public static List<?> addressFamilies(Object config,List<?> candidates) {
        try {
            if(!explicit(config,"ip")) return candidates;
            String wanted=(String)get(get(config,"i"),"T");
            if(wanted.equals("dual")) return candidates;
            for(Object candidate:candidates) if(wanted.equals(get(candidate,"T"))) return Collections.singletonList(candidate);
            throw new IllegalArgumentException("自定义 IP 类型不可用");
        } catch(ReflectiveOperationException e){throw new IllegalStateException("无法应用 IP 配置",e);}
    }
    public static void restrictIke(Object config,ArrayList<?> transforms) { restrict(config,transforms,false); }
    public static void restrictEsp(Object config,ArrayList<?> transforms) { restrict(config,transforms,true); }
    private static void restrict(Object config,ArrayList<?> transforms,boolean esp) {
        try {
            String[] names=esp?new String[]{"n",null,"o",null}:new String[]{"j","l","k","m"};
            for(int type=1;type<=4;type++) {
                String name=names[type-1]; if(name==null) continue;
                Object configured=get(config,name);
                if(!(configured instanceof WifiConfigValues.Algorithms)) continue;
                List<?> allowed=(List<?>)configured;
                int retained=0;
                for(Iterator<?> it=transforms.iterator();it.hasNext();) {
                    Object transform=it.next();
                    if(((Number)get(get(transform,"a"),"T")).intValue()!=type) continue;
                    int id=((Number)get(transform,"b")).intValue();
                    Object bits=get(transform,"c");
                    String token=algorithm(type,id,bits);
                    if(token!=null && allowed.contains(token)) retained++; else it.remove();
                }
                if(retained==0) throw new IllegalArgumentException("服务器要求的 IKE/ESP 算法不在自定义列表内，请检查配置");
            }
        } catch(ReflectiveOperationException e) { throw new IllegalStateException("无法应用 IKE/ESP 自定义配置",e); }
    }
    static String algorithm(int type,int id,Object bits) {
        if(type==1) return id==12 && bits!=null?"aes"+bits:null;
        if(type==2) return id==2?"sha1":id==5?"sha256":id==6?"sha384":id==7?"sha512":null;
        if(type==3) return id==2?"sha1":id==12?"sha256":id==13?"sha384":id==14?"sha512":null;
        if(type==4) return id==2?"modp1024":id==14?"modp2048":id==19?"ecp256":null;
        return null;
    }
}
