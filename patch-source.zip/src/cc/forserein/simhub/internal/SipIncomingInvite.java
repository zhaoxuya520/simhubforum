package cc.forserein.simhub.internal;

import static cc.forserein.simhub.internal.SipInviteFailure.call;
import static cc.forserein.simhub.internal.SipInviteFailure.copyMessage;
import static cc.forserein.simhub.internal.SipInviteFailure.field;
import static cc.forserein.simhub.internal.SipInviteFailure.first;
import static cc.forserein.simhub.internal.SipInviteFailure.headers;
import static cc.forserein.simhub.internal.SipInviteFailure.parameter;
import static cc.forserein.simhub.internal.SipInviteFailure.topVia;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.WeakHashMap;

/** Retain completed, rejected incoming INVITE transactions through ordinary retransmissions. */
public final class SipIncomingInvite {
    private static final int LIMIT = 64;
    private static final long LIFETIME = 32_000_000_000L;
    private static final WeakHashMap<Object, Bucket> CACHE = new WeakHashMap<Object, Bucket>();
    private static Timer cleaner;
    private SipIncomingInvite() {}

    private static final class Key {
        final List<String> parts;
        final String callId;
        final int sequence;
        Key(String id, int sequence, String branch, String from, String to, String uri, String sentBy) {
            callId = id; this.sequence = sequence;
            parts = Arrays.asList(id, String.valueOf(sequence), branch, from, to, uri, sentBy);
        }
        @Override public boolean equals(Object other) {
            return other instanceof Key && parts.equals(((Key) other).parts);
        }
        @Override public int hashCode() { return parts.hashCode(); }
    }
    private static final class Entry {
        final Object response;
        final long created;
        Entry(Object response, long now) { this.response = response; created = now; }
    }
    private static final class Bucket {
        final LinkedHashMap<Key, Entry> replies = new LinkedHashMap<Key, Entry>();
        boolean scheduled;
    }
    private static final class Expiry extends TimerTask {
        final WeakReference<Object> manager;
        final WeakReference<Bucket> bucket;
        Expiry(Object manager, Bucket bucket) {
            this.manager = new WeakReference<Object>(manager);
            this.bucket = new WeakReference<Bucket>(bucket);
        }
        @Override public void run() {
            synchronized (CACHE) {
                CACHE.size(); // Expunge weak manager keys even when the engine is idle.
                Object owner = manager.get();
                Bucket current = bucket.get();
                if (owner == null || current == null || CACHE.get(owner) != current) {
                    stopIdleCleaner();
                    return;
                }
                current.scheduled = false;
                long now = System.nanoTime();
                purge(current, now);
                if (current.replies.isEmpty()) CACHE.remove(owner);
                else schedule(owner, current, now);
                stopIdleCleaner();
            }
        }
    }
    private static void stopIdleCleaner() {
        if (CACHE.isEmpty() && cleaner != null) {
            cleaner.cancel();
            cleaner = null;
        }
    }
    private static void purge(Bucket bucket, long now) {
        Iterator<Entry> it = bucket.replies.values().iterator();
        while (it.hasNext()) {
            long age = now - it.next().created;
            if (age < 0 || age >= LIFETIME) it.remove();
        }
    }
    private static void schedule(Object manager, Bucket bucket, long now) {
        if (bucket.scheduled || bucket.replies.isEmpty()) return;
        long remaining = LIFETIME;
        for (Entry entry : bucket.replies.values())
            remaining = Math.min(remaining, LIFETIME - (now - entry.created));
        if (cleaner == null) cleaner = new Timer("SIMHub-SIP-replies", true);
        cleaner.schedule(new Expiry(manager, bucket), Math.max(1L, (remaining + 999_999L) / 1_000_000L));
        bucket.scheduled = true;
    }
    private static boolean present(String value) { return value != null && !value.isEmpty(); }
    private static Key key(Object request) throws Exception {
        if (request == null || !(Boolean) field(request, "a")
                || !"INVITE".equals(field(request, "b"))) return null;
        String to = first(request, "To", "t"), from = first(request, "From", "f");
        if (!present(to) || !present(from) || parameter(request, to, "tag") != null
                || !present(parameter(request, from, "tag"))) return null;
        Object seq = call(request, "e", new Class<?>[0]);
        if (seq == null || !"INVITE".equals(field(seq, "b"))) return null;
        int number = (Integer) field(seq, "a");
        String id = first(request, "Call-ID", "i"), via = topVia(request);
        String branch = parameter(request, via, "branch");
        String uri = (String) field(request, "c");
        if (number < 0 || !present(id) || !present(branch) || !present(uri) || via == null) return null;
        int semicolon = via.indexOf(';');
        String sentBy = (semicolon < 0 ? via : via.substring(0, semicolon)).trim();
        if (!sentBy.startsWith("SIP/2.0/") || sentBy.indexOf(' ') < 0) return null;
        return new Key(id, number, branch, from, to, uri, sentBy);
    }

    /** Called after native cb4.n has retained its own final response in dialog.G. */
    public static void remember(Object manager, Object dialog, Object response) {
        try {
            if (manager == null || dialog == null || response == null || (Boolean) field(response, "a")) return;
            int status = (Integer) field(response, "d");
            if ((status != 603 && status != 487) || ((byte[]) field(response, "g")).length != 0) return;
            Object direction = field(dialog, "a");
            if (direction != direction.getClass().getField("T").get(null) || field(dialog, "D") != null) return;
            Key key = key(field(dialog, "j"));
            if (key == null || key.sequence != (Integer) field(dialog, "i")
                    || ((Map<?, ?>) field(manager, "e")).get(key.callId) != dialog) return;
            Object seq = call(response, "e", new Class<?>[0]);
            if (seq == null || !"INVITE".equals(field(seq, "b"))
                    || key.sequence != (Integer) field(seq, "a")
                    || !key.callId.equals(first(response, "Call-ID", "i"))
                    || !field(dialog, "d").equals(parameter(response, first(response, "To", "t"), "tag"))) return;
            Object copy = copyMessage(response);
            synchronized (CACHE) {
                long now = System.nanoTime();
                Bucket bucket = CACHE.get(manager);
                if (bucket == null) { bucket = new Bucket(); CACHE.put(manager, bucket); }
                purge(bucket, now);
                if (bucket.replies.containsKey(key)) return; // Retransmissions never extend retention.
                if (bucket.replies.size() >= LIMIT) bucket.replies.remove(bucket.replies.keySet().iterator().next());
                bucket.replies.put(key, new Entry(copy, now));
                schedule(manager, bucket, now);
            }
        } catch (Exception ignored) { /* Native final-response delivery must remain available. */ }
    }

    /** Consume only an exact completed initial transaction; use the current reply route. */
    public static boolean handle(Object engine, Object request, Object transport) {
        boolean matched = false;
        try {
            if (engine == null) return false;
            synchronized (CACHE) {
                if (CACHE.isEmpty()) {
                    stopIdleCleaner();
                    return false;
                }
            }
            Key key = key(request);
            if (key == null) return false;
            Object manager = field(engine, "J");
            if (manager == null) return false;
            Entry entry;
            synchronized (CACHE) {
                Bucket bucket = CACHE.get(manager);
                if (bucket == null) return false;
                purge(bucket, System.nanoTime());
                entry = bucket.replies.get(key);
                if (bucket.replies.isEmpty()) CACHE.remove(manager);
                stopIdleCleaner();
            }
            if (entry == null) return false;
            matched = true;
            Object response = copyMessage(entry.response);
            // Echo the current Via chain, including received/rport; do not mutate cached pairs.
            Iterator<?> it = ((List<?>) field(response, "f")).iterator();
            while (it.hasNext()) {
                String name = (String) field(it.next(), "T");
                if ("Via".equalsIgnoreCase(name) || "v".equalsIgnoreCase(name)) it.remove();
            }
            for (String via : headers(request, "Via", "v"))
                call(response, "a", new Class<?>[]{String.class, String.class}, "Via", via);
            ClassLoader loader = engine.getClass().getClassLoader();
            Class<?> path = Class.forName("oc2", false, loader);
            Object action = Class.forName("pa4", false, loader)
                    .getConstructor(response.getClass(), path).newInstance(response, transport);
            call(engine, "k", new Class<?>[]{List.class}, Collections.singletonList(action));
            return true;
        } catch (Exception failure) {
            if (matched) {
                try { call(field(engine, "g"), "i", new Class<?>[]{Object.class},
                        "通话：来电结束响应重发未完成，等待对端重传"); }
                catch (Exception ignored) { /* Keep the ended call ended when sending fails. */ }
            }
            return matched;
        }
    }
}
