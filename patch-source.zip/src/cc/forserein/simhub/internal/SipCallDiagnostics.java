package cc.forserein.simhub.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static cc.forserein.simhub.internal.SipInviteFailure.call;
import static cc.forserein.simhub.internal.SipInviteFailure.field;
import static cc.forserein.simhub.internal.SipInviteFailure.first;
import static cc.forserein.simhub.internal.SipInviteFailure.headers;
import static cc.forserein.simhub.internal.SipInviteFailure.parameter;
import static cc.forserein.simhub.internal.SipInviteFailure.topVia;

/** A redacted observation of call setup, never an instruction to the SIP engine. */
public final class SipCallDiagnostics {
    private SipCallDiagnostics() {}

    /** "Submitted" includes a request queued for TCP; it does not claim delivery. */
    public static void outgoing(Object engine, Object request) {
        observe(engine, request, true);
    }

    /** Runs before response guards: "received" does not mean the response was accepted. */
    public static void incoming(Object engine, Object response) {
        observe(engine, response, false);
    }

    private static void observe(Object engine, Object message, boolean outgoing) {
        try {
            if (engine == null || message == null || (Boolean) field(message, "a") != outgoing) return;
            Object sequence = call(message, "e", new Class<?>[0]);
            if (sequence == null) return;
            String method = (String) field(sequence, "b");
            if (!callMethod(method)) return;
            if (outgoing && !method.equals(field(message, "b"))) return;
            int status = outgoing ? 0 : (Integer) field(message, "d");
            if (!outgoing && (status < 100 || status > 699)) return;
            if (!outgoing && !"INVITE".equals(method) && status < 200) return;

            Object manager = field(engine, "J");
            Object dialog = manager == null ? null : ((Map<?, ?>) field(manager, "e"))
                    .get(first(message, "Call-ID", "i"));
            // Only the object's process-local identity is printed, never the SIP Call-ID.
            String label = dialog == null ? "（未匹配当前通话）" : " #" + Integer.toHexString(System.identityHashCode(dialog));
            StringBuilder text = new StringBuilder("通话诊断").append(label).append("：");
            if (outgoing) text.append("提交 ");
            else text.append("收到 ").append(status).append(' ');
            text.append(method).append("（Via=").append(transport(message));
            text.append("，Gm上下文=").append(yes(field(engine, "q") != null));
            text.append("，SDP=").append(yes(hasSdp(message)));
            if ("INVITE".equals(method)) {
                text.append("，原始事务=").append(transaction(message, dialog));
                text.append("，100rel要求=").append(yes(option(message, "Require", "100rel")));
                text.append("，precondition要求=").append(yes(option(message, "Require", "precondition")));
                if (outgoing) {
                    text.append("，被叫地址类型=").append(targetType((String) field(message, "c")));
                    text.append("，precondition支持=").append(yes(option(message, "Supported", "precondition")));
                    text.append("，早期媒体声明=").append(yes(option(message, "P-Early-Media", "supported")));
                } else {
                    text.append("，RSeq=").append(yes(first(message, "RSeq", null) != null));
                    text.append("，对话分支=").append(remoteBranch(message, dialog));
                    text.append("，早期媒体授权=").append(earlyMedia(message));
                }
            } else if ("PRACK".equals(method)) {
                text.append("，RAck=").append(yes(first(message, "RAck", null) != null));
            } else if ("UPDATE".equals(method)) {
                text.append("，precondition要求=").append(yes(option(message, "Require", "precondition")));
            } else if ("CANCEL".equals(method)) {
                text.append("，原始事务=").append(transaction(message, dialog));
            }
            if ((!outgoing && (status < 200 || status >= 300)) || (outgoing && "CANCEL".equals(method))) {
                String reason = reasonCodes(message), warning = warningCodes(message);
                if (reason.length() != 0) text.append("，Reason=").append(reason);
                if (warning.length() != 0) text.append("，Warning=").append(warning);
            }
            text.append('）');
            if (text.length() > 512) text.setLength(512);
            call(field(engine, "g"), "i", new Class<?>[]{Object.class}, text.toString());
        } catch (Exception ignored) {
            // Missing fields, malformed SIP or a failed log sink cannot alter call handling.
        }
    }

    private static boolean callMethod(String method) {
        return "INVITE".equals(method) || "CANCEL".equals(method)
                || "PRACK".equals(method) || "UPDATE".equals(method);
    }

    private static String yes(boolean value) { return value ? "有" : "无"; }

    private static String targetType(String target) {
        if (target == null) return "未知";
        if (target.regionMatches(true, 0, "tel:+", 0, 5)) return "TEL（国际）";
        if (target.regionMatches(true, 0, "tel:", 0, 4)) return "TEL";
        if (target.regionMatches(true, 0, "sip:", 0, 4)) return "SIP";
        if (target.regionMatches(true, 0, "sips:", 0, 5)) return "SIPS";
        return "未知";
    }

    private static String transport(Object message) throws Exception {
        String value = topVia(message);
        if (value != null) {
            int space = value.indexOf(' ');
            String protocol = (space < 0 ? value : value.substring(0, space)).toUpperCase(Locale.ROOT);
            if ("SIP/2.0/TCP".equals(protocol)) return "TCP";
            if ("SIP/2.0/UDP".equals(protocol)) return "UDP";
            if ("SIP/2.0/TLS".equals(protocol)) return "TLS";
        }
        return "未知";
    }

    private static boolean hasSdp(Object message) throws Exception {
        if (((byte[]) field(message, "g")).length == 0) return false;
        String value = first(message, "Content-Type", "c");
        if (value == null) return false;
        int separator = value.indexOf(';');
        return "application/sdp".equalsIgnoreCase((separator < 0 ? value : value.substring(0, separator)).trim());
    }

    private static boolean option(Object message, String header, String option) throws Exception {
        for (String value : headers(message, header, "Supported".equals(header) ? "k" : null)) {
            if (value.length() > 2048) continue;
            for (String token : value.split(",")) if (option.equalsIgnoreCase(token.trim())) return true;
        }
        return false;
    }

    private static String transaction(Object message, Object dialog) throws Exception {
        if (dialog == null) return "无当前通话";
        Object original = field(dialog, "j");
        if (original == null) return "未知";
        Object firstSequence = call(original, "e", new Class<?>[0]);
        Object sequence = call(message, "e", new Class<?>[0]);
        boolean match = firstSequence != null && sequence != null
                && equal(field(firstSequence, "a"), field(sequence, "a"))
                && equal(first(original, "Call-ID", "i"), first(message, "Call-ID", "i"))
                && equal(parameter(original, topVia(original), "branch"), parameter(message, topVia(message), "branch"))
                && equal(parameter(original, first(original, "From", "f"), "tag"), parameter(message, first(message, "From", "f"), "tag"));
        return match ? "匹配" : "不匹配";
    }

    private static boolean equal(Object a, Object b) { return a != null && a.equals(b); }

    /** RFC 5009 response tokens only; arbitrary extensions are reported without their contents. */
    private static String earlyMedia(Object message) throws Exception {
        List<String> values = headers(message, "P-Early-Media", null);
        if (values.isEmpty()) return "无";
        String[] allowed = {"sendrecv", "sendonly", "recvonly", "inactive", "gated"};
        StringBuilder result = new StringBuilder();
        int count = 0;
        boolean unknown = false;
        for (String value : values) {
            if (value.length() > 2048) { unknown = true; continue; }
            for (String token : value.split(",", -1)) {
                boolean known = false;
                for (int i = 0; i < allowed.length; i++) {
                    if (!allowed[i].equalsIgnoreCase(token.trim())) continue;
                    if (count == 8) return result.append("/其余已省略").toString();
                    if (result.length() != 0) result.append('/');
                    result.append(allowed[i]);
                    count++; known = true; break;
                }
                if (!known) unknown = true;
            }
        }
        if (unknown) {
            if (result.length() != 0) result.append('/');
            result.append("有未识别值");
        }
        return result.length() == 0 ? "有未识别值" : result.toString();
    }

    private static String remoteBranch(Object message, Object dialog) throws Exception {
        if (dialog == null) return "无当前通话";
        Object chosen = field(dialog, "l");
        if (chosen == null) return "尚未选择";
        String tag = parameter(message, first(message, "To", "t"), "tag");
        return equal(chosen, tag) ? "当前" : "其他";
    }

    /** Split only outside quoted values; untrusted free text is never returned. */
    private static List<String> parts(String value, char separator) {
        List<String> result = new ArrayList<String>();
        boolean quoted = false, escaped = false;
        int start = 0;
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            if (escaped) { escaped = false; continue; }
            if (quoted && ch == '\\') { escaped = true; continue; }
            if (ch == '"') quoted = !quoted;
            else if (!quoted && ch == separator) {
                result.add(value.substring(start, i).trim()); start = i + 1;
            }
        }
        result.add(value.substring(start).trim());
        return result;
    }

    private static int code(String value) {
        if (value.length() == 0 || value.length() > 3) return -1;
        int code = 0;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c < '0' || c > '9') return -1;
            code = code * 10 + c - '0';
        }
        return code;
    }

    private static String reasonCodes(Object message) throws Exception {
        StringBuilder result = new StringBuilder();
        int count = 0;
        for (String header : headers(message, "Reason", null)) {
            if (header.length() > 2048) continue;
            for (String reason : parts(header, ',')) {
                List<String> parameters = parts(reason, ';');
                String protocol = parameters.get(0).toUpperCase(Locale.ROOT);
                if (!"SIP".equals(protocol) && !"Q.850".equals(protocol)) continue;
                for (int i = 1; i < parameters.size(); i++) {
                    String parameter = parameters.get(i);
                    int equals = parameter.indexOf('=');
                    if (equals < 0 || !"cause".equalsIgnoreCase(parameter.substring(0, equals).trim())) continue;
                    int cause = code(parameter.substring(equals + 1).trim());
                    if (cause < 0) continue;
                    if (result.length() != 0) result.append(',');
                    result.append(protocol).append('/').append(cause);
                    if (++count == 4) return result.toString();
                    break;
                }
            }
        }
        return result.toString();
    }

    private static String warningCodes(Object message) throws Exception {
        StringBuilder result = new StringBuilder();
        int count = 0;
        for (String header : headers(message, "Warning", null)) {
            if (header.length() > 2048) continue;
            for (String warning : parts(header, ',')) {
                int space = warning.indexOf(' ');
                int code = code(space < 0 ? warning : warning.substring(0, space));
                if (code < 100) continue;
                if (result.length() != 0) result.append(',');
                result.append(code);
                if (++count == 4) return result.toString();
            }
        }
        return result.toString();
    }
}
