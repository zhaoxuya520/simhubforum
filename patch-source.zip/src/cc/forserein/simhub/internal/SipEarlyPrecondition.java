package cc.forserein.simhub.internal;

import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

import static cc.forserein.simhub.internal.SipInviteFailure.call;
import static cc.forserein.simhub.internal.SipInviteFailure.field;
import static cc.forserein.simhub.internal.SipInviteFailure.first;
import static cc.forserein.simhub.internal.SipInviteFailure.headers;
import static cc.forserein.simhub.internal.SipInviteFailure.parameter;
import static cc.forserein.simhub.internal.SipInviteFailure.topVia;

/** TS 24.229 5.1.3.1: an early SDP UPDATE follows the peer's negotiated precondition requirement. */
public final class SipEarlyPrecondition {
    private static final int LIMIT = 64;
    private static final long LIFETIME_NANOS = 180000000000L;
    // Native ma4 uses Object identity. Values contain no dialog, manager, engine or message references.
    private static final WeakHashMap<Object, Proof> PROOFS = new WeakHashMap<Object, Proof>();

    private SipEarlyPrecondition() {}

    private static final class Proof {
        final String callId, branch, localTag, remoteTag;
        final int inviteSequence;
        final byte[] acceptedSdpDigest;
        final long created;
        Proof(String callId, String branch, String localTag, String remoteTag,
                int inviteSequence, byte[] digest, long created) {
            this.callId = callId; this.branch = branch; this.localTag = localTag;
            this.remoteTag = remoteTag; this.inviteSequence = inviteSequence;
            this.acceptedSdpDigest = digest; this.created = created;
        }
    }

    private static boolean present(String text) { return text != null && !text.isEmpty(); }
    private static String tag(Object message, String header, String compact) throws Exception {
        return parameter(message, first(message, header, compact), "tag");
    }
    private static boolean token(Object message, String header, String compact, String token) throws Exception {
        for (String value : headers(message, header, compact))
            for (String item : value.split(","))
                if (token.equalsIgnoreCase(item.trim())) return true;
        return false;
    }
    private static boolean sdp(Object message) throws Exception {
        byte[] body = (byte[]) field(message, "g");
        String type = first(message, "Content-Type", "c");
        if (body == null || body.length == 0 || type == null) return false;
        int semicolon = type.indexOf(';');
        return "application/sdp".equalsIgnoreCase((semicolon < 0 ? type : type.substring(0, semicolon)).trim());
    }
    private static boolean early(Object dialog) throws Exception {
        if (dialog == null || field(dialog, "D") != null || !Boolean.TRUE.equals(field(dialog, "q"))) return false;
        Object direction = field(dialog, "a"), state = field(dialog, "c");
        if (direction != direction.getClass().getField("U").get(null)) return false;
        Class<?> states = state.getClass();
        return state == states.getField("T").get(null) || state == states.getField("U").get(null)
                || state == states.getField("V").get(null);
    }
    private static byte[] digest(byte[] body) throws Exception {
        return MessageDigest.getInstance("SHA-256").digest(body);
    }
    private static void purge(long now) {
        Iterator<Map.Entry<Object, Proof>> it = PROOFS.entrySet().iterator();
        while (it.hasNext()) if (now - it.next().getValue().created >= LIFETIME_NANOS) it.remove();
    }
    private static boolean matchesOriginal(Object dialog, Proof proof) throws Exception {
        Object invite = field(dialog, "j");
        if (invite == null || !Boolean.TRUE.equals(field(invite, "a")) || !"INVITE".equals(field(invite, "b"))) return false;
        Object cseq = call(invite, "e", new Class<?>[0]);
        return cseq != null && "INVITE".equals(field(cseq, "b"))
                && proof.inviteSequence == (Integer) field(cseq, "a")
                && proof.inviteSequence == (Integer) field(dialog, "i")
                && proof.callId.equals(field(dialog, "b")) && proof.callId.equals(first(invite, "Call-ID", "i"))
                && proof.branch.equals(parameter(invite, topVia(invite), "branch"))
                && proof.localTag.equals(field(dialog, "d")) && proof.localTag.equals(tag(invite, "From", "f"))
                && proof.remoteTag.equals(field(dialog, "l"))
                && token(invite, "Supported", "k", "precondition");
    }

    /** Called only after the native provisional handler has accepted this exact response SDP. */
    public static synchronized void observe(Object response, Object dialog) {
        long now = System.nanoTime();
        purge(now);
        Proof previous = PROOFS.remove(dialog);
        try {
            if (!early(dialog) || Boolean.TRUE.equals(field(response, "a"))) return;
            int status = (Integer) field(response, "d");
            if (status <= 100 || status >= 200 || !sdp(response)) return;
            byte[] body = (byte[]) field(response, "g");
            if (body != field(dialog, "p")) return; // The hook follows the native assignment; never learn unaccepted SDP.
            Object sequence = call(response, "e", new Class<?>[0]);
            if (sequence == null || !"INVITE".equals(field(sequence, "b"))) return;
            String id = first(response, "Call-ID", "i");
            String branch = parameter(response, topVia(response), "branch");
            String local = tag(response, "From", "f"), remote = tag(response, "To", "t");
            if (!present(id) || !present(branch) || !present(local) || !present(remote)) return;
            Proof proof = new Proof(id, branch, local, remote, (Integer) field(sequence, "a"), digest(body), now);
            if (!matchesOriginal(dialog, proof) || !token(response, "Require", null, "precondition")) return;
            if (previous != null && previous.callId.equals(id) && previous.branch.equals(branch)
                    && previous.localTag.equals(local) && previous.remoteTag.equals(remote)
                    && previous.inviteSequence == proof.inviteSequence
                    && Arrays.equals(previous.acceptedSdpDigest, proof.acceptedSdpDigest)) {
                proof = previous; // A repeated accepted response cannot extend its evidence lifetime.
            }
            if (PROOFS.size() >= LIMIT) {
                Object oldest = null; long oldestTime = Long.MAX_VALUE;
                for (Map.Entry<Object, Proof> entry : PROOFS.entrySet()) {
                    if (entry.getValue().created < oldestTime) { oldest = entry.getKey(); oldestTime = entry.getValue().created; }
                }
                if (oldest != null) PROOFS.remove(oldest);
            }
            PROOFS.put(dialog, proof);
        } catch (Exception ignored) {
            // Missing ABI/evidence preserves native behavior; this helper must not fail call setup.
        }
    }

    /** Runs after cb4.k builds the UPDATE and before native security/serialization/transport dispatch. */
    public static synchronized void decorate(Object dialog, Object request) {
        long now = System.nanoTime();
        purge(now);
        Proof proof = PROOFS.get(dialog);
        if (proof == null) return;
        try {
            if (!early(dialog) || !matchesOriginal(dialog, proof)
                    || !Arrays.equals(proof.acceptedSdpDigest, digest((byte[]) field(dialog, "p")))) {
                PROOFS.remove(dialog); return;
            }
            if (!Boolean.TRUE.equals(field(request, "a")) || !"UPDATE".equals(field(request, "b")) || !sdp(request)) return;
            Object sequence = call(request, "e", new Class<?>[0]);
            if (sequence == null || !"UPDATE".equals(field(sequence, "b"))
                    || (Integer) field(sequence, "a") <= proof.inviteSequence
                    || !field(sequence, "a").equals(field(dialog, "h"))
                    || !proof.callId.equals(first(request, "Call-ID", "i"))
                    || !proof.localTag.equals(tag(request, "From", "f"))
                    || !proof.remoteTag.equals(tag(request, "To", "t"))) return;
            if (!token(request, "Require", null, "precondition"))
                call(request, "a", new Class<?>[]{String.class, String.class}, "Require", "precondition");
        } catch (Exception ignored) {
            PROOFS.remove(dialog);
        }
    }
}
