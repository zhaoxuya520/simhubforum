package cc.forserein.simhub.internal;

import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.WeakHashMap;

import static cc.forserein.simhub.internal.SipInviteFailure.field;
import static cc.forserein.simhub.internal.SipInviteFailure.call;
import static cc.forserein.simhub.internal.SipInviteFailure.first;
import static cc.forserein.simhub.internal.SipInviteFailure.parameter;
import static cc.forserein.simhub.internal.SipInviteFailure.topVia;
import static cc.forserein.simhub.internal.SipInviteFailure.copyMessage;

/** Replay the first native accepted INVITE ACK without reopening or rewriting its dialog. */
public final class SipInviteSuccess {
    private static final int MAX_ACKS = 64;
    private static final int MAX_BYE_ATTEMPTS = 2;
    private static final long RETAIN_NANOS = 32_000_000_000L;
    private static final WeakHashMap<Object, Bucket> CACHE = new WeakHashMap<Object, Bucket>();
    private SipInviteSuccess() {}

    private static final class Bucket {
        final WeakReference<Object> manager;
        final LinkedHashMap<Key, Entry> acks = new LinkedHashMap<Key, Entry>();
        Bucket(Object manager) { this.manager = new WeakReference<Object>(manager); }
    }
    private static final class Entry {
        final WeakReference<Object> dialog;
        final Object ack;
        final long created;
        List<?> pending;
        int next, byeAttempts;
        boolean processing;
        Entry(Object dialog, Object ack, long now) {
            this.dialog = new WeakReference<Object>(dialog); this.ack = ack; this.created = now;
        }
    }
    private static final class Key {
        final String callId, branch, localTag, remoteTag;
        final int sequence;
        Key(String callId, int sequence, String branch, String localTag, String remoteTag) {
            this.callId = callId; this.sequence = sequence; this.branch = branch;
            this.localTag = localTag; this.remoteTag = remoteTag;
        }
        @Override public boolean equals(Object other) {
            if (!(other instanceof Key)) return false;
            Key k = (Key) other;
            return sequence == k.sequence && callId.equals(k.callId) && branch.equals(k.branch)
                    && localTag.equals(k.localTag) && remoteTag.equals(k.remoteTag);
        }
        @Override public int hashCode() {
            int h = 31 * callId.hashCode() + sequence;
            h = 31 * h + branch.hashCode(); h = 31 * h + localTag.hashCode();
            return 31 * h + remoteTag.hashCode();
        }
    }
    private static boolean present(String value) { return value != null && value.length() != 0; }
    private static String branch(Object message) throws Exception {
        return parameter(message, topVia(message), "branch");
    }
    private static Key key(Object response) throws Exception {
        if ((Boolean) field(response, "a")) return null;
        int status = (Integer) field(response, "d");
        if (status < 200 || status >= 300) return null;
        Object sequence = call(response, "e", new Class<?>[0]);
        if (sequence == null || !"INVITE".equals(field(sequence, "b"))) return null;
        int number = (Integer) field(sequence, "a");
        String id = first(response, "Call-ID", "i"), via = branch(response);
        String local = parameter(response, first(response, "From", "f"), "tag");
        String remote = parameter(response, first(response, "To", "t"), "tag");
        if (number < 0 || !present(id) || !present(via) || !present(local) || !present(remote)) return null;
        return new Key(id, number, via, local, remote);
    }
    private static boolean outgoing(Object dialog) throws Exception {
        Object direction = field(dialog, "a");
        return direction == direction.getClass().getField("U").get(null);
    }
    private static boolean matches(Object dialog, Key key) throws Exception {
        Object invite = field(dialog, "j");
        if (!(Boolean) field(invite, "a") || !"INVITE".equals(field(invite, "b"))) return false;
        Object sequence = call(invite, "e", new Class<?>[0]);
        return sequence != null && "INVITE".equals(field(sequence, "b"))
                && key.sequence == (Integer) field(sequence, "a")
                && key.sequence == (Integer) field(dialog, "i")
                && key.callId.equals(first(invite, "Call-ID", "i"))
                && key.branch.equals(branch(invite))
                && key.localTag.equals(parameter(invite, first(invite, "From", "f"), "tag"));
    }
    private static boolean active(Map<?, ?> dialogs, Key key, Entry entry) {
        Object dialog = entry.dialog.get();
        return dialog != null && dialogs.get(key.callId) == dialog;
    }
    private static Bucket bucket(Object engine, Object manager, long now) throws Exception {
        Bucket bucket = CACHE.get(engine);
        if (bucket == null || bucket.manager.get() != manager) {
            bucket = new Bucket(manager); CACHE.put(engine, bucket);
        }
        Map<?, ?> dialogs = (Map<?, ?>) field(manager, "e");
        Iterator<Map.Entry<Key, Entry>> iterator = bucket.acks.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Key, Entry> item = iterator.next();
            long age = now - item.getValue().created;
            if (age < 0 || age >= RETAIN_NANOS && !active(dialogs, item.getKey(), item.getValue())) iterator.remove();
        }
        return bucket;
    }
    private static void diagnostic(Object engine, String text) {
        try { call(field(engine, "g"), "i", new Class<?>[]{Object.class}, text); }
        catch (Exception ignored) { /* Diagnostics never reopen a dialog. */ }
    }

    /** Called before the native dispatcher or fork handler changes transaction or dialog state. */
    public static boolean handle(Object engine, Object response) {
        boolean consumed = false;
        try {
            if (engine == null || response == null) return false;
            Key key = key(response);
            if (key == null) return false;
            Object manager = field(engine, "J");
            if (manager == null) return false;
            Entry entry;
            synchronized (CACHE) { entry = bucket(engine, manager, System.nanoTime()).acks.get(key); }
            if (entry != null) {
                consumed = true;
                call(engine, "C", new Class<?>[]{entry.ack.getClass()}, copyMessage(entry.ack));
                replayRelease(engine, entry, true);
                return true;
            }
            Object dialog = ((Map<?, ?>) field(manager, "e")).get(key.callId);
            if (dialog == null || !outgoing(dialog)) return false;
            // This app sends no outgoing re-INVITE: another original transaction cannot select this call.
            if (!matches(dialog, key)) return true;
            return false; // First accepted leg, or a distinct accepted fork, keeps native handling.
        } catch (Exception failure) {
            if (consumed) diagnostic(engine, "通话：接通确认发送暂未完成，等待对端重传");
            return consumed;
        }
    }

    /** Save the first actual native ACK before the native handler chooses connected or local release. */
    public static void remember(Object engine, Object response, Object ack) {
        try {
            if (engine == null || response == null || ack == null || !"ACK".equals(field(ack, "b"))) return;
            Key key = key(response);
            if (key == null) return;
            Object manager = field(engine, "J");
            if (manager == null) return;
            Object dialog = ((Map<?, ?>) field(manager, "e")).get(key.callId);
            if (dialog == null || !outgoing(dialog) || !matches(dialog, key)
                    || !key.remoteTag.equals(field(dialog, "l"))) return;
            Object packet = copyMessage(ack);
            synchronized (CACHE) {
                long now = System.nanoTime();
                Bucket bucket = bucket(engine, manager, now);
                if (bucket.acks.containsKey(key)) return;
                if (bucket.acks.size() >= MAX_ACKS) {
                    Map<?, ?> dialogs = (Map<?, ?>) field(manager, "e");
                    Key victim = null;
                    for (Map.Entry<Key, Entry> item : bucket.acks.entrySet())
                        if (!active(dialogs, item.getKey(), item.getValue())) { victim = item.getKey(); break; }
                    if (victim == null) victim = bucket.acks.keySet().iterator().next();
                    bucket.acks.remove(victim);
                }
                bucket.acks.put(key, new Entry(dialog, packet, now));
            }
        } catch (Exception failure) {
            diagnostic(engine, "通话：接通确认未能缓存，保留原有接通处理");
        }
    }

    private static String actionMethod(Object action) throws Exception {
        if (!"pa4".equals(action.getClass().getName())) return null;
        return (String) field(field(action, "a"), "b");
    }
    private static void nativeDispatch(Object engine, List<?> actions) throws Exception {
        try { call(engine, "k", new Class<?>[]{List.class}, actions); }
        catch (InvocationTargetException wrapped) {
            Throwable cause = wrapped.getCause();
            if (cause instanceof Error) throw (Error) cause;
            if (cause instanceof Exception) throw (Exception) cause;
            throw wrapped;
        }
    }
    /** Continue only unsent original release actions; no new BYE, CSeq, or end event is created. */
    private static void replayRelease(Object engine, Entry entry, boolean ackAlreadySent) throws Exception {
        synchronized (CACHE) {
            if (entry.processing || entry.pending == null) return;
            entry.processing = true;
        }
        try {
            while (true) {
                Object action;
                synchronized (CACHE) {
                    if (entry.next >= entry.pending.size()) { entry.pending = null; return; }
                    action = entry.pending.get(entry.next);
                    String method = actionMethod(action);
                    if (ackAlreadySent && "ACK".equals(method)) { entry.next++; continue; }
                    if ("BYE".equals(method)) {
                        if (entry.byeAttempts >= MAX_BYE_ATTEMPTS) { entry.next++; continue; }
                        entry.byeAttempts++;
                    }
                }
                try {
                    nativeDispatch(engine, Collections.singletonList(action));
                } catch (Exception failure) {
                    boolean exhausted;
                    synchronized (CACHE) {
                        exhausted = "BYE".equals(actionMethod(action)) && entry.byeAttempts >= MAX_BYE_ATTEMPTS;
                        if (exhausted) entry.next++;
                    }
                    if (!exhausted) throw failure;
                    diagnostic(engine, "通话：结束请求发送仍未完成，已停止额外重试并继续本地结束处理");
                    continue;
                }
                synchronized (CACHE) { entry.next++; }
            }
        } finally {
            synchronized (CACHE) { entry.processing = false; }
        }
    }

    /** Preserve the native action order, retaining a release batch only if it has an initial INVITE ACK. */
    public static boolean tryDispatch(Object engine, Object response, List<?> actions) {
        Entry entry = null;
        try {
            Key key = key(response);
            Object manager = field(engine, "J");
            if (key != null && manager != null) {
                boolean release = false;
                for (Object action : actions) if ("BYE".equals(actionMethod(action))) { release = true; break; }
                if (release) {
                    synchronized (CACHE) {
                        entry = bucket(engine, manager, System.nanoTime()).acks.get(key);
                        if (entry != null && entry.pending == null) entry.pending = new ArrayList<Object>(actions);
                    }
                }
            }
        } catch (Exception ignored) { /* Preserve native dispatch if no cache proof can be read. */ }
        if (entry == null) return false;
        try { replayRelease(engine, entry, false); }
        catch (Exception failure) { diagnostic(engine, "通话：取消后的接通确认或结束发送暂未完成，等待对端重传"); }
        return true;
    }

    /** A CANCEL-racing native 200 leaves D unset; a recorded ACK still proves this dialog accepted its leg. */
    public static boolean hasAccepted(Object engine, Object dialog) {
        try {
            Object manager = field(engine, "J");
            if (manager == null) return false;
            synchronized (CACHE) {
                Bucket bucket = CACHE.get(engine);
                if (bucket == null || bucket.manager.get() != manager) return false;
                Map<?, ?> dialogs = (Map<?, ?>) field(manager, "e");
                for (Map.Entry<Key, Entry> item : bucket.acks.entrySet())
                    if (item.getValue().dialog.get() == dialog && active(dialogs, item.getKey(), item.getValue())) return true;
            }
        } catch (Exception ignored) { /* An absent proof keeps the original fork guard. */ }
        return false;
    }
}
