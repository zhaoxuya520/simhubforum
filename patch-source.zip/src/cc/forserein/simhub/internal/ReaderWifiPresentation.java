package cc.forserein.simhub.internal;

import java.lang.reflect.*;

/** Reader Wi-Fi header describes its effective settings, never a synthetic SIM identity. */
public final class ReaderWifiPresentation {
    private ReaderWifiPresentation(){}
    private static String text(Object value,String field)throws ReflectiveOperationException {
        Object result=WifiConfigModel.get(value,field);return result instanceof String?(String)result:"";
    }
    private static String[] network(Object state)throws ReflectiveOperationException {
        Object config=WifiConfigModel.get(state,"f");
        if(config!=null){
            String mcc=text(config,"d"),mnc=text(config,"e");
            if(mcc.matches("[0-9]{3}")&&mnc.matches("[0-9]{2,3}"))return new String[]{mcc,mnc};
        }
        return null;
    }
    /** Keep the header short enough for its existing single-line native text layout. */
    public static String subtitle(Object state,String original){
        try{
            String[] network=network(state);if(network==null)return original;
            String name=text(WifiConfigModel.get(state,"f"),"c");
            if(name.trim().isEmpty())return original;
            Object card=WifiConfigModel.get(state,"e");
            if(card!=null&&(network[0]+network[1]).equals(card.getClass().getMethod("d").invoke(card)))return original;
            return name+" · "+network[0]+network[1];
        }catch(ReflectiveOperationException|RuntimeException ignored){return original;}
    }
    /** Reuse the native directory's exact-PLMN and unambiguous-MCC country lookup. */
    public static String country(Object state){
        try{
            String[] network=network(state);
            if(network==null){
                Object card=WifiConfigModel.get(state,"e");if(card==null)return null;
                network=new String[]{(String)card.getClass().getMethod("b").invoke(card),
                    (String)card.getClass().getMethod("c").invoke(card)};
            }
            Class<?> library=Class.forName("fj5");
            Object result=library.getMethod("c",String.class,String.class).invoke(library.getField("a").get(null),network[0],network[1]);
            return result instanceof String?(String)result:null;
        }catch(ReflectiveOperationException|RuntimeException ignored){return null;}
    }
    /** The native country-only renderer restarts with the same explicit presentation inputs. */
    public static void restartFlag(Object scope,String country,int size,int flags,int defaults)throws ReflectiveOperationException {
        Class<?> callback=Class.forName("kt1");
        Object restart=Proxy.newProxyInstance(callback.getClassLoader(),new Class<?>[]{callback},(proxy,method,args)->{
            if(method.getDeclaringClass()==Object.class){
                if(method.getName().equals("equals"))return proxy==args[0];
                if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);
                return "ReaderWifiFlagRestart";
            }
            Class.forName("fd2").getMethod("readerWifiFlag",String.class,int.class,Class.forName("lu1"),int.class,int.class)
                .invoke(null,country,size,args[0],flags|1,defaults);
            return Class.forName("sc5").getField("a").get(null);
        });
        scope.getClass().getField("d").set(scope,restart);
    }
}
