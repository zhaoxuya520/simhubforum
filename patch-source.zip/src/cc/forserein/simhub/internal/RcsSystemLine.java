package cc.forserein.simhub.internal;

import android.content.Context;
import android.os.Build;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/** Read-only optional line evidence from public Android APIs under grants already held by this app. */
public final class RcsSystemLine {
    private RcsSystemLine() {}
    private static final Pattern ICCID = Pattern.compile("[0-9]{19,20}");
    private static final Pattern E164 = Pattern.compile("\\+[1-9][0-9]{1,14}");

    public static final class Match {
        public final int subId;
        public final String number;
        public Match(int subId, String number) { this.subId = subId; this.number = number; }
    }

    /** Null means unavailable or ambiguous. Never requests permission, selects a default SIM or changes settings. */
    public static Match query(String fullIccid) {
        if (Build.VERSION.SDK_INT < 33 || !completeIccid(fullIccid)) return null;
        try {
            Object value = Class.forName("zl5").getField("f").get(null);
            return value instanceof Context ? Api33.query((Context) value, fullIccid) : null;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) {
            return null;
        }
    }

    private static boolean completeIccid(String value) {
        return value != null && ICCID.matcher(value).matches() && !value.matches("0+");
    }

    // Keep APIs introduced in 33 out of the pre-33 execution path.
    private static final class Api33 {
        private static Map<Integer, String> snapshot(SubscriptionManager manager) {
            List<SubscriptionInfo> active = manager.getActiveSubscriptionInfoList();
            if (active == null || active.isEmpty()) return null;
            Map<Integer, String> result = new LinkedHashMap<Integer, String>();
            for (SubscriptionInfo item : active) {
                if (item == null) return null;
                int id = item.getSubscriptionId();
                // DEFAULT_SUBSCRIPTION_ID is MAX_VALUE; passing it would silently select a default.
                if (id < 0 || id == Integer.MAX_VALUE || result.containsKey(id)) return null;
                String iccid = item.getIccId();
                if (!completeIccid(iccid)) return null;
                result.put(id, iccid);
            }
            return result;
        }

        private static String number(SubscriptionManager manager, int id) {
            String carrier = manager.getPhoneNumber(id, SubscriptionManager.PHONE_NUMBER_SOURCE_CARRIER);
            String ims = manager.getPhoneNumber(id, SubscriptionManager.PHONE_NUMBER_SOURCE_IMS);
            if (carrier != null && carrier.isEmpty()) carrier = null;
            if (ims != null && ims.isEmpty()) ims = null;
            // Do not infer a country or silently discard conflicting/unparseable evidence.
            if (carrier != null && !E164.matcher(carrier).matches()) return null;
            if (ims != null && !E164.matcher(ims).matches()) return null;
            if (carrier != null && ims != null && !carrier.equals(ims)) return null;
            return carrier != null ? carrier : ims;
        }

        static Match query(Context context, String fullIccid) {
            SubscriptionManager manager = context.getSystemService(SubscriptionManager.class);
            if (manager == null) return null;
            Map<Integer, String> before = snapshot(manager);
            if (before == null) return null;
            Integer selected = null;
            for (Map.Entry<Integer, String> item : before.entrySet()) {
                if (fullIccid.equals(item.getValue())) {
                    if (selected != null) return null;
                    selected = item.getKey();
                }
            }
            if (selected == null) return null;
            String line = number(manager, selected);
            if (line == null) return null;
            for (Integer other : before.keySet()) {
                if (other.equals(selected)) continue;
                String otherLine = number(manager, other);
                // If another active line cannot be inspected, uniqueness cannot be established.
                if (otherLine == null || line.equals(otherLine)) return null;
            }
            if (!before.equals(snapshot(manager))) return null;
            // Recheck the selected sources after enumeration so a changed line is never captured knowingly.
            return line.equals(number(manager, selected)) ? new Match(selected, line) : null;
        }
    }
}
