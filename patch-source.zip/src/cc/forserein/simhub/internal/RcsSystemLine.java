package cc.forserein.simhub.internal;

import android.content.Context;
import android.os.Build;
import android.se.omapi.Reader;
import android.se.omapi.SEService;
import android.telephony.SubscriptionInfo;
import android.telephony.TelephonyManager;
import android.telephony.UiccCardInfo;
import android.telephony.UiccPortInfo;
import java.util.HashSet;
import java.util.Set;
import android.telephony.SubscriptionManager;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/** Read-only optional line evidence from public Android APIs under grants already held by this app. */
public final class RcsSystemLine {
    private RcsSystemLine() {}
    private static final Pattern ICCID = Pattern.compile("[0-9]{19,20}");
    private static final Pattern E164 = Pattern.compile("\\+[1-9][0-9]{1,14}");

    public static final class Match {
        public final int subId;
        public final String number;
        public Match(int subId, String number) { this.subId = subId; this.number = number; }
    }

    /** Null means unavailable or ambiguous. Never requests permission, selects a default SIM or changes settings. */
    public static Match query(String fullIccid) {
        if (Build.VERSION.SDK_INT < 33 || !completeIccid(fullIccid)) return null;
        try {
            Object value = Class.forName("zl5").getField("f").get(null);
            return value instanceof Context ? Api33.query((Context) value, fullIccid) : null;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) {
            return null;
        }
    }

    private static boolean completeIccid(String value) {
        return value != null && ICCID.matcher(value).matches() && !value.matches("0+");
    }

    private static Map<Integer, String> snapshot(List<SubscriptionInfo> active) {
        if (active == null || active.isEmpty()) return null;
        Map<Integer, String> result = new LinkedHashMap<Integer, String>();
        for (SubscriptionInfo item : active) {
            if (item == null) return null;
            int id = item.getSubscriptionId();
            // DEFAULT_SUBSCRIPTION_ID is MAX_VALUE; passing it would silently select a default.
            if (id < 0 || id == Integer.MAX_VALUE || result.containsKey(id)) return null;
            String iccid = item.getIccId();
            if (!completeIccid(iccid)) return null;
            result.put(id, iccid);
        }
        return result;
    }

    private static Integer uniqueSubscription(Map<Integer, String> active, String fullIccid) {
        if (active == null || !completeIccid(fullIccid)) return null;
        Integer selected = null;
        for (Map.Entry<Integer, String> entry : active.entrySet()) {
            if (fullIccid.equals(entry.getValue())) {
                if (selected != null) return null;
                selected = entry.getKey();
            }
        }
        return selected;
    }

    static final class DraftLine {
        final int id, card, port, slot;
        DraftLine(int id, int card, int port, int slot) {
            this.id = id; this.card = card; this.port = port; this.slot = slot;
        }
        boolean stillMatches(DraftLine current) {
            return current != null && id == current.id
                    && (slot < 0 || (slot == current.slot && card == current.card && port == current.port));
        }
    }

    /** Caller must hold the still-selected local OMAPI reader. No own number is required for a draft. */
    static DraftLine draftLine(Context context, String iccid, Object reader, boolean requirePort) {
        try {
            SubscriptionManager manager = context.getSystemService(SubscriptionManager.class);
            if (manager == null || !completeIccid(iccid)) return null;
            List<SubscriptionInfo> rows = manager.getActiveSubscriptionInfoList();
            if (rows == null || rows.isEmpty()) return null;
            Map<Integer,String> full = snapshot(rows);
            if (full != null && !requirePort) {
                Integer id = uniqueSubscription(full, iccid);
                return id == null ? null : new DraftLine(id, -1, -1, -1);
            }
            return Build.VERSION.SDK_INT < 33 ? null : Api33.portMatch(context, rows, iccid, reader, requirePort);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) {
            return null;
        }
    }

    // Keep APIs introduced in 33 out of the pre-33 execution path.
    private static final class Api33 {
        /**
         * One other slot's SubscriptionInfo ICCID can be redacted. For draft handoff only, also
         * verify the target through Android's physical UICC, active port and actual OMAPI reader.
         * Only ordinary one-to-one physical/logical slot mappings are accepted here.
         */
        static DraftLine portMatch(Context context, List<SubscriptionInfo> rows, String iccid, Object reader,
                boolean requirePort) throws ReflectiveOperationException {
            SubscriptionInfo target = null;
            Set<Integer> ids = new HashSet<>(), slots = new HashSet<>();
            boolean redacted = false;
            for (SubscriptionInfo row : rows) {
                if (row == null) return null;
                int id = row.getSubscriptionId(), slot = row.getSimSlotIndex();
                if (id < 0 || id == Integer.MAX_VALUE || slot < 0 || slot == Integer.MAX_VALUE
                        || !ids.add(id) || !slots.add(slot)) return null;
                String value = row.getIccId();
                if ("".equals(value)) redacted = true;
                else if (!completeIccid(value)) return null;
                else if (iccid.equals(value)) {
                    if (target != null) return null;
                    target = row;
                }
            }
            if (target == null || target.getCardId() < 0 || target.getPortIndex() < 0
                    || (!redacted && !requirePort)) return null;
            TelephonyManager telephony = context.getSystemService(TelephonyManager.class);
            List<UiccCardInfo> cards = telephony == null ? null : telephony.getUiccCardsInfo();
            if (cards == null || cards.isEmpty()) return null;
            int selectedSlot = target.getSimSlotIndex();
            boolean matched = false;
            Set<Integer> physicalSlots = new HashSet<>(), activeSlots = new HashSet<>();
            for (UiccCardInfo card : cards) {
                if (card == null) return null;
                int physical = card.getPhysicalSlotIndex();
                if (physical < 0 || !physicalSlots.add(physical) || card.getPorts() == null) return null;
                for (UiccPortInfo port : card.getPorts()) {
                    if (port == null) return null;
                    if (!port.isActive()) continue;
                    int logical = port.getLogicalSlotIndex();
                    if (logical != physical || !activeSlots.add(logical)) return null;
                    if (logical == selectedSlot) {
                        if (card.getCardId() != target.getCardId() || port.getPortIndex() != target.getPortIndex()
                                || !iccid.equals(port.getIccId())) return null;
                        matched = true;
                    } else if (iccid.equals(port.getIccId()) || card.getCardId() == target.getCardId()) return null;
                }
            }
            if (!matched || !activeSlots.equals(slots) || reader == null) return null;
            Object service = WifiConfigModel.get(reader, "a"), currentReader = WifiConfigModel.get(reader, "b");
            if (!(service instanceof SEService) || !(currentReader instanceof Reader)) return null;
            SEService se = (SEService) service;
            if (!se.isConnected() || se.getUiccReader(selectedSlot + 1) != currentReader
                    || !((Reader) currentReader).isSecureElementPresent()) return null;
            return new DraftLine(target.getSubscriptionId(), target.getCardId(), target.getPortIndex(), selectedSlot);
        }

        private static String number(SubscriptionManager manager, int id) {
            String carrier = manager.getPhoneNumber(id, SubscriptionManager.PHONE_NUMBER_SOURCE_CARRIER);
            String ims = manager.getPhoneNumber(id, SubscriptionManager.PHONE_NUMBER_SOURCE_IMS);
            if (carrier != null && carrier.isEmpty()) carrier = null;
            if (ims != null && ims.isEmpty()) ims = null;
            // Do not infer a country or silently discard conflicting/unparseable evidence.
            if (carrier != null && !E164.matcher(carrier).matches()) return null;
            if (ims != null && !E164.matcher(ims).matches()) return null;
            if (carrier != null && ims != null && !carrier.equals(ims)) return null;
            return carrier != null ? carrier : ims;
        }

        static Match query(Context context, String fullIccid) {
            SubscriptionManager manager = context.getSystemService(SubscriptionManager.class);
            if (manager == null) return null;
            Map<Integer, String> before = snapshot(manager.getActiveSubscriptionInfoList());
            Integer selected = uniqueSubscription(before, fullIccid);
            if (selected == null) return null;
            String line = number(manager, selected);
            if (line == null) return null;
            for (Integer other : before.keySet()) {
                if (other.equals(selected)) continue;
                String otherLine = number(manager, other);
                // If another active line cannot be inspected, uniqueness cannot be established.
                if (otherLine == null || line.equals(otherLine)) return null;
            }
            if (!before.equals(snapshot(manager.getActiveSubscriptionInfoList()))) return null;
            // Recheck the selected sources after enumeration so a changed line is never captured knowingly.
            return line.equals(number(manager, selected)) ? new Match(selected, line) : null;
        }
    }
}
