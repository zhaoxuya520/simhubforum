package cc.forserein.simhub.internal;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.se.omapi.Reader;
import android.se.omapi.SEService;
import android.telephony.SubscriptionInfo;
import android.telephony.TelephonyManager;
import android.telephony.UiccCardInfo;
import android.telephony.UiccPortInfo;
import java.util.HashSet;
import java.util.Set;
import android.telephony.SubscriptionManager;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/** Read-only optional line evidence from public Android APIs under grants already held by this app. */
public final class RcsSystemLine {
    private RcsSystemLine() {}
    private static final Pattern ICCID = Pattern.compile("[0-9]{19,20}");
    private static final Pattern E164 = Pattern.compile("\\+[1-9][0-9]{1,14}");

    public static final class Match {
        public final int subId;
        public final String number;
        public Match(int subId, String number) { this.subId = subId; this.number = number; }
    }

    /** Null means unavailable or ambiguous. Never requests permission, selects a default SIM or changes settings. */
    public static Match query(String fullIccid) {
        if (Build.VERSION.SDK_INT < 33 || !completeIccid(fullIccid)) return null;
        try {
            Object value = Class.forName("zl5").getField("f").get(null);
            return value instanceof Context ? Api33.query((Context) value, fullIccid) : null;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) {
            return null;
        }
    }

    private static boolean completeIccid(String value) {
        return value != null && ICCID.matcher(value).matches() && !value.matches("0+");
    }

    private static Map<Integer, String> snapshot(List<SubscriptionInfo> active) {
        if (active == null || active.isEmpty()) return null;
        Map<Integer, String> result = new LinkedHashMap<Integer, String>();
        for (SubscriptionInfo item : active) {
            if (item == null) return null;
            int id = item.getSubscriptionId();
            // DEFAULT_SUBSCRIPTION_ID is MAX_VALUE; passing it would silently select a default.
            if (id < 0 || id == Integer.MAX_VALUE || result.containsKey(id)) return null;
            String iccid = item.getIccId();
            if (!completeIccid(iccid)) return null;
            result.put(id, iccid);
        }
        return result;
    }

    private static Integer uniqueSubscription(Map<Integer, String> active, String fullIccid) {
        if (active == null || !completeIccid(fullIccid)) return null;
        Integer selected = null;
        for (Map.Entry<Integer, String> entry : active.entrySet()) {
            if (fullIccid.equals(entry.getValue())) {
                if (selected != null) return null;
                selected = entry.getKey();
            }
        }
        return selected;
    }

    static final class DraftLine {
        // No Android subscription was selected for this manual draft.
        static final DraftLine MANUAL = new DraftLine(-1, -1, -1, -1);
        final int id, card, port, slot;
        DraftLine(int id, int card, int port, int slot) {
            this.id = id; this.card = card; this.port = port; this.slot = slot;
        }
        boolean stillMatches(DraftLine current) {
            return current != null && (this == MANUAL || (id == current.id
                    && (slot < 0 || (slot == current.slot && card == current.card && port == current.port))));
        }
    }

    /** Caller must hold the still-selected local OMAPI reader. No own number is required for a draft. */
    static DraftLine draftLine(Context context, String iccid, Object reader, boolean requirePort) {
        if (reader == null || !completeIccid(iccid)) return null;
        try {
            SubscriptionManager manager = context.getSystemService(SubscriptionManager.class);
            if (manager == null) return null;
            boolean completeScope = Build.VERSION.SDK_INT >= 30 && (context.checkSelfPermission(
                    "android.permission.READ_PHONE_STATE") == PackageManager.PERMISSION_GRANTED
                    || context.checkSelfPermission("android.permission.READ_PRIVILEGED_PHONE_STATE") == PackageManager.PERMISSION_GRANTED);
            // A carrier-privileged app may see only its own subscriptions. An empty visible
            // list or an unrelated visible row is not proof that the chosen card is absent.
            List<SubscriptionInfo> rows = completeScope ? Api30.allActive(manager) : manager.getActiveSubscriptionInfoList();
            if (rows == null || rows.isEmpty()) return completeScope ? null : DraftLine.MANUAL;
            SubscriptionInfo target = null;
            Set<Integer> ids = new HashSet<>();
            boolean hidden = false;
            for (SubscriptionInfo row : rows) {
                if (row == null) return null;
                int id = row.getSubscriptionId();
                if (id < 0 || id == Integer.MAX_VALUE || !ids.add(id)) return null;
                String value = row.getIccId();
                if (hiddenIccid(value)) {
                    hidden = true;
                } else if (!completeIccid(value)) {
                    return null;
                } else if (iccid.equals(value)) {
                    if (target != null) return null;
                    target = row;
                }
            }
            if (completeScope && !hidden && target == null) return null;
            if (completeScope && !hidden && !requirePort) return new DraftLine(target.getSubscriptionId(), -1, -1, -1);
            if (Build.VERSION.SDK_INT < 33) return requirePort ? null : DraftLine.MANUAL;
            return Api33.portMatch(context, rows, iccid, reader, target, completeScope);
        } catch (SecurityException denied) {
            // A regular installation may be unable to enumerate subscriptions or inspect UICC ports.
            // A draft can still be edited with an explicit choice of SIM in the default SMS app.
            return requirePort ? null : DraftLine.MANUAL;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) {
            return null;
        }
    }

    private static boolean hiddenIccid(String value) {
        return value == null || value.isEmpty() || "FFFFFFFFFFFFFFFFFFFF".equals(value);
    }

    private static final class Api30 {
        static List<SubscriptionInfo> allActive(SubscriptionManager manager) {
            return manager.getCompleteActiveSubscriptionInfoList();
        }
    }

    // Keep APIs introduced in 33 out of the pre-33 execution path.
    private static final class Api33 {
        /** If some row identities are hidden, use any available slot/port evidence to reject a
         * contradiction. Only a full match of the selected row, port and reader can prove a line. */
        static DraftLine portMatch(Context context, List<SubscriptionInfo> rows, String iccid, Object reader,
                SubscriptionInfo target, boolean completeScope) throws ReflectiveOperationException {
            Map<Integer, SubscriptionInfo> slots = new LinkedHashMap<>();
            for (SubscriptionInfo row : rows) {
                int slot = row.getSimSlotIndex();
                if (slot == SubscriptionManager.INVALID_SIM_SLOT_INDEX) continue;
                if (slot < 0 || slot == Integer.MAX_VALUE || slots.put(slot, row) != null) return null;
            }
            boolean allSlotsVisible = slots.size() == rows.size();
            TelephonyManager telephony = context.getSystemService(TelephonyManager.class);
            List<UiccCardInfo> cards = telephony == null ? null : telephony.getUiccCardsInfo();
            if (cards == null || cards.isEmpty()) return DraftLine.MANUAL;

            Set<Integer> physicalSlots = new HashSet<>(), activeSlots = new HashSet<>();
            Set<Integer> knownOtherSlots = new HashSet<>();
            int matchingPhysical = -1;
            boolean standardSlots = true;
            DraftLine verified = null;
            for (UiccCardInfo card : cards) {
                if (card == null) return null;
                int physical = card.getPhysicalSlotIndex();
                if (physical < 0 || !physicalSlots.add(physical)) return null;
                if (card.getPorts() == null) continue;
                for (UiccPortInfo port : card.getPorts()) {
                    if (port == null) return null;
                    if (!port.isActive()) {
                        if (target != null && physical == target.getSimSlotIndex()
                                && target.getCardId() >= 0 && card.getCardId() == target.getCardId()
                                && target.getPortIndex() >= 0 && port.getPortIndex() == target.getPortIndex()) return null;
                        continue;
                    }
                    int logical = port.getLogicalSlotIndex();
                    SubscriptionInfo row = slots.get(logical);
                    if (logical < 0 || !activeSlots.add(logical) || (row == null && completeScope && allSlotsVisible)) return null;
                    if (logical != physical) standardSlots = false;
                    if (row != null && row.getCardId() >= 0 && card.getCardId() >= 0 && row.getCardId() != card.getCardId()) return null;
                    if (row != null && row.getPortIndex() >= 0 && port.getPortIndex() >= 0 && row.getPortIndex() != port.getPortIndex()) return null;
                    String rowId = row == null ? null : row.getIccId(), portId = port.getIccId();
                    if (!hiddenIccid(portId) && !completeIccid(portId)) return null;
                    if (completeIccid(rowId) && completeIccid(portId) && !rowId.equals(portId)) return null;
                    if (target != null && row != target && target.getCardId() >= 0 && card.getCardId() == target.getCardId()) return null;
                    if (iccid.equals(rowId) || iccid.equals(portId)) {
                        if (matchingPhysical >= 0) return null;
                        matchingPhysical = physical;
                        if (completeScope && target != null && row == target && iccid.equals(portId) && row.getCardId() >= 0
                                && row.getCardId() == card.getCardId() && row.getPortIndex() >= 0
                                && row.getPortIndex() == port.getPortIndex()) {
                            verified = new DraftLine(row.getSubscriptionId(), row.getCardId(), row.getPortIndex(), logical);
                        }
                    } else if (completeIccid(rowId) || completeIccid(portId)) {
                        knownOtherSlots.add(logical);
                    }
                }
            }
            if (completeScope && allSlotsVisible && knownOtherSlots.containsAll(slots.keySet())) return null;

            Object service, currentReader;
            try {
                service = WifiConfigModel.get(reader, "a");
                currentReader = WifiConfigModel.get(reader, "b");
            } catch (ReflectiveOperationException unavailable) {
                return DraftLine.MANUAL;
            }
            if (!(service instanceof SEService) || !(currentReader instanceof Reader)) return DraftLine.MANUAL;
            SEService se = (SEService) service;
            if (!se.isConnected() || !((Reader) currentReader).isSecureElementPresent()) return null;
            if (matchingPhysical >= 0) {
                Reader matchedReader = readerAt(se, matchingPhysical);
                if (matchedReader == null) return DraftLine.MANUAL;
                if (matchedReader != currentReader) return null;
            } else if (standardSlots) {
                for (Integer other : knownOtherSlots) {
                    if (readerAt(se, other) == currentReader) return null;
                }
            }
            return verified != null && standardSlots && allSlotsVisible && activeSlots.equals(slots.keySet()) ? verified : DraftLine.MANUAL;
        }

        private static Reader readerAt(SEService service, int physicalSlot) {
            try {
                return service.getUiccReader(physicalSlot + 1);
            } catch (IllegalArgumentException | UnsupportedOperationException inaccessible) {
                return null;
            }
        }

        private static String number(SubscriptionManager manager, int id) {
            String carrier = manager.getPhoneNumber(id, SubscriptionManager.PHONE_NUMBER_SOURCE_CARRIER);
            String ims = manager.getPhoneNumber(id, SubscriptionManager.PHONE_NUMBER_SOURCE_IMS);
            if (carrier != null && carrier.isEmpty()) carrier = null;
            if (ims != null && ims.isEmpty()) ims = null;
            // Do not infer a country or silently discard conflicting/unparseable evidence.
            if (carrier != null && !E164.matcher(carrier).matches()) return null;
            if (ims != null && !E164.matcher(ims).matches()) return null;
            if (carrier != null && ims != null && !carrier.equals(ims)) return null;
            return carrier != null ? carrier : ims;
        }

        static Match query(Context context, String fullIccid) {
            SubscriptionManager manager = context.getSystemService(SubscriptionManager.class);
            if (manager == null) return null;
            Map<Integer, String> before = snapshot(manager.getActiveSubscriptionInfoList());
            Integer selected = uniqueSubscription(before, fullIccid);
            if (selected == null) return null;
            String line = number(manager, selected);
            if (line == null) return null;
            for (Integer other : before.keySet()) {
                if (other.equals(selected)) continue;
                String otherLine = number(manager, other);
                // If another active line cannot be inspected, uniqueness cannot be established.
                if (otherLine == null || line.equals(otherLine)) return null;
            }
            if (!before.equals(snapshot(manager.getActiveSubscriptionInfoList()))) return null;
            // Recheck the selected sources after enumeration so a changed line is never captured knowingly.
            return line.equals(number(manager, selected)) ? new Match(selected, line) : null;
        }
    }
}
