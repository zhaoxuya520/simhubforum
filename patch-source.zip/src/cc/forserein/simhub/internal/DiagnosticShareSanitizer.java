package cc.forserein.simhub.internal;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Redacts subscriber and authentication values only in user-initiated diagnostic shares. */
public final class DiagnosticShareSanitizer {
    private DiagnosticShareSanitizer() {}
    private static final String HIDDEN="[redacted]";
    private static final Pattern AUTH=Pattern.compile("(?i)\\b(?:Proxy-Authorization|Authorization|WWW-Authenticate|Proxy-Authenticate|Authentication-Info)\\s*:");
    private static final Pattern PARAM=Pattern.compile("([A-Za-z][A-Za-z0-9_-]*)\\s*=\\s*(\"(?:\\\\.|[^\"\\\\])*\"|[^,\\s]+)");
    private static final Pattern URI=Pattern.compile("(?i)\\b(sips?|tel):([^\\s<>\"\\[\\]]+|\\[[^\\s<>\"]*\\][^\\s<>\"]*)");
    private static final Pattern CALL_ID=Pattern.compile("(?i)\\bCall-ID\\s*:\\s*[^\\s<>|]+");
    private static final Pattern TIME=Pattern.compile("^\\s*\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?([ \\t]+)");
    private static final Pattern HEADER=Pattern.compile("^(?:[←→]\\s*)?(?:[0-9]{3}\\s+)?[\\p{L}][\\p{L}0-9_-]*\\s*[:：]");
    private static final Pattern RECORD=Pattern.compile("(?i)^(?:[←→]|[0-9]{3}\\s|SIP/2\\.0\\b|(?:RTP|RTCP|SDP)\\b)");
    private static final String LOG_PREFIX="^[ \\t]*(?:\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?[ \\t]+)?";
    private static final Pattern IDENTITY_HEADER=Pattern.compile(
        LOG_PREFIX+"(?:[←→]\\s*)?(?:[0-9]{3}\\s+)?(?:P-Asserted-Identity|P-Preferred-Identity|Remote-Party-ID|From|To|Contact|[ftm])\\s*:",
        Pattern.CASE_INSENSITIVE);
    private static final Pattern SMS_SENDER=Pattern.compile("("+LOG_PREFIX+"收到短信 来自 )([+]?\\d+)(?=\\s|$)");
    private static final Pattern INVITE_CALLER=Pattern.compile("("+LOG_PREFIX+"← 来电 INVITE 来自 )([^\\r\\n]*?)(?=；语音编码：)");
    private static final Pattern CALLER=Pattern.compile("("+LOG_PREFIX+"来电 )([^\\r\\n]*?)(?=（前提条件 )");
    private static final Pattern PARAM_START=Pattern.compile("^,?\\s*[A-Za-z][A-Za-z0-9_-]*\\s*=");

    public static String sanitize(String text) {
        if(text==null||text.isEmpty())return text;
        String[] lines=text.split("\\r\\n|\\r|\\n",-1);
        StringBuilder out=new StringBuilder(text.length());boolean authentication=false;
        for(int i=0;i<lines.length;i++){
            int lineIndex=i;
            String line=lines[i],clean;
            Matcher identityHeader=IDENTITY_HEADER.matcher(line);
            if(identityHeader.find()){
                int headerEnd=identityHeader.end();
                StringBuilder header=new StringBuilder(line);
                while(i+1<lines.length && isHeaderFold(lines[i+1]))header.append(' ').append(lines[++i].trim());
                line=redactDisplayNames(header.toString(),headerEnd);
            }
            Matcher auth=AUTH.matcher(line);
            if(auth.find()){
                clean=line.substring(0,auth.end())+authenticationValue(line.substring(auth.end()));
                authentication=true;
            }else{
                Matcher time=TIME.matcher(line);int offset=time.find()?time.start(1):0;
                String body=line.substring(offset),trimmed=body.trim();
                int indentation=0;while(indentation<body.length()&&Character.isWhitespace(body.charAt(indentation)))indentation++;
                // One space is the logger's timestamp separator. Additional indentation can be a folded value.
                boolean indented=indentation>(offset==0?0:1);
                boolean nextRecord=HEADER.matcher(trimmed).find()||RECORD.matcher(trimmed).find();
                boolean continuation=authentication&&!trimmed.isEmpty()
                    &&((indented&&!nextRecord)
                        ||PARAM_START.matcher(trimmed).find());
                if(continuation)clean=line.substring(0,offset)+authenticationValue(body);
                else{
                    authentication=false;
                    clean=recordIdentities(line);
                }
            }
            if(lineIndex>0)out.append('\n');out.append(clean);
        }
        return out.toString();
    }

    private static boolean isHeaderFold(String line) {
        if(line.isEmpty() || (line.charAt(0)!=' ' && line.charAt(0)!='\t'))return false;
        String body=line.trim();
        return !body.isEmpty() && !HEADER.matcher(body).find() && !RECORD.matcher(body).find()
            && !TIME.matcher(line).find();
    }

    /** Mask the optional display name in each SIP name-addr. Commas and angle
     * brackets inside a quoted name are data, not address separators. */
    private static String redactDisplayNames(String line,int start) {
        StringBuilder out=new StringBuilder(line.length());
        int copied=0, nameStart=start;
        boolean quoted=false, inAddress=false;
        for(int i=start;i<line.length();i++){
            char c=line.charAt(i);
            if(quoted && c=='\\' && i+1<line.length()){i++;continue;}
            if(!inAddress && c=='"'){quoted=!quoted;continue;}
            if(quoted)continue;
            if(c=='<' && !inAddress){
                int first=nameStart,last=i;
                while(first<last && Character.isWhitespace(line.charAt(first)))first++;
                while(last>first && Character.isWhitespace(line.charAt(last-1)))last--;
                if(first<last){
                    out.append(line,copied,first).append(HIDDEN);
                    copied=last;
                }
                inAddress=true;
            }else if(c=='>')inAddress=false;
            else if(c==',' && !inAddress)nameStart=i+1;
        }
        return out.append(line,copied,line.length()).toString();
    }

    private static String authenticationValue(String value) {
        String trimmed=value.trim();
        if(trimmed.isEmpty())return value;
        String prefix=value.substring(0,value.indexOf(trimmed));
        if(trimmed.regionMatches(true,0,"Digest",0,6)
                &&(trimmed.length()==6||Character.isWhitespace(trimmed.charAt(6)))){
            prefix+=trimmed.substring(0,6);trimmed=trimmed.substring(6);
        }else if(!PARAM_START.matcher(trimmed).find()){
            // Bearer/Basic/other token schemes and unparseable folded fragments.
            return prefix+HIDDEN;
        }
        Matcher params=PARAM.matcher(trimmed);StringBuilder out=new StringBuilder(prefix);int end=0;
        while(params.find()){
            out.append(separator(trimmed.substring(end,params.start())));
            String key=params.group(1),raw=params.group(2),lower=key.toLowerCase(Locale.ROOT);
            out.append(key).append('=');
            if(lower.equals("realm")||lower.equals("algorithm")||lower.equals("qop")
                    ||lower.equals("nc")||lower.equals("stale")||lower.equals("charset")
                    ||lower.equals("userhash")||lower.equals("uri"))out.append(identities(raw));
            else out.append(raw.startsWith("\"")?"\""+HIDDEN+"\"":HIDDEN);
            end=params.end();
        }
        out.append(separator(trimmed.substring(end)));
        return out.toString();
    }

    private static String separator(String value){return value.matches("[\\s,]*")?value:HIDDEN;}

    private static String recordIdentities(String line){
        line=SMS_SENDER.matcher(line).replaceAll("$1"+HIDDEN);
        line=INVITE_CALLER.matcher(line).replaceAll("$1"+HIDDEN);
        line=CALLER.matcher(line).replaceAll("$1"+HIDDEN);
        Matcher ids=CALL_ID.matcher(line);StringBuilder out=new StringBuilder();int end=0;
        while(ids.find()){
            out.append(identities(line.substring(end,ids.start()))).append(ids.group());end=ids.end();
        }
        return out.append(identities(line.substring(end))).toString();
    }

    private static String identities(String value) {
        Matcher uri=URI.matcher(value);StringBuffer out=new StringBuffer();
        while(uri.find()){
            String scheme=uri.group(1),body=uri.group(2),replacement=uri.group();
            if(scheme.equalsIgnoreCase("tel")){
                int end=body.indexOf(';');if(end<0)end=body.indexOf('?');if(end<0)end=body.length();
                replacement=scheme+":"+HIDDEN+body.substring(end);
            }else{
                int at=body.indexOf('@');
                if(at<0){
                    int query=body.indexOf('?');String address=query<0?body:body.substring(0,query);
                    at=address.toLowerCase(Locale.ROOT).lastIndexOf("%40");
                }
                if(at>=0)replacement=scheme+":"+HIDDEN+body.substring(at);
            }
            uri.appendReplacement(out,Matcher.quoteReplacement(replacement));
        }
        uri.appendTail(out);return out.toString();
    }
}
