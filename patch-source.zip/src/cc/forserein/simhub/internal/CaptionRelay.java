package cc.forserein.simhub.internal;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

/** An origin and its server-issued device credential stay together, including on replacement. */
final class CaptionRelay {
    final String origin;
    final String token;

    CaptionRelay(String pairing) {
        try {
            URI uri = new URI(pairing);
            if (!"https".equals(uri.getScheme()) || uri.getHost()==null || uri.getRawUserInfo()!=null ||
                    uri.getRawQuery()!=null || !("".equals(uri.getRawPath()) || "/".equals(uri.getRawPath())) ||
                    uri.getRawFragment()==null || !uri.getRawFragment().matches("sh1_[A-Za-z0-9_-]{43}"))
                throw new IllegalArgumentException();
            origin = "https://" + uri.getRawAuthority();
            token = uri.getRawFragment();
        } catch (Exception invalid) {
            throw new IllegalArgumentException("请输入服务器签发的完整 HTTPS 配对链接");
        }
    }

    String testModels() throws Exception {
        HttpURLConnection c=open("/v1/test","POST");
        try {
            c.setDoOutput(true);
            c.setFixedLengthStreamingMode(0);
            c.getOutputStream().close();
            int code=c.getResponseCode();
            if (code==401 || code==403) return "配对已失效，请重新配对";
            if (code==404) return "请将中转服务升级到 25.5 或更新版本";
            if (code!=200) return "中转测试失败（HTTP "+code+"）";
            try (BufferedReader in=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8))) {
                JSONObject data=new JSONObject(in.readLine());
                return "字幕 · "+modelStatus(data.getInt("captions"))+"     同传 · "+modelStatus(data.getInt("voice"));
            }
        } finally {c.disconnect();}
    }

    private static String modelStatus(int code) {
        if (code==200) return "可用";
        if (code==401 || code==403) return "授权失败";
        if (code==429) return "配额受限";
        if (code==404) return "模型不可用";
        return "测试失败（"+code+"）";
    }

    HttpURLConnection open(String path, String method) throws IOException {
        HttpURLConnection c = (HttpURLConnection)new URL(origin + path).openConnection();
        c.setRequestMethod(method);
        c.setInstanceFollowRedirects(false);
        c.setUseCaches(false);
        c.setConnectTimeout(8000);
        c.setReadTimeout(25000);
        c.setRequestProperty("Authorization","Bearer " + token);
        return c;
    }
}
