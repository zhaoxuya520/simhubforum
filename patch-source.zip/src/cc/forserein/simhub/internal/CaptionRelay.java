package cc.forserein.simhub.internal;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

/** An origin and its server-issued device credential stay together, including on replacement. */
final class CaptionRelay {
    final String origin;
    final String token;

    CaptionRelay(String pairing) {
        try {
            URI uri = new URI(pairing);
            if (!"https".equals(uri.getScheme()) || uri.getHost()==null || uri.getRawUserInfo()!=null ||
                    uri.getRawQuery()!=null || !("".equals(uri.getRawPath()) || "/".equals(uri.getRawPath())) ||
                    uri.getRawFragment()==null || !uri.getRawFragment().matches("sh1_[A-Za-z0-9_-]{43}"))
                throw new IllegalArgumentException();
            origin = "https://" + uri.getRawAuthority();
            token = uri.getRawFragment();
        } catch (Exception invalid) {
            throw new IllegalArgumentException("请输入服务器签发的完整 HTTPS 配对链接");
        }
    }

    HttpURLConnection open(String path, String method) throws IOException {
        HttpURLConnection c = (HttpURLConnection)new URL(origin + path).openConnection();
        c.setRequestMethod(method);
        c.setInstanceFollowRedirects(false);
        c.setUseCaches(false);
        c.setConnectTimeout(8000);
        c.setReadTimeout(25000);
        c.setRequestProperty("Authorization","Bearer " + token);
        return c;
    }
}
