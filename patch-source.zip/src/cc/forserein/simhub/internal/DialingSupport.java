package cc.forserein.simhub.internal;

import java.util.regex.Pattern;

/** Number formatting at the existing call and SMS entry points. No carrier guessing. */
public final class DialingSupport {
    private DialingSupport() {}

    /** Preserve dial-string punctuation while converting decimal digits and fullwidth +. */
    public static String ascii(String input) {
        input.getClass();
        StringBuilder out = new StringBuilder(input.length());
        for (int offset = 0; offset < input.length();) {
            int cp = input.codePointAt(offset);
            offset += Character.charCount(cp);
            if (Character.isDigit(cp)) {
                out.append((char) ('0' + Character.digit(cp, 10)));
            } else if (cp == 0xff0b) {
                out.append('+');
            } else {
                out.appendCodePoint(cp);
            }
        }
        return out.toString();
    }

    /**
     * Remove an explicit optional domestic trunk marker when the destination
     * numbering plan and national part support that notation.
     */
    public static String callInput(String input) {
        String text = ascii(input);
        StringBuilder compact = new StringBuilder(text.length());
        int[] positions = new int[text.length()];
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isWhitespace(c) || Character.isSpaceChar(c) || c == '-' || c == '\uff0d') continue;
            positions[compact.length()] = i;
            compact.append(c == '\uff08' ? '(' : c == '\uff09' ? ')' : c);
        }
        String number = compact.toString();
        int start = number.startsWith("+") ? 1 : number.startsWith("00") ? 2 : -1;
        int marker = number.indexOf("(0)");
        if (start < 0 || marker <= start || marker - start > 3 || number.charAt(start) == '0')
            return text;
        int code = 0;
        for (int i = start; i < marker; i++) {
            char c = number.charAt(i);
            if (c < '0' || c > '9') return text;
            code = code * 10 + c - '0';
        }
        int national = marker + 3;
        if (national >= number.length() || number.charAt(national) == '0') return text;
        for (int i = national; i < number.length(); i++) {
            char c = number.charAt(i);
            if (c < '0' || c > '9') return text;
        }
        if (!optionalTrunk(code, number.substring(national))) return text;
        // Delete the original marker span only; retain all other formatting.
        return text.substring(0, positions[marker]) + text.substring(positions[national - 1] + 1);
    }

    private static boolean optionalTrunk(int code, String national) {
        int count = national.length();
        // Retain the two previously supported plans' length bounds.
        if (code == 44) return count >= 7 && count <= 10;
        if (code == 49) return count >= 4 && count <= 15;
        if (count > 15 - String.valueOf(code).length()) return false;
        String rule = nationalPattern(code);
        if (rule == null) return false;
        Pattern plan = Pattern.compile(rule);
        return plan.matcher(national).matches() && !plan.matcher("0" + national).matches();
    }

    // BEGIN GENERATED NUMBERING PLANS
    // Derived from Google libphonenumber v9.0.18 (Apache License 2.0).
    // Copyright (C) 2009 The Libphonenumber Authors.
    // See validation/native-international-dialing/numbering_plans.py.
    private static String nationalPattern(int code) {
        switch (code) {
            case 20: // EG
                return "[189]\\d{8,9}|[24-6]\\d{8}|[135]\\d{7}";
            case 27: // ZA
                return "[1-79]\\d{8}|8\\d{4,9}";
            case 31: // NL
                return "(?:[124-7]\\d\\d|3(?:[02-9]\\d|1[0-8]))\\d{6}|8\\d{6,9}|9\\d{6,10}|1\\d{4,5}";
            case 32: // BE
                return "4\\d{8}|[1-9]\\d{7}";
            case 33: // FR
                return "[1-9]\\d{8}";
            case 40: // RO
                return "(?:[236-8]\\d|90)\\d{7}|[23]\\d{5}";
            case 41: // CH
                return "8\\d{11}|[2-9]\\d{8}";
            case 43: // AT
                return "1\\d{3,12}|2\\d{6,12}|43(?:(?:0\\d|5[02-9])\\d{3,9}|2\\d{4,5}|[3467]\\d{4}|8\\d{4,6}|9\\d{4,7})|5\\d{4,12}|8\\d{7,12}|9\\d{8,12}|(?:[367]\\d|4[0-24-9])\\d{4,11}";
            case 46: // SE
                return "(?:[26]\\d\\d|9)\\d{9}|[1-9]\\d{8}|[1-689]\\d{7}|[1-4689]\\d{6}|2\\d{5}";
            case 51: // PE
                return "(?:[14-8]|9\\d)\\d{7}";
            case 53: // CU
                return "(?:[2-7]|8\\d\\d)\\d{7}|[2-47]\\d{6}|[34]\\d{5}";
            case 57: // CO
                return "(?:46|60\\d\\d)\\d{6}|(?:1\\d|[39])\\d{9}";
            case 58: // VE
                return "[68]00\\d{7}|(?:[24]\\d|[59]0)\\d{8}";
            case 60: // MY
                return "1\\d{8,9}|(?:3\\d|[4-9])\\d{7}";
            case 62: // ID
                return "00[1-9]\\d{9,14}|(?:[1-36]|8\\d{5})\\d{6}|00\\d{9}|[1-9]\\d{8,10}|[2-9]\\d{7}";
            case 63: // PH
                return "(?:[2-7]|9\\d)\\d{8}|2\\d{5}|(?:1800|8)\\d{7,9}";
            case 64: // NZ
                return "[1289]\\d{9}|50\\d{5}(?:\\d{2,3})?|[27-9]\\d{7,8}|(?:[34]\\d|6[0-35-9])\\d{6}|8\\d{4,6}";
            case 66: // TH
                return "(?:001800|[2-57]|[689]\\d)\\d{7}|1\\d{7,9}";
            case 82: // KR
                return "00[1-9]\\d{8,11}|(?:[12]|5\\d{3})\\d{7}|[13-6]\\d{9}|(?:[1-6]\\d|80)\\d{7}|[3-6]\\d{4,5}|(?:00|7)0\\d{8}";
            case 84: // VN
                return "[12]\\d{9}|[135-9]\\d{8}|[16]\\d{7}|[16-8]\\d{6}";
            case 86: // CN
                return "(?:(?:1[03-689]|2\\d)\\d\\d|6)\\d{8}|1\\d{10}|[126]\\d{6}(?:\\d(?:\\d{2})?)?|86\\d{5,6}|(?:[3-579]\\d|8[0-57-9])\\d{5,9}";
            case 90: // TR
                return "4\\d{6}|8\\d{11,12}|(?:[2-58]\\d\\d|900)\\d{7}";
            case 91: // IN
                return "(?:000800|[2-9]\\d\\d)\\d{7}|1\\d{7,12}";
            case 92: // PK
                return "122\\d{6}|[24-8]\\d{10,11}|9(?:[013-9]\\d{8,10}|2(?:[01]\\d\\d|2(?:[06-8]\\d|1[01]))\\d{7})|(?:[2-8]\\d{3}|92(?:[0-7]\\d|8[1-9]))\\d{6}|[24-9]\\d{8}|[89]\\d{7}";
            case 93: // AF
                return "[2-7]\\d{8}";
            case 94: // LK
                return "[1-9]\\d{8}";
            case 95: // MM
                return "1\\d{5,7}|95\\d{6}|(?:[4-7]|9[0-46-9])\\d{6,8}|(?:2|8\\d)\\d{5,8}";
            case 98: // IR
                return "[1-9]\\d{9}|(?:[1-8]\\d\\d|9)\\d{3,4}";
            case 211: // SS
                return "[19]\\d{8}";
            case 212: // EH, MA
                return "[5-8]\\d{8}";
            case 213: // DZ
                return "(?:[1-4]|[5-79]\\d|80)\\d{7}";
            case 218: // LY
                return "[2-9]\\d{8}";
            case 231: // LR
                return "(?:[2457]\\d|33|88)\\d{7}|(?:2\\d|[4-6])\\d{6}";
            case 232: // SL
                return "(?:[237-9]\\d|66)\\d{6}";
            case 233: // GH
                return "(?:[235]\\d{3}|800)\\d{5}";
            case 234: // NG
                return "(?:20|9\\d)\\d{8}|[78]\\d{9,13}";
            case 243: // CD
                return "(?:(?:[189]|5\\d)\\d|2)\\d{7}|[1-68]\\d{6}";
            case 249: // SD
                return "[19]\\d{8}";
            case 250: // RW
                return "(?:06|[27]\\d\\d|[89]00)\\d{6}";
            case 251: // ET
                return "(?:11|[2-579]\\d)\\d{7}";
            case 252: // SO
                return "[346-9]\\d{8}|[12679]\\d{7}|[1-5]\\d{6}|[1348]\\d{5}";
            case 254: // KE
                return "(?:[17]\\d\\d|900)\\d{6}|(?:2|80)0\\d{6,7}|[4-6]\\d{6,8}";
            case 255: // TZ
                return "(?:[25-8]\\d|41|90)\\d{7}";
            case 256: // UG
                return "800\\d{6}|(?:[29]0|[347]\\d)\\d{7}";
            case 260: // ZM
                return "800\\d{6}|(?:21|[579]\\d|63)\\d{7}";
            case 262: // RE, YT
                return "7093\\d{5}|(?:80|9\\d)\\d{7}|(?:26|63)9\\d{6}|709\\d{6}|(?:26|[689]\\d)\\d{7}";
            case 263: // ZW
                return "2(?:[0-57-9]\\d{6,8}|6[0-24-9]\\d{6,7})|[38]\\d{9}|[35-8]\\d{8}|[3-6]\\d{7}|[1-689]\\d{6}|[1-3569]\\d{5}|[1356]\\d{4}";
            case 264: // NA
                return "[68]\\d{7,8}";
            case 265: // MW
                return "(?:[1289]\\d|31|77)\\d{7}|1\\d{6}";
            case 291: // ER
                return "[178]\\d{6}";
            case 353: // IE
                return "(?:1\\d|[2569])\\d{6,8}|4\\d{6,9}|7\\d{8}|8\\d{8,9}";
            case 355: // AL
                return "(?:700\\d\\d|900)\\d{3}|8\\d{5,7}|(?:[2-5]|6\\d)\\d{7}";
            case 358: // AX, FI
                return "2\\d{4,9}|35\\d{4,5}|(?:60\\d\\d|800)\\d{4,6}|7\\d{5,11}|(?:[14]\\d|3[0-46-9]|50)\\d{4,8}|[1-35689]\\d{4}|7\\d{10,11}|(?:[124-7]\\d|3[0-46-9])\\d{8}|[1-9]\\d{5,8}";
            case 359: // BG
                return "00800\\d{7}|[2-7]\\d{6,7}|[89]\\d{6,8}|2\\d{5}";
            case 370: // LT
                return "(?:[3469]\\d|52|[78]0)\\d{6}";
            case 373: // MD
                return "(?:[235-7]\\d|[89]0)\\d{6}";
            case 374: // AM
                return "(?:[1-489]\\d|55|60|77)\\d{6}";
            case 377: // MC
                return "(?:[3489]|[67]\\d)\\d{7}";
            case 380: // UA
                return "[89]\\d{9}|[3-9]\\d{8}";
            case 381: // RS
                return "38[02-9]\\d{6,9}|6\\d{7,9}|90\\d{4,8}|38\\d{5,6}|(?:7\\d\\d|800)\\d{3,9}|(?:[12]\\d|3[0-79])\\d{5,10}";
            case 382: // ME
                return "(?:20|[3-79]\\d)\\d{6}|80\\d{6,7}";
            case 383: // XK
                return "2\\d{7,8}|3\\d{7,11}|(?:4\\d\\d|[89]00)\\d{5}";
            case 385: // HR
                return "[2-69]\\d{8}|80\\d{5,7}|[1-79]\\d{7}|6\\d{6}";
            case 386: // SI
                return "[1-7]\\d{7}|8\\d{4,7}|90\\d{4,6}";
            case 387: // BA
                return "6\\d{8}|(?:[35689]\\d|49|70)\\d{6}";
            case 389: // MK
                return "[2-578]\\d{7}";
            case 421: // SK
                return "[2-689]\\d{8}|[2-59]\\d{6}|[2-5]\\d{5}";
            case 423: // LI
                return "[68]\\d{8}|(?:[2378]\\d|90)\\d{5}";
            case 508: // PM
                return "[45]\\d{5}|(?:708|8\\d\\d)\\d{6}";
            case 590: // BL, GP, MF
                return "(?:590\\d|7090)\\d{5}|(?:69|80|9\\d)\\d{7}";
            case 591: // BO
                return "8001\\d{5}|(?:[2-467]\\d|50)\\d{6}";
            case 593: // EC
                return "1\\d{9,10}|(?:[2-7]|9\\d)\\d{7}";
            case 594: // GF
                return "(?:[56]94\\d|7093)\\d{5}|(?:80|9\\d)\\d{7}";
            case 595: // PY
                return "59\\d{4,6}|9\\d{5,10}|(?:[2-46-8]\\d|5[0-8])\\d{4,7}";
            case 596: // MQ
                return "(?:596\\d|7091)\\d{5}|(?:69|[89]\\d)\\d{7}";
            case 598: // UY
                return "0004\\d{2,9}|[1249]\\d{7}|2\\d{3,4}|(?:[49]\\d|80)\\d{5}";
            case 686: // KI
                return "(?:[37]\\d|6[0-79])\\d{6}|(?:[2-48]\\d|50)\\d{3}";
            case 850: // KP
                return "85\\d{6}|(?:19\\d|[2-7])\\d{7}";
            case 855: // KH
                return "1\\d{9}|[1-9]\\d{7,8}";
            case 856: // LA
                return "[23]\\d{9}|3\\d{8}|(?:[235-8]\\d|41)\\d{6}";
            case 880: // BD
                return "[1-469]\\d{9}|8[0-79]\\d{7,8}|[2-79]\\d{8}|[2-9]\\d{7}|[3-9]\\d{6}|[57-9]\\d{5}";
            case 886: // TW
                return "[2-689]\\d{8}|7\\d{9,10}|[2-8]\\d{7}|2\\d{6}";
            case 961: // LB
                return "[27-9]\\d{7}|[13-9]\\d{6}";
            case 962: // JO
                return "(?:(?:[2689]|7\\d)\\d|32|427|53)\\d{6}";
            case 963: // SY
                return "[1-359]\\d{8}|[1-5]\\d{7}";
            case 964: // IQ
                return "(?:1|7\\d\\d)\\d{7}|[2-6]\\d{7,8}";
            case 966: // SA
                return "(?:[15]\\d|800|92)\\d{7}";
            case 967: // YE
                return "(?:1|7\\d)\\d{7}|[1-7]\\d{6}";
            case 970: // PS
                return "[2489]2\\d{6}|(?:1\\d|5)\\d{8}";
            case 971: // AE
                return "(?:[4-7]\\d|9[0-689])\\d{7}|800\\d{2,9}|[2-4679]\\d{7}";
            case 972: // IL
                return "1\\d{6}(?:\\d{3,5})?|[57]\\d{8}|[1-489]\\d{7}";
            case 976: // MN
                return "[12]\\d{7,9}|[5-9]\\d{7}";
            case 977: // NP
                return "(?:1\\d|9)\\d{9}|[1-9]\\d{7}";
            case 994: // AZ
                return "365\\d{6}|(?:[124579]\\d|60|88)\\d{7}";
            case 995: // GE
                return "(?:[3-57]\\d\\d|800)\\d{6}";
            case 996: // KG
                return "8\\d{9}|[235-9]\\d{8}";
            default: return null;
        }
    }
    // END GENERATED NUMBERING PLANS

    /** Normalize the existing dialing/contact UI before it loses the (0) marker. */
    public static String normalize(String input) {
        return digits(callInput(input));
    }

    private static String digits(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c >= '0' && c <= '9') || (c == '+' && out.length() == 0)) {
                out.append(c);
            }
        }
        return out.toString();
    }

    /** Match the existing call path's 00-prefix support before SMS BCD encoding. */
    public static String smsDestination(String input) {
        // SMS recipients and SMSC retain the original normalization semantics.
        String number = digits(ascii(input));
        if (number.startsWith("00") && number.length() > 2) {
            return "+" + number.substring(2);
        }
        return number;
    }
}
