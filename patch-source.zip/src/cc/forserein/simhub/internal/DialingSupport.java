package cc.forserein.simhub.internal;

/** Number formatting at the existing call and SMS entry points. No carrier guessing. */
public final class DialingSupport {
    private DialingSupport() {}

    /** Preserve dial-string punctuation while converting decimal digits and fullwidth +. */
    public static String ascii(String input) {
        input.getClass();
        StringBuilder out = new StringBuilder(input.length());
        for (int offset = 0; offset < input.length();) {
            int cp = input.codePointAt(offset);
            offset += Character.charCount(cp);
            if (Character.isDigit(cp)) {
                out.append((char) ('0' + Character.digit(cp, 10)));
            } else if (cp == 0xff0b) {
                out.append('+');
            } else {
                out.appendCodePoint(cp);
            }
        }
        return out.toString();
    }

    /**
     * Remove only an explicit optional domestic trunk marker in German/UK
     * international call notation. A bare zero, another country, an incomplete
     * number or extension/service syntax is deliberately left to the old parser.
     */
    public static String callInput(String input) {
        String text = ascii(input);
        StringBuilder compact = new StringBuilder(text.length());
        int[] positions = new int[text.length()];
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isWhitespace(c) || Character.isSpaceChar(c) || c == '-' || c == '\uff0d') continue;
            positions[compact.length()] = i;
            compact.append(c == '\uff08' ? '(' : c == '\uff09' ? ')' : c);
        }
        String number = compact.toString();
        int country = number.startsWith("+") ? 1 : number.startsWith("00") ? 2 : -1;
        if (country < 0 || number.length() < country + 6) return text;
        String code = number.substring(country, country + 2);
        if (!code.equals("49") && !code.equals("44")) return text;
        int marker = country + 2, national = marker + 3;
        if (!number.startsWith("(0)", marker)) return text;
        int count = number.length() - national;
        // Conservative possible lengths, not an allocation/valid-number claim.
        if (count < (code.equals("44") ? 7 : 4) || count > (code.equals("44") ? 10 : 15)) return text;
        if (number.charAt(national) < '1' || number.charAt(national) > '9') return text;
        for (int i = national; i < number.length(); i++) {
            char c = number.charAt(i);
            if (c < '0' || c > '9') return text;
        }
        // Delete the original marker span only; retain all other formatting.
        return text.substring(0, positions[marker]) + text.substring(positions[national - 1] + 1);
    }

    /** Normalize the existing dialing/contact UI before it loses the (0) marker. */
    public static String normalize(String input) {
        return digits(callInput(input));
    }

    private static String digits(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c >= '0' && c <= '9') || (c == '+' && out.length() == 0)) {
                out.append(c);
            }
        }
        return out.toString();
    }

    /** Match the existing call path's 00-prefix support before SMS BCD encoding. */
    public static String smsDestination(String input) {
        // SMS recipients and SMSC retain the original normalization semantics.
        String number = digits(ascii(input));
        if (number.startsWith("00") && number.length() > 2) {
            return "+" + number.substring(2);
        }
        return number;
    }
}
