package cc.forserein.simhub.internal;

/** Honor the registrar's binding lifetime, including sub-minute registrations. */
public final class RegistrationTiming {
    private RegistrationTiming() {}

    public static int acceptedExpires(int seconds) {
        if (seconds <= 0) {
            throw new IllegalStateException("IMS 注册未生效：服务器返回的注册有效期为 " + seconds + " 秒");
        }
        return seconds;
    }

    public static long refreshDelayMillis(int seconds) {
        if (seconds <= 0) throw new IllegalArgumentException("Registration lifetime must be positive");
        // Convert before multiplying: even Integer.MAX_VALUE seconds fits in long.
        return ((long) seconds) * 850L;
    }
}
