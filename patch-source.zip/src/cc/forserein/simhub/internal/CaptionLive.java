package cc.forserein.simhub.internal;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Full duplex: write 16 kHz microphone-independent downlink PCM while consuming 24 kHz translations. */
final class CaptionLive {
    final CaptionRelay relay;
    final String target;
    final int rate;
    final CaptionBackend.Listener listener;
    final ArrayBlockingQueue<short[]> input = new ArrayBlockingQueue<>(160);
    final short[] ring;
    private int head, count, phase, sampleSum, sampleCount;
    private volatile boolean closed, ready, overloaded;
    private volatile HttpURLConnection control, up, down;
    private volatile String session;
    private final Thread reader, writer;

    CaptionLive(String pairing,String target,int rate,CaptionBackend.Listener listener) {
        this.relay=new CaptionRelay(pairing);
        this.target=target;
        this.rate=rate;
        this.listener=listener;
        ring=new short[rate*8];
        reader=new Thread(this::receive,"SIMHub-live-receive");
        writer=new Thread(this::send,"SIMHub-live-send");
    }
    void start(){reader.start();}

    void offer(short[] pcm,int offset,int length) {
        if (!ready || closed || overloaded) return;
        if (pcm!=null && (offset<0 || length<=0 || offset>pcm.length-length)) return;
        short[] samples=pcm==null?new short[rate/50]:Arrays.copyOfRange(pcm,offset,offset+length);
        if (!input.offer(samples)) overloaded=true;
    }
    // Called by the original call AudioTrack thread. Its output route and clock also run during DTX.
    synchronized void render(short[] frame) {
        if (!ready || closed) return;
        int n=Math.min(count,frame.length);
        for (int i=0;i<n;i++) {
            frame[i]=ring[head];
            head=(head+1)%ring.length;
        }
        count-=n;
        Arrays.fill(frame,n,frame.length,(short)0);
    }
    private synchronized void accept(byte[] bytes) throws IOException {
        // Average input samples over each output interval; carry state across WebSocket chunks.
        if ((bytes.length&1)!=0) throw new IOException();
        for (int i=0;i<bytes.length;i+=2) {
            sampleSum+=(short)((bytes[i]&255)|(bytes[i+1]<<8));
            sampleCount++;
            phase+=rate;
            if (phase>=24000) {
                if (count==ring.length) throw new IOException("playback backlog");
                ring[(head+count)%ring.length]=(short)(sampleSum/sampleCount);
                count++; phase-=24000; sampleSum=0;sampleCount=0;
            }
        }
    }
    private void receive() {
        try {
            byte[] data=new JSONObject().put("target",target).toString().getBytes(StandardCharsets.UTF_8);
            for (int attempt=0; !closed; attempt++) {
                control=relay.open("/v1/live","POST");
                try {
                    control.setDoOutput(true);
                    control.setRequestProperty("Content-Type","application/json");
                    control.setFixedLengthStreamingMode(data.length);
                    try(OutputStream out=control.getOutputStream()){out.write(data);}
                    if (control.getResponseCode()==409 && attempt<5) {
                        // The preceding call or language session is still releasing its device slot.
                        Thread.sleep(300L*(attempt+1));
                        continue;
                    }
                    try(BufferedReader r=read(control)){
                        String id=new JSONObject(r.readLine()).getString("session");
                        if (!id.matches("[0-9a-f]{40}")) throw new IOException();
                        session="/v1/live/"+id;
                    }
                    break;
                } finally {control.disconnect();}
            }
            if (closed) return;
            down=relay.open(session+"/events","GET");
            down.setReadTimeout(45000);
            if (closed) return;
            try(BufferedReader r=read(down)){
                String line; StringBuilder caption=new StringBuilder();
                while (!closed && (line=r.readLine())!=null) {
                    if (line.length()>131072) throw new IOException();
                    JSONObject item=new JSONObject(line);
                    if (item.optBoolean("ready") && !ready) {
                        writer.start();
                        ready=true;
                        listener.onReady();
                    }
                    if (item.has("pcm")) accept(Base64.getDecoder().decode(item.getString("pcm")));
                    if (item.has("text")) {
                        caption.append(item.getString("text"));
                        if (caption.length()>2048) {listener.onText(caption.toString());caption.setLength(0);}
                        else listener.onPartial(caption.toString());
                    }
                    if (item.optBoolean("end") && caption.length()>0) {
                        listener.onText(caption.toString());
                        caption.setLength(0);
                    }
                }
            }
            if (!closed) throw new IOException();
        } catch(Exception failed) {fail();}
        finally {disconnect(down);disconnect(control);finishSession();}
    }
    private static BufferedReader read(HttpURLConnection c) throws IOException {
        if (c.getResponseCode()!=200) throw new IOException();
        return new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8));
    }
    private void send() {
        try {
            up=relay.open(session+"/audio","POST");
            up.setDoOutput(true);
            up.setChunkedStreamingMode(1600);
            up.setRequestProperty("Content-Type","application/octet-stream");
            if (closed) return;
            try(OutputStream out=up.getOutputStream()){
                byte[] batch=new byte[3200]; int used=0;
                while (!closed) {
                    if(overloaded) throw new IOException("input backlog");
                    short[] samples=input.poll(100,TimeUnit.MILLISECONDS);
                    if(samples==null) samples=new short[rate/10];
                    for(short sample:samples){
                        int copies=16000/rate;
                        while(copies-->0) {
                            batch[used++]=(byte)sample;
                            batch[used++]=(byte)(sample>>8);
                            if(used==batch.length) {out.write(batch);out.flush();used=0;}
                        }
                    }
                }
            }
        } catch(Exception failed){fail();}
        finally {disconnect(up);}
    }
    private void fail(){
        if (closed) return;
        ready=false;
        listener.onError("同传中断，已恢复原声。请检查中转连接或 Google 配额");
        close();
    }
    private void finishSession(){
        String path=session;
        if(path==null) return;
        HttpURLConnection c=null;
        try{c=relay.open(path,"DELETE");c.getResponseCode();}catch(IOException ignored){}finally{disconnect(c);}
    }
    private static void disconnect(HttpURLConnection c){if(c!=null)c.disconnect();}
    synchronized void close() {
        if (closed) return;
        closed=true; ready=false;
        reader.interrupt();writer.interrupt();input.clear();
        // Do not block playout or the call-state lock while a socket shuts down.
        new Thread(()->{disconnect(up);disconnect(down);disconnect(control);},"SIMHub-live-close").start();
    }
}
