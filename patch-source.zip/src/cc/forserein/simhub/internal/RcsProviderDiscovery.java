package cc.forserein.simhub.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.provider.Telephony;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static cc.forserein.simhub.internal.RcsChatTransport.PERMISSION;
import static cc.forserein.simhub.internal.RcsChatTransport.SERVICE_ACTION;
import cc.forserein.simhub.internal.RcsChatTransport.ProviderUnavailable;
import cc.forserein.simhub.internal.RcsChatTransport.UserFailure;

/** One explicitly bound GSMA endpoint. Its package and UID stay pinned for the whole session. */
final class RcsProviderDiscovery {
    final ComponentName component;
    final int uid;
    final String label;
    final boolean dependsOnSmsRole;
    private final String permissionOwner;

    private RcsProviderDiscovery(PackageManager pm, ServiceInfo service, boolean requiresRole, String owner) {
        component = new ComponentName(service.packageName, service.name);
        uid = service.applicationInfo.uid;
        label = String.valueOf(service.loadLabel(pm));
        dependsOnSmsRole = requiresRole;
        permissionOwner = owner;
    }

    static RcsProviderDiscovery find(Context context) {
        PackageManager pm = context.getPackageManager();
        Intent action = new Intent(SERVICE_ACTION);
        List<ResolveInfo> matches = pm.queryIntentServices(action, 0);
        if (matches.isEmpty()) {
            if (!pm.queryIntentServices(action, PackageManager.MATCH_DISABLED_COMPONENTS).isEmpty()) {
                throw new ProviderUnavailable("检测到已停用的 RCS 聊天服务，请检查系统应用设置");
            }
            throw new ProviderUnavailable("手机未向 SIMHub 公布 GSMA 聊天接口");
        }

        String defaultPackage = defaultSmsPackage(context);
        Map<ComponentName, ServiceInfo> eligible = new LinkedHashMap<>();
        boolean enabled = false;
        boolean trustedPackage = false;
        boolean publicService = false;
        boolean guardedService = false;
        String owner = null;
        for (ResolveInfo match : matches) {
            ServiceInfo service = match.serviceInfo;
            if (!active(service)) continue;
            enabled = true;
            if (!system(service.applicationInfo) && !service.packageName.equals(defaultPackage)) continue;
            trustedPackage = true;
            if (!service.exported) continue;
            publicService = true;
            if (!PERMISSION.equals(service.permission)) continue;
            if (!guardedService) owner = permissionOwner(pm);
            guardedService = true;
            if (ownsOrTrustsPermission(pm, service.packageName, owner)) {
                eligible.put(new ComponentName(service.packageName, service.name), service);
            }
        }

        if (!enabled) throw new ProviderUnavailable("RCS 聊天服务已停用或暂停");
        if (!trustedPackage) throw new ProviderUnavailable("发现 RCS 接口，但提供方不是系统应用或当前默认短信应用");
        if (!publicService) throw new ProviderUnavailable("RCS 聊天服务未向其他应用开放");
        if (!guardedService) throw new ProviderUnavailable("RCS 聊天服务未声明兼容的 GSMA 访问权限");
        if (eligible.isEmpty()) throw new ProviderUnavailable("无法核实 RCS 服务访问权限的来源");
        requireGrant(context);

        ServiceInfo selected = null;
        for (ServiceInfo service : eligible.values()) {
            if (!service.packageName.equals(defaultPackage)) continue;
            if (selected != null) throw new ProviderUnavailable("默认短信应用公布了多个 RCS 聊天服务，无法确定发送线路");
            selected = service;
        }
        if (selected == null) {
            if (eligible.size() != 1) throw new ProviderUnavailable("设备上有多个可信 RCS 服务，无法确定发送线路");
            selected = eligible.values().iterator().next();
        }
        // A system service chosen solely because it won a tie also depends on that choice remaining current.
        boolean requiresRole = !system(selected.applicationInfo) || eligible.size() > 1;
        return new RcsProviderDiscovery(pm, selected, requiresRole, owner);
    }

    private static String defaultSmsPackage(Context context) {
        try {
            return Telephony.Sms.getDefaultSmsPackage(context);
        } catch (RuntimeException unavailable) {
            return null;
        }
    }

    private static boolean active(ServiceInfo service) {
        if (service == null || service.applicationInfo == null || !service.enabled || !service.applicationInfo.enabled) {
            return false;
        }
        return (service.applicationInfo.flags & ApplicationInfo.FLAG_SUSPENDED) == 0;
    }

    private static boolean system(ApplicationInfo info) {
        return (info.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
    }

    private static String permissionOwner(PackageManager pm) {
        try {
            PermissionInfo permission = pm.getPermissionInfo(PERMISSION, 0);
            return permission.packageName;
        } catch (PackageManager.NameNotFoundException missing) {
            return null;
        }
    }

    private static boolean ownsOrTrustsPermission(PackageManager pm, String servicePackage, String owner) {
        if (owner == null) return false;
        if ("android".equals(owner) || servicePackage.equals(owner)) return true;
        try {
            return system(pm.getApplicationInfo(owner, 0));
        } catch (PackageManager.NameNotFoundException unavailable) {
            return false;
        }
    }

    private static void requireGrant(Context context) {
        if (context.checkSelfPermission(PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            throw new ProviderUnavailable("设备未授予 SIMHub 访问 RCS 服务的权限");
        }
    }

    void requireCurrent(Context context) {
        String packageName = component.getPackageName();
        if (dependsOnSmsRole && !packageName.equals(defaultSmsPackage(context))) {
            throw new UserFailure("默认短信应用已变更，请重新开启 RCS");
        }
        PackageManager pm = context.getPackageManager();
        try {
            ServiceInfo service = pm.getServiceInfo(component, 0);
            if (!active(service) || !service.exported || !PERMISSION.equals(service.permission)
                    || service.applicationInfo.uid != uid || !component.equals(new ComponentName(service.packageName, service.name))
                    || (!dependsOnSmsRole && !system(service.applicationInfo))) {
                throw new UserFailure("RCS 聊天服务已变更，请重新开启 RCS");
            }
        } catch (PackageManager.NameNotFoundException missing) {
            throw new UserFailure("RCS 聊天服务已停用或移除，请重新开启 RCS");
        }
        if (!permissionOwner.equals(permissionOwner(pm)) || !ownsOrTrustsPermission(pm, packageName, permissionOwner)) {
            throw new UserFailure("RCS 服务的访问权限已变更，请重新开启 RCS");
        }
        requireGrant(context);
    }
}
