package cc.forserein.simhub.internal;

import java.util.*;

/** DITO-specific settings verified in the SIMHub 29.3 binary, rather than a generic template. */
public final class DitoCarrierProfile {
    public static final String PLMN="51566",ID="apple_dito_ph",KEY=PLMN+"|"+ID,LEGACY_KEY=PLMN+"|standard_plmn_51566";
    private DitoCarrierProfile(){}
    public static boolean selected(String key){return KEY.equals(key)||LEGACY_KEY.equals(key);}
    private static Object ipv4()throws ReflectiveOperationException {
        for(Object value:Class.forName("ak5").getEnumConstants())if("ipv4".equals(WifiConfigModel.get(value,"T")))return value;
        throw new IllegalStateException("IPv4 配置类型不可用");
    }
    private static WifiConfigValues.Algorithms algorithms(String value){return new WifiConfigValues.Algorithms(Collections.singletonList(value));}
    public static Object defaults(Object card)throws ReflectiveOperationException {
        Object effective=DitoHomeIdentity.settings(card);
        return apply(effective,WifiConfigModel.builtIn(effective));
    }
    /** No catalogue lookup: automatic DITO must not silently fall back to a Vodafone preset. */
    public static Object apply(Object card,Object original)throws ReflectiveOperationException {
        String imsi=(String)WifiConfigModel.get(card,"a");Object[] args=WifiConfigModel.fields(original,27);
        String realm="mnc066.mcc515.3gppnetwork.org",domain="ims."+realm;
        args[0]=Class.forName("lj5").getField("U").get(null);args[1]=ID;args[2]="DITO";args[3]="515";args[4]="66";
        args[5]=Collections.singletonList("epdg.epc.mnc066.mcc515.pub.3gppnetwork.org");args[6]=domain;args[7]="ims";args[8]=ipv4();
        args[9]=algorithms("aes128");args[10]=algorithms("sha1");args[11]=algorithms("sha1");args[12]=algorithms("modp1024");
        args[13]=algorithms("aes128");args[14]=algorithms("sha1");args[15]=Integer.valueOf(20);args[16]=false;
        String permanentNai=DitoHomeIdentity.permanentNai(card);
        args[17]=permanentNai;args[18]=imsi+"@"+domain;args[19]=true;args[20]=Integer.valueOf(1300);args[21]=false;
        args[23]=Arrays.asList(20,21,16384,16386);args[24]=permanentNai;args[26]=null;
        // The pinned native constructor supplies registerExpires=7200 when bit 17 is clear.
        args[25]=WifiConfigModel.constructor(Class.forName("yj5"),7).newInstance(false,null,null,null,null,null,0xfffffff^0x20000);
        return WifiConfigModel.constructor(original.getClass(),27).newInstance(args);
    }
    public static boolean matches(Object config)throws ReflectiveOperationException {
        return config!=null&&"515".equals(WifiConfigModel.get(config,"d"))&&"66".equals(WifiConfigModel.get(config,"e"));
    }
}
