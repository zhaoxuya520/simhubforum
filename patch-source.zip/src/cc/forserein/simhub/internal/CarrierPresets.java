package cc.forserein.simhub.internal;

import java.text.Normalizer;
import java.util.*;

/** Selects connection settings independently of the real SIM's immutable subscriber identity. */
public final class CarrierPresets {
    public static final String KEY="carrier_preset";
    public static final int PAGE_SIZE=20;
    private CarrierPresets(){}
    public static final class Entry {
        public final String key,id,plmn,name,country,bundle,title;
        private final String search;
        private final Set<String> shortWords;
        private final Object raw;
        Entry(Object raw,String country,String name)throws ReflectiveOperationException {
            this.raw=raw;id=string(raw,"a");plmn=string(raw,"c");bundle=string(raw,"b");
            key=plmn+"|"+id;this.name=name.isEmpty()?bundle.replace('_',' '):name;
            this.country=country;
            String local=country.isEmpty()?"":new Locale("",country).getDisplayCountry(Locale.SIMPLIFIED_CHINESE);
            String english=country.isEmpty()?"":new Locale("",country).getDisplayCountry(Locale.ENGLISH);
            title=this.name+(local.isEmpty()?"":" · "+local)+" · "+plmn
                +(id.startsWith("standard_plmn_")?" · 标准模板":"\n"+bundle.replace('_',' '));
            search=fold(this.name+" "+local+" "+english+" "+country+" "+plmn+" "+bundle+" "+id);
            shortWords=new HashSet<>(Arrays.asList(fold(this.name+" "+local+" "+english+" "+country+" "+bundle.replace('_',' ')).split("[^\\p{L}\\p{N}]+")));
        }
    }
    private static List<Entry> entries;
    private static Map<String,Entry> byKey;
    private static Object get(Object value,String field)throws ReflectiveOperationException{return WifiConfigModel.get(value,field);}
    private static String string(Object value,String field)throws ReflectiveOperationException {Object v=get(value,field);return v==null?"":v.toString();}
    public static synchronized List<Entry> all()throws ReflectiveOperationException {
        if(entries!=null)return entries;
        Object library=Class.forName("fj5").getField("a").get(null);
        Map<String,Object> directory=new HashMap<>();
        for(Object row:(List<?>)library.getClass().getMethod("a").invoke(library))directory.putIfAbsent(string(row,"a")+string(row,"b"),row);
        Object file=library.getClass().getMethod("b").invoke(library);
        List<Entry> result=new ArrayList<>();Map<String,Entry> index=new HashMap<>();
        for(Object raw:(List<?>)get(file,"a")){
            String plmn=string(raw,"c");if(!plmn.matches("[0-9]{5,6}"))continue;
            Object row=directory.get(plmn);
            String country=row==null?"":string(row,"c");
            String name=row==null?"":string(row,"e");if(name.isEmpty()&&row!=null)name=string(row,"d");
            Entry e=new Entry(raw,country,name);
            if(index.put(e.key,e)!=null)throw new IllegalStateException("运营商预设标识重复");
            result.add(e);
        }
        result.sort(Comparator.comparing((Entry e)->e.country).thenComparing(e->e.name).thenComparing(e->e.key));
        byKey=Collections.unmodifiableMap(index);entries=Collections.unmodifiableList(result);return entries;
    }
    public static Entry find(String key)throws ReflectiveOperationException {
        if(DitoCarrierProfile.LEGACY_KEY.equals(key))key=DitoCarrierProfile.KEY;
        all();Entry entry=byKey.get(key);
        if(entry==null)throw new IllegalArgumentException("该运营商预设不存在，请重新选择");return entry;
    }
    private static String fold(String value){return Normalizer.normalize(value,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).trim();}
    public static List<Entry> search(String query)throws ReflectiveOperationException {
        String q=fold(query);if(q.isEmpty())return all();String[] words=q.split("\\s+");List<Entry> out=new ArrayList<>();
        for(Entry e:all()){boolean match=true;for(String word:words)if(word.matches("[a-z]{2}")?!e.shortWords.contains(word):!e.search.contains(word)){match=false;break;}if(match)out.add(e);}
        return out;
    }
    public static String label(String key)throws ReflectiveOperationException{return find(key).title;}
    public static boolean sameSelection(String first,String second){return Objects.equals(first,second)||(DitoCarrierProfile.selected(first)&&DitoCarrierProfile.selected(second));}
    public static String expand(String template,String imsi,String mcc,String mnc){
        return template.replace("$impi_user",imsi).replace("$imsi",imsi).replace("$mcc",mcc).replace("$mnc",pad(mnc));
    }
    private static String pad(String mnc){return mnc.length()==2?"0"+mnc:mnc;}
    public static Object defaults(Object card,Map<String,String> values)throws ReflectiveOperationException {
        String key=values==null?null:values.get(KEY);
        if(key==null||key.isEmpty()){
            return DitoHomeIdentity.isDito(card)?DitoCarrierProfile.defaults(card):WifiConfigModel.builtIn(card);
        }
        if(DitoCarrierProfile.selected(key))return DitoCarrierProfile.defaults(card);
        return apply(find(key),card);
    }
    /** Reuse native preset algorithm/transport settings, replacing its SIM-derived PLMN realms explicitly. */
    public static Object apply(Entry entry,Object card)throws ReflectiveOperationException {
        if(DitoCarrierProfile.selected(entry.key))return DitoCarrierProfile.defaults(card);
        if(DitoCarrierProfile.PLMN.equals(entry.plmn))card=DitoHomeIdentity.settings(card);
        Object nativeConfig=Class.forName("zl3").getMethod("i",Class.forName("bj5"),Class.forName("ek5")).invoke(null,entry.raw,card);
        Object[] args=WifiConfigModel.fields(nativeConfig,27);
        String imsi=string(card,"a"),mcc=entry.plmn.substring(0,3),mnc=entry.plmn.substring(3);
        String realm="mnc"+pad(mnc)+".mcc"+mcc+".3gppnetwork.org";
        String domain=string(entry.raw,"e");if(domain.isEmpty())domain="ims."+realm;else domain=expand(domain,imsi,mcc,mnc);
        LinkedHashSet<String> endpoints=new LinkedHashSet<>();String endpoint=string(entry.raw,"d");
        if(!endpoint.isEmpty())endpoints.add(expand(endpoint,imsi,mcc,mnc));
        endpoints.add("epdg.epc.mnc"+pad(mnc)+".mcc"+mcc+".pub.3gppnetwork.org");
        String nai=expand(string(entry.raw,"q"),imsi,mcc,mnc);
        String eap=null;
        if(!nai.contains(imsi)){
            int at=nai.indexOf('@');String naiRealm=at>=0?nai.substring(at+1):"nai.epc."+realm;
            eap="0"+imsi+"@"+naiRealm;
        }
        args[2]=entry.name;args[3]=mcc;args[4]=mnc;args[5]=new ArrayList<>(endpoints);args[6]=domain;
        args[17]=nai;args[18]=imsi+"@"+domain;args[24]=eap;
        applyPolicy(entry.plmn,card,args);
        return WifiConfigModel.constructor(nativeConfig.getClass(),27).newInstance(args);
    }
    /** Same per-PLMN transport/ISIM policy that the original automatic selector applies. */
    private static void applyPolicy(String plmn,Object card,Object[] args)throws ReflectiveOperationException {
        Map<?,?> policies=(Map<?,?>)Class.forName("zi5").getField("a").get(null);Object policy=policies.get(plmn);
        if(policy==null)return;
        for(String[] pair:new String[][]{{"a","2"},{"b","21"},{"c","8"},{"f","7"},{"g","19"}}){
            Object value=get(policy,pair[0]);if(value!=null)args[Integer.parseInt(pair[1])]=value;
        }
        args[25]=get(policy,"d");
        String first=string(policy,"e");
        if(!first.isEmpty()){
            List<String> servers=new ArrayList<>();servers.add(first);
            for(Object server:(List<?>)args[5])if(!first.equals(server))servers.add(server.toString());args[5]=servers;
        }
        Object isim=get(card,"h");
        if(Boolean.TRUE.equals(get(args[25],"u"))&&isim!=null){
            args[6]=get(isim,"b");args[17]=get(isim,"a");args[18]=get(isim,"a");args[26]=get(isim,"c");
        }
    }
    /** A new carrier replaces carrier overrides, including SMSC. IMEI belongs to the device. */
    public static Map<String,String> selection(Map<String,String> saved,String key)throws ReflectiveOperationException {
        Map<String,String> result=new LinkedHashMap<>();
        if(saved.containsKey("imei"))result.put("imei",saved.get("imei"));
        if(key!=null&&!key.isEmpty()){find(key);result.put(KEY,key);}
        return WifiConfigValues.validate(result);
    }
}
