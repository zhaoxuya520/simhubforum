package cc.forserein.simhub.internal;

import java.util.Locale;

/** Applies AT&T IMS subscription defaults before the per-card custom fields are merged. */
final class AttImsDefaults {
    private AttImsDefaults() {}

    static Object apply(Object card, Object config) throws ReflectiveOperationException {
        String plmn = (String) WifiConfigModel.get(config, "d") + WifiConfigModel.get(config, "e");
        if (!CtExcelCallPolicy.isAtt(plmn, WifiConfigModel.get(config, "b"))) return config;

        String imsi = (String) WifiConfigModel.get(card, "a");
        String domain = "one.att.net";
        String privateId = imsi + "@private.att.net";
        String publicId = "sip:" + imsi + "@" + domain;
        Object isim = WifiConfigModel.get(card, "h");
        if (isim != null) {
            String realm = text(isim, "b").toLowerCase(Locale.ROOT).replaceFirst("\\.+$", "");
            if (realm.equals("att.net") || realm.endsWith(".att.net") && validDomain(realm)) {
                domain = realm;
                String impi = text(isim, "a");
                String impu = text(isim, "c");
                if (validImpi(impi) && validImpu(impu)) {
                    privateId = impi;
                    publicId = impu;
                } else {
                    privateId = imsi + "@" + domain;
                    publicId = "sip:" + privateId;
                }
            }
        }
        if (domain.equals(WifiConfigModel.get(config, "g"))
                && privateId.equals(WifiConfigModel.get(config, "s"))
                && publicId.equals(WifiConfigModel.get(config, "A"))) return config;
        Object[] fields = WifiConfigModel.fields(config, 27);
        fields[6] = domain;
        fields[18] = privateId;
        fields[26] = publicId;
        return WifiConfigModel.constructor(config.getClass(), fields.length).newInstance(fields);
    }

    private static String text(Object isim, String field) throws ReflectiveOperationException {
        String value = (String) WifiConfigModel.get(isim, field);
        return value == null ? "" : value.trim();
    }

    private static boolean validDomain(String value) {
        return value.length() <= 253 && value.matches("[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?")
                && !value.contains("..");
    }

    private static boolean validImpi(String value) {
        int at = value.indexOf('@');
        return at > 0 && at == value.lastIndexOf('@') && at < value.length() - 1 && safe(value);
    }

    private static boolean validImpu(String value) {
        return value.length() > 4 && (value.regionMatches(true, 0, "sip:", 0, 4)
                || value.regionMatches(true, 0, "tel:", 0, 4)) && safe(value);
    }

    private static boolean safe(String value) {
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c <= 0x20 || c == 0x7f || Character.isWhitespace(c) || Character.isSpaceChar(c)
                    || c == '"' || c == '<' || c == '>') return false;
        }
        return true;
    }
}
