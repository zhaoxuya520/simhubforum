package cc.forserein.simhub.internal;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** The service credential stays in no-backup storage, encrypted by a non-exportable Android key. */
final class CaptionKeyStore {
    private static final String ALIAS = "simhub.captions.gemini.v1";
    private static final String CIPHER = "AES/GCM/NoPadding";
    private static final int IV_BYTES = 12;

    private CaptionKeyStore() {}

    private static AtomicFile file(Context context) {
        return new AtomicFile(new File(context.getNoBackupFilesDir(), "caption-service.key"));
    }

    private static SecretKey secret(boolean create) throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(ALIAS)) return (SecretKey) store.getKey(ALIAS, null);
        if (!create) throw new IllegalStateException("请重新填写 Gemini API 密钥");
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return generator.generateKey();
    }

    static synchronized boolean has(Context context) {
        return file(context).getBaseFile().isFile();
    }

    static synchronized String read(Context context) throws Exception {
        AtomicFile stored = file(context);
        if (!stored.getBaseFile().isFile()) return "";
        byte[] record = stored.readFully();
        if (record.length <= IV_BYTES + 16 || record.length > 1052) throw new IllegalStateException();
        Cipher cipher = Cipher.getInstance(CIPHER);
        cipher.init(Cipher.DECRYPT_MODE, secret(false), new GCMParameterSpec(128, record, 0, IV_BYTES));
        byte[] plain = cipher.doFinal(record, IV_BYTES, record.length - IV_BYTES);
        try {
            return new String(plain, StandardCharsets.US_ASCII);
        } finally {
            Arrays.fill(plain, (byte) 0);
        }
    }

    static synchronized void write(Context context, String value) throws Exception {
        AtomicFile stored = file(context);
        if (value.isEmpty()) {
            stored.delete();
            if (stored.getBaseFile().exists()) throw new IllegalStateException();
            return;
        }
        if (!value.matches("[!-~]{12,1024}"))
            throw new IllegalArgumentException("请检查 Gemini API 密钥");
        Cipher cipher = Cipher.getInstance(CIPHER);
        cipher.init(Cipher.ENCRYPT_MODE, secret(true));
        byte[] iv = cipher.getIV();
        if (iv.length != IV_BYTES) throw new IllegalStateException();
        byte[] bytes = value.getBytes(StandardCharsets.US_ASCII);
        try {
            byte[] encrypted = cipher.doFinal(bytes);
            FileOutputStream out = stored.startWrite();
            try {
                out.write(iv);
                out.write(encrypted);
                stored.finishWrite(out);
            } catch (Exception e) {
                stored.failWrite(out);
                throw e;
            }
        } finally {
            Arrays.fill(bytes, (byte) 0);
        }
    }
}
