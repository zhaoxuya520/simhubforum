package cc.forserein.simhub.internal;

import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/** Correlate initial INVITE responses without changing genuine pending-call failures. */
public final class SipInviteFailure {
    private static final int MAX_ACKS = 64;
    private static final long ACK_LIFETIME_NANOS = 32_000_000_000L;
    // Neither a bucket nor an ACK retains its engine, manager or dialog.
    private static final WeakHashMap<Object, Bucket> CACHE = new WeakHashMap<Object, Bucket>();
    private SipInviteFailure() {}

    private static final class Bucket {
        final WeakReference<Object> manager;
        final LinkedHashMap<Key, Entry> acks = new LinkedHashMap<Key, Entry>();
        boolean staleReported;
        Bucket(Object manager) { this.manager = new WeakReference<Object>(manager); }
    }
    private static final class Entry {
        final Object ack;
        final long created;
        Entry(Object ack, long now) { this.ack = ack; this.created = now; }
    }
    private static final class Key {
        final String callId, branch, fromTag, to;
        final int sequence;
        Key(String callId, int sequence, String branch, String fromTag, String to) {
            this.callId = callId; this.sequence = sequence; this.branch = branch;
            this.fromTag = fromTag; this.to = to;
        }
        @Override public boolean equals(Object other) {
            if (!(other instanceof Key)) return false;
            Key k = (Key) other;
            return sequence == k.sequence && callId.equals(k.callId) && branch.equals(k.branch)
                    && fromTag.equals(k.fromTag) && to.equals(k.to);
        }
        @Override public int hashCode() {
            int h = 31 * callId.hashCode() + sequence;
            h = 31 * h + branch.hashCode(); h = 31 * h + fromTag.hashCode();
            return 31 * h + to.hashCode();
        }
    }
    static Object field(Object object, String name) throws Exception {
        return object.getClass().getField(name).get(object);
    }
    static Object call(Object target, String name, Class<?>[] types, Object... values) throws Exception {
        return target.getClass().getMethod(name, types).invoke(target, values);
    }
    private static void diagnostic(Object engine, String text) {
        try { call(field(engine, "g"), "i", new Class<?>[]{Object.class}, text); }
        catch (Exception ignored) { /* Diagnostics cannot change call state. */ }
    }
    static List<String> headers(Object message, String full, String compact) throws Exception {
        List<String> result = new ArrayList<String>();
        for (Object pair : (List<?>) field(message, "f")) {
            String name = (String) field(pair, "T");
            if (full.equalsIgnoreCase(name) || (compact != null && compact.equalsIgnoreCase(name)))
                result.add((String) field(pair, "U"));
        }
        return result;
    }
    static String first(Object message, String full, String compact) throws Exception {
        List<String> values = headers(message, full, compact);
        return values.isEmpty() ? null : values.get(0);
    }
    private static String parameter(Object message, String header, String name) throws Exception {
        if (header == null) return null;
        Class<?> parser = message.getClass().getField("Companion").getType();
        return (String) parser.getMethod("b", String.class, String.class).invoke(null, name, header);
    }
    private static boolean present(String value) { return value != null && value.length() != 0; }
    /** Native parsing can retain a comma-separated Via value when its name is lowercase or it contains quotes. */
    private static String topVia(Object message) throws Exception {
        String value = first(message, "Via", "v");
        if (value == null) return null;
        boolean quoted = false, escaped = false;
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            if (escaped) { escaped = false; continue; }
            if (quoted && ch == '\\') { escaped = true; continue; }
            if (ch == '"') quoted = !quoted;
            else if (ch == ',' && !quoted) return value.substring(0, i).trim();
        }
        return value.trim();
    }
    private static boolean finalFailure(int status) { return status >= 300 && status <= 699; }
    private static Key key(Object response) throws Exception {
        Object sequence = call(response, "e", new Class<?>[0]);
        if (sequence == null || !"INVITE".equals(field(sequence, "b"))) return null;
        int number = (Integer) field(sequence, "a");
        String id = first(response, "Call-ID", "i"), to = first(response, "To", "t");
        String branch = parameter(response, topVia(response), "branch");
        String from = parameter(response, first(response, "From", "f"), "tag");
        if (number < 0 || !present(id) || !present(branch) || !present(from) || !present(to)) return null;
        return new Key(id, number, branch, from, to);
    }
    private static boolean matches(Object invite, Key response) throws Exception {
        if (invite == null || !(Boolean) field(invite, "a") || !"INVITE".equals(field(invite, "b"))) return false;
        Object sequence = call(invite, "e", new Class<?>[0]);
        return sequence != null && "INVITE".equals(field(sequence, "b"))
                && response.sequence == (Integer) field(sequence, "a")
                && response.callId.equals(first(invite, "Call-ID", "i"))
                && response.branch.equals(parameter(invite, topVia(invite), "branch"))
                && response.fromTag.equals(parameter(invite, first(invite, "From", "f"), "tag"));
    }
    private static Object copyMessage(Object original) throws Exception {
        Class<?> type = original.getClass();
        Constructor<?> ctor = type.getConstructor(boolean.class, String.class, String.class,
                int.class, String.class, ArrayList.class, byte[].class);
        Object copy = ctor.newInstance(field(original, "a"), field(original, "b"), field(original, "c"),
                field(original, "d"), field(original, "e"), new ArrayList<Object>((List<?>) field(original, "f")),
                ((byte[]) field(original, "g")).clone());
        type.getField("h").set(copy, field(original, "h"));
        return copy;
    }
    private static Bucket bucket(Object engine, Object manager, long now) {
        Bucket bucket = CACHE.get(engine);
        if (bucket == null || bucket.manager.get() != manager) {
            bucket = new Bucket(manager); CACHE.put(engine, bucket);
        }
        Iterator<Entry> entries = bucket.acks.values().iterator();
        while (entries.hasNext()) {
            long age = now - entries.next().created;
            if (age < 0 || age >= ACK_LIFETIME_NANOS) entries.remove();
        }
        return bucket;
    }
    private static void save(Object engine, Object manager, Key key, Object ack) throws Exception {
        Object copy = copyMessage(ack);
        synchronized (CACHE) {
            long now = System.nanoTime();
            Bucket bucket = bucket(engine, manager, now);
            if (bucket.acks.containsKey(key)) return; // Retransmissions do not extend the lifetime.
            if (bucket.acks.size() >= MAX_ACKS) bucket.acks.remove(bucket.acks.keySet().iterator().next());
            bucket.acks.put(key, new Entry(copy, now));
        }
    }
    private static void send(Object engine, Object ack) throws Exception {
        call(engine, "C", new Class<?>[]{ack.getClass()}, copyMessage(ack));
    }
    private static void add(Object packet, String name, String value) throws Exception {
        call(packet, "a", new Class<?>[]{String.class, String.class}, name, value);
    }
    /** Same non-2xx ACK fields as the native h branch; no dialog Contact or route is used. */
    private static Object acknowledgement(Object manager, Object invite, Key response) throws Exception {
        Class<?> parser = invite.getClass().getField("Companion").getType();
        Object ack = parser.getMethod("d", String.class, String.class)
                .invoke(null, "ACK", field(invite, "c"));
        add(ack, "Via", topVia(invite));
        add(ack, "Max-Forwards", "70");
        for (String route : headers(invite, "Route", null)) add(ack, "Route", route);
        add(ack, "From", first(invite, "From", "f"));
        add(ack, "To", response.to);
        add(ack, "Call-ID", response.callId);
        add(ack, "CSeq", response.sequence + " ACK");
        call(manager, "a", new Class<?>[]{invite.getClass()}, ack);
        return ack;
    }

    /** Called before native Call-ID-only mutation. False retains genuine initial-call failure. */
    public static boolean handle(Object engine, Object response) {
        boolean protectConfirmed = false;
        try {
            if (engine == null || response == null || (Boolean) field(response, "a")) return false;
            int status = (Integer) field(response, "d");
            boolean provisional = status >= 100 && status < 200;
            if (!provisional && !finalFailure(status)) return false;
            Object sequence = call(response, "e", new Class<?>[0]);
            if (sequence == null || !"INVITE".equals(field(sequence, "b"))) return false;
            Object manager = field(engine, "J");
            if (manager == null) return false;
            if (provisional) {
                Object dialog = ((Map<?, ?>) field(manager, "e")).get(first(response, "Call-ID", "i"));
                if (dialog == null) return false;
                Object direction = field(dialog, "a");
                if (direction != direction.getClass().getField("U").get(null)) return false;
                protectConfirmed = field(dialog, "D") != null;
                if (protectConfirmed) return true;
                int number = (Integer) field(sequence, "a");
                if (number >= 0 && number != (Integer) field(dialog, "i")) return true;
                return status > 100 && SipReliableProgress.shouldDiscard(dialog, response);
            }
            Key key = key(response);
            if (key != null) {
                Entry cached;
                synchronized (CACHE) { cached = bucket(engine, manager, System.nanoTime()).acks.get(key); }
                if (cached != null) {
                    try { send(engine, cached.ack); }
                    catch (Exception failure) { diagnostic(engine, "通话：" + status + " 确认发送失败，等待对端重传"); }
                    return true;
                }
            }
            String id = first(response, "Call-ID", "i");
            Object dialog = ((Map<?, ?>) field(manager, "e")).get(id);
            if (dialog == null) return false;
            Object direction = field(dialog, "a");
            if (direction != direction.getClass().getField("U").get(null)) return false;
            protectConfirmed = field(dialog, "D") != null;
            if (key == null || key.sequence != (Integer) field(dialog, "i")
                    || !matches(field(dialog, "j"), key)) {
                boolean report;
                synchronized (CACHE) {
                    Bucket bucket = bucket(engine, manager, System.nanoTime());
                    report = !bucket.staleReported; bucket.staleReported = true;
                }
                if (report) diagnostic(engine, "通话：收到旧 INVITE 的 " + status + "，已保留当前通话状态");
                return true;
            }
            if (!protectConfirmed) return false;
            Object ack = acknowledgement(manager, field(dialog, "j"), key);
            save(engine, manager, key, ack);
            send(engine, ack);
            diagnostic(engine, "通话：已确认迟到的 " + status + "，保留已接通通话");
            return true;
        } catch (Exception failure) {
            if (protectConfirmed) diagnostic(engine, "通话：迟到的 INVITE 响应确认暂未完成，保留已接通通话");
            return protectConfirmed;
        }
    }

    /** Retain the actual native ACK before its dialog is removed, without changing failure events. */
    public static void remember(Object engine, Object response, Object ack) {
        try {
            if (engine == null || response == null || ack == null || (Boolean) field(response, "a")
                    || !finalFailure((Integer) field(response, "d"))) return;
            Object manager = field(engine, "J");
            if (manager == null) return;
            Key key = key(response);
            if (key == null) return;
            Object dialog = ((Map<?, ?>) field(manager, "e")).get(key.callId);
            if (dialog == null || key.sequence != (Integer) field(dialog, "i")
                    || !matches(field(dialog, "j"), key) || !"ACK".equals(field(ack, "b"))) return;
            save(engine, manager, key, ack);
        } catch (Exception failure) {
            diagnostic(engine, "通话：INVITE 重传确认未能缓存，已保留原有失败处理");
        }
    }
}
