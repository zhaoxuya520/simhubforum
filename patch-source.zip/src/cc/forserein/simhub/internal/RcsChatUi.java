package cc.forserein.simhub.internal;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import java.lang.ref.WeakReference;
import java.lang.reflect.Proxy;
import java.text.DateFormat;
import java.util.*;

/** A visible RCS mode inside the original SMS screen; its original composer is shared. */
public final class RcsChatUi {
    private RcsChatUi() {}
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static final Map<Object,Session> SESSIONS=new WeakHashMap<>();
    private static final Map<String,Boolean> LINES=new LinkedHashMap<String,Boolean>(8,0.75f,true){
        protected boolean removeEldestEntry(Map.Entry<String,Boolean> e){return size()>8;}
    };
    private static final Map<String,List<RcsChatTransport.Message>> HISTORY=new LinkedHashMap<String,List<RcsChatTransport.Message>>(16,0.75f,true){
        protected boolean removeEldestEntry(Map.Entry<String,List<RcsChatTransport.Message>> e){return size()>16;}
    };
    private static final Set<String> UNCONFIRMED=new LinkedHashSet<>();
    private static Session current;
    private static Object signal;private static int revision;
    private static boolean apiChecked,apiAvailable;
    private interface Action {Object run(Object[] args)throws Exception;}
    private static Class<?> type(String name)throws ClassNotFoundException {
        if(name.equals("int"))return int.class;if(name.equals("boolean"))return boolean.class;
        if(name.equals("long"))return long.class;if(name.equals("float"))return float.class;return Class.forName(name);
    }
    private static Object call(String owner,String name,String[] names,Object receiver,Object...args)throws Exception{
        Class<?>[] types=new Class<?>[names.length];for(int i=0;i<types.length;i++)types[i]=type(names[i]);
        return type(owner).getMethod(name,types).invoke(receiver,args);
    }
    private static Object field(String owner,String name)throws Exception{return type(owner).getField(name).get(null);}
    private static Object unit()throws Exception{return field("sc5","a");}
    private static Object function(String name,Action action)throws Exception{
        Class<?> iface=type(name);return Proxy.newProxyInstance(iface.getClassLoader(),new Class<?>[]{iface},(proxy,method,args)->{
            if(method.getDeclaringClass()==Object.class){if(method.getName().equals("equals"))return proxy==args[0];if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);return "RcsScreenCallback";}
            return action.run(args==null?new Object[0]:args);
        });
    }
    private static void observe()throws Exception{
        if(signal==null)signal=call("qd2","D",new String[]{"java.lang.Object"},null,0);
        call("ot4","getValue",new String[]{},signal);
    }
    private static void changed(){try{if(signal!=null)call("m83","setValue",new String[]{"java.lang.Object"},signal,++revision);}catch(Exception ignored){}}
    private static Activity activity(Context context){while(context instanceof ContextWrapper&&!(context instanceof Activity)){Context next=((ContextWrapper)context).getBaseContext();if(next==context)break;context=next;}return context instanceof Activity?(Activity)context:null;}
    private static String message(Throwable failure){while(failure.getCause()!=null&&failure.getCause()!=failure)failure=failure.getCause();String value=failure.getMessage();return value==null||value.trim().isEmpty()?"RCS 服务暂不可用":value;}
    private static String line(Object state){try{return RcsChatBinding.lineKey(state);}catch(Exception unavailable){return null;}}
    private static String text(Object draft)throws Exception{return String.valueOf(call("ot4","getValue",new String[]{},draft));}
    private static int bytes(String text){return text.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;}
    private static boolean apiAvailable(){
        if(apiChecked)return apiAvailable;apiChecked=true;
        try{
            type("ak2").getMethod("d",type("us1"),type("zn0"),type("lu1"),int.class,int.class);
            type("ak2").getMethod("i",boolean.class,type("ws1"),type("lu1"),int.class);
            type("f84").getMethod("a",type("r53"),float.class,boolean.class);
            type("gi2").getMethod("c",Object.class,type("ws1"),type("lu1"));
            type("e51").getMethod("a");type("lu1").getMethod("u");apiAvailable=true;
        }catch(ReflectiveOperationException unsupported){apiAvailable=false;}
        return apiAvailable;
    }

    /** Rendered above the native composer, with the same card and draft objects. */
    public static void render(Object state,String peer,Object draft,Object composer){
        renderInternal(state,peer,draft,composer,false);
    }
    private static void renderInternal(Object state,String peer,Object draft,Object composer,boolean editingRecipient){
        if(!apiAvailable()){Session old=SESSIONS.get(draft);if(old!=null&&old.on)old.fail("RCS 控件暂不可用，请关闭 RCS 后使用短信");return;}
        boolean started=false;
        try{
            call("lu1","e0",new String[]{"int"},composer,0x2168c601);started=true;observe();
            Context context=(Context)call("lu1","k",new String[]{"rv3"},composer,field("h7","b"));
            Session session=SESSIONS.get(draft);String currentLine=line(state);
            if(session==null||!Objects.equals(session.peer,peer)||!Objects.equals(session.lineKey,currentLine)){
                Session previous=session;
                if(previous!=null)previous.retire();
                session=new Session(activity(context),state,peer,draft,currentLine,editingRecipient);
                session.retainDraftMode(previous);
                SESSIONS.put(draft,session);
            }
            if(current!=session){if(current!=null)current.retire();current=session;session.active=true;session.start();}
            session.state=state;session.observeDraft();
            final Session page=session;
            Object effect=function("ws1",args->function("e51",disposed->{page.retire();if(current==page)current=null;return null;}));
            call("gi2","c",new String[]{"java.lang.Object","ws1","lu1"},null,page,effect,composer);
            Object toggle=function("ws1",args->{page.toggle(Boolean.TRUE.equals(args[0]));return unit();});
            Object content=function("lt1",args->{
                Object weight=call("f84","a",new String[]{"r53","float","boolean"},args[0],field("o53","b"),1f,true);
                styled("RCS · "+page.phase(),weight,args[1],"f","e",2);
                call("ak2","i",new String[]{"boolean","ws1","lu1","int"},null,page.on,toggle,args[1],0);return unit();
            });
            Object body=call("ss","Q",new String[]{"int","gt1","lu1"},null,0x2168c602,content,composer);
            call("ak2","d",new String[]{"us1","zn0","lu1","int","int"},null,null,body,composer,48,1);
            if(page.on&&!page.detail.isEmpty())styled(page.detail,null,composer,page.failed?"e":"g","j",2);
            if(page.on&&page.snapshot!=null&&page.snapshot.maxLength>0&&bytes(page.sending.text())>page.snapshot.maxLength)
                styled("RCS 消息最多 "+page.snapshot.maxLength+" 字节",null,composer,"e","j",2);
            List<RcsChatTransport.Message> messages=page.messages();
            if(!messages.isEmpty()){
                int count=Math.min(3,messages.size());
                action("RCS 记录 · 最近 "+count+" 条  ›",composer,args->{page.historyOpen=true;changed();return unit();});
                for(int i=messages.size()-count;i<messages.size();i++){
                    RcsChatTransport.Message item=messages.get(i);
                    action((item.incoming?"收到 · ":"发出 · ")+item.status+"\n"+item.body,composer,args->{page.historyOpen=true;changed();return unit();});
                }
            }
            if(page.historyOpen)history(page,composer);
            Object scope=call("lu1","u",new String[]{},composer);started=false;
            if(scope!=null)scope.getClass().getField("d").set(scope,function("kt1",args->{renderInternal(state,peer,draft,args[0],editingRecipient);return unit();}));
        }catch(Exception failure){
            Session session=SESSIONS.get(draft);if(session!=null&&session.on)session.fail(message(failure));
        }finally{
            if(started)try{call("lu1","u",new String[]{},composer);}catch(Exception ignored){}
        }
    }
    /** The native registration hint describes ordinary SMS only. */
    public static boolean showSmsHint(Object draft){
        try{observe();}catch(Exception ignored){}
        Session session=SESSIONS.get(draft);
        return session==null||!session.on;
    }
    /** Off preserves the original SMS button predicate exactly. */
    public static boolean sendEnabled(boolean original,String peer,Object draft){
        try{observe();Session session=SESSIONS.get(draft);if(session==null||!session.on)return original;
            session.observeDraft();return session.matches(peer)&&session.ready();
        }catch(Exception failure){Session session=SESSIONS.get(draft);return session==null||!session.on?original:false;}
    }
    /** Called before the native callback clears its draft or enters SMS transport. */
    public static boolean trySend(String peer,Object draft){
        Session session=SESSIONS.get(draft);if(session==null||!session.on)return false;
        if(!session.matches(peer)){session.fail("联系人或卡片已变化，请重新确认 RCS");return true;}
        session.send();return true;
    }
    /** New-message form supplies its still-editable recipient state, not a guessed number. */
    public static void renderDraft(Object state,Object peer,Object draft,Object composer){
        try{renderInternal(state,text(peer),draft,composer,true);}catch(Exception unavailable){Session session=SESSIONS.get(draft);if(session!=null&&session.on)session.fail(message(unavailable));}
    }
    public static boolean sendEnabledDraft(boolean original,Object peer,Object draft){
        try{return sendEnabled(original,text(peer),draft);}catch(Exception unavailable){Session session=SESSIONS.get(draft);return session==null||!session.on?original:false;}
    }
    public static boolean trySendDraft(Object peer,Object draft){
        try{return trySend(text(peer),draft);}catch(Exception unavailable){Session session=SESSIONS.get(draft);if(session==null||!session.on)return false;session.fail(message(unavailable));return true;}
    }
    private static void styled(String value,Object modifier,Object composer,String color,String style,int lines)throws Exception{
        Object theme=call("lu1","k",new String[]{"rv3"},composer,field("z55","c"));
        long tint=((Number)WifiConfigModel.get(theme,color)).longValue();
        if(modifier==null)modifier=call("oo4","c",new String[]{"r53","float"},null,field("o53","b"),1f);
        call("z45","b",new String[]{"java.lang.String","r53","long","long","nq1","sz4","long","n25","long","int","boolean","int","int","s55","lu1","int","int","int"},null,
            value,modifier,tint,0L,null,null,0L,null,0L,2,true,lines,1,field("mk2",style),composer,0,0,0x1aff8);
    }
    private static void action(String title,Object composer,Action action)throws Exception{
        Object click=function("us1",action);Object content=function("lt1",args->{styled(title,null,args[1],"b","j",2);return unit();});
        Object lambda=call("ss","Q",new String[]{"int","gt1","lu1"},null,title.hashCode(),content,composer);
        call("ak2","d",new String[]{"us1","zn0","lu1","int","int"},null,click,lambda,composer,48,0);
    }
    private static void history(Session page,Object composer)throws Exception{
        Object close=function("us1",args->{page.historyOpen=false;changed();return unit();});
        Object button=type("cj2").getConstructor(String.class,type("ij2"),boolean.class,type("us1")).newInstance("关闭",field("ij2","T"),true,close);
        Object content=function("lt1",args->{
            DateFormat format=DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT);
            for(RcsChatTransport.Message item:page.messages()){
                String stamp=item.timestamp>0?format.format(new Date(item.timestamp))+" · ":"";
                styled((item.incoming?"收到 · ":"发出 · ")+stamp+item.status,null,args[1],"g","j",Integer.MAX_VALUE);
                styled(item.body,null,args[1],"f","e",Integer.MAX_VALUE);
            }
            return unit();
        });
        call("xq0","k",new String[]{"java.lang.String","java.util.List","us1","java.lang.String","boolean","lt1","lu1","int","int"},null,
            "RCS 记录",Collections.singletonList(button),close,null,false,content,composer,0,0);
    }
    public static final class DraftState {
        private String text="";private long revision;private Pending pending;private boolean uncertain;
        public String text(){return text;}public boolean busy(){return pending!=null;}public boolean uncertain(){return uncertain;}
        public void edit(String value){text=value==null?"":value;revision++;}
        public Pending begin(){if(pending!=null||uncertain||text.trim().isEmpty())throw new IllegalStateException("当前不能发送");pending=new Pending(text,revision);return pending;}
        public void stop(){pending=null;uncertain=false;}
        public boolean finish(Pending sent,boolean accepted,boolean unknown){if(pending!=sent)return false;pending=null;uncertain=unknown;
            if(accepted&&!unknown&&revision==sent.revision&&text.equals(sent.text)){text="";revision++;return true;}return false;}
    }
    public static final class Pending {public final String text;private final long revision;private Pending(String text,long revision){this.text=text;this.revision=revision;}}

    private static final class Session implements RcsChatTransport.Listener {
        final WeakReference<Activity> owner;final WeakReference<Object> draft;final String peer,lineKey;final boolean editingRecipient;
        Object state;final DraftState sending=new DraftState();RcsChatBinding binding;RcsChatTransport transport;RcsChatTransport.Snapshot snapshot;
        Application.ActivityLifecycleCallbacks lifecycle;boolean on,active,failed,connecting,historyOpen,started,confirmLine;String detail="",historyKey;long nextRefresh,epoch;
        final Runnable tick=new Runnable(){public void run(){if(!active||!on)return;if(binding!=null)validateBinding();if(transport!=null&&System.currentTimeMillis()>=nextRefresh){nextRefresh=System.currentTimeMillis()+15000;transport.refresh();}MAIN.postDelayed(this,1500);}};
        final Runnable connectTask=new Runnable(){public void run(){if(active&&on)connect();}};
        Session(Activity activity,Object state,String peer,Object draft,String key,boolean editingRecipient){owner=new WeakReference<>(activity);this.state=state;this.peer=peer==null?"":peer;this.draft=new WeakReference<>(draft);lineKey=key;this.editingRecipient=editingRecipient;on=key!=null&&Boolean.TRUE.equals(LINES.get(key));}
        void retainDraftMode(Session previous){
            if(previous==null)return;
            // This is still the same native draft. Editing its address or changing SIMs
            // must never turn an explicit RCS send into an ordinary SMS.
            if(previous.on)on=true;
            if(on&&(previous.confirmLine||!Objects.equals(previous.lineKey,lineKey))){
                confirmLine=true;failed=true;detail="卡片已切换，请关闭后重新开启 RCS";
            }
        }
        boolean matches(String address){return active&&current==this&&Objects.equals(peer,address);}
        void observeDraft()throws Exception{Object value=draft.get();if(value!=null){String latest=text(value);if(!latest.equals(sending.text()))sending.edit(latest);}}
        String phase(){if(!on)return "已关闭（短信）";if(sending.busy())return "正在发送";if(failed||sending.uncertain())return "不可用";if(connecting)return "连接中";if(snapshot!=null)return snapshot.registered&&snapshot.canSend?"已连接":"不可用";return "连接中";}
        void start(){
            if(started)return;started=true;Activity activity=owner.get();if(activity==null)return;
            lifecycle=new Application.ActivityLifecycleCallbacks(){public void onActivityCreated(Activity a,Bundle b){}public void onActivityStarted(Activity a){}
                public void onActivityResumed(Activity a){if(owner.get()==a&&active&&on){MAIN.removeCallbacks(tick);MAIN.post(tick);if(transport==null&&!failed)scheduleConnect();}}
                public void onActivityPaused(Activity a){}public void onActivityStopped(Activity a){if(owner.get()==a){MAIN.removeCallbacks(tick);MAIN.removeCallbacks(connectTask);}}
                public void onActivitySaveInstanceState(Activity a,Bundle b){}public void onActivityDestroyed(Activity a){if(owner.get()==a)retire();}};
            activity.getApplication().registerActivityLifecycleCallbacks(lifecycle);
            if(on&&!confirmLine){scheduleConnect();MAIN.postDelayed(tick,1500);}
        }
        void toggle(boolean value){
            if(!active)return;on=value;confirmLine=false;
            if(lineKey!=null&&lineKey.equals(line(state)))LINES.put(lineKey,value);
            historyOpen=false;
            MAIN.removeCallbacks(tick);MAIN.removeCallbacks(connectTask);
            if(!value){epoch++;if(transport!=null){transport.close();transport=null;}snapshot=null;failed=false;connecting=false;detail="";sending.stop();if(historyKey!=null)UNCONFIRMED.remove(historyKey);}
            else {scheduleConnect();MAIN.postDelayed(tick,1500);}changed();
        }
        void scheduleConnect(){MAIN.removeCallbacks(connectTask);failed=false;connecting=true;detail="";MAIN.postDelayed(connectTask,editingRecipient?650:0);}
        void connect(){
            if(!active||!on)return;
            final long generation=++epoch;if(transport!=null){transport.close();transport=null;}snapshot=null;failed=false;connecting=true;detail="";nextRefresh=System.currentTimeMillis()+15000;
            try{
                Activity activity=owner.get();if(activity==null||activity.isFinishing()||activity.isDestroyed())throw new IllegalStateException("页面已关闭，请重新打开短信");
                binding=RcsChatBinding.capture(state,peer);binding.validateCurrent();
                if(lineKey!=null&&!lineKey.equals(binding.cardKey))throw new IllegalStateException("卡片已切换，请重新打开会话");
                historyKey=binding.cardKey+"\n"+binding.peer;
                if(UNCONFIRMED.contains(historyKey)){sending.uncertain=true;throw new IllegalStateException("上一条 RCS 发送结果待确认，请先核对消息记录");}
                RcsChatTransport.Listener listener=new RcsChatTransport.Listener(){
                    public void onSnapshot(RcsChatTransport.Snapshot value){if(active&&on&&epoch==generation)Session.this.onSnapshot(value);}
                    public void onFailure(String reason){if(active&&on&&epoch==generation)Session.this.onFailure(reason);}
                };
                transport=new RcsChatTransport(activity.getApplicationContext(),binding,listener);transport.connect();
            }catch(Exception unavailable){fail(message(unavailable));}changed();
        }
        boolean validateBinding(){
            if(!active||binding==null)return false;
            // The transport checks full subscriber/provider proof before sends
            // and before publishing callbacks. Rendering/ticks need only the
            // cheap current reader identity, not another telephony Binder query.
            try{if(!binding.cardKey.equals(RcsChatBinding.lineKey(WifiConfigRuntime.state())))throw new IllegalStateException("卡片已切换，请重新打开会话");return true;}
            catch(Exception changed){
                // Retain the pending-send guard under the old key before detaching its
                // messages. The current card may now be a different line for this peer.
                fail(message(changed));historyKey=null;historyOpen=false;return false;
            }
        }
        boolean ready(){return on&&!failed&&!sending.busy()&&!sending.uncertain()&&binding!=null&&snapshot!=null&&snapshot.registered&&snapshot.canSend&&!sending.text().trim().isEmpty()&&(snapshot.maxLength<=0||bytes(sending.text())<=snapshot.maxLength);}
        void send(){
            try{
                observeDraft();if(!ready()||!validateBinding()){changed();return;}
                binding.validateProvider(snapshot.localContact);Pending pending=sending.begin();final long generation=epoch;detail="";changed();
                transport.send(pending.text,result->{
                    if(!active||!on||epoch!=generation)return;
                    try{
                        observeDraft();if(!validateBinding()){sending.finish(pending,false,result.uncertain);changed();return;}
                        boolean clear=sending.finish(pending,result.accepted,result.uncertain);
                        if(clear){Object input=draft.get();if(input!=null&&pending.text.equals(text(input)))call("m83","setValue",new String[]{"java.lang.Object"},input,"");}
                        if(!result.accepted||result.uncertain){failed=true;detail=result.detail==null?"RCS 发送未确认，草稿已保留":result.detail;if(result.uncertain){markUnconfirmed();detail+="；请先核对消息记录";}}
                        changed();if(transport!=null)transport.refresh();
                    }catch(Exception failure){fail(message(failure));}
                });
            }catch(Exception failure){fail(message(failure));}
        }
        public void onSnapshot(RcsChatTransport.Snapshot value){
            if(!active||!on||!validateBinding())return;
            snapshot=value;if(value.registered)connecting=false;
            if(!sending.uncertain()){
                failed=(!value.registered&&!connecting)||(value.registered&&!value.canSend&&!sending.busy());
                detail=value.status==null||value.status.equals("RCS 已连接")||(connecting&&!value.registered)?"":value.status;
            }
            if(historyKey!=null&&value.messages!=null){
                Map<String,RcsChatTransport.Message> merged=new LinkedHashMap<>();for(RcsChatTransport.Message item:messages())merged.put(item.id,item);
                for(RcsChatTransport.Message item:value.messages)if(item!=null&&item.id!=null)merged.put(item.id,item);
                List<RcsChatTransport.Message> rows=new ArrayList<>(merged.values());Collections.sort(rows,(a,b)->Long.compare(a.timestamp,b.timestamp));
                if(rows.size()>100)rows=new ArrayList<>(rows.subList(rows.size()-100,rows.size()));HISTORY.put(historyKey,Collections.unmodifiableList(rows));
            }
            changed();
        }
        public void onFailure(String reason){if(active&&on)fail(reason==null?"RCS 服务暂不可用":reason);}
        void markUnconfirmed(){if(historyKey!=null){UNCONFIRMED.add(historyKey);while(UNCONFIRMED.size()>16)UNCONFIRMED.remove(UNCONFIRMED.iterator().next());}}
        void fail(String reason){
            if(sending.busy()){sending.finish(sending.pending,false,true);markUnconfirmed();reason+="；发送结果待确认，草稿已保留";}
            boolean notify=!failed||!Objects.equals(detail,reason)||snapshot!=null;failed=true;connecting=false;detail=reason;if(transport!=null){epoch++;transport.close();transport=null;}snapshot=null;if(notify)changed();
        }
        List<RcsChatTransport.Message> messages(){List<RcsChatTransport.Message> value=historyKey==null?null:HISTORY.get(historyKey);return value==null?Collections.<RcsChatTransport.Message>emptyList():value;}
        void retire(){if(sending.busy()){sending.finish(sending.pending,false,true);markUnconfirmed();}epoch++;active=false;MAIN.removeCallbacks(tick);MAIN.removeCallbacks(connectTask);if(transport!=null){transport.close();transport=null;}
            Activity activity=owner.get();if(activity!=null&&lifecycle!=null)activity.getApplication().unregisterActivityLifecycleCallbacks(lifecycle);lifecycle=null;started=false;}
    }
}
