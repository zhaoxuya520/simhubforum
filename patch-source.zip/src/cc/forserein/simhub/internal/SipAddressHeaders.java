package cc.forserein.simhub.internal;

import java.util.ArrayList;

/** Address-list forms used by IMS registration and SIP dialog routing. */
public final class SipAddressHeaders {
    private SipAddressHeaders() {}

    public static boolean handles(String name) {
        return "P-Associated-URI".equalsIgnoreCase(name)
                || "Service-Route".equalsIgnoreCase(name)
                || "Record-Route".equalsIgnoreCase(name)
                || "Route".equalsIgnoreCase(name)
                || "Contact".equalsIgnoreCase(name)
                || "m".equalsIgnoreCase(name);
    }

    /** RFC 3261 sections 7.3.1 and 25.1; RFC 3455 section 4.1. */
    public static ArrayList<String> split(String value) {
        ArrayList<String> addresses = new ArrayList<>();
        int start = 0;
        int commentDepth = 0;
        boolean quoted = false;
        boolean inUri = false;
        boolean escaped = false;
        boolean valid = true;
        for (int index = 0; index < value.length(); index++) {
            char c = value.charAt(index);
            if (escaped) {
                escaped = false;
            } else if ((quoted || commentDepth > 0) && c == '\\') {
                escaped = true;
            } else if (quoted) {
                if (c == '"') quoted = false;
            } else if (commentDepth > 0) {
                if (c == '(') commentDepth++;
                if (c == ')') commentDepth--;
            } else if (inUri) {
                if (c == '>') inUri = false;
            } else if (c == '"') {
                quoted = true;
            } else if (c == '(') {
                commentDepth = 1;
            } else if (c == '<') {
                inUri = true;
            } else if (c == ')' || c == '>') {
                valid = false;
                break;
            } else if (c == ',') {
                String address = value.substring(start, index).trim();
                if (address.isEmpty()) {
                    valid = false;
                    break;
                }
                addresses.add(address);
                start = index + 1;
            }
        }
        if (!valid || quoted || inUri || commentDepth != 0 || start == value.length()
                || (start > 0 && value.substring(start).trim().isEmpty())) {
            // Keep malformed input opaque to avoid routing through a partial address.
            addresses.clear();
            addresses.add(value);
        } else {
            addresses.add(start == 0 ? value : value.substring(start).trim());
        }
        return addresses;
    }
}
