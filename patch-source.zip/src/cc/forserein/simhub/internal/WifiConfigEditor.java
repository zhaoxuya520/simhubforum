package cc.forserein.simhub.internal;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import java.lang.ref.WeakReference;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Uses the original app's Compose row, alert and text-field renderers, without replacing its UI. */
public final class WifiConfigEditor {
    private WifiConfigEditor() {}
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static final Map<String,Method> METHODS=new ConcurrentHashMap<>();
    private static Session current;
    private interface Action {Object run(Object[] args) throws Exception;}
    private static Class<?> type(String name) throws ClassNotFoundException {
        if(name.equals("int"))return int.class;if(name.equals("boolean"))return boolean.class;
        if(name.equals("long"))return long.class;if(name.equals("float"))return float.class;
        return Class.forName(name);
    }
    private static Method method(String owner,String name,String...types) throws Exception {
        String key=owner+"."+name+Arrays.toString(types);Method m=METHODS.get(key);
        if(m==null){Class<?>[] args=new Class<?>[types.length];for(int i=0;i<args.length;i++)args[i]=type(types[i]);m=type(owner).getMethod(name,args);METHODS.put(key,m);}return m;
    }
    private static Object call(String owner,String name,String[] types,Object target,Object...args) throws Exception {
        return method(owner,name,types).invoke(target,args);
    }
    private static Object field(String owner,String name) throws Exception {return type(owner).getField(name).get(null);}
    private static Object unit() throws Exception {return field("sc5","a");}
    private static Object function(String iface,Action action) throws Exception {
        Class<?> t=type(iface);
        return Proxy.newProxyInstance(t.getClassLoader(),new Class<?>[]{t},(proxy,m,args)->{
            if(m.getDeclaringClass()==Object.class){
                if(m.getName().equals("equals"))return proxy==args[0];
                if(m.getName().equals("hashCode"))return System.identityHashCode(proxy);
                return "WiFiConfigCallback";
            }
            return action.run(args==null?new Object[0]:args);
        });
    }
    private static Object signal() throws Exception {return call("qd2","D",new String[]{"java.lang.Object"},null,0);}
    private static void read(Session s) throws Exception {call("ot4","getValue",new String[]{},s.signal);}
    private static void changed(Session s) throws Exception {call("m83","setValue",new String[]{"java.lang.Object"},s.signal,++s.revision);}
    private static void invoke(Object callback) throws Exception {call("us1","a",new String[]{},callback);}
    private static Activity activity(Context context) {
        while(context instanceof ContextWrapper && !(context instanceof Activity)){
            Context base=((ContextWrapper)context).getBaseContext();if(base==context)break;context=base;
        }
        return context instanceof Activity?(Activity)context:null;
    }
    private static final class Session {
        final WifiConfigRuntime.Snapshot snapshot;
        final WifiConfigDraft draft;
        final WeakReference<Activity> owner;
        final Object original,signal;
        Object done,cancel;int revision;boolean busy;
        Selection selection;
        Application.ActivityLifecycleCallbacks lifecycle;
        Session(Activity owner,Object close) throws Exception {
            this.owner=new WeakReference<>(owner);original=close;snapshot=WifiConfigRuntime.snapshot();
            draft=new WifiConfigDraft(snapshot.values);signal=signal();
        }
    }
    private static final class Selection {
        final String row;final Map<String,String> values=new LinkedHashMap<>();
        String error="";
        Selection(String row,WifiConfigDraft draft){this.row=row;for(String key:WifiConfigDraft.keys(row))values.put(key,draft.text(key));}
    }
    /** Called before constructing the original config sheet content. */
    public static Object begin(Context context,Object onClose) {
        try {
            Activity owner=activity(context);
            if(owner==null)throw new IllegalStateException("配置页面尚未就绪");
            Session s=current;
            if(s==null || s.owner.get()!=owner) {
                if(s!=null) dispose(s);
                s=new Session(owner,onClose);current=s;
                final Session page=s;
                s.done=function("us1",args->{finish(page);return unit();});
                s.cancel=function("us1",args->{if(!page.busy){dispose(page);invoke(page.original);}return unit();});
                s.lifecycle=new Application.ActivityLifecycleCallbacks(){
                    public void onActivityCreated(Activity a,Bundle b){}
                    public void onActivityStarted(Activity a){}
                    public void onActivityResumed(Activity a){}
                    public void onActivityPaused(Activity a){}
                    public void onActivityStopped(Activity a){}
                    public void onActivitySaveInstanceState(Activity a,Bundle b){}
                    public void onActivityDestroyed(Activity a){if(page.owner.get()==a)dispose(page);}
                };
                owner.getApplication().registerActivityLifecycleCallbacks(s.lifecycle);
                if(s.snapshot.warning!=null)toast(s,s.snapshot.warning);
            }
            return s.done;
        }catch(Exception e){toast(context,message(e));return onClose;}
    }
    /** The original inline Apply control acknowledges the draft; only page Done persists. */
    public static Object stageCallback(Object fallback) {
        Session s=current;if(s==null)return fallback;
        try{return function("us1",args->{
            if(current==s && !s.busy){
                try{s.draft.validated();toast(s,"修改已暂存，尚未保存。请点击右上角“完成”统一保存。");}
                catch(WifiConfigValues.Invalid e){toast(s,WifiConfigValues.field(e.key).label+"："+e.getMessage());}
            }
            return unit();
        });}catch(Exception e){toast(s,message(e));return null;}
    }
    public static Object cancelCallback(Object fallback){return current==null?fallback:current.cancel;}
    private static void dispose(Session s) {
        Activity owner=s.owner.get();
        if(owner!=null && s.lifecycle!=null)owner.getApplication().unregisterActivityLifecycleCallbacks(s.lifecycle);
        if(current==s)current=null;
    }
    private static String legacyKey(int mode){return mode==16?"epdg":mode==17?"imei":mode==18?"smsc":null;}
    /** Existing inline text fields read a draft instead of overwriting the stored config while typing. */
    public static String scalar(String original,int mode) {
        Session s=current;String key=legacyKey(mode);if(s==null || key==null)return original;
        try{read(s);return s.draft.text(key);}catch(Exception e){toast(s,message(e));return original;}
    }
    public static String imeiText(String original){return scalar(original,17);}
    public static boolean imeiValid(Object state) {
        try {
            if(current==null)return Boolean.TRUE.equals(state.getClass().getMethod("c").invoke(state));
            read(current);String value=current.draft.text("imei");
            if(value.trim().isEmpty())return false;
            WifiConfigValues.validate(Collections.singletonMap("imei",value));return true;
        }catch(Exception e){return false;}
    }
    public static boolean editLegacy(int mode,Object value) {
        Session s=current;String key=legacyKey(mode);if(s==null || key==null)return false;
        if(s.busy)return true;
        try{s.draft.edit(key,(String)value);changed(s);}catch(Exception e){toast(s,message(e));}
        return true;
    }
    private static void finish(Session s) {
        if(current!=s || s.busy)return;
        final Map<String,String> values;
        try{values=s.draft.validated();}catch(WifiConfigValues.Invalid e){toast(s,WifiConfigValues.field(e.key).label+"："+e.getMessage());return;}
        s.busy=true;
        new Thread(()->{
            Exception error=null;
            try{WifiConfigRuntime.save(s.snapshot.key,s.snapshot.record,values);}catch(Exception e){error=e;}
            final Exception failure=error;
            MAIN.post(()->{
                s.busy=false;if(current!=s)return;
                if(failure!=null){toast(s,message(failure));return;}
                dispose(s);
                try{invoke(s.original);}catch(Exception e){toast(s,message(e));}
            });
        },"simhub-config-save").start();
    }
    private static String message(Throwable e){
        while(e instanceof InvocationTargetException && e.getCause()!=null)e=e.getCause();
        if(e instanceof IllegalArgumentException || e instanceof IllegalStateException)return e.getMessage();
        return "配置操作失败（"+e.getClass().getSimpleName()+"），请关闭后重新打开配置";
    }
    private static void toast(Session s,String message){Activity a=s.owner.get();if(a!=null && !a.isDestroyed())toast(a,message);}
    private static void toast(Context c,String message){Toast.makeText(c,message,Toast.LENGTH_LONG).show();}

    /** Same fj(mode=3) content and ak2.d row as yd2.d; only its click callback is added. */
    public static void row(String label,String original,Object composer,int flags) {
        try {
            call("lu1","e0",new String[]{"int"},composer,0x2168c001^label.hashCode());
            Session s=current;
            String value=original;Object click=null;
            if(s!=null){
                read(s);value=s.draft.display(label,original,s.snapshot.defaults);
                if(label.equals("NAI") && !value.equals(original))value=maskIdentity(value);
                click=function("us1",args->{if(current==s && !s.busy){s.selection=new Selection(label,s.draft);changed(s);}return unit();});
            }
            Object theme=call("lu1","k",new String[]{"rv3"},composer,field("z55","c"));
            Object content=type("fj").getConstructor(type("jj2"),String.class,String.class,int.class).newInstance(theme,label,value,3);
            Object lambda=call("ss","Q",new String[]{"int","gt1","lu1"},null,-1495627232,content,composer);
            call("ak2","d",new String[]{"us1","zn0","lu1","int","int"},null,click,lambda,composer,48,click==null?1:0);
            Object scope=call("lu1","u",new String[]{},composer);
            if(scope!=null)scope.getClass().getField("d").set(scope,function("kt1",args->{row(label,original,args[0],flags|1);return unit();}));
        }catch(Exception e){throw new IllegalStateException("配置条目载入失败",e);}
    }
    private static String maskIdentity(String value) throws Exception {
        Object card=WifiConfigModel.get(WifiConfigRuntime.state(),"e");if(card==null)return value;
        String imsi=(String)WifiConfigModel.get(card,"a");
        String masked=imsi.length()>7?imsi.substring(0,5)+repeat("•",imsi.length()-7)+imsi.substring(imsi.length()-2):repeat("•",imsi.length());
        return value.replace(imsi,masked);
    }
    private static String repeat(String text,int count){StringBuilder b=new StringBuilder();for(int i=0;i<count;i++)b.append(text);return b.toString();}
    /** Original IosAlert, original field controls; no Android replacement form or new main-page rows. */
    public static void overlay(Object composer) {
        try {
            call("lu1","e0",new String[]{"int"},composer,0x2168c002);
            Session s=current;
            if(s!=null){
                read(s);Selection selection=s.selection;
                if(selection!=null){
                    Object cancel=function("us1",args->{if(current==s){s.selection=null;changed(s);}return unit();});
                    Object reset=function("us1",args->{for(String key:selection.values.keySet())selection.values.put(key,"");selection.error="";changed(s);return unit();});
                    Object confirm=function("us1",args->{
                        if(current!=s)return unit();
                        try{s.draft.apply(selection.values);s.selection=null;}
                        catch(WifiConfigValues.Invalid e){selection.error=WifiConfigValues.field(e.key).label+"："+e.getMessage();}
                        changed(s);return unit();
                    });
                    List<Object> buttons=Arrays.asList(button("取消","U",cancel),button(selection.values.size()==1?"恢复本项内置":"恢复本组内置","T",reset),button("暂存修改","T",confirm));
                    Object body=function("lt1",args->{fields(s,selection,args[1]);return unit();});
                    String description=selection.error.isEmpty()?"填写自定义值，留空使用内置。“暂存修改”后，点击页面右上角“完成”保存。":selection.error;
                    call("xq0","k",new String[]{"java.lang.String","java.util.List","us1","java.lang.String","boolean","lt1","lu1","int","int"},null,
                        selection.row,buttons,cancel,description,false,body,composer,0,0);
                }
            }
            Object scope=call("lu1","u",new String[]{},composer);
            if(scope!=null)scope.getClass().getField("d").set(scope,function("kt1",args->{overlay(args[0]);return unit();}));
        }catch(Exception e){throw new IllegalStateException("配置编辑载入失败",e);}
    }
    private static Object button(String label,String role,Object callback) throws Exception {
        return type("cj2").getConstructor(String.class,type("ij2"),boolean.class,type("us1")).newInstance(label,field("ij2",role),true,callback);
    }
    /** Full-width native Compose Text. Never use the app's two-column setting row inside alerts. */
    private static void text(String label,String value,Object composer) throws Exception {
        Object theme=call("lu1","k",new String[]{"rv3"},composer,field("z55","c"));
        long color=((Number)WifiConfigModel.get(theme,"f")).longValue();
        Object width=call("oo4","c",new String[]{"r53","float"},null,field("o53","b"),1f);
        String content=value==null || value.isEmpty()?label:label+"\n"+value;
        call("z45","b",new String[]{"java.lang.String","r53","long","long","nq1","sz4","long","n25","long","int","boolean","int","int","s55","lu1","int","int","int"},null,
            content,width,color,0L,null,null,0L,null,0L,0,true,Integer.MAX_VALUE,1,field("mk2","h"),composer,0,0,0x1fff8);
    }
    private static void fields(Session s,Selection selection,Object composer) throws Exception {
        read(s);
        for(String key:selection.values.keySet()) {
            WifiConfigValues.Field f=WifiConfigValues.field(key);
            String override=selection.values.get(key);
            // Keep editing reachable before the reference/default text, even on small displays.
            text(selection.values.size()==1?"自定义覆盖值（留空使用内置）":f.label+" · 自定义覆盖值",null,composer);
            Object change=function("ws1",args->{if(current==s){selection.values.put(key,(String)args[0]);selection.error="";changed(s);}return unit();});
            Object width=call("oo4","c",new String[]{"r53","float"},null,field("o53","b"),1f);
            call("ak2","f",new String[]{"java.lang.String","ws1","java.lang.String","r53","int","boolean","s55","lu1","int","int"},null,
                selection.values.get(key),change,"留空使用内置 / 自动值",width,key.equals("keepalive")?3:1,false,null,composer,0,96);
            String saved=s.snapshot.values.get(key);
            text("内置默认值（不可改写）",WifiConfigPresentation.defaultText(key,s.snapshot.defaults),composer);
            text("当前已保存（"+WifiConfigPresentation.source(saved)+"）",WifiConfigPresentation.effective(key,saved,s.snapshot.defaults),composer);
            text("本次保存后（预览）",WifiConfigPresentation.effective(key,override,s.snapshot.defaults)+"（"+WifiConfigPresentation.source(override)+"，尚未保存）",composer);
            text("说明",f.help,composer);
        }
    }
}
