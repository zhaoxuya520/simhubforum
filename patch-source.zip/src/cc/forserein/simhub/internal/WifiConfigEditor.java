package cc.forserein.simhub.internal;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import java.lang.ref.WeakReference;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Uses the original app's Compose row, alert and text-field renderers, without replacing its UI. */
public final class WifiConfigEditor {
    private WifiConfigEditor() {}
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static final Map<String,Method> METHODS=new ConcurrentHashMap<>();
    private static Session current;
    private interface Action {Object run(Object[] args) throws Exception;}
    private static Class<?> type(String name) throws ClassNotFoundException {
        if(name.equals("int"))return int.class;if(name.equals("boolean"))return boolean.class;
        if(name.equals("long"))return long.class;if(name.equals("float"))return float.class;
        return Class.forName(name);
    }
    private static Method method(String owner,String name,String...types) throws Exception {
        String key=owner+"."+name+Arrays.toString(types);Method m=METHODS.get(key);
        if(m==null){Class<?>[] args=new Class<?>[types.length];for(int i=0;i<args.length;i++)args[i]=type(types[i]);m=type(owner).getMethod(name,args);METHODS.put(key,m);}return m;
    }
    private static Object call(String owner,String name,String[] types,Object target,Object...args) throws Exception {
        return method(owner,name,types).invoke(target,args);
    }
    private static Object field(String owner,String name) throws Exception {return type(owner).getField(name).get(null);}
    private static Object unit() throws Exception {return field("sc5","a");}
    private static Object function(String iface,Action action) throws Exception {
        Class<?> t=type(iface);
        return Proxy.newProxyInstance(t.getClassLoader(),new Class<?>[]{t},(proxy,m,args)->{
            if(m.getDeclaringClass()==Object.class){
                if(m.getName().equals("equals"))return proxy==args[0];
                if(m.getName().equals("hashCode"))return System.identityHashCode(proxy);
                return "WiFiConfigCallback";
            }
            return action.run(args==null?new Object[0]:args);
        });
    }
    private static Object signal() throws Exception {return call("qd2","D",new String[]{"java.lang.Object"},null,0);}
    private static void read(Session s) throws Exception {call("ot4","getValue",new String[]{},s.signal);}
    private static void changed(Session s) throws Exception {call("m83","setValue",new String[]{"java.lang.Object"},s.signal,++s.revision);}
    private static void invoke(Object callback) throws Exception {call("us1","a",new String[]{},callback);}
    private static Activity activity(Context context) {
        while(context instanceof ContextWrapper && !(context instanceof Activity)){
            Context base=((ContextWrapper)context).getBaseContext();if(base==context)break;context=base;
        }
        return context instanceof Activity?(Activity)context:null;
    }
    private static final class Session {
        final WifiConfigRuntime.Snapshot snapshot;
        final WifiConfigDraft draft;
        final WeakReference<Activity> owner;
        final Object original,signal;
        Object done,cancel;int revision;boolean busy;
        String record;Map<String,String> saved;
        Selection selection;
        Application.ActivityLifecycleCallbacks lifecycle;
        Session(Activity owner,Object close) throws Exception {
            this.owner=new WeakReference<>(owner);original=close;snapshot=WifiConfigRuntime.snapshot();
            draft=new WifiConfigDraft(snapshot.values);record=snapshot.record;saved=new LinkedHashMap<>(snapshot.values);signal=signal();
        }
    }
    private static final class Selection {
        final String row;final Map<String,String> values=new LinkedHashMap<>();
        WifiConfigListDraft list;String error="";
        Selection(String row,WifiConfigDraft draft,Map<String,String> defaults){
            this.row=row;
            if(row.equals("ePDG") || row.equals("短信中心"))list=new WifiConfigListDraft(row.equals("短信中心"),draft.copy(),defaults);
            else for(String key:WifiConfigDraft.keys(row))values.put(key,WifiConfigPresentation.input(key,draft.text(key),defaults));
        }
        Map<String,String> changes(Map<String,String> defaults){return list==null?WifiConfigPresentation.overrides(values,defaults):list.values();}
    }
    /** Called before constructing the original config sheet content. */
    public static Object begin(Context context,Object onClose) {
        try {
            Activity owner=activity(context);
            if(owner==null)throw new IllegalStateException("配置页面尚未就绪");
            Session s=current;
            if(s==null || s.owner.get()!=owner) {
                if(s!=null) dispose(s);
                s=new Session(owner,onClose);current=s;
                final Session page=s;
                s.done=function("us1",args->{finish(page);return unit();});
                s.cancel=function("us1",args->{if(!page.busy){dispose(page);invoke(page.original);}return unit();});
                s.lifecycle=new Application.ActivityLifecycleCallbacks(){
                    public void onActivityCreated(Activity a,Bundle b){}
                    public void onActivityStarted(Activity a){}
                    public void onActivityResumed(Activity a){}
                    public void onActivityPaused(Activity a){}
                    public void onActivityStopped(Activity a){}
                    public void onActivitySaveInstanceState(Activity a,Bundle b){}
                    public void onActivityDestroyed(Activity a){if(page.owner.get()==a)dispose(page);}
                };
                owner.getApplication().registerActivityLifecycleCallbacks(s.lifecycle);
                if(s.snapshot.warning!=null)toast(s,s.snapshot.warning);
            }
            return s.done;
        }catch(Exception e){toast(context,message(e));return onClose;}
    }
    /** Compatibility callback for the original page-level save control. */
    public static Object stageCallback(Object fallback) {
        Session s=current;if(s==null)return fallback;
        try{return function("us1",args->{finish(s);return unit();});}
        catch(Exception e){toast(s,message(e));return fallback;}
    }
    public static Object cancelCallback(Object fallback){return current==null?fallback:current.cancel;}
    private static void dispose(Session s) {
        Activity owner=s.owner.get();
        if(owner!=null && s.lifecycle!=null)owner.getApplication().unregisterActivityLifecycleCallbacks(s.lifecycle);
        if(current==s)current=null;
    }
    private static String legacyKey(int mode){return mode==16?"epdg":mode==17?"imei":mode==18?"smsc":null;}
    /** Existing inline text fields read a draft instead of overwriting the stored config while typing. */
    public static String scalar(String original,int mode) {
        Session s=current;String key=legacyKey(mode);if(s==null || key==null)return original;
        try{read(s);return s.draft.text(key);}catch(Exception e){toast(s,message(e));return original;}
    }
    public static String imeiText(String original){return scalar(original,17);}
    public static boolean imeiValid(Object state) {
        try {
            if(current==null)return Boolean.TRUE.equals(state.getClass().getMethod("c").invoke(state));
            read(current);String value=current.draft.text("imei");
            if(value.trim().isEmpty())return false;
            WifiConfigValues.validate(Collections.singletonMap("imei",value));return true;
        }catch(Exception e){return false;}
    }
    public static boolean editLegacy(int mode,Object value) {
        Session s=current;String key=legacyKey(mode);if(s==null || key==null)return false;
        if(s.busy)return true;
        try{s.draft.edit(key,(String)value);changed(s);}catch(Exception e){toast(s,message(e));}
        return true;
    }
    private static void finish(Session s) {
        if(current!=s || s.busy)return;
        final Map<String,String> values;
        try{values=s.draft.validated();}catch(WifiConfigValues.Invalid e){toast(s,WifiConfigValues.field(e.key).label+"："+e.getMessage());return;}
        s.busy=true;
        new Thread(()->{
            Exception error=null;
            try{WifiConfigRuntime.save(s.snapshot.key,s.record,values);}catch(Exception e){error=e;}
            final Exception failure=error;
            MAIN.post(()->{
                s.busy=false;if(current!=s)return;
                if(failure!=null){toast(s,message(failure));return;}
                dispose(s);
                try{invoke(s.original);}catch(Exception e){toast(s,message(e));}
            });
        },"simhub-config-save").start();
    }
    private static String message(Throwable e){
        while(e instanceof InvocationTargetException && e.getCause()!=null)e=e.getCause();
        if(e instanceof IllegalArgumentException || e instanceof IllegalStateException)return e.getMessage();
        return "配置操作失败（"+e.getClass().getSimpleName()+"），请关闭后重新打开配置";
    }
    private static void toast(Session s,String message){Activity a=s.owner.get();if(a!=null && !a.isDestroyed())toast(a,message);}
    private static void toast(Context c,String message){Toast.makeText(c,message,Toast.LENGTH_LONG).show();}

    public static boolean listSection(int mode,Object composer) {
        if(current==null || mode<20 || mode>22)return false;
        String label=mode==20?"ePDG":mode==21?"短信中心":"IMEI";
        row(label,"",composer,6);return true;
    }
    private static String rowValue(Session s,String label,String original){
        if(label.equals("ePDG") || label.equals("短信中心")){
            WifiConfigListDraft list=new WifiConfigListDraft(label.equals("短信中心"),s.draft.copy(),s.snapshot.defaults);
            if(list.entries.isEmpty())return "未设置";
            if(label.equals("ePDG"))return list.entries.size()==1?list.entries.get(0):list.entries.size()+" 条";
            return list.entries.get(list.selected);
        }
        if(label.equals("IMEI"))return WifiConfigPresentation.input("imei",s.draft.text("imei"),s.snapshot.defaults);
        return s.draft.display(label,original,s.snapshot.defaults);
    }
    private static void saveSelection(Session s,Selection selection,boolean reset){
        if(current!=s || s.busy || s.selection!=selection)return;
        final Map<String,String> changes=new LinkedHashMap<>(),merged=new LinkedHashMap<>(s.saved);
        try{
            if(!reset)changes.putAll(selection.changes(s.snapshot.defaults));
            for(String key:WifiConfigDraft.keys(selection.row))merged.remove(key);
            merged.putAll(changes);WifiConfigValues.validate(merged);
        }catch(IllegalArgumentException e){selection.error=e.getMessage();try{changed(s);}catch(Exception ignored){}return;}
        s.busy=true;
        new Thread(()->{
            Exception error=null;
            try{WifiConfigRuntime.save(s.snapshot.key,s.record,merged);}catch(Exception e){error=e;}
            final Exception failure=error;
            MAIN.post(()->{
                s.busy=false;if(current!=s)return;
                try{
                    if(failure!=null){selection.error=message(failure);changed(s);return;}
                    s.saved=new LinkedHashMap<>(WifiConfigValues.validate(merged));s.record=WifiConfigValues.encode(s.saved);
                    for(String key:WifiConfigDraft.keys(selection.row))s.draft.edit(key,s.saved.containsKey(key)?s.saved.get(key):"");
                    s.selection=reset?new Selection(selection.row,s.draft,s.snapshot.defaults):null;
                    changed(s);
                }catch(Exception e){toast(s,message(e));}
            });
        },"simhub-field-save").start();
    }
    /** Same fj(mode=3) content and ak2.d row as yd2.d; only its click callback is added. */
    public static void row(String label,String original,Object composer,int flags) {
        try {
            call("lu1","e0",new String[]{"int"},composer,0x2168c001^label.hashCode());
            Session s=current;
            String value=original;Object click=null;
            if(s!=null){
                read(s);value=rowValue(s,label,original);
                if(label.equals("NAI") && !value.equals(original))value=maskIdentity(value);
                click=function("us1",args->{if(current==s && !s.busy){s.selection=new Selection(label,s.draft,s.snapshot.defaults);changed(s);}return unit();});
            }
            Object theme=call("lu1","k",new String[]{"rv3"},composer,field("z55","c"));
            Object content=type("fj").getConstructor(type("jj2"),String.class,String.class,int.class).newInstance(theme,label,value,3);
            Object lambda=call("ss","Q",new String[]{"int","gt1","lu1"},null,-1495627232,content,composer);
            call("ak2","d",new String[]{"us1","zn0","lu1","int","int"},null,click,lambda,composer,48,click==null?1:0);
            Object scope=call("lu1","u",new String[]{},composer);
            if(scope!=null)scope.getClass().getField("d").set(scope,function("kt1",args->{row(label,original,args[0],flags|1);return unit();}));
        }catch(Exception e){throw new IllegalStateException("配置条目载入失败",e);}
    }
    private static String maskIdentity(String value) throws Exception {
        Object card=WifiConfigModel.get(WifiConfigRuntime.state(),"e");if(card==null)return value;
        String imsi=(String)WifiConfigModel.get(card,"a");
        String masked=imsi.length()>7?imsi.substring(0,5)+repeat("•",imsi.length()-7)+imsi.substring(imsi.length()-2):repeat("•",imsi.length());
        return value.replace(imsi,masked);
    }
    private static String repeat(String text,int count){StringBuilder b=new StringBuilder();for(int i=0;i<count;i++)b.append(text);return b.toString();}
    /** Original IosAlert, original field controls; no Android replacement form or new main-page rows. */
    public static void overlay(Object composer) {
        try {
            call("lu1","e0",new String[]{"int"},composer,0x2168c002);
            Session s=current;
            if(s!=null){
                read(s);Selection selection=s.selection;
                if(selection!=null){
                    Object cancel=function("us1",args->{if(current==s && !s.busy){s.selection=null;changed(s);}return unit();});
                    Object reset=function("us1",args->{saveSelection(s,selection,true);return unit();});
                    Object confirm=function("us1",args->{saveSelection(s,selection,false);return unit();});
                    List<Object> buttons=Arrays.asList(button("重置为内置","T",reset,!s.busy),button("保存","T",confirm,!s.busy));
                    Object body=function("lt1",args->{fields(s,selection,args[1]);return unit();});
                    String description=selection.error.isEmpty()?null:selection.error;
                    call("xq0","k",new String[]{"java.lang.String","java.util.List","us1","java.lang.String","boolean","lt1","lu1","int","int"},null,
                        selection.row,buttons,cancel,description,false,body,composer,0,0);
                }
            }
            Object scope=call("lu1","u",new String[]{},composer);
            if(scope!=null)scope.getClass().getField("d").set(scope,function("kt1",args->{overlay(args[0]);return unit();}));
        }catch(Exception e){throw new IllegalStateException("配置编辑载入失败",e);}
    }
    private static Object button(String label,String role,Object callback,boolean enabled) throws Exception {
        return type("cj2").getConstructor(String.class,type("ij2"),boolean.class,type("us1")).newInstance(label,field("ij2",role),enabled,callback);
    }
    /** Full-width native Compose Text. Never use the app's two-column setting row inside alerts. */
    private static void text(String label,String value,Object composer) throws Exception {
        Object theme=call("lu1","k",new String[]{"rv3"},composer,field("z55","c"));
        long color=((Number)WifiConfigModel.get(theme,"f")).longValue();
        Object width=call("oo4","c",new String[]{"r53","float"},null,field("o53","b"),1f);
        String content=value==null || value.isEmpty()?label:label+"\n"+value;
        call("z45","b",new String[]{"java.lang.String","r53","long","long","nq1","sz4","long","n25","long","int","boolean","int","int","s55","lu1","int","int","int"},null,
            content,width,color,0L,null,null,0L,null,0L,0,true,Integer.MAX_VALUE,1,field("mk2","h"),composer,0,0,0x1fff8);
    }
    private static void input(Session s,String key,String label,String value,Object composer,Action edit) throws Exception {
        text(label,null,composer);
        Object change=function("ws1",args->{if(current==s && !s.busy){edit.run(args);changed(s);}return unit();});
        Object width=call("oo4","c",new String[]{"r53","float"},null,field("o53","b"),1f);
        call("ak2","f",new String[]{"java.lang.String","ws1","java.lang.String","r53","int","boolean","s55","lu1","int","int"},null,
            value,change,"",width,key.equals("keepalive")?3:1,false,null,composer,0,96);
    }
    private static void action(String label,Object composer,Action action) throws Exception {
        Object click=function("us1",action);
        Object content=function("lt1",args->{text(label,null,args[1]);return unit();});
        Object lambda=call("ss","Q",new String[]{"int","gt1","lu1"},null,label.hashCode(),content,composer);
        call("ak2","d",new String[]{"us1","zn0","lu1","int","int"},null,click,lambda,composer,48,0);
    }
    private static void fields(Session s,Selection selection,Object composer) throws Exception {
        read(s);
        if(selection.list!=null){
            WifiConfigListDraft list=selection.list;
            for(int n=0;n<list.entries.size();n++){
                final int index=n;
                input(s,list.smsc?"smsc":"epdg",selection.row+" "+(n+1),list.entries.get(n),composer,args->{if(index<list.entries.size()){list.entries.set(index,(String)args[0]);selection.error="";}return unit();});
                if(list.smsc)action(list.selected==n?"● 当前使用":"○ 使用此号码",composer,args->{if(current==s && s.selection==selection && !s.busy && index<list.entries.size()){list.choose(index);selection.error="";changed(s);}return unit();});
                action("删除",composer,args->{if(current==s && s.selection==selection && !s.busy && index<list.entries.size()){list.remove(index);selection.error="";changed(s);}return unit();});
            }
            action("添加",composer,args->{if(current==s && s.selection==selection && !s.busy){list.add();selection.error="";changed(s);}return unit();});
            return;
        }
        for(String key:selection.values.keySet()){
            WifiConfigValues.Field f=WifiConfigValues.field(key);
            input(s,key,f.label,selection.values.get(key),composer,args->{selection.values.put(key,(String)args[0]);selection.error="";return unit();});
        }
    }
}
