package cc.forserein.simhub.internal;

import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.regex.Pattern;

/** Associates one user's chat view with a physical card and a network-registered public line. */
public final class RcsChatBinding {
    private static final Pattern E164 = Pattern.compile("\\+[1-9][0-9]{1,14}");
    private static final Pattern GLOBAL_INPUT = Pattern.compile("(?:\\+|00)[0-9() .-]+");
    private static final Pattern SIP_HOST = Pattern.compile(
            "(?:[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?|\\[[0-9A-Fa-f:.]+\\])(?::[0-9]{1,5})?");
    private static final String NO_LINE = "未能核对当前卡的系统线路或 IMS 注册号码";
    private static final String CARD_CHANGED = "卡片或 IMS 连接已更换，请重新打开 RCS 会话";

    public final String peer;
    public final String cardKey;
    public final String cardLabel;
    private final String iccid;
    private final Object engine;
    private final Set<String> initialLines;
    private final int systemSubId;
    private final Object localReader;

    // The native o82 engine uses object identity. Each registered x72 also needs an identity check:
    // x72 implements structural equality, and two distinct registrations may contain identical URIs.
    private static final WeakHashMap<Object, Proof> registrations = new WeakHashMap<Object, Proof>();

    private static final class Proof {
        final WeakReference<Object> registration;
        final Set<String> lines;
        final long observedAt;
        final long wallTime;
        final long lifetimeMs;
        Proof(Object registration, Set<String> lines, int seconds) {
            this.registration = new WeakReference<Object>(registration);
            this.lines = Collections.unmodifiableSet(lines);
            this.observedAt = System.nanoTime();
            this.wallTime = System.currentTimeMillis();
            this.lifetimeMs = seconds * 1000L;
        }
        boolean active(Object current) {
            long wall = System.currentTimeMillis() - wallTime;
            long elapsedNs = System.nanoTime() - observedAt;
            return current != null && registration.get() == current
                    && wall >= 0 && wall < lifetimeMs
                    && elapsedNs >= 0 && elapsedNs < lifetimeMs * 1000000L;
        }
    }

    /** Called before native code publishes a successful REGISTER. The list precedes its local IMPU fallback. */
    public static synchronized void remember(Object engine, Object registration, List<?> networkUris, int expires) {
        registrations.remove(engine);
        if (engine == null || registration == null || expires <= 0 || networkUris == null) return;
        Set<String> numbers = new HashSet<String>();
        for (Object value : networkUris) {
            if (value instanceof String) {
                String line = associatedNumber((String) value);
                if (line != null) numbers.add(line);
            }
        }
        if (!numbers.isEmpty()) registrations.put(engine, new Proof(registration, numbers, expires));
    }

    public static synchronized void clear(Object engine) {
        registrations.remove(engine);
    }

    /** Stable preference key from the selected physical card, independent of its RCS availability. */
    public static String lineKey(Object gl5) {
        if (gl5 == null) throw new IllegalStateException("请先读取卡片");
        try {
            String current = iccid(WifiConfigModel.get(gl5, "e"));
            requireActiveCard(current);
            return key(current);
        } catch (ReflectiveOperationException error) {
            throw new IllegalStateException("无法核对当前卡片", error);
        }
    }

    private static String key(String iccid) {
        return WifiConfigValues.digest("RCS\n" + iccid);
    }

    /** Capture the card the user opened, even if the UI's native state object has since been replaced. */
    public static RcsChatBinding capture(Object gl5, String destination) {
        String normalized = peerNumber(destination);
        if (gl5 == null) throw new IllegalStateException("请先读取卡片");
        try {
            String iccid = iccid(WifiConfigModel.get(gl5, "e"));
            requireActiveCard(iccid);
            Object engine = currentEngine();
            Proof proof = registeredProof(engine, iccid);
            if (proof != null) return new RcsChatBinding(iccid, engine, normalized, proof.lines, -1, null);
            Object reader = localReader();
            if (reader == null) throw new IllegalStateException(NO_LINE);
            RcsSystemLine.Match system = RcsSystemLine.query(iccid);
            requireActiveCard(iccid);
            if (system == null || reader != localReader()) throw new IllegalStateException(NO_LINE);
            return new RcsChatBinding(iccid, null, normalized, Collections.singleton(system.number), system.subId, reader);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException(NO_LINE, e);
        }
    }

    private RcsChatBinding(String iccid, Object engine, String peer, Set<String> lines, int systemSubId, Object localReader) {
        this.iccid = iccid;
        this.engine = engine;
        this.peer = peer;
        this.initialLines = lines;
        this.systemSubId = systemSubId;
        this.localReader = localReader;
        this.cardKey = key(iccid);
        this.cardLabel = "卡片 ···· " + iccid.substring(iccid.length() - 4);
    }

    public void validateCurrent() {
        Set<String> current = checkedLines();
        if (Collections.disjoint(initialLines, current)) throw new IllegalStateException(CARD_CHANGED);
    }

    /** The transport must also confirm that this same TAPI service is registered. */
    public void validateProvider(String myContactId) {
        Set<String> current = checkedLines();
        String self = myContactId == null ? "" : myContactId;
        if (!E164.matcher(self).matches() || !initialLines.contains(self) || !current.contains(self)) {
            throw new IllegalStateException("RCS 服务的号码与当前卡已注册的号码不匹配");
        }
    }

    private Set<String> checkedLines() {
        try {
            requireActiveCard(iccid);
            if (systemSubId >= 0) {
                if (localReader != localReader()) throw new IllegalStateException(CARD_CHANGED);
                RcsSystemLine.Match current = RcsSystemLine.query(iccid);
                requireActiveCard(iccid);
                if (localReader != localReader() || current == null || current.subId != systemSubId || !initialLines.contains(current.number)) {
                    throw new IllegalStateException(CARD_CHANGED);
                }
                return initialLines;
            }
            if (currentEngine() != engine) throw new IllegalStateException(CARD_CHANGED);
            Proof proof = registeredProof(engine, iccid);
            if (proof == null) throw new IllegalStateException(NO_LINE);
            return proof.lines;
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException(CARD_CHANGED, e);
        }
    }

    private static Object currentEngine() throws ReflectiveOperationException {
        return Class.forName("zl5").getField("n").get(null);
    }

    /** qf3 is this APK's concrete android.se.omapi.Reader transport; external devices use other types. */
    private static Object localReader() throws ReflectiveOperationException {
        Object current = Class.forName("zl5").getField("j").get(null);
        return current != null && "qf3".equals(current.getClass().getName()) ? current : null;
    }

    private static String iccid(Object card) throws ReflectiveOperationException {
        if (card != null) {
            Object value = WifiConfigModel.get(card, "b");
            if (value instanceof String && ((String) value).matches("[0-9]{19,20}")
                    && !((String) value).matches("0+")) return (String) value;
        }
        throw new IllegalStateException("请先读取含完整 ICCID 的卡片");
    }

    private static void requireActiveCard(String expectedIccid) throws ReflectiveOperationException {
        Object state = WifiConfigRuntime.state();
        if (state == null || !expectedIccid.equals(iccid(WifiConfigModel.get(state, "e"))))
            throw new IllegalStateException(CARD_CHANGED);
    }

    private static synchronized Proof registeredProof(Object engine, String expectedIccid)
            throws ReflectiveOperationException {
        if (engine == null || currentEngine() != engine) return null;
        Object connected = WifiConfigModel.get(engine, "c");
        if (connected == null || !expectedIccid.equals(WifiConfigModel.get(connected, "b"))) return null;
        Object registration = WifiConfigModel.get(engine, "s");
        Proof proof = registrations.get(engine);
        return proof != null && proof.active(registration) ? proof : null;
    }

    private static String peerNumber(String value) {
        String number = value == null ? "" : DialingSupport.ascii(value.trim());
        if (number.regionMatches(true, 0, "tel:", 0, 4)) number = number.substring(4);
        if (GLOBAL_INPUT.matcher(number).matches() && !number.replace(" ", "").contains("(0)")) {
            number = DialingSupport.normalize(number);
            if (number.startsWith("00")) number = "+" + number.substring(2);
            if (E164.matcher(number).matches()) return number;
        }
        throw new IllegalArgumentException("请输入含国家区号的完整国际号码，例如 +441632960123");
    }

    /** Use only a complete international public identity from the native REGISTER response. */
    private static String associatedNumber(String uri) {
        if (uri.regionMatches(true, 0, "tel:", 0, 4)) {
            String number = uri.substring(4);
            return E164.matcher(number).matches() ? number : null;
        }
        int prefix = uri.regionMatches(true, 0, "sip:", 0, 4) ? 4
                : uri.regionMatches(true, 0, "sips:", 0, 5) ? 5 : 0;
        int at = uri.indexOf('@');
        if (prefix == 0 || at <= prefix || at != uri.lastIndexOf('@')) return null;
        String number = uri.substring(prefix, at);
        if (!E164.matcher(number).matches()) return null;
        String host = uri.substring(at + 1);
        if (host.toLowerCase(java.util.Locale.ROOT).endsWith(";user=phone")) {
            host = host.substring(0, host.length() - ";user=phone".length());
        }
        return SIP_HOST.matcher(host).matches() ? number : null;
    }
}
