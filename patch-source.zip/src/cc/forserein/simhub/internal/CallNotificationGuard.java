package cc.forserein.simhub.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.lang.reflect.InvocationTargetException;
import java.util.WeakHashMap;

/** Bind asynchronous notification/permission actions to the call that created them. */
public final class CallNotificationGuard {
    public static final String ID = "simhub.call.id";
    public static final String TOKEN = "simhub.call.token";
    public static final String ANSWER = "cc.forserein.simhub.call.ANSWER";
    public static final String DECLINE = "cc.forserein.simhub.call.DECLINE";
    public static final String HANGUP = "cc.forserein.simhub.call.HANGUP";
    private static final String SHOW = "cc.forserein.simhub.call.SHOW";
    private static final ThreadLocal<Action> selectedAction = new ThreadLocal<Action>();
    private static final WeakHashMap<Object,Action> pendingAnswers = new WeakHashMap<Object,Action>();

    private CallNotificationGuard() {}

    private static final class Action {
        final String id, token, action;
        Action(String id,String token,String action){this.id=id;this.token=token;this.action=action;}
        boolean valid(){return id!=null&&!id.isEmpty()&&token!=null&&!token.isEmpty();}
        boolean allows(Object call){
            if(!valid()||call==null)return false;
            try {
                if(!id.equals(field(call,"a"))||!token.equals(field(call,"j")))return false;
                Object state=field(call,"e");
                if(state==null)return false;
                String kind=state.getClass().getName();
                if(ANSWER.equals(action)||DECLINE.equals(action))
                    return Boolean.TRUE.equals(field(call,"d"))&&"z00".equals(kind);
                return HANGUP.equals(action)&&("x00".equals(kind)||"w00".equals(kind)
                        ||"a10".equals(kind)||"v00".equals(kind));
            } catch(Exception ignored){return false;}
        }
    }

    private static Object field(Object object,String name)throws Exception {
        return object.getClass().getField(name).get(object);
    }
    private static Action fromCall(Object call,String action){
        if(call==null)return null;
        try {
            Action result=new Action((String)field(call,"a"),(String)field(call,"j"),action);
            return result.valid()?result:null;
        } catch(Exception ignored){return null;}
    }
    private static Action fromIntent(Intent intent){
        if(intent==null)return null;
        Action result=new Action(intent.getStringExtra(ID),intent.getStringExtra(TOKEN),intent.getAction());
        return result.valid()?result:null;
    }
    private static Object currentCall(){
        try{return Class.forName("k10").getMethod("j").invoke(null);}
        catch(Exception ignored){return null;}
    }

    /** URI participates in PendingIntent identity; extras alone do not. */
    public static void bind(Intent intent,Object call){
        if(intent==null)return;
        intent.removeExtra(ID);intent.removeExtra(TOKEN);intent.setData(null);
        Action action=fromCall(call,intent.getAction());
        if(action==null)return;
        intent.putExtra(ID,action.id);intent.putExtra(TOKEN,action.token);
        intent.setData(new Uri.Builder().scheme("simhub-call").authority("notification")
                .appendPath(action.token).appendQueryParameter("id",action.id)
                .appendQueryParameter("action",action.action==null?SHOW:action.action).build());
    }

    /** Uses the rendered call snapshot, never a potentially newer global call. */
    public static PendingIntent activityIntent(int requestCode,Context context,String action,Object call){
        try {
            Intent intent=new Intent(context,Class.forName("cc.forserein.simhub.ui.call.CallActivity"));
            intent.setAction(action==null?SHOW:action).addFlags(0x30000000);
            bind(intent,call);
            return PendingIntent.getActivity(context,requestCode,intent,0x0c000000);
        } catch(ClassNotFoundException error){throw new IllegalStateException(error);}
    }

    public static boolean allows(Intent intent,Object call){
        Action action=fromIntent(intent);
        return action!=null&&action.allows(call);
    }

    private static void invoke(Object target,String owner,String method){
        try {
            Class<?> type=target==null?Class.forName(owner):target.getClass();
            type.getMethod(method).invoke(target);
        } catch(InvocationTargetException error){
            Throwable cause=error.getCause();
            if(cause instanceof RuntimeException)throw (RuntimeException)cause;
            if(cause instanceof Error)throw (Error)cause;
            throw new IllegalStateException(cause);
        } catch(Exception error){throw new IllegalStateException(error);}
    }
    private static void execute(Action action){
        if(action==null||!action.allows(currentCall()))return;
        String method=ANSWER.equals(action.action)?"b":DECLINE.equals(action.action)?"e":
                HANGUP.equals(action.action)?"l":null;
        if(method==null)return;
        Action previous=selectedAction.get();selectedAction.set(action);
        try {invoke(null,"k10",method);}
        finally {if(previous==null)selectedAction.remove();else selectedAction.set(previous);}
    }

    /** Broadcast path. Ringing stops only after the final native call selection matches. */
    public static void dispatch(Intent intent){
        Action action=fromIntent(intent);
        if(action!=null&&(DECLINE.equals(action.action)||HANGUP.equals(action.action)))execute(action);
    }

    /** Hook immediately after native k10.b/h select the object captured by d10. */
    public static boolean allowSelected(Object call){
        Action action=selectedAction.get();
        if(action==null)return true; // System Telecom/headset paths retain native behavior.
        if(!action.allows(call))return false;
        if(ANSWER.equals(action.action)||DECLINE.equals(action.action))invoke(null,"w10","b");
        return true;
    }

    public static void answerFromIntent(Object activity,Intent intent){
        Action action=fromIntent(intent);
        if(activity==null||action==null||!ANSWER.equals(action.action)||!action.allows(currentCall()))return;
        Action previous=selectedAction.get();selectedAction.set(action);
        try {invoke(activity,null,"i");}
        finally {if(previous==null)selectedAction.remove();else selectedAction.set(previous);}
    }

    /** Called after the native activity selects an incoming call, before audio/permission work. */
    public static boolean prepareAnswer(Object activity,Object call){
        if(activity==null)return false;
        // One ActivityResult permission request is in flight per activity. A
        // second call must not replace the identity that owns its callback.
        try {if(activity.getClass().getField("o0").getBoolean(activity))return false;}
        catch(Exception ignored){return false;}
        Action action=fromCall(call,ANSWER),expected=selectedAction.get();
        synchronized(pendingAnswers){pendingAnswers.remove(activity);}
        if(action==null||!action.allows(call)||(expected!=null&&!expected.allows(call)))return false;
        synchronized(pendingAnswers){pendingAnswers.put(activity,action);}
        return true;
    }
    private static Action takeAnswer(Object activity){
        synchronized(pendingAnswers){return pendingAnswers.remove(activity);}
    }
    private static boolean clearWaiting(Object activity){
        try {
            boolean waiting=activity.getClass().getField("o0").getBoolean(activity);
            activity.getClass().getField("o0").setBoolean(activity,false);
            return waiting;
        } catch(Exception ignored){return false;}
    }
    public static void answerPrepared(Object activity){
        Action action=takeAnswer(activity);clearWaiting(activity);execute(action);
    }
    public static void resumePermission(Object activity,Boolean granted){
        Action action=takeAnswer(activity);
        boolean waiting=clearWaiting(activity);
        if(waiting&&Boolean.TRUE.equals(granted))execute(action);
    }
}
