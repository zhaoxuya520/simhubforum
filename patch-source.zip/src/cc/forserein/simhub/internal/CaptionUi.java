package cc.forserein.simhub.internal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.text.Editable;
import android.text.InputType;
import android.text.Layout;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Embedded views share preferences and current-call captions through CallCaptions. */
public final class CaptionUi {
    private CaptionUi() {}
    private enum Placement { DIALER, SETTINGS, CALL }

    public static View dialerView(Context context) { return new Panel(context, Placement.DIALER); }
    public static View settingsView(Context context) { return new Panel(context, Placement.SETTINGS); }
    public static View callView(Context context) { return new Panel(context, Placement.CALL); }

    private static int dp(Context context, float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    private static boolean dark(Context context) {
        int mode = context.getResources().getConfiguration().uiMode;
        return (mode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    private static int ink(Context c) { return dark(c) ? 0xffeef3ff : 0xff142239; }
    private static int muted(Context c) { return dark(c) ? 0xffb4bed0 : 0xff526178; }
    private static int blue(Context c) { return dark(c) ? 0xff93bcff : 0xff1859a8; }
    private static int outline(Context c) { return dark(c) ? 0xff3b485c : 0xffdae3ef; }

    private static GradientDrawable surface(Context c, int fill, int edge, float radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(c, radius));
        if (edge != 0) drawable.setStroke(dp(c, 1), edge);
        return drawable;
    }

    private static void padding(View v, int start, int top, int end, int bottom) {
        Context c = v.getContext();
        v.setPaddingRelative(dp(c,start),dp(c,top),dp(c,end),dp(c,bottom));
    }

    private static TextView text(Context c, String value, float size, int color, boolean medium) {
        TextView t = new TextView(c);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        t.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        t.setTextDirection(TEXT_DIRECTION_FIRST_STRONG);
        return t;
    }

    private static final int TEXT_DIRECTION_FIRST_STRONG = View.TEXT_DIRECTION_FIRST_STRONG;

    private static LinearLayout row(Context c) {
        LinearLayout layout = new LinearLayout(c);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private static LinearLayout.LayoutParams stretch() {
        return new LinearLayout.LayoutParams(0, -2, 1);
    }

    private static void action(View v, Runnable callback) {
        v.setClickable(true);
        v.setFocusable(true);
        v.setOnClickListener(view -> callback.run());
        v.setForeground(new RippleDrawable(ColorStateList.valueOf(0x226faaff),null,
                surface(v.getContext(),Color.WHITE,0,12)));
    }

    private static String language(String code) {
        if ("zh".equalsIgnoreCase(code) || "zh-Hans".equalsIgnoreCase(code) ||
                "zh-CN".equalsIgnoreCase(code)) return "简体中文";
        if ("zh-Hant".equalsIgnoreCase(code) || "zh-TW".equalsIgnoreCase(code)) return "繁體中文";
        Locale locale = Locale.forLanguageTag(code);
        String name = locale.getDisplayName(Locale.SIMPLIFIED_CHINESE);
        return name.isEmpty() ? code : name;
    }

    /** A speech bubble with two caption lines, painted identically across system font packs. */
    private static final class Mark extends View {
        final Paint pen = new Paint(Paint.ANTI_ALIAS_FLAG);
        Mark(Context context) {
            super(context);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float unit = Math.min(getWidth(),getHeight()) / 24f;
            canvas.save();
            canvas.translate((getWidth()-24*unit)*.5f,(getHeight()-24*unit)*.5f);
            canvas.scale(unit,unit);
            pen.setStrokeWidth(1.65f);
            pen.setStrokeCap(Paint.Cap.ROUND);
            pen.setColor(blue(getContext()));
            pen.setStyle(Paint.Style.STROKE);
            canvas.drawRoundRect(new RectF(2.4f,4.3f,21.6f,19.7f),4,4,pen);
            canvas.drawLine(6.5f,10.2f,17.3f,10.2f,pen);
            canvas.drawLine(6.5f,14.3f,13.3f,14.3f,pen);
            canvas.restore();
        }
    }

    private static final class Panel extends LinearLayout {
        final Placement placement;
        final TextView label;
        TextView target;
        Switch toggle;
        TextView sentence, prior, indicator;
        ScrollView lines;
        LinearLayout controls, reading, history;
        FrameLayout viewport;
        final boolean compact;
        private boolean painting;
        private boolean enabled;
        private String activeTarget = "";
        private CallCaptions.Display displayed;

        Panel(Context context, Placement place) {
            super(context);
            placement = place;
            compact = context.getResources().getConfiguration().screenHeightDp < 500;
            setOrientation(VERTICAL);
            setClipToPadding(false);
            controls = row(context);
            Mark mark = new Mark(context);
            int icon = dp(context, place==Placement.CALL ? 19 : 22);
            controls.addView(mark,new LayoutParams(icon,icon));
            label = text(context,place==Placement.CALL?"通话字幕":"通话翻译",
                    place==Placement.CALL ? 13 : 16,ink(context),true);
            padding(label,8,0,4,0);
            controls.addView(label,stretch());
            if (place==Placement.CALL) setupCall(); else setupControl();
            refresh(true);
        }

        private void setupControl() {
            Context c = getContext();
            controls.setMinimumHeight(dp(c,48));
            if (placement==Placement.DIALER) {
                padding(controls,13,0,8,0);
                controls.setBackground(surface(c,dark(c)?0xff222f42:0xfff0f5fc,0,14));
                toggle = new Switch(c);
                toggle.setMinHeight(dp(c,48));
                toggle.setMinWidth(dp(c,48));
                toggle.setGravity(Gravity.CENTER);
                toggle.setContentDescription("通话翻译");
                toggle.setOnCheckedChangeListener((button,on) -> {
                    if (painting) return;
                    if (on && !CallCaptions.hasKey(c)) {
                        // The switch reflects persisted state while setup is open.
                        refresh(true);
                        configure(true);
                    } else {
                        try {
                            CallCaptions.setEnabled(c,on);
                            refresh(true);
                            if (on) pickLanguage(c,CallCaptions.target(c),this::choose);
                        } catch (RuntimeException error) { failure(c,error); refresh(true); }
                    }
                });
                target = text(c,"",14,blue(c),true);
                target.setMinHeight(dp(c,48));
                target.setMaxLines(1);
                target.setEllipsize(TextUtils.TruncateAt.END);
                target.setMaxWidth(dp(c,116));
                padding(target,6,0,6,0);
                action(target,()->pickLanguage(c,CallCaptions.target(c),this::choose));
                controls.addView(target);
                controls.addView(toggle);
                action(label,()->configure(false));
                label.setContentDescription("通话翻译设置");
            } else {
                padding(controls,16,0,14,0);
                target = text(c,"",14,muted(c),false);
                target.setMaxWidth(dp(c,150));
                target.setSingleLine();
                target.setEllipsize(TextUtils.TruncateAt.END);
                controls.addView(target);
                action(controls,()->configure(false));
            }
            addView(controls,new LayoutParams(-1,-2));
        }

        private void setupCall() {
            Context c = getContext();
            padding(this,14,compact?0:2,14,compact?5:9);
            setBackground(surface(c,dark(c)?0xff1c2a3e:0xfff2f6fc,outline(c),16));
            controls.setMinimumHeight(dp(c,40));
            target = text(c,"",13,blue(c),true);
            target.setGravity(Gravity.CENTER);
            target.setMinHeight(dp(c,48));
            target.setMaxWidth(dp(c,140));
            target.setSingleLine();
            target.setEllipsize(TextUtils.TruncateAt.END);
            padding(target,6,0,6,0);
            action(target,()->pickLanguage(c,CallCaptions.target(c),this::choose));
            controls.addView(target);
            TextView options = text(c,"⋯",20,muted(c),true);
            options.setGravity(Gravity.CENTER);
            options.setContentDescription("通话字幕设置");
            options.setMinWidth(dp(c,48));
            options.setMinHeight(dp(c,48));
            action(options,()->configure(false));
            controls.addView(options);
            addView(controls,new LayoutParams(-1,-2));
            reading = new LinearLayout(c);
            reading.setOrientation(VERTICAL);
            indicator = text(c,"",14,muted(c),false);
            indicator.setIncludeFontPadding(true);
            indicator.setAccessibilityLiveRegion(ACCESSIBILITY_LIVE_REGION_POLITE);
            reading.addView(indicator,new LayoutParams(-1,-2));

            sentence = text(c,"",compact?18:20,ink(c),false);
            sentence.setIncludeFontPadding(true);
            sentence.setGravity(Gravity.TOP | Gravity.START);
            sentence.setTextAlignment(TEXT_ALIGNMENT_TEXT_START);
            sentence.setLineSpacing(dp(c,2),1);
            sentence.setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY);
            sentence.setAccessibilityLiveRegion(ACCESSIBILITY_LIVE_REGION_POLITE);
            lines = new CaptionScroll(c,sentence);
            lines.setFillViewport(false);
            lines.setNestedScrollingEnabled(true);
            lines.setOverScrollMode(OVER_SCROLL_IF_CONTENT_SCROLLS);
            lines.addView(sentence,new ScrollView.LayoutParams(-1,-2));
            viewport = new FrameLayout(c);
            viewport.addView(lines,new FrameLayout.LayoutParams(-1,-1,Gravity.TOP));
            reading.addView(viewport,new LayoutParams(-1,0,1));

            history = row(c);
            padding(history,0,6,0,0);
            TextView previousLabel = text(c,"上一句",12,muted(c),true);
            padding(previousLabel,0,0,8,0);
            history.addView(previousLabel);
            prior = text(c,"",13,muted(c),false);
            prior.setIncludeFontPadding(true);
            prior.setSingleLine();
            prior.setEllipsize(TextUtils.TruncateAt.END);
            prior.setTextAlignment(TEXT_ALIGNMENT_TEXT_START);
            history.addView(prior,stretch());
            reading.addView(history,new LayoutParams(-1,-2));

            // Reserve the reading space across utterances. Use font metrics so
            // large system fonts retain complete baselines and room for accents.
            int mainLines = compact ? 2 : 3;
            Paint.FontMetricsInt font = sentence.getPaint().getFontMetricsInt();
            // Fallback CJK and Arabic fonts can have taller glyphs than the
            // Latin text paint. The scroll viewport below uses actual line boxes.
            int lineBudget = Math.max(sentence.getLineHeight(),
                    (int)Math.ceil(sentence.getTextSize()*1.45f)+dp(c,2));
            int bodyHeight = Math.max(lineBudget,font.bottom-font.top) + (mainLines-1)*lineBudget;
            if (!compact) {
                Paint.FontMetricsInt note = prior.getPaint().getFontMetricsInt();
                bodyHeight += note.bottom-note.top + dp(c,6);
            }
            reading.setMinimumHeight(bodyHeight);
            addView(reading,new LayoutParams(-1,bodyHeight));
        }

        private void choose(String code) {
            try { CallCaptions.setTarget(getContext(),code); refresh(true); }
            catch(RuntimeException error) { failure(getContext(),error); }
        }

        private void configure(boolean enableOnSave) {
            showSettings(this,enableOnSave);
        }

        private void refresh(boolean force) {
            Context c = getContext();
            boolean on = CallCaptions.enabled(c);
            String code = CallCaptions.target(c);
            if (force || enabled!=on || !code.equals(activeTarget)) {
                painting = true;
                if (toggle!=null) toggle.setChecked(on);
                if (placement==Placement.SETTINGS) {
                    target.setText((on?language(code):"已关闭")+"  ›");
                } else {
                    target.setText(language(code)+"  ▾");
                    target.setContentDescription("字幕语言，"+language(code));
                    if (placement==Placement.DIALER) target.setVisibility(on?VISIBLE:GONE);
                }
                if (placement==Placement.CALL && enabled!=on) requestLayout();
                if (placement==Placement.CALL && !code.equals(activeTarget)) {
                    Locale locale = Locale.forLanguageTag(code);
                    int direction = TextUtils.getLayoutDirectionFromLocale(locale)==LAYOUT_DIRECTION_RTL
                            ? TEXT_DIRECTION_FIRST_STRONG_RTL : TEXT_DIRECTION_FIRST_STRONG_LTR;
                    sentence.setTextLocale(locale);
                    sentence.setTextDirection(direction);
                    prior.setTextLocale(locale);
                    prior.setTextDirection(direction);
                }
                enabled=on; activeTarget=code; painting=false;
                if (placement==Placement.CALL) {
                    setImportantForAccessibility(on?IMPORTANT_FOR_ACCESSIBILITY_AUTO:IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
                    controls.setVisibility(on?VISIBLE:GONE);
                    reading.setVisibility(on?VISIBLE:GONE);
                }
            }
            if (placement!=Placement.CALL) return;
            CallCaptions.Display next = on ? CallCaptions.display() : null;
            if (next==displayed && !force) return;
            boolean newUtterance = next!=null && (displayed==null || next.utterance!=displayed.utterance);
            displayed = next;
            String now = next==null ? "" : next.current;
            String last = next==null ? "" : next.previous;
            String status = next==null ? "" : next.status;
            String note = on && now.isEmpty() && status.isEmpty() ? "等待对方说话…" : status;
            if (!TextUtils.equals(sentence.getText(),now)) sentence.setText(now);
            if (!TextUtils.equals(prior.getText(),last)) prior.setText(last);
            if (!TextUtils.equals(indicator.getText(),note)) {
                indicator.setText(note);
                indicator.setTextColor(now.isEmpty() && "等待对方说话…".equals(note)
                        ? muted(c) : dark(c)?0xffffcb8e:0xff875015);
            }
            lines.setVisibility(now.isEmpty()?GONE:VISIBLE);
            viewport.setVisibility(now.isEmpty()?GONE:VISIBLE);
            history.setVisibility(compact || !note.isEmpty() || now.isEmpty()?GONE:
                    last.isEmpty()?INVISIBLE:VISIBLE);
            indicator.setVisibility(note.isEmpty()?GONE:VISIBLE);
            if (newUtterance) {
                lines.scrollTo(0,0);
                if (lines.isAttachedToWindow()) lines.fling(0);
            }
        }

        private final Runnable tick = new Runnable() {
            @Override public void run() {
                if (!isAttachedToWindow() || getWindowVisibility()!=VISIBLE) return;
                refresh(false);
                postDelayed(this,placement==Placement.CALL && enabled ? 350 : 1000);
            }
        };
        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            removeCallbacks(tick); post(tick);
        }
        @Override protected void onDetachedFromWindow() {
            removeCallbacks(tick); super.onDetachedFromWindow();
        }
        @Override protected void onWindowVisibilityChanged(int visibility) {
            super.onWindowVisibilityChanged(visibility);
            if (tick==null) return;
            removeCallbacks(tick);
            if (visibility==VISIBLE && isAttachedToWindow()) post(tick);
        }
        @Override protected void onMeasure(int width,int height) {
            if (placement==Placement.CALL && !enabled) {
                setMeasuredDimension(MeasureSpec.getSize(width),0);
                return;
            }
            if (placement==Placement.CALL && reading!=null) {
                // A wrapped service error may need more than the reserved lines.
                // Measure it at the real sheet width, leaving room for the first
                // translated line even at large accessibility scales.
                int required = reading.getMinimumHeight();
                if (indicator.getVisibility()==VISIBLE && MeasureSpec.getMode(width)!=MeasureSpec.UNSPECIFIED) {
                    int available = Math.max(0,MeasureSpec.getSize(width)-getPaddingLeft()-getPaddingRight());
                    indicator.measure(MeasureSpec.makeMeasureSpec(available,MeasureSpec.EXACTLY),
                            MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED));
                    int firstLine = lines.getVisibility()==VISIBLE ? sentence.getLineHeight()+dp(getContext(),5) : 0;
                    required = Math.max(required,indicator.getMeasuredHeight()+firstLine);
                }
                reading.getLayoutParams().height = required;
            }
            super.onMeasure(width,height);
        }
    }

    /** The parent reserves a stable rectangle. Lay out only complete text lines
     * at the beginning and end; leave residual pixels outside the scroller. */
    private static final class CaptionScroll extends ScrollView {
        private final TextView body;
        private boolean atEnd;
        private float previousTouchY;

        CaptionScroll(Context context, TextView body) {
            super(context);
            this.body = body;
        }

        @Override public boolean dispatchTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            float y = event.getRawY();
            if (action==MotionEvent.ACTION_DOWN) {
                // Decline the whole gesture when this sentence already fits.
                // The enclosing Compose call page can then scroll from this area.
                if (!canScrollVertically(-1) && !canScrollVertically(1)) return false;
                previousTouchY = y;
            }
            boolean handled = super.dispatchTouchEvent(event);
            if (action==MotionEvent.ACTION_MOVE) {
                float delta = previousTouchY-y;
                if (delta!=0 && !canScrollVertically(delta>0 ? 1 : -1) && getParent()!=null) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }
                previousTouchY = y;
            }
            return handled;
        }

        @Override protected void onMeasure(int width, int height) {
            super.onMeasure(width,height);
            Layout layout = body.getLayout();
            int box = getMeasuredHeight();
            if (layout==null || body.getMeasuredHeight()<=box || layout.getLineCount()<2) return;
            int padding = body.getTotalPaddingTop();
            int first, last;
            if (atEnd) {
                int minimumTop = body.getMeasuredHeight()-box-padding;
                first = layout.getLineForVertical(Math.max(0,minimumTop));
                if (layout.getLineTop(first)<minimumTop) first++;
                if (first>=layout.getLineCount()) return;
                last = body.getMeasuredHeight() - padding;
            } else {
                first = 0;
                int lastLine = layout.getLineForVertical(Math.max(0,box-padding-1));
                if (padding+layout.getLineBottom(lastLine)>box) lastLine--;
                if (lastLine<0) return;
                last = layout.getLineBottom(lastLine) + padding;
            }
            int aligned = last-layout.getLineTop(first);
            if (aligned>0 && aligned<box) setMeasuredDimension(getMeasuredWidth(),aligned);
        }

        @Override protected void onScrollChanged(int x,int y,int oldX,int oldY) {
            super.onScrollChanged(x,y,oldX,oldY);
            boolean end = body!=null && y>0 && y+getHeight()>=body.getHeight()-1;
            if (atEnd!=end) {
                atEnd=end;
                requestLayout();
            }
        }

        @Override protected void onLayout(boolean changed,int left,int top,int right,int bottom) {
            boolean keepEnd = atEnd;
            super.onLayout(changed,left,top,right,bottom);
            if (keepEnd) scrollTo(0,body.getHeight());
        }
    }

    private static void failure(Context context,RuntimeException error) {
        String message=error.getMessage();
        Toast.makeText(context,message==null?"无法保存通话翻译设置":message,Toast.LENGTH_LONG).show();
    }

    private static AlertDialog.Builder dialog(Context c) {
        return new AlertDialog.Builder(c,dark(c)?android.R.style.Theme_Material_Dialog_Alert:
                android.R.style.Theme_Material_Light_Dialog_Alert);
    }

    private interface Selected { void accept(String code); }

    private static void pickLanguage(Context c, String selected, Selected callback) {
        List<String> all = new ArrayList<>(Arrays.asList(CallCaptions.targetCodes()));
        all.sort(Comparator.comparing(CaptionUi::language,java.text.Collator.getInstance(Locale.SIMPLIFIED_CHINESE)));
        LinearLayout container = new LinearLayout(c);
        container.setOrientation(LinearLayout.VERTICAL);
        padding(container,18,6,18,0);
        EditText filter = new EditText(c);
        filter.setSingleLine();
        filter.setHint("搜索语言");
        filter.setContentDescription("搜索字幕语言");
        filter.setTextColor(ink(c));
        filter.setTextSize(16);
        container.addView(filter,new LinearLayout.LayoutParams(-1,-2));
        ListView list = new ListView(c);
        list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        list.setDividerHeight(0);
        container.addView(list,new LinearLayout.LayoutParams(-1,dp(c,Math.min(330,Math.max(112,
                c.getResources().getConfiguration().screenHeightDp/2)))));
        List<String> visible = new ArrayList<>();
        AlertDialog popup = dialog(c).setTitle("字幕语言").setView(container).setNegativeButton("取消",null).create();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(popup.getContext(),
                android.R.layout.simple_list_item_single_choice,new ArrayList<>());
        list.setAdapter(adapter);
        Runnable applyFilter = () -> {
            String query=filter.getText().toString().trim().toLowerCase(Locale.ROOT);
            visible.clear();
            adapter.setNotifyOnChange(false);
            adapter.clear();
            for(String code:all) {
                Locale loc=Locale.forLanguageTag(code);
                String search=language(code)+" "+code+" "+loc.getDisplayName(Locale.ENGLISH)+" "+loc.getDisplayName(loc);
                if(search.toLowerCase(Locale.ROOT).contains(query)) {
                    visible.add(code);
                    adapter.add(language(code));
                }
            }
            adapter.notifyDataSetChanged();
            list.clearChoices();
            int index=visible.indexOf(selected);
            if(index>=0) list.setItemChecked(index,true);
        };
        applyFilter.run();
        filter.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            public void onTextChanged(CharSequence s,int start,int before,int count) { applyFilter.run(); }
            public void afterTextChanged(Editable editable) {}
        });
        list.setOnItemClickListener((parent,view,position,id)->{
            if(position<0 || position>=visible.size()) return;
            String choice=visible.get(position);
            popup.dismiss(); callback.accept(choice);
        });
        show(popup);
    }

    private static void showSettings(Panel owner,boolean enableOnSave) {
        Context c=owner.getContext();
        boolean hasKey=CallCaptions.hasKey(c);
        LinearLayout content=new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        padding(content,22,12,22,4);
        String[] selection={CallCaptions.target(c)};
        Switch enabled = new Switch(c);
        enabled.setText("开启通话翻译");
        enabled.setTextColor(ink(c));
        enabled.setTextSize(16);
        enabled.setChecked(enableOnSave || CallCaptions.enabled(c));
        enabled.setMinHeight(dp(c,48));
        content.addView(enabled,new LinearLayout.LayoutParams(-1,-2));
        TextView target=text(c,"字幕语言     "+language(selection[0])+"  ▾",16,blue(c),true);
        target.setMinimumHeight(dp(c,48));
        action(target,()->pickLanguage(c,selection[0],code->{
            selection[0]=code; target.setText("字幕语言     "+language(code)+"  ▾");
        }));
        content.addView(target);
        Switch voice=new Switch(c);
        voice.setText("同声传译 · 播放译音");
        voice.setTextColor(ink(c));
        voice.setMinHeight(dp(c,48));
        voice.setChecked(CallCaptions.voice(c));
        content.addView(voice,new LinearLayout.LayoutParams(-1,-2));
        TextView keyLabel=text(c,"服务器配对链接",14,ink(c),true);
        padding(keyLabel,0,12,0,4);
        content.addView(keyLabel);
        EditText key=new EditText(c);
        key.setSingleLine();
        key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setSaveEnabled(false);
        key.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        key.setTextColor(ink(c)); key.setTextSize(15);
        key.setHint(hasKey?"已配对，可粘贴新链接":"粘贴服务器签发的 HTTPS 链接");
        key.setContentDescription("服务器配对链接");
        content.addView(key,new LinearLayout.LayoutParams(-1,-2));
        if(hasKey) {
            boolean[] remove={false};
            TextView removeButton=text(c,"解除服务器配对",14,muted(c),false);
            removeButton.setMinHeight(dp(c,44));
            action(removeButton,()->{
                remove[0]=!remove[0]; key.setTag(Boolean.valueOf(remove[0]));
                key.setEnabled(!remove[0]);
                enabled.setEnabled(!remove[0]);
                if(remove[0]) enabled.setChecked(false);
                removeButton.setText(remove[0]?"撤销移除":"解除服务器配对");
            });
            content.addView(removeButton);
        }
        TextView notice=text(c,CallCaptions.privacyNotice(),13,muted(c),false);
        notice.setLineSpacing(dp(c,2),1);
        content.addView(notice);
        ScrollView scroll=new ScrollView(c); scroll.addView(content);
        AlertDialog popup=dialog(c).setTitle("通话翻译").setView(scroll)
                .setNegativeButton("取消",null).setPositiveButton("保存",null).create();
        popup.setOnShowListener(ignored->popup.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String typed=key.getText().toString().trim();
            boolean remove=Boolean.TRUE.equals(key.getTag());
            if(enabled.isChecked() && typed.isEmpty() && !hasKey) {
                key.setError("请粘贴服务器配对链接"); key.requestFocus(); return;
            }
            try {
                if(remove) CallCaptions.setKey(c,"");
                else if(!typed.isEmpty()) CallCaptions.setKey(c,typed);
                CallCaptions.setVoice(c,voice.isChecked());
                CallCaptions.setTarget(c,selection[0]);
                CallCaptions.setEnabled(c,enabled.isChecked());
                owner.refresh(true);
                popup.dismiss();
            } catch(RuntimeException error) { failure(c,error); }
        }));
        popup.setOnDismissListener(ignored->key.getText().clear());
        show(popup);
    }

    private static void show(AlertDialog dialog) {
        if(dialog.getWindow()!=null) {
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                    |WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        dialog.show();
    }
}
