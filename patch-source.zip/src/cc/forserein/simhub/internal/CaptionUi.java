package cc.forserein.simhub.internal;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Window;
import android.widget.Button;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.Path;
import android.text.Editable;
import android.text.InputType;
import android.text.Layout;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Embedded views share preferences and current-call captions through CallCaptions. */
public final class CaptionUi {
    private CaptionUi() {}
    private enum Placement { DIALER, SETTINGS, CALL }

    public static View dialerView(Context context) { return new Panel(context, Placement.DIALER); }
    public static View settingsView(Context context) { return new Panel(context, Placement.SETTINGS); }
    public static View callView(Context context) { return new Panel(context, Placement.CALL); }

    public static View gearView(Context c) {
        FrameLayout header=new FrameLayout(c);
        Gear gear=new Gear(c);
        gear.setContentDescription("通话翻译设置");
        action(gear,()->showSettings(c,false,()->{}));
        header.addView(gear,new FrameLayout.LayoutParams(dp(c,48),dp(c,48),Gravity.RIGHT|Gravity.CENTER_VERTICAL));
        return header;
    }

    private static final class Gear extends View {
        final Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path teeth=new Path();
        Gear(Context c) {
            super(c);
            for(int tooth=0; tooth<8; tooth++) {
                for(int edge=0;edge<4;edge++) {
                    double angle=(tooth+(edge+.5)/4)*Math.PI/4;
                    float radius=edge==1 || edge==2 ? 9.3f : 7.2f;
                    float x=(float)Math.cos(angle)*radius, y=(float)Math.sin(angle)*radius;
                    if(tooth==0 && edge==0) teeth.moveTo(x,y); else teeth.lineTo(x,y);
                }
            }
            teeth.close();
        }
        @Override protected void onDraw(Canvas canvas) {
            float unit=Math.min(getWidth(),getHeight())/48f;
            canvas.save();
            canvas.translate(getWidth()/2f,getHeight()/2f);
            canvas.scale(unit,unit);
            pen.setStyle(Paint.Style.FILL);
            pen.setColor(dark(getContext())?0xff273343:0xffeef0f3);
            canvas.drawCircle(0,0,18,pen);
            pen.setStyle(Paint.Style.STROKE);
            pen.setStrokeWidth(1.75f);
            pen.setStrokeJoin(Paint.Join.ROUND);
            pen.setColor(ink(getContext()));
            canvas.drawPath(teeth,pen);
            canvas.drawCircle(0,0,3,pen);
            canvas.restore();
        }
    }

    private static int dp(Context context, float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    private static boolean dark(Context context) {
        int mode = context.getResources().getConfiguration().uiMode;
        return (mode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    private static int ink(Context c) { return dark(c) ? 0xffeef3ff : 0xff142239; }
    private static int muted(Context c) { return dark(c) ? 0xffb4bed0 : 0xff526178; }
    private static int blue(Context c) { return dark(c) ? 0xff93bcff : 0xff1859a8; }
    private static int outline(Context c) { return dark(c) ? 0xff3b485c : 0xffdae3ef; }

    private static GradientDrawable surface(Context c, int fill, int edge, float radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(c, radius));
        if (edge != 0) drawable.setStroke(dp(c, 1), edge);
        return drawable;
    }

    private static void padding(View v, int start, int top, int end, int bottom) {
        Context c = v.getContext();
        v.setPaddingRelative(dp(c,start),dp(c,top),dp(c,end),dp(c,bottom));
    }

    private static TextView text(Context c, String value, float size, int color, boolean medium) {
        TextView t = new TextView(c);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        t.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        t.setTextDirection(TEXT_DIRECTION_FIRST_STRONG);
        return t;
    }

    private static final int TEXT_DIRECTION_FIRST_STRONG = View.TEXT_DIRECTION_FIRST_STRONG;

    private static LinearLayout row(Context c) {
        LinearLayout layout = new LinearLayout(c);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private static LinearLayout.LayoutParams stretch() {
        return new LinearLayout.LayoutParams(0, -2, 1);
    }

    private static void action(View v, Runnable callback) {
        v.setClickable(true);
        v.setFocusable(true);
        v.setOnClickListener(view -> callback.run());
        v.setForeground(new RippleDrawable(ColorStateList.valueOf(0x226faaff),null,
                surface(v.getContext(),Color.WHITE,0,12)));
    }

    private static String language(String code) {
        if ("zh".equalsIgnoreCase(code) || "zh-Hans".equalsIgnoreCase(code) ||
                "zh-CN".equalsIgnoreCase(code)) return "简体中文";
        if ("zh-Hant".equalsIgnoreCase(code) || "zh-TW".equalsIgnoreCase(code)) return "繁體中文";
        Locale locale = Locale.forLanguageTag(code);
        String name = locale.getDisplayName(Locale.SIMPLIFIED_CHINESE);
        return name.isEmpty() ? code : name;
    }

    /** A speech bubble with two caption lines, painted identically across system font packs. */
    private static final class Mark extends View {
        final Paint pen = new Paint(Paint.ANTI_ALIAS_FLAG);
        Mark(Context context) {
            super(context);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float unit = Math.min(getWidth(),getHeight()) / 24f;
            canvas.save();
            canvas.translate((getWidth()-24*unit)*.5f,(getHeight()-24*unit)*.5f);
            canvas.scale(unit,unit);
            pen.setStrokeWidth(1.65f);
            pen.setStrokeCap(Paint.Cap.ROUND);
            pen.setColor(blue(getContext()));
            pen.setStyle(Paint.Style.STROKE);
            canvas.drawRoundRect(new RectF(2.4f,4.3f,21.6f,19.7f),4,4,pen);
            canvas.drawLine(6.5f,10.2f,17.3f,10.2f,pen);
            canvas.drawLine(6.5f,14.3f,13.3f,14.3f,pen);
            canvas.restore();
        }
    }

    private static final class Panel extends LinearLayout {
        final Placement placement;
        final TextView label;
        TextView target;
        Switch toggle;
        TextView sentence, prior, indicator;
        CaptionScroll lines;
        LinearLayout controls, reading;
        TextView latest;
        FrameLayout viewport;
        final boolean compact;
        private boolean painting;
        private boolean enabled;
        private String activeTarget = "";
        private CallCaptions.Display displayed;

        Panel(Context context, Placement place) {
            super(context);
            placement = place;
            compact = context.getResources().getConfiguration().screenHeightDp < 500;
            setOrientation(VERTICAL);
            setClipToPadding(false);
            controls = row(context);
            Mark mark = new Mark(context);
            int icon = dp(context, place==Placement.CALL ? 19 : 22);
            controls.addView(mark,new LayoutParams(icon,icon));
            label = text(context,place==Placement.CALL?"通话字幕":"通话翻译",
                    place==Placement.CALL ? 13 : 16,ink(context),true);
            padding(label,8,0,4,0);
            controls.addView(label,stretch());
            if (place==Placement.CALL) setupCall(); else setupControl();
            refresh(true);
        }

        private void setupControl() {
            Context c = getContext();
            controls.setMinimumHeight(dp(c,48));
            if (placement==Placement.DIALER) {
                padding(controls,13,0,8,0);
                controls.setBackground(surface(c,dark(c)?0xff222f42:0xfff0f5fc,0,14));
                toggle = new Switch(c);
                toggle.setMinHeight(dp(c,48));
                toggle.setMinWidth(dp(c,48));
                toggle.setGravity(Gravity.CENTER);
                toggle.setContentDescription("通话翻译");
                toggle.setOnCheckedChangeListener((button,on) -> {
                    if (painting) return;
                    if (on && !CallCaptions.hasKey(c)) {
                        // The switch reflects persisted state while setup is open.
                        refresh(true);
                        configure(true);
                    } else {
                        try {
                            CallCaptions.setEnabled(c,on);
                            refresh(true);
                            if (on) pickLanguage(c,CallCaptions.target(c),this::choose);
                        } catch (RuntimeException error) { failure(c,error); refresh(true); }
                    }
                });
                target = text(c,"",14,blue(c),true);
                target.setMinHeight(dp(c,48));
                target.setMaxLines(1);
                target.setEllipsize(TextUtils.TruncateAt.END);
                target.setMaxWidth(dp(c,116));
                padding(target,6,0,6,0);
                action(target,()->pickLanguage(c,CallCaptions.target(c),this::choose));
                controls.addView(target);
                controls.addView(toggle);
                action(label,()->configure(false));
                label.setContentDescription("通话翻译设置");
            } else {
                padding(controls,16,0,14,0);
                target = text(c,"",14,muted(c),false);
                target.setMaxWidth(dp(c,150));
                target.setSingleLine();
                target.setEllipsize(TextUtils.TruncateAt.END);
                controls.addView(target);
                action(controls,()->configure(false));
            }
            addView(controls,new LayoutParams(-1,-2));
        }

        private void setupCall() {
            Context c = getContext();
            padding(this,14,compact?0:2,14,compact?5:9);
            setBackground(surface(c,dark(c)?0xff1c2a3e:0xfff2f6fc,outline(c),16));
            controls.setMinimumHeight(dp(c,40));
            target = text(c,"",13,blue(c),true);
            target.setGravity(Gravity.CENTER);
            target.setMinHeight(dp(c,48));
            target.setMaxWidth(dp(c,140));
            target.setSingleLine();
            target.setEllipsize(TextUtils.TruncateAt.END);
            padding(target,6,0,6,0);
            action(target,()->pickLanguage(c,CallCaptions.target(c),this::choose));
            controls.addView(target);
            addView(controls,new LayoutParams(-1,-2));
            reading = new LinearLayout(c);
            reading.setOrientation(VERTICAL);
            indicator = text(c,"",14,muted(c),false);
            indicator.setIncludeFontPadding(true);
            indicator.setAccessibilityLiveRegion(ACCESSIBILITY_LIVE_REGION_POLITE);
            reading.addView(indicator,new LayoutParams(-1,-2));

            sentence = text(c,"",compact?18:20,ink(c),false);
            sentence.setIncludeFontPadding(true);
            sentence.setGravity(Gravity.TOP | Gravity.START);
            sentence.setTextAlignment(TEXT_ALIGNMENT_TEXT_START);
            sentence.setLineSpacing(dp(c,2),1);
            sentence.setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY);
            sentence.setAccessibilityLiveRegion(ACCESSIBILITY_LIVE_REGION_POLITE);
            lines = new CaptionScroll(c);
            lines.setFillViewport(false);
            lines.setVerticalScrollBarEnabled(true);
            lines.setNestedScrollingEnabled(false);
            LinearLayout transcript=new LinearLayout(c);
            transcript.setOrientation(VERTICAL);
            prior=text(c,"",compact?16:17,muted(c),false);
            prior.setLineSpacing(dp(c,2),1);
            padding(prior,0,0,0,6);
            transcript.addView(prior,new LayoutParams(-1,-2));
            transcript.addView(sentence,new LayoutParams(-1,-2));
            lines.addView(transcript,new ScrollView.LayoutParams(-1,-2));
            viewport = new FrameLayout(c);
            viewport.addView(lines,new FrameLayout.LayoutParams(-1,-1,Gravity.TOP));
            reading.addView(viewport,new LayoutParams(-1,0,1));
            latest=text(c,"回到最新",13,blue(c),true);
            latest.setMinHeight(dp(c,48));
            action(latest,()->{lines.follow=true; refresh(true); lines.tail();});
            latest.setVisibility(GONE);
            controls.addView(latest);
            lines.onReadingChange=()->{
                latest.setVisibility(lines.follow?GONE:VISIBLE);
                target.setVisibility(lines.follow?VISIBLE:GONE);
            };

            // Reserve the reading space across utterances. Use font metrics so
            // large system fonts retain complete baselines and room for accents.
            int mainLines = compact ? 2 : 3;
            Paint.FontMetricsInt font = sentence.getPaint().getFontMetricsInt();
            // Fallback CJK and Arabic fonts can have taller glyphs than the
            // Latin text paint. The scroll viewport below uses actual line boxes.
            int lineBudget = Math.max(sentence.getLineHeight(),
                    (int)Math.ceil(sentence.getTextSize()*1.45f)+dp(c,2));
            int bodyHeight = Math.max(lineBudget,font.bottom-font.top) + (mainLines-1)*lineBudget;
            if (!compact) {
                Paint.FontMetricsInt note = prior.getPaint().getFontMetricsInt();
                bodyHeight += note.bottom-note.top + dp(c,6);
            }
            reading.setMinimumHeight(bodyHeight);
            addView(reading,new LayoutParams(-1,bodyHeight));
        }

        private void choose(String code) {
            try { CallCaptions.setTarget(getContext(),code); refresh(true); }
            catch(RuntimeException error) { failure(getContext(),error); }
        }

        private void configure(boolean enableOnSave) {
            showSettings(getContext(),enableOnSave,()->refresh(true));
        }

        private void refresh(boolean force) {
            Context c = getContext();
            boolean on = CallCaptions.enabled(c);
            String code = CallCaptions.target(c);
            if (force || enabled!=on || !code.equals(activeTarget)) {
                painting = true;
                if (toggle!=null) toggle.setChecked(on);
                if (placement==Placement.SETTINGS) {
                    target.setText((on?language(code):"已关闭")+"  ›");
                } else {
                    target.setText(language(code)+"  ▾");
                    target.setContentDescription("字幕语言，"+language(code));
                    if (placement==Placement.DIALER) target.setVisibility(on?VISIBLE:GONE);
                }
                if (placement==Placement.CALL && enabled!=on) requestLayout();
                if (placement==Placement.CALL && !code.equals(activeTarget)) {
                    lines.follow=true;
                    Locale locale = Locale.forLanguageTag(code);
                    int direction = TextUtils.getLayoutDirectionFromLocale(locale)==LAYOUT_DIRECTION_RTL
                            ? TEXT_DIRECTION_FIRST_STRONG_RTL : TEXT_DIRECTION_FIRST_STRONG_LTR;
                    sentence.setTextLocale(locale);
                    sentence.setTextDirection(direction);
                    prior.setTextLocale(locale);
                    prior.setTextDirection(direction);
                }
                enabled=on; activeTarget=code; painting=false;
                if (placement==Placement.CALL) {
                    setImportantForAccessibility(on?IMPORTANT_FOR_ACCESSIBILITY_AUTO:IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
                    controls.setVisibility(on?VISIBLE:GONE);
                    reading.setVisibility(on?VISIBLE:GONE);
                }
            }
            if (placement!=Placement.CALL) return;
            CallCaptions.Display next = on ? CallCaptions.display() : null;
            if (next==null || next.current.isEmpty()) lines.follow=true;
            if (!lines.follow && next!=null && displayed!=null && !next.current.isEmpty()) return;
            if (next==displayed && !force) return;
            boolean changed=next!=displayed;
            displayed = next;
            String now = next==null ? "" : next.current;
            String last = next==null ? "" : TextUtils.join("\n\n",next.history);
            String status = next==null ? "" : next.status;
            String note = on && now.isEmpty() && status.isEmpty() ? "等待对方说话…" : status;
            if (!TextUtils.equals(sentence.getText(),now)) sentence.setText(now);
            if (!TextUtils.equals(prior.getText(),last)) prior.setText(last);
            if (!TextUtils.equals(indicator.getText(),note)) {
                indicator.setText(note);
                indicator.setTextColor(now.isEmpty() && "等待对方说话…".equals(note)
                        ? muted(c) : dark(c)?0xffffcb8e:0xff875015);
            }
            lines.setVisibility(now.isEmpty()?GONE:VISIBLE);
            viewport.setVisibility(now.isEmpty()?GONE:VISIBLE);
            prior.setVisibility(last.isEmpty()?GONE:VISIBLE);
            latest.setVisibility(lines.follow?GONE:VISIBLE);
            target.setVisibility(lines.follow?VISIBLE:GONE);
            indicator.setVisibility(note.isEmpty()?GONE:VISIBLE);
            if (changed && lines.follow) lines.tail();
        }

        private final Runnable tick = new Runnable() {
            @Override public void run() {
                if (!isAttachedToWindow() || getWindowVisibility()!=VISIBLE) return;
                refresh(false);
                postDelayed(this,placement==Placement.CALL && enabled ? 350 : 1000);
            }
        };
        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            removeCallbacks(tick); post(tick);
        }
        @Override protected void onDetachedFromWindow() {
            removeCallbacks(tick); super.onDetachedFromWindow();
        }
        @Override protected void onWindowVisibilityChanged(int visibility) {
            super.onWindowVisibilityChanged(visibility);
            if (tick==null) return;
            removeCallbacks(tick);
            if (visibility==VISIBLE && isAttachedToWindow()) post(tick);
        }
        @Override protected void onMeasure(int width,int height) {
            if (placement==Placement.CALL && !enabled) {
                setMeasuredDimension(MeasureSpec.getSize(width),0);
                return;
            }
            if (placement==Placement.CALL && reading!=null) {
                // A wrapped service error may need more than the reserved lines.
                // Measure it at the real sheet width, leaving room for the first
                // translated line even at large accessibility scales.
                int required = reading.getMinimumHeight();
                if (indicator.getVisibility()==VISIBLE && MeasureSpec.getMode(width)!=MeasureSpec.UNSPECIFIED) {
                    int available = Math.max(0,MeasureSpec.getSize(width)-getPaddingLeft()-getPaddingRight());
                    indicator.measure(MeasureSpec.makeMeasureSpec(available,MeasureSpec.EXACTLY),
                            MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED));
                    int firstLine = lines.getVisibility()==VISIBLE ? sentence.getLineHeight()+dp(getContext(),5) : 0;
                    required = Math.max(required,indicator.getMeasuredHeight()+firstLine);
                }
                reading.getLayoutParams().height = required;
            }
            super.onMeasure(width,height);
        }
    }

    /** Keep a reader's position while new words arrive and give the call page unused gestures. */
    private static final class CaptionScroll extends ScrollView {
        boolean follow=true, dragging;
        Runnable onReadingChange;
        float downY;
        CaptionScroll(Context c) {super(c);}
        void tail() {
            post(()->{if(follow && !dragging && getChildCount()>0) scrollTo(0,getChildAt(0).getHeight());});
        }
        @Override protected void onLayout(boolean changed,int left,int top,int right,int bottom) {
            super.onLayout(changed,left,top,right,bottom);
            if(follow && !dragging && getChildCount()>0) scrollTo(0,getChildAt(0).getHeight());
        }
        private void follow(boolean value) {
            if (value==follow) return;
            follow=value;
            if(onReadingChange!=null) onReadingChange.run();
        }
        @Override public boolean dispatchTouchEvent(MotionEvent event) {
            int action=event.getActionMasked();
            if (action==MotionEvent.ACTION_DOWN) {
                if (!canScrollVertically(-1) && !canScrollVertically(1)) return false;
                downY=event.getRawY();
                dragging=true;
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            if(action==MotionEvent.ACTION_MOVE && Math.abs(event.getRawY()-downY)>
                    android.view.ViewConfiguration.get(getContext()).getScaledTouchSlop()) follow(false);
            boolean handled=super.dispatchTouchEvent(event);
            if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_CANCEL) {
                dragging=false;
                getParent().requestDisallowInterceptTouchEvent(false);
                follow(!canScrollVertically(1));
            }
            return handled;
        }
        @Override protected void onScrollChanged(int x,int y,int oldX,int oldY) {
            super.onScrollChanged(x,y,oldX,oldY);
            if(!dragging && !follow && !canScrollVertically(1)) follow(true);
        }
    }

    private static void failure(Context context,RuntimeException error) {
        String message=error.getMessage();
        Toast.makeText(context,message==null?"无法保存通话翻译设置":message,Toast.LENGTH_LONG).show();
    }

    private static int sheet(Context c) {return dark(c)?0xff24221e:0xfffaf8f1;}
    private static int paper(Context c) {return dark(c)?0xff302e29:0xfffffefa;}
    private static int tone(Context c) {return dark(c)?0xfff5f0e6:0xff302d27;}
    private static int detail(Context c) {return dark(c)?0xffbfb8aa:0xff6a6359;}
    private static int seam(Context c) {return dark(c)?0xff47433b:0xffe8e2d5;}
    private static int well(Context c) {return dark(c)?0xff25231f:0xfff2efe6;}
    private static int accent(Context c) {return dark(c)?0xffe8d8b8:0xff514532;}

    private static void inputSurface(EditText input) {
        Context c=input.getContext();
        StateListDrawable states=new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_focused},surface(c,paper(c),accent(c),13));
        states.addState(new int[0],surface(c,well(c),seam(c),13));
        input.setBackgroundTintList(null);
        input.setBackground(states);
        input.setMinHeight(dp(c,48));
        input.setTextColor(tone(c));
        input.setHintTextColor(detail(c));
        input.setHighlightColor(dark(c)?0x556a604e:0x4488754f);
        padding(input,13,8,13,8);
    }
    private static void switchSurface(Switch control) {
        Context c=control.getContext();
        GradientDrawable thumb=surface(c,Color.WHITE,0x22000000,20);
        thumb.setSize(dp(c,25),dp(c,25));
        control.setThumbTintList(null);
        control.setThumbDrawable(new InsetDrawable(thumb,dp(c,2)));
        control.setTrackTintList(null);
        StateListDrawable track=new StateListDrawable();
        int[] colors={dark(c)?0xff3d6950:0xff788575,0xff31865a,dark(c)?0xff605d55:0xffd5d2c9};
        int[][] states={{-android.R.attr.state_enabled},{android.R.attr.state_checked},{}};
        for(int i=0;i<states.length;i++) {
            GradientDrawable rail=surface(c,colors[i],0,20);
            rail.setSize(dp(c,48),dp(c,29));
            track.addState(states[i],rail);
        }
        control.setTrackDrawable(track);
        control.setSwitchMinWidth(dp(c,48));
        control.setSplitTrack(false);
    }
    private static Button sheetButton(Context c,String label,boolean primary) {
        Button b=new Button(c);
        b.setText(label); b.setTextSize(16); b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        b.setLetterSpacing(0); b.setStateListAnimator(null); b.setMinWidth(0); b.setMinimumWidth(0);
        b.setTextColor(primary?sheet(c):tone(c));
        b.setBackgroundTintList(null);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x26756b5a),
                surface(c,primary?accent(c):well(c),primary?0:seam(c),16),null));
        return b;
    }
    private interface Submit { void run(Dialog dialog); }
    private static Dialog showSheet(Context c,String title,View body,Submit save) {
        Dialog popup=new Dialog(c);
        popup.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout shell=new LinearLayout(c);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackground(surface(c,sheet(c),seam(c),28));
        shell.setClipToOutline(true);
        shell.setFocusableInTouchMode(true);
        TextView heading=text(c,title,24,tone(c),true);
        padding(heading,22,20,22,12);
        shell.addView(heading);
        shell.addView(body,new LinearLayout.LayoutParams(-1,-2,1));
        LinearLayout foot=row(c);
        padding(foot,18,10,18,16);
        Button cancel=sheetButton(c,"取消",false);
        cancel.setOnClickListener(v->popup.dismiss());
        foot.addView(cancel,new LinearLayout.LayoutParams(0,dp(c,48),1));
        if(save!=null) {
            Button apply=sheetButton(c,"保存",true);
            apply.setOnClickListener(v->save.run(popup));
            LinearLayout.LayoutParams size=new LinearLayout.LayoutParams(0,dp(c,48),1);
            size.setMarginStart(dp(c,10));
            foot.addView(apply,size);
        }
        shell.addView(foot);
        popup.setContentView(shell);
        Window window=popup.getWindow();
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setDimAmount(.32f);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                |WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        int width=c.getResources().getDisplayMetrics().widthPixels;
        window.setLayout(Math.min(dp(c,416),width-dp(c,32)),WindowManager.LayoutParams.WRAP_CONTENT);
        popup.setCanceledOnTouchOutside(true);
        popup.show();
        return popup;
    }

    private interface Selected { void accept(String code); }

    private static void pickLanguage(Context c, String selected, Selected callback) {
        pickLanguage(c,selected,false,callback);
    }

    private static void pickLanguage(Context c,String selected,boolean spoken,Selected callback) {
        List<String> all = new ArrayList<>(Arrays.asList(CallCaptions.targetCodes()));
        if (spoken) all.remove("yue-Hant");
        all.sort(Comparator.comparing(CaptionUi::language,java.text.Collator.getInstance(Locale.SIMPLIFIED_CHINESE)));
        LinearLayout container = new LinearLayout(c);
        container.setOrientation(LinearLayout.VERTICAL);
        padding(container,18,6,18,0);
        EditText filter = new EditText(c);
        filter.setSingleLine();
        filter.setHint("搜索语言");
        filter.setContentDescription(spoken?"搜索译音语言":"搜索字幕语言");
        inputSurface(filter);
        filter.setTextSize(16);
        container.addView(filter,new LinearLayout.LayoutParams(-1,-2));
        ListView list = new ListView(c);
        list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        list.setDividerHeight(0);
        container.addView(list,new LinearLayout.LayoutParams(-1,dp(c,Math.min(330,Math.max(112,
                c.getResources().getConfiguration().screenHeightDp/2)))));
        List<String> visible = new ArrayList<>();
        Dialog popup=showSheet(c,spoken?"译音语言":"字幕语言",container,null);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(c,
                android.R.layout.simple_list_item_single_choice,new ArrayList<>()) {
            @Override public View getView(int position,View recycled,android.view.ViewGroup parent) {
                android.widget.CheckedTextView v=(android.widget.CheckedTextView)super.getView(position,recycled,parent);
                v.setTextColor(tone(c)); v.setCheckMarkTintList(ColorStateList.valueOf(accent(c)));
                return v;
            }
        };
        list.setAdapter(adapter);
        Runnable applyFilter = () -> {
            String query=filter.getText().toString().trim().toLowerCase(Locale.ROOT);
            visible.clear();
            adapter.setNotifyOnChange(false);
            adapter.clear();
            for(String code:all) {
                Locale loc=Locale.forLanguageTag(code);
                String search=language(code)+" "+code+" "+loc.getDisplayName(Locale.ENGLISH)+" "+loc.getDisplayName(loc);
                if(search.toLowerCase(Locale.ROOT).contains(query)) {
                    visible.add(code);
                    adapter.add(language(code));
                }
            }
            adapter.notifyDataSetChanged();
            list.clearChoices();
            int index=visible.indexOf(selected);
            if(index>=0) list.setItemChecked(index,true);
        };
        applyFilter.run();
        filter.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            public void onTextChanged(CharSequence s,int start,int before,int count) { applyFilter.run(); }
            public void afterTextChanged(Editable editable) {}
        });
        list.setOnItemClickListener((parent,view,position,id)->{
            if(position<0 || position>=visible.size()) return;
            String choice=visible.get(position);
            popup.dismiss(); callback.accept(choice);
        });
    }

    private static LinearLayout section(Context c,LinearLayout parent) {
        LinearLayout card=new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        padding(card,16,4,16,4);
        card.setBackground(surface(c,paper(c),seam(c),19));
        LinearLayout.LayoutParams bounds=new LinearLayout.LayoutParams(-1,-2);
        bounds.bottomMargin=dp(c,10);
        parent.addView(card,bounds);
        return card;
    }
    private static Switch mode(Context c,LinearLayout content,boolean spoken,boolean checked,String[] targets) {
        int index=spoken?1:0;
        LinearLayout card=section(c,content);
        String title=spoken?"同声传译":"通话字幕";
        String field=spoken?"译音语言":"字幕语言";
        Switch toggle=new Switch(c);
        toggle.setText(title);
        toggle.setTextSize(16);
        toggle.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        toggle.setTextColor(tone(c));
        toggle.setMinHeight(dp(c,48));
        switchSurface(toggle);
        toggle.setChecked(checked);
        card.addView(toggle,new LinearLayout.LayoutParams(-1,-2));
        View line=new View(c);
        line.setBackgroundColor(seam(c));
        card.addView(line,new LinearLayout.LayoutParams(-1,dp(c,1)));
        LinearLayout select=row(c);
        select.setMinimumHeight(dp(c,44));
        select.addView(text(c,field,14,detail(c),false),stretch());
        TextView value=text(c,language(targets[index])+"  ›",14,accent(c),true);
        select.addView(value);
        select.setContentDescription(field+"，"+language(targets[index]));
        action(select,()->pickLanguage(c,targets[index],spoken,code->{
            targets[index]=code;
            value.setText(language(code)+"  ›");
            select.setContentDescription(field+"，"+language(code));
        }));
        card.addView(select);
        return toggle;
    }
    private static void showSettings(Context c,boolean enableOnSave,Runnable saved) {
        boolean hasKey=CallCaptions.hasKey(c);
        LinearLayout content=new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        padding(content,16,2,16,0);
        content.setFocusableInTouchMode(true);
        String[] selection={CallCaptions.target(c),CallCaptions.voiceTarget(c)};
        Switch enabled=mode(c,content,false,enableOnSave || CallCaptions.enabled(c),selection);
        Switch voice=mode(c,content,true,CallCaptions.voice(c),selection);
        LinearLayout keyCard=section(c,content);
        LinearLayout keyHeader=row(c);
        keyHeader.addView(text(c,"服务器配对",15,tone(c),true),stretch());
        TextView test=text(c,"测试密钥",14,accent(c),true);
        test.setGravity(Gravity.CENTER);
        test.setMinHeight(dp(c,40));
        padding(test,10,0,10,0);
        keyHeader.addView(test);
        keyCard.addView(keyHeader);
        EditText key=new EditText(c);
        key.setSingleLine();
        key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setSaveEnabled(false);
        key.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        inputSurface(key); key.setTextSize(15);
        key.setHint(hasKey?"已配对，可粘贴新链接":"粘贴服务器签发的 HTTPS 链接");
        key.setContentDescription("服务器配对链接");
        keyCard.addView(key,new LinearLayout.LayoutParams(-1,-2));
        TextView result=text(c,"",13,detail(c),false);
        padding(result,0,5,0,8);
        result.setVisibility(View.GONE);
        result.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        keyCard.addView(result);
        int[] generation={0};
        key.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            public void afterTextChanged(Editable s) {}
            public void onTextChanged(CharSequence s,int start,int before,int count) {
                generation[0]++;
                result.setVisibility(View.GONE);
                test.setEnabled(key.isEnabled());
            }
        });
        action(test,()->{
            final String typed=key.getText().toString().trim();
            if (typed.isEmpty() && !hasKey) {
                key.setError("请先粘贴配对链接"); key.requestFocus(); return;
            }
            final int ticket=++generation[0];
            test.setEnabled(false);
            result.setText("正在测试字幕和同传模型…");
            result.setVisibility(View.VISIBLE);
            new Thread(()->{
                String message;
                try {
                    String pairing=typed.isEmpty()?CaptionKeyStore.read(c):typed;
                    message=new CaptionRelay(pairing).testModels();
                } catch(IllegalArgumentException invalid) {message="配对链接格式有误";}
                catch(Exception failure) {message="连接失败，请检查中转地址和网络";}
                final String report=message;
                test.post(()->{
                    if(ticket!=generation[0] || !test.isAttachedToWindow()) return;
                    result.setText(report); test.setEnabled(true);
                });
            },"SIMHub-test-translation").start();
        });
        if(hasKey) {
            boolean[] remove={false};
            TextView removeButton=text(c,"解除服务器配对",14,detail(c),false);
            removeButton.setMinHeight(dp(c,44));
            action(removeButton,()->{
                remove[0]=!remove[0]; key.setTag(Boolean.valueOf(remove[0]));
                key.setEnabled(!remove[0]);
                enabled.setEnabled(!remove[0]);
                voice.setEnabled(!remove[0]); test.setEnabled(!remove[0]);
                generation[0]++; result.setVisibility(View.GONE);
                if(remove[0]) {enabled.setChecked(false); voice.setChecked(false);}
                removeButton.setText(remove[0]?"撤销移除":"解除服务器配对");
            });
            keyCard.addView(removeButton);
        }
        TextView notice=text(c,CallCaptions.privacyNotice(),13,detail(c),false);
        notice.setLineSpacing(dp(c,2),1);
        content.addView(notice);
        ScrollView scroll=new ScrollView(c); scroll.addView(content);
        Dialog popup=showSheet(c,"通话翻译",scroll,dialog->{
            String typed=key.getText().toString().trim();
            boolean remove=Boolean.TRUE.equals(key.getTag());
            if((enabled.isChecked() || voice.isChecked()) && typed.isEmpty() && !hasKey) {
                key.setError("请粘贴服务器配对链接"); key.requestFocus(); return;
            }
            try {
                CallCaptions.configure(c,enabled.isChecked(),selection[0],voice.isChecked(),selection[1],
                        remove?"":typed.isEmpty()?null:typed);
                saved.run();
                dialog.dismiss();
            } catch(RuntimeException error) { failure(c,error); }
        });
        popup.setOnDismissListener(ignored->{generation[0]++; key.getText().clear();});
    }
}
