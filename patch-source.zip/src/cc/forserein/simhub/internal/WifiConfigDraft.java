package cc.forserein.simhub.internal;

import java.util.*;

/** Page-scoped draft: edits never reach the live connection or disk before Done. */
public final class WifiConfigDraft {
    private final Map<String,String> initial, values;
    public WifiConfigDraft(Map<String,String> initial) {
        this.initial=new LinkedHashMap<>(initial);values=new LinkedHashMap<>(initial);
    }
    public String text(String key) {String v=values.get(key);return v==null?"":v;}
    public void edit(String key,String value) {WifiConfigValues.field(key);values.put(key,value);}
    public Map<String,String> copy() {return new LinkedHashMap<>(values);}
    public Map<String,String> validated() {return WifiConfigValues.validate(values);}
    public boolean changed(String key) {
        String before=initial.get(key),after=values.get(key);
        return !Objects.equals(before==null?"":before,after==null?"":after);
    }
    public void apply(Map<String,String> subset) {
        Map<String,String> valid=WifiConfigValues.validate(subset);
        for(String key:subset.keySet()) edit(key,valid.containsKey(key)?valid.get(key):"");
    }
    public static String[] keys(String row) {
        switch(row){
            case "Domain":return new String[]{"domain"};
            case "APN":return new String[]{"apn"};
            case "IP":return new String[]{"ip"};
            case "IPsec":return new String[]{"ipsec"};
            case "NAI":return new String[]{"nai","impi","impu","eap"};
            case "IKE":return new String[]{"ike_encr","ike_integ","ike_prf","ike_dh"};
            case "ESP":return new String[]{"esp_encr","esp_integ"};
            case "Keepalive":return new String[]{"keepalive"};
            default:throw new IllegalArgumentException("未知配置条目");
        }
    }
    public String display(String row,String original,Map<String,String> defaults) {
        String[] keys=keys(row);
        boolean changed=false;for(String key:keys) changed|=changed(key);
        if(!changed) return original;
        if(row.equals("NAI")) keys=new String[]{"nai"};
        List<String> parts=new ArrayList<>();
        for(String key:keys) {String v=text(key).trim();parts.add(v.isEmpty()?defaults.get(key):v);}
        String result=WifiConfigValues.join(parts," ");
        return row.equals("Keepalive")?result+"s":result;
    }
}
