package cc.forserein.simhub.internal;

import static cc.forserein.simhub.internal.SipInviteFailure.call;
import static cc.forserein.simhub.internal.SipInviteFailure.field;

import java.util.List;
import java.util.Map;

/** Keep an initial outgoing INVITE aligned with its native TCP-to-UDP fallback. */
public final class SipInviteTransport {
    private static final String TCP = "SIP/2.0/TCP";
    private static final String UDP = "SIP/2.0/UDP";
    private SipInviteTransport() {}

    private static String header(Object message, String full, String compact) throws Exception {
        String value = null;
        for (Object pair : (List<?>) field(message, "f")) {
            String name = (String) field(pair, "T");
            if (full.equalsIgnoreCase(name) || compact != null && compact.equalsIgnoreCase(name)) {
                if (value != null) return null; // Native initial requests have one top Via/identity.
                value = (String) field(pair, "U");
            }
        }
        return value;
    }
    private static String parameter(Object message, String header, String name) throws Exception {
        if (header == null) return null;
        Class<?> parser = message.getClass().getField("Companion").getType();
        return (String) parser.getMethod("b", String.class, String.class).invoke(null, name, header);
    }
    private static boolean present(String value) { return value != null && !value.isEmpty(); }
    private static boolean request(Object message) throws Exception {
        return message != null && (Boolean) field(message, "a")
                && "INVITE".equals(field(message, "b"));
    }
    private static boolean same(Object first, Object second) {
        return first != null && first.equals(second);
    }

    /** Called only after a82 has dispatched its rewritten queued request through native C. */
    public static void onFallbackSent(Object engine, Object queued) {
        try {
            if (engine == null || !request(queued) || !(Boolean) field(engine, "W")) return;
            String via = header(queued, "Via", "v");
            String id = header(queued, "Call-ID", "i");
            String from = header(queued, "From", "f");
            if (via == null || !via.startsWith(UDP + " ") || !present(id)) return;
            String branch = parameter(queued, via, "branch");
            if (!present(branch) || !present(parameter(queued, from, "tag"))) return;
            Object sequence = call(queued, "e", new Class<?>[0]);
            if (sequence == null || !"INVITE".equals(field(sequence, "b"))) return;

            Object manager = field(engine, "J");
            if (manager == null) return;
            Object dialog = ((Map<?, ?>) field(manager, "e")).get(id);
            if (dialog == null) return;
            Object direction = field(dialog, "a"), state = field(dialog, "c");
            if (direction != direction.getClass().getField("U").get(null)
                    || state == state.getClass().getField("Y").get(null)
                    || field(dialog, "D") != null) return;
            Object original = field(dialog, "j");
            if (!request(original) || !same(field(sequence, "a"), field(dialog, "i"))) return;
            Object originalSequence = call(original, "e", new Class<?>[0]);
            String originalVia = header(original, "Via", "v");
            if (originalSequence == null || !"INVITE".equals(field(originalSequence, "b"))
                    || !same(field(sequence, "a"), field(originalSequence, "a"))
                    || !id.equals(header(original, "Call-ID", "i"))
                    || !same(from, header(original, "From", "f"))
                    || !same(field(queued, "c"), field(original, "c"))
                    || originalVia == null || !originalVia.startsWith(TCP + " ")
                    || !via.equals(originalVia.replace(TCP, UDP))) return;

            // kb4.i replaces its immutable header pair; never mutate a shared jl3 value.
            call(original, "i", new Class<?>[]{String.class, String.class}, "Via", via);

            // The original TCP INVITE already owns a final-response timer. Reuse that
            // exact request/timer, retain its deadline, and enable native UDP cadence
            // only until the first provisional response. No new timer is installed.
            if ((Boolean) field(dialog, "w") || (Boolean) field(dialog, "x")
                    || state != state.getClass().getField("T").get(null)) return;
            double now = (Double) engine.getClass().getMethod("p").invoke(null);
            for (Object timer : (List<?>) field(dialog, "F")) {
                Object kind = field(timer, "f");
                if (field(timer, "a") != original || field(timer, "b") != null
                        || kind == null || !"ja4".equals(kind.getClass().getName())
                        || !branch.equals(field(kind, "n"))) continue;
                double interval = (Double) field(timer, "c"), next = (Double) field(timer, "d");
                double deadline = (Double) field(timer, "e");
                if (interval == Double.POSITIVE_INFINITY && next == Double.POSITIVE_INFINITY
                        && !Double.isInfinite(deadline) && !Double.isNaN(deadline) && deadline > now) {
                    timer.getClass().getField("c").setDouble(timer, 0.5);
                    timer.getClass().getField("d").setDouble(timer, now + 0.5);
                }
                return;
            }
        } catch (Exception failure) {
            try {
                call(field(engine, "g"), "i", new Class<?>[]{Object.class},
                        "通话：UDP 回退的事务状态同步未完成");
            } catch (Exception ignored) { /* Logging must not change native dispatch. */ }
        }
    }
}
