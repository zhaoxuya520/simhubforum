"""Align only a native queued outgoing INVITE after TCP-to-UDP fallback dispatch."""
from pathlib import Path
import hashlib
from sip_early_transaction_transport_patch import reverse_sip_early_transaction_transport

SIGNATURE = '.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;'
BASE_CLASS_SHA256 = '59d84b2a3992a64e220194f5dece51f518c5b5f7719f7ac515ac85a0f9f3e9f0'
BASE_METHOD_SHA256 = '4830b0b2dff35aca131d65697863c034cf30994579e30688ba71bac4598e0ec0'
DISPATCH = '    invoke-virtual {v6, v2}, Lo82;->C(Lkb4;)V\n'
HOOK = '''
    invoke-static {v6, v2}, Lcc/forserein/simhub/internal/SipInviteTransport;->onFallbackSent(Ljava/lang/Object;Ljava/lang/Object;)V
'''


def _method(text):
    a = text.index(SIGNATURE)
    b = text.index('.end method', a) + len('.end method')
    return a, b, text[a:b]


def apply_sip_invite_transport(smali):
    path = Path(smali) / 'a82.smali'
    text = path.read_text()
    assert hashlib.sha256(text.encode()).hexdigest() == BASE_CLASS_SHA256, 'native TCP callback changed'
    a, b, body = _method(text)
    assert hashlib.sha256(body.encode()).hexdigest() == BASE_METHOD_SHA256
    assert body.count(DISPATCH) == 1
    path.write_text(text[:a] + body.replace(DISPATCH, DISPATCH + HOOK) + text[b:])


def reverse_sip_invite_transport(name, text):
    text = reverse_sip_early_transaction_transport(name, text)
    if name != 'a82.smali':
        return text
    if 'SipInviteTransport;->' not in text:
        return text
    a, b, body = _method(text)
    assert body.count(DISPATCH + HOOK) == 1
    body = body.replace(DISPATCH + HOOK, DISPATCH)
    assert hashlib.sha256(body.encode()).hexdigest() == BASE_METHOD_SHA256
    restored = text[:a] + body + text[b:]
    assert hashlib.sha256(restored.encode()).hexdigest() == BASE_CLASS_SHA256
    return restored


def verify_sip_invite_transport(smali):
    text = (Path(smali) / 'a82.smali').read_text()
    assert text.count(DISPATCH + HOOK) == 1
    reverse_sip_invite_transport('a82.smali', text)
    return {
        'hook': 'a82.f native queued fallback, after successful o82.C return',
        'scope': 'same original outgoing INVITE Call-ID, CSeq, From, URI, complete rewritten Via',
        'mutation': 'stored original Via only; branch, sent-by and all other parameters retained',
        'timer': 'reuse matching original pre-provisional TCP timer; preserve final deadline',
        'new_timer': False,
        'native_callback_exactly_reversible': True,
        'real_carrier_tested': False,
    }
