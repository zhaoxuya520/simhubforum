"""Read-only, redacted CTExcel call setup observations; apply after existing SIP fixes."""
from pathlib import Path
import hashlib

PINS = {
    'public final C(Lkb4;)V': '1fd8d04ad49358790f014d8b0b361c44d7450fcfb1a38a10e81181bbb12840a5',
    'public final h(Lkb4;)Z': '5992ab4e05f97a9e75eb7a95e65c5925d8bc17b81835b3845bcf5829731320e9',
}
SEND_OLD = '    .locals 11\n\n    .line 1\n'
SEND_NEW = ('    .locals 11\n\n'
            '    # sip_call_diagnostics_submit\n'
            '    invoke-static {p0, p1}, Lcc/forserein/simhub/internal/SipCallDiagnostics;->outgoing(Ljava/lang/Object;Ljava/lang/Object;)V\n\n'
            '    .line 1\n')
RECEIVE_OLD = ('    move-object/from16 v1, p1\n\n'
               '    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/SipInviteSuccess;->handle')
RECEIVE_NEW = ('    move-object/from16 v1, p1\n\n'
               '    # sip_call_diagnostics_receive\n'
               '    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/SipCallDiagnostics;->incoming(Ljava/lang/Object;Ljava/lang/Object;)V\n\n'
               '    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/SipInviteSuccess;->handle')
EDITS = {
    'public final C(Lkb4;)V': (SEND_OLD, SEND_NEW),
    'public final h(Lkb4;)Z': (RECEIVE_OLD, RECEIVE_NEW),
}


def _method(text, signature):
    start = text.index('.method ' + signature)
    end = text.index('.end method', start) + len('.end method')
    return start, end, text[start:end]


def apply_sip_call_diagnostics(smali):
    path = Path(smali) / 'o82.smali'
    text = path.read_text()
    for signature, pin in PINS.items():
        start, end, body = _method(text, signature)
        assert hashlib.sha256(body.encode()).hexdigest() == pin, signature + ': unexpected native baseline'
        old, new = EDITS[signature]
        assert body.count(old) == 1, signature + ': non-unique observation anchor'
        body = body.replace(old, new)
        text = text[:start] + body + text[end:]
    path.write_text(text)


def reverse_sip_call_diagnostics(name, text):
    if name != 'o82.smali' or 'SipCallDiagnostics;->' not in text:
        return text
    for signature, pin in PINS.items():
        start, end, body = _method(text, signature)
        old, new = EDITS[signature]
        assert body.count(new) == 1, signature + ': incomplete diagnostic hook'
        body = body.replace(new, old)
        assert hashlib.sha256(body.encode()).hexdigest() == pin, signature + ': unrelated instructions changed'
        text = text[:start] + body + text[end:]
    assert 'SipCallDiagnostics;->' not in text and 'sip_call_diagnostics_' not in text
    return text


def verify_sip_call_diagnostics(smali):
    text = (Path(smali) / 'o82.smali').read_text()
    for old, new in EDITS.values():
        assert text.count(new) == 1
    reverse_sip_call_diagnostics('o82.smali', text)
    return {
        'native_methods': ['o82.C', 'o82.h'],
        'carrier_scope': 'effective configuration MCC234/MNC33',
        'observations': ['submitted INVITE/CANCEL/PRACK/UPDATE', 'received corresponding SIP responses',
                         'original transaction and early-dialog match', 'fixed early-media response tokens',
                         'SDP and option presence', 'whitelisted Reason protocol/cause and Warning code'],
        'request_delivery_claimed': False, 'response_acceptance_claimed': False,
        'packet_and_dialog_mutation': False, 'additional_call_cache': False,
        'raw_identity_address_sdp_or_reason_logged': False,
        'untrusted_header_value_limit': 2048, 'max_reason_or_warning_codes_per_line': 4,
        'max_early_media_tokens': 8, 'early_media_token_order_preserved': True,
        'max_diagnostic_line_characters': 512,
        'native_methods_exactly_reversible': True,
    }
