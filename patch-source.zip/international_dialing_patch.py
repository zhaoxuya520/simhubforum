"""Explicit optional-trunk notation at the raw call input, after CTExcel's existing overlay."""
from pathlib import Path
import hashlib

BASE_SHA256 = 'fa86d5ad41c633e3e1333de667664c0e846d24261183c9d466d289a9c3a0277a'
OLD = 'invoke-static {v1}, Lcc/forserein/simhub/internal/DialingSupport;->ascii(Ljava/lang/String;)Ljava/lang/String;'
NEW = OLD.replace('->ascii(', '->callInput(')


def apply_international_dialing(smali):
    path = Path(smali) / 'f82.smali'
    text = path.read_text()
    assert hashlib.sha256(text.encode()).hexdigest() == BASE_SHA256, 'unexpected pre-dialing call coroutine'
    assert text.count(OLD) == 1 and NEW not in text
    path.write_text(text.replace(OLD, NEW))


def reverse_international_dialing(name, text):
    if name != 'f82.smali':
        return text
    assert text.count(NEW) == 1 and OLD not in text, 'partial or changed international dialing hook'
    restored = text.replace(NEW, OLD)
    assert hashlib.sha256(restored.encode()).hexdigest() == BASE_SHA256, 'other call instructions changed'
    return restored


def verify_international_dialing(smali):
    text = (Path(smali) / 'f82.smali').read_text()
    reverse_international_dialing('f82.smali', text)
    return dict(native_method='f82.q', hook='DialingSupport.callInput',
                prior_coroutine_sha256=BASE_SHA256, whole_class_exactly_reversible=True,
                preserves_call_id_and_emergency_branches=True,
                scope='explicit international optional (0) validated against destination plans before native punctuation filtering')
