"""Coordinate every discovered multi-chip reader and protect its AID selection while suspended."""
from pathlib import Path
import shutil

def patch_chip_selection(text):
    anchor='.method public final D(Ljava/lang/String;)V\n'
    assert text.count(anchor)==1 and ':multichip_selection_allowed' not in text
    start=text.index(anchor)+len(anchor)
    local_end=text.index('\n',text.index('    .locals ',start))
    return text[:local_end]+'''\n    invoke-static {p0}, Lcc/forserein/simhub/internal/MultiChipSwitch;->allowSelection(Ljava/lang/Object;)Z
    move-result v0
    if-nez v0, :multichip_selection_allowed
    return-void
    :multichip_selection_allowed'''+text[local_end:]

def apply_multichip(smali):
    path=Path(smali)/'cg0.smali'
    text=path.read_text()
    assert text.count('new-instance p1, Lhz3;')==1
    assert text.count('Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V')==1
    text=text.replace('new-instance p1, Lhz3;', 'new-instance p1, LInternalSimMultiChipSwitch;')
    text=text.replace('Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V','LInternalSimMultiChipSwitch;-><init>(Liz3;Lqy3;ZLct0;)V')
    path.write_text(text)
    # The ordinary list toggle uses sj, while details use cg0. Both must coordinate.
    path=Path(smali)/'sj.smali'
    text=path.read_text()
    assert text.count('new-instance v0, Lhz3;')==1
    assert text.count('Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V')==1
    text=text.replace('new-instance v0, Lhz3;','new-instance v0, LInternalSimMultiChipSwitch;')
    text=text.replace('Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V','LInternalSimMultiChipSwitch;-><init>(Liz3;Lqy3;ZLct0;)V')
    path.write_text(text)
    for name in ('InternalSimMultiChipSwitch.smali','InternalSimCheckedRead.smali','InternalSimChipRead.smali','InternalSimSwitchRequest.smali','InternalSimNoRefreshCommand.smali'):
        shutil.copyfile(Path(__file__).parent/'smali'/name,Path(smali)/name)
    path=Path(smali)/'iz3.smali'
    path.write_text(patch_chip_selection(path.read_text()))


    # Catch only explicit card rejection, not an ambiguous lost response or timeout.
    path=Path(smali)/'pg1.smali'
    text=path.read_text()
    anchor='    :cond_11\n    sget-object v0, Lhh1;->Companion:Lsf1;'
    assert text.count(anchor)==1
    text=text.replace(anchor, '    :cond_11\n    iget v4, v0, Lpg1;->Z:I\n    invoke-static {v4, v3}, Lcc/forserein/simhub/internal/ProfileRefresh;->checkResult(II)V\n    sget-object v0, Lhh1;->Companion:Lsf1;')
    path.write_text(text)
    path=Path(smali)/'hz3.smali'
    text=path.read_text()
    original='invoke-virtual {v0, v2, v7, p1, p0}, Lhh1;->v(Ljava/lang/String;ILws1;Lcz4;)Ljava/lang/Object;'
    assert text.count(original)==2
    text=text.replace(original,'invoke-static {v0, v2, v7, p1, p0}, LInternalSimSwitchRequest;->start(Lhh1;Ljava/lang/String;ILws1;Lcz4;)Ljava/lang/Object;')
    path.write_text(text)
