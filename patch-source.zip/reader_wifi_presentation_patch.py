"""Project the reader Wi-Fi header from its explicit effective configuration.

The shared SIM flag, reader switch, status and connection methods stay intact.
The new country-only renderer retains the pinned native flag layout and theme;
its input and restart callback are independent of immutable SIM credentials.
Apply after config_copy_patch, which hides the obsolete profile-mismatch card.
"""
from pathlib import Path
import hashlib
import re

TARGET='fd2.smali'
READER='public static final r(Lgl5;Ljava/lang/String;Lus1;Lus1;Lus1;ZLlu1;I)V'
FLAG='public static final m(Lek5;ILlu1;II)V'
RENDERER='public static final readerWifiFlag(Ljava/lang/String;ILlu1;II)V'
METHOD_PINS={
    (TARGET,READER):'a47e73801f2aed93d8c011bdd1718a9f9dfc8b56c11574ec333e93974fb85595',
    (TARGET,FLAG):'194fccd362eebc5110ba8f5a78518419606c3f487a5033f348df68af20b29860',
}
HELPER='Lcc/forserein/simhub/internal/ReaderWifiPresentation;'
FLAG_OLD='    invoke-static {v0, v3, v8, v14, v2}, Lfd2;->m(Lek5;ILlu1;II)V'
FLAG_NEW=('    invoke-static {v1}, '+HELPER+'->country(Ljava/lang/Object;)Ljava/lang/String;\n'
    '    move-result-object v0\n'
    '    invoke-static {v0, v3, v8, v14, v2}, Lfd2;->readerWifiFlag(Ljava/lang/String;ILlu1;II)V')
SUBTITLE_OLD='''    invoke-static {v4, v5, v3}, Lxv0;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3'''
SUBTITLE_NEW=SUBTITLE_OLD+'\n\n    invoke-static {v1, v3}, '+HELPER+'->subtitle(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;\n    move-result-object v3'

def method(text,signature):
    marker='.method '+signature+'\n'
    assert text.count(marker)==1,'reader presentation method missing/duplicate: '+signature
    start=text.index(marker);end=text.index('.end method',start)+len('.end method')
    return start,end,text[start:end]

def pin(body,signature):
    assert hashlib.sha256(body.encode()).hexdigest()==METHOD_PINS[(TARGET,signature)],'unexpected reader baseline: '+signature

def renderer(flag):
    pin(flag,FLAG)
    # Keep every native layout instruction, excluding non-semantic .line metadata.
    lines=[line for line in flag.splitlines() if line.strip() and not line.strip().startswith('.line ')]
    body='\n'.join(lines).replace('.method '+FLAG,'.method '+RENDERER,1)
    body=body.replace('    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;\n','',1)
    body=body.replace('    const v1, 0x24e7ea22','    const v1, 0x2168c104',1)
    # The renderer receives country directly. No async task or pretend SIM is needed.
    start=body.index('    invoke-virtual {v0}, Lek5;->d()Ljava/lang/String;')
    stop=body.index('    check-cast v1, Ljava/lang/String;',start)+len('    check-cast v1, Ljava/lang/String;')
    body=body[:start]+'''    move-object v1, v0
    sget-object v11, Lxo0;->a:Lq8;'''+body[stop:]
    start=body.index('    new-instance v1, Ll33;')
    stop=body.index('    iput-object v1, v0, Lu04;->d:Lkt1;',start)+len('    iput-object v1, v0, Lu04;->d:Lkt1;')
    body=body[:start]+'''    move-object/from16 v1, p0
    move v2, v6
    move/from16 v3, p3
    move/from16 v4, p4
    invoke-static {v0, v1, v2, v3, v4}, '''+HELPER+'''->restartFlag(Ljava/lang/Object;Ljava/lang/String;III)V'''+body[stop:]
    assert 'Lek5;' not in body and 'Ll33;' not in body and 'Lo95;' not in body
    return body

def transform(text,reverse=False):
    _,_,flag=method(text,FLAG);extra='\n\n'+renderer(flag)+'\n'
    if reverse:
        assert text.count('.method '+RENDERER+'\n')==1 and text.endswith(extra),'country-only flag renderer changed'
        text=text[:-len(extra)]
    else:assert '.method '+RENDERER+'\n' not in text,'reader presentation already applied'
    start,end,body=method(text,READER)
    if reverse:
        assert body.count(FLAG_NEW)==1 and body.count(SUBTITLE_NEW)==1,'reader presentation hook changed/missing'
        restored=body.replace(FLAG_NEW,FLAG_OLD,1).replace(SUBTITLE_NEW,SUBTITLE_OLD,1)
        pin(restored,READER)
        return text[:start]+restored+text[end:]
    pin(body,READER)
    assert body.count(FLAG_OLD)==1 and body.count(SUBTITLE_OLD)==1,'reader presentation anchor mismatch'
    patched=text[:start]+body.replace(FLAG_OLD,FLAG_NEW,1).replace(SUBTITLE_OLD,SUBTITLE_NEW,1)+text[end:]+extra
    assert transform(patched,True)==text,'reader presentation is not exactly reversible'
    return patched

def apply_reader_wifi_presentation(smali):
    path=Path(smali)/TARGET;path.write_text(transform(path.read_text()))

def reverse_reader_wifi_presentation(name,text):
    return transform(text,True) if name==TARGET else text

def verify_reader_wifi_presentation(smali):
    text=(Path(smali)/TARGET).read_text();original=transform(text,True)
    assert transform(original)==text
    _,_,new=method(text,RENDERER)
    labels=set(re.findall(r'^\s*(:\w+)\s*$',new,re.M))
    targets=set(re.findall(r'(?:if-\w+|goto(?:/\w+)?) [^\n]*(:\w+)',new))
    assert targets<=labels,'dangling native flag branch'
    assert new.count('Llu1;->e0(I)')==1 and new.count('Llu1;->u()')==1
    return dict(native_entry=READER,renderer=RENDERER,explicit_state=True,
        original_sim_flag_unchanged=True,native_flag_layout_preserved=True,
        credential_mutation=False,global_state_lookup=False,
        switch_and_status_unchanged=True,fully_reversible=True,device_tested=False)
