"""Scope notification and delayed permission actions to the rendered native call.

All normal Telecom/headset call paths keep their original controller code. The
final b/h selection hook checks only explicitly scoped asynchronous actions.
"""
from pathlib import Path
import hashlib

EDITS=[('sj5.smali', 'public final l(Ljava/lang/Object;Lct0;)Ljava/lang/Object;', '    invoke-static {v15, v1, v2}, Lt3;->q(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;', '    invoke-static {v15, v1, v2, v4}, Lcc/forserein/simhub/internal/CallNotificationGuard;->activityIntent(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Landroid/app/PendingIntent;', 1), ('sj5.smali', 'public final l(Ljava/lang/Object;Lct0;)Ljava/lang/Object;', '    invoke-static {v15, v1, v6}, Lt3;->q(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;', '    invoke-static {v15, v1, v6, v4}, Lcc/forserein/simhub/internal/CallNotificationGuard;->activityIntent(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Landroid/app/PendingIntent;', 1), ('sj5.smali', 'public final l(Ljava/lang/Object;Lct0;)Ljava/lang/Object;', '    invoke-static {v10, v1, v2}, Lt3;->q(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;', '    invoke-static {v10, v1, v2, v4}, Lcc/forserein/simhub/internal/CallNotificationGuard;->activityIntent(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Landroid/app/PendingIntent;', 1), ('sj5.smali', 'public final l(Ljava/lang/Object;Lct0;)Ljava/lang/Object;', '    invoke-static {v1, v11, v6, v10}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;', '    invoke-static {v6, v4}, Lcc/forserein/simhub/internal/CallNotificationGuard;->bind(Landroid/content/Intent;Ljava/lang/Object;)V\n\n    invoke-static {v1, v11, v6, v10}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;', 2), ('cc/forserein/simhub/vowifi/calling/CallActionReceiver.smali', 'public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V', '    .locals 0\n\n    .line 1\n    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;\n\n    .line 2\n    .line 3\n    .line 4\n    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;\n\n    .line 5\n    .line 6\n    .line 7\n    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;\n\n    .line 8\n    .line 9\n    .line 10\n    move-result-object p0\n\n    .line 11\n    if-eqz p0, :cond_3\n\n    .line 12\n    .line 13\n    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I\n\n    .line 14\n    .line 15\n    .line 16\n    move-result p1\n\n    .line 17\n    const p2, -0x760c7f13\n\n    .line 18\n    .line 19\n    .line 20\n    if-eq p1, p2, :cond_2\n\n    .line 21\n    .line 22\n    const p2, 0x5565bd96\n\n    .line 23\n    .line 24\n    .line 25\n    if-eq p1, p2, :cond_0\n\n    .line 26\n    .line 27\n    goto :goto_0\n\n    .line 28\n    :cond_0\n    const-string p1, "cc.forserein.simhub.call.HANGUP"\n\n    .line 29\n    .line 30\n    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z\n\n    .line 31\n    .line 32\n    .line 33\n    move-result p0\n\n    .line 34\n    if-nez p0, :cond_1\n\n    .line 35\n    .line 36\n    goto :goto_0\n\n    .line 37\n    :cond_1\n    sget-object p0, Lk10;->a:Lk10;\n\n    .line 38\n    .line 39\n    invoke-static {}, Lk10;->l()V\n\n    .line 40\n    .line 41\n    .line 42\n    return-void\n\n    .line 43\n    :cond_2\n    const-string p1, "cc.forserein.simhub.call.DECLINE"\n\n    .line 44\n    .line 45\n    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z\n\n    .line 46\n    .line 47\n    .line 48\n    move-result p0\n\n    .line 49\n    if-eqz p0, :cond_3\n\n    .line 50\n    .line 51\n    invoke-static {}, Lw10;->b()V\n\n    .line 52\n    .line 53\n    .line 54\n    sget-object p0, Lk10;->a:Lk10;\n\n    .line 55\n    .line 56\n    invoke-static {}, Lk10;->e()V\n\n    .line 57\n    .line 58\n    .line 59\n    :cond_3\n    :goto_0\n    return-void\n', '    .locals 0\n    invoke-static {p2}, Lcc/forserein/simhub/internal/CallNotificationGuard;->dispatch(Landroid/content/Intent;)V\n    return-void\n', 1), ('cc/forserein/simhub/ui/call/CallActivity.smali', 'public final onCreate(Landroid/os/Bundle;)V', '    invoke-virtual {p0}, Lcc/forserein/simhub/ui/call/CallActivity;->i()V', '    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;\n    move-result-object p1\n    invoke-static {p0, p1}, Lcc/forserein/simhub/internal/CallNotificationGuard;->answerFromIntent(Ljava/lang/Object;Landroid/content/Intent;)V', 1), ('cc/forserein/simhub/ui/call/CallActivity.smali', 'public final onNewIntent(Landroid/content/Intent;)V', '    invoke-virtual {p0}, Lcc/forserein/simhub/ui/call/CallActivity;->i()V', '    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;\n    move-result-object p1\n    invoke-static {p0, p1}, Lcc/forserein/simhub/internal/CallNotificationGuard;->answerFromIntent(Ljava/lang/Object;Landroid/content/Intent;)V', 1), ('cc/forserein/simhub/ui/call/CallActivity.smali', 'public final i()V', '    iget-object v0, v0, Lc10;->a:Lu00;', '    iget-object v0, v0, Lc10;->a:Lu00;\n    invoke-static {p0, v0}, Lcc/forserein/simhub/internal/CallNotificationGuard;->prepareAnswer(Ljava/lang/Object;Ljava/lang/Object;)Z\n    move-result v1\n    if-eqz v1, :goto_0', 1), ('cc/forserein/simhub/ui/call/CallActivity.smali', 'public final i()V', '    invoke-static {}, Lk10;->b()V', '    invoke-static {p0}, Lcc/forserein/simhub/internal/CallNotificationGuard;->answerPrepared(Ljava/lang/Object;)V', 1), ('au0.smali', 'public e(Ljava/lang/Object;)V', '    check-cast p0, Lcc/forserein/simhub/ui/call/CallActivity;\n\n    .line 9\n    .line 10\n    check-cast p1, Ljava/lang/Boolean;\n\n    .line 11\n    .line 12\n    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;\n\n    .line 13\n    .line 14\n    .line 15\n    iget-boolean p1, p0, Lcc/forserein/simhub/ui/call/CallActivity;->o0:Z\n\n    .line 16\n    .line 17\n    if-eqz p1, :cond_0\n\n    .line 18\n    .line 19\n    const/4 p1, 0x0\n\n    .line 20\n    iput-boolean p1, p0, Lcc/forserein/simhub/ui/call/CallActivity;->o0:Z\n\n    .line 21\n    .line 22\n    sget-object p0, Lk10;->a:Lk10;\n\n    .line 23\n    .line 24\n    invoke-static {}, Lk10;->b()V\n\n    .line 25\n    .line 26\n    .line 27\n    :cond_0\n    return-void\n\n    .line 28\n', '    check-cast p0, Lcc/forserein/simhub/ui/call/CallActivity;\n    check-cast p1, Ljava/lang/Boolean;\n    invoke-static {p0, p1}, Lcc/forserein/simhub/internal/CallNotificationGuard;->resumePermission(Ljava/lang/Object;Ljava/lang/Boolean;)V\n    return-void\n\n', 1), ('k10.smali', 'public static b()V', '    move-result-object v1\n', '    move-result-object v1\n    invoke-static {v1}, Lcc/forserein/simhub/internal/CallNotificationGuard;->allowSelected(Ljava/lang/Object;)Z\n    move-result v2\n    if-eqz v2, :goto_0\n', 1), ('k10.smali', 'public static h()V', '    move-result-object v1\n', '    move-result-object v1\n    invoke-static {v1}, Lcc/forserein/simhub/internal/CallNotificationGuard;->allowSelected(Ljava/lang/Object;)Z\n    move-result v2\n    if-eqz v2, :goto_0\n', 1)]

# Stopping the global ringtone before permission/final call selection can silence
# a replacement call, or leave a denied-permission incoming call silently ringing.
EDITS.append(('cc/forserein/simhub/ui/call/CallActivity.smali','public final i()V',
    '    invoke-static {}, Lw10;->b()V',
    '    # Ringtone stops only after CallNotificationGuard validates the selected answer.',1))

METHOD_PINS={('sj5.smali', 'public final l(Ljava/lang/Object;Lct0;)Ljava/lang/Object;'): '2bbc25aec01eed77d777e3daf109b679c8ca033f3e36a0e076c7a746260d0e6d', ('cc/forserein/simhub/vowifi/calling/CallActionReceiver.smali', 'public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V'): '0f4f10b8ac9917009152f1eaabd83cb643d808b911d671df6fafd64a46c73614', ('cc/forserein/simhub/ui/call/CallActivity.smali', 'public final onCreate(Landroid/os/Bundle;)V'): '57868c48ca47ab8c4d485843b8b096fc2afc5238fa32fd2028a11cf1338812e3', ('cc/forserein/simhub/ui/call/CallActivity.smali', 'public final onNewIntent(Landroid/content/Intent;)V'): '2226921241e72124252136abebb6d679dd9112d8158b784e4b28e75a1bc25498', ('cc/forserein/simhub/ui/call/CallActivity.smali', 'public final i()V'): 'af07ceff63b7bb3a215b4fc17c57bea675a3caaf4426a6a98788ceebaf4c0e30', ('au0.smali', 'public e(Ljava/lang/Object;)V'): '4f95943d58cb232a1dee95a771855f1b974ba59c10602e91f326e322e869203b', ('k10.smali', 'public static b()V'): '378fdf830c6ef734ca5fdc5dc1761e845f75b5030da24a1c874a78ba8781ea4b', ('k10.smali', 'public static h()V'): '0f04d6208cbe1ad116368c8c88bdb43c4eb7da8e44acdd31d91cf89176b0e52b'}

def _method(text,signature):
    start=text.index('.method '+signature+'\n')
    end=text.index('.end method',start)+len('.end method')
    return start,end,text[start:end]


def _edit(text,signature,old,new,count):
    start,end,body=_method(text,signature)
    assert body.count(old)==count,(signature,'unexpected bounded notification hook',body.count(old))
    return text[:start]+body.replace(old,new)+text[end:]


def reverse_notification_actions(name,text):
    for target,signature,old,new,count in reversed(EDITS):
        if target==name:text=_edit(text,signature,new,old,count)
    for (target,signature),digest in METHOD_PINS.items():
        if target==name:assert hashlib.sha256(_method(text,signature)[2].encode()).hexdigest()==digest,(name,signature,'native method changed outside notification hook')
    return text


def apply_notification_actions(smali):
    for name in sorted({entry[0] for entry in EDITS}):
        path=Path(smali)/name;text=path.read_text()
        for (target,signature),digest in METHOD_PINS.items():
            if target==name:assert hashlib.sha256(_method(text,signature)[2].encode()).hexdigest()==digest,(name,signature,'unexpected baseline')
        for target,signature,old,new,count in EDITS:
            if target==name:text=_edit(text,signature,old,new,count)
        path.write_text(text)


def verify_notification_actions(smali):
    for name in sorted({entry[0] for entry in EDITS}):
        reverse_notification_actions(name,(Path(smali)/name).read_text())
    return {'native_methods':['sj5.l','CallActionReceiver.onReceive','CallActivity.onCreate','CallActivity.onNewIntent','CallActivity.i','au0.e (only CallActivity branch)','k10.b','k10.h'],
        'identity':'native SIP call ID plus per-call UUID token in extras and unique PendingIntent data URI',
        'notification':'rendered call snapshot; missing/stale identities fail closed; SHOW unchanged',
        'permission':'grant must be true, pending answer consumed once, still same incoming call',
        'ringtone':'answer stops only at the validated final native selection; unresolved/denied/stale permission leaves it unchanged',
        'final_native_selection':'scoped identity check after k10.b/h select the object passed to native d10 coroutine',
        'telecom_headset_paths':'unscoped native commands preserved',
        'media_and_sip_unchanged':True,'device_carrier_verified':False}
