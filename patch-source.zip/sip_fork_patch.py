"""Early, bounded fork isolation before native dialog/transaction mutation."""
from pathlib import Path
import hashlib
from sip_invite_failure_patch import reverse_sip_invite_failure
from sip_invite_success_patch import reverse_sip_invite_success
from sip_incoming_invite_patch import reverse_sip_incoming_invite
from sip_precondition_patch import reverse_sip_precondition
FORK_CLASSES={'o82.smali'}
SIGNATURE='public final h(Lkb4;)Z'
REQUEST_SIGNATURE='public final r(Lkb4;Loc2;Ljava/lang/String;)V'
BASE_METHOD_SHA256='a7e43d44d578ca3b09aa47841c446f014564468968286f2f0af68ecc4c2b7fa3'
REQUEST_BASE_SHA256='1c2d5040990d3e0faa1327ff8c88fbfbb89039e4acad40cdec978bc6e9dca6c3'
REQUEST_OLD='    move-object/from16 v1, p3\n'
REQUEST_NEW=REQUEST_OLD+'\n    invoke-static {v0, v11, v3}, Lcc/forserein/simhub/internal/SipForkProtection;->handleRequest(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z\n    move-result v2\n    if-eqz v2, :sip_fork_native_request\n    return-void\n    :sip_fork_native_request\n'
OLD='    move-object/from16 v1, p1\n'
NEW='    move-object/from16 v1, p1\n\n    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/SipForkProtection;->handle(Ljava/lang/Object;Ljava/lang/Object;)Z\n    move-result v2\n    if-eqz v2, :sip_fork_native_response\n    const/4 v2, 0x1\n    return v2\n    :sip_fork_native_response\n'

def _body(text,signature=SIGNATURE):
 a=text.index('.method '+signature);b=text.index('.end method',a)+len('.end method')
 return a,b,text[a:b]

def reverse_sip_fork(name,text):
 text=reverse_sip_precondition(name,text)
 if name!='o82.smali':return text
 text=reverse_sip_incoming_invite(name,text)
 text=reverse_sip_invite_success(name,text)
 text=reverse_sip_invite_failure(name,text)
 a,b,body=_body(text);assert body.count(NEW)==1
 body=body.replace(NEW,OLD)
 assert hashlib.sha256(body.encode()).hexdigest()==BASE_METHOD_SHA256,'native timer/response instructions changed'
 text=text[:a]+body+text[b:]
 a,b,body=_body(text,REQUEST_SIGNATURE);assert body.count(REQUEST_NEW)==1
 body=body.replace(REQUEST_NEW,REQUEST_OLD)
 assert hashlib.sha256(body.encode()).hexdigest()==REQUEST_BASE_SHA256,'native request instructions changed'
 return text[:a]+body+text[b:]

def apply_sip_fork(smali):
 p=Path(smali)/'o82.smali';text=p.read_text();a,b,body=_body(text)
 assert hashlib.sha256(body.encode()).hexdigest()==BASE_METHOD_SHA256,'apply after SIP timer patch'
 assert body.count(OLD)==1
 text=text[:a]+body.replace(OLD,NEW)+text[b:]
 a,b,body=_body(text,REQUEST_SIGNATURE)
 assert hashlib.sha256(body.encode()).hexdigest()==REQUEST_BASE_SHA256
 assert body.count(REQUEST_OLD)==1
 p.write_text(text[:a]+body.replace(REQUEST_OLD,REQUEST_NEW)+text[b:])

def verify_sip_fork(smali):
 reverse_sip_fork('o82.smali',(Path(smali)/'o82.smali').read_text())
 return {'guard':'selected outgoing original INVITE 2xx, differing nonempty To-tag',
  'response_hook':'before native transaction/dialog/SDP mutation','fork_tag_cap':64,
  'cache':'weak original dialog key; values have no original/manager/engine reference',
  'duplicate':'ACK every time; BYE constructed once, at most two send attempts on failure',
  'request_hook':'before native request dispatch; known fork BYE 200, other differing legs 481, ACK consumed',
  'unchanged':'matching selected-dialog tags, unselected CANCEL race, CANCEL transaction dispatch',
  'invalid_tags':'extra INVITE2xx consumed; invalid in-dialog requests 481/ACK silent',
  'device_tested':False}
