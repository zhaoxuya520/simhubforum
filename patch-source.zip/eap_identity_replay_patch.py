"""Replay a session's most recent successful AKA-Identity reply without rehashing it.

Only da1 owns the cache. Native coroutine resumes, AKA challenge processing,
transcript reset/cleanup, and key derivation remain unchanged.
"""
from pathlib import Path
import hashlib

BASE_SHA256 = '78b3558ac89325d7fc699facad3edd34c38ef34749334c6ab668a1e1d5fd286e'
HELPER = 'Lcc/forserein/simhub/internal/EapIdentityReplay;'
FIELD = '\n.field private final simhubIdentityReplay:' + HELPER + '\n'
CONSTRUCTOR = 'public constructor <init>(Ljava/lang/String;Ls01;)V'
PROCESS = 'public final b([BLdt0;)Ljava/lang/Object;'

EDITS = [
    (None, '.field public l:Z\n', '.field public l:Z\n' + FIELD),
    (CONSTRUCTOR,
     '    iput-object p1, p0, Lda1;->e:Ljava/io/ByteArrayOutputStream;\n',
     '    iput-object p1, p0, Lda1;->e:Ljava/io/ByteArrayOutputStream;\n'
     '\n    new-instance p1, ' + HELPER + '\n'
     '    invoke-direct {p1}, ' + HELPER + '-><init>()V\n'
     '    iput-object p1, p0, Lda1;->simhubIdentityReplay:' + HELPER + '\n'),
    (PROCESS,
     '    :cond_2\n    const/16 v18, 0x0\n\n    .line 90\n    .line 91\n    invoke-static {v2}, Loc2;->N(Ljava/lang/Object;)V\n',
     '    :cond_2\n    const/16 v18, 0x0\n\n    .line 90\n    .line 91\n    invoke-static {v2}, Loc2;->N(Ljava/lang/Object;)V\n'
     '\n    iget-object v2, v0, Lda1;->simhubIdentityReplay:' + HELPER + '\n'
     '    invoke-virtual {v13}, Ljava/io/ByteArrayOutputStream;->size()I\n'
     '    move-result v4\n'
     '    invoke-virtual {v2, v1, v4}, ' + HELPER + '->replay([BI)[B\n'
     '    move-result-object v2\n'
     '    if-eqz v2, :simhub_identity_not_replayed\n'
     '    new-instance v0, Lz91;\n'
     '    invoke-direct {v0, v2}, Lz91;-><init>([B)V\n'
     '    return-object v0\n'
     '    :simhub_identity_not_replayed\n'),
    (PROCESS,
     '    .line 603\n    invoke-static {v13, v0}, Lei0;->j(Ljava/io/ByteArrayOutputStream;[B)V\n',
     '    .line 603\n    invoke-static {v13, v0}, Lei0;->j(Ljava/io/ByteArrayOutputStream;[B)V\n'
     '\n    move-object/from16 v2, p0\n'
     '    iget-object v2, v2, Lda1;->simhubIdentityReplay:' + HELPER + '\n'
     '    invoke-virtual {v13}, Ljava/io/ByteArrayOutputStream;->size()I\n'
     '    move-result v3\n'
     '    invoke-virtual {v2, v0, v3}, ' + HELPER + '->record([BI)V\n'),
]


def _replace(text, signature, old, new):
    start, end = 0, len(text)
    if signature is not None:
        start = text.index('.method ' + signature + '\n')
        end = text.index('.end method', start) + len('.end method')
    body = text[start:end]
    assert body.count(old) == 1, (signature, 'unexpected EAP replay hook count', body.count(old))
    return text[:start] + body.replace(old, new) + text[end:]


def transform_native(text):
    assert hashlib.sha256(text.encode()).hexdigest() == BASE_SHA256, 'unexpected native da1 baseline'
    for signature, old, new in EDITS:
        text = _replace(text, signature, old, new)
    return text


def restore_native(text):
    for signature, old, new in reversed(EDITS):
        text = _replace(text, signature, new, old)
    assert hashlib.sha256(text.encode()).hexdigest() == BASE_SHA256, 'da1 changed outside bounded EAP replay hooks'
    return text


def apply_eap_identity_replay(smali):
    path = Path(smali) / 'da1.smali'
    path.write_text(transform_native(path.read_text()))


def verify_eap_identity_replay(smali):
    restore_native((Path(smali) / 'da1.smali').read_text())
    return {'native_class': 'da1', 'native_baseline_sha256': BASE_SHA256,
            'native_methods': ['da1.<init>', 'da1.b initial coroutine entry and successful subtype 5 return'],
            'scope': 'one most recent successful AKA-Identity exchange per native EAP session',
            'key': 'complete declared EAP bytes and unchanged native transcript size',
            'responses': 'independent copies; exact replay bypasses native transcript append',
            'challenge_and_key_derivation_unchanged': True,
            'full_native_class_exactly_restorable': True,
            'physical_card_or_gateway_tested': False}
