# SIMHub 25.5 通话翻译中转

手机通过 HTTPS 连接自己的中转。字幕模式按语句上传对方的声音，由 Gemini 3.5 Flash-Lite 翻译。同声传译模式通过 Gemini 3.5 Live Translate Preview 同时接收译音和字幕。手机把译音送到通话的听筒、扬声器或耳机。语音、字幕和上游会话均在内存中处理。Google 按所属项目的条款、地区、模型权限和配额处理请求。

## Ubuntu 安装

准备可从手机访问的域名，解析到服务器。公网放行 TCP 443；如果用 Caddy 的 HTTP 验证，也放行 TCP 80。安装 Python 3.10+、python3-venv 和 Caddy。将此压缩包中的文件解压到 /opt/simhub-translation，使服务账号可读取程序。

    cd /opt/simhub-translation
    sudo chmod 755 /opt/simhub-translation
    sudo chmod 644 relay.py requirements.txt
    sudo python3 -m venv .venv
    sudo .venv/bin/pip install -r requirements.txt
    id simhub-translation >/dev/null 2>&1 || sudo useradd --system --home-dir /var/lib/simhub-translation --shell /usr/sbin/nologin simhub-translation
    sudo install -m 644 simhub-translation.service /etc/systemd/system/
    sudo install -m 600 /dev/null /etc/simhub-translation.env
    sudoedit /etc/simhub-translation.env

最后两条用于首次安装。已有密钥文件时直接编辑。填写一行 GEMINI_API_KEY=你的Google项目密钥。该密钥由 Google 项目签发，留在服务器。把 Caddyfile.example 里的示例域名换成实际域名，并将站点段添加到当前 Caddy 配置。系统服务只监听本机 8871，反向代理需要支持流式请求与响应。

    sudo systemctl daemon-reload
    sudo systemctl enable --now simhub-translation
    sudo caddy validate --config /etc/caddy/Caddyfile
    sudo systemctl reload caddy

## 配对和使用

服务启动后运行以下命令。把域名替换为自己的 HTTPS 地址。每台手机单独执行一次。

    sudo -u simhub-translation /opt/simhub-translation/.venv/bin/python /opt/simhub-translation/relay.py --devices /var/lib/simhub-translation/devices --pair https://relay.example.com

终端会显示配对链接和用于撤销的 Device ID。完整复制到 SIMHub 拨号页的「通话翻译」设置，分别设置「通话字幕」和「同声传译」开关及各自的语言。通话中也可点右上角齿轮。语言相同时共用一条实时流，选择不同语言时单独请求字幕和译音，两项可能分别计费。点「测试密钥」会用服务器生成的短静音片段测试字幕模型，同时尝试建立并关闭一个同传会话，分别显示权限结果。此测试可能消耗少量配额。断开中转后恢复原声。实时翻译是预览服务，延迟受网络和模型影响。粤语可选作纯字幕目标，葡萄牙语译音使用 pt-PT。

配对链接是该设备的访问凭据，私下交付。服务器只保存设备令牌的 SHA-256 摘要。撤销时，删除 devices 下与 Device ID 同名的文件。新请求随即失效，运行中的语音会话会在下一次清理时结束（约 5 秒）。备份 Google 密钥和 devices 目录时单独加密保存。APK 签名与运营商 SIM 认证沿用各自已有流程。

## 测试

运行 python -m unittest -v test_relay。测试使用本机模拟的 Google HTTP 和 WebSocket 服务，以及运行时生成的测试配对。无需 Google 密钥。
