"""Run the Java media backend through a real TLS relay and a local fake Google endpoint."""

import argparse
import asyncio
import os
from pathlib import Path
import ssl
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from aiohttp.test_utils import TestServer
from test_relay import RelayTests


async def run(args):
    base = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory() as work:
        folder = Path(work)

        def command(*argv):
            subprocess.run(
                argv,
                cwd=folder,
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )

        command(
            "openssl",
            "req",
            "-x509",
            "-nodes",
            "-newkey",
            "rsa:2048",
            "-subj",
            "/CN=localhost",
            "-days",
            "1",
            "-addext",
            "subjectAltName=DNS:localhost,IP:127.0.0.1",
            "-keyout",
            "server.key",
            "-out",
            "cert.pem",
        )
        command(
            "keytool",
            "-importcert",
            "-noprompt",
            "-file",
            "cert.pem",
            "-keystore",
            "trust.p12",
            "-storetype",
            "PKCS12",
            "-storepass",
            "localhost-test",
        )
        cp = [str(args.json_jar.resolve())]
        sources = [base / "LiveProbe.java"]
        if args.probe_jar:
            cp.append(str(args.probe_jar.resolve()))
        else:
            root = (
                base.parents[1]
                / "android/phone-slot-patch/src/cc/forserein/simhub/internal"
            )
            sources.extend(
                root / name
                for name in [
                    "CaptionBackend.java",
                    "CaptionLive.java",
                    "CaptionRelay.java",
                ]
            )
        compiler = (
            ["java", "-jar", args.ecj, "-17", "-proc:none"] if args.ecj else ["javac"]
        )
        command(
            *compiler,
            "-encoding",
            "UTF-8",
            "-cp",
            os.pathsep.join(cp),
            "-d",
            folder,
            *sources,
        )
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(folder / "cert.pem", folder / "server.key")
        fixture = RelayTests()
        await fixture.asyncSetUp()
        server = TestServer(fixture.relay_app())
        try:
            await server.start_server(ssl=context)
            for rate in (8000, 16000):
                fixture.received.clear()
                origin = f"https://127.0.0.1:{server.port}"
                link = origin + "/#" + fixture.pair_phone()
                proc = await asyncio.create_subprocess_exec(
                    "java",
                    "-noverify",
                    "-Djavax.net.ssl.trustStore=" + str(folder / "trust.p12"),
                    "-Djavax.net.ssl.trustStorePassword=localhost-test",
                    "-cp",
                    os.pathsep.join([str(folder), *cp]),
                    "cc.forserein.simhub.internal.LiveProbe",
                    link,
                    str(rate),
                )
                try:
                    status = await asyncio.wait_for(proc.wait(), 16)
                finally:
                    if proc.returncode is None:
                        proc.kill()
                        await proc.wait()
                assert status == 0 and any(
                    b"\xd2\x04" in buf for buf in fixture.received if isinstance(buf,bytes)
                )
        finally:
            await server.close()
            await fixture.asyncTearDown()


if __name__ == "__main__":
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument("--json-jar", type=Path, required=True)
    args.add_argument("--ecj", type=Path)
    args.add_argument("--probe-jar", type=Path)
    asyncio.run(run(args.parse_args()))
