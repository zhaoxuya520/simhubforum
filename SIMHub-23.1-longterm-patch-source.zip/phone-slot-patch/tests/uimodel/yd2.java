import java.util.*;
public class yd2 {
 public static final Map<String,String> values=new LinkedHashMap<>();
 public static void d(String label,String value,lu1 c,int flags){ak2.labels.add(label);values.put(label,value);}
}
