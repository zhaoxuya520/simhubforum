import cc.forserein.simhub.internal.*;
import android.app.Activity;
import android.os.Handler;
import android.widget.Toast;
import java.util.*;

/** Actual editor Java callbacks with platform/Compose doubles; styling checked against original smali. */
public class WifiConfigUiTest {
 static int passed,closed;
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);passed++;}
 static void waitForSave() throws Exception {
  long end=System.nanoTime()+2_000_000_000L;
  while(Handler.tasks.isEmpty() && System.nanoTime()<end)Thread.sleep(5);
  check(!Handler.tasks.isEmpty(),"save completes");Handler.drain();
 }
 public static void main(String[] args)throws Exception {
  WifiConfigTest.Ctx ctx=new WifiConfigTest.Ctx();zl5.f=ctx;
  ek5 card=new ek5("001010000000001","ui-test-profile");
  zl5.b.value=WifiConfigTest.state(card,zl3.r(card));
  Activity activity=new Activity();us1 close=()->{closed++;return sc5.a;};
  us1 done=(us1)WifiConfigEditor.begin(activity,close);
  check(done!=close && activity.app.callbacks.size()==1,"page lifecycle and Done intercepted");
  check(WifiConfigEditor.begin(activity,close)==done,"recomposition reuses session");
  lu1 composer=new lu1();
  WifiConfigEditor.row("Domain","ims.example.org",composer,6);
  check(ak2.row.mode==3 && ak2.row.label.equals("Domain") && ak2.row.value.equals("ims.example.org"),"original row renderer and value retained");
  check(ak2.click!=null && composer.depth==0,"row clickable, composition group balanced");
  ak2.click.a();WifiConfigEditor.overlay(composer);
  check(xq0.title.equals("Domain") && ak2.edits.size()==1,"original alert contains selected field only");
  check(ak2.edits.get(0).value.isEmpty() && ak2.edits.get(0).hint.contains("ims.example.org"),"default is hint, no implicit override");
  ak2.edits.get(0).change.i("custom.example.org");xq0.press("取消");
  WifiConfigEditor.row("Domain","ims.example.org",composer,6);
  check(ak2.row.value.equals("ims.example.org"),"popup cancel discards typing");
  ak2.click.a();WifiConfigEditor.overlay(composer);ak2.edits.get(0).change.i("bad\nheader");xq0.press("确定");WifiConfigEditor.overlay(composer);
  check(!xq0.message.contains("右上角") && ak2.edits.get(0).value.contains("header"),"invalid value stays in alert with error");
  ak2.edits.get(0).change.i("custom.example.org");xq0.press("确定");
  WifiConfigEditor.row("Domain","ims.example.org",composer,6);
  check(ak2.row.value.equals("custom.example.org"),"confirmation previews staged value");
  check(ctx.prefs.data.isEmpty() && ((gl5)zl5.b.value).f.g.equals("ims.example.org"),"staged values not persisted or applied to engine");
  check(WifiConfigEditor.editLegacy(17,"49"),"existing IMEI callback intercepted");
  check(WifiConfigEditor.scalar("old",17).equals("49"),"partial IMEI text retained");
  check(!WifiConfigEditor.imeiValid(zl5.b.value) && WifiConfigEditor.imeiText("old").equals("49"),"original IMEI inline validation follows partial draft");
  done.a();check(closed==0 && Toast.last.contains("IMEI"),"Done validates entire page without closing on invalid input");
  WifiConfigEditor.editLegacy(17,"490154203237518");
  check(WifiConfigEditor.imeiValid(zl5.b.value),"valid draft clears original IMEI error");
  WifiConfigEditor.editLegacy(17,"");
  WifiConfigEditor.editLegacy(18,"+441234567890");
  ((us1)WifiConfigEditor.cancelCallback(close)).a();
  check(closed==1 && ctx.prefs.data.isEmpty() && activity.app.callbacks.isEmpty(),"sheet cancel discards all changes and unregisters lifecycle");
  check(!WifiConfigEditor.editLegacy(17,"12"),"callbacks outside page retain legacy path");
  done=(us1)WifiConfigEditor.begin(activity,close);
  WifiConfigEditor.row("IKE","aes256 sha256 sha256 modp2048",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);
  check(ak2.edits.size()==4,"IKE aggregate opens four algorithm fields");
  ak2.edits.get(0).change.i("aes128");ak2.edits.get(1).change.i("sha256");xq0.press("确定");
  WifiConfigEditor.row("IKE","aes256 sha256 sha256 modp2048",composer,6);
  check(ak2.row.value.equals("aes128 sha256 sha256 modp2048"),"aggregate display keeps original format");
  done.a();done.a();waitForSave();
  check(closed==2 && ((gl5)zl5.b.value).f.j.equals(Arrays.asList("aes128")),"Done commits staged algorithms once");
  check(WifiConfigRuntime.snapshot().values.get("ike_encr").equals("aes128"),"save persists across reopening");
  done=(us1)WifiConfigEditor.begin(activity,close);
  WifiConfigEditor.row("IKE","aes128 sha256 sha256 modp2048",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);xq0.press("使用内置");
  WifiConfigEditor.overlay(composer);check(ak2.edits.get(0).value.equals(""),"restore only clears popup draft");
  xq0.press("确定");done.a();waitForSave();
  check(((gl5)zl5.b.value).f.j.equals(Arrays.asList("aes256")),"clear then Done restores original algorithm list");
  done=(us1)WifiConfigEditor.begin(activity,close);
  WifiConfigEditor.row("NAI","anonymous@nai.example.org",composer,6);ak2.click.a();WifiConfigEditor.overlay(composer);
  check(ak2.edits.size()==4,"identity advanced edits don't add main-page rows");
  xq0.press("取消");
  WifiConfigEditor.editLegacy(17,"49");activity.destroy();
  check(activity.app.callbacks.isEmpty() && !WifiConfigEditor.editLegacy(17,"50"),"destroyed activity releases draft and callbacks");
  check(composer.depth==0,"all editor composition groups balanced");
  System.out.println("PASS: "+passed+" original-UI callback assertions (platform/Compose doubles)");
 }
}
