public class yd2 {public static void d(String label,String value,lu1 c,int flags){ak2.labels.add(label);}}
