import java.util.*;
public class xq0 {
 public static String title,message;public static List<cj2> buttons;public static us1 cancel;
 @SuppressWarnings("unchecked")
 public static void k(String title,List buttons,us1 cancel,String message,boolean b,lt1 body,lu1 c,int flags,int mask){
  xq0.title=title;xq0.buttons=buttons;xq0.cancel=cancel;xq0.message=message;
  ak2.edits.clear();ak2.labels.clear();body.d(new Object(),c,0);
 }
 public static void press(String title){for(cj2 b:buttons)if(b.a.equals(title)){b.d.a();return;}throw new AssertionError(title);}
}
