.class public final LInternalSimMultiChipSwitch;
.super Lcz4;
.implements Lkt1;

.field public final owner:Liz3;
.field public final target:Lqy3;
.field public final enable:Z
.field public backend:Lhh1;
.field public plan:Lcc/forserein/simhub/internal/MultiChipSwitch;
.field public state:I

.method public constructor <init>(Liz3;Lqy3;ZLct0;)V
    .locals 1
    const/4 v0, 0x2
    invoke-direct {p0, v0, p4}, Lcz4;-><init>(ILct0;)V
    iput-object p1, p0, LInternalSimMultiChipSwitch;->owner:Liz3;
    iput-object p2, p0, LInternalSimMultiChipSwitch;->target:Lqy3;
    iput-boolean p3, p0, LInternalSimMultiChipSwitch;->enable:Z
    return-void
.end method

.method public final o(Lct0;Ljava/lang/Object;)Lct0;
    .locals 4
    new-instance v0, LInternalSimMultiChipSwitch;
    iget-object v1, p0, LInternalSimMultiChipSwitch;->owner:Liz3;
    iget-object v2, p0, LInternalSimMultiChipSwitch;->target:Lqy3;
    iget-boolean v3, p0, LInternalSimMultiChipSwitch;->enable:Z
    invoke-direct {v0, v1, v2, v3, p1}, LInternalSimMultiChipSwitch;-><init>(Liz3;Lqy3;ZLct0;)V
    check-cast p2, Lhh1;
    iput-object p2, v0, LInternalSimMultiChipSwitch;->backend:Lhh1;
    return-object v0
.end method

.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0
    check-cast p2, Lct0;
    invoke-virtual {p0, p2, p1}, LInternalSimMultiChipSwitch;->o(Lct0;Ljava/lang/Object;)Lct0;
    move-result-object p0
    check-cast p0, LInternalSimMultiChipSwitch;
    sget-object p1, Lsc5;->a:Lsc5;
    invoke-virtual {p0, p1}, LInternalSimMultiChipSwitch;->q(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p0
    return-object p0
.end method

.method public final q(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    sget-object v0, Lpu0;->T:Lpu0;
    iget-object v1, p0, LInternalSimMultiChipSwitch;->backend:Lhh1;
    iget-object v2, p0, LInternalSimMultiChipSwitch;->owner:Liz3;
    :try_start
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    iget v3, p0, LInternalSimMultiChipSwitch;->state:I
    if-nez v3, :advance
    iget-object v3, v1, Lhh1;->a:Lqg0;
    instance-of v3, v3, Ls4;
    if-eqz v3, :original
    new-instance v3, Lcc/forserein/simhub/internal/MultiChipSwitch;
    iget-object v4, p0, LInternalSimMultiChipSwitch;->target:Lqy3;
    iget-boolean v5, p0, LInternalSimMultiChipSwitch;->enable:Z
    invoke-direct {v3, v2, v4, v5}, Lcc/forserein/simhub/internal/MultiChipSwitch;-><init>(Ljava/lang/Object;Ljava/lang/Object;Z)V
    iput-object v3, p0, LInternalSimMultiChipSwitch;->plan:Lcc/forserein/simhub/internal/MultiChipSwitch;
    :advance
    iget v3, p0, LInternalSimMultiChipSwitch;->state:I
    const/4 v4, 0x3
    if-eq v3, v4, :done
    iget-object v3, p0, LInternalSimMultiChipSwitch;->plan:Lcc/forserein/simhub/internal/MultiChipSwitch;
    invoke-virtual {v3, p1}, Lcc/forserein/simhub/internal/MultiChipSwitch;->next(Ljava/lang/Object;)V
    iget v4, v3, Lcc/forserein/simhub/internal/MultiChipSwitch;->kind:I
    if-eqz v4, :done
    const/4 v5, 0x1
    if-ne v4, v5, :change
    iput v5, p0, LInternalSimMultiChipSwitch;->state:I
    const/4 v4, 0x0
    iput-boolean v4, v1, Lhh1;->d:Z
    iput-boolean v4, v1, Lhh1;->e:Z
    new-instance v3, Lkg1;
    const/4 v4, 0x0
    invoke-direct {v3, v1, v4, v5}, Lkg1;-><init>(Lhh1;Lct0;I)V
    invoke-static {v3, p0}, Lhh1;->s(Lws1;Ldt0;)Ljava/lang/Object;
    move-result-object p1
    if-eq p1, v0, :suspended
    goto :advance
    :change
    const/4 v4, 0x2
    iput v4, p0, LInternalSimMultiChipSwitch;->state:I
    iget-object v4, v3, Lcc/forserein/simhub/internal/MultiChipSwitch;->profile:Ljava/lang/Object;
    check-cast v4, Lqy3;
    iget-boolean v5, v3, Lcc/forserein/simhub/internal/MultiChipSwitch;->enabled:Z
    goto :run_change
    :original
    const/4 v3, 0x3
    iput v3, p0, LInternalSimMultiChipSwitch;->state:I
    iget-object v4, p0, LInternalSimMultiChipSwitch;->target:Lqy3;
    iget-boolean v5, p0, LInternalSimMultiChipSwitch;->enable:Z
    :run_change
    new-instance v3, Lhz3;
    const/4 v6, 0x0
    invoke-direct {v3, v2, v4, v5, v6}, Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V
    invoke-virtual {v3, v1, p0}, Lhz3;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p1
    if-eq p1, v0, :suspended
    goto :advance
    :done
    sget-object v0, Lsc5;->a:Lsc5;
    :try_end
    .catchall {:try_start .. :try_end} :failed
    :suspended
    return-object v0
    :failed
    move-exception v0
    iget-object v1, p0, LInternalSimMultiChipSwitch;->plan:Lcc/forserein/simhub/internal/MultiChipSwitch;
    if-eqz v1, :throw
    invoke-virtual {v1}, Lcc/forserein/simhub/internal/MultiChipSwitch;->restore()V
    :throw
    throw v0
.end method
