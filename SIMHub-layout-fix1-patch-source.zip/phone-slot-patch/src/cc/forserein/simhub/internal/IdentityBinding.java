package cc.forserein.simhub.internal;

import java.lang.ref.WeakReference;
import java.util.*;
import android.util.Log;

/** Binds a modem-owned USIM read to the management selection without inventing an IMSI. */
public final class IdentityBinding {
    private static final Map<Object,WeakReference<Object>> owners=new WeakHashMap<>();
    public static synchronized void track(Object transport,Object controller){
        if(transport!=null)owners.put(transport,new WeakReference<>(controller));
    }
    private static Object get(Object o,String name)throws Exception{return o.getClass().getField(name).get(o);}
    private static Object call(Object o,String name)throws Exception{return o.getClass().getMethod(name).invoke(o);}
    public static String tail(String value){if(value==null)return "unknown";return "…"+value.substring(Math.max(0,value.length()-4));}
    private static String iccid(String value){return value==null?"":value.replaceAll("[\\sFf]","");}
    public static void read(Object transport,Object auth,Object card)throws Exception {
        Object owner; synchronized(IdentityBinding.class){WeakReference<Object> ref=owners.get(transport);owner=ref==null?null:ref.get();}
        String actual=String.valueOf(get(card,"b"));
        String imsi=String.valueOf(get(card,"a"));
        String expected=null,eid=null;
        if(owner!=null) {
            eid=String.valueOf(call(owner,"r"));
            for(Object chip:(List<?>)call(owner,"l"))if(eid.equals(get(chip,"b"))) {
                for(Object p:(List<?>)get(chip,"d"))if(Boolean.TRUE.equals(get(p,"b"))) {
                    if(expected!=null)throw new IllegalStateException("所选芯片有多个启用配置，请重新切卡并刷新");
                    expected=String.valueOf(get(p,"a"));
                }
            }
        }
        String reader="unknown";try{reader=String.valueOf(get(transport,"f"));}catch(Exception ignored){}
        String channel="unknown";try{Object logical=get(auth,"e");Object omapi=get(logical,"a");channel=String.valueOf(call(omapi,"getChannelNumber"));}catch(Exception ignored){}
        String prefix=imsi.matches("[0-9]{5,15}")?imsi.substring(0,5):"invalid";
        Log.e("SIMHubIdentity","USIM read reader="+reader+" channel="+channel+" EID="+tail(eid)+" selectedICCID="+tail(expected)+" actualICCID="+tail(actual)+" IMSI-prefix="+prefix);
        // Plain SIMs have no management profile list. Never infer their carrier from ICCID.
        if(expected!=null && !iccid(expected).equals(iccid(actual)))
            throw new IllegalStateException("所选配置 ICCID "+tail(expected)+" 与实际 USIM "+tail(actual)+" 不一致，已停止使用错误身份。请关闭 Wi-Fi 通话并重新切卡、读卡。");
    }
    /** Keep identities private: retain only identity type, PLMN prefix and realm. */
    public static String identity(String value) {
        if(value==null||value.isEmpty())return "builtin";
        int at=value.indexOf('@');String user=at<0?value:value.substring(0,at);
        String prefix=user.matches("[0-9]{6,}")?user.substring(0,6)+"…":"masked";
        return prefix+(at<0?"":"@"+value.substring(at+1));
    }
    public static void config(Object card,Object config,Map<String,String> overrides) {
        try {
        Log.e("SIMHubIdentity","effective ICCID="+tail(String.valueOf(get(card,"b")))+" PLMN="+call(card,"d")
            +" NAI="+identity((String)get(config,"r"))+" EAP="+identity((String)get(config,"y"))
            +" NAI-source="+(overrides!=null&&overrides.containsKey("nai")?"override":"builtin")
            +" EAP-source="+(overrides!=null&&overrides.containsKey("eap")?"override":"builtin"));
        } catch(Exception ignored) {Log.e("SIMHubIdentity","Identity diagnostic unavailable");}
    }
}
