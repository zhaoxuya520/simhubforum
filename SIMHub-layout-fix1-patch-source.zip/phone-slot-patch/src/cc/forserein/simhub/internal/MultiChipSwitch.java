package cc.forserein.simhub.internal;

import java.util.*;

/** Coroutine-independent transaction state; every list is freshly read before planning changes. */
public final class MultiChipSwitch {
    private final Object controller, target;
    private final boolean enable;
    private final List<String> chips=new ArrayList<>();
    private final Map<String,List<?>> observed=new LinkedHashMap<>();
    private final List<Object> disable=new ArrayList<>();
    private String targetChip, reading;
    private int scan, mutation, phase;
    public int kind; // 0 done, 1 read selected chip, 2 original profile operation
    public Object profile;
    public boolean enabled;
    public MultiChipSwitch(Object controller,Object target,boolean enable) throws Exception {
        this.controller=controller;this.target=target;this.enable=enable;
        String wanted=(String)get(target,"a");
        for(Object chip:(List<?>)invoke(controller,"l")) {
            String eid=(String)get(chip,"b");
            if(chips.contains(eid))throw new IllegalStateException("芯片标识重复，请重新连接读卡器");
            chips.add(eid);
            for(Object p:(List<?>)get(chip,"d"))if(wanted.equals(get(p,"a"))) {
                if(targetChip!=null)throw new IllegalStateException("配置标识重复，无法确定目标芯片");
                targetChip=eid;
            }
        }
        if(targetChip==null)throw new IllegalStateException("目标配置已变化，请刷新后重试");
    }
    private static Object get(Object o,String f)throws Exception{return o.getClass().getField(f).get(o);}
    private static Object invoke(Object o,String name)throws Exception{return o.getClass().getMethod(name).invoke(o);}
    private void select(String eid)throws Exception {
        controller.getClass().getMethod("D",String.class).invoke(controller,eid);
        if(!eid.equals(invoke(controller,"r")))throw new IllegalStateException("芯片选择失败，请重新连接读卡器");
    }
    private void publish(List<?> list)throws Exception {
        controller.getClass().getMethod("J",List.class).invoke(controller,list);
        invoke(controller,"K");
    }
    /** Called after the previous suspend operation completed successfully. */
    public void next(Object result)throws Exception {
        if(reading!=null) {
            if(!(result instanceof List))throw new IllegalStateException("未能读取芯片配置，停止切换");
            List<?> list=new ArrayList<>((List<?>)result);
            Set<String> ids=new HashSet<>();
            for(Object p:list)if(!ids.add((String)get(p,"a")))throw new IllegalStateException("芯片配置标识重复");
            observed.put(reading,list);publish(list);reading=null;
        }
        if(phase==0) {
            if(scan<chips.size()){reading=chips.get(scan++);select(reading);kind=1;return;}
            boolean found=false;
            String wanted=(String)get(target,"a");
            for(Map.Entry<String,List<?>> entry:observed.entrySet())for(Object p:entry.getValue()) {
                boolean isTarget=entry.getKey().equals(targetChip)&&wanted.equals(get(p,"a"));
                found|=isTarget;
                if(enable && !isTarget && Boolean.TRUE.equals(get(p,"b")))disable.add(p);
            }
            if(!found)throw new IllegalStateException("目标配置已不存在，请刷新后重试");
            phase=1;
        }
        if(phase==1) {
            if(mutation<disable.size()) {
                profile=disable.get(mutation++);enabled=false;
                select(owner(profile));kind=2;return;
            }
            select(targetChip);profile=target;enabled=enable;kind=2;phase=2;return;
        }
        if(phase==2){phase=3;scan=0;observed.clear();}
        if(scan<chips.size()){reading=chips.get(scan++);select(reading);kind=1;return;}
        String wanted=(String)get(target,"a");boolean targetSeen=false;
        for(Map.Entry<String,List<?>> entry:observed.entrySet())for(Object p:entry.getValue()) {
            boolean active=Boolean.TRUE.equals(get(p,"b"));
            boolean isTarget=entry.getKey().equals(targetChip)&&wanted.equals(get(p,"a"));
            if(isTarget){targetSeen=true;if(active!=enable)throw new IllegalStateException("目标配置状态未确认，请刷新后重试");}
            else if(enable && active)throw new IllegalStateException("仍检测到其他启用配置，请刷新确认后重试");
        }
        if(!targetSeen)throw new IllegalStateException("目标配置状态未确认");
        select(targetChip);kind=0;
    }
    private String owner(Object profile)throws Exception {
        for(Map.Entry<String,List<?>> entry:observed.entrySet())if(entry.getValue().contains(profile))return entry.getKey();
        throw new IllegalStateException("配置所属芯片已变化");
    }
    public void restore(){try{select(targetChip);}catch(Exception ignored){/* preserve original failure */}}
}
