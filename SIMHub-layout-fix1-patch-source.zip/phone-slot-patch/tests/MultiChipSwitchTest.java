import cc.forserein.simhub.internal.MultiChipSwitch;
import java.util.*;
public class MultiChipSwitchTest {
 static int passed;
 static void check(boolean b){if(!b)throw new AssertionError();passed++;}
 public static class Profile {public String a;public boolean b;Profile(String a,boolean b){this.a=a;this.b=b;}}
 public static class Chip {public String b;public List<Profile>d;Chip(String b,Profile...p){this.b=b;d=new ArrayList<>(Arrays.asList(p));}}
 public static class Controller {
  public List<Chip> chips;public String selected;public List<?> shown;
  Controller(Chip...c){chips=Arrays.asList(c);selected=c[0].b;}
  public List<Chip> l(){return chips;}public String r(){return selected;}
  public void D(String eid){selected=eid;}public void J(List<?>v){shown=v;}public void K(){}
  List<Profile> read(){for(Chip c:chips)if(c.b.equals(selected))return c.d;throw new AssertionError();}
 }
 static void run(Controller c,MultiChipSwitch p,boolean ignoreDisable)throws Exception {
  p.next(null);int reads=0,changes=0;
  while(p.kind!=0){
   if(p.kind==1){reads++;p.next(c.read());}
   else {changes++;check(reads>=c.chips.size());Profile profile=(Profile)p.profile;
    check(c.read().contains(profile));
    if(p.enabled || !ignoreDisable)profile.b=p.enabled;
    p.next(null);
   }
   if(reads+changes>30)throw new AssertionError("loop");
  }
  check(reads==c.chips.size()*2);
 }
 public static void main(String[]args)throws Exception {
  Profile a=new Profile("a",true),b=new Profile("b",false);
  Controller c=new Controller(new Chip("8962",a),new Chip("9059",b));
  run(c,new MultiChipSwitch(c,b,true),false);check(!a.b&&b.b&&c.selected.equals("9059"));
  run(c,new MultiChipSwitch(c,a,true),false);check(a.b&&!b.b&&c.selected.equals("8962"));
  // Both initially active: enabling a target cleans up the other chip.
  b.b=true;run(c,new MultiChipSwitch(c,a,true),false);check(a.b&&!b.b);
  // Cached disabled profile becomes active: fresh reads, rather than cached UI, decide cleanup.
  a.b=true;b.b=false;MultiChipSwitch p=new MultiChipSwitch(c,b,true);run(c,p,false);check(!a.b&&b.b);
  // Failure to disable must not be accepted as a successful final transaction.
  a.b=true;b.b=false;p=new MultiChipSwitch(c,b,true);
  try{run(c,p,true);throw new AssertionError("accepted multiple active profiles");}catch(IllegalStateException expected){check(true);p.restore();check(c.selected.equals("9059"));}
  // Disable does not disable another chip's active profile.
  a.b=true;b.b=true;run(c,new MultiChipSwitch(c,b,false),false);check(a.b&&!b.b);
  // Failed scan stops before any mutation.
  p=new MultiChipSwitch(c,a,true);p.next(null);
  try{p.next(null);throw new AssertionError();}catch(IllegalStateException expected){check(a.b);p.restore();}
  Profile duplicate=new Profile("a",true);
  try{new MultiChipSwitch(new Controller(new Chip("x",a),new Chip("y",duplicate)),a,true);throw new AssertionError();}catch(IllegalStateException expected){check(true);}
  System.out.println("PASS: "+passed+" multi-chip transaction assertions");
 }
}
