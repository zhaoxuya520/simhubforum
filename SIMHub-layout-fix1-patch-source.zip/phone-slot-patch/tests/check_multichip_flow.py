#!/usr/bin/env python3
"""Execute the real wrapper instructions with synchronous and suspended operations.
The separate Java test exercises the actual planner; this checks coroutine dispatch/cleanup.
"""
import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).parent))
path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parents[1]/'smali/InternalSimMultiChipSwitch.smali'
sys.argv=[sys.argv[0],str(path)]
import check_refresh_flow as vm
Obj=vm.Obj
class Run(vm.Run):
 def __init__(self,slot=True,suspend=True,fail=None):
  self.transport=Obj('s4' if slot else 'usb')
  self.manager=Obj('hh1',a=self.transport,d=True,e=True)
  self.controller=Obj('iz3')
  self.target=Obj('qy3',a='target')
  self.frame=Obj('InternalSimMultiChipSwitch',state=0,backend=self.manager,owner=self.controller,target=self.target,enable=True)
  self.suspend=suspend;self.next_resume=vm.UNIT;self.fail=fail
  self.actions=[1,1,2,2,1,1,0];self.reads=0;self.changes=0;self.restored=False
 def invoke(self,ref,args):
  if ref.startswith('Lcc/forserein/simhub/internal/MultiChipSwitch;->'):
   name=ref.split('->')[1].split('(')[0]
   if name=='<init>':return None
   if name=='next':
    args[0].fields.update(kind=self.actions.pop(0),profile=self.target,enabled=True);return None
   if name=='restore':self.restored=True;return None
   raise AssertionError(ref)
  if ref=='Lhh1;->s(Lws1;Ldt0;)Ljava/lang/Object;':
   assert self.manager.fields['d']==0 and self.manager.fields['e']==0
   self.reads+=1;return self.result(self.fail if self.fail and self.reads==2 else [])
  if ref=='Lhz3;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;':
   assert args[1] is self.manager and args[2] is self.frame
   self.changes+=1;return self.result(vm.UNIT)
  return super().invoke(ref,args)
class Flow(unittest.TestCase):
 def test_local_sync(self):
  r=Run(suspend=False);self.assertIs(r.execute(),vm.UNIT);self.assertEqual((r.reads,r.changes),(4,2))
 def test_local_suspend(self):
  r=Run();self.assertIs(r.execute(),vm.UNIT);self.assertEqual((r.reads,r.changes),(4,2))
 def test_usb_sync(self):
  r=Run(slot=False,suspend=False);self.assertIs(r.execute(),vm.UNIT);self.assertEqual((r.reads,r.changes),(0,1))
 def test_usb_suspend(self):
  r=Run(slot=False);self.assertIs(r.execute(),vm.UNIT);self.assertEqual((r.reads,r.changes),(0,1))
 def test_error(self):
  r=Run(fail=vm.CardError('read failed'))
  with self.assertRaises(vm.CardError):r.execute()
  self.assertTrue(r.restored);self.assertEqual(r.changes,0)
 def test_cancel(self):
  r=Run(fail=vm.Cancelled('cancel'))
  with self.assertRaises(vm.Cancelled):r.execute()
  self.assertTrue(r.restored);self.assertEqual(r.changes,0)
if __name__=='__main__':unittest.main(verbosity=2)
