import cc.forserein.simhub.internal.*;
public class IdentityBindingTest {
 static int passed;static void check(boolean b){if(!b)throw new AssertionError();passed++;}
 public static class Card {public String a,b;Card(String imsi,String iccid){a=imsi;b=iccid;}public String d(){return a.substring(0,5);}}
 public static class Transport {public String f="SIM2";}
 public static void main(String[]args)throws Exception {
  MultiChipSwitchTest.Profile dito=new MultiChipSwitchTest.Profile("8963660000005526",true);
  MultiChipSwitchTest.Controller c=new MultiChipSwitchTest.Controller(new MultiChipSwitchTest.Chip("8962",dito));
  Transport t=new Transport();IdentityBinding.track(t,c);
  IdentityBinding.read(t,new Object(),new Card("515660000000001",dito.a));check(true);
  try{IdentityBinding.read(t,new Object(),new Card("204040000000023","8900000000006164"));throw new AssertionError();}
  catch(IllegalStateException expected){check(expected.getMessage().contains("不一致"));check(!expected.getMessage().contains(dito.a));}
  IdentityBinding.read(new Transport(),new Object(),new Card("204040000000023","plain"));check(true);
  check(IdentityBinding.identity("0204040000000023@nai.epc.mnc004.mcc204.3gppnetwork.org").equals("020404…@nai.epc.mnc004.mcc204.3gppnetwork.org"));
  check(!IdentityBinding.identity("515660000000001@example.org").contains("000000001"));
  check(IdentityBinding.identity("anonymous@example.org").equals("masked@example.org"));
  check(IdentityBinding.tail(dito.a).equals("…5526"));
  System.out.println("PASS: "+passed+" identity binding and redaction assertions");
 }
}
