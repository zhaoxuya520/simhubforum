"""Wrap the existing profile operation; USB/Bluetooth still use the original coroutine."""
from pathlib import Path
import hashlib

def apply_multichip(smali):
    path=Path(smali)/'cg0.smali'
    text=path.read_text()
    assert text.count('new-instance p1, Lhz3;')==1
    assert text.count('Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V')==1
    text=text.replace('new-instance p1, Lhz3;', 'new-instance p1, LInternalSimMultiChipSwitch;')
    text=text.replace('Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V','LInternalSimMultiChipSwitch;-><init>(Liz3;Lqy3;ZLct0;)V')
    path.write_text(text)
    import shutil
    shutil.copyfile(Path(__file__).parent/'smali/InternalSimMultiChipSwitch.smali',Path(smali)/'InternalSimMultiChipSwitch.smali')
