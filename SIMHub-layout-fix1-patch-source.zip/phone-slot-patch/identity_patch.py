"""Local UICC identity binding, with errors routed through the existing read failure handler."""
import re
from pathlib import Path

def apply_identity(smali, texts=None):
    def edit(file,signature,fn):
        p=Path(smali)/file
        s=p.read_text() if texts is None else texts[file]
        pattern=re.compile(r'(\.method '+re.escape(signature)+r'\n)(.*?)(\.end method)',re.S)
        assert len(pattern.findall(s))==1
        patched=pattern.sub(lambda m:m[1]+fn(m[2])+m[3],s)
        if texts is None:p.write_text(patched)
        else:texts[file]=patched
    def getter(s):
        assert '.locals 0' in s and s.count('return-object p0')==1
        s=s.replace('.locals 0','.locals 1\n    move-object v0, p0',1)
        return s.replace('    return-object p0','    invoke-static {p0, v0}, Lcc/forserein/simhub/internal/IdentityBinding;->track(Ljava/lang/Object;Ljava/lang/Object;)V\n    return-object p0')
    edit('iz3.smali','public final s()Lqg0;',getter)
    def reread(s):
        # The old same-transport fast path kept the previous profile's identity.
        anchor='    sget-object v2, Lzl5;->j:Lqg0;'
        assert s.count(anchor)==1
        return s.replace(anchor,'''    instance-of v2, v1, Ls4;
    if-nez v2, :cond_4
'''+anchor)
    edit('zl5.smali','public final d(Lqg0;Ljava/lang/String;Ldt0;)Ljava/lang/Object;',reread)
    def guard(s):
        # Normalize line metadata only within this method, retaining instructions/registers.
        s='\n'.join(x for x in s.splitlines() if not x.strip().startswith('.line'))+'\n'
        anchor='    check-cast v0, Lek5;'
        assert s.count(anchor)==1
        s=s.replace(anchor,anchor+'''
    :identity_start
    instance-of v5, v15, Ls4;
    if-eqz v5, :identity_end
    invoke-static {v15, v14, v0}, Lcc/forserein/simhub/internal/IdentityBinding;->read(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    :identity_end
    .catchall {:identity_start .. :identity_end} :catchall_0
''')
        return s
    edit('zl5.smali','public final q(Ldt0;)Ljava/lang/Object;',guard)
