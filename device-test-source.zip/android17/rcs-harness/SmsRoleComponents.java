package rcssmoke;

import android.app.Activity;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import java.util.TreeSet;

/** Empty components for role qualification on the isolated emulator. No SMS calls or storage. */
public final class SmsRoleComponents {
    private SmsRoleComponents() {}

    public static final class IncomingSms extends BroadcastReceiver {
        @Override public void onReceive(Context context, Intent intent) {}
    }

    public static final class IncomingMms extends BroadcastReceiver {
        @Override public void onReceive(Context context, Intent intent) {}
    }

    public static final class RespondService extends Service {
        @Override public IBinder onBind(Intent intent) { return null; }
        @Override public int onStartCommand(Intent intent, int flags, int id) {
            stopSelf(id);
            return START_NOT_STICKY;
        }
    }

    public static final class ComposeActivity extends Activity {
        @Override public void onCreate(Bundle state) {
            super.onCreate(state);
            Intent intent = getIntent();
            // Receipts exist only for the reserved synthetic peer/body in this offline probe.
            if (intent != null && Intent.ACTION_SENDTO.equals(intent.getAction())
                    && intent.getData() != null && "smsto".equals(intent.getData().getScheme())
                    && NativeRcsFixture.PEER.equals(intent.getData().getSchemeSpecificPart())
                    && "系统编辑器草稿：仅测试，不发送".equals(intent.getStringExtra("sms_body"))) {
                Intent receipt = new Intent("rcssmoke.HANDOFF_RECEIPT").setPackage("cc.forserein.simhub");
                receipt.putExtra("action", intent.getAction());
                receipt.putExtra("scheme", intent.getData().getScheme());
                receipt.putExtra("peer", intent.getData().getSchemeSpecificPart());
                receipt.putExtra("body", intent.getStringExtra("sms_body"));
                receipt.putExtra("keys", new TreeSet<>(intent.getExtras().keySet()).toString());
                receipt.putExtra("component", intent.getComponent().flattenToString());
                receipt.putExtra("pid", android.os.Process.myPid());
                sendBroadcast(receipt, OfflineRcsProvider.PERMISSION);
            }
            finish();
        }
    }
}
