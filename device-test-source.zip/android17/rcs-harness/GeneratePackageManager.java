import java.lang.reflect.*;
import java.util.*;
public final class GeneratePackageManager {
 static String name(Class<?> c){return c.isArray()?name(c.getComponentType())+"[]":c.getCanonicalName();}
 public static void main(String[] args)throws Exception{
  Class<?> cls=Class.forName("android.content.pm.PackageManager",false,GeneratePackageManager.class.getClassLoader());
  System.out.println("package rcssmoke;\npublic class ForwardingPackageManager extends android.content.pm.PackageManager {\n protected final android.content.pm.PackageManager delegate;\n public ForwardingPackageManager(android.content.pm.PackageManager value){delegate=value;}");
  ArrayList<Method> all=new ArrayList<>(Arrays.asList(cls.getMethods()));all.sort(Comparator.comparing(Method::toGenericString));
  for(Method m:all){if(!Modifier.isAbstract(m.getModifiers()))continue;
   StringBuilder s=new StringBuilder(" @Override public ").append(name(m.getReturnType())).append(' ').append(m.getName()).append('(');
   Class<?>[] p=m.getParameterTypes();for(int i=0;i<p.length;i++){if(i>0)s.append(',');s.append(name(p[i])).append(" p").append(i);}s.append(')');
   Class<?>[] e=m.getExceptionTypes();if(e.length>0){s.append(" throws ");for(int i=0;i<e.length;i++){if(i>0)s.append(',');s.append(name(e[i]));}}
   s.append("{");if(m.getReturnType()!=void.class)s.append("return ");s.append("delegate.").append(m.getName()).append('(');for(int i=0;i<p.length;i++){if(i>0)s.append(',');s.append('p').append(i);}s.append(");}");System.out.println(s);
  }
  System.out.println("}");
 }
}
