package rcssmoke;

import android.content.Context;
import java.lang.reflect.*;
import java.util.*;

/** Synthetic native card/engine/registration state; no native registration or SMS dispatch. */
public final class NativeRcsFixture {
 public static final String LOCAL="+441632960246",ALIAS="+441632960247",PEER="+441632960248";
 final ClassLoader loader;final Object flow,oldState,oldEngine;Object state,engine,registration,card;
 public NativeRcsFixture(Context context)throws Exception{
  loader=context.getClassLoader();flow=type("zl5").getField("b").get(null);oldState=flow.getClass().getMethod("getValue").invoke(flow);oldEngine=type("zl5").getField("n").get(null);
  card=constructor(type("ek5"),8).newInstance("234330000000246","8944100000000000246",2,null,null,null,null,null);
  Object config=helper("WifiConfigModel").getMethod("builtIn",Object.class).invoke(null,card);
  Object[] fields=new Object[20];for(int i=0;i<20;i++)fields[i]=get(oldState,String.valueOf((char)('a'+i)));
  fields[4]=card;fields[5]=config;fields[6]=false;fields[7]="";fields[8]="";fields[9]="490154203237518";fields[10]=type("tk5").getField("g").get(null);fields[11]=false;fields[15]=new ArrayList<>();fields[16]=new ArrayList<>();fields[17]=false;fields[18]=null;
  state=constructor(type("gl5"),20).newInstance(fields);
  Object address=type("x82").getConstructor(byte[].class).newInstance((Object)new byte[]{(byte)192,0,2,46});
  registration=type("x72").getConstructor(List.class,int.class,type("x82"),type("x82"),ArrayList.class).newInstance(Arrays.asList("tel:"+LOCAL,"tel:"+ALIAS),1800,address,address,new ArrayList<>());
  engine=raw(type("o82"));set(engine,"c",card);set(engine,"s",registration);set(engine,"b",config);
  type("zl5").getField("n").set(null,engine);publish(state);
  helper("RcsChatBinding").getMethod("remember",Object.class,Object.class,List.class,int.class).invoke(null,engine,registration,Arrays.asList("tel:"+LOCAL,"tel:"+ALIAS),1800);
 }
 public Class<?> type(String name)throws Exception{return Class.forName(name,true,loader);}
 public Class<?> helper(String name)throws Exception{return type("cc.forserein.simhub.internal."+name);}
 public static Object get(Object value,String name)throws Exception{Field f=value.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(value);}
 public static void set(Object value,String name,Object data)throws Exception{Field f=value.getClass().getDeclaredField(name);f.setAccessible(true);f.set(value,data);}
 public static Constructor<?> constructor(Class<?> cls,int n){for(Constructor<?> c:cls.getDeclaredConstructors())if(c.getParameterTypes().length==n){c.setAccessible(true);return c;}throw new AssertionError(cls.getName()+" ctor "+n);}
 public static Object raw(Class<?> cls)throws Exception{Class<?> u=Class.forName("sun.misc.Unsafe");Field f=u.getDeclaredField("theUnsafe");f.setAccessible(true);return u.getMethod("allocateInstance",Class.class).invoke(f.get(null),cls);}
 public void publish(Object value)throws Exception{flow.getClass().getMethod("i",Object.class).invoke(flow,value);}
 public Object binding()throws Exception{return helper("RcsChatBinding").getMethod("capture",Object.class,String.class).invoke(null,state,PEER);}
 public void changeCard()throws Exception{
  Object other=constructor(type("ek5"),8).newInstance("234330000000249","8944100000000000249",2,null,null,null,null,null);
  Object[] fields=new Object[20];for(int i=0;i<20;i++)fields[i]=get(state,String.valueOf((char)('a'+i)));fields[4]=other;
  publish(constructor(type("gl5"),20).newInstance(fields));
 }
 public void resetCard()throws Exception{publish(state);}
 public void close()throws Exception{
  helper("RcsChatBinding").getMethod("clear",Object.class).invoke(null,engine);type("zl5").getField("n").set(null,oldEngine);publish(oldState);
 }
}
