"""Verify the explicit compose handoff using an inert role-qualified application and a virtual SIM."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
ADB = '/workspace/tools/android-platform-tools/platform-tools/adb'
APP = 'cc.forserein.simhub'
FIXTURE = APP + '.rcssmoke'
ROLE = 'android.app.role.SMS'
SERVICE = FIXTURE + '/rcssmoke.RcsRemoteService'
RCS = 'com.gsma.services.rcs.chat.IChatService'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apk-sha256', required=True)
    parser.add_argument('--serial', default='emulator-5580')
    parser.add_argument('--skip-install', action='store_true')
    parser.add_argument('--previous', action='store_true', help='assert the documented 24.7 blocked state')
    opt = parser.parse_args()
    def adb(*args, timeout=150):
        return subprocess.run([ADB, '-s', opt.serial, *map(str, args)], capture_output=True, text=True,
                              check=True, timeout=timeout).stdout.strip()
    def installed_hash(pkg):
        found = re.search(r'^package:(/[^\s]+/base\.apk)$', adb('shell','pm','path',pkg), re.M)
        assert found, 'Missing installed base APK: ' + pkg
        return adb('shell','sha256sum',found[1]).split()[0]
    def holder():
        role=adb('shell','cmd','role','get-role-holders','--user','0',ROLE)
        if not re.fullmatch(r'[a-zA-Z0-9_]+(?:\.[a-zA-Z0-9_]+)+',role): raise RuntimeError('Expected one Android SMS app for user 0')
        return role
    def choose(package):
        for attempt in range(3):
            try:
                if holder()==package: return
                adb('shell','cmd','role','add-role-holder','--user','0',ROLE,package,'1')
            except Exception as e: print('Role transition:',str(e)[:180],flush=True)
            for _ in range(10):
                try:
                    if holder() == package: return
                except RuntimeError: pass
                time.sleep(1.5)
        raise RuntimeError('SMS role selection did not change')
    def fixture_chat_state(value):
        print('Test service '+value,flush=True)
        out=adb('shell','am','instrument','-w','-e','state',value,FIXTURE+'/rcssmoke.FixtureChatState')
        assert "INSTRUMENTATION_RESULT: status=passed" in out and "INSTRUMENTATION_CODE: 0" in out, out
    def advertised():
        query = adb('shell','cmd','package','query-services','--components','--user','0','-a',RCS)
        return SERVICE in {line.strip() for line in query.splitlines()}
    assert re.fullmatch(r'emulator-\d+',opt.serial) and adb('shell','getprop','ro.kernel.qemu') == '1'
    assert adb('shell','am','get-current-user')=='0'
    pkg_hash = installed_hash(APP)
    assert pkg_hash == opt.apk_sha256
    # Android 17 may have populated the real subscription database before legacy gsm.* is updated.
    # Device-side shell is used only to witness that a virtual subscription is genuinely active.
    # Never give the instrumentation this data or a privileged phone-state identity.
    raw=adb('shell','dumpsys','isub')
    segment=raw.partition('Active subscriptions:')[2]
    active=bool(re.match(r'\s*\[SubscriptionInfoInternal: id=\d+ .*?simSlotIndex=\d+',segment))
    assert active, 'Android 17 needs at least one active virtual SIM'
    del raw,segment
    local = ROOT/'rcs-instrumentation.apk'
    if not opt.skip_install: assert 'Success' in adb('install','--no-streaming','-r',local)
    probe_hash = hashlib.sha256(local.read_bytes()).hexdigest()
    assert installed_hash(FIXTURE)==probe_hash
    before = holder()
    assert before != FIXTURE and advertised()
    dump = adb('shell','dumpsys','package',FIXTURE)
    for altered in re.findall(r'(?m)^      (?:enabled|disabled)Components:\n((?:        [^\n]+\n?)+)',dump):
        assert 'rcssmoke.RcsRemoteService' not in altered,'Expected default component state'
    report = {'stock_platform_active_subscription':active,'apk_sha256':pkg_hash,'test_apk_sha256':probe_hash,'role_before':before,'status':'failed'}
    try:
        assert 'adoptShellPermissionIdentity' not in (ROOT/'RcsComposerHandoffSmoke.java').read_text()
        fixture_chat_state('disabled')
        assert not advertised()
        report.update(phases={}, api=adb('shell','getprop','ro.build.version.sdk'), serial=opt.serial,
                      baseline_24_7=opt.previous, advertised_chat_services_while_testing=0)
        for form in (('thread',) if opt.previous else ('thread','new')):
            print('Selecting role for '+form,flush=True)
            choose(FIXTURE)
            print('Running '+form,flush=True)
            text = adb('shell','am','instrument','-w','-e','restorePackage',before,'-e','form',form,
                       '-e','previous',str(opt.previous).lower(),FIXTURE+'/rcssmoke.RcsComposerHandoffSmoke',timeout=520)
            prefix='previous-' if opt.previous else ''
            (ROOT/(prefix+'handoff-'+form+'-instrumentation.txt')).write_text(text+'\n')
            rows=dict(re.findall(r'^INSTRUMENTATION_RESULT: (\w+)=(.*)$',text,re.M))
            report['phases'][form]=rows
            if rows.get('status')!='passed' or 'INSTRUMENTATION_CODE: 0' not in text: raise RuntimeError(text)
            assert rows['full_iccid_hidden']=='true' and rows['adopted_subscriber_permissions']=='false'
            assert rows['baseline_24_7']==str(opt.previous).lower()
            assert int(rows['actual_external_draft_receipts'])==(0 if opt.previous else 1)
            assert holder()==before, 'In-session role restoration not observed'
        phases=report['phases'].values()
        report['results']={
          'checks':sum(int(x['checks']) for x in phases), 'status':'passed',
          'actual_external_draft_receipts':sum(int(x['actual_external_draft_receipts']) for x in phases),
          'ui_unavailable_reproduced':opt.previous,
          'visible_manual_sim_route':not opt.previous, 'iccid_hidden_to_application':True,
          'adopted_subscriber_permissions':False, 'real_network_messages':0,
          'receiver_extras': [] if opt.previous else ['sms_body'],
          'local_drafts_preserved':True
        }
        report['status']='passed'
    finally:
        try:
            fixture_chat_state('default')
            assert advertised()
            report['chat_component_restored']=True
        finally:
            if holder()!=before: choose(before)
            report['role_after']=holder()
            if report['role_after']!=before or not report.get('chat_component_restored'):
                report['status']='failed'
            report['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
            (ROOT/('previous-handoff-validation.json' if opt.previous else 'handoff-validation.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
