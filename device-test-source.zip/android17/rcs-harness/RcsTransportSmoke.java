package rcssmoke;
import android.app.Instrumentation;
import android.os.Bundle;
import android.os.SystemClock;
import android.content.Context;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/** Runs the installed production adapter against synthetic official Binder interfaces; no network. */
public final class RcsTransportSmoke extends Instrumentation {
 int checks,scenarios,transactions;NativeRcsFixture nativeState;
 interface Condition{boolean ready()throws Exception;}
 void check(boolean condition,String message){checks++;if(!condition)throw new AssertionError(message);}
 void await(Condition value,String label)throws Exception{long end=SystemClock.elapsedRealtime()+7000;while(SystemClock.elapsedRealtime()<end){if(value.ready()){checks++;return;}Thread.sleep(15);}throw new AssertionError("timeout "+label);}
 static Object field(Object v,String n)throws Exception{return v.getClass().getField(n).get(v);}
 static boolean flag(Object v,String n)throws Exception{return v!=null&&(Boolean)field(v,n);}
 static int integer(Object v,String n)throws Exception{return (Integer)field(v,n);}
 static String string(Object v,String n)throws Exception{return (String)field(v,n);}
 static List<?> messages(Object s)throws Exception{return (List<?>)field(s,"messages");}
 public void onCreate(Bundle arguments){super.onCreate(arguments);start();}
 public void onStart(){Bundle result=new Bundle();try{
  nativeState=new NativeRcsFixture(getTargetContext());
  positive();unavailable();isolations();uncertain();crossProcess();
  result.putString("status","passed");result.putString("checks",String.valueOf(checks));result.putString("scenarios",String.valueOf(scenarios));result.putString("binder_transactions",String.valueOf(transactions));
  result.putString("provider","synthetic system metadata and official GSMA typed Stub/Proxy/Parcel; in-process plus distinct Android service process; trust metadata synthetic, not actual carrier");
  result.putString("network_messages_sent","0");result.putString("broadcast_authentication","in-process hints simulated; additional isolated service sends real permission-filtered incoming broadcast; OEM trust resolution remains synthetic");
 }catch(Throwable error){result.putString("status","failed");result.putString("error",android.util.Log.getStackTraceString(error));}finally{try{if(nativeState!=null)nativeState.close();}catch(Exception error){result.putString("restore_error",error.toString());}}finish(0,result);}
 final class Session implements AutoCloseable {
  final OfflineRcsProvider provider;final Object transport;final Class<?> type;final List<Object> snapshots=new CopyOnWriteArrayList<>(),results=new CopyOnWriteArrayList<>();final List<String> errors=new CopyOnWriteArrayList<>(),unavailable=new CopyOnWriteArrayList<>();
  Session()throws Exception{this(new OfflineRcsProvider(getTargetContext()));}
  Session(OfflineRcsProvider provider)throws Exception{this.provider=provider;type=nativeState.helper("RcsChatTransport");Class<?> listener=nativeState.helper("RcsChatTransport$Listener");
   Object callback=Proxy.newProxyInstance(listener.getClassLoader(),new Class<?>[]{listener},(p,m,a)->{if(m.getName().equals("onSnapshot"))snapshots.add(a[0]);else if(m.getName().equals("onFailure"))errors.add((String)a[0]);else if(m.getName().equals("onProviderUnavailable")){errors.add((String)a[0]);unavailable.add((String)a[0]);}return null;});
   transport=type.getConstructor(Context.class,nativeState.helper("RcsChatBinding"),listener).newInstance(provider,nativeState.binding(),callback);
  }
  void connect()throws Exception{type.getMethod("connect").invoke(transport);}
  Object last(){return snapshots.isEmpty()?null:snapshots.get(snapshots.size()-1);}
  void ready()throws Exception{connect();await(()->flag(last(),"canSend"),"registered");}
  void refresh()throws Exception{type.getMethod("refresh").invoke(transport);}
  Object send(String body)throws Exception{int before=results.size();Class<?> cb=nativeState.helper("RcsChatTransport$SendCallback");Object callback=Proxy.newProxyInstance(cb.getClassLoader(),new Class<?>[]{cb},(p,m,a)->{if(m.getName().equals("onResult"))results.add(a[0]);return null;});type.getMethod("send",String.class,cb).invoke(transport,body,callback);await(()->results.size()>before||!errors.isEmpty(),"send response");return results.size()>before?results.get(before):null;}
  public void close()throws Exception{type.getMethod("close").invoke(transport);await(()->provider.unbinds>=provider.binds,"unbind");transactions+=provider.transactions;provider.close();}
 }
 void positive()throws Exception{scenarios++;try(Session s=new Session()){
  s.ready();check(s.provider.binds==1,"explicit bind once");check(s.provider.compatibilityRequests==1,"compat handshake");check(s.provider.sends==0,"connect did not send");
  Object sent=s.send("测试消息");check(flag(sent,"accepted")&&!flag(sent,"uncertain"),"actual queued result");Object message=field(sent,"message");check(integer(message,"statusCode")==1,"queued not delivered");String id=string(message,"id");
  check(s.provider.sends==1,"exactly one typed send");s.provider.status(id,5);await(()->messages(s.last()).size()==1&&integer(messages(s.last()).get(0),"statusCode")==5,"delivered callback fetch");
  s.provider.incoming("incoming","真实 Binder 内容",NativeRcsFixture.PEER,System.currentTimeMillis());s.provider.signalIncoming("incoming");await(()->messages(s.last()).size()==2,"incoming typed lookup");
  Object received=messages(s.last()).get(1);check(flag(received,"incoming")&&"真实 Binder 内容".equals(string(received,"body")),"broadcast body ignored");
  s.provider.signalIncoming("incoming");Thread.sleep(100);check(messages(s.last()).size()==2,"duplicate incoming suppressed");
  s.provider.incoming("old","old",NativeRcsFixture.PEER,1);s.provider.signalIncoming("old");s.provider.incoming("wrong","other","+331632960248",System.currentTimeMillis());s.provider.signalIncoming("wrong");Thread.sleep(100);check(messages(s.last()).size()==2,"old and wrong peer excluded");
  s.provider.allowSend=false;s.refresh();await(()->!flag(s.last(),"canSend"),"capability disabled");Object blocked=s.send("blocked");check(!flag(blocked,"accepted")&&s.provider.sends==1,"no disallowed write");
  s.provider.allowSend=true;s.provider.limit=4;s.refresh();await(()->flag(s.last(),"canSend")&&integer(s.last(),"maxLength")==4,"byte limit");
  Object tooLong=s.send("中文");check(!flag(tooLong,"accepted")&&s.provider.sends==1,"UTF8 six bytes rejected at four");Object emoji=s.send("😀");check(flag(emoji,"accepted")&&s.provider.sends==2,"UTF8 four-byte emoji accepted");
 }}
 void unavailable()throws Exception{
  for(String mode:Arrays.asList("missing","disabled","private","gate","denied","untrusted","incompatible","version","unregistered","line")){scenarios++;try(Session s=new Session()){
   if(mode.equals("missing"))s.provider.available=false;if(mode.equals("untrusted"))s.provider.trusted=false;if(mode.equals("incompatible"))s.provider.compatible=false;if(mode.equals("version"))s.provider.serviceVersion=1;if(mode.equals("unregistered"))s.provider.registered=false;if(mode.equals("line"))s.provider.local="+331632960249";
   if(mode.equals("disabled"))s.provider.componentEnabled=false;if(mode.equals("private"))s.provider.exported=false;if(mode.equals("gate"))s.provider.properPermission=false;if(mode.equals("denied"))s.provider.granted=false;
   s.connect();await(()->!s.errors.isEmpty(),mode);check(s.provider.sends==0,"unavailable no message "+mode);check(!flag(s.last(),"canSend"),"unavailable disabled "+mode);
   if(mode.equals("missing")||mode.equals("untrusted")||mode.equals("incompatible"))check(s.provider.binds==0,"no incompatible bind "+mode);
   if(Arrays.asList("missing","disabled","untrusted","private","gate","denied").contains(mode)) {
    check(s.provider.compatibilityRequests==0&&s.provider.binds==0&&s.provider.transactions==0,"no data or IPC to ineligible "+mode);
    Map<String,String> reasons=new HashMap<>();reasons.put("missing","未向 SIMHub 公布");reasons.put("disabled","已停用");reasons.put("untrusted","不是系统应用或当前默认短信应用");reasons.put("private","未向其他应用开放");reasons.put("gate","未声明兼容的 GSMA 访问权限");reasons.put("denied","未授予");check(s.errors.get(0).contains(reasons.get(mode)),"distinguishable cause "+mode+" "+s.errors);
   }
   check(mode.equals("line")?s.unavailable.isEmpty():s.unavailable.size()==1,"eligibility callback only for true initial provider failure: "+mode);
   if(mode.equals("version"))check(s.provider.removedListeners==0,"no cleanup transaction on incompatible version");
  }}
 }
 void isolations()throws Exception{
  scenarios++;try(Session s=new Session()){s.ready();s.provider.local=NativeRcsFixture.ALIAS;s.refresh();await(()->!s.errors.isEmpty(),"same-IMS-alias switch");check(!flag(s.last(),"canSend")&&messages(s.last()).isEmpty(),"local line pinned");check(s.provider.sends==0,"alias did not send");check(s.unavailable.isEmpty(),"line change never offered as provider unavailable");}
  scenarios++;try(Session s=new Session()){s.ready();nativeState.changeCard();s.send("must not send");await(()->!s.errors.isEmpty(),"card change");check(s.provider.sends==0,"card changed before send blocks write");}finally{nativeState.resetCard();}
  scenarios++;try(Session s=new Session()){s.ready();s.provider.unregister();await(()->!s.errors.isEmpty(),"unregistered callback");check(!flag(s.last(),"canSend")&&messages(s.last()).isEmpty(),"disconnect hides prior session");check(s.provider.sends==0,"unregister no fallback");check(s.unavailable.isEmpty(),"registered-session loss never opens SMS fallback");}
  scenarios++;Session s=new Session();s.ready();int before=s.snapshots.size();s.close();Thread.sleep(100);check(s.snapshots.size()==before,"close no stale callbacks");
 }
 void crossProcess()throws Exception{
  scenarios++;CrossProcessRcsProvider remote=new CrossProcessRcsProvider(getTargetContext());remote.openControl();
  try(Session s=new Session(remote)){
   int[] initial=remote.stats();check(initial[0]!=android.os.Process.myPid(),"provider is a distinct Android process");
   s.ready();check(remote.stats()[1]==initial[1],"remote connect did not send");
   Object result=s.send("跨进程测试");check(flag(result,"accepted")&&!flag(result,"uncertain"),"remote queued submission");
   String id=string(field(result,"message"),"id");check(remote.stats()[1]==initial[1]+1,"remote provider exactly one message");
   remote.updateStatus(id,5);await(()->messages(s.last()).size()==1&&integer(messages(s.last()).get(0),"statusCode")==5,"remote delivery callback");
   remote.receive("remote-incoming","跨进程真实正文",NativeRcsFixture.PEER);await(()->messages(s.last()).size()==2,"real incoming broadcast to binder read");
   check("跨进程真实正文".equals(string(messages(s.last()).get(1),"body")),"real broadcast extra was ignored");
   check(remote.stats()[2]>20,"actual cross-process AIDL operations");
   remote.unregisterRemote();await(()->!s.errors.isEmpty(),"remote unregister callback");check(!flag(s.last(),"canSend"),"remote offline blocks sends");
  }
 }
 void uncertain()throws Exception{scenarios++;try(Session s=new Session()){s.ready();s.provider.failSend=true;Object response=s.send("unknown");check(flag(response,"uncertain")&&!flag(response,"accepted"),"ambiguous result preserved");await(()->!flag(s.last(),"canSend"),"uncertain disabled");check(s.provider.sends==1,"one attempt only");s.send("repeat");check(s.provider.sends==1,"no ambiguous retry");s.provider.failSend=false;s.refresh();Thread.sleep(100);check(!flag(s.last(),"canSend"),"refresh not retry or unlock");}}
}
