package rcssmoke;
import android.content.*;import android.os.Bundle;
/** Reference public compatibility protocol, implemented by a synthetic isolated-process provider. */
public final class RcsRemoteCompatibility extends BroadcastReceiver{
 public void onReceive(Context c,Intent i){Bundle b=new Bundle();b.putBoolean("get_compatibility_response",
  "ChatService".equals(i.getStringExtra("get_compatibility_service"))&&"GSMA".equals(i.getStringExtra("get_compatibility_codename"))
  &&i.getIntExtra("get_compatibility_version",-1)==2&&i.getIntExtra("get_compatibility_increment",-1)==0);setResultExtras(b);}
}
