package rcssmoke;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import android.graphics.Rect;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Exercise the actual independent new-SMS form under its original theme. No SMS is dispatched. */
public class RcsComposeNewSmoke extends Instrumentation {
    Activity activity;
    NativeRcsFixture fixture;
    private OfflineRcsProvider provider;
    private Object transport;
    int checks, navigations;
    private static final String BODY="新建会话的测试草稿";
    interface Operation { void run() throws Exception; }
    interface Condition { boolean get() throws Exception; }
    private interface Callback { Object invoke(Object[] args) throws Exception; }

    void check(boolean condition,String label) {
        checks++;
        if (!condition) throw new AssertionError(label);
    }
    void main(Operation op) {
        Throwable[] error={null};
        runOnMainSync(()->{try{op.run();}catch(Throwable t){error[0]=t;}});
        if(error[0]!=null)throw new AssertionError("main-thread action",error[0]);
    }
    void await(Condition condition,String label) throws Exception {
        long end=SystemClock.elapsedRealtime()+90000;
        do {
            clearSimulatorAnrDialog();
            if(condition.get()){checks++;return;}
            SystemClock.sleep(75);
        }while(SystemClock.elapsedRealtime()<end);
        throw new AssertionError("timeout "+label+" "+describe());
    }
    // Android's software-only emulator may stack unrelated process ANR dialogs above the app.
    // Use only the system dialog's own Wait action, never the SIMHub or external messaging UI.
    private void clearSimulatorAnrDialog() {
        List<AccessibilityNodeInfo> window = nodes();
        boolean anr = false;
        AccessibilityNodeInfo wait = null;
        for (AccessibilityNodeInfo node : window) {
            if (!"android".contentEquals(node.getPackageName() == null ? "" : node.getPackageName())) continue;
            String text = node.getText() == null ? "" : node.getText().toString();
            if (text.contains("isn't responding") || text.contains("isn’t responding")) anr = true;
            if ("Wait".equals(text) && node.isClickable() && node.isEnabled()) wait = node;
        }
        if (anr && wait != null) { wait.performAction(AccessibilityNodeInfo.ACTION_CLICK); SystemClock.sleep(180); }
    }
    Class<?> type(String name) throws Exception {return fixture.type(name);}
    private Object unit() throws Exception {return type("sc5").getField("a").get(null);}
    private Class<?> ui() throws Exception {return fixture.helper("RcsChatUi");}
    Object session() throws Exception {
        Field field=ui().getDeclaredField("current");field.setAccessible(true);return field.get(null);
    }
    private Object callback(String iface,Callback action) throws Exception {
        return Proxy.newProxyInstance(fixture.loader,new Class<?>[]{type(iface)},(proxy,method,args)->{
            if(method.getDeclaringClass()==Object.class){
                if("equals".equals(method.getName()))return proxy==args[0];
                if("hashCode".equals(method.getName()))return System.identityHashCode(proxy);
                return "New SMS form smoke callback";
            }
            return action.invoke(args);
        });
    }
    private Object composable(int key,Object callback) throws Exception{
        return type("zn0").getConstructor(int.class,boolean.class,type("gt1")).newInstance(key,true,callback);
    }
    void render() throws Exception { renderForm(false); }
    void renderForm(boolean existing) throws Exception {
        Object afterSend=callback("ws1",args->{navigations++;return unit();});
        Object back=callback("us1",args->{throw new AssertionError("unexpected dismiss");});
        Object body=callback("kt1",args->{
            if (existing) {
                type("pk5").getMethod("j",type("em0"),type("gl5"),String.class,String.class,type("us1"),type("lu1"),int.class)
                    .invoke(null,type("em0").getField("a").get(null),fixture.state,NativeRcsFixture.PEER,"离线测试联系人",back,args[0],0);
            } else {
                type("pk5").getMethod("e",type("gl5"),type("ws1"),type("us1"),type("lu1"),int.class)
                    .invoke(null,fixture.state,afterSend,back,args[0],0);
            }
            return unit();
        });
        Object inner=composable(246240,body);
        Object theme=callback("kt1",args->{
            type("z55").getMethod("a",type("zn0"),type("lu1"),int.class).invoke(null,inner,args[0],0);
            return unit();
        });
        type("sn0").getMethod("a",type("rn0"),type("zn0")).invoke(null,activity,composable(246241,theme));
    }
    private AccessibilityNodeInfo root(){return getUiAutomation().getRootInActiveWindow();}
    private void collect(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> out) {
        if(n==null)return;out.add(n);
        for(int i=0;i<n.getChildCount();i++)collect(n.getChild(i),out);
    }
    List<AccessibilityNodeInfo> nodes(){
        List<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root(),nodes);return nodes;
    }
    private String describe(){
        StringBuilder out=new StringBuilder();
        for(AccessibilityNodeInfo node:nodes())out.append(node.getClassName()).append('/').append(node.getText())
                .append('/').append(node.getContentDescription()).append('/').append(node.isEditable())
                .append('/').append(node.isEnabled()).append('\n');
        return out.toString();
    }
    private static Rect bounds(AccessibilityNodeInfo node){Rect r=new Rect();node.getBoundsInScreen(r);return r;}
    List<AccessibilityNodeInfo> edits(){
        List<AccessibilityNodeInfo> fields=new ArrayList<>();
        for(AccessibilityNodeInfo node:nodes())if(node.isEditable())fields.add(node);
        fields.sort(Comparator.comparingInt(n->bounds(n).top));return fields;
    }
    AccessibilityNodeInfo toggle(){
        for(AccessibilityNodeInfo n:nodes())if(n.isCheckable())return n;
        return null;
    }
    boolean label(String value){
        for(AccessibilityNodeInfo n:nodes())if(n.getText()!=null&&n.getText().toString().contains(value))return true;
        return false;
    }
    private AccessibilityNodeInfo sendKey() {
        List<AccessibilityNodeInfo> inputs=edits();
        if(inputs.size()!=2)return null;
        Rect body=bounds(inputs.get(1));
        AccessibilityNodeInfo best=null;
        int score=Integer.MAX_VALUE;
        for(AccessibilityNodeInfo node:nodes()) {
            if(!node.isClickable()||node.isCheckable()||node.isEditable())continue;
            Rect r=bounds(node);
            if(r.width()<=0||r.height()<=0||r.centerX()<=body.centerX()
                    ||r.centerY()<body.top-10||r.centerY()>body.bottom+30)continue;
            int rank=Math.abs(r.centerY()-body.centerY())+r.width()+r.height();
            if(rank<score){score=rank;best=node;}
        }
        return best;
    }
    void input(int index,String value)throws Exception{
        List<AccessibilityNodeInfo> fields=edits();check(fields.size()==2,"native form has two fields");
        Bundle args=new Bundle();args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,value);
        check(fields.get(index).performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args),"native form accepts text");
        await(()->{List<AccessibilityNodeInfo> f=edits();return f.size()==2&&value.contentEquals(f.get(index).getText());},"field update");
    }
    private Object draft(Object page)throws Exception {return ((WeakReference<?>)NativeRcsFixture.get(page,"draft")).get();}
    String body(Object page)throws Exception{return (String)type("ot4").getMethod("getValue").invoke(draft(page));}
    String peer(Object page)throws Exception{return (String)NativeRcsFixture.get(page,"peer");}
    boolean enabled(Object page)throws Exception{return (Boolean)ui().getMethod("sendEnabled",boolean.class,String.class,Object.class).invoke(null,true,peer(page),draft(page));}
    private void runCases()throws Exception{
        main(()->render());
        await(()->session()!=null&&toggle()!=null&&edits().size()==2&&label("RCS · 已关闭"),"native new SMS form");
        String smsHint=(String)type("qv4").getMethod("b",String.class).invoke(null,"vowifi_sms_send_hint");
        check(smsHint!=null&&!smsHint.isEmpty()&&label(smsHint),"original SMS registration hint visible off");
        check(peer(session()).isEmpty(),"recipient initially empty");
        input(1,BODY);
        check(BODY.equals(body(session())),"original body field bound to actual RCS composer");
        check(toggle().performAction(AccessibilityNodeInfo.ACTION_CLICK),"toggle on in new message");
        await(()->toggle()!=null&&toggle().isChecked(),"requested mode");
        input(0,"+44");
        await(()->"+44".equals(peer(session())),"edited recipient reaches state");
        Object old=session();
        input(0,NativeRcsFixture.PEER);
        await(()->NativeRcsFixture.PEER.equals(peer(session())),"completed recipient selected");
        Object page=session();
        check(page!=old&&!Boolean.TRUE.equals(NativeRcsFixture.get(old,"active")),"previous recipient session retired");
        check(Boolean.TRUE.equals(NativeRcsFixture.get(page,"on")),"RCS selection follows editing");
        await(()->label("RCS · 不可用")&&NativeRcsFixture.get(page,"binding")!=null,"stable recipient attempted RCS without OEM service");
        check(!label(smsHint),"SMS-only registration hint hidden in unavailable RCS mode");
        check(!enabled(page)&&BODY.equals(body(page)),"offline disables send and keeps body");
        check(NativeRcsFixture.PEER.equals(peer(page))&&navigations==0,"recipient kept, no SMS navigation");
        check(((List<?>)NativeRcsFixture.get(fixture.state,"q")).isEmpty(),"no native SMS record");
        // Active edit sessions and current card/peer come solely from the native form. Supply a local
        // provider after testing actual non-availability in order to exercise its independent send key.
        provider=new OfflineRcsProvider(getTargetContext());
        main(()->{
            Object binding=NativeRcsFixture.get(page,"binding");
            Class<?> adapter=fixture.helper("RcsChatTransport");
            Object oldTransport=NativeRcsFixture.get(page,"transport");
            if(oldTransport!=null)adapter.getMethod("close").invoke(oldTransport);
            transport=adapter.getConstructor(android.content.Context.class,fixture.helper("RcsChatBinding"),fixture.helper("RcsChatTransport$Listener")).newInstance(provider,binding,page);
            NativeRcsFixture.set(page,"transport",transport);NativeRcsFixture.set(page,"connecting",true);NativeRcsFixture.set(page,"failed",false);
            adapter.getMethod("connect").invoke(transport);
        });
        await(()->label("RCS · 已连接")&&enabled(page),"new recipient connected");
        check(!label(smsHint),"SMS-only registration hint hidden in connected RCS mode");
        check(provider.sends==0,"no write on connect");
        await(()->sendKey()!=null&&sendKey().isEnabled(),"original new-message send key enabled");
        check(sendKey().performAction(AccessibilityNodeInfo.ACTION_CLICK),"original visible new-message send key clicked");
        await(()->provider.sends==1&&body(page).isEmpty(),"native new-message callback provider ack");
        check(provider.records.size()==1&&navigations==0,"exactly one RCS record, no SMS navigation");
        check(NativeRcsFixture.PEER.equals(peer(page)),"RCS acknowledgement keeps recipient");
        check(toggle().performAction(AccessibilityNodeInfo.ACTION_CLICK),"explicitly close RCS");
        await(()->label("RCS · 已关闭")&&!toggle().isChecked()&&label(smsHint),"closing RCS restores original SMS registration hint");
    }
    @Override public void onCreate(Bundle arguments){super.onCreate(arguments);start();}
    @Override public void onStart(){
        Throwable failure=null;
        try{
            activity=startActivitySync(new Intent().setClassName("cc.forserein.simhub","cc.forserein.simhub.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            waitForIdleSync();fixture=new NativeRcsFixture(getTargetContext());runCases();
        }catch(Throwable t){failure=t;}
        finally{
            try{
                if(activity!=null&&!activity.isFinishing())main(()->activity.finish());
                if(transport!=null)transport.getClass().getMethod("close").invoke(transport);
                if(provider!=null)provider.close();
                if(fixture!=null)fixture.close();
            }catch(Throwable t){if(failure==null)failure=t;else failure.addSuppressed(t);}
        }
        Bundle result=new Bundle();
        result.putString("status",failure==null?"passed":"failed");result.putInt("checks",checks);
        result.putInt("provider_send_calls",provider==null?0:provider.sends);result.putInt("navigations",navigations);
        result.putString("scope","Actual installed pk5.e/mc0.d new form, native Accessibility field edits and toggle, visible original send key and its native zz callback. Synthetic card/registration, positive provider injected after observing actual unavailable service. No live number, carrier or network message.");
        if(failure!=null)result.putString("error",android.util.Log.getStackTraceString(failure));
        finish(failure==null?0:1,result);
    }
}
