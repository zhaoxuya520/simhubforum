package rcssmoke;

import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;

/** A synthetic messaging app may change the state of its own optional service. */
public final class FixtureChatState extends Instrumentation {
    @Override public void onCreate(Bundle args) {
        super.onCreate(args);
        Bundle reply = new Bundle();
        try {
            Context self = getTargetContext();
            if (!"cc.forserein.simhub.rcssmoke".equals(self.getPackageName())) {
                throw new IllegalStateException("Expected offline fixture");
            }
            String value = args.getString("state");
            int state;
            if ("disabled".equals(value)) state = PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
            else if ("default".equals(value)) state = PackageManager.COMPONENT_ENABLED_STATE_DEFAULT;
            else throw new IllegalArgumentException("Invalid test component state");
            ComponentName service = new ComponentName(self,RcsRemoteService.class);
            PackageManager pm = self.getPackageManager();
            pm.setComponentEnabledSetting(service, state, PackageManager.DONT_KILL_APP);
            if (pm.getComponentEnabledSetting(service) != state) throw new IllegalStateException("State mismatch");
            reply.putString("status","passed");
            finish(0,reply);
        } catch (RuntimeException e) {
            reply.putString("error",e.toString());
            finish(1,reply);
        }
    }
}
