from pathlib import Path
import importlib.util
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
PROJECT = Path('/workspace/simhubforum/android/phone-slot-patch')
TOOLS = Path('/workspace/tools/android-recovery')
SDK = TOOLS / 'sdk/android-35/android.jar'


def run(*args, **kwargs):
    return subprocess.run(list(map(str, args)), check=True, **kwargs)


bootstrap = ROOT / 'bootstrap'
bootstrap.mkdir(exist_ok=True)
run('java', '-jar', TOOLS / 'ecj-3.40.0.jar', '-8', '-cp', SDK,
    '-d', bootstrap, ROOT / 'GeneratePackageManager.java')
generated = run('java', '-cp', str(bootstrap) + ':' + str(SDK),
                'GeneratePackageManager', capture_output=True, text=True).stdout
(ROOT / 'ForwardingPackageManager.java').write_text(generated)
spec = importlib.util.spec_from_file_location('rcs_tapi_build', PROJECT / 'rcs_tapi_build.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
sources = module.generate_rcs_tapi(ROOT / 'generated-tapi')
for target in ('classes', 'dex'):
    shutil.rmtree(ROOT / target, ignore_errors=True)
    (ROOT / target).mkdir()
sources += [p for p in sorted(ROOT.glob('*.java')) if p.name != 'GeneratePackageManager.java']
run('java', '-jar', TOOLS / 'ecj-3.40.0.jar', '-8', '-nowarn', '-cp', SDK,
    '-d', ROOT / 'classes', *sources)
with zipfile.ZipFile(ROOT / 'classes.jar', 'w') as archive:
    for path in (ROOT / 'classes').rglob('*.class'):
        archive.write(path, path.relative_to(ROOT / 'classes'))
run('java', '-cp', TOOLS / 'sdk/android-15/lib/d8.jar', 'com.android.tools.r8.D8',
    '--min-api', '28', '--lib', SDK, '--output', ROOT / 'dex', ROOT / 'classes.jar')
run(TOOLS / 'sdk/android-15/aapt2', 'link', '-o', ROOT / 'unsigned.apk',
    '--manifest', ROOT / 'AndroidManifest.xml', '-I', SDK)
with zipfile.ZipFile(ROOT / 'unsigned.apk', 'a') as archive:
    archive.write(ROOT / 'dex/classes.dex', 'classes.dex')
run('java', '-jar', TOOLS / 'sdk/android-15/lib/apksigner.jar', 'sign',
    '--ks', '/workspace/simhub-signing/simhub-longterm-2026.p12',
    '--ks-key-alias', 'simhub-longterm', '--ks-pass',
    'file:/workspace/simhub-signing/simhub-longterm-password',
    '--out', ROOT / 'rcs-instrumentation.apk', ROOT / 'unsigned.apk')
print(ROOT / 'rcs-instrumentation.apk')
