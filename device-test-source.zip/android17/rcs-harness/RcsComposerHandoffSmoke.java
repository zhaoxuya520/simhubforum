package rcssmoke;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.Telephony;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Click the native form with ordinary SIMHub permission, real system roles and a synthetic local card. */
public final class RcsComposerHandoffSmoke extends RcsComposeNewSmoke {
    private static final String PROVIDER = "cc.forserein.simhub.rcssmoke";
    private static final String BODY = "系统编辑器草稿：仅测试，不发送";
    private static final String PRIV = "android.permission.READ_PRIVILEGED_PHONE_STATE";
    private final List<Intent> receipts = new CopyOnWriteArrayList<>();
    private Bundle args;
    private Field readerField;
    private Object priorReader;
    private Object reader;
    private boolean hidden;
    private boolean receiveRegistered;
    private boolean previous;
    private boolean thread;
    private final BroadcastReceiver ack = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { receipts.add(new Intent(i)); }
    };

    @Override public void onCreate(Bundle arguments) {
        args=arguments;
        previous="true".equals(args.getString("previous"));
        thread="thread".equals(args.getString("form"));
        super.onCreate(arguments);
    }
    private boolean canReadFullIccid() {
        SubscriptionManager sm=getTargetContext().getSystemService(SubscriptionManager.class);
        try {
            List<SubscriptionInfo> active=sm.getActiveSubscriptionInfoList();
            if(active!=null) for(SubscriptionInfo info:active) {
                String id=info.getIccId();
                if(id!=null && id.matches("[0-9]{19,20}")) return true;
            }
        }catch(SecurityException denied){ /* Expected on ordinary unprivileged applications. */ }
        return false;
    }
    private Object capture(String peer) throws Exception {
        return fixture.helper("RcsSystemComposer").getMethod("capture",Context.class,Object.class,String.class)
                .invoke(null,activity,fixture.state,peer);
    }
    private void open(Object route,String peer) throws Exception {
        fixture.helper("RcsSystemComposer").getMethod("open",Activity.class,Object.class,String.class,String.class)
               .invoke(route,activity,fixture.state,peer,BODY);
    }
    private void rejects(Operation op,String why) throws Exception {
        try { op.run(); }catch(InvocationTargetException failure){
            check(failure.getCause() instanceof IllegalStateException || failure.getCause() instanceof IllegalArgumentException,why);
            return;
        }
        throw new AssertionError("unexpected handoff allowed: "+why);
    }
    private AccessibilityNodeInfo handoffButton() {
        for(AccessibilityNodeInfo leaf:nodes()){
            if(leaf.getText()==null || !leaf.getText().toString().contains("去Offline RCS probe选卡"))continue;
            for(AccessibilityNodeInfo node=leaf;node!=null;node=node.getParent())
                if(node.isClickable() && node.isEnabled())return node;
        }
        return null;
    }
    private void toggleMode(boolean value)throws Exception {
        AccessibilityNodeInfo control=toggle();
        check(control!=null && control.isChecked()!=value && control.performAction(AccessibilityNodeInfo.ACTION_CLICK),"toggle actual RCS switch");
        await(()->toggle()!=null && toggle().isChecked()==value,"RCS switch reflects click");
    }
    private void setThreadBody() throws Exception {
        Bundle b=new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,BODY);
        check(edits().size()==1 && edits().get(0).performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b),"edit installed conversation body");
        await(()->BODY.equals(body(session())),"original conversation captures body");
    }
    private void restoreOriginalRole()throws Exception {
        String name=args.getString("restorePackage");
        check(name!=null && name.matches("[A-Za-z_0-9]+(?:\\.[A-Za-z_0-9]+)+") && !PROVIDER.equals(name),"known original SMS package");
        ParcelFileDescriptor pipe=getUiAutomation().executeShellCommand("cmd role add-role-holder --user 0 android.app.role.SMS "+name+" 1");
        try(InputStream stream=new ParcelFileDescriptor.AutoCloseInputStream(pipe)){
            byte[] bytes=new byte[128];while(stream.read(bytes)>=0){}
        }
        await(()->name.equals(Telephony.Sms.getDefaultSmsPackage(activity)),"system restored SMS role");
    }
    private void prepareForm()throws Exception {
        main(()->renderForm(thread));
        await(()->session()!=null && toggle()!=null && edits().size()==(thread?1:2),"native SMS form");
        if(thread) setThreadBody(); else{input(0,NativeRcsFixture.PEER);input(1,BODY);}
        toggleMode(true);
    }
    private void assertUiReady()throws Exception {
        await(()->handoffButton()!=null && label("RCS · 需手动选卡"),"named manual SIM option in native SMS UI");
        check(label("在该应用内选择 SIM，确认发送栏显示 RCS 后再发送。"),"confirm external SIM and RCS before sending");
        check(!label("RCS · 不可用") && !label("RCS · 已连接"),"honest actionable manual state");
        check(!enabled(session()) && BODY.equals(body(session())),"native send disabled, local body complete");
        check(receipts.isEmpty(),"no external activity on toggle or discovery");
    }
    private void runHandoff()throws Exception {
        final String peer=NativeRcsFixture.PEER;
        readerField=type("zl5").getField("j");priorReader=readerField.get(null);
        readerField.set(null,null);
        rejects(()->capture(peer),"external or missing reader does not launch unrelated phone subscription");
        reader=NativeRcsFixture.raw(type("qf3"));readerField.set(null,reader);
        check(getTargetContext().checkSelfPermission(PRIV)==PackageManager.PERMISSION_DENIED,"target has no privileged subscriber-read grant");
        hidden=!canReadFullIccid();
        check(hidden,"emulator masks the active ICCID to the ordinary target UID");
        check(PROVIDER.equals(Telephony.Sms.getDefaultSmsPackage(activity)),"actual default SMS app");
        if(previous) {
            rejects(()->capture(peer),"24.7 cannot produce a draft with redacted ICCID");
            prepareForm();
            await(()->label("无法核对当前卡对应的系统 SIM"),"24.7 completed failing draft discovery");
            check(label("RCS · 不可用") && handoffButton()==null && !enabled(session()),"24.7 user observed blocked state and no manual entry");
            check(BODY.equals(body(session())) && receipts.isEmpty(),"24.7 retained input and opened no draft");
            restoreOriginalRole();
            return;
        }
        Object route=capture(peer);
        check(Boolean.TRUE.equals(NativeRcsFixture.get(route,"requiresManualSim")),"hidden subscription yields manual route");
        check("Offline RCS probe".equals(NativeRcsFixture.get(route,"appLabel")),"actual SMS app name");
        rejects(()->open(route,"+331632960249"),"stale recipient blocked");
        readerField.set(null,NativeRcsFixture.raw(type("qf3")));
        rejects(()->open(route,peer),"changed physical reader blocked");
        readerField.set(null,reader);
        fixture.changeCard();rejects(()->open(route,peer),"changed local profile blocked");fixture.resetCard();
        prepareForm();
        assertUiReady();
        // Exercise both no-exported-chat and no-direct-own-number independently on each native form.
        toggleMode(false);
        fixture.helper("RcsChatBinding").getMethod("clear",Object.class).invoke(null,fixture.engine);
        toggleMode(true);assertUiReady();
        Object page=session();
        check(handoffButton().performAction(AccessibilityNodeInfo.ACTION_CLICK),"tap the visible named pick-SIM action");
        await(()->receipts.size()==1,"chosen external compose Activity receives one draft");
        Intent reply=receipts.get(0);
        check(Intent.ACTION_SENDTO.equals(reply.getStringExtra("action")),"external draft action");
        check("smsto".equals(reply.getStringExtra("scheme")) && peer.equals(reply.getStringExtra("peer")),"entered peer only");
        check(BODY.equals(reply.getStringExtra("body")) && "[sms_body]".equals(reply.getStringExtra("keys")),"exactly typed body; no subscription/subId/SIM/transport hints");
        check((PROVIDER+"/rcssmoke.SmsRoleComponents$ComposeActivity").equals(reply.getStringExtra("component")),"explicit default SMS Activity");
        check(reply.getIntExtra("pid",-1)>0 && reply.getIntExtra("pid",-1)!=android.os.Process.myPid(),"distinct Activity process");
        check(BODY.equals(body(page)) && navigations==0,"original draft remains, no SIMHub SMS navigation");
        check(((List<?>)NativeRcsFixture.get(fixture.state,"q")).isEmpty(),"no outgoing SIMHub SMS record");
        restoreOriginalRole();rejects(()->open(route,peer),"previous target invalid after default role change");
        SystemClock.sleep(250);check(receipts.size()==1,"no repeat or post-role-change launch");
    }
    @Override public void onStart() {
        Throwable failure=null;
        try{
            activity=startActivitySync(new Intent().setClassName("cc.forserein.simhub","cc.forserein.simhub.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            waitForIdleSync();
            getTargetContext().registerReceiver(ack,new IntentFilter("rcssmoke.HANDOFF_RECEIPT"),OfflineRcsProvider.PERMISSION,null,Context.RECEIVER_EXPORTED);
            receiveRegistered=true;fixture=new NativeRcsFixture(getTargetContext());runHandoff();
        }catch(Throwable e){failure=e;}
        finally{
            try {
                if(readerField!=null)readerField.set(null,priorReader);
                if(receiveRegistered)getTargetContext().unregisterReceiver(ack);
                if(activity!=null && !activity.isFinishing())main(()->activity.finish());
                if(fixture!=null)fixture.close();
            }catch(Throwable cleanup){if(failure==null)failure=cleanup;else failure.addSuppressed(cleanup);}
        }
        Bundle out=new Bundle();
        out.putString("status",failure==null?"passed":"failed");out.putInt("checks",checks);
        out.putString("form",thread?"existing conversation":"new message");
        out.putInt("actual_external_draft_receipts",receipts.size());out.putBoolean("full_iccid_hidden",hidden);
        out.putBoolean("adopted_subscriber_permissions",false);out.putBoolean("baseline_24_7",previous);
        out.putString("scope","Installed native SMS form and accessibility clicks. Real Android subscription APIs and role, synthetic local SIMHub OMAPI reader/card; inert external compose Activity accepts reserved test input only. Zero carrier traffic.");
        if(failure!=null)out.putString("error",android.util.Log.getStackTraceString(failure));
        finish(failure==null?0:1,out);
    }
}
