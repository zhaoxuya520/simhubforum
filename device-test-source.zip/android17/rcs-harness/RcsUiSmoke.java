package rcssmoke;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.util.Base64;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.ByteArrayOutputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.*;
import java.util.*;

/** Actual shipped pk5.j thread and native send callbacks with synthetic data. */
public final class RcsUiSmoke extends Instrumentation {
 private Activity activity;private NativeRcsFixture fixture;private OfflineRcsProvider provider;
 private Object session,draft,transport;private int checks,nativeSendCallbacks;private final List<String> captures=new ArrayList<>();
 private interface Work{void run()throws Exception;}private interface Condition{boolean ready()throws Exception;}
 private void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
 private void main(Work work){final Throwable[] failure={null};runOnMainSync(()->{try{work.run();}catch(Throwable error){failure[0]=error;}});if(failure[0]!=null)throw new AssertionError("main-thread fixture",failure[0]);}
 private void await(Condition condition,String label)throws Exception{long end=SystemClock.uptimeMillis()+20000;while(SystemClock.uptimeMillis()<end){if(condition.ready()){checks++;return;}SystemClock.sleep(50);}throw new AssertionError("timeout "+label+"\n"+tree(getUiAutomation().getRootInActiveWindow(),0));}
 private Class<?> type(String name)throws Exception{return fixture.type(name);}
 private Class<?> ui()throws Exception{return fixture.helper("RcsChatUi");}
 private Object current()throws Exception{Field f=ui().getDeclaredField("current");f.setAccessible(true);return f.get(null);}
 private Object field(Object value,String name)throws Exception{return NativeRcsFixture.get(value,name);}
 private void set(Object value,String name,Object data)throws Exception{NativeRcsFixture.set(value,name,data);}
 private Object invoke(Object value,String name,Class<?>[] signature,Object...args)throws Exception{Method m=value.getClass().getDeclaredMethod(name,signature);m.setAccessible(true);return m.invoke(value,args);}
 private Object unit()throws Exception{return type("sc5").getField("a").get(null);}
 private Object callback(String name,java.util.function.Function<Object[],Object> action)throws Exception{
  return Proxy.newProxyInstance(fixture.loader,new Class<?>[]{type(name)},(proxy,method,args)->{
   if(method.getDeclaringClass()==Object.class){if(method.getName().equals("equals"))return proxy==args[0];if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);return "Offline RCS native screen fixture";}return action.apply(args);
  });
 }
 private Object composable(int key,Object callback)throws Exception{return type("zn0").getConstructor(int.class,boolean.class,type("gt1")).newInstance(key,true,callback);}
 private void render()throws Exception{
  Object back=callback("us1",args->{try{return unit();}catch(Exception e){throw new RuntimeException(e);}});
  Object body=callback("kt1",args->{try{
   type("pk5").getMethod("j",type("em0"),type("gl5"),String.class,String.class,type("us1"),type("lu1"),int.class)
    .invoke(null,type("em0").getField("a").get(null),fixture.state,NativeRcsFixture.PEER,"离线测试联系人",back,args[0],0);
   return unit();
  }catch(Exception e){throw new RuntimeException(e);}});
  Object inner=composable(246100,body);
  Object theme=callback("kt1",args->{try{type("z55").getMethod("a",type("zn0"),type("lu1"),int.class).invoke(null,inner,args[0],0);return unit();}catch(Exception e){throw new RuntimeException(e);}});
  type("sn0").getMethod("a",type("rn0"),type("zn0")).invoke(null,activity,composable(246101,theme));
 }
 private String tree(AccessibilityNodeInfo node,int depth){if(node==null||depth>30)return "";Rect bounds=new Rect();node.getBoundsInScreen(bounds);StringBuilder out=new StringBuilder();out.append(node.getClassName()).append(':').append(node.getText()).append(':').append(node.getContentDescription()).append(":enabled=").append(node.isEnabled()).append(":clickable=").append(node.isClickable()).append(":checked=").append(node.isChecked()).append(':').append(bounds).append('\n');for(int i=0;i<node.getChildCount();i++)out.append(tree(node.getChild(i),depth+1));return out.toString();}
 private AccessibilityNodeInfo toggle(AccessibilityNodeInfo node){if(node==null)return null;if(node.isCheckable())return node;for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo found=toggle(node.getChild(i));if(found!=null)return found;}return null;}
 private AccessibilityNodeInfo edit(AccessibilityNodeInfo node){if(node==null)return null;if(node.isEditable())return node;for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo found=edit(node.getChild(i));if(found!=null)return found;}return null;}
 private void buttons(AccessibilityNodeInfo node,List<AccessibilityNodeInfo> out){if(node==null)return;if(node.isClickable()&&!node.isCheckable()&&!node.isEditable())out.add(node);for(int i=0;i<node.getChildCount();i++)buttons(node.getChild(i),out);}
 private AccessibilityNodeInfo sendButton(){AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow(),input=edit(root);if(input==null)return null;Rect text=new Rect();input.getBoundsInScreen(text);List<AccessibilityNodeInfo> options=new ArrayList<>();buttons(root,options);AccessibilityNodeInfo best=null;int score=Integer.MAX_VALUE;for(AccessibilityNodeInfo candidate:options){Rect r=new Rect();candidate.getBoundsInScreen(r);if(r.width()<=0||r.height()<=0||r.centerX()<text.centerX()||r.centerY()<text.top-10||r.centerY()>text.bottom+30)continue;int rank=Math.abs(r.centerY()-text.centerY())+r.width()+r.height();if(rank<score){score=rank;best=candidate;}}return best;}
 private String draftText()throws Exception{return (String)type("ot4").getMethod("getValue").invoke(draft);}
 private void draftText(String value)throws Exception{main(()->type("m83").getMethod("setValue",Object.class).invoke(draft,value));}
 private boolean enabled(boolean original)throws Exception{return (Boolean)ui().getMethod("sendEnabled",boolean.class,String.class,Object.class).invoke(null,original,NativeRcsFixture.PEER,draft);}
 private void screenshot(String label)throws Exception{
  try{getUiAutomation().waitForIdle(250,4000);}catch(java.util.concurrent.TimeoutException ignored){}
  Bitmap image=getUiAutomation().takeScreenshot();check(image!=null,label+" screenshot");ByteArrayOutputStream bytes=new ByteArrayOutputStream();image.compress(Bitmap.CompressFormat.PNG,100,bytes);image.recycle();
  Bundle status=new Bundle();status.putString("capture",label);status.putString("png_base64",Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP));status.putString("accessibility_tree",tree(getUiAutomation().getRootInActiveWindow(),0));sendStatus(0,status);captures.add(label);
 }
 private void threadCallback(boolean nativeEnabled)throws Exception{
  main(()->{Object action=type("j51").getConstructor(boolean.class,String.class,type("m83")).newInstance(nativeEnabled,NativeRcsFixture.PEER,draft);Object result=type("j51").getMethod("a").invoke(action);nativeSendCallbacks++;check(result==unit(),"actual native thread callback returns Unit");});
 }
 private void newDraftCallback()throws Exception{
  main(()->{Object peer=type("qd2").getMethod("D",Object.class).invoke(null,NativeRcsFixture.PEER);Object nav=callback("ws1",args->{throw new AssertionError("RCS consumed new draft must not navigate to native SMS thread");});Object action=type("zz").getConstructor(boolean.class,type("gt1"),type("m83"),type("m83"),int.class).newInstance(true,nav,peer,draft,3);Object result=type("zz").getMethod("a").invoke(action);nativeSendCallbacks++;check(result==unit(),"actual new-message callback consumes requested RCS");});
 }
 private void cases()throws Exception{
  main(()->render());await(()->tree(getUiAutomation().getRootInActiveWindow(),0).contains("RCS · 已关闭"),"native thread RCS toggle off");
  session=current();check(session!=null,"native render created RCS session");draft=((WeakReference<?>)field(session,"draft")).get();check(draft!=null,"native existing draft captured");draftText("离线 RCS 测试消息");
  await(()->edit(getUiAutomation().getRootInActiveWindow())!=null,"existing native message field");
  check(enabled(true)&&!enabled(false),"off preserves true/false original SMS predicate");
  check(tree(getUiAutomation().getRootInActiveWindow(),0).contains("Enable and register before sending."),"off keeps SMS registration hint on English emulator");
  check(!(Boolean)ui().getMethod("trySend",String.class,Object.class).invoke(null,NativeRcsFixture.PEER,draft),"off delegates to original SMS callback");threadCallback(false);check("离线 RCS 测试消息".equals(draftText()),"off native disabled send preserves draft");screenshot("thread-off-original-sms");
  AccessibilityNodeInfo control=toggle(getUiAutomation().getRootInActiveWindow());check(control!=null&&!control.isChecked(),"actual RCS switch is off");check(control.performAction(AccessibilityNodeInfo.ACTION_CLICK),"actual switch click accepted");
  await(()->tree(getUiAutomation().getRootInActiveWindow(),0).contains("RCS · 不可用"),"no emulator RCS provider");
  check(!tree(getUiAutomation().getRootInActiveWindow(),0).contains("Enable and register before sending."),"unavailable RCS hides unrelated SMS hint");check(toggle(getUiAutomation().getRootInActiveWindow()).isChecked(),"requested RCS remains on after unavailable");check(!enabled(true),"unavailable RCS disables original send");
  threadCallback(true);newDraftCallback();check("离线 RCS 测试消息".equals(draftText()),"both actual callbacks preserve draft and block SMS fallback");check(((List<?>)field(fixture.state,"q")).isEmpty(),"no pending native SMS created by RCS failure");screenshot("thread-on-unavailable-no-fallback");
  // Replace only the UI session's provider context with an explicit test fixture.
  // The real installed adapter, typed IPC and original visible send key still run.
  provider=new OfflineRcsProvider(getTargetContext());Object binding=field(session,"binding");check(binding!=null,"synthetic native registered line captured");
  main(()->{Object old=field(session,"transport");if(old!=null)old.getClass().getMethod("close").invoke(old);Class<?> api=fixture.helper("RcsChatTransport");transport=api.getConstructor(Context.class,fixture.helper("RcsChatBinding"),fixture.helper("RcsChatTransport$Listener")).newInstance(provider,binding,session);set(session,"transport",transport);set(session,"connecting",true);set(session,"failed",false);api.getMethod("connect").invoke(transport);});
  await(()->tree(getUiAutomation().getRootInActiveWindow(),0).contains("RCS · 已连接"),"actual provider ready updates same thread");
  check(enabled(false),"RCS ready enables existing send independent of original SMS predicate");
  check(!tree(getUiAutomation().getRootInActiveWindow(),0).contains("Enable and register before sending."),"connected RCS does not display native SMS registration hint");await(()->sendButton()!=null&&sendButton().isEnabled(),"original native send button enabled");screenshot("thread-connected-fixture-original-send");
  AccessibilityNodeInfo send=sendButton();Rect sendBounds=new Rect();send.getBoundsInScreen(sendBounds);check(send.performAction(AccessibilityNodeInfo.ACTION_CLICK),"actual original native send button click");
  await(()->provider.sends==1,"one provider send from original button");await(()->draftText().isEmpty(),"acknowledgement clears same native draft");
  check(provider.records.size()==1,"one typed outgoing message");check(((List<?>)field(fixture.state,"q")).isEmpty(),"RCS send did not create SMS history row");screenshot("thread-fixture-send-accepted");
  provider.incoming("ui-incoming","测试服务收到的回复",NativeRcsFixture.PEER,System.currentTimeMillis());provider.signalIncoming("ui-incoming");await(()->tree(getUiAutomation().getRootInActiveWindow(),0).contains("测试服务收到的回复"),"typed incoming shown within thread");screenshot("thread-fixture-incoming");
  draftText("切卡后保留此草稿");fixture.changeCard();main(()->invoke(session,"validateBinding",new Class<?>[]{}));await(()->!enabled(true),"card switch blocks original send");
  await(()->!tree(getUiAutomation().getRootInActiveWindow(),0).contains("测试服务收到的回复"),"prior line's incoming message hidden after card switch");
  check(field(session,"historyKey")==null&&!Boolean.TRUE.equals(field(session,"historyOpen")),"invalidated line detaches old history and closes history view");
  threadCallback(true);check(provider.sends==1&&"切卡后保留此草稿".equals(draftText()),"switched card does not resend or clear draft");
  fixture.resetCard();AccessibilityNodeInfo off=toggle(getUiAutomation().getRootInActiveWindow());check(off!=null&&off.isChecked(),"failed selected RCS mode still explicit");check(off.performAction(AccessibilityNodeInfo.ACTION_CLICK),"explicit off returns to SMS mode");await(()->enabled(true),"off restores original SMS predicate");await(()->tree(getUiAutomation().getRootInActiveWindow(),0).contains("Enable and register before sending."),"off restores original SMS registration hint");check(provider.sends==1,"toggle off did not send");
  main(()->activity.finish());await(()->!Boolean.TRUE.equals(field(session,"active")),"Activity destroy retires native Compose session");check(field(session,"transport")==null,"destroy releases provider transport");check(provider.unbinds==provider.binds,"provider unbound after switch/destroy");
 }
 @Override public void onCreate(Bundle arguments){super.onCreate(arguments);start();}
 @Override public void onStart(){Bundle result=new Bundle();Throwable problem=null;try{
  runOnMainSync(()->{});activity=startActivitySync(new Intent().setClassName("cc.forserein.simhub","cc.forserein.simhub.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));waitForIdleSync();fixture=new NativeRcsFixture(getTargetContext());cases();
 }catch(Throwable error){problem=error;}finally{try{if(activity!=null&&!activity.isFinishing())main(()->activity.finish());if(transport!=null)transport.getClass().getMethod("close").invoke(transport);if(provider!=null)provider.close();if(fixture!=null)fixture.close();}catch(Throwable cleanup){if(problem==null)problem=cleanup;else problem.addSuppressed(cleanup);}}
  result.putString("status",problem==null?"passed":"failed");result.putInt("checks",checks);result.putInt("native_callback_invocations",nativeSendCallbacks);result.putInt("provider_send_calls",provider==null?0:provider.sends);result.putInt("binder_transactions",provider==null?0:provider.transactions);result.putStringArrayList("captures",new ArrayList<>(captures));
  result.putString("scope","Actual installed pk5.j SMS thread rendered inside MainActivity under native z55 theme, synthetic card/engine/registration and peer. Toggle and original send button clicked through Accessibility. Native j51/zz callback failures also invoked. Connected UI session uses a deliberately substituted ContextWrapper fixture running actual installed RcsChatTransport and typed Binder Proxy/Parcel, not an OEM/carrier. No full navigation, real subscription, real network or private message.");
  if(problem!=null)result.putString("error",android.util.Log.getStackTraceString(problem));finish(problem==null?0:1,result);
 }
}
