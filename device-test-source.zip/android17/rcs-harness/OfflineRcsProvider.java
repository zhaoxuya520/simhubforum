package rcssmoke;

import android.content.*;
import android.content.pm.*;
import android.os.*;
import com.gsma.services.rcs.*;
import com.gsma.services.rcs.chat.*;
import com.gsma.services.rcs.contact.ContactId;
import java.util.*;

/** In-process typed provider with forced Binder Proxy/Parcel calls and synthetic data only. */
public class OfflineRcsProvider extends ContextWrapper {
 public static final String ACTION="com.gsma.services.rcs.chat.IChatService",PERMISSION="com.gsma.services.permission.RCS";
 public volatile boolean available=true,trusted=true,compatible=true,registered=true,allowSend=true,failSend=false;
 public volatile String local=NativeRcsFixture.LOCAL;
 public volatile boolean componentEnabled=true, exported=true, properPermission=true, granted=true;
 public volatile int limit=16384,serviceVersion=2,sends,binds,unbinds,transactions,compatibilityRequests,removedListeners;
 public volatile BroadcastReceiver incoming;public volatile ServiceConnection connection;
 public volatile IOneToOneChatListener messageListener;public volatile IRcsServiceRegistrationListener registrationListener;
 public final Map<String,Message> records=Collections.synchronizedMap(new LinkedHashMap<>());
 private final Handler main=new Handler(Looper.getMainLooper());private final ServiceInfo service;private final PackageManager pm;
 private final BroadcastReceiver compatibilityReceiver;
 public OfflineRcsProvider(Context context){this(context,context.getPackageName(),android.os.Process.myUid());}
 protected OfflineRcsProvider(Context context,String packageName,int uid){
  super(context);service=new ServiceInfo();service.packageName=packageName;service.name=packageName+".OfflineFixtureService";service.permission=PERMISSION;service.enabled=true;service.exported=true;service.nonLocalizedLabel="Offline RCS fixture";
  service.applicationInfo=new ApplicationInfo();service.applicationInfo.packageName=service.packageName;service.applicationInfo.enabled=true;service.applicationInfo.uid=uid;service.applicationInfo.flags=ApplicationInfo.FLAG_SYSTEM;
  pm=new ForwardingPackageManager(context.getPackageManager()){
   // Android 11's Telephony.Sms default-app lookup also calls hidden per-user PM methods.
   // This disposable fixture operates solely in user 0 and forwards their public equivalents.
   public List<ResolveInfo> queryBroadcastReceiversAsUser(Intent intent,int flags,int user) {
    if(user!=0)throw new IllegalArgumentException("Unexpected test user");
    return delegate.queryBroadcastReceivers(intent, flags);
   }
   public List<ResolveInfo> queryIntentActivitiesAsUser(Intent intent,int flags,int user) {
    if(user!=0)throw new IllegalArgumentException("Unexpected test user");
    return delegate.queryIntentActivities(intent, flags);
   }
   public List<ResolveInfo> queryIntentServicesAsUser(Intent intent,int flags,int user) {
    if(user!=0)throw new IllegalArgumentException("Unexpected test user");
    return delegate.queryIntentServices(intent, flags);
   }
   @Override public List<ResolveInfo> queryIntentServices(Intent intent,int flags){if(!ACTION.equals(intent.getAction()))return super.queryIntentServices(intent,flags);if(!available||(!componentEnabled&&(flags&PackageManager.MATCH_DISABLED_COMPONENTS)==0))return Collections.emptyList();ServiceInfo s=fresh();ResolveInfo r=new ResolveInfo();r.serviceInfo=s;return Collections.singletonList(r);}
   @Override public ServiceInfo getServiceInfo(ComponentName name,int flags)throws NameNotFoundException{if(name.getClassName().equals(service.name))return fresh();return super.getServiceInfo(name,flags);}
   @Override public PermissionInfo getPermissionInfo(String name,int flags)throws NameNotFoundException{if(!PERMISSION.equals(name))return super.getPermissionInfo(name,flags);PermissionInfo info=new PermissionInfo();info.name=name;info.packageName=service.packageName;return info;}
  };
  compatibilityReceiver=new BroadcastReceiver(){public void onReceive(Context context,Intent intent){Bundle result=new Bundle();result.putBoolean("get_compatibility_response",compatible);setResultExtras(result);}};
  context.registerReceiver(compatibilityReceiver,new IntentFilter("rcssmoke.COMPAT"),Context.RECEIVER_NOT_EXPORTED);
 }
 public static ContactId contact(String value){Parcel p=Parcel.obtain();try{p.writeString(value);p.setDataPosition(0);return ContactId.CREATOR.createFromParcel(p);}finally{p.recycle();}}
 public void status(String id,int value)throws Exception{Message m=records.get(id);m.status=value;if(messageListener!=null)messageListener.onMessageStatusChanged(contact(m.peer),"text/plain",id,value,0);}
 public void unregister()throws Exception{registered=false;if(registrationListener!=null)registrationListener.onServiceUnregistered(0);}
 private ServiceInfo fresh(){ServiceInfo value=new ServiceInfo(service);value.applicationInfo=new ApplicationInfo(service.applicationInfo);value.applicationInfo.flags=trusted?ApplicationInfo.FLAG_SYSTEM:0;value.enabled=componentEnabled;value.exported=exported;value.permission=properPermission?PERMISSION:null;return value;}
 @Override public Context getApplicationContext(){return this;}
 @Override public PackageManager getPackageManager(){return pm;}
 @Override public int checkSelfPermission(String permission){return PERMISSION.equals(permission)?(granted?PackageManager.PERMISSION_GRANTED:PackageManager.PERMISSION_DENIED):super.checkSelfPermission(permission);}
 @Override public void sendOrderedBroadcast(Intent intent,String permission,BroadcastReceiver result,Handler scheduler,int initialCode,String initialData,Bundle initialExtras){
  if(!"com.gsma.services.rcs.action.GET_COMPATIBILITY".equals(intent.getAction()))throw new AssertionError("unexpected broadcast");
  if(!service.packageName.equals(intent.getPackage())||!"ChatService".equals(intent.getStringExtra("get_compatibility_service"))||intent.getIntExtra("get_compatibility_version",-1)!=2)throw new AssertionError("incorrect compatibility request");
  compatibilityRequests++;super.sendOrderedBroadcast(new Intent("rcssmoke.COMPAT").setPackage(getPackageName()),null,result,scheduler,initialCode,initialData,initialExtras);
 }
 @Override public boolean bindService(Intent intent,ServiceConnection callback,int flags){
  if(!ACTION.equals(intent.getAction())||!service.name.equals(intent.getComponent().getClassName()))throw new AssertionError("wrong bind target");
  binds++;connection=callback;main.post(()->callback.onServiceConnected(intent.getComponent(),remote(api)));return true;
 }
 @Override public void unbindService(ServiceConnection callback){unbinds++;if(connection==callback)connection=null;}
 @Override public Intent registerReceiver(BroadcastReceiver receiver,IntentFilter filter,String permission,Handler scheduler,int flags){
  if(!PERMISSION.equals(permission))throw new AssertionError("missing incoming permission filter");incoming=receiver;return null;
 }
 @Override public Intent registerReceiver(BroadcastReceiver receiver,IntentFilter filter,String permission,Handler scheduler){return registerReceiver(receiver,filter,permission,scheduler,0);}
 @Override public void unregisterReceiver(BroadcastReceiver receiver){if(incoming==receiver)incoming=null;else super.unregisterReceiver(receiver);}
 protected synchronized void recordSend(){sends++;}
 public void close(){if(compatibilityReceiver!=null)getBaseContext().unregisterReceiver(compatibilityReceiver);}
 private IBinder remote(final IBinder local){
  return new Binder(){
   @Override public IInterface queryLocalInterface(String descriptor){return null;}
   @Override public String getInterfaceDescriptor(){try{return local.getInterfaceDescriptor();}catch(Exception error){throw new RuntimeException(error);}}
   @Override protected boolean onTransact(int code,Parcel data,Parcel reply,int flags)throws RemoteException{transactions++;return local.transact(code,data,reply,flags);}
  };
 }
 public final class Message extends IChatMessage.Stub {
  public final String id,body,peer;public final int direction;public volatile int status;public long timestamp;
  Message(String id,String body,String peer,int direction,int status,long timestamp){this.id=id;this.body=body;this.peer=peer;this.direction=direction;this.status=status;this.timestamp=timestamp;}
  @Override public IBinder asBinder(){return remote(this);}
  public ContactId getContact(){return contact(peer);}public String getId(){return id;}public String getContent(){return body;}public String getMimeType(){return "text/plain";}public int getDirection(){return direction;}public long getTimestamp(){return timestamp;}public long getTimestampSent(){return timestamp;}public long getTimestampDelivered(){return 0;}public long getTimestampDisplayed(){return 0;}public int getStatus(){return status;}public int getReasonCode(){return 0;}public String getChatId(){return peer;}public boolean isRead(){return false;}public boolean isExpiredDelivery(){return false;}
 }
 public Message incoming(String id,String body,String peer,long timestamp){Message value=new Message(id,body,peer,0,7,timestamp);records.put(id,value);return value;}
 public void signalIncoming(String id){BroadcastReceiver receiver=incoming;if(receiver==null)throw new AssertionError("incoming listener not registered");main.post(()->receiver.onReceive(this,new Intent("com.gsma.services.rcs.chat.action.NEW_ONE_TO_ONE_CHAT_MESSAGE").putExtra("messageId",id).putExtra("body","untrusted broadcast body")));}
 private final ICommonServiceConfiguration.Stub common=new ICommonServiceConfiguration.Stub(){
  @Override public IBinder asBinder(){return remote(this);}
  public int getDefaultMessagingMethod(){return 0;}public int getMessagingUX(){return 0;}public ContactId getMyContactId(){return contact(local);}public String getMyDisplayName(){return "fixture";}public boolean isConfigValid(){return true;}public void setDefaultMessagingMethod(int value){}public void setMyDisplayName(String value){}public int getMinimumBatteryLevel(){return 0;}public void setMinimumBatteryLevel(int value){}
 };
 private final IChatServiceConfiguration.Stub configuration=new IChatServiceConfiguration.Stub(){
  @Override public IBinder asBinder(){return remote(this);}
  public long getIsComposingTimeout(){return 0;}public long getGeolocExpirationTime(){return 0;}public int getGeolocLabelMaxLength(){return 0;}public int getGroupChatMaxParticipants(){return 0;}public int getGroupChatMessageMaxLength(){return limit;}public int getGroupChatMinParticipants(){return 0;}public int getGroupChatSubjectMaxLength(){return 0;}public int getOneToOneChatMessageMaxLength(){return limit;}public boolean isChatWarnSF(){return false;}public boolean isGroupChatSupported(){return false;}public boolean isRespondToDisplayReportsEnabled(){return false;}public boolean isSmsFallback(){return false;}public void setRespondToDisplayReports(boolean enabled){}
 };
 private IOneToOneChat chat(final ContactId peer){return new IOneToOneChat.Stub(){
  @Override public IBinder asBinder(){return remote(this);}
  public ContactId getRemoteContact(){return peer;}public boolean isAllowedToSendMessage(){return allowSend;}public void openChat(){}public void setComposingStatus(boolean composing){}public void resendMessage(String id){throw new AssertionError("unexpected resend");}public IChatMessage sendMessage2(Geoloc location){throw new AssertionError("unexpected geolocation");}
  public IChatMessage sendMessage(String text)throws RemoteException{recordSend();if(failSend)throw new RemoteException("synthetic provider uncertainty");Message value=new Message("fixture-out-"+sends,text,peer.toString(),1,1,System.currentTimeMillis());records.put(value.id,value);return value;}
 };}
 public IBinder serviceBinder(){return remote(api);}
 private final IChatService.Stub api=new IChatService.Stub(){
  public boolean isServiceRegistered(){return registered;}public int getServiceRegistrationReasonCode(){return 0;}public int getServiceVersion(){return serviceVersion;}public void addEventListener(IRcsServiceRegistrationListener value){registrationListener=IRcsServiceRegistrationListener.Stub.asInterface(remote(value.asBinder()));}public void removeEventListener(IRcsServiceRegistrationListener value){registrationListener=null;removedListeners++;}public void addEventListener2(IOneToOneChatListener value){messageListener=IOneToOneChatListener.Stub.asInterface(remote(value.asBinder()));}public void removeEventListener2(IOneToOneChatListener value){messageListener=null;removedListeners++;}public void addEventListener3(IGroupChatListener value){}public void removeEventListener3(IGroupChatListener value){}
  public IChatServiceConfiguration getConfiguration(){return configuration;}public ICommonServiceConfiguration getCommonConfiguration(){return common;}public IOneToOneChat getOneToOneChat(ContactId peer){return chat(peer);}public IChatMessage getChatMessage(String id){return records.get(id);}public IGroupChat initiateGroupChat(List<ContactId> contacts,String subject){throw new AssertionError("unexpected group");}public IGroupChat getGroupChat(String id){throw new AssertionError("unexpected group");}public void markMessageAsRead(String id){}public boolean isAllowedToInitiateGroupChat(){return false;}public boolean isAllowedToInitiateGroupChat2(ContactId contact){return false;}public void deleteOneToOneChats(){throw new AssertionError("unexpected delete");}public void deleteGroupChats(){throw new AssertionError("unexpected delete");}public void deleteOneToOneChat(ContactId contact){throw new AssertionError("unexpected delete");}public void deleteGroupChat(String id){throw new AssertionError("unexpected delete");}public void deleteMessage(String id){throw new AssertionError("unexpected delete");}public void clearMessageDeliveryExpiration(List<String> ids){}
 };
}
