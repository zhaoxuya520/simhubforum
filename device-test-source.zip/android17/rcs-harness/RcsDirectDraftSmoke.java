package rcssmoke;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Telephony;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Ordinary-permission, installed core test. No native view click or proof of foreground view rendering. */
public final class RcsDirectDraftSmoke extends RcsComposeNewSmoke {
    private static final String DEFAULT = "cc.forserein.simhub.rcssmoke";
    private static final String TEXT = "系统编辑器草稿：仅测试，不发送";
    private final List<Intent> receipts = new CopyOnWriteArrayList<>();
    private final BroadcastReceiver recipient = new BroadcastReceiver() {
        public void onReceive(Context c, Intent data) { receipts.add(new Intent(data)); }
    };
    private boolean ordinaryHidden() {
        try {
            List<SubscriptionInfo> all=getTargetContext().getSystemService(SubscriptionManager.class).getActiveSubscriptionInfoList();
            if (all!=null) for (SubscriptionInfo info : all) {
                String id=info.getIccId();
                if(id!=null && id.matches("[0-9]{19,20}")) return false;
            }
        } catch (SecurityException hidden) { return true; }
        return true;
    }
    @Override public void onStart() {
        Throwable failure=null;
        Field reader=null;
        Object previous=null;
        boolean registered=false, hidden=false;
        try {
            Context target=getTargetContext();
            activity=startActivitySync(new Intent().setClassName("cc.forserein.simhub","cc.forserein.simhub.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            target.registerReceiver(recipient,new IntentFilter("rcssmoke.HANDOFF_RECEIPT"),OfflineRcsProvider.PERMISSION,null,Context.RECEIVER_EXPORTED);
            registered=true;
            check("cc.forserein.simhub".equals(target.getPackageName()),"real release context");
            check(DEFAULT.equals(Telephony.Sms.getDefaultSmsPackage(target)),"actual Android SMS role");
            check(target.checkSelfPermission("android.permission.READ_PRIVILEGED_PHONE_STATE")==PackageManager.PERMISSION_DENIED,"no privileged identity");
            hidden=ordinaryHidden(); check(hidden,"system conceals active ICCID");
            fixture=new NativeRcsFixture(target);
            reader=fixture.type("zl5").getField("j"); previous=reader.get(null);
            reader.set(null,NativeRcsFixture.raw(fixture.type("qf3")));
            Class<?> composer=fixture.helper("RcsSystemComposer");
            Object route=composer.getMethod("capture",Context.class,Object.class,String.class).invoke(null,activity,fixture.state,NativeRcsFixture.PEER);
            check(Boolean.TRUE.equals(NativeRcsFixture.get(route,"requiresManualSim")),"actual capture yielded explicit manual route");
            check("Offline RCS probe".equals(NativeRcsFixture.get(route,"appLabel")),"returned selected SMS application");
            check(receipts.isEmpty(),"capture does not launch a draft");
            java.lang.reflect.Method open=composer.getMethod("open",Activity.class,Object.class,String.class,String.class);
            try {
                open.invoke(route,activity,fixture.state,"+331632960249",TEXT);
                throw new AssertionError("changed recipient accepted");
            } catch(InvocationTargetException stale) {
                check(stale.getCause() instanceof IllegalStateException,"stale recipient");
            }
            main(()->open.invoke(route,activity,fixture.state,NativeRcsFixture.PEER,TEXT));
            long end=SystemClock.elapsedRealtime()+90000;
            while(receipts.isEmpty() && SystemClock.elapsedRealtime()<end)SystemClock.sleep(75);
            check(receipts.size()==1,"external activity accepted one draft after core open");
            Intent reply=receipts.get(0);
            check(Intent.ACTION_SENDTO.equals(reply.getStringExtra("action")) && "smsto".equals(reply.getStringExtra("scheme")),"real Android draft Intent");
            check(NativeRcsFixture.PEER.equals(reply.getStringExtra("peer")) && TEXT.equals(reply.getStringExtra("body")),"target and draft preserved");
            check("[sms_body]".equals(reply.getStringExtra("keys")),"no subscription or transport hints");
            check((DEFAULT+"/rcssmoke.SmsRoleComponents$ComposeActivity").equals(reply.getStringExtra("component")),"real default component");
            check(reply.getIntExtra("pid",-1)>0 && reply.getIntExtra("pid",-1)!=Process.myPid(),"independent receiving process");
            check(((List<?>)NativeRcsFixture.get(fixture.state,"q")).isEmpty(),"no outgoing native SMS record");
        } catch(Throwable e){failure=e;} finally {
            try {
                if(reader!=null)reader.set(null,previous);
                if(registered)getTargetContext().unregisterReceiver(recipient);
                if(activity!=null&&!activity.isFinishing())main(()->activity.finish());
                if(fixture!=null)fixture.close();
            }catch(Throwable e){if(failure==null)failure=e;else failure.addSuppressed(e);}
        }
        Bundle b=new Bundle();b.putString("status",failure==null?"passed":"failed");b.putInt("checks",checks);
        b.putInt("actual_external_draft_receipts",receipts.size());b.putBoolean("full_iccid_hidden",hidden);
        b.putBoolean("adopted_subscriber_permissions",false);b.putBoolean("ui_clicked",false);
        b.putString("scope","Actual signed release core capture/open, real Android SMS role and external activity, synthetic native reader/card. Zero carrier traffic.");
        if(failure!=null)b.putString("error",android.util.Log.getStackTraceString(failure));
        finish(failure==null?0:1,b);
    }
}
