from pathlib import Path
import subprocess, re, hashlib, json, time, datetime
root=Path(__file__).resolve().parent; h=root/'rcs-harness'
adb=['/workspace/tools/android-platform-tools/platform-tools/adb','-s','emulator-5582']
app='cc.forserein.simhub'; fixture=app+'.rcssmoke'; role='android.app.role.SMS'
signed='dcb52b9b0ea1f0115de88015490a1ae9b723187f180904938266ed71a7451efb'
def run(*cmd,timeout=130):
 p=subprocess.run(adb+list(map(str,cmd)),capture_output=True,text=True,timeout=timeout)
 if p.returncode: raise RuntimeError((p.stdout+p.stderr).strip()[:700])
 return p.stdout.strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pkgname(pkg):
    out=run('shell','cmd','package','path',pkg)
    path=re.fullmatch(r'package:(/[^\s]+/base.apk)',out)[1]
    return run('shell','sha256sum',path).split()[0]
def holder(): return run('shell','cmd','role','get-role-holders','--user','0',role)
def choose(pkg):
 for i in range(3):
    if holder()==pkg: return
    try:run('shell','cmd','role','add-role-holder','--user','0',role,pkg,'1')
    except RuntimeError as e:print('Waiting for asynchronous role update:',str(e)[:190],flush=True)
    for j in range(14):
        if holder()==pkg:return
        time.sleep(1)
 raise RuntimeError('Expected SMS role owner '+pkg)
def change(state):
 out=run('shell','am','instrument','-w','-e','state',state,fixture+'/rcssmoke.FixtureChatState',timeout=280)
 assert 'INSTRUMENTATION_RESULT: status=passed' in out and 'INSTRUMENTATION_CODE: 0' in out
def available(): return fixture+'/' in run('shell','cmd','package','query-services','--components','--user','0','-a','com.gsma.services.rcs.chat.IChatService')
until=time.monotonic()+420
while time.monotonic()<until:
 if (root/'fixture-core-install.log').exists() and 'Success' in (root/'fixture-core-install.log').read_text(): break
 time.sleep(3)
else:raise RuntimeError('Core fixture missing')
assert run('shell','getprop','ro.build.version.sdk')=='37' and run('shell','getprop','ro.kernel.qemu')=='1'
assert pkgname(app)==signed and pkgname(fixture)==sha(h/'rcs-instrumentation.apk')
sub=run('shell','dumpsys','isub').partition('Active subscriptions:')[2]
assert re.match(r'\s*\[SubscriptionInfoInternal: id=\d+ .*?simSlotIndex=\d+',sub)
del sub
before=holder();assert before=='com.android.messaging' and available()
r={'status':'failed','version':'17','api':37,'apk_sha256':signed,'test_apk_sha256':sha(h/'rcs-instrumentation.apk'),'original_sms_default':before,'updated_from_sha256':'6c64349e698a1f8a0b468257e8916142d5d2c22501eccf073d93c85f0e777b7b','android_subscription_active':True,'device_type':'Official AOSP software emulator','root_checked_iccid':False}
try:
 change('disabled')
 assert not available()
 choose(fixture)
 r['selected_sms_default']=holder()
 print('Running ordinary-permission release core',flush=True)
 out=run('shell','am','instrument','-w',fixture+'/rcssmoke.RcsDirectDraftSmoke',timeout=390)
 (root/'core-instrumentation.txt').write_text(out+'\n')
 fields=dict(re.findall(r'^INSTRUMENTATION_RESULT: (\w+)=(.*)$',out,re.M))
 r['test']=fields
 assert fields.get('status')=='passed' and 'INSTRUMENTATION_CODE: 0' in out, out
 assert fields['adopted_subscriber_permissions']=='false' and fields['full_iccid_hidden']=='true'
 assert fields['ui_clicked']=='false' and fields['actual_external_draft_receipts']=='1'
 r['real_carrier_traffic']=0;r['status']='passed'
 r['scope']='Installed 24.8 release capture/open in a foreground activity with actual Android 17 SMS role, ordinary SIMHub read permissions, masked ICCID, synthetic local reader/card, real explicit Intent to a separate process. Target accepted one draft with only recipient and sms_body. No SIM selection or transport hints; no SMS or carrier RCS delivery. This run did not click the native view.'
finally:
 try:
  change('default')
  assert available()
  choose(before)
  r['restored_default']=holder()
 except Exception:
  r['status']='failed';raise
 finally:
  r['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  (root/'android17-core-validation.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(r,indent=2),flush=True)
