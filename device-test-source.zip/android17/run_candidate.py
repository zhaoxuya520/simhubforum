from pathlib import Path
import argparse, datetime, hashlib, json, re, subprocess, sys, time
root=Path(__file__).resolve().parent
h=root/'rcs-harness'
adb=['/workspace/tools/android-platform-tools/platform-tools/adb','-s','emulator-5582']
def dev(*args, timeout=150):
    r=subprocess.run(adb+list(map(str,args)),capture_output=True,text=True,timeout=timeout)
    if r.returncode: raise RuntimeError((r.stdout+r.stderr)[:1000])
    return r.stdout.strip()
def sdk(name): return dev('shell','getprop',name)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def installed():
    res=dev('shell','cmd','package','path','cc.forserein.simhub')
    m=re.fullmatch(r'package:(/[^\r\n ]+/base.apk)',res)
    return dev('shell','sha256sum',m[1]).split()[0] if m else None
parser=argparse.ArgumentParser()
parser.add_argument('--apk',type=Path,required=True)
parser.add_argument('--apk-sha256',required=True)
opt=parser.parse_args()
assert re.fullmatch('[0-9a-f]{64}',opt.apk_sha256) and sha(opt.apk)==opt.apk_sha256
until=time.monotonic()+1600
while not (root/'ready.json').is_file() and time.monotonic()<until: time.sleep(2)
base=json.loads((root/'ready.json').read_text())
assert sdk('ro.build.version.sdk')=='37' and sdk('ro.kernel.qemu')=='1' and sdk('ro.build.version.release')=='17'
while time.monotonic()<until:
    try:
        if sdk('sys.boot_completed')=='1': break
    except (RuntimeError, subprocess.TimeoutExpired): pass
    time.sleep(3)
else: raise RuntimeError('API37 did not complete telephone startup')
current=installed()
if current==base['prior_apk_sha256']:
    print('24.7 installed hash confirmed',flush=True)
    staged='/data/local/tmp/simhub-24.8-original-signed.apk'
    dev('push',opt.apk,staged,timeout=120)
    for attempt in range(3):
        try:
            result=dev('shell','pm','install','-r',staged,timeout=420)
            if 'Success' in result: break
            print('Package installer:',result,flush=True)
        except (RuntimeError, subprocess.TimeoutExpired) as failure:
            print('Package install retry:',str(failure)[:170],flush=True)
            try:
                if installed()==opt.apk_sha256: break
            except (RuntimeError,subprocess.TimeoutExpired): pass
        time.sleep(4)
    assert installed()==opt.apk_sha256
elif current!=opt.apk_sha256:
    raise RuntimeError('Expected an existing signed 24.7 or current candidate on the emulator')
assert installed()==opt.apk_sha256
print('Signed 24.8 installed hash confirmed',flush=True)
print('Updating SMS test fixture',flush=True)
print(dev('install','--no-streaming','-r',h/'rcs-instrumentation.apk',timeout=420),flush=True)
until=time.monotonic()+600
while time.monotonic()<until:
    try:
        if sdk('gsm.sim.state')=='LOADED': break
    except (RuntimeError, subprocess.TimeoutExpired): pass
    time.sleep(3)
initial=dev('shell','cmd','role','get-role-holders','--user','0','android.app.role.SMS')
assert initial==base['original_default_sms']
subprocess.run([sys.executable,'-u',str(h/'run_handoff.py'),'--serial','emulator-5582','--skip-install','--apk-sha256',opt.apk_sha256],cwd=h,check=True)
r=json.loads((h/'handoff-validation.json').read_text())
assert r['status']=='passed' and r['role_before']==r['role_after']==initial and r['results']['actual_external_draft_receipts']==2
assert {f for f,p in r['phases'].items() if p['full_iccid_hidden']=='true' and p['adopted_subscriber_permissions']=='false'}=={'new','thread'}
old=h/'previous-handoff-validation.json'
baseline=None
if old.exists():
    v=json.loads(old.read_text())
    if v['status']=='passed' and v['apk_sha256']==base['prior_apk_sha256']:
        baseline={'status':v['status'],'results':v['results'],'test_apk_sha256':v['test_apk_sha256']}
image=json.loads((root.parents[1]/'rcs24.7-review/android17/image.json').read_text())
report={'apk_sha256':opt.apk_sha256,'api':37,'version':'17','status':'passed','image':{key:image[key] for key in ('url','official_sha1','local_sha256')},'original_installed_sha256':base['prior_apk_sha256'],'same_signed_in_place_update':True,'24_7_comparison':baseline,'handoff':r,'device':'emulator-5582','scope':'Official AOSP Android 17, synthetic SIMHub OMAPI reader/profile with redaction enforced by the real Android subscription APIs. The actual native thread and new-message forms both handed a reserved draft to the explicitly selected cross-process messaging fixture only after tapping the action. The target app had no privileged phone-state permission, and zero SMS or RCS messages were sent to a carrier. Test observer waits and AVD responsiveness settings were extended for software-only rendering.'}
(root/'android17-validation.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print('Final AOSP Android 17 proof saved',flush=True)
