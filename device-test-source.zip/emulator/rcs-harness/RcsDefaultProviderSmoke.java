package rcssmoke;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.Telephony;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Device-local integration of the installed adapter with a real selected SMS role holder. */
public final class RcsDefaultProviderSmoke extends Instrumentation {
    private static final String FIXTURE = "cc.forserein.simhub.rcssmoke";
    private int checks;
    private Bundle args;
    private Context target;
    private Class<?> api;
    private Object transport;
    private NativeRcsFixture nativeLine;
    private CrossProcessRcsProvider monitor;
    private final List<Object> snapshots = new CopyOnWriteArrayList<>();
    private final List<Object> outcomes = new CopyOnWriteArrayList<>();
    private final List<String> failures = new CopyOnWriteArrayList<>();
    private final List<String> unavailable = new CopyOnWriteArrayList<>();
    private interface Condition { boolean ready() throws Exception; }

    @Override public void onCreate(Bundle extras) {
        super.onCreate(extras);
        args = extras;
        start();
    }
    private void check(boolean ok, String name) {
        checks++;
        if (!ok) throw new AssertionError(name);
    }
    private void await(Condition condition, String name) throws Exception {
        long end = SystemClock.elapsedRealtime() + 10000;
        while (SystemClock.elapsedRealtime() < end) {
            if (condition.ready()) { checks++; return; }
            SystemClock.sleep(30);
        }
        throw new AssertionError(name + " / failures=" + failures);
    }
    private static Object field(Object item, String name) throws Exception {
        return item.getClass().getField(name).get(item);
    }
    private Object last() { return snapshots.isEmpty() ? null : snapshots.get(snapshots.size() - 1); }
    private boolean ready() throws Exception { return last() != null && Boolean.TRUE.equals(field(last(), "canSend")); }
    private String holder() { return Telephony.Sms.getDefaultSmsPackage(target); }
    private List<?> messages() throws Exception {
        return last() == null ? new ArrayList<Object>() : (List<?>)field(last(), "messages");
    }
    private void prepare() throws Exception {
        target = getTargetContext().getApplicationContext();
        check("cc.forserein.simhub".equals(target.getPackageName()), "SIMHub application context");
        PackageManager pm = target.getPackageManager();
        ServiceInfo found = null;
        for (ResolveInfo info : pm.queryIntentServices(new Intent(OfflineRcsProvider.ACTION), 0)) {
            if (info.serviceInfo != null && FIXTURE.equals(info.serviceInfo.packageName)) found = info.serviceInfo;
        }
        check(found != null && "rcssmoke.RcsRemoteService".equals(found.name), "real service discovery from app");
        check(found.enabled && found.exported && OfflineRcsProvider.PERMISSION.equals(found.permission), "provider protects exported service");
        check((found.applicationInfo.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) == 0,
              "provider is a normal installed application");
        check(pm.getPermissionInfo(OfflineRcsProvider.PERMISSION, 0).packageName.equals(FIXTURE), "verified permission owner");
        check(target.checkSelfPermission(OfflineRcsProvider.PERMISSION) == PackageManager.PERMISSION_GRANTED, "real permission grant");
        // The wrapper is solely a test monitor bound to a synthetic fixture control endpoint.
        // No application Context, PackageManager, binder, role getter or session call is intercepted.
        monitor = new CrossProcessRcsProvider(target);
        monitor.openControl();
        nativeLine = new NativeRcsFixture(target);
        api = nativeLine.helper("RcsChatTransport");
        Class<?> listener = nativeLine.helper("RcsChatTransport$Listener");
        Object callback = Proxy.newProxyInstance(listener.getClassLoader(), new Class<?>[]{listener}, (p,m,a) -> {
            if ("onSnapshot".equals(m.getName())) snapshots.add(a[0]);
            if ("onFailure".equals(m.getName())) failures.add(String.valueOf(a[0]));
            if ("onProviderUnavailable".equals(m.getName())) {unavailable.add(String.valueOf(a[0]));failures.add(String.valueOf(a[0]));}
            return null;
        });
        transport = api.getConstructor(Context.class,nativeLine.helper("RcsChatBinding"),listener)
                       .newInstance(target,nativeLine.binding(),callback);
    }
    private void send(String body) throws Exception {
        Class<?> callback = nativeLine.helper("RcsChatTransport$SendCallback");
        Object onResult = Proxy.newProxyInstance(callback.getClassLoader(), new Class<?>[]{callback}, (p,m,a) -> {
            if ("onResult".equals(m.getName())) outcomes.add(a[0]); return null;
        });
        api.getMethod("send",String.class,callback).invoke(transport, body, onResult);
    }
    private void restore(String original) throws Exception {
        String command;
        if (original == null || original.isEmpty()) {
            command = "cmd role remove-role-holder --user 0 android.app.role.SMS " + FIXTURE + " 1";
        } else {
            if (!original.matches("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+") || FIXTURE.equals(original))
                throw new AssertionError("unexpected original role holder");
            command = "cmd role add-role-holder --user 0 android.app.role.SMS " + original + " 1";
        }
        ParcelFileDescriptor descriptor = getUiAutomation().executeShellCommand(command);
        try (InputStream in = new ParcelFileDescriptor.AutoCloseInputStream(descriptor)) {
            byte[] data = new byte[256];
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            int length;
            while ((length = in.read(data)) != -1) out.write(data,0,length);
            if (out.size() > 0 && out.toString("UTF-8").contains("Error"))
                throw new AssertionError("Android refused role restoration");
        }
        await(() -> original == null || original.isEmpty() ? holder() == null : original.equals(holder()), "real holder changed");
    }
    private void runCase(String phase) throws Exception {
        prepare();
        int[] before = monitor.stats();
        check(before[0] != android.os.Process.myPid(), "independent Android provider process");
        boolean selected = "selected".equals(phase);
        check(selected || "off".equals(phase), "recognized phase");
        check(selected == FIXTURE.equals(holder()), "Android confirms requested role");
        api.getMethod("connect").invoke(transport);
        boolean previous = "true".equals(args.getString("previous"));
        if (!selected || previous) {
            await(() -> !failures.isEmpty(), "unselected provider rejected");
            check(!ready() && messages().isEmpty(), "refusal is visible");
            if (previous) check(failures.get(0).equals("设备未提供可供本应用使用的系统 RCS 服务"),"old generic discovery result");
            else check(unavailable.size()==1&&unavailable.get(0).contains("当前默认短信应用"),"distinguish unselected from missing endpoint");
            check(monitor.stats()[1] == before[1], "no submission");
            check(monitor.stats()[2] == before[2], "no GSMA binder calls to unselected provider");
            return;
        }
        await(() -> ready() || !failures.isEmpty(), "selected provider processed");
        check(ready(), "only authentic role selection reaches ready: " + failures);
        check(monitor.stats()[1] == before[1], "connecting does not send");
        send("经当前默认短信服务发送测试");
        await(() -> !outcomes.isEmpty() || !failures.isEmpty(), "provider returned message");
        check(!outcomes.isEmpty() && Boolean.TRUE.equals(field(outcomes.get(0), "accepted")), "acknowledged queued send");
        check(monitor.stats()[1] == before[1] + 1, "one real submission");
        String sent = (String)field(field(outcomes.get(0), "message"), "id");
        monitor.updateStatus(sent,5);
        await(() -> !messages().isEmpty() && Integer.valueOf(5).equals(field(messages().get(0),"statusCode")), "real status callback");
        monitor.receive("role-incoming","实际 Binder 回读",NativeRcsFixture.PEER);
        await(() -> messages().size()==2,"real permission-filtered incoming notification");
        check("实际 Binder 回读".equals(field(messages().get(1),"body")), "real incoming body");
        int[] preSwitch = monitor.stats();
        restore(args.getString("restorePackage"));
        int oldOutcomes = outcomes.size();
        send("更换默认短信应用后必须阻止");
        await(() -> !failures.isEmpty() || outcomes.size() > oldOutcomes, "role loss reported");
        if (outcomes.size() > oldOutcomes)
            check(!Boolean.TRUE.equals(field(outcomes.get(outcomes.size()-1),"accepted")), "role lost does not acknowledge");
        await(() -> !ready() && messages().isEmpty(), "revoked endpoint and stale history cleared");
        int[] after = monitor.stats();
        check(unavailable.isEmpty(),"role revoked after initial connection never invokes handoff callback");
        check(after[0] == preSwitch[0], "old provider process intact during revocation");
        check(after[1] == preSwitch[1], "old provider received zero messages after revocation");
    }
    @Override public void onStart() {
        Bundle result = new Bundle();
        Throwable problem = null;
        String phase = args.getString("phase");
        try {runCase(phase);}
        catch (Throwable error) {problem=error;}
        finally {
            try {
                if (transport!=null) api.getMethod("close").invoke(transport);
                if (monitor!=null) monitor.close();
                if (nativeLine!=null) nativeLine.close();
            } catch(Throwable cleanup) {if (problem==null) problem=cleanup;else problem.addSuppressed(cleanup);}
        }
        result.putString("phase", phase);
        result.putString("status",problem==null?"passed":"failed");
        result.putInt("checks", checks);
        result.putString("scope","Installed SIMHub uses Android's real PackageManager, role, compatibility broadcast and remote typed Binder against a synthetic user-installed provider and line; zero carrier network traffic.");
        if (problem!=null) result.putString("error",android.util.Log.getStackTraceString(problem));
        finish(problem==null?0:1,result);
    }
}
