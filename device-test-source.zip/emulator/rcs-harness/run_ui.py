"""Run only after the shared emulator is released; does not install any APK."""
from pathlib import Path
import argparse
import base64
import hashlib
import json
import re
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apk-sha256', required=True, help='verified SHA-256 of the signed application under test')
expected = parser.parse_args().apk_sha256
ROOT = Path(__file__).resolve().parent
ADB = ['/workspace/tools/android-platform-tools/platform-tools/adb', '-s', 'emulator-5580']


def adb(*args, timeout=180):
    completed = subprocess.run(ADB + list(args), capture_output=True, text=True, timeout=timeout)
    completed.check_returncode()
    return completed.stdout + completed.stderr


package = adb('shell', 'dumpsys', 'package', 'cc.forserein.simhub')
assert 'versionName=24.8' in package, 'UI test requires the final 24.8 installation'
installed = adb('shell', 'pm', 'path', 'cc.forserein.simhub').strip().removeprefix('package:')
digest = adb('shell', 'sha256sum', installed).split()[0]
assert digest == expected, 'unexpected app installed on emulator'
probe_path = adb('shell', 'pm', 'path', 'cc.forserein.simhub.rcssmoke').strip().removeprefix('package:')
local_probe_sha = hashlib.sha256((ROOT / 'rcs-instrumentation.apk').read_bytes()).hexdigest()
assert adb('shell','sha256sum',probe_path).split()[0] == local_probe_sha, 'installed RCS probe differs'
adb('shell', 'am', 'force-stop', 'cc.forserein.simhub')
output = adb('shell', 'am', 'instrument', '-w', 'cc.forserein.simhub.rcssmoke/rcssmoke.RcsUiSmoke')
(ROOT / 'ui-instrumentation.txt').write_text(output)
images = []
for block in output.split('INSTRUMENTATION_STATUS_CODE:'):
    label = re.search(r'^INSTRUMENTATION_STATUS: capture=(.+)$', block, re.M)
    image = re.search(r'^INSTRUMENTATION_STATUS: png_base64=(.+)$', block, re.M)
    if label and image:
        name = label.group(1).strip()
        target = ROOT / (name + '.png')
        target.write_bytes(base64.b64decode(image.group(1)))
        images.append(dict(name=name, path=str(target), sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
result = dict(re.findall(r'^INSTRUMENTATION_RESULT: (\w+)=(.*)$', output, re.M))
result.update(installed_apk_sha256=digest, test_apk_sha256=local_probe_sha, screenshots=images,
              ui_fixture_source_sha256=hashlib.sha256((ROOT/'RcsUiSmoke.java').read_bytes()).hexdigest())
(ROOT / 'ui-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
if result.get('status') != 'passed' or 'INSTRUMENTATION_CODE: 0' not in output:
    error = re.search(r'INSTRUMENTATION_RESULT: error=([\s\S]*?)(?=INSTRUMENTATION_RESULT:|INSTRUMENTATION_CODE:)', output)
    if error:
        print(error.group(1))
    raise SystemExit(1)
