from pathlib import Path
import argparse,hashlib,json,re,subprocess,datetime
p=argparse.ArgumentParser();p.add_argument('--apk-sha256',required=True);p.add_argument('--serial',default='emulator-5580');p.add_argument('--skip-install',action='store_true');a=p.parse_args()
r=Path(__file__).resolve().parent
adb=['/workspace/tools/android-platform-tools/platform-tools/adb','-s',a.serial]
def run(*args):
 t=subprocess.run(adb+list(map(str,args)),capture_output=True,text=True,timeout=120);t.check_returncode();return t.stdout+t.stderr
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
package='cc.forserein.simhub'
apk=run('shell','pm','path',package).strip().removeprefix('package:')
actual=run('shell','sha256sum',apk).split()[0];assert actual==a.apk_sha256,(actual,a.apk_sha256)
if not a.skip_install:
 out=run('install','--no-streaming','-r',r/'rcs-instrumentation.apk');(r/'new-compose-install.txt').write_text(out);assert 'Success' in out
run('shell','am','force-stop',package)
out=run('shell','am','instrument','-w','cc.forserein.simhub.rcssmoke/rcssmoke.RcsComposeNewSmoke');(r/'new-compose-result.txt').write_text(out)
fields=dict(re.findall(r'^INSTRUMENTATION_RESULT: (\w+)=(.*)$',out,re.M))
report={'apk_sha256':actual,'test_apk_sha256':sha(r/'rcs-instrumentation.apk'),'results':fields,'sources':{p.name:sha(p) for p in r.glob('*') if p.suffix in ('.java','.xml','.py')},'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limitations':['The installed form is rendered inside MainActivity under the original theme with a synthetic native card and registration.','Positive connected service metadata is simulated. No carrier or network message is sent.']}
(r/'new-compose-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
assert fields.get('status')=='passed' and 'INSTRUMENTATION_CODE: 0' in out,out
print(json.dumps(report,ensure_ascii=False,indent=2))
