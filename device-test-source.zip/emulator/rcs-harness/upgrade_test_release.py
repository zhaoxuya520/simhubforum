"""Verify the installed 24.7 -> 24.8 transition and run the offline fixtures on the exact release APK."""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess

p=argparse.ArgumentParser()
p.add_argument('--apk', type=Path, required=True)
p.add_argument('--apk-sha256',required=True)
opts=p.parse_args()
assert re.fullmatch(r'[0-9a-f]{64}',opts.apk_sha256)
assert hashlib.sha256(opts.apk.read_bytes()).hexdigest()==opts.apk_sha256
root=Path(__file__).resolve().parent
baseline=json.loads((root/'previous-handoff-validation.json').read_text())
assert baseline['status']=='passed' and baseline['baseline_24_7'] and baseline['results']['actual_external_draft_receipts']==0
old=baseline['apk_sha256']
assert old=='6c64349e698a1f8a0b468257e8916142d5d2c22501eccf073d93c85f0e777b7b'
adb=['/workspace/tools/android-platform-tools/platform-tools/adb','-s','emulator-5580']
def run(cmd,timeout=240):
 proc=subprocess.run(list(map(str,cmd)),check=True,capture_output=True,text=True,timeout=timeout);return (proc.stdout+proc.stderr).strip()
def installed():
 path=run(adb+['shell','pm','path','cc.forserein.simhub']).removeprefix('package:')
 assert path.startswith('/data/app/') and path.endswith('/base.apk')
 return run(adb+['shell','sha256sum',path]).split()[0]
assert run(adb+['shell','getprop','ro.kernel.qemu'])=='1'
assert installed()==old
assert 'Success' in run(adb+['install','--no-streaming','-r',opts.apk],timeout=320)
assert installed()==opts.apk_sha256
assert 'versionName=24.8' in run(adb+['shell','dumpsys','package','cc.forserein.simhub'])
(root/'release-upgrade-observed.json').write_text(json.dumps({
    'status':'passed','apk_sha256':opts.apk_sha256,'old_apk_sha256':old,
    'serial':'emulator-5580','api':run(adb+['shell','getprop','ro.build.version.sdk']),
    'same_signature_in_place_upgrade':True,'cleared_app_data':False,'utc':datetime.now(timezone.utc).isoformat()
},indent=2)+'\n')
print('Observed installed 24.7 -> 24.8 hash',opts.apk_sha256,flush=True)
subprocess.run(['python3','-u',str(root/'run_release.py'),'--apk-sha256',opts.apk_sha256],cwd=root,check=True)
