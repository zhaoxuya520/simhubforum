package rcssmoke;
import android.content.*;import android.os.*;import java.util.*;import java.util.concurrent.*;
/** Trust metadata is synthetic; Binder, compatibility broadcast and incoming broadcast cross a real process boundary. */
public final class CrossProcessRcsProvider extends OfflineRcsProvider {
 static final String PACKAGE="cc.forserein.simhub.rcssmoke";
 final Map<ServiceConnection,ServiceConnection> links=new HashMap<>();
 final Set<BroadcastReceiver> receivers=new HashSet<>();
 IBinder control;ServiceConnection controlConnection;
 public CrossProcessRcsProvider(Context context)throws Exception{super(context,PACKAGE,context.getPackageManager().getApplicationInfo(PACKAGE,0).uid);}
 private Intent service(String action){return new Intent(action).setComponent(new ComponentName(PACKAGE,"rcssmoke.RcsRemoteService"));}
 @Override public void sendOrderedBroadcast(Intent intent,String permission,BroadcastReceiver result,Handler scheduler,int code,String data,Bundle extras){
  compatibilityRequests++;getBaseContext().sendOrderedBroadcast(intent,null,result,scheduler,code,data,extras);
 }
 @Override public boolean bindService(Intent intent,ServiceConnection callback,int flags){
  final ComponentName expected=intent.getComponent();ServiceConnection bridge=new ServiceConnection(){
   public void onServiceConnected(ComponentName n,IBinder b){callback.onServiceConnected(expected,b);}
   public void onServiceDisconnected(ComponentName n){callback.onServiceDisconnected(expected);}
   public void onBindingDied(ComponentName n){callback.onBindingDied(expected);}
   public void onNullBinding(ComponentName n){callback.onNullBinding(expected);}
  };links.put(callback,bridge);boolean bound=getBaseContext().bindService(service(ACTION),bridge,flags);if(bound)binds++;return bound;
 }
 @Override public void unbindService(ServiceConnection callback){ServiceConnection bridge=links.remove(callback);if(bridge!=null){getBaseContext().unbindService(bridge);unbinds++;}}
 @Override public Intent registerReceiver(BroadcastReceiver r,IntentFilter filter,String permission,Handler scheduler,int flags){receivers.add(r);incoming=r;return getBaseContext().registerReceiver(r,filter,permission,scheduler,flags);}
 @Override public Intent registerReceiver(BroadcastReceiver r,IntentFilter filter,String permission,Handler scheduler){receivers.add(r);incoming=r;return getBaseContext().registerReceiver(r,filter,permission,scheduler);}
 @Override public void unregisterReceiver(BroadcastReceiver r){if(receivers.remove(r)){getBaseContext().unregisterReceiver(r);incoming=null;}else super.unregisterReceiver(r);}
 public void openControl()throws Exception{
  CountDownLatch done=new CountDownLatch(1);controlConnection=new ServiceConnection(){public void onServiceConnected(ComponentName n,IBinder b){control=b;done.countDown();}public void onServiceDisconnected(ComponentName n){control=null;}};
  if(!getBaseContext().bindService(service("rcssmoke.CONTROL"),controlConnection,Context.BIND_AUTO_CREATE)||!done.await(7,TimeUnit.SECONDS))throw new AssertionError("remote control did not bind");
 }
 public int[] stats()throws Exception{Parcel d=Parcel.obtain(),r=Parcel.obtain();try{d.writeInterfaceToken("rcssmoke.Control");if(!control.transact(1,d,r,0))throw new AssertionError("stats");r.readException();return new int[]{r.readInt(),r.readInt(),r.readInt()};}finally{d.recycle();r.recycle();}}
 public void updateStatus(String id,int status)throws Exception{command(2,id,null,null,status);}
 public void receive(String id,String body,String peer)throws Exception{command(3,id,body,peer,0);}
 public void unregisterRemote()throws Exception{command(4,null,null,null,0);}
 private void command(int code,String id,String body,String peer,int status)throws Exception{Parcel d=Parcel.obtain(),r=Parcel.obtain();try{d.writeInterfaceToken("rcssmoke.Control");if(code==2){d.writeString(id);d.writeInt(status);}if(code==3){d.writeString(id);d.writeString(body);d.writeString(peer);}if(!control.transact(code,d,r,0))throw new AssertionError("remote command");r.readException();}finally{d.recycle();r.recycle();}}
 @Override public void close(){if(controlConnection!=null)getBaseContext().unbindService(controlConnection);super.close();}
}
