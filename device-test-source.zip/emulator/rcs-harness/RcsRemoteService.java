package rcssmoke;
import android.app.Service;
import android.content.Intent;
import android.os.*;
/** Test APK only: no network, no telephony permission or transport. */
public final class RcsRemoteService extends Service {
 OfflineRcsProvider provider;
 public void onCreate(){super.onCreate();provider=new OfflineRcsProvider(this);}
 public IBinder onBind(Intent intent){return "rcssmoke.CONTROL".equals(intent.getAction())?control:provider.serviceBinder();}
 public void onDestroy(){provider.close();super.onDestroy();}
 private final Binder control=new Binder(){
  protected boolean onTransact(int code,Parcel data,Parcel reply,int flags)throws RemoteException{
   data.enforceInterface("rcssmoke.Control");
   try{
    if(code==1){reply.writeNoException();reply.writeInt(android.os.Process.myPid());reply.writeInt(provider.sends);reply.writeInt(provider.transactions);return true;}
    if(code==2){provider.status(data.readString(),data.readInt());reply.writeNoException();return true;}
    if(code==3){String id=data.readString(),body=data.readString(),peer=data.readString();provider.incoming(id,body,peer,System.currentTimeMillis());
     sendBroadcast(new Intent("com.gsma.services.rcs.chat.action.NEW_ONE_TO_ONE_CHAT_MESSAGE").setPackage("cc.forserein.simhub").putExtra("messageId",id).putExtra("body","untrusted remote broadcast extra"));reply.writeNoException();return true;}
    if(code==4){provider.unregister();reply.writeNoException();return true;}
    return super.onTransact(code,data,reply,flags);
   }catch(Exception error){throw new RemoteException(error.toString());}
  }
 };
}
