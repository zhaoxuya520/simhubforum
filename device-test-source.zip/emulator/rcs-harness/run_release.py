from pathlib import Path
from datetime import datetime,timezone
import argparse, hashlib, json, subprocess
p=argparse.ArgumentParser();p.add_argument('--apk-sha256',required=True);a=p.parse_args()
root=Path(__file__).resolve().parent
items=[('default_provider','default-provider-validation.json'),('handoff','handoff-validation.json'),('new_compose','new-compose-validation.json'),('ui','ui-result.json'),('transport','transport-validation.json')]
h=hashlib.sha256((root/'rcs-instrumentation.apk').read_bytes()).hexdigest()
results={}
for i,(runner,report) in enumerate(items):
 cmd=['python3','-u',str(root/('run_'+runner+'.py')),'--apk-sha256',a.apk_sha256]
 if i and runner!='ui':cmd.append('--skip-install')
 with (root/('final-'+runner+'.log')).open('w') as out:
  result=subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT)
 if result.returncode:raise RuntimeError(runner+' failed. Review '+str(root/('final-'+runner+'.log')))
 data=json.loads((root/report).read_text())
 assert data.get('apk_sha256',data.get('installed_apk_sha256'))==a.apk_sha256 and data.get('test_apk_sha256')==h
 r=data.get('results',data)
 assert r.get('status',data.get('status'))=='passed'
 checks=int(r.get('checks',sum(int(x['checks']) for x in data.get('phases',{}).values())))
 results[runner]={'status':'passed','checks':checks,'sha256':hashlib.sha256((root/report).read_bytes()).hexdigest(),'report':report}
 print(runner,checks,'passed',flush=True)
(root/'rcs-device-validation.json').write_text(json.dumps({'apk_sha256':a.apk_sha256,'test_apk_sha256':h,'status':'passed','checks':sum(d['checks'] for d in results.values()),'tests':results,'utc':datetime.now(timezone.utc).isoformat(),'real_network_messages':0,'physical_device_validated':False},indent=2)+'\n')
