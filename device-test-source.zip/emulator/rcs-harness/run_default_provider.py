"""Exercise discovery under an actual SMS role on the disposable Android emulator."""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import argparse
import json
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
ADB = Path('/workspace/tools/android-platform-tools/platform-tools/adb')
APP = 'cc.forserein.simhub'
PROVIDER = 'cc.forserein.simhub.rcssmoke'
ROLE = 'android.app.role.SMS'
ACTION = 'com.gsma.services.rcs.chat.IChatService'
TAPI = PROVIDER + '/rcssmoke.RcsRemoteService'
PROBE = PROVIDER + '/rcssmoke.RcsDefaultProviderSmoke'
REPORT = ROOT / 'default-provider-validation.json'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apk-sha256', required=True)
    parser.add_argument('--serial', default='emulator-5580')
    parser.add_argument('--skip-install', action='store_true')
    parser.add_argument('--previous-24-6',action='store_true')
    args = parser.parse_args()

    def adb(*command, timeout=60):
        completed = subprocess.run([str(ADB), '-s', args.serial, *map(str, command)],
                                   text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   timeout=timeout, check=True)
        return completed.stdout.strip()

    def installed_sha(package):
        output = adb('shell', 'pm', 'path', package)
        match = re.search(r'^package:(/[^\r\n ]+/base\.apk)$', output, re.M)
        if match is None:
            raise RuntimeError('Expected a base APK for ' + package)
        return adb('shell', 'sha256sum', match.group(1)).split()[0]

    def holder():
        state = adb('shell', 'dumpsys', 'role')
        sections = re.split(r'^\s*user_id=', state, flags=re.M)[1:]
        user_state = next((s for s in sections if re.match(r'0\s*\n', s)), '')
        group = re.search(r'(?m)^\s*name=android\.app\.role\.SMS\s*\n([^}]+)', user_state)
        if group is None:
            raise RuntimeError('Could not inspect the user-0 SMS role')
        raw = re.findall(r'(?m)^\s*holders=([^\n]+)$', group.group(1))
        if len(raw) != 1:
            raise RuntimeError('Expected an existing exclusive SMS role holder')
        name = raw[0].strip().strip('[]')
        if not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)+', name):
            raise RuntimeError('Ambiguous SMS role holder')
        return name

    def set_holder(package):
        adb('shell', 'cmd', 'role', 'add-role-holder', '--user', '0', ROLE, package, '1')
        end = time.monotonic() + 12
        while time.monotonic() < end:
            if holder() == package:
                return
            time.sleep(.2)
        raise RuntimeError('Role grant did not take effect: ' + package)

    def phase(name, baseline):
        out = adb('shell', 'am', 'instrument', '-w', '-e', 'previous', str(args.previous_24_6).lower(), '-e', 'phase', name,
                  '-e', 'restorePackage', baseline, PROBE, timeout=140)
        (ROOT / ('default-provider-' + name + '.txt')).write_text(out + '\n')
        data = dict(re.findall(r'^INSTRUMENTATION_RESULT: (\w+)=(.*)$', out, re.M))
        if data.get('status') != 'passed' or 'INSTRUMENTATION_CODE: 0' not in out:
            raise RuntimeError(out)
        return data

    if (not re.fullmatch(r'emulator-[0-9]+', args.serial)
            or adb('shell', 'getprop', 'ro.kernel.qemu') != '1'
            or adb('shell', 'am', 'get-current-user') != '0'):
        raise RuntimeError('Only user 0 on a disposable Android emulator is supported')
    app_hash = installed_sha(APP)
    if args.previous_24_6 and app_hash!='8fbf8495fe19be5e90f82d14e256a41581dbf56672b0dfd777880405ac94398d':
        raise RuntimeError('Unexpected previous version')
    if app_hash != args.apk_sha256:
        raise RuntimeError('Installed application differs from requested release')
    probe_apk = ROOT / 'rcs-instrumentation.apk'
    expected_probe = sha256(probe_apk.read_bytes()).hexdigest()
    if not args.skip_install:
        print(adb('install', '--no-streaming', '-r', probe_apk), flush=True)
    if installed_sha(PROVIDER) != expected_probe:
        raise RuntimeError('Installed instrumentation/role provider differs from local APK')
    original = holder()
    if original == PROVIDER:
        raise RuntimeError('Fixture already holds the role; expected the original messaging app')
    matched = adb('shell', 'cmd', 'package', 'query-services', '--components',
                  '--user', '0', '-a', ACTION).splitlines()
    if TAPI not in [row.strip() for row in matched]:
        raise RuntimeError('Fixture chat service missing from PackageManager: ' + repr(matched))
    evidence = {'apk_sha256': app_hash, 'test_apk_sha256': expected_probe, 'api': adb('shell', 'getprop', 'ro.build.version.sdk'),
                'serial': args.serial, 'role_before': original, 'query_result': matched, 'phases': {}, 'status': 'failed',
                'scope': 'Real Android package resolution and role manager. Synthetic card, registration and isolated-process RCS provider. No carrier messages.'}
    try:
        evidence['phases']['off'] = phase('off', original)
        if holder() != original:
            raise RuntimeError('Non-role test changed the selected app')
        set_holder(PROVIDER)
        evidence['role_selected'] = holder()
        evidence['phases']['selected'] = phase('selected', original)
        if not args.previous_24_6 and holder() != original:
            raise RuntimeError('Selected-phase test did not exercise role removal in-session')
        evidence['status'] = 'passed'
    finally:
        try:
            if holder() != original:
                set_holder(original)
            evidence['role_after'] = holder()
        finally:
            if evidence.get('role_after') != original:
                evidence['status'] = 'failed'
            evidence['utc'] = datetime.now(timezone.utc).isoformat()
            (ROOT/('previous-default-provider-validation.json' if args.previous_24_6 else REPORT.name)).write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(evidence, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
