"""SIMHub account storage and Cloud Mail reminders."""
import argparse
import asyncio
from contextlib import contextmanager
import getpass
import hashlib
import hmac
from html import escape
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import time

from aiohttp import ClientSession, ClientTimeout, web

DAY = 86400
EMAIL = re.compile(r"[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+")
SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS account (
  id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, salt BLOB NOT NULL,
  password BLOB NOT NULL, recipient TEXT, revision INTEGER NOT NULL DEFAULT 0,
  snapshot TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS session (
  token BLOB PRIMARY KEY, account INTEGER NOT NULL REFERENCES account(id),
  expires INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reminder (
  account INTEGER NOT NULL REFERENCES account(id), card TEXT NOT NULL,
  expires INTEGER NOT NULL, title TEXT NOT NULL,
  sent INTEGER NOT NULL DEFAULT 0, retry_after INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (account, card, expires)
);
"""
DB = web.AppKey("database", str)
FAILURES = web.AppKey("login_failures", dict)


@contextmanager
def database(path):
    con = sqlite3.connect(path, timeout=5)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        with con:
            yield con
    finally:
        con.close()


def password_hash(password, salt):
    return hashlib.scrypt(password.encode(), salt=salt, n=16384, r=8, p=1)


def token_hash(token):
    return hashlib.sha256(token.encode()).digest()


def provision(path, name, password):
    if not re.fullmatch(r"[a-zA-Z0-9_.-]{3,64}", name) or not 12 <= len(password) <= 256:
        raise ValueError("Use a 3–64 character username and 12–256 character password.")
    salt = secrets.token_bytes(16)
    with database(path) as con:
        con.execute("INSERT INTO account(name,salt,password) VALUES(?,?,?)",
                    (name.lower(), salt, password_hash(password, salt)))


async def object_body(request):
    try:
        value = await request.json()
    except (ValueError, UnicodeError):
        raise web.HTTPBadRequest() from None
    if not isinstance(value, dict):
        raise web.HTTPBadRequest()
    return value


def require_session(con, request):
    header = request.headers.get("Authorization", "")
    if not re.fullmatch(r"Bearer [A-Za-z0-9_-]{43}", header):
        raise web.HTTPUnauthorized()
    digest = token_hash(header[7:])
    result = con.execute("SELECT account FROM session WHERE token=? AND expires>?",
                         (digest, int(time.time()))).fetchone()
    if result is None:
        raise web.HTTPUnauthorized()
    return result["account"], digest


async def login(request):
    payload = await object_body(request)
    name, password = payload.get("username"), payload.get("password")
    if not isinstance(name, str) or not isinstance(password, str) or len(name) > 64 or len(password) > 256:
        raise web.HTTPUnauthorized()
    now = int(time.time())
    failures = request.app[FAILURES]
    for key, (_, deadline) in list(failures.items()):
        if deadline <= now:
            del failures[key]
    peer = request.remote
    if peer in ("127.0.0.1", "::1"):
        # Our 8443 gateway overwrites the header with the actual connection peer.
        peer = request.headers.get("X-SIMHub-Peer", peer)
    key = (peer, name.lower()[:64])
    ip_key = (peer, "")
    total, ip_deadline = failures.get(ip_key, (0, now + 60))
    if total >= 60:
        raise web.HTTPTooManyRequests(headers={"Retry-After": str(ip_deadline - now)})
    failures[ip_key] = (total + 1, ip_deadline)
    count, deadline = failures.get(key, (0, now + 60))
    if count >= 10:
        raise web.HTTPTooManyRequests(headers={"Retry-After": str(deadline - now)})
    failures[key] = (count + 1, deadline)
    with database(request.app[DB]) as con:
        row = con.execute("SELECT id,salt,password FROM account WHERE name=?", (name.lower(),)).fetchone()
    calculated = await asyncio.to_thread(password_hash, password, row["salt"] if row else bytes(16))
    if row is None or not hmac.compare_digest(row["password"], calculated):
        raise web.HTTPUnauthorized()
    failures.pop(key, None)
    token = secrets.token_urlsafe(32)
    with database(request.app[DB]) as con:
        con.execute("DELETE FROM session WHERE expires<=?", (now,))
        con.execute("INSERT INTO session VALUES(?,?,?)", (token_hash(token), row["id"], now + 30 * DAY))
    return web.json_response({"token": token, "username": name.lower()}, headers={"Cache-Control": "no-store"})


async def logout(request):
    with database(request.app[DB]) as con:
        _, token = require_session(con, request)
        con.execute("DELETE FROM session WHERE token=?", (token,))
    return web.Response(status=204)


async def settings(request):
    recipient = None
    if request.method == "PUT":
        recipient = (await object_body(request)).get("recipient")
        if recipient is not None and (not isinstance(recipient, str) or len(recipient) > 254 or not EMAIL.fullmatch(recipient)):
            raise web.HTTPBadRequest()
    with database(request.app[DB]) as con:
        account, _ = require_session(con, request)
        if request.method == "PUT":
            con.execute("UPDATE account SET recipient=? WHERE id=?", (recipient, account))
        row = con.execute("SELECT recipient FROM account WHERE id=?", (account,)).fetchone()
    return web.json_response(dict(row), headers={"Cache-Control": "no-store"})


def reminder_rows(cards):
    if not isinstance(cards, list) or len(cards) > 10000:
        raise web.HTTPBadRequest()
    result = {}
    for card in cards:
        if not isinstance(card, dict):
            raise web.HTTPBadRequest()
        identifier, title, expiry = card.get("id"), card.get("title"), card.get("expires")
        if (not isinstance(identifier, str) or not 1 <= len(identifier) <= 128
                or not isinstance(title, str) or len(title) > 160 or type(expiry) is not int
                or not 0 < expiry < 4102444800 or identifier in result):
            raise web.HTTPBadRequest()
        result[identifier] = (expiry, title)
    return result


async def snapshot(request):
    path = request.app[DB]
    with database(path) as con:
        account, _ = require_session(con, request)
    if request.method == "PUT":
        payload = await object_body(request)
        revision, data = payload.get("revision"), payload.get("data")
        if type(revision) is not int or revision < 0 or not isinstance(data, dict):
            raise web.HTTPBadRequest()
        cards = reminder_rows(payload.get("cards"))
        try:
            encoded = json.dumps(data, ensure_ascii=True, allow_nan=False)
        except (ValueError, RecursionError):
            raise web.HTTPBadRequest() from None
        with database(path) as con:
            con.execute("BEGIN IMMEDIATE")
            current, _ = require_session(con, request)
            if current != account:
                raise web.HTTPUnauthorized()
            changed = con.execute("UPDATE account SET revision=revision+1,snapshot=? WHERE id=? AND revision=?",
                                  (encoded, account, revision)).rowcount
            if not changed:
                raise web.HTTPConflict()
            for existing in con.execute("SELECT card,expires FROM reminder WHERE account=?", (account,)).fetchall():
                if existing["card"] not in cards or cards[existing["card"]][0] != existing["expires"]:
                    con.execute("DELETE FROM reminder WHERE account=? AND card=? AND expires=?",
                                (account, existing["card"], existing["expires"]))
            con.executemany("""INSERT INTO reminder(account,card,expires,title) VALUES(?,?,?,?)
                            ON CONFLICT(account,card,expires) DO UPDATE SET title=excluded.title""",
                            [(account, identifier, expiry, title) for identifier, (expiry, title) in cards.items()])
        response = {"revision": revision + 1}
    else:
        with database(path) as con:
            row = con.execute("SELECT revision,snapshot FROM account WHERE id=?", (account,)).fetchone()
        response = {"revision": row["revision"], "data": json.loads(row["snapshot"])}
    return web.json_response(response, headers={"Cache-Control": "no-store"})


class CloudMail:
    BASE = "https://mail.linuxai.de/api"
    USER_AGENT = "Mozilla/5.0 AppleWebKit/537.36 Chrome/130.0 Safari/537.36"

    def __init__(self, http, email, password, account_id=1057):
        self.http = http
        self.email = email
        self.password = password
        self.account_id = account_id
        self.token = None

    async def request(self, path, data, token=None):
        headers = {"User-Agent": self.USER_AGENT}
        if token:
            headers["Authorization"] = token
        async with self.http.post(self.BASE + path, json=data, headers=headers, allow_redirects=False) as response:
            response.raise_for_status()
            payload = await response.json()
        if payload.get("code") != 200:
            raise ValueError("Cloud Mail rejected the request")
        return payload["data"]

    def reset(self):
        self.token = None

    async def send(self, recipient, title, expires):
        if not self.token:
            self.token = (await self.request("/login", {"email": self.email, "password": self.password}))["token"]
        date = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(expires))
        data = await self.request("/email/send", {
            "accountId": self.account_id, "receiveEmail": [recipient], "type": 1,
            "subject": "SIMHub eSIM 到期提醒",
            "content": f"{escape(title or 'eSIM')} 将于 {date} 到期。请在 SIMHub 查看记录。",
        }, self.token)
        if not isinstance(data, list) or not data or not data[0].get("emailId"):
            raise ValueError("Cloud Mail returned no email ID")


async def send_due(path, mail, now=None):
    now = int(time.time()) if now is None else now
    with database(path) as con:
        candidates = con.execute("""SELECT reminder.account,card,expires FROM reminder
                                   JOIN account ON account.id=reminder.account
                                   WHERE recipient IS NOT NULL AND expires>? AND expires<=?
                                   AND sent=0 AND retry_after<=? ORDER BY expires LIMIT 50""", (now, now + 7 * DAY, now)).fetchall()
    for candidate in candidates:
        key = tuple(candidate)
        with database(path) as con:
            con.execute("BEGIN IMMEDIATE")
            task = con.execute("""SELECT reminder.title,account.recipient FROM reminder JOIN account ON account.id=reminder.account
                                WHERE account.id=? AND card=? AND expires=? AND sent=0 AND retry_after<=?
                                AND recipient IS NOT NULL""", (*key, now)).fetchone()
            if not task:
                continue
            con.execute("UPDATE reminder SET retry_after=? WHERE account=? AND card=? AND expires=?",
                        (now + 900, *key))
        try:
            await mail.send(task["recipient"], task["title"], candidate["expires"])
        except Exception:
            mail.reset()
            # Leave the retry lease in place. Credentials and recipient stay out of logs.
            print("A Cloud Mail reminder will be retried.", flush=True)
            continue
        with database(path) as con:
            con.execute("UPDATE reminder SET sent=? WHERE account=? AND card=? AND expires=?", (now, *key))


def create_app(path):
    app = web.Application(client_max_size=16 * 1024 * 1024)
    app[DB] = path
    app[FAILURES] = {}
    app.router.add_post("/accounts/v1/login", login)
    app.router.add_post("/accounts/v1/logout", logout)
    app.router.add_get("/accounts/v1/settings", settings)
    app.router.add_put("/accounts/v1/settings", settings)
    app.router.add_get("/accounts/v1/snapshot", snapshot)
    app.router.add_put("/accounts/v1/snapshot", snapshot)
    return app


async def mail_once(path):
    config = Path(os.environ["CREDENTIALS_DIRECTORY"]) / "cloud-mail.json"
    credentials = json.loads(config.read_text())
    async with ClientSession(timeout=ClientTimeout(total=25)) as http:
        mail = CloudMail(http, credentials["email"], credentials["password"], credentials.get("accountId", 1057))
        await send_due(path, mail)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True)
    parser.add_argument("--port", type=int, default=8872)
    parser.add_argument("action", choices=["serve", "add-user", "send-due"])
    parser.add_argument("username", nargs="?")
    args = parser.parse_args()
    os.umask(0o077)
    with database(args.db) as con:
        con.executescript(SCHEMA)
    if args.action == "serve":
        web.run_app(create_app(args.db), host="127.0.0.1", port=args.port, access_log=None)
    elif args.action == "send-due":
        asyncio.run(mail_once(args.db))
    else:
        password = getpass.getpass("Password: ")
        if password != getpass.getpass("Repeat password: "):
            parser.error("Passwords differ")
        provision(args.db, args.username or "", password)


if __name__ == "__main__":
    main()
