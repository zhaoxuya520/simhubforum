package akasmoke;

import android.app.Instrumentation;
import android.content.Context;
import android.os.Bundle;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.*;
import java.nio.ByteBuffer;
import java.util.*;

/** Actual APK da1.b calls with ordinary synthetic AKA Identity requests; no sockets or APDU. */
public final class AkaSmoke extends Instrumentation {
 private ClassLoader loader;private int checks,transportCalls,nativeCalls;private final ArrayList<String> completed=new ArrayList<>();
 private Class<?> type(String name)throws Exception{return Class.forName(name,true,loader);}
 private Object get(Object target,String name)throws Exception{Field field=target.getClass().getDeclaredField(name);field.setAccessible(true);return field.get(target);}
 private void check(boolean condition,String message){if(!condition)throw new AssertionError(message);checks++;}
 private byte[] request(int id,int attribute){return new byte[]{1,(byte)id,0,12,23,5,0,0,(byte)attribute,1,0,0};}
 private byte[] expected(int id,String identity)throws Exception{
  byte[] bytes=identity.getBytes("US-ASCII");int attributeSize=(bytes.length+7)/4*4;
  ByteBuffer out=ByteBuffer.allocate(8+attributeSize);out.put((byte)2).put((byte)id).putShort((short)out.capacity()).put((byte)23).put((byte)5).putShort((short)0);
  out.put((byte)14).put((byte)(attributeSize/4)).putShort((short)bytes.length).put(bytes);return out.array();
 }
 private Object engine(String identity)throws Exception{
  Object transport=Proxy.newProxyInstance(loader,new Class<?>[]{type("qg0")},(proxy,method,args)->{
   if(method.getDeclaringClass()==Object.class){if(method.getName().equals("equals"))return proxy==args[0];if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);return "Synthetic AKA Identity transport";}
   transportCalls++;throw new AssertionError("AKA Identity unexpectedly called transport method "+method.getName());
  });
  Object auth=type("ac5").getConstructor(type("qg0"),Context.class).newInstance(transport,getTargetContext());
  Object adapter=type("s01").getConstructor(type("ac5")).newInstance(auth);
  return type("da1").getConstructor(String.class,type("s01")).newInstance(identity,adapter);
 }
 private byte[] send(Object engine,byte[] request)throws Exception{
  nativeCalls++;
  Object reply=type("da1").getMethod("b",byte[].class,type("dt0")).invoke(engine,request,null);
  check(reply!=null&&reply.getClass()==type("z91"),"actual native AKA identity worker returns z91 synchronously");return (byte[])get(reply,"a");
 }
 private ByteArrayOutputStream transcript(Object engine)throws Exception{return (ByteArrayOutputStream)get(engine,"e");}
 private void pair(ByteArrayOutputStream stream,byte[] request,byte[] response)throws Exception{stream.write(request);stream.write(response);}
 private void bytes(byte[] expected,byte[] actual,String message){check(Arrays.equals(expected,actual),message);}
 private void cases()throws Exception{
  for(String name:new String[]{"da1","z91","s01","ac5","cc.forserein.simhub.internal.EapIdentityReplay"}){type(name).getDeclaredMethods();checks++;}
  String identity="0204049876543210@nai.epc.mnc004.mcc204.3gppnetwork.org";
  String otherIdentity="051566000000039@nai.epc.mnc066.mcc515.3gppnetwork.org";
  Object first=engine(identity);byte[] a=request(7,10),canonicalA=a.clone(),replyA=expected(7,identity);
  ByteArrayOutputStream accounting=new ByteArrayOutputStream();pair(accounting,canonicalA,replyA);
  byte[] initial=send(first,a);bytes(replyA,initial,"first real AT_PERMANENT_ID_REQ response has correct original bytes");bytes(accounting.toByteArray(),transcript(first).toByteArray(),"first identity exchange appends exactly request and reply");
  for(int repeat=0;repeat<3;repeat++){
   bytes(replyA,send(first,canonicalA.clone()),"consecutive identical normal request replays original response");
   bytes(accounting.toByteArray(),transcript(first).toByteArray(),"consecutive retransmission does not append transcript");
  }
  completed.add("ordinary-identical-identity-retransmission");
  initial[12]^=1;bytes(replyA,send(first,canonicalA.clone()),"caller mutation of returned response cannot corrupt cached reply");bytes(accounting.toByteArray(),transcript(first).toByteArray(),"caller response mutation leaves transcript and replay accounting intact");
  a[1]=99;bytes(replyA,send(first,canonicalA.clone()),"caller mutation of previously supplied request cannot corrupt cached key");bytes(accounting.toByteArray(),transcript(first).toByteArray(),"caller request mutation does not re-account original exchange");
  byte[] padded=Arrays.copyOf(canonicalA,16);padded[12]=0x11;padded[13]=0x22;padded[14]=0x33;padded[15]=0x44;
  bytes(replyA,send(first,padded),"transport bytes after declared EAP length do not change retransmitted identity request");bytes(accounting.toByteArray(),transcript(first).toByteArray(),"outer padding difference does not append transcript");
  completed.add("normal-buffer-and-envelope-copy-boundaries");
  byte[] b=request(8,10),replyB=expected(8,identity);bytes(replyB,send(first,b),"next valid identity identifier returns its own native response");pair(accounting,b,replyB);bytes(accounting.toByteArray(),transcript(first).toByteArray(),"new identity identifier appends a fresh exchange");
  bytes(replyB,send(first,b.clone()),"new request becomes latest replay candidate");bytes(accounting.toByteArray(),transcript(first).toByteArray(),"latest replay remains accounted once");
  byte[] any=request(8,13);bytes(replyB,send(first,any),"valid AT_ANY_ID_REQ with same identifier uses original native path");pair(accounting,any,replyB);bytes(accounting.toByteArray(),transcript(first).toByteArray(),"different normal identity attribute is accounted as a new request");
  bytes(replyA,send(first,canonicalA.clone()),"older request after a newer request is handled natively again");pair(accounting,canonicalA,replyA);bytes(accounting.toByteArray(),transcript(first).toByteArray(),"only the most recent identity request is eligible for replay suppression");
  completed.add("new-request-accounting-and-latest-request-scope");
  Object second=engine(otherIdentity);byte[] otherReply=expected(7,otherIdentity);ByteArrayOutputStream otherAccounting=new ByteArrayOutputStream();pair(otherAccounting,canonicalA,otherReply);
  bytes(otherReply,send(second,canonicalA.clone()),"fresh native session answers with its own synthetic permanent identity");bytes(otherAccounting.toByteArray(),transcript(second).toByteArray(),"fresh session does not inherit first session transcript");
  bytes(replyA,send(first,canonicalA.clone()),"first session retains its own cached response while another session is active");bytes(accounting.toByteArray(),transcript(first).toByteArray(),"other session does not disturb first-session replay accounting");
  bytes(otherReply,send(second,canonicalA.clone()),"second session repeats its own response independently");bytes(otherAccounting.toByteArray(),transcript(second).toByteArray(),"second-session duplicate is also counted once");
  completed.add("native-session-isolation");
  transcript(first).reset();accounting.reset();pair(accounting,canonicalA,replyA);
  bytes(replyA,send(first,canonicalA.clone()),"normal transcript reset makes old identity request fresh again");bytes(accounting.toByteArray(),transcript(first).toByteArray(),"after simulated native cleanup reset exchange is appended again");
  bytes(replyA,send(first,canonicalA.clone()),"post-reset duplicate returns newly recorded reply");bytes(accounting.toByteArray(),transcript(first).toByteArray(),"post-reset duplicate is accounted once");
  completed.add("transcript-reset-session-lifecycle");
  check(transportCalls==0,"all real native calls remained ordinary Identity requests without APDU/authentication");
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);start();}
 @Override public void onStart(){Bundle result=new Bundle();Throwable error=null;
  try{runOnMainSync(()->{});loader=getTargetContext().getClassLoader();cases();}catch(Throwable problem){error=problem;}
  result.putInt("checks",checks);result.putInt("apdu_calls",transportCalls);result.putInt("native_identity_calls",nativeCalls);result.putStringArrayList("completed_cases",completed);
  result.putString("scope","Actual APK da1.b normal synthetic AKA Identity calls on ART; original replies and exact transcript bytes verified. Fresh native session objects; no preferences/global app state changed. Transcript reset explicitly simulates native cleanup. No socket, APDU, challenge, live SIM or carrier request.");
  if(error==null){result.putString("status","passed");finish(0,result);}else{result.putString("status","failed");result.putString("error",android.util.Log.getStackTraceString(error));finish(1,result);}
 }
}
