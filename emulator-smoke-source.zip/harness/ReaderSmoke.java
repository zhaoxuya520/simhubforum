package readersmoke;

import android.app.Instrumentation;
import android.content.*;
import android.os.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.CancellationException;

/** Actual zl5.z / xq0.X / hm0 scheduling, without ever executing the captured connection task. */
public final class ReaderSmoke extends Instrumentation {
 private ClassLoader loader;private int checks,apduCalls;
 private final ArrayList<String> cases=new ArrayList<>();
 private final LinkedHashMap<Field,Object> saved=new LinkedHashMap<>();
 private IsolatedContext isolated;private Object originalContext,originalLibraryContext,flow,originalState,scope,originalScopeContext;
 private Field scopeContext;private CaptureHandler handler;private Object auth;
 private Class<?> type(String name)throws Exception{return Class.forName(name,true,loader);}
 private Object get(Object value,String field)throws Exception{Field f=value.getClass().getDeclaredField(field);f.setAccessible(true);return f.get(value);}
 private void check(boolean condition,String description){if(!condition)throw new AssertionError(description);checks++;}
 private Object helper(String name,String method,Class<?>[] types,Object...args)throws Exception{return type("cc.forserein.simhub.internal."+name).getMethod(method,types).invoke(null,args);}
 private Constructor<?> constructor(Class<?> type,int count){for(Constructor<?> c:type.getDeclaredConstructors())if(c.getParameterTypes().length==count){c.setAccessible(true);return c;}throw new AssertionError(type.getName());}
 private void remember(String name)throws Exception{for(Field f:type(name).getDeclaredFields())if(Modifier.isStatic(f.getModifiers())&&!Modifier.isFinal(f.getModifiers())){f.setAccessible(true);saved.put(f,f.get(null));}}
 private Object state()throws Exception{return flow.getClass().getMethod("getValue").invoke(flow);}
 private Object card(String imsi,String iccid,int mnc)throws Exception{return constructor(type("ek5"),8).newInstance(imsi,iccid,mnc,null,null,null,null,null);}
 public static final class IsolatedContext extends ContextWrapper {
  final String prefix="art_reader237_"+UUID.randomUUID()+"_";final Set<String> files=new LinkedHashSet<>();
  int foregroundStarts;String lastForegroundComponent;
  IsolatedContext(Context base){super(base);}
  @Override public Context getApplicationContext(){return this;}
  @Override public SharedPreferences getSharedPreferences(String name,int mode){String actual=prefix+name;files.add(actual);return getBaseContext().getSharedPreferences(actual,mode);}
  @Override public ComponentName startForegroundService(Intent intent){foregroundStarts++;lastForegroundComponent=intent.getComponent()==null?null:intent.getComponent().getClassName();return intent.getComponent();}
  void clean(){for(String file:files){if(!getBaseContext().getSharedPreferences(file,0).edit().clear().commit()||!getBaseContext().deleteSharedPreferences(file))throw new IllegalStateException("Temporary reader ART preferences cleanup failed");}}
 }
 public static final class CaptureHandler extends Handler {
  final ArrayList<Runnable> queued=new ArrayList<>();
  CaptureHandler(){super(Looper.getMainLooper());}
  @Override public synchronized boolean sendMessageAtTime(Message message,long at){Runnable task=message.getCallback();if(task==null)throw new AssertionError("Unexpected non-runnable connection dispatch");queued.add(task);return true;}
  synchronized ArrayList<Runnable> copy(){return new ArrayList<>(queued);}
  synchronized void clear(){queued.clear();}
 }
 private void setup()throws Exception{
  originalContext=type("zl5").getField("f").get(null);originalLibraryContext=type("fj5").getField("d").get(null);flow=type("zl5").getField("b").get(null);originalState=state();
  check(type("zl5").getField("p").get(null)==null&&type("zl5").getField("m").get(null)==null&&type("zl5").getField("n").get(null)==null,"instrumentation starts without a real connection or active engine");
  remember("zl5");remember("cc.forserein.simhub.internal.WifiConfigRuntime");remember("cc.forserein.simhub.internal.CarrierPresets");
  isolated=new IsolatedContext(getTargetContext());type("zl5").getField("f").set(null,isolated);type("fj5").getField("d").set(null,isolated);
  scope=type("zl5").getField("e").get(null);scopeContext=scope.getClass().getDeclaredField("T");scopeContext.setAccessible(true);originalScopeContext=scopeContext.get(scope);
  handler=new CaptureHandler();Object dispatcher=type("vz1").getConstructor(Handler.class).newInstance(handler);
  Object fixtureContext=type("fu0").getMethod("E",type("fu0")).invoke(originalScopeContext,dispatcher);scopeContext.set(scope,fixtureContext);
  check(scope.getClass().getMethod("c").invoke(scope)==fixtureContext,"actual native coroutine scope uses the recording dispatcher context");
  Object key=type("t3").getField("H0").get(null);check(type("fu0").getMethod("M",type("eu0")).invoke(fixtureContext,key)==dispatcher,"native context resolves the capture-only dispatcher");
  Object transport=Proxy.newProxyInstance(loader,new Class<?>[]{type("qg0")},(proxy,method,args)->{
   if(method.getDeclaringClass()==Object.class){if(method.getName().equals("equals"))return proxy==args[0];if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);return "ART synthetic no-APDU transport";}
   apduCalls++;throw new AssertionError("Connection task executed transport method "+method.getName());
  });
  auth=type("ac5").getConstructor(type("qg0"),Context.class).newInstance(transport,isolated);type("zl5").getField("l").set(null,auth);
 }
 private Object publish(Object card,String selection)throws Exception{
  String key=(String)helper("WifiConfigRuntime","cardKey",new Class<?>[]{Object.class},card);Map<String,String> values=new LinkedHashMap<>();if(selection!=null)values.put("carrier_preset",selection);
  String record=(String)helper("WifiConfigValues","encode",new Class<?>[]{Map.class},values);check(isolated.getSharedPreferences("wifi_config_overrides_v1",0).edit().putString(key,record).commit(),"synthetic carrier selection persisted in isolated preferences");
  Object config=helper("WifiConfigModel","builtIn",new Class<?>[]{Object.class},card);Object[] fields=new Object[20];for(int i=0;i<fields.length;i++)fields[i]=get(originalState,String.valueOf((char)('a'+i)));
  fields[4]=card;fields[5]=config;fields[6]=false;fields[7]="";fields[8]="";fields[9]="490154203237518";fields[10]=type("tk5").getField("g").get(null);fields[11]=false;fields[17]=false;
  flow.getClass().getMethod("i",Object.class).invoke(flow,constructor(type("gl5"),20).newInstance(fields));return get(state(),"f");
 }
 private Object findTask(Object value,IdentityHashMap<Object,Boolean> seen,int depth)throws Exception{
  if(value==null||depth>12||seen.size()>300||seen.put(value,Boolean.TRUE)!=null)return null;
  if(value.getClass()==type("hm0")&&Integer.valueOf(1).equals(get(value,"X")))return value;
  if(value.getClass().getClassLoader()!=loader)return null;
  for(Class<?> cls=value.getClass();cls!=null&&cls.getClassLoader()==loader;cls=cls.getSuperclass())for(Field f:cls.getDeclaredFields())if(!Modifier.isStatic(f.getModifiers())&&!f.getType().isPrimitive()){
   f.setAccessible(true);Object result=findTask(f.get(value),seen,depth+1);if(result!=null)return result;
  }return null;
 }
 private void cancelCaptured()throws Exception{
  Object job=type("zl5").getField("p").get(null);if(job!=null)job.getClass().getMethod("i",CancellationException.class).invoke(job,new CancellationException("Independent ART probe: connection task never executed"));
  type("zl5").getField("p").set(null,null);if(handler!=null)handler.clear();
 }
 private void captured(String label,Object raw,Object config,String expectedImsi,boolean sameCard)throws Exception{
  captured(label,raw,config,expectedImsi,sameCard,false);
 }
 private void captured(String label,Object raw,Object config,String expectedImsi,boolean sameCard,boolean enableEntry)throws Exception{
  handler.clear();int before=type("zl5").getField("q").getInt(null);
  if(enableEntry)type("zl5").getMethod("x",boolean.class).invoke(null,true);else type("zl5").getMethod("z").invoke(null);
  if(enableEntry){check(Boolean.TRUE.equals(get(state(),"l")),"actual enable entry publishes the on state");check(isolated.foregroundStarts==1&&"cc.forserein.simhub.vowifi.VoWiFiForegroundService".equals(isolated.lastForegroundComponent),"actual enable entry requests its foreground service, intercepted without starting it");}
  check(type("zl5").getField("q").getInt(null)==before+1,label+": actual native connection generation advances");
  check(type("zl5").getField("p").get(null)!=null,label+": actual native connection job created");
  ArrayList<Runnable> tasks=handler.copy();check(!tasks.isEmpty(),label+": actual xq0.X queues native coroutine without running it");
  Object task=null;for(Runnable queued:tasks){task=findTask(queued,new IdentityHashMap<Object,Boolean>(),0);if(task!=null)break;}
  check(task!=null,label+": actual queued continuation contains hm0 connection task");
  check(get(task,"a0")==auth&&get(task,"b0")==config,label+": native task captures actual auth and published config");
  Object identity=get(task,"c0");check(expectedImsi.equals(get(identity,"a")),label+": native task captures expected observed IMSI");
  check((identity==raw)==sameCard,label+": native task preserves expected card/immutable-copy identity");
  check(get(raw,"b").equals(get(identity,"b")),label+": captured identity belongs to the same ICCID");
  check(Integer.valueOf(0).equals(get(task,"Y"))&&apduCalls==0,label+": coroutine body and APDU never execute");
  check(type("zl5").getField("m").get(null)==null&&type("zl5").getField("n").get(null)==null,label+": no IKE or IMS engine was started");
  cases.add(label);cancelCaptured();
 }
 private void cases()throws Exception{
  for(String name:new String[]{"zl5","hm0","ac5","b72","cc.forserein.simhub.internal.DitoHomeIdentity","cc.forserein.simhub.internal.DitoCarrierProfile"}){type(name).getDeclaredMethods();checks++;}
  Object roaming=card("204049876543210","8963660000000000037",2);
  Object config=publish(roaming,null);check("DITO".equals(get(config,"c")),"actual runtime selects DITO for the synthetic known IIN");
  captured("current-20404-no-home",roaming,config,"204049876543210",true);
  config=publish(roaming,null);captured("enable-x-true-current-20404-no-home",roaming,config,"204049876543210",true,true);
  Object home=card("515660000000037","8963660000000000037",2);helper("DitoHomeIdentity","observe",new Class<?>[]{Object.class},home);
  config=publish(roaming,null);captured("same-card-real-home-DITO",roaming,config,"515660000000037",false);
  String otherKey=null;for(Object entry:(List<?>)helper("CarrierPresets","search",new Class<?>[]{String.class},"20404")){if("20404".equals(get(entry,"plmn"))){otherKey=(String)get(entry,"key");break;}}
  check(otherKey!=null,"a real non-DITO preset is available for manual selection");config=publish(roaming,otherKey);check(!"DITO".equals(get(config,"c")),"actual runtime honors non-DITO preset selection");
  captured("manual-non-DITO-with-home-history",roaming,config,"204049876543210",true);
  config=publish(home,null);captured("current-native-51566",home,config,"515660000000037",true);
  Object mismatch=card("515660000000037","8963660000000000037",3);publish(mismatch,null);handler.clear();int before=type("zl5").getField("q").getInt(null);type("zl5").getMethod("x",boolean.class).invoke(null,true);
  boolean connectionQueued=false;for(Runnable queued:handler.copy())if(findTask(queued,new IdentityHashMap<Object,Boolean>(),0)!=null)connectionQueued=true;
  check(!connectionQueued&&type("zl5").getField("p").get(null)==null&&type("zl5").getField("q").getInt(null)==before,"current 51566 with wrong MNC length never schedules a native hm0 connection (teardown may be queued)");
  check(Boolean.FALSE.equals(get(state(),"l"))&&isolated.foregroundStarts==2,"actual rejected enable entry returns the switch to off; foreground service requests remain intercepted");
  check(apduCalls==0,"all real entry probes remain offline with no APDU calls");
 }
 private void cleanup()throws Exception{
  if(handler!=null)cancelCaptured();if(scopeContext!=null&&originalScopeContext!=null)scopeContext.set(scope,originalScopeContext);
  if(flow!=null&&originalState!=null)flow.getClass().getMethod("i",Object.class).invoke(flow,originalState);
  for(Map.Entry<Field,Object> entry:saved.entrySet())entry.getKey().set(null,entry.getValue());
  if(loader!=null){type("zl5").getField("f").set(null,originalContext);type("fj5").getField("d").set(null,originalLibraryContext);}
  if(isolated!=null)isolated.clean();
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);start();}
 @Override public void onStart(){Bundle result=new Bundle();Throwable error=null;boolean cleaned=false;
  try{runOnMainSync(()->{});loader=getTargetContext().getClassLoader();setup();cases();}catch(Throwable problem){error=problem;}finally{try{cleanup();cleaned=true;}catch(Throwable problem){if(error==null)error=problem;else error.addSuppressed(problem);}}
  result.putInt("checks",checks);result.putInt("apdu_calls",apduCalls);result.putBoolean("synthetic_state_cleaned",cleaned);result.putStringArrayList("captured_native_cases",cases);
  result.putString("scope","Actual zl5.x(true) and zl5.z -> xq0.X -> ls4/hm0 scheduling on ART. Foreground-service start is intercepted; native dispatcher uses a capture-only Handler and coroutine task never executes. Synthetic current/home identities and private temporary preferences. No network, SIM/APDU or audio.");
  if(error==null){result.putString("status","passed");finish(0,result);}else{result.putString("status","failed");result.putString("error",android.util.Log.getStackTraceString(error));finish(1,result);}
 }
}
