package readersmoke;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.*;
import android.util.Base64;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.*;
import java.util.*;

/** Renders the shipped fd2.r reader Wi-Fi card, with no replacement UI and no toggle clicks. */
public final class ReaderUiSmoke extends Instrumentation {
 private ClassLoader loader;private Activity activity;private int checks,callbacks;
 private final LinkedHashMap<Field,Object> saved=new LinkedHashMap<>();private final ArrayList<String> captures=new ArrayList<>();
 private ReaderSmoke.IsolatedContext isolated;private Object flow,originalState,originalContext,originalLibraryContext;
 private Object signal;private int revision;private boolean rendered;
 private Class<?> type(String name)throws Exception{return Class.forName(name,true,loader);}
 private Object get(Object value,String name)throws Exception{Field f=value.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(value);}
 private void check(boolean condition,String message){if(!condition)throw new AssertionError(message);checks++;}
 private Object helper(String name,String method,Class<?>[] types,Object...args)throws Exception{return type("cc.forserein.simhub.internal."+name).getMethod(method,types).invoke(null,args);}
 private Constructor<?> constructor(Class<?> cls,int count){for(Constructor<?> c:cls.getDeclaredConstructors())if(c.getParameterTypes().length==count){c.setAccessible(true);return c;}throw new AssertionError(cls.getName());}
 private void remember(String name)throws Exception{for(Field f:type(name).getDeclaredFields())if(Modifier.isStatic(f.getModifiers())&&!Modifier.isFinal(f.getModifiers())){f.setAccessible(true);saved.put(f,f.get(null));}}
 private Object state()throws Exception{return flow.getClass().getMethod("getValue").invoke(flow);}
 private Object card(String imsi,String iccid)throws Exception{return constructor(type("ek5"),8).newInstance(imsi,iccid,2,null,null,null,null,null);}
 private void setup()throws Exception{
  originalContext=type("zl5").getField("f").get(null);originalLibraryContext=type("fj5").getField("d").get(null);flow=type("zl5").getField("b").get(null);originalState=state();
  remember("cc.forserein.simhub.internal.WifiConfigRuntime");remember("cc.forserein.simhub.internal.CarrierPresets");
  isolated=new ReaderSmoke.IsolatedContext(getTargetContext());type("zl5").getField("f").set(null,isolated);type("fj5").getField("d").set(null,isolated);
  signal=type("qd2").getMethod("D",Object.class).invoke(null,Integer.valueOf(0));
 }
 private void publish(Object card,String selection)throws Exception{
  String key=(String)helper("WifiConfigRuntime","cardKey",new Class<?>[]{Object.class},card);Map<String,String> overrides=new LinkedHashMap<>();if(selection!=null)overrides.put("carrier_preset",selection);
  String record=(String)helper("WifiConfigValues","encode",new Class<?>[]{Map.class},overrides);if(!isolated.getSharedPreferences("wifi_config_overrides_v1",0).edit().putString(key,record).commit())throw new IllegalStateException("UI fixture preference write failed");
  Object config=helper("WifiConfigModel","builtIn",new Class<?>[]{Object.class},card);Object[] values=new Object[20];for(int i=0;i<values.length;i++)values[i]=get(originalState,String.valueOf((char)('a'+i)));
  values[4]=card;values[5]=config;values[6]=false;values[7]="";values[8]="";values[9]="490154203237518";values[10]=type("tk5").getField("g").get(null);values[11]=false;values[17]=false;
  flow.getClass().getMethod("i",Object.class).invoke(flow,constructor(type("gl5"),20).newInstance(values));
 }
 private Object callback(String name,java.util.function.Function<Object[],Object> action)throws Exception{
  return Proxy.newProxyInstance(loader,new Class<?>[]{type(name)},(proxy,method,args)->{
   if(method.getDeclaringClass()==Object.class){if(method.getName().equals("equals"))return proxy==args[0];if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);return "Reader native UI fixture callback";}return action.apply(args);
  });
 }
 private Object composable(int key,Object callback)throws Exception{return type("zn0").getConstructor(int.class,boolean.class,type("gt1")).newInstance(key,true,callback);}
 private void render(int key)throws Exception{
  final Object noAction=callback("us1",args->{try{callbacks++;return type("sc5").getField("a").get(null);}catch(Exception e){throw new RuntimeException(e);}});
  Object body=callback("kt1",args->{try{
   type("ot4").getMethod("getValue").invoke(signal);Object captured=state();String iccid=(String)get(get(captured,"e"),"b");
   type("fd2").getMethod("r",type("gl5"),String.class,type("us1"),type("us1"),type("us1"),boolean.class,type("lu1"),int.class).invoke(null,captured,iccid,noAction,noAction,noAction,false,args[0],0);
   return type("sc5").getField("a").get(null);
  }catch(Exception error){throw new RuntimeException(error);}});
  final Object inner=composable(key,body);Object theme=callback("kt1",args->{try{type("z55").getMethod("a",type("zn0"),type("lu1"),int.class).invoke(null,inner,args[0],0);return type("sc5").getField("a").get(null);}catch(Exception error){throw new RuntimeException(error);}});
  type("sn0").getMethod("a",type("rn0"),type("zn0")).invoke(null,activity,composable(key+1,theme));
 }
 private String tree(AccessibilityNodeInfo node,int depth){if(node==null||depth>20)return "";StringBuilder text=new StringBuilder();text.append(node.getClassName()).append(':').append(node.getText()).append(":enabled=").append(node.isEnabled()).append(":checkable=").append(node.isCheckable()).append(":checked=").append(node.isChecked()).append('\n');for(int i=0;i<node.getChildCount();i++)text.append(tree(node.getChild(i),depth+1));return text.toString();}
 private AccessibilityNodeInfo toggle(AccessibilityNodeInfo node){if(node==null)return null;if(node.isCheckable())return node;for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo value=toggle(node.getChild(i));if(value!=null)return value;}return null;}
 private Bitmap awaitFlag(String country)throws Exception{
  // Inspect the native header's leading icon in actual screenshot pixels. The app
  // scales Compose independently of raw Resources density, so no dp conversion is used.
  long end=SystemClock.uptimeMillis()+20000;int reds=0,blues=0;long redY=0,blueY=0;
  while(SystemClock.uptimeMillis()<end){Bitmap bitmap=getUiAutomation().takeScreenshot();if(bitmap!=null){
   reds=0;blues=0;redY=0;blueY=0;
   for(int y=10;y<bitmap.getHeight()/10;y++)for(int x=0;x<Math.round(bitmap.getWidth()*.14f);x++){
    int color=bitmap.getPixel(x,y),red=Color.red(color),green=Color.green(color),blue=Color.blue(color);
    if(red>blue+50&&red>green+20){reds++;redY+=y;}
    if(blue>red+50&&blue>green+20){blues++;blueY+=y;}
   }
   if(reds>20&&blues>20){double averageRed=redY/(double)reds,averageBlue=blueY/(double)blues;if("PH".equals(country)?averageBlue+2<averageRed:averageRed+2<averageBlue)return bitmap;}
   bitmap.recycle();
  }SystemClock.sleep(200);}
  throw new AssertionError("Native flag not fully rendered as "+country+" red/blue pixel counts="+reds+"/"+blues);
 }
 private AccessibilityNodeInfo awaitCard(String subtitle,String ready)throws Exception{
  long end=SystemClock.uptimeMillis()+45000;while(SystemClock.uptimeMillis()<end){AccessibilityNodeInfo node=getUiAutomation().getRootInActiveWindow();String text=tree(node,0);if(text.contains(subtitle)&&text.contains(ready))return node;SystemClock.sleep(200);}throw new AssertionError("Native reader card text not rendered: "+tree(getUiAutomation().getRootInActiveWindow(),0));
 }
 private void capture(String label,Object card,String selection,String country)throws Exception{
  final Throwable[] error={null};runOnMainSync(()->{try{publish(card,selection);if(!rendered){render(237100);rendered=true;}else type("m83").getMethod("setValue",Object.class).invoke(signal,Integer.valueOf(++revision));}catch(Throwable e){error[0]=e;}});if(error[0]!=null)throw new AssertionError("Native reader rendering failed",error[0]);
  check(country.equals(helper("ReaderWifiPresentation","country",new Class<?>[]{Object.class},state())),label+": actual selected preset country is "+country);
  String rawPlmn=(String)card.getClass().getMethod("d").invoke(card);
  String subtitle="PH".equals(country)&&!"51566".equals(rawPlmn)?"DITO · 51566":get(get(state(),"f"),"c")+" · PLMN "+rawPlmn;
  String ready=(String)type("qv4").getMethod("b",String.class).invoke(null,"vowifi_sms_phase_card_ready");
  AccessibilityNodeInfo node=awaitCard(subtitle,ready);String text=tree(node,0);check(text.contains(subtitle)&&(!"PH".equals(country)||!text.contains("PLMN 20404")),label+": actual fd2.r subtitle follows selected preset");
  check(text.contains(ready),label+": native readiness status allows valid observed identity");
  AccessibilityNodeInfo toggle=toggle(node);check(toggle!=null&&!toggle.isChecked(),label+": actual native switch is visibly off");check(toggle.isEnabled(),label+": native switch remains enabled");
  check(Boolean.FALSE.equals(get(state(),"l"))&&type("zl5").getField("m").get(null)==null&&type("zl5").getField("n").get(null)==null,label+": rendering did not start IKE or IMS");
  try{getUiAutomation().waitForIdle(300,5000);}catch(java.util.concurrent.TimeoutException ignored){}
  Bitmap bitmap=awaitFlag(country);check(bitmap!=null,label+": actual expected PH/NL flag pixels finish loading after recomposition");check(bitmap!=null,label+": native reader screenshot captured");ByteArrayOutputStream png=new ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.PNG,100,png);
  Bundle image=new Bundle();image.putString("capture",label);image.putString("png_base64",Base64.encodeToString(png.toByteArray(),Base64.NO_WRAP));image.putString("accessibility_tree",text);sendStatus(0,image);captures.add(label);
 }
 private void cases()throws Exception{
  Object roaming=card("204049876543210","8963660000000000137");capture("synthetic-reader-current20404-no-home",roaming,null,"PH");
  Object home=card("515660000000137","8963660000000000137");helper("DitoHomeIdentity","observe",new Class<?>[]{Object.class},home);capture("synthetic-reader-current20404-saved-home",roaming,null,"PH");
  String selected=null;for(Object entry:(List<?>)helper("CarrierPresets","search",new Class<?>[]{String.class},"20404"))if("20404".equals(get(entry,"plmn"))){selected=(String)get(entry,"key");break;}
  check(selected!=null,"real 20404 preset available for same-card recomposition");capture("synthetic-reader-same-card-manual-nl",roaming,selected,"NL");
  capture("synthetic-reader-same-card-return-dito",roaming,null,"PH");capture("synthetic-reader-native51566",home,null,"PH");
  check(callbacks==0,"no callback or connection toggle was invoked during native UI inspection");
 }
 private void cleanup()throws Exception{
  if(activity!=null){runOnMainSync(()->activity.finish());waitForIdleSync();}
  if(flow!=null&&originalState!=null)flow.getClass().getMethod("i",Object.class).invoke(flow,originalState);
  for(Map.Entry<Field,Object> item:saved.entrySet())item.getKey().set(null,item.getValue());
  if(loader!=null){type("zl5").getField("f").set(null,originalContext);type("fj5").getField("d").set(null,originalLibraryContext);}if(isolated!=null)isolated.clean();
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);start();}
 @Override public void onStart(){Bundle result=new Bundle();Throwable error=null;boolean cleaned=false;
  try{runOnMainSync(()->{});loader=getTargetContext().getClassLoader();activity=startActivitySync(new Intent().setClassName("cc.forserein.simhub","cc.forserein.simhub.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));waitForIdleSync();setup();cases();}catch(Throwable e){error=e;}finally{try{cleanup();cleaned=true;}catch(Throwable e){if(error==null)error=e;else error.addSuppressed(e);}}
  result.putInt("checks",checks);result.putBoolean("synthetic_state_cleaned",cleaned);result.putStringArrayList("native_reader_captures",captures);result.putString("scope","Actual shipped fd2.r reader Wi-Fi card under native z55 theme. Synthetic current/home cards and isolated preferences; no replacement layout or connection toggle click; no APDU/network/audio.");
  if(error==null){result.putString("status","passed");finish(0,result);}else{result.putString("status","failed");result.putString("error",android.util.Log.getStackTraceString(error));finish(1,result);}
 }
}
