package sipfailuresmoke;
import android.app.Instrumentation;
import android.os.Bundle;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** Actual installed o82.h/C execution with an empty native in-memory TCP connection map. */
@SuppressWarnings({"rawtypes","unchecked"})
public final class SipFailureSmoke extends Instrumentation {
 private ClassLoader loader;private int checks,nativeCalls,logCalls;private final ArrayList<String> completed=new ArrayList<>();
 private final String ID="art-sip-failure@example.invalid",BRANCH="z9hG4bK-art-invite-11";
 private final String SDP="v=0\r\no=- 1 1 IN IP4 192.0.2.10\r\ns=synthetic\r\nc=IN IP4 192.0.2.10\r\nt=0 0\r\nm=audio 10000 RTP/AVP 116\r\na=rtpmap:116 AMR-WB/16000\r\na=fmtp:116 octet-align=1\r\na=sendrecv\r\n";
 private Class<?> type(String name)throws Exception{return Class.forName(name,true,loader);}
 private Object get(Object o,String name)throws Exception{Field f=o.getClass().getField(name);f.setAccessible(true);return f.get(o);}
 private void set(Object o,String name,Object value)throws Exception{Field f=o.getClass().getField(name);f.setAccessible(true);f.set(o,value);}
 private Object stat(String c,String f)throws Exception{return type(c).getField(f).get(null);}
 private Object raw(String name)throws Exception{Class<?> u=Class.forName("sun.misc.Unsafe");Field f=u.getDeclaredField("theUnsafe");f.setAccessible(true);return u.getMethod("allocateInstance",Class.class).invoke(f.get(null),type(name));}
 private void check(boolean yes,String label){if(!yes)throw new AssertionError(label);checks++;}
 private Object message(boolean request,String method,int status,String body)throws Exception{return type("kb4").getConstructor(boolean.class,String.class,String.class,int.class,String.class,ArrayList.class,byte[].class).newInstance(request,method,"sip:peer@example.invalid",status,request?"":status==487?"Request Terminated":"OK",new ArrayList<>(),body.getBytes(StandardCharsets.US_ASCII));}
 private void header(Object p,String name,String value)throws Exception{type("kb4").getMethod("a",String.class,String.class).invoke(p,name,value);}
 private String first(Object p,String name)throws Exception{List list=(List)type("kb4").getMethod("j",String.class).invoke(p,name);return list.isEmpty()?null:(String)list.get(0);}
 private Object response(int code,int seq,String method,String tag,String branch)throws Exception{
  Object p=message(false,method,code,code==200&&method.equals("INVITE")?SDP:"");header(p,"Call-ID",ID);header(p,"CSeq",seq+" "+method);
  header(p,"From","<sip:local@example.invalid>;tag=local-tag");header(p,"To","<sip:peer@example.invalid>;tag="+tag);
  header(p,"Via","SIP/2.0/TCP 192.0.2.1:5060;branch="+branch);if(code==200&&method.equals("INVITE")){header(p,"Contact","<sip:A@example.invalid>");header(p,"Content-Type","application/sdp");}return p;
 }
 private final class Session {
  Object dialog,manager,engine,stack;
  Session()throws Exception{
   Object invite=message(true,"INVITE",0,"synthetic offer");header(invite,"Via","SIP/2.0/TCP 192.0.2.1:5060;branch="+BRANCH);
   header(invite,"From","<sip:local@example.invalid>;tag=local-tag");header(invite,"To","<sip:peer@example.invalid>");header(invite,"Call-ID",ID);header(invite,"CSeq","11 INVITE");header(invite,"Route","<sip:route.example.invalid;lr>");
   dialog=type("ma4").getConstructors()[0].newInstance(stat("ga4","U"),ID,stat("la4","T"),"local-tag","sip:local@example.invalid","sip:peer@example.invalid","sip:peer@example.invalid",11,11,invite,0.0);
   Object config=type("ra4").getConstructors()[0].newInstance("192.0.2.1",5060,"sip:local@example.invalid","urn:uuid:art-failure","sip:local@example.invalid","probe",new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),true,false);
   manager=type("cb4").getConstructors()[0].newInstance(config,null,null,null);((Map)get(manager,"e")).put(ID,dialog);
   engine=raw("o82");set(engine,"J",manager);set(engine,"V",new ArrayList<>());
   Object card=type("ek5").getConstructor(String.class,String.class,int.class,String.class,String.class,String.class,String.class,type("z82")).newInstance("","",2,"","",null,null,null);set(engine,"c",card);set(engine,"b",raw("xi5"));
   Object logger=Proxy.newProxyInstance(loader,new Class<?>[]{type("ws1")},(o,m,a)->{if(m.getName().equals("i")){logCalls++;return stat("sc5","a");}if(m.getName().equals("toString"))return "Synthetic SIP log sink";throw new AssertionError(m.toString());});
   set(engine,"g",type("g11").getConstructor(int.class,Object.class,Object.class).newInstance(13,engine,logger));
   stack=type("jf2").getConstructor(byte[].class).newInstance((Object)new byte[]{127,0,0,1});set(engine,"R",stack);set(engine,"T",Integer.valueOf(1));set(engine,"U",false);
  }
  boolean accept(Object response)throws Exception{nativeCalls++;try{return(Boolean)type("o82").getMethod("h",type("kb4")).invoke(engine,response);}catch(InvocationTargetException e){Throwable t=e.getCause();if(t instanceof Exception)throw(Exception)t;throw(Error)t;}}
  List packets()throws Exception{return(List)get(engine,"V");}
  boolean present()throws Exception{return((Map)get(manager,"e")).get(ID)==dialog;}
  void selected()throws Exception{check(accept(response(200,11,"INVITE","A",BRANCH)),"actual 200 response accepted");check(get(dialog,"D")!=null&&"A".equals(get(dialog,"l")),"actual native selected dialog confirmed");packets().clear();}
  void offline()throws Exception{check(((Map)get(stack,"j")).isEmpty()&&((Map)get(stack,"k")).isEmpty(),"native TCP stack has no connections or remote endpoint");check(get(stack,"c")==null,"native packet-output callback remains absent");}
 }
 private void ack(Object p,int cseq)throws Exception{check("ACK".equals(get(p,"b")),"native output packet is ACK");check((cseq+" ACK").equals(first(p,"CSeq")),"ACK preserves transaction CSeq");check(ID.equals(first(p,"Call-ID")),"ACK preserves Call-ID");check(first(p,"Via").contains(BRANCH),"ACK preserves original INVITE branch");}
 private byte[] wire(Object packet)throws Exception{return(byte[])type("kb4").getMethod("b").invoke(packet);}
 private void cases()throws Exception{
  for(String c:new String[]{"o82","cb4","kb4","ma4","jf2"}){type(c).getDeclaredMethods();checks++;}
  Session s=new Session();s.selected();Object state=get(s.dialog,"c"),confirmed=get(s.dialog,"D");byte[] media=((byte[])get(s.dialog,"p")).clone();
  check(s.accept(response(487,11,"INVITE","A",BRANCH)),"late final response consumed");
  check(s.present(),"delayed original INVITE 487 must retain confirmed dialog");check(get(s.dialog,"c")==state&&Objects.equals(get(s.dialog,"D"),confirmed),"delayed 487 preserves confirmed state/time");check(Arrays.equals(media,(byte[])get(s.dialog,"p")),"delayed 487 preserves negotiated media");check(s.packets().size()==1,"confirmed late487 receives one transaction ACK");ack(s.packets().get(0),11);s.offline();completed.add("confirmed-dialog-survives-delayed-487");
  s=new Session();check(s.accept(response(487,11,"INVITE","A",BRANCH)),"matching pending 487 consumed");check(!s.present(),"matching pending INVITE rejection ends pending dialog");check(s.packets().size()==1,"matching pending 487 produces one ACK");ack(s.packets().get(0),11);byte[] originalAck=wire(s.packets().get(0));s.packets().clear();check(s.accept(response(487,11,"INVITE","A",BRANCH)),"removed-dialog 487 retransmission consumed");check(!s.present()&&s.packets().size()==1,"removed-dialog retransmission only generates cached ACK");check(Arrays.equals(originalAck,wire(s.packets().get(0))),"487 retransmission sends byte-identical ACK");s.offline();completed.add("pending-matching-487-ACK-and-end");completed.add("removed-dialog-487-retransmission-ACK");
  s=new Session();state=get(s.dialog,"c");check(s.accept(response(487,10,"INVITE","A",BRANCH)),"old CSeq response consumed");check(s.present()&&get(s.dialog,"c")==state,"old CSeq response preserves current pending INVITE");check(s.packets().isEmpty(),"unmatched old CSeq cannot emit an ACK for current transaction");s.offline();completed.add("old-CSeq-cannot-end-new-INVITE");
  s=new Session();s.selected();state=get(s.dialog,"c");check(s.accept(response(487,12,"UPDATE","A","z9hG4bK-art-update")),"UPDATE failure consumed");check(s.present()&&get(s.dialog,"c")==state,"UPDATE487 does not terminate confirmed INVITE");s.offline();completed.add("UPDATE487-preserves-call");
  s=new Session();state=get(s.dialog,"c");check(s.accept(response(487,11,"INVITE","A","z9hG4bK-wrong-branch")),"wrong branch response consumed");check(s.present()&&get(s.dialog,"c")==state&&s.packets().isEmpty(),"same CSeq with wrong branch preserves pending dialog without ACK");
  Object wrongFrom=response(487,11,"INVITE","A",BRANCH);type("kb4").getMethod("i",String.class,String.class).invoke(wrongFrom,"From","<sip:local@example.invalid>;tag=wrong-tag");check(s.accept(wrongFrom),"wrong local From-tag response consumed");check(s.present()&&get(s.dialog,"c")==state&&s.packets().isEmpty(),"wrong local From-tag cannot terminate or ACK current transaction");s.offline();completed.add("branch-and-local-tag-transaction-scope");
  s=new Session();set(s.dialog,"w",true);List actions=(List)type("cb4").getMethod("j",String.class,double.class).invoke(s.manager,ID,10.0);
  check(get(s.dialog,"c")==stat("la4","X"),"actual native local cancellation enters terminating state");
  boolean cancelEvent=false;for(Object action:actions)if(action.getClass()==type("na4")){Object event=get(action,"a");for(Field f:event.getClass().getFields())if(!Modifier.isStatic(f.getModifiers())&&f.get(event)==stat("ua4","l"))cancelEvent=true;}
  check(cancelEvent,"actual native cancellation action carries user-cancel reason");type("o82").getMethod("k",List.class).invoke(s.engine,actions);
  check(s.packets().size()==1&&"CANCEL".equals(get(s.packets().get(0),"b")),"actual native cancellation builds CANCEL into offline transport");s.packets().clear();
  check(s.accept(response(487,11,"INVITE","A",BRANCH)),"matching487 after local cancellation consumed");check(!s.present()&&get(s.dialog,"c")==stat("la4","Y"),"cancelled dialog ends normally after487");check(s.packets().size()==1,"cancelled INVITE receives one ACK");ack(s.packets().get(0),11);s.offline();completed.add("native-local-CANCEL-then-487");
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);start();}
 @Override public void onStart(){Bundle b=new Bundle();Throwable failure=null;try{runOnMainSync(()->{});loader=getTargetContext().getClassLoader();cases();}catch(Throwable t){failure=t;}
  b.putInt("checks",checks);b.putInt("native_response_calls",nativeCalls);b.putInt("native_log_calls",logCalls);b.putInt("network_socket_calls",0);b.putStringArrayList("completed_cases",completed);
  b.putString("scope","Actual installed o82.h, C and native SIP builders execute on Android ART. Native TCP stack has no connection and no packet-output callback; intended ACKs are inspected in native V before closed-session discard. No socket, APDU, SIM, media or real number is used.");
  if(failure==null){b.putString("status","passed");finish(0,b);}else{b.putString("status","failed");b.putString("error",android.util.Log.getStackTraceString(failure));finish(1,b);}
 }
}
