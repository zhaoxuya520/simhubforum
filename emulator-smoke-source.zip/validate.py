"""Independent Android ART validation; execute only with the final signed APK/hash."""
from pathlib import Path
import argparse, subprocess, hashlib, re, json, datetime
parser=argparse.ArgumentParser()
parser.add_argument('--apk',type=Path,required=True)
parser.add_argument('--sha256',required=True)
args=parser.parse_args()
review=Path(__file__).resolve().parent
release=Path('/workspace/recovery/switch24.0-release')
adb=['/workspace/tools/android-platform-tools/platform-tools/adb','-s','emulator-5580']
package='cc.forserein.simhub'
baseline='669cb2270e4473bf6261ca627a5e459b085d82a536cadbe5567fb0b46dea2728'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run(*command,timeout=120):
 result=subprocess.run([*adb,*map(str,command)],capture_output=True,text=True,timeout=timeout)
 result.check_returncode();return result.stdout+result.stderr
def write(name,value):
 (review/name).write_text(value);return value
def installed_hash():
 path=run('shell','pm','path',package).strip().split('package:')[-1]
 return run('shell','sha256sum',path).split()[0]
def certificate(apk,name):
 result=subprocess.run(['java','-jar','/workspace/tools/android-recovery/sdk/android-15/lib/apksigner.jar','verify','--verbose','--print-certs',str(apk)],capture_output=True,text=True,check=True)
 output=write(name,result.stdout+result.stderr)
 return re.search(r'certificate SHA-256 digest: (\w+)',output).group(1)
def art(name,apk,component):
 install=write(name+'-install.txt',run('install','--no-streaming','-r',apk,timeout=180))
 assert 'Success' in install
 output=write(name+'-art.txt',run('shell','am','instrument','-w',component,timeout=180))
 assert 'INSTRUMENTATION_RESULT: status=passed' in output and 'INSTRUMENTATION_CODE: 0' in output,output
 return output,int(re.search(r'checks=(\d+)',output).group(1))
assert digest(args.apk)==args.sha256
assert run('shell','getprop','sys.boot_completed').strip()=='1'
before=installed_hash();assert before==baseline,before
previous=write('baseline23.9-package.txt',run('shell','dumpsys','package',package))
assert 'versionName=23.9' in previous and 'versionCode=18 ' in previous
old_cert=certificate(Path('/workspace/recovery/aka23.9-release/SIMHub-23.9-signed.apk'),'baseline23.9-signature.txt')
new_cert=certificate(args.apk,'final-signature.txt');assert new_cert==old_cert
run('shell','am','force-stop',package);run('logcat','-c')
install=write('install.txt',run('install','--no-streaming','-r',args.apk,timeout=300));assert 'Success' in install
print('Upgrade 23.9 -> 24.0 installation: Success',flush=True)
switch_apk=review/'harness/switch-instrumentation.apk'
switch,switch_checks=art('switch',switch_apk,'cc.forserein.simhub.switchsmoke/switchsmoke.SwitchSmoke')
print('Actual switch ART checks:',switch_checks,flush=True)
aka_apk=Path('/workspace/recovery/aka23.9-review/emulator/harness/aka-instrumentation.apk')
aka,aka_checks=art('aka',aka_apk,'cc.forserein.simhub.akasmoke/akasmoke.AkaSmoke')
assert 'apdu_calls=0' in aka
print('Actual normal AKA regression checks:',aka_checks,flush=True)
run('shell','am','force-stop',package)
cold=write('cold-start.txt',run('shell','am','start','-W','-n',package+'/.MainActivity'))
assert 'Status: ok' in cold and 'LaunchState: COLD' in cold
info=write('package.txt',run('shell','dumpsys','package',package))
assert 'versionName=24.0' in info and 'versionCode=19 ' in info
installed=installed_hash();assert installed==args.sha256
write('installed-apk-sha256.txt',installed+'\n')
logs=write('final-logcat.txt',run('logcat','-d','-v','threadtime',timeout=45))
errors=[line for line in logs.splitlines() if re.search(r'FATAL EXCEPTION|VerifyError|Verification failed|NoSuchMethodError|NoClassDefFoundError|ANR in cc\.forserein\.simhub',line)]
assert not errors,errors
write('app-error-summary.txt','No app fatal, ART verification/linkage failure or SIMHub ANR in captured logs.\n')
def fields(output):
 return dict(re.findall(r'^INSTRUMENTATION_RESULT: (\w+)=(.*)$',output,re.M))
result={
 'status':'passed','version_name':'24.0','version_code':19,
 'upgrade_from_sha256':before,'apk_sha256':args.sha256,'installed_apk_sha256':installed,
 'install_upgrade_verified':True,'signature_unchanged':True,'signer_certificate_sha256':new_cert,
 'main_activity_start':True,'art_execution':True,'offline_art_checks':switch_checks+aka_checks,
 'switch_art_checks':switch_checks,'aka_regression_checks':aka_checks,
 'switch_results':fields(switch),'aka_results':fields(aka),
 'physical_apdu_calls':int(fields(switch)['physical_apdu_calls']),'synthetic_apdu_calls':int(fields(switch)['total_synthetic_apdus']),
 'native_switch_calls':int(fields(switch)['native_switch_calls']),
 'baseline_bug_reproduced_on_actual_art':True,'baseline_evidence':'baseline23.9-switch-art.txt',
 'fatal_or_verification_errors':errors,'synthetic_sim':True,'real_carrier_tested':False,
 'physical_phone_tested':False,'physical_card_mutated':False,'calls_sent':False,
 'scope':'Final APK actual classes on Android ART with controlled synthetic profile/transport state; normal AKA regression invokes actual da1.b. No real card, APDU to hardware, IMS registration or calls.',
 'limits':['No physical phone or reader is attached; emulator-5580 uses Android 11 API30 x86_64 software acceleration.','Synthetic transport/profile operations verify application control flow, not real eUICC firmware, radio refresh or physical card compatibility.','No UI layout or audio changed in the requested test scope, so no screenshots or media tests were repeated.'],
 'sources':{p.name:digest(p) for p in (review/'harness').glob('*') if p.suffix in ('.java','.py','.xml')},
 'driver_sha256':digest(Path(__file__)),'instrumentation_apk_sha256':digest(switch_apk),
 'aka_instrumentation_apk_sha256':digest(aka_apk),
 'logs':{p.name:digest(p) for p in review.glob('*.txt')},
 'cold_start':cold.strip(),'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()
}
(release/'emulator-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Emulator validation report:',release/'emulator-validation.json',flush=True)
