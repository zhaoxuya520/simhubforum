from pathlib import Path
import subprocess, json, hashlib, re, datetime
review=Path(__file__).resolve().parent
release=Path('/workspace/recovery/eap23.8-release')
apk=release/'SIMHub-23.8-signed.apk'
adb='/workspace/tools/android-platform-tools/platform-tools/adb'
package='cc.forserein.simhub'
def run(*args):
    return subprocess.check_output([adb,'-s','emulator-5580',*map(str,args)],text=True,stderr=subprocess.STDOUT)
def write(name,value):
    (review/name).write_text(value)
verify=json.loads(Path('/workspace/simhubforum/android/phone-slot-patch/build-config3/longterm-signed-validation.json').read_text())
digest=hashlib.sha256(apk.read_bytes()).hexdigest()
assert digest==verify['signed_apk_sha256']
device_apk=run('shell','pm','path',package).strip().split('package:')[-1]
before=run('shell','sha256sum',device_apk).split()[0]
assert before=='9f4779611ba4d5b9270699f6f504b7a01b7124f2f4b58badc9b4199c8e551375'
install=run('install','-r',apk);write('install.txt',install);assert 'Success' in install
device_apk=run('shell','pm','path',package).strip().split('package:')[-1]
installed=run('shell','sha256sum',device_apk).split()[0];assert installed==digest
package_info=run('shell','dumpsys','package',package)
assert 'versionName=23.8' in package_info and 'versionCode=17 ' in package_info
starttime=run('shell','date',r"+%m-%d\ %H:%M:%S.000").strip()
art=run('shell','am','instrument','-w','cc.forserein.simhub.readersmoke/readersmoke.ReaderSmoke')
write('auth-art.txt',art)
assert 'status=passed' in art and 'INSTRUMENTATION_CODE: 0' in art and 'synthetic_state_cleaned=true' in art and 'apdu_calls=0' in art,art
run('shell','am','force-stop',package)
launch=run('shell','am','start','-W','-n',package+'/.MainActivity')
write('cold-start.txt',launch)
assert 'Status: ok' in launch and package in launch and run('shell','pidof',package).strip().isdigit()
crash=run('logcat','-b','crash','-d','-T',starttime)
assert 'Process: '+package+',' not in crash
result=dict(version_name='23.8',version_code=17,upgrade_from_sha256=before,apk_sha256=digest,installed_apk_sha256=installed,
 install_upgrade_verified=True,main_activity_start=True,art_execution=True,offline_art_checks=int(re.search('checks=(\\d+)',art)[1]),
 fatal_or_verification_errors=[],synthetic_sim=True,real_carrier_tested=False,physical_phone_tested=False,
 calls_sent=False,apdu_calls=0,native_at_permanent_id_req_tested=True,
 scope='Actual APK config and scheduler on ART plus independent checks of da1 response to EAP-AKA/Identity AT_PERMANENT_ID_REQ, using synthetic subscriber data and a disconnected transport.',
 sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (review/'harness').glob('*') if p.suffix in ('.java','.py','.xml')},cold_start=launch.strip())
(release/'emulator-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['offline_art_checks'],digest)
