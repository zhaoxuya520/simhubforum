"""Install only the final pinned signed24.4; verify retained24.3 preferences and offline native ART."""
from pathlib import Path
import argparse, subprocess, hashlib, re, json, datetime

parser=argparse.ArgumentParser();parser.add_argument('--apk',type=Path,required=True);parser.add_argument('--sha256',required=True);args=parser.parse_args()
root=Path(__file__).resolve().parent;release=Path('/workspace/recovery/call24.4-release')
fixture=Path('/workspace/recovery/stable24.3-review/emulator')
adb=['/workspace/tools/android-platform-tools/platform-tools/adb','-s','emulator-5580']
package='cc.forserein.simhub';baseline='4aff162690628b2e9265b6cf88eeb1cf93b0c644d0c999015ba1d609863abf98'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(*c,timeout=180):
 p=subprocess.run(adb+list(map(str,c)),capture_output=True,text=True,timeout=timeout);p.check_returncode();return p.stdout+p.stderr
def write(name,text):(root/name).write_text(text);return text
def installed():
 p=run('shell','pm','path',package).strip().removeprefix('package:');return run('shell','sha256sum',p).split()[0]
def signer(apk,name):
 p=subprocess.run(['java','-jar','/workspace/tools/android-recovery/sdk/android-15/lib/apksigner.jar','verify','--verbose','--print-certs',str(apk)],capture_output=True,text=True,check=True)
 text=write(name,p.stdout+p.stderr);return re.search(r'certificate SHA-256 digest: (\w+)',text).group(1)
def fields(output):return dict(re.findall(r'^INSTRUMENTATION_RESULT: (\w+)=(.*)$',output,re.M))
def instrument(name,component,extras=()):
 run('shell','am','force-stop',package)
 output=write(name+'.txt',run('shell','am','instrument','-w',*extras,component))
 result=fields(output);assert result.get('status')=='passed' and 'INSTRUMENTATION_CODE: 0' in output,output
 print(name,result.get('checks'),'passed',flush=True);return result
def install_test(apk,name):
 output=write(name+'-install.txt',run('install','--no-streaming','-r',apk));assert 'Success' in output,output
assert sha(args.apk)==args.sha256
assert run('shell','getprop','sys.boot_completed').strip()=='1'
assert installed()==baseline,'Expected retained24.3 baseline before upgrade'
before=write('baseline24.3-package.txt',run('shell','dumpsys','package',package))
assert 'versionName=24.3' in before and 'versionCode=22 ' in before
oldcert=signer(Path('/workspace/recovery/call24.3-release/SIMHub-24.3-signed.apk'),'baseline24.3-signature.txt')
cert=signer(args.apk,'final-signature.txt');assert oldcert==cert
run('shell','am','force-stop',package);run('logcat','-c')
install=write('install.txt',run('install','--no-streaming','-r',args.apk,timeout=300));assert 'Success' in install
print('24.3 -> 24.4 same-signature upgrade succeeded',flush=True)
test=fixture/'config-harness/config-format-instrumentation.apk';install_test(test,'new-config-precondition')
prefix='cc.forserein.simhub.configformatsmoke/configformatsmoke.'
upgrade=instrument('retained24.3-config-recovery',prefix+'UpgradeConfigSmoke',('-e','phase','recover'))
assert upgrade['persisted_overrides_xml_sha256']=='30f08f246c9abbde1d6f8809d178f4286f03ea4270521658c385d332845e7e33'
config_write=instrument('config-new-write',prefix+'ConfigFormatSmoke',('-e','phase','write','-e','expect','fixed'))
config_read=instrument('config-new-cold-read',prefix+'ConfigFormatSmoke',('-e','phase','read','-e','expect','fixed'))
assert config_write['pid']!=config_read['pid'] and config_read['baseline_corruption_reproduced']=='false'
precondition=instrument('native-precondition',prefix+'PreconditionSmoke',('-e','expect','fixed'))
regressions={
 'prior24.3-success':(Path('/workspace/recovery/call24.3-review/emulator/harness/invite-success-instrumentation.apk'),'cc.forserein.simhub.invitesuccesssmoke/invitesuccesssmoke.InviteSuccessSmoke'),
 'prior24.2-terminal':(Path('/workspace/recovery/call24.3-review/emulator/baseline24.2/terminal-failure-instrumentation.apk'),'cc.forserein.simhub.terminalfailuresmoke/terminalfailuresmoke.TerminalFailureSmoke'),
 'prior24.1-487':(Path('/workspace/recovery/call24.3-review/emulator/baseline24.2/prior487/sip-failure-instrumentation.apk'),'cc.forserein.simhub.sipfailuresmoke/sipfailuresmoke.SipFailureSmoke'),
 'prior24.0-switch':(Path('/workspace/recovery/switch24.0-review/emulator/harness/switch-instrumentation.apk'),'cc.forserein.simhub.switchsmoke/switchsmoke.SwitchSmoke'),
}
prior={}
for name,(apk,component) in regressions.items():install_test(apk,name);prior[name]=instrument(name,component)
run('shell','am','force-stop',package)
cold=write('cold-start.txt',run('shell','am','start','-W','-n',package+'/.MainActivity'))
assert 'Status: ok' in cold and 'LaunchState: COLD' in cold
info=write('package.txt',run('shell','dumpsys','package',package));assert 'versionName=24.4' in info and 'versionCode=23 ' in info
device_hash=installed();assert device_hash==args.sha256
write('installed-apk-sha256.txt',device_hash+'\n')
logs=write('final-logcat.txt',run('logcat','-d','-v','threadtime',timeout=45))
errors=[line for line in logs.splitlines() if re.search(r'FATAL EXCEPTION|VerifyError|Verification failed|NoSuchMethodError|NoClassDefFoundError|ANR in cc\.forserein\.simhub',line)]
assert not errors,errors
write('app-error-summary.txt','No app fatal, ART verification/linkage failure or SIMHub ANR in captured validation logs.\n')
all_results={'retained24.3':upgrade,'new-config-write':config_write,'new-config-read':config_read,'precondition':precondition,**prior}
report={
 'status':'passed','version_name':'24.4','version_code':23,'apk_sha256':args.sha256,'installed_apk_sha256':device_hash,
 'upgrade_from_sha256':baseline,'install_upgrade_verified':True,'signature_unchanged':True,'signer_certificate_sha256':cert,
 'main_activity_start':True,'art_execution':True,'offline_art_checks':sum(int(x['checks']) for x in all_results.values()),
 'config_art_checks':sum(int(x['checks']) for x in (upgrade,config_write,config_read)),
 'precondition_art_checks':int(precondition['checks']),'prior_regression_checks':sum(int(x['checks']) for x in prior.values()),
 'results':all_results,'retained24.3_xml_sha256':upgrade['persisted_overrides_xml_sha256'],'old_configuration_xml_unchanged':True,
 'real_android_cross_process_preferences':True,'native_sip_response_calls':int(precondition['native_response_calls'])+sum(int(x.get('native_response_calls',0)) for x in prior.values()),
 'native_request_calls':int(prior['prior24.3-success'].get('native_request_calls',0)),
 'network_socket_calls':0,'physical_apdu_calls':0,'synthetic_apdu_calls':int(prior['prior24.0-switch']['total_synthetic_apdus']),
 'physical_phone_tested':False,'real_carrier_tested':False,'sms_sent':False,'calls_placed':False,'private_production_preferences_modified':False,
 'fatal_or_verification_errors':errors,'cold_start':cold.strip(),
 'instrumentation_apk_sha256':sha(test),
 'success_instrumentation_apk_sha256':sha(regressions['prior24.3-success'][0]),
 'terminal_instrumentation_apk_sha256':sha(regressions['prior24.2-terminal'][0]),
 'prior_sip_instrumentation_apk_sha256':sha(regressions['prior24.1-487'][0]),
 'switch_instrumentation_apk_sha256':sha(regressions['prior24.0-switch'][0]),
 'source_sha256':{p.name:sha(p) for p in (fixture/'config-harness').iterdir() if p.suffix in ('.java','.py','.xml')},
 'driver_sha256':sha(Path(__file__)),
 'baseline_evidence':{str(p):sha(p) for p in [fixture/'upgrade24.3-seed.txt',fixture/'upgrade24.3-cold-read.txt',fixture/'precondition24.3-baseline.txt',fixture/'baseline-six-records/validation.json']},
 'limits':['Android11 API30 x86_64 software emulator; no physical phone or reader attached.',
  'Real preference data is synthetic and kept in isolated files; the four24.3-created records remain retained unchanged for audit. This is not a read of user configuration.',
  'SMS preparation tests invoke the actual helper with an inert captured-card object. They do not call o82.D or send an SMS; the native send hook is separately covered by host verification.',
  'The legacy zl5.j/ck5 store is temporarily redirected to a private test SharedPreferences object and restored. No production legacy preference key is written.',
  'SIP precondition test starts from explicitly constructed early dialogs, then executes real h, qa1, cb4.k and C. Initial f82 creation and Gm encryption are covered on host, not in this ART fixture.',
  'Native TCP stacks are empty and have no output callback. Intended SIP packets are inspected before native closed-session discard; no operator, radio, audio or call quality validation is claimed.',
  'The original SIP and dual-chip fixtures are rerun byte-for-byte; dual-chip transport remains synthetic.',
  'No new UI screenshots are required for these configuration/protocol changes.'],
 'logs_sha256':{p.name:sha(p) for p in root.glob('*.txt')},'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()
}
(release/'emulator-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(release/'emulator-validation.json',flush=True)
