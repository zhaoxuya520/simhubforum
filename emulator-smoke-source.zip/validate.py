"""Independent Android ART validation; execute only with the final signed APK/hash."""
from pathlib import Path
import argparse, subprocess, hashlib, re, json, datetime
parser=argparse.ArgumentParser()
parser.add_argument('--apk',type=Path,required=True)
parser.add_argument('--sha256',required=True)
args=parser.parse_args()
review=Path(__file__).resolve().parent
release=Path('/workspace/recovery/call24.2-release')
adb=['/workspace/tools/android-platform-tools/platform-tools/adb','-s','emulator-5580']
package='cc.forserein.simhub'
baseline='1727977e6ad2fe300b9218360be8363cf8169f6dffad7b98e87be58c2a4a56dd'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run(*command,timeout=120):
 result=subprocess.run([*adb,*map(str,command)],capture_output=True,text=True,timeout=timeout)
 result.check_returncode();return result.stdout+result.stderr
def write(name,value):
 (review/name).write_text(value);return value
def installed_hash():
 path=run('shell','pm','path',package).strip().split('package:')[-1]
 return run('shell','sha256sum',path).split()[0]
def certificate(apk,name):
 result=subprocess.run(['java','-jar','/workspace/tools/android-recovery/sdk/android-15/lib/apksigner.jar','verify','--verbose','--print-certs',str(apk)],capture_output=True,text=True,check=True)
 output=write(name,result.stdout+result.stderr)
 return re.search(r'certificate SHA-256 digest: (\w+)',output).group(1)
def art(name,apk,component):
 install=write(name+'-install.txt',run('install','--no-streaming','-r',apk,timeout=180))
 assert 'Success' in install
 output=write(name+'-art.txt',run('shell','am','instrument','-w',component,timeout=180))
 assert 'INSTRUMENTATION_RESULT: status=passed' in output and 'INSTRUMENTATION_CODE: 0' in output,output
 return output,int(re.search(r'checks=(\d+)',output).group(1))
assert digest(args.apk)==args.sha256
assert run('shell','getprop','sys.boot_completed').strip()=='1'
before=installed_hash();assert before==baseline,before
previous=write('baseline24.1-package.txt',run('shell','dumpsys','package',package))
assert 'versionName=24.1' in previous and 'versionCode=20 ' in previous
old_cert=certificate(Path('/workspace/recovery/call24.1-release/SIMHub-24.1-signed.apk'),'baseline24.1-signature.txt')
new_cert=certificate(args.apk,'final-signature.txt');assert new_cert==old_cert
run('shell','am','force-stop',package);run('logcat','-c')
install=write('install.txt',run('install','--no-streaming','-r',args.apk,timeout=300));assert 'Success' in install
print('Upgrade 24.1 -> 24.2 installation: Success',flush=True)
sip_apk=review/'harness/terminal-failure-instrumentation.apk'
sip,sip_checks=art('terminal-failure',sip_apk,'cc.forserein.simhub.terminalfailuresmoke/terminalfailuresmoke.TerminalFailureSmoke')
print('Extended actual SIP ART checks:',sip_checks,flush=True)
prior_sip_apk=review/'baseline24.1/sip-failure-instrumentation.apk'
prior_sip,prior_sip_checks=art('prior487-regression',prior_sip_apk,'cc.forserein.simhub.sipfailuresmoke/sipfailuresmoke.SipFailureSmoke')
print('Preserved 24.1 SIP 487 ART checks:',prior_sip_checks,flush=True)
switch_apk=Path('/workspace/recovery/switch24.0-review/emulator/harness/switch-instrumentation.apk')
switch,switch_checks=art('switch-regression',switch_apk,'cc.forserein.simhub.switchsmoke/switchsmoke.SwitchSmoke')
print('Actual dual-chip regression checks:',switch_checks,flush=True)
run('shell','am','force-stop',package)
cold=write('cold-start.txt',run('shell','am','start','-W','-n',package+'/.MainActivity'))
assert 'Status: ok' in cold and 'LaunchState: COLD' in cold
info=write('package.txt',run('shell','dumpsys','package',package))
assert 'versionName=24.2' in info and 'versionCode=21 ' in info
installed=installed_hash();assert installed==args.sha256
write('installed-apk-sha256.txt',installed+'\n')
logs=write('final-logcat.txt',run('logcat','-d','-v','threadtime',timeout=45))
errors=[line for line in logs.splitlines() if re.search(r'FATAL EXCEPTION|VerifyError|Verification failed|NoSuchMethodError|NoClassDefFoundError|ANR in cc\.forserein\.simhub',line)]
assert not errors,errors
write('app-error-summary.txt','No app fatal, ART verification/linkage failure or SIMHub ANR in captured logs.\n')
def fields(output):
 return dict(re.findall(r'^INSTRUMENTATION_RESULT: (\w+)=(.*)$',output,re.M))
result={
 'status':'passed','version_name':'24.2','version_code':21,
 'upgrade_from_sha256':before,'apk_sha256':args.sha256,'installed_apk_sha256':installed,
 'install_upgrade_verified':True,'signature_unchanged':True,'signer_certificate_sha256':new_cert,
 'main_activity_start':True,'art_execution':True,'offline_art_checks':sip_checks+prior_sip_checks+switch_checks,
 'sip_art_checks':sip_checks+prior_sip_checks,'extended_sip_art_checks':sip_checks,'prior_sip_regression_checks':prior_sip_checks,'switch_regression_checks':switch_checks,
 'sip_results':fields(sip),'prior_sip_results':fields(prior_sip),'switch_results':fields(switch),
 'transport_helper_calls':int(fields(sip)['transport_helper_calls']),'native_response_calls':int(fields(sip)['native_response_calls'])+int(fields(prior_sip)['native_response_calls']),'network_socket_calls':int(fields(sip)['network_socket_calls']),
 'physical_apdu_calls':int(fields(switch)['physical_apdu_calls']),'synthetic_apdu_calls':int(fields(switch)['total_synthetic_apdus']),
 'native_switch_calls':int(fields(switch)['native_switch_calls']),
 'baseline_bug_reproduced_on_actual_art':True,'baseline_evidence':'baseline24.1-terminal-art.txt','baseline_provisional_evidence':['baseline24.1-late180-art.txt','baseline24.1-late183-art.txt','baseline24.1-reliable-art.txt'],
 'fatal_or_verification_errors':errors,'synthetic_sim':True,'real_carrier_tested':False,
 'physical_phone_tested':False,'physical_card_mutated':False,'calls_sent':False,
 'scope':'Actual final APK o82.h/C response processing and native SIP builders on ART with empty native TCP connection state. Existing dual-chip native regression uses synthetic transport. No actual socket, SIM, media, real phone number or network registration.',
 'limits':['No physical phone or reader is attached; emulator-5580 uses Android 11 API30 x86_64 software acceleration.','SIP ACK/PRACK intent is inspected before native discard for missing TCP connection; no carrier delivery, server behavior, call audio or radio operation is validated.','Fallback ART directly invokes SipInviteTransport on native dialogs and ka4/ja4 objects constructed in the verified f82 initial TCP shape; it does not execute f82 initialization, a82 failure dispatch or transmit on UDP.','Synthetic dual-chip regression verifies application control flow, not physical eUICC firmware or modem refresh.','The call-UI event callback is disconnected; ART validates native cancellation reason, packets and dialog state, not full UI event delivery.','No screenshots or media tests were repeated.'],
 'sources':{p.name:digest(p) for p in (review/'harness').glob('*') if p.suffix in ('.java','.py','.xml')},
 'driver_sha256':digest(Path(__file__)),'instrumentation_apk_sha256':digest(sip_apk),
 'switch_instrumentation_apk_sha256':digest(switch_apk),'prior_sip_instrumentation_apk_sha256':digest(prior_sip_apk),
 'logs':{p.name:digest(p) for p in review.glob('*.txt')},
 'cold_start':cold.strip(),'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()
}
(release/'emulator-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Emulator validation report:',release/'emulator-validation.json',flush=True)
