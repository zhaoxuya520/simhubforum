"""Run only after the parent supplies the final signed APK/hash. No production edits."""
from pathlib import Path
import argparse, subprocess, hashlib, re, json, datetime

parser=argparse.ArgumentParser()
parser.add_argument('--apk',type=Path,required=True)
parser.add_argument('--sha256',required=True)
args=parser.parse_args()
review=Path(__file__).resolve().parent
release=Path('/workspace/recovery/aka23.9-release')
adb=['/workspace/tools/android-platform-tools/platform-tools/adb','-s','emulator-5580']
package='cc.forserein.simhub'
baseline='1258e3c7b7f69cadd7d97932dae72fdb0f40caf202178c6d345c0a703cf93647'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run(*command,timeout=120):
    result=subprocess.run([*adb,*map(str,command)],capture_output=True,text=True,timeout=timeout)
    result.check_returncode()
    return result.stdout+result.stderr
def write(name,value):
    (review/name).write_text(value)
    return value
def installed_hash():
    path=run('shell','pm','path',package).strip().split('package:')[-1]
    return run('shell','sha256sum',path).split()[0]
def certificate(apk,name):
    result=subprocess.run(['java','-jar','/workspace/tools/android-recovery/sdk/android-15/lib/apksigner.jar','verify','--verbose','--print-certs',str(apk)],capture_output=True,text=True,check=True)
    output=write(name,result.stdout+result.stderr)
    return re.search(r'certificate SHA-256 digest: (\w+)',output).group(1)

assert digest(args.apk)==args.sha256
before=installed_hash()
assert before==baseline,before
previous=run('shell','dumpsys','package',package)
assert 'versionName=23.8' in previous and 'versionCode=17 ' in previous
write('baseline23.8-package.txt',previous)
old_cert=certificate(Path('/workspace/recovery/eap23.8-release/SIMHub-23.8-signed.apk'),'baseline23.8-signature.txt')
new_cert=certificate(args.apk,'final-signature.txt')
assert new_cert==old_cert
run('shell','am','force-stop',package)
run('logcat','-c')
install=write('install.txt',run('install','--no-streaming','-r',args.apk,timeout=300))
assert 'Success' in install
print('Upgrade 23.8 -> 23.9 installation: Success',flush=True)
harness=review/'harness/aka-instrumentation.apk'
install=write('harness-install.txt',run('install','--no-streaming','-r',harness,timeout=180))
assert 'Success' in install
art=write('aka-art.txt',run('shell','am','instrument','-w','cc.forserein.simhub.akasmoke/akasmoke.AkaSmoke',timeout=180))
assert 'INSTRUMENTATION_RESULT: status=passed' in art and 'INSTRUMENTATION_CODE: 0' in art and 'apdu_calls=0' in art,art
checks=int(re.search(r'checks=(\d+)',art).group(1))
print('Actual native AKA ART checks:',checks,flush=True)
run('shell','am','force-stop',package)
cold=write('cold-start.txt',run('shell','am','start','-W','-n',package+'/.MainActivity'))
assert 'Status: ok' in cold and 'LaunchState: COLD' in cold
info=write('package.txt',run('shell','dumpsys','package',package))
assert 'versionName=23.9' in info and 'versionCode=18 ' in info
installed=installed_hash()
assert installed==args.sha256
write('installed-apk-sha256.txt',installed+'\n')
logs=write('final-logcat.txt',run('logcat','-d','-v','threadtime',timeout=45))
errors=[line for line in logs.splitlines() if re.search(r'FATAL EXCEPTION|VerifyError|Verification failed|NoSuchMethodError|NoClassDefFoundError|ANR in cc\.forserein\.simhub',line)]
assert not errors,errors
write('app-error-summary.txt','No app fatal, ART verification/linkage failure or SIMHub ANR in captured logs.\n')
result={
 'status':'passed','version_name':'23.9','version_code':18,
 'upgrade_from_sha256':before,'apk_sha256':args.sha256,'installed_apk_sha256':installed,
 'install_upgrade_verified':True,'signature_unchanged':True,'signer_certificate_sha256':new_cert,
 'main_activity_start':True,'art_execution':True,'offline_art_checks':checks,
 'fatal_or_verification_errors':errors,'synthetic_sim':True,'real_carrier_tested':False,
 'physical_phone_tested':False,'calls_sent':False,'apdu_calls':0,
 'native_at_permanent_id_req_tested':True,'native_at_any_id_req_tested':True,
 'scope':'Actual final APK da1.b normal AKA Identity requests and z91 responses on Android ART. Exact original response bytes and da1.e transcript bytes checked across ordinary retransmissions, new requests and independent native sessions. No socket, APDU, challenge or live carrier operation.',
 'verified':[
  'First actual AT_PERMANENT_ID_REQ records one exact request/response transcript pair',
  'Three consecutive identical requests return the original response without appending transcript',
  'Caller mutation of previously returned response or supplied request cannot contaminate the saved response/key',
  'Normal lower-layer bytes beyond declared EAP Length do not create another identity exchange',
  'New identifier and same identifier with a new valid AT_ANY_ID_REQ attribute use the native path and append their exact transcript pair',
  'An older request after a newer exchange is processed natively again; only the latest request is replayed',
  'Two fresh native da1 sessions with different synthetic permanent identities keep responses and transcripts isolated',
  'Resetting the real ByteArrayOutputStream simulates native cleanup and invalidates the previous replay entry'],
 'normal_synthetic_request_type':23,'native_identity_calls':int(re.search(r'native_identity_calls=(\d+)',art).group(1)),
 'global_app_state_or_preferences_modified':False,
 'transcript_reset_is_explicit_fixture':True,
 'limits':[
  'Tests use normal synthetic AKA Identity requests only; no EAP challenge/key derivation, SIM authentication, IKE/IMS registration, real call or audio is attempted.',
  'The lifecycle case directly resets the real native transcript buffer; it does not run a full network-session shutdown.',
  'No physical phone is attached; emulator-5580 is Android 11 API30 x86_64 with software acceleration.',
  'No UI layout changed in this task, so no screenshots or visual regression tests were repeated.'],
 'sources':{p.name:digest(p) for p in (review/'harness').glob('*') if p.suffix in ('.java','.py','.xml')},
 'driver_sha256':digest(Path(__file__)),'instrumentation_apk_sha256':digest(harness),
 'logs':{p.name:digest(p) for p in review.glob('*.txt')},
 'cold_start':cold.strip(),'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()
}
(release/'emulator-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Emulator validation report:',release/'emulator-validation.json',flush=True)
