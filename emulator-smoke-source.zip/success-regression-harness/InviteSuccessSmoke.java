package invitesuccesssmoke;
import android.app.Instrumentation;
import android.os.Bundle;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** Actual installed o82.h/C execution with an empty native in-memory TCP connection map. */
@SuppressWarnings({"rawtypes","unchecked"})
public final class InviteSuccessSmoke extends Instrumentation {
 private String scenario="all";private ClassLoader loader;private int checks,nativeCalls,requestCalls,logCalls,transportHelperCalls;private final ArrayList<String> completed=new ArrayList<>(),actionTrace=new ArrayList<>();
 private final String ID="art-sip-failure@example.invalid",BRANCH="z9hG4bK-art-invite-11";
 private final String SDP="v=0\r\no=- 1 1 IN IP4 192.0.2.10\r\ns=synthetic\r\nc=IN IP4 192.0.2.10\r\nt=0 0\r\nm=audio 10000 RTP/AVP 116\r\na=rtpmap:116 AMR-WB/16000\r\na=fmtp:116 octet-align=1\r\na=sendrecv\r\n";
 private Class<?> type(String name)throws Exception{return Class.forName(name,true,loader);}
 private Object get(Object o,String name)throws Exception{Field f=o.getClass().getField(name);f.setAccessible(true);return f.get(o);}
 private void set(Object o,String name,Object value)throws Exception{Field f=o.getClass().getField(name);f.setAccessible(true);f.set(o,value);}
 private Object stat(String c,String f)throws Exception{return type(c).getField(f).get(null);}
 private Object raw(String name)throws Exception{Class<?> u=Class.forName("sun.misc.Unsafe");Field f=u.getDeclaredField("theUnsafe");f.setAccessible(true);return u.getMethod("allocateInstance",Class.class).invoke(f.get(null),type(name));}
 private void check(boolean yes,String label){if(!yes)throw new AssertionError(label);checks++;}
 private Object message(boolean request,String method,int status,String body)throws Exception{return type("kb4").getConstructor(boolean.class,String.class,String.class,int.class,String.class,ArrayList.class,byte[].class).newInstance(request,method,"sip:peer@example.invalid",status,request?"":status==487?"Request Terminated":"OK",new ArrayList<>(),body.getBytes(StandardCharsets.US_ASCII));}
 private void header(Object p,String name,String value)throws Exception{type("kb4").getMethod("a",String.class,String.class).invoke(p,name,value);}
 private String first(Object p,String name)throws Exception{List list=(List)type("kb4").getMethod("j",String.class).invoke(p,name);return list.isEmpty()?null:(String)list.get(0);}
 private Object response(int code,int seq,String method,String tag,String branch)throws Exception{
  Object p=message(false,method,code,code==200&&method.equals("INVITE")?SDP:"");header(p,"Call-ID",ID);header(p,"CSeq",seq+" "+method);
  header(p,"From","<sip:local@example.invalid>;tag=local-tag");header(p,"To","<sip:peer@example.invalid>;tag="+tag);
  header(p,"Via","SIP/2.0/TCP 192.0.2.1:5060;branch="+branch);if(code==200&&method.equals("INVITE")){header(p,"Contact","<sip:A@example.invalid>");header(p,"Content-Type","application/sdp");}return p;
 }
 private final class Session {
  Object dialog,manager,engine,stack;
  Session()throws Exception{
   Object invite=message(true,"INVITE",0,"synthetic offer");header(invite,"Via","SIP/2.0/TCP 192.0.2.1:5060;branch="+BRANCH);
   header(invite,"From","<sip:local@example.invalid>;tag=local-tag");header(invite,"To","<sip:peer@example.invalid>");header(invite,"Call-ID",ID);header(invite,"CSeq","11 INVITE");header(invite,"Route","<sip:route.example.invalid;lr>");
   dialog=type("ma4").getConstructors()[0].newInstance(stat("ga4","U"),ID,stat("la4","T"),"local-tag","sip:local@example.invalid","sip:peer@example.invalid","sip:peer@example.invalid",11,11,invite,0.0);
   Object config=type("ra4").getConstructors()[0].newInstance("192.0.2.1",5060,"sip:local@example.invalid","urn:uuid:art-failure","sip:local@example.invalid","probe",new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),true,false);
   manager=type("cb4").getConstructors()[0].newInstance(config,null,null,null);((Map)get(manager,"e")).put(ID,dialog);
   engine=raw("o82");set(engine,"J",manager);set(engine,"V",new ArrayList<>());
   Object card=type("ek5").getConstructor(String.class,String.class,int.class,String.class,String.class,String.class,String.class,type("z82")).newInstance("","",2,"","",null,null,null);set(engine,"c",card);set(engine,"b",raw("xi5"));
   Object logger=Proxy.newProxyInstance(loader,new Class<?>[]{type("ws1")},(o,m,a)->{if(m.getName().equals("i")){logCalls++;return stat("sc5","a");}if(m.getName().equals("toString"))return "Synthetic SIP log sink";throw new AssertionError(m.toString());});
   set(engine,"g",type("g11").getConstructor(int.class,Object.class,Object.class).newInstance(13,engine,logger));
   stack=type("jf2").getConstructor(byte[].class).newInstance((Object)new byte[]{127,0,0,1});set(engine,"R",stack);set(engine,"T",Integer.valueOf(1));set(engine,"U",false);
  }
  boolean accept(Object response)throws Exception{nativeCalls++;try{return(Boolean)type("o82").getMethod("h",type("kb4")).invoke(engine,response);}catch(InvocationTargetException e){Throwable t=e.getCause();if(t instanceof Exception)throw(Exception)t;throw(Error)t;}}
  List packets()throws Exception{return(List)get(engine,"V");}
  boolean present()throws Exception{return((Map)get(manager,"e")).get(ID)==dialog;}
  void selected()throws Exception{check(accept(response(200,11,"INVITE","A",BRANCH)),"actual 200 response accepted");check(get(dialog,"D")!=null&&"A".equals(get(dialog,"l")),"actual native selected dialog confirmed");packets().clear();}
  void offline()throws Exception{check(((Map)get(stack,"j")).isEmpty()&&((Map)get(stack,"k")).isEmpty(),"native TCP stack has no connections or remote endpoint");check(get(stack,"c")==null,"native packet-output callback remains absent");}
 }
 private void ack(Object p,int cseq)throws Exception{check("ACK".equals(get(p,"b")),"native output packet is ACK");check((cseq+" ACK").equals(first(p,"CSeq")),"ACK preserves transaction CSeq");check(ID.equals(first(p,"Call-ID")),"ACK preserves Call-ID");check(first(p,"Via").contains(BRANCH),"ACK preserves original INVITE branch");}
 private byte[] wire(Object packet)throws Exception{return(byte[])type("kb4").getMethod("b").invoke(packet);}
 private String deep(Object value)throws Exception{
  if(value==null)return "null";if(value instanceof byte[])return Arrays.toString((byte[])value);
  if(value instanceof List){StringBuilder b=new StringBuilder("[");for(Object x:(List)value)b.append(deep(x)).append(';');return b+"]";}
  if(value instanceof Map)return ((Map)value).toString();
  if(value.getClass()==type("kb4")){StringBuilder b=new StringBuilder();for(Field f:value.getClass().getFields())if(!Modifier.isStatic(f.getModifiers()))b.append(f.getName()).append(':').append(deep(f.get(value))).append(';');return b.toString();}
  return value.toString();
 }
 private Map<String,String> snapshot(Object value)throws Exception{Map<String,String> values=new TreeMap<>();for(Field f:value.getClass().getFields())if(!Modifier.isStatic(f.getModifiers()))values.put(f.getName(),deep(f.get(value)));return values;}
 private String actions(Session s)throws Exception{List<String> out=new ArrayList<>();for(Object p:s.packets())out.add(((Boolean)get(p,"a")?get(p,"b"):"response-"+get(p,"d"))+"/"+first(p,"CSeq"));return out.toString();}
 private List<String> changed(Map<String,String> before,Object dialog)throws Exception{Map<String,String> after=snapshot(dialog);List<String> names=new ArrayList<>();for(String key:before.keySet())if(!Objects.equals(before.get(key),after.get(key)))names.add(key);return names;}
 private void dispatch(Session s,List actions)throws Exception{type("o82").getMethod("k",List.class).invoke(s.engine,actions);}
 private Object accepted()throws Exception{Object r=response(200,11,"INVITE","A",BRANCH);header(r,"Record-Route","<sip:chosen-route.example.invalid;lr>");return r;}
 private Session cancelled()throws Exception{
  Session s=new Session();check(s.accept(response(180,11,"INVITE","A",BRANCH)),"actual180 accepted before local cancellation");
  List actions=(List)type("cb4").getMethod("j",String.class,double.class).invoke(s.manager,ID,12.0);dispatch(s,actions);
  check(get(s.dialog,"c")==stat("la4","X")&&s.packets().size()==1&&"CANCEL".equals(get(s.packets().get(0),"b")),"actual cancellation emits CANCEL and enters terminating state");
  s.packets().clear();check(s.accept(response(200,11,"CANCEL","A",BRANCH)),"CANCEL200 handled");check(s.present(),"CANCEL200 does not prematurely remove pending INVITE");s.packets().clear();return s;
 }
 private Object responseTo(Object request)throws Exception{
  Object r=message(false,(String)get(request,"b"),200,"");for(String name:new String[]{"Via","From","To","Call-ID","CSeq"})for(Object value:(List)type("kb4").getMethod("j",String.class).invoke(request,name))header(r,name,(String)value);return r;
 }
 private Object[] firstLate200(Session s,Object success)throws Exception{
  check(s.accept(success),"first200 after local CANCEL handled");actionTrace.add("first-after-CANCEL actions="+actions(s));check(s.packets().size()==2,"first200 after CANCEL emits exactly ACK then BYE");Object a=s.packets().get(0),b=s.packets().get(1);
  check("ACK".equals(get(a,"b"))&&"BYE".equals(get(b,"b")),"native late success sends ACK then cleanup BYE");check("11 ACK".equals(first(a,"CSeq")),"cleanup ACK preserves INVITE sequence");check(get(s.dialog,"c")==stat("la4","X"),"late success remains terminating");return new Object[]{a,b};
 }
 private void repeatedAfterCancel(boolean afterBye)throws Exception{
  Session s=cancelled();Object success=accepted();Object[] sent=firstLate200(s,success);byte[] ackBytes=wire(sent[0]);s.packets().clear();
  if(afterBye){check(s.accept(responseTo(sent[1])),"cleanupBYE200 handled");check(!s.present(),"cleanupBYE200 removes the dialog");s.packets().clear();}
  Map<String,String> before=snapshot(s.dialog);boolean handled=s.accept(success);actionTrace.add("repeat-after-"+(afterBye?"BYE":"CANCEL")+" handled="+handled+" actions="+actions(s)+" changedFields="+changed(before,s.dialog)+" member="+s.present());
  check(handled&&s.packets().size()==1,"repeated200 "+(afterBye?"after BYE":"after CANCEL")+" emits exactly cached ACK, without another BYE");check("ACK".equals(get(s.packets().get(0),"b"))&&Arrays.equals(ackBytes,wire(s.packets().get(0))),"retransmitted successful INVITE gets byte-identical ACK");
  check(before.equals(snapshot(s.dialog)),"repeated200 cannot change completed or terminating dialog fields");check(s.present()!=afterBye,"repeated200 preserves dialog membership without resurrection");s.offline();completed.add(afterBye?"cancelled-200-retransmit-after-BYE-removal":"cancelled-200-retransmit-before-BYE");
 }
 private void normal200()throws Exception{
  Session s=new Session();Object success=accepted();check(s.accept(success),"normal initial200 handled");check(s.present()&&get(s.dialog,"D")!=null&&s.packets().size()==1,"normal initial200 confirms and ACKs");byte[] ackBytes=wire(s.packets().get(0));s.packets().clear();Map<String,String> before=snapshot(s.dialog);
  check(s.accept(success),"normal identical200 retransmission handled");actionTrace.add("normal-repeat actions="+actions(s)+" changedFields="+changed(before,s.dialog)+" sameACK="+(s.packets().size()==1&&Arrays.equals(ackBytes,wire(s.packets().get(0)))));check(s.packets().size()==1&&"ACK".equals(get(s.packets().get(0),"b")),"normal200 retransmission sends only ACK");check(Arrays.equals(ackBytes,wire(s.packets().get(0))),"normal200 retransmission repeats original ACK bytes");check(before.equals(snapshot(s.dialog)),"normal200 retransmission preserves all selected dialog fields");s.offline();completed.add("normal-confirmed200-retransmission");
 }
 private void terminatingActions()throws Exception{
  Session s=cancelled();Map<String,String> before=snapshot(s.dialog);
  List again=(List)type("cb4").getMethod("j",String.class,double.class).invoke(s.manager,ID,13.0);
  check(again.isEmpty()&&before.equals(snapshot(s.dialog)),"repeat local hangup while terminating produces no action or state change");
  again=(List)type("cb4").getMethod("g",String.class,double.class).invoke(s.manager,ID,14.0);
  check(again.isEmpty()&&before.equals(snapshot(s.dialog)),"local decline on terminating dialog produces no action or state change");
  check(s.packets().isEmpty(),"terminating local operations emit no SIP packets");s.offline();completed.add("native-local-g-j-noop-after-terminating");
 }
 private final class Incoming {
  final Session session;final String id="art-incoming@example.invalid",branch="z9hG4bK-incoming-original";final String initial;
  Incoming()throws Exception{
   session=new Session();((Map)get(session.manager,"e")).clear();set(session.engine,"y",new LinkedHashMap<>());set(session.engine,"K",raw("ls4"));
   Object ip=type("x82").getConstructor(byte[].class).newInstance((Object)new byte[]{(byte)192,0,2,1});
   Object answer=type("pu").getConstructor(Object.class,int.class,Object.class,int.class).newInstance(ip,45000,stat("vk","c"),11);set(session.manager,"b",answer);
   initial=request("INVITE",id,10,null,branch,SDP);
  }
  String request(String method,String callId,int seq,String tag,String viaBranch,String body){return method+" sip:local@example.invalid SIP/2.0\r\nVia: SIP/2.0/TCP 192.0.2.10:5060;branch="+viaBranch+";rport\r\nFrom: <sip:peer@example.invalid>;tag=remote-tag\r\nTo: <sip:local@example.invalid>"+(tag==null?"":";tag="+tag)+"\r\nCall-ID: "+callId+"\r\nCSeq: "+seq+" "+method+"\r\nContact: <sip:peer@192.0.2.10:5060>\r\nContent-Type: application/sdp\r\nContent-Length: "+body.length()+"\r\n\r\n"+body;}
  void receive(String wire)throws Exception{
   Object packet=type("jb4").getMethod("c",byte[].class).invoke(null,(Object)wire.getBytes(StandardCharsets.US_ASCII));requestCalls++;
   try{type("o82").getMethod("r",type("kb4"),type("oc2"),String.class).invoke(session.engine,packet,null,"offline TCP fixture");}catch(InvocationTargetException e){Throwable t=e.getCause();if(t instanceof Exception)throw(Exception)t;throw(Error)t;}
  }
  Object dialog(String callId)throws Exception{return((Map)get(session.manager,"e")).get(callId);}
  int status()throws Exception{List packets=session.packets();return packets.isEmpty()?-1:(Integer)get(packets.get(packets.size()-1),"d");}
  void decline()throws Exception{Object task=type("f82").getConstructor(type("o82"),String.class,type("ct0"),int.class).newInstance(session.engine,id,null,2);type("f82").getMethod("q",Object.class).invoke(task,stat("sc5","a"));}
 }
 private void rejectedIncoming(boolean remoteCancel)throws Exception{
  Incoming in=new Incoming();in.receive(in.initial);Object original=in.dialog(in.id);check(original!=null&&in.status()==180,"actual initial incoming INVITE produces pending dialog and180");String tag=(String)get(original,"d");
  if(remoteCancel)in.receive(in.request("CANCEL",in.id,10,null,in.branch,""));else in.decline();int expected=remoteCancel?487:603;
  check(in.status()==expected,"actual incoming termination produces expected final response "+expected);
  in.receive(in.request("ACK",in.id,10,tag,in.branch,""));check(in.dialog(in.id)==null,"matching final ACK removes terminated incoming dialog");in.session.packets().clear();Map<String,String> before=snapshot(original);
  in.receive(in.initial);actionTrace.add("incoming-repeat-final"+expected+" actions="+actions(in.session)+" lastStatus="+in.status()+" newDialog="+(in.dialog(in.id)!=null));
  check(in.dialog(in.id)==null&&in.session.packets().size()==1&&in.status()==expected,"delayed duplicate initial INVITE replays final without rebuilding/ringing incoming dialog "+expected);check(before.equals(snapshot(original)),"cached incoming rejection leaves retired dialog untouched");in.session.packets().clear();
  String nextId=remoteCancel?"art-new-incoming@example.invalid":in.id;int nextSequence=remoteCancel?10:11;
  in.receive(in.request("INVITE",nextId,nextSequence,null,"z9hG4bK-incoming-new",SDP));check(in.dialog(nextId)!=null&&in.status()==180,"new Call-ID or newer INVITE sequence is allowed after old rejection");in.session.offline();completed.add(remoteCancel?"incoming-CANCEL487-ACK-retransmission-and-new-CallID":"incoming-decline603-ACK-retransmission-and-new-CSeq");
 }
 private void cases()throws Exception{
  for(String c:new String[]{"o82","cb4","kb4","ma4","jf2"}){type(c).getDeclaredMethods();checks++;}
  if(scenario.equals("afterbye")){repeatedAfterCancel(true);return;}
  if(scenario.equals("normal")){normal200();return;}
  if(scenario.equals("local")){terminatingActions();return;}
  if(scenario.equals("incoming-decline")){rejectedIncoming(false);return;}
  if(scenario.equals("incoming-cancel")){rejectedIncoming(true);return;}
  repeatedAfterCancel(false);repeatedAfterCancel(true);normal200();terminatingActions();rejectedIncoming(false);rejectedIncoming(true);
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);if(args!=null&&args.getString("case")!=null)scenario=args.getString("case");start();}
 @Override public void onStart(){Bundle b=new Bundle();Throwable failure=null;try{runOnMainSync(()->{});loader=getTargetContext().getClassLoader();cases();}catch(Throwable t){failure=t;}
  b.putInt("checks",checks);b.putInt("native_response_calls",nativeCalls);b.putInt("native_request_calls",requestCalls);b.putInt("native_log_calls",logCalls);b.putInt("transport_helper_calls",transportHelperCalls);b.putInt("network_socket_calls",0);b.putStringArrayList("completed_cases",completed);b.putStringArrayList("action_trace",actionTrace);
  b.putString("scope","Actual installed o82.h/r/C, cb4 controls, f82 decline and native SIP parsing/builders execute on Android ART. Native TCP stack has no connection and no packet-output callback; intended ACKs are inspected in native V before closed-session discard. No socket, APDU, SIM, media or real number is used.");
  if(failure==null){b.putString("status","passed");finish(0,b);}else{b.putString("status","failed");b.putString("error",android.util.Log.getStackTraceString(failure));finish(1,b);}
 }
}
