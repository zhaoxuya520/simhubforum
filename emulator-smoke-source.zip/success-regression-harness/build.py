from pathlib import Path
import subprocess,zipfile
r=Path(__file__).parent;t=Path('/workspace/tools/android-recovery');sdk=t/'sdk/android-35/android.jar';classes=r/'classes';classes.mkdir(exist_ok=True);dex=r/'dex';dex.mkdir(exist_ok=True)
def run(*args):subprocess.run(list(map(str,args)),check=True)
run('java','-jar',t/'ecj-3.40.0.jar','-8','-cp',sdk,'-d',classes,r/'InviteSuccessSmoke.java')
with zipfile.ZipFile(r/'classes.jar','w')as z:
 for p in classes.rglob('*.class'):z.write(p,p.relative_to(classes))
run('java','-cp',t/'sdk/android-15/lib/d8.jar','com.android.tools.r8.D8','--min-api','26','--lib',sdk,'--output',dex,r/'classes.jar')
run(t/'sdk/android-15/aapt2','link','-o',r/'unsigned.apk','--manifest',r/'AndroidManifest.xml','-I',sdk)
with zipfile.ZipFile(r/'unsigned.apk','a')as z:z.write(dex/'classes.dex','classes.dex')
run('java','-jar',t/'sdk/android-15/lib/apksigner.jar','sign','--ks','/workspace/simhub-signing/simhub-longterm-2026.p12','--ks-key-alias','simhub-longterm','--ks-pass','file:/workspace/simhub-signing/simhub-longterm-password','--out',r/'invite-success-instrumentation.apk',r/'unsigned.apk')
