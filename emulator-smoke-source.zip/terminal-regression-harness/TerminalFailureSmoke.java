package terminalfailuresmoke;
import android.app.Instrumentation;
import android.os.Bundle;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** Actual installed o82.h/C execution with an empty native in-memory TCP connection map. */
@SuppressWarnings({"rawtypes","unchecked"})
public final class TerminalFailureSmoke extends Instrumentation {
 private String scenario="all";private ClassLoader loader;private int checks,nativeCalls,logCalls,transportHelperCalls;private final ArrayList<String> completed=new ArrayList<>();
 private final String ID="art-sip-failure@example.invalid",BRANCH="z9hG4bK-art-invite-11";
 private final String SDP="v=0\r\no=- 1 1 IN IP4 192.0.2.10\r\ns=synthetic\r\nc=IN IP4 192.0.2.10\r\nt=0 0\r\nm=audio 10000 RTP/AVP 116\r\na=rtpmap:116 AMR-WB/16000\r\na=fmtp:116 octet-align=1\r\na=sendrecv\r\n";
 private Class<?> type(String name)throws Exception{return Class.forName(name,true,loader);}
 private Object get(Object o,String name)throws Exception{Field f=o.getClass().getField(name);f.setAccessible(true);return f.get(o);}
 private void set(Object o,String name,Object value)throws Exception{Field f=o.getClass().getField(name);f.setAccessible(true);f.set(o,value);}
 private Object stat(String c,String f)throws Exception{return type(c).getField(f).get(null);}
 private Object raw(String name)throws Exception{Class<?> u=Class.forName("sun.misc.Unsafe");Field f=u.getDeclaredField("theUnsafe");f.setAccessible(true);return u.getMethod("allocateInstance",Class.class).invoke(f.get(null),type(name));}
 private void check(boolean yes,String label){if(!yes)throw new AssertionError(label);checks++;}
 private Object message(boolean request,String method,int status,String body)throws Exception{return type("kb4").getConstructor(boolean.class,String.class,String.class,int.class,String.class,ArrayList.class,byte[].class).newInstance(request,method,"sip:peer@example.invalid",status,request?"":status==487?"Request Terminated":"OK",new ArrayList<>(),body.getBytes(StandardCharsets.US_ASCII));}
 private void header(Object p,String name,String value)throws Exception{type("kb4").getMethod("a",String.class,String.class).invoke(p,name,value);}
 private String first(Object p,String name)throws Exception{List list=(List)type("kb4").getMethod("j",String.class).invoke(p,name);return list.isEmpty()?null:(String)list.get(0);}
 private Object response(int code,int seq,String method,String tag,String branch)throws Exception{
  Object p=message(false,method,code,code==200&&method.equals("INVITE")?SDP:"");header(p,"Call-ID",ID);header(p,"CSeq",seq+" "+method);
  header(p,"From","<sip:local@example.invalid>;tag=local-tag");header(p,"To","<sip:peer@example.invalid>;tag="+tag);
  header(p,"Via","SIP/2.0/TCP 192.0.2.1:5060;branch="+branch);if(code==200&&method.equals("INVITE")){header(p,"Contact","<sip:A@example.invalid>");header(p,"Content-Type","application/sdp");}return p;
 }
 private final class Session {
  Object dialog,manager,engine,stack;
  Session()throws Exception{
   Object invite=message(true,"INVITE",0,"synthetic offer");header(invite,"Via","SIP/2.0/TCP 192.0.2.1:5060;branch="+BRANCH);
   header(invite,"From","<sip:local@example.invalid>;tag=local-tag");header(invite,"To","<sip:peer@example.invalid>");header(invite,"Call-ID",ID);header(invite,"CSeq","11 INVITE");header(invite,"Route","<sip:route.example.invalid;lr>");
   dialog=type("ma4").getConstructors()[0].newInstance(stat("ga4","U"),ID,stat("la4","T"),"local-tag","sip:local@example.invalid","sip:peer@example.invalid","sip:peer@example.invalid",11,11,invite,0.0);
   Object config=type("ra4").getConstructors()[0].newInstance("192.0.2.1",5060,"sip:local@example.invalid","urn:uuid:art-failure","sip:local@example.invalid","probe",new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),true,false);
   manager=type("cb4").getConstructors()[0].newInstance(config,null,null,null);((Map)get(manager,"e")).put(ID,dialog);
   engine=raw("o82");set(engine,"J",manager);set(engine,"V",new ArrayList<>());
   Object card=type("ek5").getConstructor(String.class,String.class,int.class,String.class,String.class,String.class,String.class,type("z82")).newInstance("","",2,"","",null,null,null);set(engine,"c",card);set(engine,"b",raw("xi5"));
   Object logger=Proxy.newProxyInstance(loader,new Class<?>[]{type("ws1")},(o,m,a)->{if(m.getName().equals("i")){logCalls++;return stat("sc5","a");}if(m.getName().equals("toString"))return "Synthetic SIP log sink";throw new AssertionError(m.toString());});
   set(engine,"g",type("g11").getConstructor(int.class,Object.class,Object.class).newInstance(13,engine,logger));
   stack=type("jf2").getConstructor(byte[].class).newInstance((Object)new byte[]{127,0,0,1});set(engine,"R",stack);set(engine,"T",Integer.valueOf(1));set(engine,"U",false);
  }
  boolean accept(Object response)throws Exception{nativeCalls++;try{return(Boolean)type("o82").getMethod("h",type("kb4")).invoke(engine,response);}catch(InvocationTargetException e){Throwable t=e.getCause();if(t instanceof Exception)throw(Exception)t;throw(Error)t;}}
  List packets()throws Exception{return(List)get(engine,"V");}
  boolean present()throws Exception{return((Map)get(manager,"e")).get(ID)==dialog;}
  void selected()throws Exception{check(accept(response(200,11,"INVITE","A",BRANCH)),"actual 200 response accepted");check(get(dialog,"D")!=null&&"A".equals(get(dialog,"l")),"actual native selected dialog confirmed");packets().clear();}
  void offline()throws Exception{check(((Map)get(stack,"j")).isEmpty()&&((Map)get(stack,"k")).isEmpty(),"native TCP stack has no connections or remote endpoint");check(get(stack,"c")==null,"native packet-output callback remains absent");}
 }
 private void ack(Object p,int cseq)throws Exception{check("ACK".equals(get(p,"b")),"native output packet is ACK");check((cseq+" ACK").equals(first(p,"CSeq")),"ACK preserves transaction CSeq");check(ID.equals(first(p,"Call-ID")),"ACK preserves Call-ID");check(first(p,"Via").contains(BRANCH),"ACK preserves original INVITE branch");}
 private byte[] wire(Object packet)throws Exception{return(byte[])type("kb4").getMethod("b").invoke(packet);}
 private void statusCases(int code)throws Exception{
  Session s=new Session();s.selected();Object state=get(s.dialog,"c"),confirmed=get(s.dialog,"D");byte[] media=((byte[])get(s.dialog,"p")).clone();
  check(s.accept(response(code,11,"INVITE","A",BRANCH)),"late terminal response consumed "+code);
  check(s.present(),"delayed original INVITE "+code+" must retain confirmed dialog");check(get(s.dialog,"c")==state&&Objects.equals(get(s.dialog,"D"),confirmed),"delayed final preserves confirmed state/time "+code);check(Arrays.equals(media,(byte[])get(s.dialog,"p")),"delayed final preserves media "+code);
  check(s.packets().size()==1,"confirmed late final receives one transaction ACK "+code);ack(s.packets().get(0),11);s.offline();completed.add("confirmed-dialog-survives-"+code);
  s=new Session();check(s.accept(response(code,11,"INVITE","A",BRANCH)),"matching pending terminal consumed "+code);check(!s.present(),"matching genuine pending failure ends dialog "+code);check(s.packets().size()==1,"genuine pending failure produces one ACK "+code);ack(s.packets().get(0),11);
  byte[] originalAck=wire(s.packets().get(0));s.packets().clear();check(s.accept(response(code,11,"INVITE","A",BRANCH)),"removed-dialog final retransmission consumed "+code);check(!s.present()&&s.packets().size()==1,"removed-dialog retransmission only generates cached ACK "+code);check(Arrays.equals(originalAck,wire(s.packets().get(0))),"duplicate final sends byte-identical ACK "+code);s.offline();completed.add("genuine-failure-and-duplicate-ACK-"+code);
  s=new Session();state=get(s.dialog,"c");check(s.accept(response(code,10,"INVITE","A",BRANCH)),"old CSeq response consumed "+code);check(s.present()&&get(s.dialog,"c")==state&&s.packets().isEmpty(),"old CSeq preserves current pending transaction "+code);
  check(s.accept(response(code,11,"INVITE","A","z9hG4bK-wrong-branch")),"wrong branch final consumed "+code);check(s.present()&&get(s.dialog,"c")==state&&s.packets().isEmpty(),"wrong branch preserves transaction without ACK "+code);s.offline();completed.add("stale-CSeq-and-branch-isolated-"+code);
 }
 private String deep(Object value)throws Exception{
  if(value==null)return "null";if(value instanceof byte[])return Arrays.toString((byte[])value);
  if(value instanceof List){StringBuilder b=new StringBuilder("[");for(Object x:(List)value)b.append(deep(x)).append(';');return b+"]";}
  if(value instanceof Map)return ((Map)value).toString();
  if(value.getClass()==type("kb4")){StringBuilder b=new StringBuilder();for(Field f:value.getClass().getFields())if(!Modifier.isStatic(f.getModifiers()))b.append(f.getName()).append(':').append(deep(f.get(value))).append(';');return b.toString();}
  return value.toString();
 }
 private Map<String,String> snapshot(Object value)throws Exception{Map<String,String> values=new TreeMap<>();for(Field f:value.getClass().getFields())if(!Modifier.isStatic(f.getModifiers()))values.put(f.getName(),deep(f.get(value)));return values;}
 private Object progress(int code,int rseq)throws Exception{
  Object p=message(false,"INVITE",code,code==183?SDP.replace("192.0.2.10","192.0.2.20").replace("10000","20000"):"");
  header(p,"Call-ID",ID);header(p,"CSeq","11 INVITE");header(p,"From","<sip:local@example.invalid>;tag=local-tag");header(p,"To","<sip:peer@example.invalid>;tag=A");header(p,"Via","SIP/2.0/TCP 192.0.2.1:5060;branch="+BRANCH);
  header(p,"Contact","<sip:late@example.invalid>");header(p,"Record-Route","<sip:late-route.example.invalid;lr>");
  if(code==183){header(p,"Content-Type","application/sdp");header(p,"Require","100rel");header(p,"RSeq",Integer.toString(rseq));}return p;
 }
 private void lateProgress(int code,boolean terminating)throws Exception{
  Session s=new Session();s.selected();if(terminating)set(s.dialog,"c",stat("la4","X"));Map<String,String> before=snapshot(s.dialog);
  check(s.accept(progress(code,1)),"post-200 provisional response consumed "+code);
  check(s.present(),"post-200 provisional retains confirmed dialog "+code);
  check(before.equals(snapshot(s.dialog)),"post-200 "+code+" must preserve all confirmed dialog fields, routes and media");
  check(s.packets().isEmpty(),"post-200 "+code+" must emit neither PRACK nor ACK");s.offline();completed.add("confirmed"+(terminating?"-terminating":"")+"-ignores-late-"+code);
 }
 private Object reliable(int sequence,String tag,String marker)throws Exception{
  Object p=progress(183,sequence);type("kb4").getMethod("i",String.class,String.class).invoke(p,"To","<sip:peer@example.invalid>;tag="+tag);
  set(p,"g",SDP.replace("192.0.2.10",marker).getBytes(StandardCharsets.US_ASCII));return p;
 }
 private void prack(Session s,int sequence)throws Exception{
  check(s.packets().size()==1&&"PRACK".equals(get(s.packets().get(0),"b")),"one actual native PRACK for accepted reliable response "+sequence);
  check((sequence+" 11 INVITE").equals(first(s.packets().get(0),"RAck")),"PRACK RAck matches reliable response "+sequence);
 }
 private void normalProgress()throws Exception{
  Session s=new Session();check(s.accept(response(100,11,"INVITE","A",BRANCH)),"normal pending100 accepted");check(s.present()&&get(s.dialog,"D")==null,"100 retains unconfirmed call");
  check(s.accept(progress(180,1)),"normal pre-answer180 accepted");check(s.present()&&get(s.dialog,"D")==null&&(Boolean)get(s.dialog,"w"),"normal180 advances pending call without confirming");
  check(s.accept(reliable(47,"A","192.0.2.47")),"first reliable183 with arbitrary RSeq47 accepted");check(s.present()&&get(s.dialog,"D")==null,"normal183 remains pending");prack(s,47);check(Integer.valueOf(47).equals(((Map)get(s.dialog,"v")).get("A")),"native tracks first RSeq47 for A");s.packets().clear();Map<String,String> before=snapshot(s.dialog);
  check(s.accept(reliable(47,"A","192.0.2.99")),"duplicate reliable183 consumed");check(before.equals(snapshot(s.dialog))&&s.packets().isEmpty(),"duplicate RSeq47 does not change SDP, state, timers or send another PRACK");
  Object gap=reliable(49,"A","192.0.2.49");check(s.accept(gap),"out-of-order reliable183 consumed");check(before.equals(snapshot(s.dialog))&&s.packets().isEmpty(),"RSeq49 gap leaves SDP and all dialog state intact without PRACK");
  check(s.accept(reliable(48,"A","192.0.2.48")),"missing next RSeq48 accepted");prack(s,48);check(new String((byte[])get(s.dialog,"p"),StandardCharsets.US_ASCII).contains("192.0.2.48"),"accepted next RSeq updates native SDP");s.packets().clear();
  check(s.accept(gap),"previously skipped RSeq49 accepted after48");prack(s,49);check(Integer.valueOf(49).equals(((Map)get(s.dialog,"v")).get("A")),"A RSeq advances to49");check(new String((byte[])get(s.dialog,"p"),StandardCharsets.US_ASCII).contains("192.0.2.49"),"accepted49 updates native SDP");s.packets().clear();
  check(s.accept(reliable(12,"B","192.0.2.12")),"different To-tag B accepts independent initialRSeq12");prack(s,12);check(Integer.valueOf(49).equals(((Map)get(s.dialog,"v")).get("A"))&&Integer.valueOf(12).equals(((Map)get(s.dialog,"v")).get("B")),"native RSeq accounting remains per To-tag");
  s.offline();completed.add("normal-pre-answer-100-180-reliable183");completed.add("reliable-47-duplicate-gap49-48-49-and-independent-B12");
 }
 private Object copyMessage(Object packet)throws Exception{return type("kb4").getConstructor(boolean.class,String.class,String.class,int.class,String.class,ArrayList.class,byte[].class).newInstance(get(packet,"a"),get(packet,"b"),get(packet,"c"),get(packet,"d"),get(packet,"e"),new ArrayList((List)get(packet,"f")),((byte[])get(packet,"g")).clone());}
 private double now()throws Exception{return(Double)type("o82").getMethod("p").invoke(null);}
 private void installInitialTcpTimer(Session s)throws Exception{
  Object kind=type("ja4").getConstructor(String.class).newInstance(BRANCH);
  Object timer=type("ka4").getConstructor(type("kb4"),type("oc2"),double.class,double.class,double.class,type("hc2")).newInstance(get(s.dialog,"j"),null,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,now()+32.0,kind);
  ((List)get(s.dialog,"F")).add(timer);
 }
 private void fallbackTransport()throws Exception{
  Method fallback=type("cc.forserein.simhub.internal.SipInviteTransport").getMethod("onFallbackSent",Object.class,Object.class);
  Session s=new Session();Object original=get(s.dialog,"j");installInitialTcpTimer(s);
  List timers=(List)get(s.dialog,"F");check(timers.size()==1,"native ka4/ja4 fixture has one initial TCP timer in the actual f82 shape");Object timer=timers.get(0),deadline=get(timer,"e"),oldViaPair=null;
  for(Object pair:(List)get(original,"f"))if("Via".equals(get(pair,"T")))oldViaPair=pair;
  check(Double.isInfinite((Double)get(timer,"c"))&&Double.isInfinite((Double)get(timer,"d")),"native TCP timer initially has no UDP retransmit cadence");
  Object queued=copyMessage(original);String tcpVia=first(original,"Via"),udpVia=tcpVia.replace("SIP/2.0/TCP","SIP/2.0/UDP");type("kb4").getMethod("i",String.class,String.class).invoke(queued,"Via",udpVia);set(s.engine,"W",true);
  double start=now();transportHelperCalls++;fallback.invoke(null,s.engine,queued);double end=now();
  check(udpVia.equals(first(original,"Via")),"fallback synchronizes exact pending original INVITE Via to UDP");check(tcpVia.equals(get(oldViaPair,"U")),"fallback preserves old immutable header pair");check(timers.size()==1&&timers.get(0)==timer&&get(timer,"a")==original,"fallback retains original native timer/request identity");
  check(deadline.equals(get(timer,"e")),"fallback retains original final-response deadline");check(((Double)get(timer,"c"))==0.5,"fallback activates native 500ms UDP cadence");double next=(Double)get(timer,"d");check(next>=start+0.5&&next<=end+0.5,"fallback schedules next native retry from current clock");check(s.packets().isEmpty(),"helper synchronizes state without sending a packet");s.offline();completed.add("exact-pending-fallback-preserves-timer-deadline-and-header-pair");
  s=new Session();original=get(s.dialog,"j");installInitialTcpTimer(s);Map<String,String> before=snapshot(s.dialog);
  queued=copyMessage(original);type("kb4").getMethod("i",String.class,String.class).invoke(queued,"Via","SIP/2.0/UDP 192.0.2.1:5060;branch=z9hG4bK-mismatched");set(s.engine,"W",true);transportHelperCalls++;fallback.invoke(null,s.engine,queued);
  check(before.equals(snapshot(s.dialog))&&s.packets().isEmpty(),"mismatched fallback branch cannot mutate original dialog or timer");s.offline();completed.add("mismatched-fallback-cannot-rewrite-original-INVITE");
 }
 private void cases()throws Exception{
  for(String c:new String[]{"o82","cb4","kb4","ma4","jf2"}){type(c).getDeclaredMethods();checks++;}
  if(scenario.equals("late180")){lateProgress(180,false);return;}
  if(scenario.equals("late183")){lateProgress(183,false);return;}
  if(scenario.equals("reliable")){normalProgress();return;}
  for(int code:new int[]{486,500,603})statusCases(code);
  for(int code:new int[]{180,183})for(boolean terminating:new boolean[]{false,true})lateProgress(code,terminating);
  normalProgress();fallbackTransport();
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);if(args!=null&&args.getString("case")!=null)scenario=args.getString("case");start();}
 @Override public void onStart(){Bundle b=new Bundle();Throwable failure=null;try{runOnMainSync(()->{});loader=getTargetContext().getClassLoader();cases();}catch(Throwable t){failure=t;}
  b.putInt("checks",checks);b.putInt("native_response_calls",nativeCalls);b.putInt("native_log_calls",logCalls);b.putInt("transport_helper_calls",transportHelperCalls);b.putInt("network_socket_calls",0);b.putStringArrayList("completed_cases",completed);
  b.putString("scope","Actual installed o82.h, C and native SIP builders execute on Android ART. Native TCP stack has no connection and no packet-output callback; intended ACKs are inspected in native V before closed-session discard. SipInviteTransport is additionally invoked directly on real isolated pending dialogs with actual ka4/ja4 objects constructed in the f82 initial TCP timer shape; the native a82 socket-failure callback is not exercised here. No socket, APDU, SIM, media or real number is used.");
  if(failure==null){b.putString("status","passed");finish(0,b);}else{b.putString("status","failed");b.putString("error",android.util.Log.getStackTraceString(failure));finish(1,b);}
 }
}
