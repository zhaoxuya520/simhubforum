package carriersmoke;
import android.app.*;
import android.content.*;
import android.os.Bundle;
import java.lang.reflect.*;
import java.util.*;

/** Independent emulator instrumentation; synthetic metadata only, no SIM or network operations. */
public final class CarrierSmoke extends Instrumentation {
 private ClassLoader loader;private int checks;private final ArrayList<String> loaded=new ArrayList<>();
 private final ArrayList<Object> transports=new ArrayList<>(),auths=new ArrayList<>(),fixtureCards=new ArrayList<>();
 private int previousFixtureRecordsRemoved;
 private final LinkedHashMap<Field,Object> savedStatics=new LinkedHashMap<>();
 private IsolatedContext isolated;private Object originalState,flow,originalContext,originalLibraryContext;
 private Class<?> type(String name)throws Exception{return Class.forName(name,true,loader);}
 private Object get(Object value,String name)throws Exception{Field f=value.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(value);}
 private void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;}
 private Object invoke(String helper,String method,Class<?>[] params,Object...args)throws Exception{
  fixtureContext(helper+"."+method+" before");Object value=type("cc.forserein.simhub.internal."+helper).getMethod(method,params).invoke(null,args);fixtureContext(helper+"."+method+" after");return value;
 }
 private void fixtureContext(String stage)throws Exception{
  if(isolated!=null&&(type("zl5").getField("f").get(null)!=isolated||type("fj5").getField("d").get(null)!=isolated))throw new AssertionError("Instrumentation context replaced at "+stage);
 }
 private Object unary(String helper,String method,Object arg)throws Exception{return invoke(helper,method,new Class<?>[]{Object.class},arg);}
 private boolean dito(Object card)throws Exception{return (Boolean)unary("DitoHomeIdentity","isDito",card);}
 private Constructor<?> constructor(Class<?> type,int count){for(Constructor<?> c:type.getDeclaredConstructors())if(c.getParameterTypes().length==count){c.setAccessible(true);return c;}throw new AssertionError(type.getName());}
 private Object card(String imsi,String iccid)throws Exception{Object c=constructor(type("ek5"),8).newInstance(imsi,iccid,2,null,null,"+639980000001","+639980000002",null);fixtureCards.add(c);return c;}
 private void missingHome(Object card)throws Exception{
  try{unary("DitoHomeIdentity","connection",card);throw new AssertionError("missing real home IMSI connected");}
  catch(InvocationTargetException expected){Throwable cause=expected.getCause();check(cause instanceof IllegalStateException&&cause.getMessage().contains("51566"),"missing actual home identity blocks connection");}
 }
 public static final class IsolatedContext extends ContextWrapper {
  final String prefix="art_carrier235_"+UUID.randomUUID().toString()+"_";
  final Set<String> files=new LinkedHashSet<>();
  IsolatedContext(Context base){super(base);}
  @Override public Context getApplicationContext(){return this;}
  @Override public SharedPreferences getSharedPreferences(String name,int mode){String actual=prefix+name;files.add(actual);return getBaseContext().getSharedPreferences(actual,mode);}
  void clean(){for(String name:files){if(!getBaseContext().getSharedPreferences(name,0).edit().clear().commit()||!getBaseContext().deleteSharedPreferences(name))throw new IllegalStateException("Temporary ART preferences cleanup failed");}}
 }
 public static final class Profile {
  public String a,c,d,e;public boolean b=true;
  Profile(String iccid,String nickname,String provider){a=iccid;c=nickname;d=provider;e=nickname;}
 }
 public static final class Chip {public String b="art-eid";public List<Profile>d;Chip(Profile p){d=Collections.singletonList(p);}}
 public static final class Controller {
  private final List<Chip> chips;Controller(Profile p){chips=Collections.singletonList(new Chip(p));}
  public String r(){return "art-eid";}public List<Chip> l(){return chips;}
 }
 public static final class Transport {public String f="ART synthetic reader";}
 private void physicalRead(Object card,String metadataIccid,String nickname,String provider)throws Exception{
  Object transport=new Transport(),auth=new Object();transports.add(transport);auths.add(auth);
  invoke("IdentityBinding","track",new Class<?>[]{Object.class,Object.class},transport,new Controller(new Profile(metadataIccid,nickname,provider)));
  invoke("IdentityBinding","begin",new Class<?>[]{Object.class,Object.class},transport,auth);
  invoke("IdentityBinding","read",new Class<?>[]{Object.class,Object.class,Object.class},transport,auth,card);
 }
 private void saveMutableStatics(String name)throws Exception{
  for(Field f:type(name).getDeclaredFields())if(Modifier.isStatic(f.getModifiers())&&!Modifier.isFinal(f.getModifiers())){f.setAccessible(true);savedStatics.put(f,f.get(null));}
 }
 private void removePriorFixtureResidue()throws Exception{
  for(String[] entry:new String[][]{{"wifi_calling_dito_identity_v1","vowifi.dito.home_imsi.8963668800123459001","515660123456789"},{"wifi_calling_dito_provider_v1","vowifi.dito.provider.8901234500123457001","DITO TELECOMMUNITY"}}){
   SharedPreferences preferences=getTargetContext().getSharedPreferences(entry[0],0);String key=(String)invoke("WifiConfigValues","digest",new Class<?>[]{String.class},entry[1]);
   if(entry[2].equals(preferences.getString(key,null))){if(!preferences.edit().remove(key).commit())throw new IllegalStateException("Prior synthetic fixture cleanup failed");previousFixtureRecordsRemoved++;}
  }
 }
 private void setup()throws Exception{
  Class<?> nativeState=type("zl5"),library=type("fj5");originalContext=nativeState.getField("f").get(null);originalLibraryContext=library.getField("d").get(null);
  flow=nativeState.getField("b").get(null);originalState=flow.getClass().getMethod("getValue").invoke(flow);
  isolated=new IsolatedContext(getTargetContext());nativeState.getField("f").set(null,isolated);library.getField("d").set(null,isolated);
  saveMutableStatics("cc.forserein.simhub.internal.WifiConfigRuntime");saveMutableStatics("cc.forserein.simhub.internal.CarrierPresets");
 }
 private void state(Object card,Object config)throws Exception{
  Object[] values=new Object[20];for(int i=0;i<20;i++)values[i]=get(originalState,String.valueOf((char)('a'+i)));
  values[4]=card;values[5]=config;values[6]=false;values[7]="old.vodafone.example.org";values[8]="+639980000001";values[9]="490154203237518";values[11]=false;values[17]=false;
  Object changed=constructor(type("gl5"),20).newInstance(values);flow.getClass().getMethod("i",Object.class).invoke(flow,changed);
 }
 @SuppressWarnings("unchecked") private void cleanup()throws Exception{
  Exception failure=null;
  try{if(flow!=null&&originalState!=null)flow.getClass().getMethod("i",Object.class).invoke(flow,originalState);}catch(Exception e){failure=e;}
  for(Map.Entry<Field,Object> e:savedStatics.entrySet())try{e.getKey().set(null,e.getValue());}catch(Exception x){failure=x;}
  Class<?> identity=type("cc.forserein.simhub.internal.IdentityBinding");
  synchronized(identity){for(String field:new String[]{"selections","reads","latest"}){Field f=identity.getDeclaredField(field);f.setAccessible(true);Map<Object,Object> map=(Map<Object,Object>)f.get(null);for(Object key:field.equals("reads")?auths:transports)map.remove(key);}}
  type("zl5").getField("f").set(null,originalContext);type("fj5").getField("d").set(null,originalLibraryContext);
  Field providers=type("cc.forserein.simhub.internal.DitoHomeIdentity").getDeclaredField("currentProviders");providers.setAccessible(true);List<?> current=(List<?>)providers.get(null);
  synchronized(current){for(int i=current.size()-1;i>=0;i--){Object value=((java.lang.ref.WeakReference<?>)current.get(i)).get();for(Object card:fixtureCards)if(value==card){current.remove(i);break;}}}
  if(isolated!=null)isolated.clean();if(failure!=null)throw failure;
 }
 private void cases()throws Exception{
  for(String n:new String[]{"DitoHomeIdentity","IdentityBinding","WifiConfigRuntime","WifiConfigEditor","CarrierPresets","DitoCarrierProfile"}){type("cc.forserein.simhub.internal."+n).getDeclaredMethods();loaded.add(n);checks++;}
  Object known=card("260031234567890","8963668800123459001");
  check(dito(known),"known DITO IIN recognized with non-20404 current IMSI");
  Object nativeConfig=unary("WifiConfigModel","builtIn",known);
  check(!"DITO".equals(get(nativeConfig,"c")),"actual native roaming selector provides non-DITO baseline");
  Object effective=invoke("WifiConfigRuntime","resolve",new Class<?>[]{Object.class,Object.class},known,nativeConfig);
  check("DITO".equals(get(effective,"c")),"runtime automatically selects DITO from known IIN");
  check("ims.mnc066.mcc515.3gppnetwork.org".equals(get(effective,"g")),"automatic DITO realm is the home realm");
  missingHome(known);
  Object provider=card("204049876543210","8901234500123457001");
  check(!dito(provider),"unknown IIN starts without invented DITO evidence");
  physicalRead(provider,"8901234500123457001","Unrelated nickname"," DITO Telecommunity ");
  check(dito(provider),"actual IdentityBinding learns provider on exact physical ICCID");
  check(unary("DitoHomeIdentity","settings",provider)==provider,"provider alone does not fabricate home IMSI");missingHome(provider);
  Object nickname=card("204049876543210","8901234500123457002");
  physicalRead(nickname,"8901234500123457002","DITO","Vodafone");check(!dito(nickname),"nickname DITO alone is not provider evidence");
  Object wrong=card("204049876543210","8901234500123457003");
  physicalRead(wrong,"8901234500123457004","Other","DITO");check(!dito(wrong),"provider for a different ICCID is not learned");
  Object home=card("515660123456789","8963668800123459001");unary("DitoHomeIdentity","observe",home);
  Object restored=unary("DitoHomeIdentity","connection",known);
  check(restored!=known&&"515660123456789".equals(get(restored,"a")),"same-card real home IMSI restored for non-20404 identity");
  check("260031234567890".equals(get(known,"a")),"physical identity object remains untouched");
  check(get(known,"b").equals(get(restored,"b"))&&get(known,"f").equals(get(restored,"f")),"home clone preserves ICCID and SMSC");
  state(known,nativeConfig);
  String key=(String)unary("WifiConfigRuntime","cardKey",known);
  Map<String,String> broken=new LinkedHashMap<>();broken.put("carrier_preset","51566|missing_saved_template");
  String record=(String)invoke("WifiConfigValues","encode",new Class<?>[]{Map.class},broken);
  SharedPreferences prefs=isolated.getSharedPreferences("wifi_config_overrides_v1",0);check(prefs.edit().putString(key,record).commit(),"synthetic bad preset saved only to isolated test preferences");
  effective=invoke("WifiConfigRuntime","resolve",new Class<?>[]{Object.class,Object.class},known,nativeConfig);
  check("DITO".equals(get(effective,"c"))&&"ims.mnc066.mcc515.3gppnetwork.org".equals(get(effective,"g")),"bad saved preset still resolves to DITO home settings");
  check(((List<?>)get(effective,"f")).contains("epdg.epc.mnc066.mcc515.pub.3gppnetwork.org"),"DITO fallback keeps correct ePDG endpoint");
  Object actualEpdg=invoke("WifiConfigRuntime","epdg",new Class<?>[]{Object.class,String.class},known,"old.vodafone.example.org");
  Method actualPrefsMethod=type("cc.forserein.simhub.internal.WifiConfigRuntime").getDeclaredMethod("prefs");actualPrefsMethod.setAccessible(true);SharedPreferences actualPrefs=(SharedPreferences)actualPrefsMethod.invoke(null);
  String actualRecord=actualPrefs.getString(key,null);Object actualContext=type("zl5").getField("f").get(null);
  ArrayList<String> preferenceNameHashes=new ArrayList<>();for(String name:isolated.files)preferenceNameHashes.add((String)invoke("WifiConfigValues","digest",new Class<?>[]{String.class},name));
  String details="actualEpdg="+actualEpdg+" isDito="+dito(known)+" contextSame="+(actualContext==isolated)+" contextType="+actualContext.getClass().getName()+" prefsSame="+(actualPrefs==prefs)+" keySame="+key.equals(unary("WifiConfigRuntime","cardKey",known))+" actualRecord="+(actualRecord==null?"null":actualRecord.equals(record)?"expected-synthetic-bad-preset":"different-record-hash:"+invoke("WifiConfigValues","digest",new Class<?>[]{String.class},actualRecord))+" harnessRecordSame="+record.equals(prefs.getString(key,null))+" prefNameHashes="+preferenceNameHashes;
  android.util.Log.i("CarrierArtFixture",details);
  check("".equals(actualEpdg),"stale Vodafone endpoint cannot override DITO recovery: "+details);
  Object snapshot=invoke("WifiConfigRuntime","snapshot",new Class<?>[0]);
  check(get(snapshot,"warning")!=null&&((Map<?,?>)get(snapshot,"values")).isEmpty(),"editor snapshot recovers with warning and clean draft");
  check(record.equals(get(snapshot,"record"))&&record.equals(prefs.getString(key,null)),"bad record is retained until explicit repair");
  Class<?> session=type("cc.forserein.simhub.internal.WifiConfigEditor$Session");Constructor<?> ctor=session.getDeclaredConstructor(Activity.class,Object.class);ctor.setAccessible(true);Object editor=ctor.newInstance(new Object[]{null,null});
  check(get(editor,"snapshot")!=null&&get(editor,"draft")!=null,"actual editor Session constructor accepts recovered snapshot");
  invoke("WifiConfigRuntime","save",new Class<?>[]{String.class,String.class,Map.class},key,record,Collections.<String,String>emptyMap());
  snapshot=invoke("WifiConfigRuntime","snapshot",new Class<?>[0]);check(((Map<?,?>)get(snapshot,"values")).isEmpty(),"explicit empty save repairs invalid preset");
  check(!record.equals(prefs.getString(key,null)),"repair replaces bad saved record");
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);start();}
 @Override public void onStart(){Bundle result=new Bundle();Throwable problem=null;boolean cleaned=false;loader=getTargetContext().getClassLoader();
  try{runOnMainSync(new Runnable(){public void run(){}});removePriorFixtureResidue();setup();cases();}catch(Throwable e){problem=e;}finally{try{cleanup();cleaned=true;}catch(Throwable cleanup){if(problem==null)problem=cleanup;else problem.addSuppressed(cleanup);}}
  result.putInt("checks",checks);result.putInt("previous_fixture_records_removed",previousFixtureRecordsRemoved);result.putBoolean("synthetic_state_cleaned",cleaned);result.putStringArrayList("loaded_classes",loaded);result.putString("scope","Actual ART DITO/IdentityBinding/Runtime/editor Session with synthetic cards/profile metadata and private temporary preferences. No APDU/network/audio; app state/context restored.");
  if(problem==null){result.putString("status","passed");finish(0,result);}else{result.putString("status","failed");result.putString("error",android.util.Log.getStackTraceString(problem));finish(1,result);}
 }
}
