"""Exercise only disposable preferences in the explicitly pinned installed APK."""
from pathlib import Path
import argparse, subprocess, hashlib, re, json, datetime

parser=argparse.ArgumentParser()
parser.add_argument('--apk-sha256',required=True)
parser.add_argument('--expect',choices=('baseline','fixed'),required=True)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parent
args.out.mkdir(parents=True,exist_ok=True)
adb=['/workspace/tools/android-platform-tools/platform-tools/adb','-s','emulator-5580']
component='cc.forserein.simhub.configformatsmoke/configformatsmoke.ConfigFormatSmoke'
def run(*c):
 p=subprocess.run(adb+list(map(str,c)),capture_output=True,text=True,timeout=150)
 p.check_returncode();return p.stdout+p.stderr
def installed():
 p=run('shell','pm','path','cc.forserein.simhub').strip().removeprefix('package:')
 return run('shell','sha256sum',p).split()[0]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before=installed();assert before==args.apk_sha256,before
apk=root/'config-harness/config-format-instrumentation.apk'
install=run('install','--no-streaming','-r',apk)
(args.out/'instrumentation-install.txt').write_text(install)
assert 'Success' in install
results={}
for phase in ('write','read'):
 run('shell','am','force-stop','cc.forserein.simhub')
 log=run('shell','am','instrument','-w','-e','phase',phase,'-e','expect',args.expect,component)
 (args.out/(phase+'.txt')).write_text(log)
 results[phase]=dict(re.findall(r'^INSTRUMENTATION_RESULT: ([A-Za-z0-9_]+)=(.*)$',log,re.M))
 assert results[phase].get('status')=='passed',log
 assert 'INSTRUMENTATION_CODE: 0' in log,log
 print(phase,results[phase].get('checks'),results[phase].get('status'),flush=True)
assert results['write']['pid']!=results['read']['pid']
assert results['read']['baseline_corruption_reproduced']==str(args.expect=='baseline').lower()
assert installed()==before
report={'status':'passed','expect':args.expect,'apk_sha256':before,'installed_apk_unchanged':True,
 'cross_process_android_preferences':True,'checks':sum(int(r['checks']) for r in results.values()),
 'results':results,'instrumentation_apk_sha256':sha(apk),
 'sources':{p.name:sha(p) for p in (root/'config-harness').iterdir() if p.suffix in ('.java','.py','.xml')},
 'driver_sha256':sha(Path(__file__)),'private_production_preferences_modified':False,
 'disposable_test_preferences_deleted':True,'physical_card_accessed':False,
 'sms_or_call_sent':False,'network_requests':False,
 'limits':['Android11 API30 software emulator; no physical OnePlus device attached.',
  'Validates actual installed serialization helpers and real Android preference storage, not carrier SMS delivery or calls.'],
 'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(args.out/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(args.out/'validation.json')
