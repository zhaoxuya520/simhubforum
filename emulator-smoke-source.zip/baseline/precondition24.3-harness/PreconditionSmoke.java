package configformatsmoke;

import android.app.Instrumentation;
import android.os.Bundle;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Actual h -> PRACK response -> qa1 -> native cb4.k UPDATE, with disconnected native TCP transport. */
@SuppressWarnings({"rawtypes","unchecked"})
public final class PreconditionSmoke extends Instrumentation {
 private boolean fixed;private ClassLoader loader;private int checks,nativeCalls,logCalls;
 private static final String ID="art-precondition@example.invalid",BRANCH="z9hG4bK-art-precondition-11";
 private static final String BASE="v=0\r\no=- 1 1 IN IP4 192.0.2.10\r\ns=synthetic\r\nc=IN IP4 192.0.2.10\r\nt=0 0\r\nm=audio 10000 RTP/AVP 116\r\na=rtpmap:116 AMR-WB/16000\r\na=fmtp:116 octet-align=1\r\n";
 private static final String OFFER=BASE+"a=curr:qos local sendrecv\r\na=curr:qos remote none\r\na=des:qos mandatory local sendrecv\r\na=des:qos mandatory remote sendrecv\r\na=sendrecv\r\n";
 private static final String ANSWER=BASE+"a=curr:qos local none\r\na=curr:qos remote sendrecv\r\na=des:qos mandatory local sendrecv\r\na=des:qos mandatory remote sendrecv\r\na=conf:qos remote sendrecv\r\na=sendrecv\r\n";
 private Class<?> type(String n)throws Exception{return Class.forName(n,true,loader);}
 private Object get(Object o,String n)throws Exception{return o.getClass().getField(n).get(o);}
 private void set(Object o,String n,Object v)throws Exception{Field f=o.getClass().getField(n);f.setAccessible(true);f.set(o,v);}
 private Object stat(String c,String f)throws Exception{return type(c).getField(f).get(null);}
 private Object raw(String n)throws Exception{Class<?> u=Class.forName("sun.misc.Unsafe");Field f=u.getDeclaredField("theUnsafe");f.setAccessible(true);return u.getMethod("allocateInstance",Class.class).invoke(f.get(null),type(n));}
 private void check(boolean b,String m){if(!b)throw new AssertionError(m);checks++;}
 private void add(Object p,String n,String v)throws Exception{type("kb4").getMethod("a",String.class,String.class).invoke(p,n,v);}
 private String first(Object p,String n)throws Exception{List l=(List)type("kb4").getMethod("j",String.class).invoke(p,n);return l.isEmpty()?null:(String)l.get(0);}
 private boolean option(Object p,String name,String token)throws Exception{for(Object h:(List)type("kb4").getMethod("j",String.class).invoke(p,name))for(String s:h.toString().split(","))if(token.equalsIgnoreCase(s.trim()))return true;return false;}
 private String body(Object p)throws Exception{return new String((byte[])get(p,"g"),StandardCharsets.US_ASCII);}
 private Object packet(boolean request,String method,int status,String body)throws Exception{return type("kb4").getConstructor(boolean.class,String.class,String.class,int.class,String.class,ArrayList.class,byte[].class).newInstance(request,method,"sip:peer@example.invalid",status,request?"":"OK",new ArrayList<>(),body.getBytes(StandardCharsets.US_ASCII));}
 private Object response(Object request,int status,String body)throws Exception{
  Object p=packet(false,(String)get(request,"b"),status,body);for(String h:new String[]{"Via","From","Call-ID","CSeq"})add(p,h,first(request,h));String to=first(request,"To");add(p,"To",to+(to.contains(";tag=")?"":";tag=A"));
  add(p,"Contact","<sip:peer@example.invalid>");if(!body.isEmpty())add(p,"Content-Type","application/sdp");return p;
 }
 private final class Session {
  final Object invite,dialog,manager,engine,stack;
  Session()throws Exception{
   invite=packet(true,"INVITE",0,OFFER);add(invite,"Via","SIP/2.0/TCP 192.0.2.1:5060;branch="+BRANCH);add(invite,"From","<sip:local@example.invalid>;tag=local-tag");add(invite,"To","<sip:peer@example.invalid>");add(invite,"Call-ID",ID);add(invite,"CSeq","11 INVITE");add(invite,"Content-Type","application/sdp");add(invite,"Supported","100rel,precondition");
   dialog=type("ma4").getConstructors()[0].newInstance(stat("ga4","U"),ID,stat("la4","T"),"local-tag","sip:local@example.invalid","sip:peer@example.invalid","sip:peer@example.invalid",11,11,invite,0.0);
   set(dialog,"o",OFFER.getBytes(StandardCharsets.US_ASCII));set(dialog,"q",true);
   Object config=type("ra4").getConstructors()[0].newInstance("192.0.2.1",5060,"sip:local@example.invalid","urn:uuid:art-precondition","sip:local@example.invalid","probe",new ArrayList<>(),Arrays.asList("ipsec-3gpp;alg=hmac-sha-1-96"),new ArrayList<>(),true,false);
   manager=type("cb4").getConstructors()[0].newInstance(config,null,null,null);((Map)get(manager,"e")).put(ID,dialog);
   Object address=type("x82").getConstructor(byte[].class).newInstance((Object)new byte[]{(byte)192,0,2,1});
   set(manager,"c",type("wv1").getConstructor(Object.class,int.class,Object.class,int.class).newInstance(address,45000,stat("vk","c"),2));set(manager,"d",type("qa1").getConstructor(int.class).newInstance(29));
   engine=raw("o82");set(engine,"J",manager);set(engine,"V",new ArrayList<>());set(engine,"b",raw("xi5"));
   set(engine,"c",type("ek5").getConstructor(String.class,String.class,int.class,String.class,String.class,String.class,String.class,type("z82")).newInstance("","",2,"","",null,null,null));
   Object logger=Proxy.newProxyInstance(loader,new Class<?>[]{type("ws1")},(o,m,a)->{if(m.getName().equals("i")){logCalls++;return stat("sc5","a");}if(m.getName().equals("toString"))return "Offline precondition logger";throw new AssertionError(m.toString());});
   set(engine,"g",type("g11").getConstructor(int.class,Object.class,Object.class).newInstance(13,engine,logger));
   stack=type("jf2").getConstructor(byte[].class).newInstance((Object)new byte[]{127,0,0,1});set(engine,"R",stack);set(engine,"T",1);set(engine,"U",false);
  }
  List sent()throws Exception{return (List)get(engine,"V");}
  void accept(Object p)throws Exception{nativeCalls++;check((Boolean)type("o82").getMethod("h",type("kb4")).invoke(engine,p),"actual native response consumed");}
  void offline()throws Exception{check(((Map)get(stack,"j")).isEmpty()&&((Map)get(stack,"k")).isEmpty()&&get(stack,"c")==null,"native TCP has no connection, endpoint, or packet-output callback");}
 }
 private void exercise(boolean required,boolean hasSdp)throws Exception{
  Session s=new Session();Object progress=response(s.invite,183,hasSdp?ANSWER:"");add(progress,"Require",required?"100rel,PrEcOnDiTiOn":"100rel");add(progress,"RSeq","1");s.accept(progress);
  check(s.sent().size()==1&&"PRACK".equals(get(s.sent().get(0),"b")),"one actual native PRACK for reliable183");Object prack=s.sent().get(0);
  check(body(prack).isEmpty()&&!option(prack,"Require","precondition"),"bodyless PRACK has no new SDP requirement");check(option(prack,"Require","sec-agree"),"native PRACK security-agreement requirement preserved");
  s.sent().clear();s.accept(response(prack,200,""));
  if(hasSdp){check(s.sent().size()==1&&"UPDATE".equals(get(s.sent().get(0),"b")),"native PRACK200 callback generates one UPDATE");Object update=s.sent().get(0);
   check(option(update,"Require","precondition")== (fixed&&required),"UPDATE requirement follows accepted negotiated proof and expected baseline/fixed behavior");
   check(option(update,"Require","sec-agree")&&first(update,"Security-Verify")!=null,"UPDATE preserves existing security headers");
   check("application/sdp".equals(first(update,"Content-Type"))&&body(update).contains("a=curr:qos local sendrecv")&&body(update).contains("a=curr:qos remote none"),"native SDP resource-confirmation payload preserved");
   check(first(update,"To").endsWith(";tag=A"),"UPDATE remains in the accepted early dialog");
  }else check(s.sent().isEmpty(),"header-only reliable response does not negotiate an SDP UPDATE");
  check(get(s.dialog,"D")==null,"all cases remain early dialogs without a real call");s.offline();
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);fixed="fixed".equals(args.getString("expect"));start();}
 @Override public void onStart(){Bundle b=new Bundle();Throwable error=null;try{runOnMainSync(()->{});loader=getTargetContext().getClassLoader();exercise(true,true);exercise(false,true);exercise(true,false);}catch(Throwable t){error=t;}
  b.putInt("checks",checks);b.putInt("native_response_calls",nativeCalls);b.putInt("native_log_calls",logCalls);b.putInt("network_socket_calls",0);b.putString("expect",fixed?"fixed":"baseline");
  b.putString("scope","Actual o82.h -> PRACK -> native qa1/cb4.k UPDATE -> o82.C on ART, using explicit synthetic already-created early dialogs with offered SDP/precondition flag. Empty native TCP stack discards queued packets without sockets. Initial f82 INVITE creation, encryption, audio, SIM and operator behavior are not exercised.");
  b.putString("status",error==null?"passed":"failed");if(error!=null)b.putString("error",android.util.Log.getStackTraceString(error));finish(error==null?0:1,b);
 }
}
