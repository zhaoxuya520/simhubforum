package configformatsmoke;

import android.app.Instrumentation;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import java.io.File;
import java.nio.file.Files;
import java.lang.reflect.*;
import java.security.MessageDigest;
import java.util.*;

/** Actual installed serialization methods; only a uniquely named disposable preference file. */
public final class ConfigFormatSmoke extends Instrumentation {
 private static final String PREF="offline24_3_format_probe_20261119";
 private String phase;private boolean fixed;private int checks;private Method validate,encode,decode;
 private final Bundle result=new Bundle();
 private void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;}
 private String hash(String s)throws Exception{StringBuilder b=new StringBuilder();for(byte x:MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8")))b.append(String.format(Locale.ROOT,"%02x",x&255));return b.toString();}
 private String hex(String s)throws Exception{StringBuilder b=new StringBuilder();for(byte x:s.getBytes("UTF-8"))b.append(String.format(Locale.ROOT,"%02x",x&255));return b.toString();}
 @SuppressWarnings("unchecked") private Map<String,String> validate(Map<String,String> m)throws Exception{return (Map<String,String>)validate.invoke(null,m);}
 @SuppressWarnings("unchecked") private Map<String,String> decode(String s)throws Exception{return (Map<String,String>)decode.invoke(null,s);}
 private List<Map<String,String>> cases(){
  List<Map<String,String>> list=new ArrayList<>();
  list.add(Collections.singletonMap("smsc","+8613800100500"));
  Map<String,String> multiple=new LinkedHashMap<>();multiple.put("smsc","+8613800200500");multiple.put("smsc_list","+8613800100500\n+8613800200500");list.add(multiple);
  list.add(Collections.singletonMap("epdg","epdg-a.example.invalid\nepdg-b.example.invalid"));
  Map<String,String> all=new LinkedHashMap<>(multiple);all.put("epdg","epdg-a.example.invalid\nepdg-b.example.invalid");all.put("domain","ims.example.invalid");all.put("apn","ims");all.put("impi","probe@ims.example.invalid");list.add(all);
  list.add(Collections.<String,String>emptyMap());
  Map<String,String> deleted=new LinkedHashMap<>();deleted.put("smsc_list","[]");deleted.put("epdg","[]");list.add(deleted);
  return list;
 }
 private void runCases()throws Exception{
  Class<?> cls=Class.forName("cc.forserein.simhub.internal.WifiConfigValues",true,getTargetContext().getClassLoader());
  validate=cls.getMethod("validate",Map.class);encode=cls.getMethod("encode",Map.class);decode=cls.getMethod("decode",String.class);
  SharedPreferences prefs=getTargetContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);
  result.putString("preferences_implementation",prefs.getClass().getName());result.putString("context_implementation",getTargetContext().getClass().getName());
  List<Map<String,String>> cases=cases();
  if("write".equals(phase)){
   check(prefs.getAll().isEmpty(),"fixture preference file starts empty; never overwrite an existing file");
   SharedPreferences.Editor editor=prefs.edit();
   for(int i=0;i<cases.size();i++){
    Map<String,String> canonical=validate(cases.get(i));String record=(String)encode.invoke(null,canonical);
    check(record.startsWith("v1\n"),"actual encoder version header");
    check(canonical.isEmpty()||record.indexOf('\t')>0,"actual encoder uses TAB delimiters for populated records");
    check(decode(record).equals(canonical),"actual encode/decode round trip before persistence case "+i);
    if(fixed&&!canonical.isEmpty())check(!record.endsWith("\n"),"new populated record does not end with LF");
    editor.putString("case"+i,record);result.putString("case"+i+"_sha256",hash(record));
    if(fixed)editor.putString("legacy_case"+i,record.endsWith("\n")?record:record+"\n");
   }
   check(editor.putInt("writer_pid",android.os.Process.myPid()).commit(),"real SharedPreferences disk commit succeeds");
  }else if("read".equals(phase)){
   check(prefs.getInt("writer_pid",-1)>0,"first-process fixture data present");
   check(prefs.getInt("writer_pid",-1)!=android.os.Process.myPid(),"read occurs in a separate app process");
   String rawXml=new String(Files.readAllBytes(new File(getTargetContext().getDataDir(),"shared_prefs/"+PREF+".xml").toPath()),"UTF-8");
   result.putString("xml_escaped",rawXml.replace("\t","\\t").replace("\n","\\n").replace("\r","\\r"));
   for(int i=0;i<cases.size();i++){
    Map<String,String> canonical=validate(cases.get(i));String expected=(String)encode.invoke(null,canonical),actual=prefs.getString("case"+i,null);
    result.putString("case"+i+"_expected",expected.replace("\t","\\t").replace("\n","\\n").replace("\r","\\r"));
    result.putString("case"+i+"_actual",actual==null?"<null>":actual.replace("\t","\\t").replace("\n","\\n").replace("\r","\\r"));
    result.putString("case"+i+"_expected_hex",hex(expected));result.putString("case"+i+"_actual_hex",hex(actual));
    if(fixed){
     check(canonical.isEmpty()?(actual.equals(expected)||actual.equals(expected+"    ")):expected.equals(actual),"new record survives cold-read serialization case "+i);
     check(decode(actual).equals(canonical),"actual decoder preserves all fields after fresh process case "+i);
     String legacy=prefs.getString("legacy_case"+i,null);
     check(((expected.endsWith("\n")?expected:expected+"\n")+"    ").equals(legacy),"old v1 record actually experiences XML indentation in separate process case "+i);
     check(decode(legacy).equals(canonical),"existing v1 XML-indent tail recovers without losing values case "+i);
    }else{
     check((expected+"    ").equals(actual),"baseline reproducibly appends four indentation spaces after final LF case "+i);
     boolean rejected=false;try{decode(actual);}catch(InvocationTargetException failure){rejected=true;check("配置记录损坏".equals(failure.getCause().getMessage()),"cold read yields exact reported error case "+i);}
     check(rejected,"baseline actual decoder rejects XML-indent-only difference case "+i);
    }
    result.putString("case"+i+"_sha256",hash(actual));
   }
   String xml=new String(Files.readAllBytes(new File(getTargetContext().getDataDir(),"shared_prefs/"+PREF+".xml").toPath()),"UTF-8");
   result.putString("xml_sha256",hash(xml));result.putInt("xml_literal_tabs",xml.length()-xml.replace("\t","").length());
   result.putInt("xml_literal_linefeeds",xml.length()-xml.replace("\n","").length());
   check(getTargetContext().deleteSharedPreferences(PREF),"disposable fixture preference file removed");
   result.putBoolean("baseline_corruption_reproduced",!fixed);
  }else throw new AssertionError("phase must be write or read");
  boolean failed=false;
  try{decode("v1\nsmsc +8613800100500\n");}
  catch(InvocationTargetException e){failed=true;check("配置记录损坏".equals(e.getCause().getMessage()),"missing TAB produces exact reported Chinese error");result.putString("malformed_message",e.getCause().getMessage());}
  check(failed,"malformed-record negative control is rejected");
 }
 @Override public void onCreate(Bundle arguments){super.onCreate(arguments);phase=arguments.getString("phase");fixed="fixed".equals(arguments.getString("expect"));start();}
 @Override public void onStart(){Throwable error=null;try{runOnMainSync(()->{});runCases();}catch(Throwable problem){error=problem;}
  result.putInt("checks",checks);result.putInt("pid",android.os.Process.myPid());result.putString("phase",phase);
  result.putString("expect",fixed?"fixed":"baseline");
  result.putString("scope","Actual installed 24.3 validation/encoding/decoding and Android SharedPreferences; only new disposable fixture file; no production settings, SIM, APDU, SMS, call or socket.");
  result.putString("status",error==null?"passed":"failed");if(error!=null)result.putString("error",android.util.Log.getStackTraceString(error));finish(error==null?0:1,result);
 }
}
