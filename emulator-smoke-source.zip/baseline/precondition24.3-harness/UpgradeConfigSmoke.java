package configformatsmoke;

import android.app.Instrumentation;
import android.content.*;
import android.os.Bundle;
import java.io.File;
import java.lang.reflect.*;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.*;

/** Real 24.3 Runtime.save records retained across signed app upgrade; no production preference files. */
public final class UpgradeConfigSmoke extends Instrumentation {
 private static final String PREFIX="art_upgrade244_";
 private ClassLoader loader;private String phase;private int checks;private final Bundle result=new Bundle();
 private Object flow,oldState,oldContext,oldLibraryContext;private IsolatedContext isolated;
 private Object nativeLegacyStore;private Field legacyField;private Object originalLegacyPreferences;
 private final Map<Field,Object> saved=new LinkedHashMap<>();
 private Class<?> type(String n)throws Exception{return Class.forName(n,true,loader);}
 private Object get(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
 private Object helper(String n,String method,Class<?>[] signature,Object...args)throws Exception{
  if(type("zl5").getField("f").get(null)!=isolated)throw new AssertionError("Synthetic preference context was replaced");
  return type("cc.forserein.simhub.internal."+n).getMethod(method,signature).invoke(null,args);
 }
 private void check(boolean condition,String message){if(!condition)throw new AssertionError(message);checks++;}
 private Constructor<?> constructor(String n,int count)throws Exception{for(Constructor<?> c:type(n).getDeclaredConstructors())if(c.getParameterTypes().length==count){c.setAccessible(true);return c;}throw new AssertionError(n);}
 private String hash(byte[] b)throws Exception{StringBuilder out=new StringBuilder();for(byte x:MessageDigest.getInstance("SHA-256").digest(b))out.append(String.format(Locale.ROOT,"%02x",x&255));return out.toString();}
 private String xmlHash()throws Exception{return hash(Files.readAllBytes(new File(getTargetContext().getDataDir(),"shared_prefs/"+PREFIX+"wifi_config_overrides_v1.xml").toPath()));}
 public static final class IsolatedContext extends ContextWrapper {
  IsolatedContext(Context base){super(base);}
  @Override public Context getApplicationContext(){return this;}
  @Override public SharedPreferences getSharedPreferences(String name,int mode){return getBaseContext().getSharedPreferences(PREFIX+name,mode);}
 }
 public static final class Connection {public Object c;Connection(Object card){c=card;}}
 private void setup()throws Exception{
  oldContext=type("zl5").getField("f").get(null);oldLibraryContext=type("fj5").getField("d").get(null);
  flow=type("zl5").getField("b").get(null);oldState=flow.getClass().getMethod("getValue").invoke(flow);
  for(String cls:new String[]{"WifiConfigRuntime","CarrierPresets","IdentityBinding"})for(Field f:type("cc.forserein.simhub.internal."+cls).getDeclaredFields())if(Modifier.isStatic(f.getModifiers())&&!Modifier.isFinal(f.getModifiers())){f.setAccessible(true);saved.put(f,f.get(null));}
  isolated=new IsolatedContext(getTargetContext());type("zl5").getField("f").set(null,isolated);type("fj5").getField("d").set(null,isolated);
 }
 private void restore()throws Exception{
  if(flow!=null&&oldState!=null)flow.getClass().getMethod("i",Object.class).invoke(flow,oldState);
  for(Map.Entry<Field,Object> e:saved.entrySet())e.getKey().set(null,e.getValue());
  if(legacyField!=null)legacyField.set(nativeLegacyStore,originalLegacyPreferences);
  if(oldContext!=null)type("zl5").getField("f").set(null,oldContext);if(oldLibraryContext!=null)type("fj5").getField("d").set(null,oldLibraryContext);
 }
 private Object card(int i)throws Exception{return constructor("ek5",8).newInstance("234101234567890","894410000000024400"+i,2,null,null,"+447785016005",null,null);}
 private String key(Object c)throws Exception{return (String)helper("WifiConfigRuntime","cardKey",new Class<?>[]{Object.class},c);}
 private Object current()throws Exception{return flow.getClass().getMethod("getValue").invoke(flow);}
 private void publish(Object card,boolean active)throws Exception{
  Object defaults=helper("WifiConfigModel","builtIn",new Class<?>[]{Object.class},card);
  Object[] fields=new Object[20];for(int i=0;i<20;i++)fields[i]=get(oldState,String.valueOf((char)('a'+i)));
  fields[4]=card;fields[5]=defaults;fields[6]=false;fields[7]="";fields[8]="+199900000000";fields[9]="";fields[10]=active?type("al5").getField("g").get(null):get(oldState,"k");fields[11]=false;fields[17]=false;
  flow.getClass().getMethod("i",Object.class).invoke(flow,constructor("gl5",20).newInstance(fields));
 }
 private Map<String,String> draft(int i){
  Map<String,String> v=new LinkedHashMap<>();
  if(i<2){v.put("smsc",i==0?"+8613800100500":"+8613800200500");v.put("smsc_list","+8613800100500\n+8613800200500");v.put("domain",i==0?"ims-a.example.invalid":"ims-b.example.invalid");v.put("apn","ims");v.put("epdg","epdg-a.example.invalid\nepdg-b.example.invalid");}
  if(i==2){v.put("smsc_list","[]");v.put("epdg","[]");}
  return v;
 }
 private String prepare(Object card)throws Exception{return (String)helper("WifiConfigRuntime","prepareSmsCenter",new Class<?>[]{Object.class},new Connection(card));}
 private boolean blocked(Object card)throws Exception{try{prepare(card);return false;}catch(InvocationTargetException e){if(!(e.getCause() instanceof IllegalStateException))throw e;return true;}}
 private void legacyScope()throws Exception{
  nativeLegacyStore=type("zl5").getMethod("j").invoke(null);check(nativeLegacyStore!=null,"actual native legacy store is available");
  legacyField=nativeLegacyStore.getClass().getField("a");legacyField.setAccessible(true);originalLegacyPreferences=legacyField.get(nativeLegacyStore);
  SharedPreferences testLegacy=isolated.getSharedPreferences("legacy_sms",0);legacyField.set(nativeLegacyStore,testLegacy);
  check(legacyField.get(type("zl5").getMethod("j").invoke(null))==testLegacy,"actual zl5.j store points to isolated fixture preferences during legacy tests");
  SharedPreferences.Editor write=testLegacy.edit();for(int i=0;i<5;i++)write.putString("vowifi_sms_smsc_"+get(card(i),"b"),"+199900000004");
  check(write.commit(),"synthetic legacy SMSC keys stored only in fixture file");
  Object c=card(4);publish(c,true);check("+199900000004".equals(prepare(c)),"same-card upstream legacy SMSC is preserved when no managed record exists");
  c=card(5);publish(c,true);check("+447785016005".equals(prepare(c)),"another ICCID cannot inherit a legacy SMSC");
  c=card(0);publish(c,true);check(draft(0).get("smsc").equals(prepare(c)),"managed SMSC takes precedence over upstream legacy value");
  c=card(2);publish(c,true);check(blocked(c),"managed deleted SMSC list cannot resurrect upstream legacy value");
  c=card(3);publish(c,true);check("+447785016005".equals(prepare(c)),"managed empty overrides use card SMSC without resurrecting upstream legacy value");
  c=card(0);publish(c,true);Class<?> runtime=type("cc.forserein.simhub.internal.WifiConfigRuntime");Field editing=runtime.getDeclaredField("editingSmsKey"),value=runtime.getDeclaredField("editingSmsValue");editing.setAccessible(true);value.setAccessible(true);
  Object oldKey=editing.get(null),oldValue=value.get(null);try{editing.set(null,key(c));value.set(null,"+");check(blocked(c),"incomplete SMS draft cannot be sent using a silently substituted number");}finally{editing.set(null,oldKey);value.set(null,oldValue);}
  legacyField.set(nativeLegacyStore,originalLegacyPreferences);check(legacyField.get(nativeLegacyStore)==originalLegacyPreferences,"native legacy store preference reference restored");
  check(getTargetContext().deleteSharedPreferences(PREFIX+"legacy_sms"),"temporary legacy store file deleted");
 }
 @SuppressWarnings("unchecked") private void cases()throws Exception{
  SharedPreferences prefs=isolated.getSharedPreferences("wifi_config_overrides_v1",0),meta=isolated.getSharedPreferences("upgrade_meta",0);
  if("seed".equals(phase)){
   check(prefs.getAll().isEmpty()&&meta.getAll().isEmpty(),"new retained fixture starts empty");
   for(int i=0;i<4;i++){
    Object c=card(i);publish(c,false);String k=key(c);Map<String,String> values=draft(i);
    helper("WifiConfigRuntime","save",new Class<?>[]{String.class,String.class,Map.class},k,null,values);
    String record=prefs.getString(k,null);check(record!=null&&record.endsWith("\n"),"actual24.3 Runtime.save persists newline-terminated v1 case "+i);
    check(helper("WifiConfigValues","decode",new Class<?>[]{String.class},record).equals(helper("WifiConfigValues","validate",new Class<?>[]{Map.class},values)),"actual24.3 saved values are correct before restart case "+i);
   }
   String archive=xmlHash();check(meta.edit().putString("source_apk","24.3").putString("overrides_xml_sha256",archive).putInt("writer_pid",android.os.Process.myPid()).commit(),"seed manifest committed separately");
   result.putString("persisted_overrides_xml_sha256",archive);result.putBoolean("retained_for_upgrade",true);
  }else{
   check("24.3".equals(meta.getString("source_apk",null)),"records were seeded by baseline24.3");
   check(meta.getInt("writer_pid",-1)!=android.os.Process.myPid(),"records loaded in a separate process");
   String archive=meta.getString("overrides_xml_sha256",null);check(xmlHash().equals(archive),"persisted24.3 XML bytes are untouched before recovery");
   for(int i=0;i<4;i++){
    Object c=card(i);String k=key(c),record=prefs.getString(k,null);check(record.endsWith("\n    "),"actual24.3 file loaded with trailing serializer indentation case "+i);
    if("verify-old".equals(phase)){
     boolean rejected=false;try{helper("WifiConfigValues","decode",new Class<?>[]{String.class},record);}catch(InvocationTargetException e){rejected="配置记录损坏".equals(e.getCause().getMessage());}
     check(rejected,"actual24.3 rejects its own persisted record case "+i);continue;
    }
    Map<String,String> canonical=(Map<String,String>)helper("WifiConfigValues","validate",new Class<?>[]{Map.class},draft(i));
    check(helper("WifiConfigValues","decode",new Class<?>[]{String.class},record).equals(canonical),"upgraded decoder reads baseline record unchanged case "+i);
    publish(c,true);Object snapshot=helper("WifiConfigRuntime","smsSnapshot",new Class<?>[0]);
    check(get(snapshot,"values").equals(canonical),"actual Runtime SMS snapshot restores all baseline fields case "+i);
    check(!Boolean.TRUE.equals(get(snapshot,"needsRepair")),"valid old record no longer falsely requires repair case "+i);
    check(record.equals(get(snapshot,"record"))&&record.equals(prefs.getString(k,null)),"reading keeps exact baseline raw record case "+i);
    if(i<2){
     check(draft(i).get("domain").equals(get(get(current(),"f"),"g")),"actual native gl5 resolves each card's saved IMS domain case "+i);
     check(draft(i).get("smsc").equals(helper("WifiConfigRuntime","prepareSmsCenter",new Class<?>[]{Object.class},new Connection(c))),"same-card SMS helper selects persisted current number case "+i);
     boolean blocked=false;try{helper("WifiConfigRuntime","prepareSmsCenter",new Class<?>[]{Object.class},new Connection(card(1-i)));}catch(InvocationTargetException e){blocked=e.getCause() instanceof IllegalStateException;}
     check(blocked,"different captured card cannot use this card's saved SMSC case "+i);
    }else if(i==2){
     boolean blocked=false;try{helper("WifiConfigRuntime","prepareSmsCenter",new Class<?>[]{Object.class},new Connection(c));}catch(InvocationTargetException e){blocked=e.getCause() instanceof IllegalStateException;}
     check(blocked,"explicit deleted SMSC list does not silently fall back to card number");
    }else check("+447785016005".equals(helper("WifiConfigRuntime","prepareSmsCenter",new Class<?>[]{Object.class},new Connection(c))),"empty override uses same physical card's SMSC");
   }
   if(!"verify-old".equals(phase))legacyScope();
   check(xmlHash().equals(archive),"all legacy reads left baseline XML byte-for-byte unchanged");result.putString("persisted_overrides_xml_sha256",archive);
   result.putBoolean("baseline_corruption_reproduced","verify-old".equals(phase));result.putBoolean("retained_for_upgrade",true);
  }
 }
 @Override public void onCreate(Bundle b){super.onCreate(b);phase=b.getString("phase");start();}
 @Override public void onStart(){Throwable error=null;try{runOnMainSync(()->{});loader=getTargetContext().getClassLoader();setup();cases();}catch(Throwable t){error=t;}finally{try{restore();}catch(Throwable t){if(error==null)error=t;else error.addSuppressed(t);}}
  result.putString("phase",phase);result.putInt("checks",checks);result.putInt("pid",android.os.Process.myPid());result.putString("status",error==null?"passed":"failed");
  result.putString("scope","Actual installed Runtime.save / native gl5 / Runtime snapshots with synthetic cards and private mapped SharedPreferences, retained across upgrade. prepareSmsCenter uses an inert connection object carrying its captured card; no o82.D send, APDU, audio or network. Original in-memory state/context restored; production preferences untouched.");
  if(error!=null)result.putString("error",android.util.Log.getStackTraceString(error));finish(error==null?0:1,result);
 }
}
