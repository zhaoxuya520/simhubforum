package carriersmoke;

import android.app.*;
import android.content.*;
import android.os.*;
import android.graphics.Bitmap;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.lang.reflect.*;
import java.util.*;
import java.io.*;

/** Real native Compose and accessibility actions, with synthetic isolated SMS/IMS state only. */
public final class SmsUiSmoke extends Instrumentation {
 private ClassLoader loader;private Activity activity;private int checks;
 private final LinkedHashMap<Field,Object> saved=new LinkedHashMap<>();
 private CarrierSmoke.IsolatedContext isolated;private Object flow,oldState,oldContext,oldLibraryContext,card,config,phase;
 private SharedPreferences preferences;private String key;private final ArrayList<String> screenshots=new ArrayList<>();
 private static final String A="+639980000011",B="+639980000012",C="+639980000013";
 private Class<?> type(String name)throws Exception{return Class.forName(name,true,loader);}
 private Object get(Object object,String name)throws Exception{Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
 private void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;}
 private Object helper(String name,String method,Class<?>[] types,Object...args)throws Exception{return type("cc.forserein.simhub.internal."+name).getMethod(method,types).invoke(null,args);}
 private Object state()throws Exception{return flow.getClass().getMethod("getValue").invoke(flow);}
 private Constructor<?> constructor(Class<?> type,int count){for(Constructor<?> c:type.getDeclaredConstructors())if(c.getParameterTypes().length==count){c.setAccessible(true);return c;}throw new AssertionError(type.getName());}
 private void remember(String name)throws Exception{for(Field f:type(name).getDeclaredFields())if(Modifier.isStatic(f.getModifiers())&&!Modifier.isFinal(f.getModifiers())){f.setAccessible(true);saved.put(f,f.get(null));}}
 private void setup()throws Exception{
  oldContext=type("zl5").getField("f").get(null);oldLibraryContext=type("fj5").getField("d").get(null);
  flow=type("zl5").getField("b").get(null);oldState=state();isolated=new CarrierSmoke.IsolatedContext(getTargetContext());
  type("zl5").getField("f").set(null,isolated);type("fj5").getField("d").set(null,isolated);
  remember("cc.forserein.simhub.internal.WifiConfigRuntime");remember("cc.forserein.simhub.internal.CarrierPresets");remember("cc.forserein.simhub.internal.WifiConfigEditor");
  card=constructor(type("ek5"),8).newInstance("515660000000036","8963660000000000036",2,null,null,null,null,null);
  config=helper("DitoCarrierProfile","defaults",new Class<?>[]{Object.class},card);phase=type("al5").getField("g").get(null);
  Object[] fields=new Object[20];for(int i=0;i<fields.length;i++)fields[i]=get(oldState,String.valueOf((char)('a'+i)));
  fields[4]=card;fields[5]=config;fields[6]=false;fields[7]="";fields[8]=A;fields[9]="490154203237518";fields[10]=phase;fields[11]=false;fields[17]=false;
  key=(String)helper("WifiConfigRuntime","cardKey",new Class<?>[]{Object.class},card);
  Map<String,String> values=new LinkedHashMap<>();values.put("smsc",A);values.put("smsc_list",A+"\n"+B);values.put("domain","art.example.org");values.put("imei","490154203237518");
  String record=(String)helper("WifiConfigValues","encode",new Class<?>[]{Map.class},values);preferences=isolated.getSharedPreferences("wifi_config_overrides_v1",0);
  check(preferences.edit().putString(key,record).commit(),"synthetic SMS values stored only in temporary preferences");
  Object rawDefault=config;flow.getClass().getMethod("i",Object.class).invoke(flow,constructor(type("gl5"),20).newInstance(fields));
  config=get(state(),"f");phase=get(state(),"k");
  check(get(card,"f")==null,"synthetic card matches missing EF_SMSP null condition");
  check("art.example.org".equals(get(config,"g")),"actual native gl5 constructor activates persisted synthetic configuration");
  check(config!=rawDefault,"actual published config differs from raw constructor argument after native override resolution");
  android.util.Log.i("SmsArtFixture","rawConfigHash="+System.identityHashCode(rawDefault)+" publishedConfigHash="+System.identityHashCode(config)+" phaseHash="+System.identityHashCode(phase));
  check(Boolean.TRUE.equals(phase.getClass().getMethod("z").invoke(phase)),"actual native Ready phase is treated as active IMS");
  try{helper("WifiConfigRuntime","snapshot",new Class<?>[0]);throw new AssertionError("ordinary config allowed active IMS");}catch(InvocationTargetException expected){check(expected.getCause() instanceof IllegalStateException,"ordinary config guard remains active");}
  check(helper("WifiConfigRuntime","smsSnapshot",new Class<?>[0])!=null,"SMS snapshot is available in synthetic active IMS");
 }
 private Object callback(String name,java.util.function.Function<Object[],Object> action)throws Exception{
  return Proxy.newProxyInstance(loader,new Class<?>[]{type(name)},(proxy,method,args)->{
   if(method.getDeclaringClass()==Object.class){if(method.getName().equals("equals"))return proxy==args[0];if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);return "SyntheticSmsUi";}
   return action.apply(args);
  });
 }
 private Object composable(int id,Object callback)throws Exception{return type("zn0").getConstructor(int.class,boolean.class,type("gt1")).newInstance(id,true,callback);}
 private void render()throws Exception{
  Object body=callback("kt1",args->{try{
   String value=(String)get(state(),"i");helper("WifiConfigEditor","smsCenterEntry",new Class<?>[]{String.class,Object.class},value,args[0]);return type("sc5").getField("a").get(null);
  }catch(Exception error){throw new RuntimeException(error);}});
  final Object inner=composable(236001,body);
  Object theme=callback("kt1",args->{try{
   type("z55").getMethod("a",type("zn0"),type("lu1"),int.class).invoke(null,inner,args[0],0);return type("sc5").getField("a").get(null);
  }catch(Exception error){throw new RuntimeException(error);}});
  type("sn0").getMethod("a",type("rn0"),type("zn0")).invoke(null,activity,composable(236002,theme));
 }
 private AccessibilityNodeInfo find(AccessibilityNodeInfo root,String text,boolean editable){
  if(root==null)return null;CharSequence value=root.getText();
  if(value!=null&&(editable?value.toString().equals(text):value.toString().equals(text)||value.toString().startsWith(text))&&(!editable||root.isEditable()))return root;
  for(int i=0;i<root.getChildCount();i++){AccessibilityNodeInfo found=find(root.getChild(i),text,editable);if(found!=null)return found;}return null;
 }
 private AccessibilityNodeInfo await(String text,boolean editable)throws Exception{
  long end=SystemClock.uptimeMillis()+45000;while(SystemClock.uptimeMillis()<end){AccessibilityNodeInfo node=find(getUiAutomation().getRootInActiveWindow(),text,editable);if(node!=null)return node;SystemClock.sleep(200);}throw new AssertionError("Actual accessibility node unavailable: "+text+" editable="+editable+" tree="+tree(getUiAutomation().getRootInActiveWindow(),0));
 }
 private String tree(AccessibilityNodeInfo node,int depth){if(node==null||depth>15)return "";StringBuilder out=new StringBuilder();out.append(node.getClassName()).append(':').append(node.getText()).append(':').append(node.isClickable()).append(':').append(node.isEditable()).append('\n');for(int i=0;i<node.getChildCount();i++)out.append(tree(node.getChild(i),depth+1));return out.toString();}
 private void click(String text)throws Exception{AccessibilityNodeInfo node=await(text,false);while(node!=null&&!node.isClickable())node=node.getParent();check(node!=null&&node.performAction(AccessibilityNodeInfo.ACTION_CLICK),"actual accessibility click: "+text);}
 private void cancel()throws Exception{sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);waitClosed();check(current()==null,"actual Android Back invokes dialog cancel/dismiss");}
 private void replace(String before,String after)throws Exception{AccessibilityNodeInfo node=await(before,true);Bundle args=new Bundle();args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,after);check(node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args),"actual editable SMS text changed via accessibility");await(after,true);}
 private Object current()throws Exception{Field f=type("cc.forserein.simhub.internal.WifiConfigEditor").getDeclaredField("current");f.setAccessible(true);return f.get(null);}
 private void waitClosed()throws Exception{long end=SystemClock.uptimeMillis()+45000;while(SystemClock.uptimeMillis()<end){final Object[] value={null};runOnMainSync(()->{try{value[0]=current();}catch(Exception e){throw new RuntimeException(e);}});if(value[0]==null)return;SystemClock.sleep(100);}throw new AssertionError("SMS session did not close");}
 private void screenshot(String name)throws Exception{Bitmap bitmap=getUiAutomation().takeScreenshot();check(bitmap!=null,"actual native Compose screenshot captured");File file=new File(getTargetContext().getExternalFilesDir(null),name);try(FileOutputStream out=new FileOutputStream(file)){if(!bitmap.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("screenshot failed");}screenshots.add(file.getAbsolutePath());}
 @SuppressWarnings("unchecked") private void cases()throws Exception{
  String before=preferences.getString(key,null);click("短信中心 · ");await("保存",false);check(current()!=null,"actual SMS entry opens standalone editor while IMS remains active");
  screenshot("synthetic-sms236-open.png");replace(A,C);check(before.equals(preferences.getString(key,null)),"editing real input does not save immediately");
  cancel();check(before.equals(preferences.getString(key,null)),"actual Cancel discards unsaved SMS edits");
  click("短信中心 · ");await("保存",false);replace(A,C);click("保存");waitClosed();
  Map<String,String> values=(Map<String,String>)helper("WifiConfigValues","decode",new Class<?>[]{String.class},preferences.getString(key,null));
  check(C.equals(values.get("smsc"))&&(C+"\n"+B).equals(values.get("smsc_list")),"actual Save replaces current SMSC and retains alternative");
  android.util.Log.i("SmsArtFixture","savedConfigHash="+System.identityHashCode(get(state(),"f"))+" savedPhaseHash="+System.identityHashCode(get(state(),"k")));
  check(get(state(),"f")==config&&get(state(),"k")==phase,"SMS save preserves exact active config and phase objects");
  check(C.equals(get(state(),"i"))&&"art.example.org".equals(values.get("domain")),"SMS save updates live number and retains unrelated saved config");
  click("短信中心 · ");await(C,true);await(B,true);screenshot("synthetic-sms236-saved.png");cancel();
 }
 private void cleanup()throws Exception{
  if(activity!=null){runOnMainSync(()->activity.finish());waitForIdleSync();}
  if(flow!=null&&oldState!=null)flow.getClass().getMethod("i",Object.class).invoke(flow,oldState);
  for(Map.Entry<Field,Object> item:saved.entrySet())item.getKey().set(null,item.getValue());
  if(oldContext!=null)type("zl5").getField("f").set(null,oldContext);if(oldLibraryContext!=null)type("fj5").getField("d").set(null,oldLibraryContext);
  if(isolated!=null)isolated.clean();
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);start();}
 @Override public void onStart(){Bundle result=new Bundle();Throwable problem=null;boolean cleaned=false;
  try{runOnMainSync(()->{});loader=getTargetContext().getClassLoader();activity=startActivitySync(new Intent().setClassName("cc.forserein.simhub","cc.forserein.simhub.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));waitForIdleSync();
   final Throwable[] failed={null};runOnMainSync(()->{try{setup();render();}catch(Throwable e){failed[0]=e;}});if(failed[0]!=null)throw failed[0];cases();
  }catch(Throwable e){problem=e;}finally{try{cleanup();cleaned=true;}catch(Throwable e){if(problem==null)problem=e;else problem.addSuppressed(e);}}
  result.putInt("checks",checks);result.putBoolean("synthetic_state_cleaned",cleaned);result.putStringArrayList("actual_screenshots",screenshots);result.putString("scope","Real native Compose SMS entry, inputs, Cancel and Save through accessibility; synthetic active IMS/card and isolated preferences. No SIM/APDU/network/audio.");
  if(problem==null){result.putString("status","passed");finish(0,result);}else{result.putString("status","failed");result.putString("error",android.util.Log.getStackTraceString(problem));finish(1,result);}
 }
}
