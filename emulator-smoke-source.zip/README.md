# Offline Android ART SIP validation

`SipFailureSmoke` invokes the installed application's real `o82.h`, native dialog manager, SIP builders, `o82.C`, and `o82.E`. No application method is replaced or patched for testing.

The engine is an isolated synthetic instance, with the real in-memory `jf2` TCP stack, an empty connection map, and no packet-output callback. The transport uses an intentionally absent connection ID. Native `C` copies intended TCP messages into its normal `V` queue before `E` discards them because that connection does not exist. This allows ACK construction and dialog state to be checked without opening a socket, contacting IMS, authenticating a SIM, or touching audio. Test identities use reserved example.invalid and documentation IP addresses.

The instrumentation waits for Application initialization, then uses only local objects; it does not replace application globals or persisted user settings. The actual dual-chip instrumentation from 24.0 is also rerun unchanged against the final APK. No physical phone is attached.

The final driver verifies same-signature upgrade from the exact signed 24.0 baseline to 24.1/code20, installed APK bytes, ART results, cold launch and captured app errors. Any successful report is an offline control-flow/serialization result, not a claim that a real operator will stop returning 487.

## Baseline reproduction and coverage limits

On signed 24.0/code19, the native dispatcher first accepts a synthetic 200 response and confirms its dialog. Feeding the matching original INVITE 487 then removes that confirmed dialog. The assertion failure is retained in `baseline24.0-sip-art.txt`; `baseline-fixture-manifest.json` records the original fixture/app hashes. The initial fixture-only constructor failure (an empty synthetic ICCID was incorrectly passed as null) is retained separately and is not claimed as an application defect.

The final focused cases cover confirmed-dialog preservation and its ACK, genuine pending failure, duplicate 487 ACK after dialog removal, stale CSeq, wrong branch/local tag, UPDATE failure isolation, and real local-CANCEL actions followed by 487. The call-UI event callback is not connected: the ART test inspects the real cancellation action's reason and SIP/dialog outcomes, but does not claim full UI-event lifecycle validation. No audio object is started.
