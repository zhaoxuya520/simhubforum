# Android ART validation, 24.3 → 24.4

The application itself is installed only after the root agent provides its signed
APK hash. `validate.py` verifies that the installed predecessor is the exact
signed 24.3, checks the unchanged signer, then installs 24.4 and verifies the
installed bytes/version. No physical phone or SIM is attached.

New instrumentation source is in
`/workspace/recovery/stable24.3-review/emulator/config-harness`:

- `ConfigFormatSmoke.java`: six synthetic configuration maps through actual APK
  validation/encoding, real Android SharedPreferences, process termination and
  a second process. Tests SMSC, multiple SMSCs, multiple ePDGs, IMS/APN, empty
  overrides and explicit empty lists. Fixed-mode also writes old v1 records
  before the restart to exercise actual XML-added trailing indentation.
- `UpgradeConfigSmoke.java`: actual 24.3 `WifiConfigRuntime.save` created four
  synthetic per-card records. A separate 24.3 process proved that its decoder
  rejected them. The files remain in isolated preferences during the APK
  upgrade. Actual 24.4 Runtime/native state objects must read them without
  changing the original XML SHA-256. Captured-card SMS preparation and legacy
  SMSC selection are tested without calling the SMS sender. The native legacy
  store preference reference is temporarily redirected to an isolated file and
  then restored; no production legacy keys are written.
- `PreconditionSmoke.java`: explicit synthetic early native dialogs provide the
  already-created INVITE/offer. Actual `o82.h` handles 183, emits a bodyless
  PRACK, handles the PRACK 200, and invokes the real `qa1`/`cb4.k` to build UPDATE.
  The original native TCP stack is empty, so `o82.C` records intent and discards
  packets without sockets. `sec-agree`, SDP content and dialog binding are
  checked in both negotiated and non-negotiated cases. No initial f82 INVITE
  creation, Gm encryption, audio or operator exchange is claimed by this test.

Immutable baseline sources/APK hashes and logs are retained in the sibling
`stable24.3-review/emulator` folder. `upgrade24.3-harness` contains the exact
fixture used to seed and cold-read the retained records;
`precondition24.3-harness` contains the exact protocol baseline fixture.
`baseline-six-records/validation.json` records 45 baseline assertions including
actual cross-process XML corruption. The earlier four-record reproduction is
also retained separately. The canonical retained XML hash is
`30f08f246c9abbde1d6f8809d178f4286f03ea4270521658c385d332845e7e33`.

The original 24.3 success/retransmission, 24.2 terminal/progress/fallback,
24.1 487 and 24.0 dual-chip instrumentation APKs are rerun without modification.
Their hashes are reported separately. Dual-chip transport remains synthetic.

Final output is `/workspace/recovery/call24.4-release/emulator-validation.json`.
It must say `passed`, match the final signed APK hash and accurately distinguish
synthetic ART behavior from physical carrier operation. Reported test numbers
never imply a real SMS was delivered or a call connected.
