# Android ART validation scope

The emulator preserves the installed 23.9/code18 application and user data. No physical device is attached. `validate.py` runs only after the root agent provides the final signed 24.0 APK and its SHA-256.

`SwitchSmoke` is an independently signed instrumentation package. It loads the installed application's actual `hz3`, `hh1`, `iz3`, `pg1`, `rf1`, `vf1`, `qy3`, and `xx3` classes by reflection; it does not replace their bytecode or package alternative copies. The only device substitute is a `qg0` interface proxy, which answers normal logical-channel and ES10c commands entirely from in-memory synthetic chips. No USB, Bluetooth, OMAPI, modem, or real card transport is opened.

The two synthetic management AIDs are the exact eSTK SE0/SE1 pair ending `2030` and `2031`; the synthetic EIDs and ICCIDs are generated test identifiers. This validates the ordinary reader path on Android ART. It does not claim Android OMAPI/phone-slot or physical eUICC firmware validation.

The independent 23.9 AKA instrumentation is rerun unchanged on the candidate, covering ordinary synthetic Identity retransmissions without authentication, networking, or APDU calls. The driver also checks same-certificate upgrade, version, installed APK bytes, cold startup, and app fatal/verification/linkage logs.

Any final report must disclose actual completed cases and cannot infer real-card/network success from synthetic tests.

## Baseline evidence

Before the candidate was installed, the same instrumentation was run against the signed 23.9/code18 APK. `baseline23.9-switch-art.txt` records the old behavior: the native worker completes and emits only `enable1=0`, leaving chip A active. Both logical channels are closed. This establishes that the fixture reaches the real old path and reproduces the reported defect.

The first fixture run exposed a missing fixed reader-initialization command (`80AA00000AA9088100820101830107`), not an application failure. The synthetic transport now answers that exact command with `9000`, consistent with its ignored status in the native opener. The initial trace is retained separately as `baseline23.9-fixture-missing-reader-init.txt`.
