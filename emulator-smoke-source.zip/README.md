# 24.2 independent Android ART validation

The emulator retains signed 24.1/code20. `baseline24.1/` freezes the previous passing report, original SIP487 instrumentation source/APK and its hashes. The installed 24.1 APK hash was independently checked before reproducing any new case. No physical device is attached.

The new instrumentation directly invokes installed `o82.h`, `o82.C`, the dialog manager and native SIP builders. Its real in-memory `jf2` TCP stack has an empty connection map and no output callback; intended packets are inspected in native `V` before the missing-connection path discards them. There are no replaced application methods, opened sockets, SIM operations, RTP/audio or real numbers.

Signed 24.1 baseline evidence:

- `baseline24.1-terminal-art.txt`: a real 200 confirms A, then matching original INVITE 486 incorrectly removes A.
- `baseline24.1-late180-art.txt`: post-200 180 changes the confirmed dialog snapshot.
- `baseline24.1-late183-art.txt`: post-200 reliable183 changes the confirmed dialog snapshot.

The final fixture covers 486/500/603 terminal response correlation and duplicate ACKs, late180/183 isolation after confirmation (including terminating state), and normal pre-answer progress. The exact previously passed 24.1 SIP487 instrumentation and 24.0 dual-chip instrumentation are rerun unchanged. Their APK hashes are included in the final report.

The call-UI callback remains disconnected. Native dialog, packet and cancellation-action state are verified, but UI event delivery, real carrier acceptance, physical cards and audio are outside this offline test's coverage.

The reliable-provisional fixture also reproduces the 24.1 defect after normal100→180→RSeq47: a repeated47 changes the native dialog snapshot. `baseline24.1-reliable-art.txt` records that failure after the first native PRACK was verified. The final chain checks repeated47 and gap49 produce no extra PRACK or state/media change; next48 and then49 are processed normally, and another To-tag B may independently start at12. Each generated PRACK's real RAck header is checked.

The final instrumentation also calls `SipInviteTransport.onFallbackSent` directly with actual native pending dialogs and native `ka4`/`ja4` timer objects constructed in the verified `f82` initial-TCP shape (interval/next Infinity, deadline now+32, original request/branch). It verifies exact UDP Via synchronization, preservation of the old immutable header pair and original timer/deadline, activation of the 500ms cadence, and rejection of a mismatched branch. These two helper calls do not execute the `a82` TCP failure dispatcher or send any packet; the full native fallback path is covered separately by the host probe.

The native `cb4.p` method returns early for TCP, so it is not used to create these fallback-fixture timers. This ART helper case does not claim execution of the initial `f82` timer creation either.

For reproducibility on the preserved 24.1 APK, run the new instrumentation with `-e case late180`, `-e case late183`, or `-e case reliable`; its default path reaches the delayed486 assertion first. These are expected baseline failures, not successful candidate test results. Final validation runs the complete default suite against the explicitly supplied signed 24.2 hash.
