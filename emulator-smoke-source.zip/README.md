# 24.3 independent Android ART validation

The installed signed 24.2/code21 APK was verified by device-side SHA-256 before testing. `baseline24.2/` freezes its original passing report and TerminalFailureSmoke fixture; its prior487 fixture is preserved unchanged too. The original dual-chip fixture remains unchanged. Final reports include all three prior APK hashes.

The new fixture executes the installed application's actual `o82.h`, `o82.r`, `o82.C/E`, `cb4`, `f82` and native SIP parser/builders. It inspects the ordinary `V` packet queue before the intentionally nonexistent native TCP connection discards each packet. No application method is replaced, socket opened, real number called or SIM/audio operation started. All messages/identities are synthetic.

24.2 baseline action traces show:

- CANCEL→first200 sends ACK/11 and BYE/12; repeated200 sends another BYE/13 and changes dialog A/h fields.
- After the real cleanup BYE200 removes the dialog, repeated200 gets no ACK.
- Ordinary selected200 retransmission sends one ACK but its bytes differ; the dialog fields themselves stay unchanged.
- Incoming decline603 or remote-CANCEL487 followed by ACK removes the dialog, but a delayed duplicate initial INVITE creates another dialog and responds180.
- Another native local hangup while already terminating is not a no-op.

Final tests assert cached identical ACKs, no repeated BYE/state resurrection, no-op terminating local controls, and cached incoming603/487 with no rebuilt dialog. Incoming positive cases permit a newer CSeq or a new Call-ID. The three previous instrumentation APKs are rerun without modification.

The call-UI callback is disconnected. An inert K marker prevents the independent background timer loop from starting during incoming tests. Thus ART checks real dialog/actions/packets and timer state, not audible ringing, scheduled timer callbacks, network delivery, physical cards or media. Prior24.2 fallback coverage remains explicitly helper-level in ART; its full native dispatch is covered separately by host tests.
