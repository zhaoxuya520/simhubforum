package switchsmoke;

import android.app.Instrumentation;
import android.os.Bundle;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;

/** Calls installed APK classes. All card responses come from this in-memory transport. */
public final class SwitchSmoke extends Instrumentation {
 private ClassLoader loader;private int checks,opens,closes,commands,totalCommands,nativeCalls;private String entry="hz3";
 private final List<String> writes=new ArrayList<>();private final ArrayList<String> completed=new ArrayList<>();
 private final String[] EID={"89010000000000000000000000000001","89010000000000000000000000000002"};
 private final String[] AID={"A06573746B6D65FFFF4953442D522030","A06573746B6D65FFFF4953442D522031"};
 private final String[] ICC={"89123456789000100001","89123456789000200002"};
 private boolean[] enabled;private int wrongEidChip=-1,forcedResult=-1;private boolean applyRejectedChange;private String forcedOperation;private final Map<Integer,Integer> channels=new HashMap<>();private int nextChannel=1;
 private Class<?> type(String n)throws Exception{return Class.forName(n,true,loader);}
 private Object get(Object o,String n)throws Exception{Field f=o.getClass().getField(n);f.setAccessible(true);return f.get(o);}
 private void set(Object o,String n,Object v)throws Exception{Field f=o.getClass().getField(n);f.setAccessible(true);f.set(o,v);}
 private Object staticField(String c,String f)throws Exception{return type(c).getField(f).get(null);}
 private void check(boolean v,String label){if(!v)throw new AssertionError(label+" writes="+writes);checks++;}
 private Throwable cause(Throwable failure,String name){for(int i=0;failure!=null&&i<12;i++,failure=failure.getCause())if(failure.getClass().getName().equals(name))return failure;return null;}
 private Object create(String c,Object...args)throws Exception{
  for(Constructor<?> k:type(c).getConstructors()){Class<?>[] p=k.getParameterTypes();if(p.length!=args.length)continue;boolean match=true;
   for(int i=0;i<p.length;i++)if(args[i]!=null&&!p[i].isInstance(args[i])&&!(p[i]==boolean.class&&args[i] instanceof Boolean))match=false;
   if(match)return k.newInstance(args);
  }throw new AssertionError("No matching actual constructor "+c);
 }
 private Object call(Object o,String n,Class<?>[] p,Object...v)throws Exception{
  try{return o.getClass().getMethod(n,p).invoke(o,v);}catch(InvocationTargetException ex){Throwable cause=ex.getCause();if(cause instanceof Exception)throw(Exception)cause;throw(Error)cause;}
 }
 private byte[] bytes(String h){byte[] out=new byte[h.length()/2];for(int i=0;i<out.length;i++)out[i]=(byte)Integer.parseInt(h.substring(i*2,i*2+2),16);return out;}
 private String hex(byte[] b){StringBuilder out=new StringBuilder();for(byte v:b)out.append(String.format(Locale.ROOT,"%02X",v));return out.toString();}
 private String tlv(String t,String v){return t+String.format(Locale.ROOT,"%02X",v.length()/2)+v;}
 private String bcd(String id){StringBuilder b=new StringBuilder();for(int i=0;i<id.length();i+=2)b.append(id.charAt(i+1)).append(id.charAt(i));return b.toString();}
 private String record(int chip){return tlv("E3",tlv("5A",bcd(ICC[chip]))+tlv("9F70",enabled[chip]?"01":"00"));}
 private Object profile(int chip,boolean on)throws Exception{return create("qy3",ICC[chip],on,"Synthetic",null,null,null,null);}
 private byte[] transmit(byte[] apdu){
  commands++;totalCommands++;String command=hex(apdu);if(apdu.length<4)throw new AssertionError("Short synthetic APDU");
  int cla=apdu[0]&255,ins=apdu[1]&255,p1=apdu[2]&255,p2=apdu[3]&255;
  if(ins==0x70){if(p1==0){int ch=nextChannel++;if(ch>3){nextChannel=2;ch=1;}channels.put(ch,-1);opens++;return new byte[]{(byte)ch,(byte)0x90,0};}
   if(p1==0x80){if(channels.remove(p2)!=null)closes++;return bytes("9000");}}
  if(command.equals("80AA00000AA9088100820101830107"))return bytes("9000");
  int ch=cla&3;
  if(ins==0xA4){int count=apdu[4]&255;String aid=hex(Arrays.copyOfRange(apdu,5,5+count));int chip=Arrays.asList(AID).indexOf(aid);if(chip<0)throw new AssertionError("Unknown synthetic AID "+aid);channels.put(ch,chip);return bytes("9000");}
  Integer chip=channels.get(ch);if(ins!=0xE2||chip==null||chip<0||apdu.length<7)throw new AssertionError("Unexpected synthetic APDU "+command);
  String op=command.substring(10,14),body;
  if(op.equals("BF3E"))body=tlv("5A",EID[chip==wrongEidChip?1-chip:chip]);
  else if(op.equals("BF2D"))body=tlv("A0",record(chip));
  else if(op.equals("BF28"))body=tlv("A0","");
  else if(op.equals("BF31")||op.equals("BF32")){
   check(command.contains(tlv("5A",bcd(ICC[chip]))),"operation ICCID belongs to selected synthetic AID");
   boolean on=op.equals("BF31");int result=enabled[chip]==on?2:0;
   if(op.equals(forcedOperation)&&forcedResult>=0){result=forcedResult;forcedResult=-1;if(applyRejectedChange)enabled[chip]=on;}
   if(result==0)enabled[chip]=on;
   writes.add((on?"enable":"disable")+chip+"="+result);body=tlv("80",String.format(Locale.ROOT,"%02X",result));
  }else throw new AssertionError("Unhandled synthetic ES10c operation "+command);
  return bytes(tlv(op,body)+"9000");
 }
 private Object setup(boolean a,boolean b,boolean uiA,boolean uiB)throws Exception{
  enabled=new boolean[]{a,b};writes.clear();channels.clear();opens=0;closes=0;commands=0;nextChannel=1;wrongEidChip=-1;forcedResult=-1;forcedOperation=null;applyRejectedChange=false;
  Object transport=Proxy.newProxyInstance(loader,new Class<?>[]{type("qg0")},(o,m,v)->{
   switch(m.getName()){case "a":return 240;case "b":return null;case "c":return transmit((byte[])v[0]);case "d":return false;case "e":return false;case "f":return true;case "g":return "Synthetic dual eSTK reader";case "close":return null;case "hashCode":return System.identityHashCode(o);case "equals":return o==v[0];case "toString":return "Synthetic dual eSTK reader";default:throw new AssertionError(m.toString());}
  });
  Object manager=create("hh1",transport),controller=create("iz3",getTargetContext());set(controller,"d",manager);
  type("xl3").getMethod("setValue",Object.class).invoke(get(controller,"c"),transport);
  List<Object> chips=new ArrayList<>();for(int i=0;i<2;i++)chips.add(create("xx3",bytes(AID[i]),EID[i],null,Collections.singletonList(profile(i,i==0?uiA:uiB)),null,null));
  type("xl3").getMethod("setValue",Object.class).invoke(get(controller,"k"),chips);call(controller,"D",new Class<?>[]{String.class},EID[0]);return controller;
 }
 private Object tap(Object controller,int chip,boolean on)throws Exception{
  call(controller,"D",new Class<?>[]{String.class},EID[chip]);List<?> chips=(List<?>)call(controller,"l",new Class<?>[0]);Object target=((List<?>)get(chips.get(chip),"d")).get(0);
  Object frame=create(entry,controller,target,on,null);final Object[] delivered={null};CountDownLatch done=new CountDownLatch(1);
  Object continuation=Proxy.newProxyInstance(loader,new Class<?>[]{type("ct0")},(o,m,v)->{if(m.getName().equals("h"))return staticField("qd1","T");if(m.getName().equals("s")){delivered[0]=v[0];done.countDown();return null;}throw new AssertionError(m.toString());});
  nativeCalls++;Object result=call(frame,"f",new Class<?>[]{Object.class,Object.class},get(controller,"d"),continuation);
  if(result==staticField("pu0","T")){check(done.await(30,TimeUnit.SECONDS),"native coroutine completes within bounded time");result=delivered[0];type("oc2").getMethod("N",Object.class).invoke(null,result);}
  return result;
 }
 private boolean cached(Object c,int chip)throws Exception{List<?> chips=(List<?>)call(c,"l",new Class<?>[0]);return(Boolean)get(((List<?>)get(chips.get(chip),"d")).get(0),"b");}
 private void cases()throws Exception{
  for(String n:new String[]{"hh1","iz3","hz3","pg1","rf1","vf1","qy3","xx3"}){type(n).getDeclaredMethods();checks++;}
  Object c=setup(true,false,true,false);Object result=tap(c,1,true);
  check(result==staticField("sc5","a"),"actual switch worker completes");check(!enabled[0]&&enabled[1],"cross-chip A to B leaves only B active");check(!cached(c,0)&&cached(c,1),"both actual controller caches match A to B");
  check(writes.equals(Arrays.asList("disable0=0","enable1=0")),"A disabled before B enabled");check(opens==closes&&channels.isEmpty(),"logical channels released after actual-native-A-to-B");completed.add("actual-native-A-to-B");
  writes.clear();tap(c,0,true);check(enabled[0]&&!enabled[1],"cross-chip B to A leaves only A active");check(cached(c,0)&&!cached(c,1),"both actual controller caches match B to A");check(writes.equals(Arrays.asList("disable1=0","enable0=0")),"B disabled before A enabled");check(opens==closes&&channels.isEmpty(),"logical channels released after actual-native-B-to-A");completed.add("actual-native-B-to-A");
  c=setup(false,true,true,true);tap(c,0,false);check(!cached(c,0),"stale enabled UI reconciled from same chip card read");check(enabled[1]&&cached(c,1),"manual disable leaves other active chip intact");check(opens==closes&&channels.isEmpty(),"logical channels released after manual-disable-stale-cache");completed.add("manual-disable-stale-cache");
  c=setup(true,false,true,false);forcedOperation="BF32";forcedResult=2;applyRejectedChange=true;
  tap(c,1,true);check(!enabled[0]&&enabled[1],"code 2 accepted only after requested state is observed");check(!cached(c,0)&&cached(c,1),"verified code 2 state published to actual controller");check(opens==closes&&channels.isEmpty(),"logical channels released after code2-confirmed-by-same-chip-readback");completed.add("code2-confirmed-by-same-chip-readback");
  c=setup(true,false,true,false);forcedOperation="BF32";forcedResult=2;applyRejectedChange=false;Throwable rejected=null;
  try{tap(c,1,true);}catch(Exception problem){rejected=problem;}
  check(cause(rejected,"ze0")!=null,"unconfirmed code 2 propagates original native card rejection, not fixture failure");check(enabled[0]&&!enabled[1],"unconfirmed source disable never enables target");check(!writes.toString().contains("enable"),"unconfirmed source disable issues no target enable");check(opens==closes&&channels.isEmpty(),"logical channels released after code2-unconfirmed-state-rejected");completed.add("code2-unconfirmed-state-rejected");
  c=setup(true,false,true,false);wrongEidChip=0;Throwable mismatch=null;
  try{tap(c,1,true);}catch(Exception problem){mismatch=problem;}
  check(cause(mismatch,"cc.forserein.simhub.internal.EstkSwitchPlan$BoundaryFailure")!=null,"wrong EID propagates actual planner boundary failure");check(writes.isEmpty(),"wrong EID detected before any state-changing command");check(enabled[0]&&!enabled[1],"wrong EID leaves both synthetic chip states untouched");check(opens==closes&&channels.isEmpty(),"logical channels released after wrong-EID-stops-before-mutation");completed.add("wrong-EID-stops-before-mutation");
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);if(args!=null&&args.getString("entry")!=null)entry=args.getString("entry");start();}
 @Override public void onStart(){Bundle result=new Bundle();Throwable error=null;try{runOnMainSync(()->{});loader=getTargetContext().getClassLoader();cases();}catch(Throwable problem){error=problem;}
  result.putInt("checks",checks);result.putInt("native_switch_calls",nativeCalls);result.putInt("total_synthetic_apdus",totalCommands);result.putInt("last_case_synthetic_apdus",commands);result.putInt("last_case_channel_opens",opens);result.putInt("last_case_channel_closes",closes);result.putInt("physical_apdu_calls",0);result.putStringArrayList("completed_cases",completed);
  result.putString("scope","Actual installed native switch worker and controller with a synthetic qg0 reader; logical-channel selection and ES10c replies are generated in memory. No native method replacement and no physical card operation.");
  if(error==null){result.putString("status","passed");finish(0,result);}else{result.putString("status","failed");result.putString("error",android.util.Log.getStackTraceString(error));finish(1,result);}
 }
}
