import java.util.ArrayList;
import java.util.List;
/** Emulator-only transport sink. It cannot access or send through a socket. */
public final class ForkTransport {
 public Object J;
 public final Sink g=new Sink();
 public final List<Object> packets=new ArrayList<Object>();
 public void C(kb4 packet){packets.add(packet);}
 public void k(List<?> actions)throws Exception{
  for(Object action:actions)C((kb4)action.getClass().getField("a").get(action));
 }
 public static final class Sink {public Object i(Object text){return null;}}
}
