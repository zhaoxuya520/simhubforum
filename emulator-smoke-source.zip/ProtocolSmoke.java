package protocolsmoke;
import android.app.Instrumentation;
import android.os.Bundle;
import java.lang.reflect.*;
import java.util.*;
/** Emulator-only offline ART smoke test. No network, SIM, microphone, or application-state edits. */
public final class ProtocolSmoke extends Instrumentation {
 private ClassLoader loader;private int checks;private ArrayList<String> loaded=new ArrayList<>();
 private Class<?> type(String name)throws Exception {return Class.forName(name,true,loader);}
 private void check(boolean value,String what){if(!value)throw new AssertionError(what);checks++;}
 private Object get(Object value,String field)throws Exception{return value.getClass().getField(field).get(value);}
 private void set(Object value,String field,Object next)throws Exception{value.getClass().getField(field).set(value,next);}
 private Object message(boolean request,String method,int status)throws Exception{return type("kb4").getConstructor(boolean.class,String.class,String.class,int.class,String.class,ArrayList.class,byte[].class).newInstance(request,method,"sip:peer@example.invalid",status,request?"":"OK",new ArrayList<>(),new byte[0]);}
 private void header(Object m,String name,String value)throws Exception{m.getClass().getMethod("a",String.class,String.class).invoke(m,name,value);}
 @Override public void onCreate(Bundle args){super.onCreate(args);start();}
 @Override public void onStart(){Bundle result=new Bundle();try{
  loader=getTargetContext().getClassLoader();
  for(String name:new String[]{"o82","bh1","cb4","ma4","t10","m10","k7","yz","cc.forserein.simhub.internal.AmrFraming","cc.forserein.simhub.internal.RegistrationTiming"}){type(name).getDeclaredMethods();loaded.add(name);checks++;}
  check(((Integer)type("cc.forserein.simhub.internal.AmrFraming").getMethod("shape",byte[].class,boolean.class,boolean.class).invoke(null,new byte[0],true,true))<0,"empty AMR payload rejected");
  Class<?> timing=type("cc.forserein.simhub.internal.RegistrationTiming");
  for(int seconds:new int[]{1,30,7200,Integer.MAX_VALUE}){
   check(((Integer)timing.getMethod("acceptedExpires",int.class).invoke(null,seconds))==seconds,"expiry retained");
   check(((Long)timing.getMethod("refreshDelayMillis",int.class).invoke(null,seconds))==((long)seconds)*850L,"millisecond refresh");
  }
  try{timing.getMethod("acceptedExpires",int.class).invoke(null,0);throw new AssertionError("zero lifetime accepted");}catch(InvocationTargetException expected){check(expected.getCause() instanceof IllegalStateException,"zero lifetime rejected");}
  Class<?> dialog=type("ma4"),msg=type("kb4");
  Object d=dialog.getConstructors()[0].newInstance(type("ga4").getField("U").get(null),"probe@example.invalid",type("la4").getField("W").get(null),"local-tag","sip:local@example.invalid","sip:peer@example.invalid","sip:peer@example.invalid",11,11,message(true,"INVITE",0),0.0);
  Object incoming=message(true,"UPDATE",0),outgoingResponse=message(false,"UPDATE",200);header(incoming,"x","1800;refresher=UAS");
  type("cb4").getMethod("c",msg,msg,dialog).invoke(null,outgoingResponse,incoming,d);
  check(((Integer)get(d,"B"))==1800,"compact incoming SIP timer applied");check((Boolean)get(d,"C"),"incoming uppercase UAS interpreted locally");
  set(d,"sipPendingRefreshCSeq",12);set(d,"B",1800);set(d,"C",false);set(d,"E",1.0);
  Object response=message(false,"UPDATE",200);header(response,"CSeq","12 UPDATE");header(response,"x","90;refresher=uac");
  Method apply=type("cb4").getMethod("sipApplyRefreshResponse",msg,dialog,double.class);apply.invoke(null,response,d,20.0);
  check(((Integer)get(d,"B"))==90,"compact SIP timer applied");check((Boolean)get(d,"C"),"local refresher applied");check(((Double)get(d,"E"))==20.0,"time updated");check(((Integer)get(d,"sipPendingRefreshCSeq"))==0,"pending response consumed");
  apply.invoke(null,response,d,30.0);check(((Double)get(d,"E"))==20.0,"duplicate cannot extend timer");
  result.putString("status","passed");result.putInt("checks",checks);result.putStringArrayList("loaded_classes",loaded);result.putString("scope","Actual ART class loading; offline synthetic SIP timer response and registration helper. No real IMS, SIM or call.");finish(0,result);
 }catch(Throwable e){result.putString("status","failed");result.putInt("checks",checks);result.putString("error",android.util.Log.getStackTraceString(e));finish(1,result);}}
}
