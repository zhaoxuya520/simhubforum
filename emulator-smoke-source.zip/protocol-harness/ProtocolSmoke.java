package protocolsmoke;
import android.app.Instrumentation;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import java.lang.reflect.*;
import java.util.*;
/** Emulator-only offline ART smoke test. No network, SIM, microphone, or application-state edits. */
public final class ProtocolSmoke extends Instrumentation {
 private ClassLoader loader;private int checks;private ArrayList<String> loaded=new ArrayList<>();
 private Class<?> type(String name)throws Exception {return Class.forName(name,true,loader);}
 private void check(boolean value,String what){if(!value)throw new AssertionError(what);checks++;}
 private Object get(Object value,String field)throws Exception{return value.getClass().getField(field).get(value);}
 private void set(Object value,String field,Object next)throws Exception{value.getClass().getField(field).set(value,next);}
 private Object message(boolean request,String method,int status)throws Exception{return type("kb4").getConstructor(boolean.class,String.class,String.class,int.class,String.class,ArrayList.class,byte[].class).newInstance(request,method,"sip:peer@example.invalid",status,request?"":"OK",new ArrayList<>(),new byte[0]);}
 private void header(Object m,String name,String value)throws Exception{m.getClass().getMethod("a",String.class,String.class).invoke(m,name,value);}

 public static final class NotificationCall {
  public String a,j;public boolean d=true;public Object e;
  NotificationCall(String id,String token,Object state){a=id;j=token;e=state;}
 }
 private void notificationActions()throws Exception{
  Class<?> guard=type("cc.forserein.simhub.internal.CallNotificationGuard");
  String answer=(String)guard.getField("ANSWER").get(null),hangup=(String)guard.getField("HANGUP").get(null);
  Object ringing=type("z00").getField("a").get(null);
  NotificationCall a=new NotificationCall("art-call-A","11111111-1111-4111-8111-111111111111",ringing);
  NotificationCall b=new NotificationCall("art-call-B","22222222-2222-4222-8222-222222222222",ringing);
  NotificationCall replaced=new NotificationCall(a.a,b.j,ringing);
  Method bind=guard.getMethod("bind",Intent.class,Object.class),allows=guard.getMethod("allows",Intent.class,Object.class);
  Intent ia=new Intent(answer),ib=new Intent(answer);bind.invoke(null,ia,a);bind.invoke(null,ib,b);
  check(!ia.filterEquals(ib),"per-call URI participates in Android Intent identity");
  check((Boolean)allows.invoke(null,ia,a),"notification accepts its original synthetic call");
  check(!(Boolean)allows.invoke(null,ia,b),"old notification rejects another call");
  check(!(Boolean)allows.invoke(null,ia,replaced),"same Call-ID with a new UUID is rejected");
  Method create=guard.getMethod("activityIntent",int.class,android.content.Context.class,String.class,Object.class);
  ArrayList<PendingIntent> pending=new ArrayList<PendingIntent>();
  try{
   PendingIntent pa=(PendingIntent)create.invoke(null,932340,getTargetContext(),answer,a);pending.add(pa);
   PendingIntent pa2=(PendingIntent)create.invoke(null,932340,getTargetContext(),answer,a);pending.add(pa2);
   PendingIntent pb=(PendingIntent)create.invoke(null,932340,getTargetContext(),answer,b);pending.add(pb);
   PendingIntent pr=(PendingIntent)create.invoke(null,932340,getTargetContext(),answer,replaced);pending.add(pr);
   PendingIntent ph=(PendingIntent)create.invoke(null,932340,getTargetContext(),hangup,a);pending.add(ph);
   check(pa.equals(pa2),"same call/action resolves to same real PendingIntent");
   check(!pa.equals(pb),"call A and B have distinct real PendingIntents");
   check(!pa.equals(pr),"new UUID has distinct real PendingIntent");
   check(!pa.equals(ph),"answer and hangup actions have distinct real PendingIntents");
   check(getTargetContext().getPackageName().equals(pa.getCreatorPackage()),"PendingIntent belongs to target app");
  }finally{for(PendingIntent pi:pending)pi.cancel();}
 }
 private void sanitizeDiagnostic()throws Exception{
  Method sanitize=type("cc.forserein.simhub.internal.DiagnosticShareSanitizer").getMethod("sanitize",String.class);
  String input="19:05:01 Authorization: Digest username=\"515660000000001\", realm=\"ims.example.invalid\", nonce=\"synthetic-auth-token\", response=\"synthetic-response\"\n"
    +"19:05:02 P-Asserted-Identity: <tel:+639991234567>\n"
    +"19:05:03 Contact: <sip:+639991234567@ims.example.invalid>\n"
    +"19:05:04 收到短信 来自 +639991234567 32B\n"
    +"19:05:05 ← 来电 INVITE 来自 +639991234567；语音编码：AMR-WB\n"
    +"19:05:06 Call-ID: art-call-123@ims.example.invalid\n"
    +"19:05:07 媒体：收到第一个 RTP，来自 192.0.2.20:20000，PT 116，45B";
  String clean=(String)sanitize.invoke(null,input);
  for(String secret:new String[]{"515660000000001","+639991234567","synthetic-auth-token","synthetic-response"})check(!clean.contains(secret),"diagnostic removes synthetic identity/auth value");
  check(clean.contains("ims.example.invalid"),"diagnostic keeps operator domain");
  check(clean.contains("Call-ID: art-call-123@ims.example.invalid"),"diagnostic keeps call correlation");
  check(clean.contains("192.0.2.20:20000，PT 116，45B"),"diagnostic keeps media troubleshooting fields");
  check(clean.equals(sanitize.invoke(null,clean)),"diagnostic sanitization is idempotent");
 }
 @SuppressWarnings({"rawtypes","unchecked"})
 private void forkIsolation()throws Exception{
  Class<?> dialog=type("ma4"),msg=type("kb4"),manager=type("cb4");
  Object invite=message(true,"INVITE",0);
  Object selected=dialog.getConstructors()[0].newInstance(type("ga4").getField("U").get(null),"art-fork@example.invalid",type("la4").getField("W").get(null),"local-tag","sip:local@example.invalid","sip:peer@example.invalid","sip:A@example.invalid",11,11,invite,0.0);
  set(selected,"D",12.0);set(selected,"l","selected-A");set(selected,"p",new byte[]{1,2,3});
  Object config=type("ra4").getConstructors()[0].newInstance("192.0.2.1",5060,"sip:local@example.invalid","urn:uuid:art-fork","sip:local@example.invalid","probe",new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),true,false);
  Object m=manager.getConstructors()[0].newInstance(config,null,null,null);((Map)get(m,"e")).put("art-fork@example.invalid",selected);
  Object engine=Class.forName("ForkTransport",true,getClass().getClassLoader()).getConstructor().newInstance();set(engine,"J",m);
  Object response=message(false,"INVITE",200);header(response,"Call-ID","art-fork@example.invalid");header(response,"CSeq","11 INVITE");header(response,"To","<sip:peer@example.invalid>;tag=extra-B");header(response,"From","<sip:local@example.invalid>;tag=local-tag");header(response,"Contact","<sip:B@example.invalid>");
  Method handle=type("cc.forserein.simhub.internal.SipForkProtection").getMethod("handle",Object.class,Object.class);
  List packets=(List)get(engine,"packets");
  Object invalid=message(false,"INVITE",200);header(invalid,"Call-ID","art-fork@example.invalid");header(invalid,"CSeq","11 INVITE");header(invalid,"To","<sip:peer@example.invalid>;tag=invalid-C");header(invalid,"From","<sip:local@example.invalid>;tag=wrong-local");header(invalid,"Contact","<sip:wrong@example.invalid>");
  check((Boolean)handle.invoke(null,engine,invalid),"wrong local From-tag extra response is consumed");check(packets.isEmpty(),"wrong local From-tag never sends ACK/BYE to its contact");
  check((Boolean)handle.invoke(null,engine,response),"additional INVITE leg consumed by actual helper");check(packets.size()==2,"additional leg builds ACK and BYE into recording-only transport");
  check("ACK".equals(get(packets.get(0),"b"))&&"BYE".equals(get(packets.get(1),"b")),"native packet methods are ACK then BYE");
  check("sip:B@example.invalid".equals(get(packets.get(0),"c")),"fork ACK targets extra leg contact");
  check("selected-A".equals(get(selected,"l"))&&"sip:A@example.invalid".equals(get(selected,"g")),"selected dialog identity and target preserved");
  check(java.util.Arrays.equals(new byte[]{1,2,3},(byte[])get(selected,"p")),"selected dialog SDP remains unchanged");
  check((Boolean)handle.invoke(null,engine,response),"retransmitted fork consumed");
  check(packets.size()==3&&"ACK".equals(get(packets.get(2),"b")),"retransmission only repeats ACK");
  Method requestHandler=type("cc.forserein.simhub.internal.SipForkProtection").getMethod("handleRequest",Object.class,Object.class,Object.class);
  Object bye=legRequest("BYE","extra-B");check((Boolean)requestHandler.invoke(null,engine,bye,null),"known extra-leg BYE is consumed");check(packets.size()==4&&((Integer)get(packets.get(3),"d"))==200,"known extra-leg BYE builds 200 reply");
  Object unknown=legRequest("BYE","unknown-C");check((Boolean)requestHandler.invoke(null,engine,unknown,null),"unknown dialog request is isolated");check(packets.size()==5&&((Integer)get(packets.get(4),"d"))==481,"unknown dialog request builds 481 reply");
  Object ack=legRequest("ACK","unknown-C");check((Boolean)requestHandler.invoke(null,engine,ack,null),"unknown dialog ACK is consumed");check(packets.size()==5,"ACK never produces a response");
  check("selected-A".equals(get(selected,"l"))&&"sip:A@example.invalid".equals(get(selected,"g"))&&java.util.Arrays.equals(new byte[]{1,2,3},(byte[])get(selected,"p"))&&((Map)get(m,"e")).get("art-fork@example.invalid")==selected,"fork closure preserves selected dialog and media");
 }
 private Object legRequest(String method,String remote)throws Exception{
  Object request=message(true,method,0);header(request,"Call-ID","art-fork@example.invalid");header(request,"CSeq","99 "+method);header(request,"To","<sip:local@example.invalid>;tag=local-tag");header(request,"From","<sip:peer@example.invalid>;tag="+remote);header(request,"Via","SIP/2.0/TCP 192.0.2.20:5060;branch=z9hG4bK-art-fork");return request;
 }
 @Override public void onCreate(Bundle args){super.onCreate(args);start();}
 @Override public void onStart(){Bundle result=new Bundle();try{
  runOnMainSync(new Runnable(){public void run(){}});
  loader=getTargetContext().getClassLoader();
  for(String name:new String[]{"o82","bh1","cb4","ma4","t10","m10","k7","yz","cc.forserein.simhub.internal.AmrFraming","cc.forserein.simhub.internal.RegistrationTiming","cc.forserein.simhub.internal.CallNotificationGuard","cc.forserein.simhub.internal.DiagnosticShareSanitizer","cc.forserein.simhub.internal.SipForkProtection"}){type(name).getDeclaredMethods();loaded.add(name);checks++;}
  check(((Integer)type("cc.forserein.simhub.internal.AmrFraming").getMethod("shape",byte[].class,boolean.class,boolean.class).invoke(null,new byte[0],true,true))<0,"empty AMR payload rejected");
  Class<?> timing=type("cc.forserein.simhub.internal.RegistrationTiming");
  for(int seconds:new int[]{1,30,7200,Integer.MAX_VALUE}){
   check(((Integer)timing.getMethod("acceptedExpires",int.class).invoke(null,seconds))==seconds,"expiry retained");
   check(((Long)timing.getMethod("refreshDelayMillis",int.class).invoke(null,seconds))==((long)seconds)*850L,"millisecond refresh");
  }
  try{timing.getMethod("acceptedExpires",int.class).invoke(null,0);throw new AssertionError("zero lifetime accepted");}catch(InvocationTargetException expected){check(expected.getCause() instanceof IllegalStateException,"zero lifetime rejected");}
  Class<?> dialog=type("ma4"),msg=type("kb4");
  Object d=dialog.getConstructors()[0].newInstance(type("ga4").getField("U").get(null),"probe@example.invalid",type("la4").getField("W").get(null),"local-tag","sip:local@example.invalid","sip:peer@example.invalid","sip:peer@example.invalid",11,11,message(true,"INVITE",0),0.0);
  Object incoming=message(true,"UPDATE",0),outgoingResponse=message(false,"UPDATE",200);header(incoming,"x","1800;refresher=UAS");
  type("cb4").getMethod("c",msg,msg,dialog).invoke(null,outgoingResponse,incoming,d);
  check(((Integer)get(d,"B"))==1800,"compact incoming SIP timer applied");check((Boolean)get(d,"C"),"incoming uppercase UAS interpreted locally");
  set(d,"sipPendingRefreshCSeq",12);set(d,"B",1800);set(d,"C",false);set(d,"E",1.0);
  Object response=message(false,"UPDATE",200);header(response,"CSeq","12 UPDATE");header(response,"x","90;refresher=uac");
  Method apply=type("cb4").getMethod("sipApplyRefreshResponse",msg,dialog,double.class);apply.invoke(null,response,d,20.0);
  check(((Integer)get(d,"B"))==90,"compact SIP timer applied");check((Boolean)get(d,"C"),"local refresher applied");check(((Double)get(d,"E"))==20.0,"time updated");check(((Integer)get(d,"sipPendingRefreshCSeq"))==0,"pending response consumed");
  apply.invoke(null,response,d,30.0);check(((Double)get(d,"E"))==20.0,"duplicate cannot extend timer");
  notificationActions(); sanitizeDiagnostic(); forkIsolation();
  result.putString("status","passed");result.putInt("checks",checks);result.putStringArrayList("loaded_classes",loaded);result.putString("scope","Actual ART helper loading, synthetic SIP timers/fork handling with a recording-only transport, diagnostic masking, and Android PendingIntent identity; PendingIntents are never sent. No real IMS, SIM or call.");finish(0,result);
 }catch(Throwable e){result.putString("status","failed");result.putInt("checks",checks);result.putString("error",android.util.Log.getStackTraceString(e));finish(1,result);}}
}
