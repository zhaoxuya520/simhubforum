from pathlib import Path
import subprocess, re, base64, hashlib, json

root=Path(__file__).resolve().parent
adb=['/workspace/tools/android-platform-tools/platform-tools/adb','-s','emulator-5580']
result=subprocess.run(adb+['shell','am','instrument','-w','cc.forserein.simhub.readersmoke/readersmoke.ReaderUiSmoke'],capture_output=True,text=True,timeout=360)
output=result.stdout+result.stderr
captures=[]
for block in output.split('INSTRUMENTATION_STATUS_CODE: 0'):
    name=re.search(r'^INSTRUMENTATION_STATUS: capture=([a-z0-9-]+)$',block,re.M)
    data=re.search(r'^INSTRUMENTATION_STATUS: png_base64=([A-Za-z0-9+/=]+)$',block,re.M)
    if not name or not data:
        continue
    payload=base64.b64decode(data.group(1),validate=True)
    assert payload.startswith(b'\x89PNG\r\n\x1a\n')
    target=root/(name.group(1)+'.png')
    target.write_bytes(payload)
    captures.append({'path':str(target),'sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload)})
    output=output.replace(data.group(0),'INSTRUMENTATION_STATUS: png_file='+str(target))
(root/'reader-ui-art.txt').write_text(output)
(root/'reader-ui-captures.json').write_text(json.dumps(captures,indent=2)+'\n')
summary={}
for line in output.splitlines():
    if line.startswith('INSTRUMENTATION_RESULT: '):
        key,value=line.split(': ',1)[1].split('=',1)
        summary[key]=value
print(json.dumps({'results':summary,'captures':captures},indent=2,ensure_ascii=False))
if 'INSTRUMENTATION_RESULT: status=passed' not in output:
    print(output[-12000:])
    raise SystemExit(1)
