#!/usr/bin/env bash
set -euo pipefail
umask 077
base=${SIMHUB_TS_DIR:-"${XDG_STATE_HOME:-$HOME/.local/state}/simhub-tailnet"}
if [[ -z ${SIMHUB_TS_DIR:-} && -x /workspace/tools/simhub-tailnet/tailscale ]]; then base=/workspace/tools/simhub-tailnet; fi
mkdir -p -m 700 "$base/state"
base=$(cd "$base" && pwd)
sock="$base/state/tailscaled.sock"
cli=("$base/tailscale" "--socket=$sock")
url=http://161.153.97.110:8080
prepare() {
  if [[ ! -x "$base/tailscale" || ! -x "$base/tailscaled" ]]; then
    case "$(uname -m)" in x86_64) arch=amd64;; aarch64|arm64) arch=arm64;; *) echo "Unsupported Linux architecture" >&2; return 1;; esac
    local stem="tailscale_1.104.7_${arch}" tmp checksum
    tmp=$(mktemp -d)
    curl -fsSL "https://pkgs.tailscale.com/stable/$stem.tgz" -o "$tmp/pkg.tgz"
    checksum=$(curl -fsSL "https://pkgs.tailscale.com/stable/$stem.tgz.sha256")
    printf '%s  %s\n' "${checksum%% *}" "$tmp/pkg.tgz" | sha256sum -c -
    tar xzf "$tmp/pkg.tgz" -C "$tmp" "$stem/tailscale" "$stem/tailscaled"
    install -m 700 "$tmp/$stem/tailscale" "$tmp/$stem/tailscaled" "$base/"
    rm -rf -- "$tmp"
  fi
  if ! "${cli[@]}" status --json >/dev/null 2>&1; then
    nohup "$base/tailscaled" --tun=userspace-networking --statedir="$base/state" --socket="$sock" --no-logs-no-support </dev/null >>"$base/state/daemon.log" 2>&1 &
    local pid=$!
    for ((i=0; i<50; i++)); do
      if "${cli[@]}" status --json >/dev/null 2>&1; then return; fi
      kill -0 "$pid" || return 1
      sleep .2
    done
    echo "Local daemon failed to become ready" >&2; return 1
  fi
}
status() {
  "${cli[@]}" status --json | python3 -c 'import json,sys
v=json.load(sys.stdin)
peers=[p for p in (v.get("Peer") or {}).values() if "100.64.0.1" in (p.get("TailscaleIPs") or [])]
print("BackendState =",v.get("BackendState"),"| client IPs =",v.get("TailscaleIPs") or [],"| Oracle listed =",bool(peers))
sys.exit(0 if v.get("BackendState")=="Running" and v.get("TailscaleIPs") else 1)'
}
case "${1:-}" in
  prepare) prepare; "$base/tailscale" version | head -n 1 ;;
  status) status ;;
  join)
    prepare
    if status; then exit 0; fi
    if [[ -n ${SIMHUB_AUTHKEY_FILE:-} ]]; then
      exec 3<"$SIMHUB_AUTHKEY_FILE"
    else
      IFS= read -rs -p 'Headscale auth key: ' key </dev/tty
      printf '\n' >/dev/tty
      [[ -n $key ]]
      exec 3<<<"$key"
      unset key
    fi
    if ! "${cli[@]}" up --login-server="$url" --hostname="${SIMHUB_NODE_NAME:-simhub-codex}" --accept-dns=false --accept-routes=false --auth-key=file:/dev/fd/3 --timeout=35s; then
      exec 3<&-
      if ! status; then "${cli[@]}" down; exit 1; fi
    fi
    exec 3<&-
    status ;;
  *) echo "Usage: bash cloud-client.sh prepare|join|status" >&2; exit 2 ;;
esac
