"""Dedicated HTTPS listener for the existing SIMHub translation application."""
import os
import ssl
from pathlib import Path

from aiohttp import web
from relay import application


def main():
    credentials = Path(os.environ["CREDENTIALS_DIRECTORY"])
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(credentials / "fullchain.pem", credentials / "privkey.pem")
    key = (credentials / "gemini.key").read_text().strip()
    if not key:
        raise ValueError("Empty Gemini credential")
    web.run_app(
        application(key, Path(os.environ["STATE_DIRECTORY"]) / "devices"),
        host=os.environ.get("SIMHUB_BIND", "0.0.0.0"),
        port=8443,
        ssl_context=context,
        access_log=None,
    )


if __name__ == "__main__":
    main()
