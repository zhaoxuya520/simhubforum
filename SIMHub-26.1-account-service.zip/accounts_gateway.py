"""Expose the local account service on the translation listener's dedicated 8443 port."""
from aiohttp import ClientSession, ClientTimeout, ClientError, web

LOCAL_API = "http://127.0.0.1:8872"

METHODS = {
    "/accounts/v1/register": {"POST"},
    "/accounts/v1/reset-password": {"POST"},
    "/accounts/v1/login": {"POST"},
    "/accounts/v1/logout": {"POST"},
    "/accounts/v1/snapshot": {"GET", "PUT"},
    "/accounts/v1/settings": {"GET", "PUT"},
}


@web.middleware
async def accounts_gateway(request, handler):
    methods = METHODS.get(request.path)
    if methods is None:
        return await handler(request)
    if request.method not in methods:
        raise web.HTTPMethodNotAllowed(request.method, methods)
    headers = {"Content-Type": "application/json", "X-SIMHub-Peer": request.remote or "local"}
    if "Authorization" in request.headers:
        headers["Authorization"] = request.headers["Authorization"]
    limit = 16 * 1024 * 1024 if request.path.endswith("/snapshot") else 8192
    body = await request.clone(client_max_size=limit).read()
    try:
        async with ClientSession(timeout=ClientTimeout(total=30)) as session:
            async with session.request(request.method, LOCAL_API + request.path,
                                       headers=headers, data=body, allow_redirects=False) as response:
                return web.Response(status=response.status, body=await response.read(),
                                    content_type=response.content_type, headers={"Cache-Control": "no-store"})
    except (ClientError, TimeoutError):
        raise web.HTTPBadGateway() from None
