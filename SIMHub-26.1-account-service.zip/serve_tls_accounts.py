"""Dedicated HTTPS listener for the existing SIMHub translation application."""
import os
import ssl
from pathlib import Path

from aiohttp import web
from accounts_gateway import accounts_gateway


def main():
    credentials = Path(os.environ["CREDENTIALS_DIRECTORY"])
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(credentials / "fullchain.pem", credentials / "privkey.pem")
    google_key = credentials / "gemini.key"
    if google_key.exists():
        from relay import application
        key = google_key.read_text().strip()
        if not key:
            raise ValueError("Empty Gemini credential")
        app = application(key, Path(os.environ["STATE_DIRECTORY"]) / "devices")
    else:
        app = web.Application()
    app.middlewares.insert(0, accounts_gateway)
    web.run_app(
        app,
        host=os.environ.get("SIMHUB_BIND", "0.0.0.0"),
        port=8443,
        ssl_context=context,
        access_log=None,
    )


if __name__ == "__main__":
    main()
