import asyncio
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest

from aiohttp import ClientSession, web
from aiohttp.test_utils import TestClient, TestServer

from service import CloudMail, DAY, SCHEMA, create_app, database, provision, send_due


class Mail:
    def __init__(self):
        self.calls = []
        self.fail = False

    def reset(self):
        pass

    async def send(self, recipient, title, expires):
        self.calls.append((recipient, title, expires))
        if self.fail:
            raise OSError()


class ServiceTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.path = str(Path(directory.name) / "accounts.sqlite")
        with database(self.path) as con:
            con.executescript(SCHEMA)
        for name in ("alice", "bob"):
            provision(self.path, name, "test-password-only")
        self.client = await self.enterAsyncContext(TestClient(TestServer(create_app(self.path))))

    async def login(self, name):
        response = await self.client.post("/accounts/v1/login", json={"username": name, "password": "test-password-only"})
        self.assertEqual(response.status, 200)
        return {"Authorization": "Bearer " + (await response.json())["token"]}

    def admin_code(self, *action):
        return subprocess.check_output([sys.executable, str(Path(__file__).with_name("service.py")),
                                        "--db", self.path, *action], text=True).strip()

    async def test_invitation_and_recovery_through_gateway(self):
        from unittest.mock import patch
        import accounts_gateway
        gateway = await self.enterAsyncContext(TestClient(TestServer(
            web.Application(middlewares=[accounts_gateway.accounts_gateway]))))
        invite = self.admin_code("invite")
        user = {"username": "New.User", "password": "first-secret-password", "code": invite}
        async def post(action, data):
            return await gateway.post("/accounts/v1/" + action, json=data)
        with patch.object(accounts_gateway, "LOCAL_API", str(self.client.make_url("/")).rstrip("/")):
            self.assertEqual((await post("register", dict(user, username="alice"))).status, 409)
            responses = await asyncio.gather(post("register", user), post("register", dict(user, username="rival")))
            self.assertEqual(sorted(r.status for r in responses), [200, 403])
            index = next(i for i, response in enumerate(responses) if response.status == 200)
            response = responses[index]
            recovery = (await response.json())["recovery_code"]
            name = "rival" if index else "new.user"
            old = (await (await post("login", dict(user, username=name))).json())["token"]
            headers = {"Authorization": "Bearer " + old}
            snapshot = {"revision": 0, "data": {"private": "saved"}, "cards": []}
            self.assertEqual((await gateway.put("/accounts/v1/snapshot", headers=headers, json=snapshot)).status, 200)
            new = {"username": name, "code": recovery, "password": "second-secret-password"}
            self.assertEqual((await post("reset-password", dict(new, username="alice"))).status, 403)
            self.assertEqual((await post("reset-password", dict(new, code=self.admin_code("invite")))).status, 403)
            response = await post("reset-password", new)
            self.assertEqual(response.status, 200)
            rotated = (await response.json())["recovery_code"]
            self.assertNotEqual(recovery, rotated)
            self.assertEqual((await post("reset-password", new)).status, 403)
            self.assertEqual((await post("login", dict(user, username=name))).status, 401)
            self.assertEqual((await gateway.get("/accounts/v1/snapshot", headers=headers)).status, 401)
            token = (await (await post("login", new)).json())["token"]
            saved = await gateway.get("/accounts/v1/snapshot", headers={"Authorization": "Bearer " + token})
            self.assertEqual((await saved.json())["data"], snapshot["data"])

    async def test_existing_account_and_expired_codes(self):
        old = self.admin_code("reset-code", "ALICE")
        latest = self.admin_code("reset-code", "alice")
        self.assertNotEqual(latest, old)
        async def reset(code, name="alice"):
            return await self.client.post("/accounts/v1/reset-password", json={
                "username": name, "password": "replacement-password", "code": code})
        self.assertEqual((await reset(old)).status, 403)
        self.assertEqual((await reset(latest, "bob")).status, 403)
        self.assertEqual((await reset(latest)).status, 200)
        invite = self.admin_code("invite")
        expired = self.admin_code("reset-code", "bob")
        with database(self.path) as con:
            con.execute("UPDATE access_code SET expires=0 WHERE expires IS NOT NULL")
        self.assertEqual((await reset(expired, "bob")).status, 403)
        self.assertEqual((await self.client.post("/accounts/v1/register", json={
            "username":"another", "code":invite, "password":"valid-length-password"})).status, 403)

    async def test_accounts_isolation_and_conflict(self):
        alice, bob = await self.login("alice"), await self.login("bob")
        url = "/accounts/v1/snapshot"
        payload = {"revision": 0, "data": {"notes": "private"}, "cards": []}
        self.assertEqual((await self.client.put(url, json=payload, headers=alice)).status, 200)
        self.assertEqual((await self.client.put(url, json=payload, headers=alice)).status, 409)
        self.assertEqual(await (await self.client.get(url, headers=bob)).json(), {"revision": 0, "data": {}})
        self.assertEqual((await self.client.post("/accounts/v1/logout", headers=alice)).status, 204)
        self.assertEqual((await self.client.get(url, headers=alice)).status, 401)

    async def test_reminder_timing_retry_and_deduplication(self):
        alice, bob = await self.login("alice"), await self.login("bob")
        now = int(time.time())
        for name, headers in (("alice", alice), ("bob", bob)):
            self.assertEqual((await self.client.put("/accounts/v1/settings", headers=headers,
                                                  json={"recipient": name + "@example.org"})).status, 200)
            cards = [{"id": "same-card-id", "title": name, "expires": now + 7 * DAY + 1}]
            payload = {"revision": 0, "data": {}, "cards": cards}
            self.assertEqual((await self.client.put("/accounts/v1/snapshot", headers=headers, json=payload)).status, 200)
        mail = Mail()
        await send_due(self.path, mail, now)
        self.assertEqual(mail.calls, [])
        mail.fail = True
        await send_due(self.path, mail, now + 1)
        self.assertEqual(len(mail.calls), 2)
        mail.fail = False
        await send_due(self.path, mail, now + 16)
        self.assertEqual(len(mail.calls), 2)
        await asyncio.gather(send_due(self.path, mail, now + 901), send_due(self.path, mail, now + 901))
        self.assertEqual(len(mail.calls), 4)
        self.assertEqual({r[0] for r in mail.calls[2:]}, {"alice@example.org", "bob@example.org"})
        payload["revision"] = 1
        self.assertEqual((await self.client.put("/accounts/v1/snapshot", headers=bob, json=payload)).status, 200)
        await send_due(self.path, mail, now + 1000)
        self.assertEqual(len(mail.calls), 4)

    async def test_cloud_mail_http_contract(self):
        sent = []

        async def authenticate(request):
            self.assertEqual(await request.json(), {"email": "sender@example.org", "password": "fixture"})
            self.assertTrue(request.headers["User-Agent"].startswith("Mozilla/5.0"))
            return web.json_response({"code": 200, "data": {"token": "fixture-token"}})

        async def send(request):
            self.assertEqual(request.headers.get("Authorization"), "fixture-token")
            payload = await request.json()
            self.assertEqual(payload["accountId"], 1057)
            self.assertEqual(payload["receiveEmail"], ["owner@example.org"])
            self.assertEqual(payload["type"], 1)
            sent.append(payload)
            return web.json_response({"code": 200, "data": [{"emailId": "fixture-id"}]})

        provider = web.Application()
        provider.router.add_post("/api/login", authenticate)
        provider.router.add_post("/api/email/send", send)
        server = await self.enterAsyncContext(TestServer(provider))
        async with ClientSession() as http:
            mail = CloudMail(http, "sender@example.org", "fixture")
            mail.BASE = str(server.make_url("/api"))
            await mail.send("owner@example.org", "Test card", int(time.time()))
        self.assertIn("Test card", sent[0]["content"])

    async def test_gateway_and_changed_expiry(self):
        from unittest.mock import patch
        import accounts_gateway
        front = web.Application(middlewares=[accounts_gateway.accounts_gateway])
        async def translation(req):
            return web.Response(status=401)
        front.router.add_post("/v1/test", translation)
        gateway = await self.enterAsyncContext(TestClient(TestServer(front)))
        with patch.object(accounts_gateway, "LOCAL_API", str(self.client.make_url("/")).rstrip("/")):
            response = await gateway.post("/accounts/v1/login", json={"username":"alice","password":"test-password-only"})
            self.assertEqual(response.status, 200)
            headers={"Authorization":"Bearer "+(await response.json())["token"]}
            self.assertEqual((await gateway.post("/v1/test", headers=headers)).status, 401)
            self.assertEqual((await gateway.put("/accounts/v1/settings", headers=headers,
                                               json={"recipient":"a@example.org"})).status, 200)
            now = int(time.time())
            card={"id":"one","title":"Demo","expires":now+7*DAY}
            async def upload(rev, cards):
                res=await gateway.put("/accounts/v1/snapshot",headers=headers,
                    json={"revision":rev,"data":{"esim_card":{}}, "cards":cards})
                self.assertEqual(res.status,200)
            await upload(0,[card])
            mail=Mail()
            await send_due(self.path,mail,now)
            self.assertEqual(len(mail.calls),1)
            card["expires"]+=30*DAY
            await upload(1,[card])
            await send_due(self.path,mail,now+30*DAY)
            self.assertEqual(len(mail.calls),2)
            await upload(2,[])
            await send_due(self.path,mail,now+30*DAY+1)
            self.assertEqual(len(mail.calls),2)
