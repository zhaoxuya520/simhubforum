import cc.forserein.simhub.internal.*;
import java.util.*;
import android.content.*;

public class WifiConfigTest {
 static int passed;
 static void check(boolean ok,String what){if(!ok)throw new AssertionError(what);passed++;}
 interface Op {void run() throws Exception;}
 static void rejects(Op op,String what) throws Exception {try{op.run();throw new AssertionError("accepted "+what);}catch(IllegalArgumentException|IllegalStateException e){passed++;}}
 static Map<String,String> values(String...pairs){Map<String,String> m=new LinkedHashMap<>();for(int i=0;i<pairs.length;i+=2)m.put(pairs[i],pairs[i+1]);return m;}
 public static class Prefs implements SharedPreferences {
  Map<String,String> data=new HashMap<>();boolean fail;
  public String getString(String k,String fallback){return data.containsKey(k)?data.get(k):fallback;}
  public Editor edit(){return new Editor(){Map<String,String> changes=new HashMap<>();public Editor putString(String k,String v){changes.put(k,v);return this;}public Editor remove(String k){changes.put(k,null);return this;}public boolean commit(){for(Map.Entry<String,String> e:changes.entrySet()){if(e.getValue()==null)data.remove(e.getKey());else data.put(e.getKey(),e.getValue());}boolean result=!fail;fail=false;return result;}};}
 }
 public static class Ctx extends Context {final Prefs prefs=new Prefs();public SharedPreferences getSharedPreferences(String n,int mode){return prefs;} }
 public static class Family {public String T;Family(String t){T=t;}}
 public static class Type {public int T;Type(int v){T=v;}}
 public static class Transform {public Type a;public int b;public Integer c;Transform(int type,int id,Integer bits){a=new Type(type);b=id;c=bits;}}
 static gl5 state(ek5 card,xi5 config){return new gl5("label","id",false,null,card,config,false,"legacy.epdg.example.org","+441234567890","490154203237518",new Phase(),false,null,null,null,new ArrayList<>(),new ArrayList<>(),false,null,0L);}
 static ArrayList<Transform> ike(){return new ArrayList<>(Arrays.asList(new Transform(1,12,256),new Transform(1,12,128),new Transform(2,5,null),new Transform(2,7,null),new Transform(2,2,null),new Transform(3,12,null),new Transform(3,14,null),new Transform(3,2,null),new Transform(4,14,null),new Transform(4,2,null)));}
 public static void main(String[] args) throws Exception {
  for(WifiConfigValues.Field f:WifiConfigValues.FIELDS)check(!WifiConfigValues.validate(values(f.key," \n ")).containsKey(f.key),"blank resets "+f.key);
  String[] all={"epdg","EPDG.example.org,backup.example.org epdg.example.org","smsc","00441234567890","imei","490154203237518","domain","IMS.Custom.Example.org","apn","custom.ims","ip","IPV4","ipsec","false","nai","anonymous@custom.example.org","impi","test@custom.example.org","impu","tel:+441234567890","eap","test@eap.example.org","ike_encr","AES192,aes256,aes192","ike_integ","sha512","ike_prf","sha384","ike_dh","ecp256","esp_encr","aes128","esp_integ","sha1","keepalive","45"};
  Map<String,String> custom=WifiConfigValues.validate(values(all));
  check(custom.size()==18,"all entries editable");
  check(custom.get("epdg").equals("epdg.example.org\nbackup.example.org"),"ordered endpoints deduplicated");
  check(custom.get("smsc").equals("+441234567890"),"international SMSC");
  check(custom.get("ike_encr").equals("aes192 aes256"),"algorithm order");
  check(custom.get("ipsec").equals("off"),"false is an override");
  check(WifiConfigValues.decode(WifiConfigValues.encode(custom)).equals(custom),"all fields persist roundtrip");
  check(WifiConfigValues.decode("v1\n").isEmpty(),"managed empty differs from legacy");
  for(String[] bad:new String[][]{{"domain","ims.example.org\r\nInjected: yes"},{"domain","https://ims.example.org"},{"domain","a..b"},{"epdg","x.example.org:500"},{"keepalive","0"},{"keepalive","9"},{"keepalive","-1"},{"keepalive","3601"},{"keepalive","20s"},{"ip","ipv5"},{"ipsec","maybe"},{"ike_encr","aes-gcm"},{"ike_dh","modp4096"},{"esp_integ","md5"},{"imei","490154203237519"},{"smsc","+44abc123"},{"impu","sip:user\r\n@host"},{"nai","bad<>@example.org"}})
   rejects(()->WifiConfigValues.validate(values(bad)),"invalid "+bad[0]);
  rejects(()->WifiConfigValues.decode("v2\n"),"unknown version");
  rejects(()->WifiConfigValues.decode("v1\nunknown\tx\n"),"unknown field");
  ek5 card=new ek5("001010000000001","test-profile-a");xi5 builtin=zl3.r(card);
  xi5 merged=(xi5)WifiConfigModel.merge(builtin,custom);
  check(merged.g.equals("ims.custom.example.org") && merged.h.equals("custom.ims"),"IMS domain/APN applied");
  List<Family> families=Arrays.asList(new Family("dual"),new Family("ipv6"),new Family("ipv4"));
  check(WifiConfigModel.addressFamilies(merged,families).size()==1 && WifiConfigModel.addressFamilies(merged,families).get(0)==families.get(2),"explicit IPv4 no fallback");
  check(WifiConfigModel.addressFamilies(builtin,families)==families,"default family fallback retained");
  xi5 ipv6=(xi5)WifiConfigModel.merge(builtin,WifiConfigValues.validate(values("ip","ipv6")));
  check(WifiConfigModel.addressFamilies(ipv6,families).get(0)==families.get(1),"explicit IPv6 no fallback");
  xi5 dual=(xi5)WifiConfigModel.merge(builtin,WifiConfigValues.validate(values("ip","dual")));
  check(WifiConfigModel.addressFamilies(dual,families)==families,"dual retains both families");
  check(merged.i==ak5.U && !merged.t,"IP and false IPsec applied");
  check(merged.r.equals(custom.get("nai")) && merged.s.equals(custom.get("impi")),"NAI and IMPI applied");
  check(merged.A.equals(custom.get("impu")) && merged.y.equals(custom.get("eap")),"IMPU and EAP applied");
  check(merged.p==45 && merged.w.equals(custom.get("imei")),"keepalive and IMEI applied");
  for(WifiConfigValues.Field f:WifiConfigValues.FIELDS) if(f.key.startsWith("ike_")||f.key.startsWith("esp_"))
   check(WifiConfigModel.get(merged,Character.toString((char)('a'+f.index))) instanceof WifiConfigValues.Algorithms,"explicit list marker "+f.key);
  check(merged.f.equals(Arrays.asList("epdg.example.org","backup.example.org")),"custom endpoints replace default");
  check(merged.z==builtin.z && merged.x==builtin.x && merged.u==builtin.u && merged.q==builtin.q && merged.v==builtin.v,"unexposed fields retained");
  check(builtin.t && builtin.g.equals("ims.example.org"),"built-in immutable");
  check(WifiConfigModel.merge(builtin,Collections.emptyMap())==builtin,"clear restores original object");
  xi5 narrow=(xi5)WifiConfigModel.merge(builtin,WifiConfigValues.validate(values("ike_encr","aes256","ike_integ","sha256","ike_prf","sha256","ike_dh","modp2048","esp_encr","aes256","esp_integ","sha256")));
  check(narrow.a==lj5.W && !Objects.equals(narrow.b,builtin.b),"equal lists still distinct state config");
  ArrayList<Transform> proposals=ike();WifiConfigModel.restrictIke(narrow,proposals);
  check(proposals.size()==4,"no unsolicited IKE alternatives");
  check(proposals.get(0).c==256 && proposals.get(1).b==5 && proposals.get(2).b==12 && proposals.get(3).b==14,"exact configured algorithms");
  ArrayList<Transform> normal=ike();WifiConfigModel.restrictIke(builtin,normal);check(normal.size()==10,"default negotiation retained");
  ArrayList<Transform> esp=new ArrayList<>(Arrays.asList(new Transform(1,12,256),new Transform(1,12,128),new Transform(3,12,null),new Transform(3,2,null),new Transform(5,0,null)));
  WifiConfigModel.restrictEsp(narrow,esp);check(esp.size()==3 && esp.get(2).a.T==5,"ESP narrowed and ESN preserved");
  ArrayList<Transform> retry=ike();retry.removeIf(t->t.a.T==4 && t.b==14);
  rejects(()->WifiConfigModel.restrictIke(narrow,retry),"server DH retry outside policy");
  Ctx ctx=new Ctx();zl5.f=ctx;zl5.b.value=state(card,builtin);
  check(WifiConfigRuntime.resolve(card,builtin)==builtin,"unmanaged config preserved");
  WifiConfigRuntime.Snapshot snapshot=WifiConfigRuntime.snapshot();
  check(snapshot.values.get("epdg").equals("legacy.epdg.example.org"),"migrate legacy edits");
  check(snapshot.defaults.get("domain").equals("ims.example.org"),"defaults fresh");
  Map<String,String> draft=new LinkedHashMap<>(snapshot.values);draft.put("domain","not-saved.example.org");
  check(((gl5)zl5.b.value).f==builtin,"draft and cancel have no effect");
  zl5.b.conflicts=2;WifiConfigRuntime.save(snapshot.key,custom);
  gl5 saved=(gl5)zl5.b.value;check(saved.f.g.equals("ims.custom.example.org") && saved.f.p==45,"save updates effective state with CAS retry");
  check(saved.i.equals(custom.get("smsc")) && saved.j.equals(custom.get("imei")),"SMSC and IMEI state fields applied");
  check(WifiConfigRuntime.snapshot().values.equals(custom),"reopen persisted overrides");
  int builds=zl3.builds;for(int i=0;i<100;i++)WifiConfigRuntime.resolve(card,builtin);
  check(zl3.builds==builds,"log/state updates use cached preset");
  ek5 reread=new ek5(card.a,card.b);zl5.b.value=state(reread,zl3.r(reread));
  check(((gl5)zl5.b.value).f.g.equals("ims.custom.example.org"),"reread reapplies per-card settings");
  ek5 other=new ek5("001010000000002","test-profile-b");xi5 otherBuiltin=zl3.r(other);zl5.b.value=state(other,otherBuiltin);
  check(((gl5)zl5.b.value).f==otherBuiltin,"another card isolated");
  rejects(()->WifiConfigRuntime.save(snapshot.key,custom),"stale card save");
  zl5.b.value=state(reread,zl3.r(reread));
  Map<String,String> partial=new LinkedHashMap<>(custom);partial.put("domain","");
  WifiConfigRuntime.save(snapshot.key,partial);
  check(((gl5)zl5.b.value).f.g.equals("ims.example.org") && ((gl5)zl5.b.value).f.p==45,"single clear doesn't reset other overrides");
  WifiConfigRuntime.save(snapshot.key,Collections.emptyMap());saved=(gl5)zl5.b.value;
  check(saved.f.g.equals("ims.example.org") && saved.f.t && saved.f.p==20,"clear restores built-in not last effective");
  check(saved.i.equals("") && saved.j.equals("") && saved.h.equals(""),"clear does not resurrect legacy global overrides");
  check(!(saved.f.j instanceof WifiConfigValues.Algorithms),"clear restores original proposal behavior");
  check(WifiConfigRuntime.snapshot().values.isEmpty(),"all-clear persists as managed empty");
  String previous=ctx.prefs.getString(snapshot.key,null);ctx.prefs.fail=true;
  rejects(()->WifiConfigRuntime.save(snapshot.key,custom),"disk write failure");
  check(ctx.prefs.getString(snapshot.key,null).equals(previous),"failed commit restores memory/disk state");
  ((gl5)zl5.b.value).k.busy=true;
  rejects(()->WifiConfigRuntime.save(snapshot.key,custom),"active connection can't edit");
  check(ctx.prefs.getString(snapshot.key,null).equals(previous),"busy save unchanged");
  ((gl5)zl5.b.value).k.busy=false;
  zl5.b.onCas=()->zl5.b.value=state(other,otherBuiltin);
  rejects(()->WifiConfigRuntime.save(snapshot.key,custom),"card swap during save");
  check(ctx.prefs.getString(snapshot.key,null).equals(previous),"card swap rolls back preference");
  check(!snapshot.key.contains(card.a) && snapshot.key.length()==64,"storage key omits card identifiers");
  zl5.b.value=state(reread,zl3.r(reread));
  ctx.prefs.data.put(snapshot.key,"v1\nunknown\tbad\n");
  WifiConfigRuntime.Snapshot damaged=WifiConfigRuntime.snapshot();
  check(damaged.warning!=null && damaged.values.isEmpty(),"corrupt record opens editable reset form");
  WifiConfigRuntime.save(snapshot.key,Collections.emptyMap());
  check(WifiConfigRuntime.snapshot().values.isEmpty(),"corrupt record can reset to defaults");
  System.out.println("PASS: "+passed+" Wi-Fi configuration assertions");
 }
}
