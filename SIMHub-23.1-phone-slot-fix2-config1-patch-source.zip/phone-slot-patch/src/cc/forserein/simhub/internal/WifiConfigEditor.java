package cc.forserein.simhub.internal;

import android.app.*;
import android.content.*;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.lang.ref.WeakReference;
import java.util.*;

/** Opens from the existing Compose configuration entry; drafts never change live settings. */
public final class WifiConfigEditor {
    private WifiConfigEditor() {}
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static final Map<Activity,WeakReference<AlertDialog>> OPEN=new WeakHashMap<>();
    private static final Set<Activity> PENDING=Collections.newSetFromMap(new WeakHashMap<Activity,Boolean>());
    public static void present(Context context,final Object onClose) {
        while(context instanceof ContextWrapper && !(context instanceof Activity)) {
            Context next=((ContextWrapper)context).getBaseContext();if(next==context) break;context=next;
        }
        if(!(context instanceof Activity)) {close(onClose);return;}
        final Activity activity=(Activity)context;
        if(activity.isFinishing() || activity.isDestroyed() || PENDING.contains(activity)) return;
        WeakReference<AlertDialog> ref=OPEN.get(activity);
        if(ref!=null && ref.get()!=null && ref.get().isShowing()) return;
        PENDING.add(activity);
        MAIN.post(() -> {
            PENDING.remove(activity);
            if(activity.isFinishing() || activity.isDestroyed()) return;
            try { show(activity,onClose,WifiConfigRuntime.snapshot()); }
            catch(Exception e) {Toast.makeText(activity,message(e),Toast.LENGTH_LONG).show();close(onClose);}
        });
    }
    private static String message(Throwable e) {
        while(e instanceof java.lang.reflect.InvocationTargetException && e.getCause()!=null) e=e.getCause();
        if(e instanceof IllegalArgumentException || e instanceof IllegalStateException) return e.getMessage();
        return "配置操作失败，请关闭页面后重试（"+e.getClass().getSimpleName()+"）";
    }
    private static void close(Object callback) {
        try {Class.forName("us1").getMethod("a").invoke(callback);}
        catch(Exception e) {android.util.Log.e("SIMHubConfig","Could not close configuration entry");}
    }
    private static int dp(Context c,int n) {return Math.round(n*c.getResources().getDisplayMetrics().density);}
    private static TextView text(Context context,String value,int size) {
        TextView v=new TextView(context);v.setText(value);v.setTextSize(size);v.setPadding(0,dp(context,8),0,dp(context,4));return v;
    }
    private static void show(Activity activity,Object callback,WifiConfigRuntime.Snapshot snapshot) {
        Context context=new ContextThemeWrapper(activity,android.R.style.Theme_DeviceDefault_Dialog_Alert);
        ScrollView scroll=new ScrollView(context);scroll.setFillViewport(true);
        LinearLayout body=new LinearLayout(context);body.setOrientation(LinearLayout.VERTICAL);
        int pad=dp(context,20);body.setPadding(pad,0,pad,pad);scroll.addView(body);
        body.addView(text(context,"填写值优先；留空保存后使用内置配置。设置仅对当前卡片生效，下次开启 Wi-Fi 通话时使用。",15));
        if(snapshot.warning!=null) body.addView(text(context,snapshot.warning,15));
        Map<String,EditText> inputs=new LinkedHashMap<>();
        String section="";
        for(WifiConfigValues.Field f:WifiConfigValues.FIELDS) {
            if(!section.equals(f.section)) {section=f.section;TextView heading=text(context,section,20);heading.setTypeface(null,1);body.addView(heading);}
            LinearLayout row=new LinearLayout(context);row.setGravity(Gravity.CENTER_VERTICAL);
            TextView label=text(context,f.label,16);row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            Button reset=new Button(context);reset.setText("使用内置");reset.setTextSize(12);
            reset.setContentDescription(f.label+"：清空并使用内置值");row.addView(reset);body.addView(row);
            EditText edit;
            if(f.key.equals("ip") || f.key.equals("ipsec")) {
                AutoCompleteTextView choice=new AutoCompleteTextView(context);choice.setThreshold(0);
                choice.setAdapter(new ArrayAdapter<String>(context,android.R.layout.simple_dropdown_item_1line,
                    f.key.equals("ip")?new String[]{"ipv4","ipv6","dual"}:new String[]{"on","off"}));
                choice.setOnFocusChangeListener((v,focused) -> {if(focused)choice.showDropDown();});
                choice.setOnClickListener(v -> choice.showDropDown());edit=choice;
            } else edit=new EditText(context);
            edit.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            edit.setSingleLine(!f.key.equals("epdg"));
            if(f.key.equals("epdg")){edit.setMinLines(2);edit.setMaxLines(5);edit.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);}
            if(f.key.equals("keepalive") || f.key.equals("imei")) edit.setInputType(InputType.TYPE_CLASS_NUMBER);
            edit.setText(snapshot.values.containsKey(f.key)?snapshot.values.get(f.key):"");
            edit.setHint("留空使用内置");edit.setTextSize(16);edit.setContentDescription(f.label);
            edit.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
            body.addView(edit,new LinearLayout.LayoutParams(-1,-2));inputs.put(f.key,edit);
            TextView hint=text(context,"内置："+snapshot.defaults.get(f.key)+"\n"+f.help,13);hint.setTextIsSelectable(true);body.addView(hint);
            reset.setOnClickListener(v -> {edit.setText("");edit.setError(null);});
        }
        AlertDialog dialog=new AlertDialog.Builder(context).setTitle("查看 / 修改配置").setView(scroll)
            .setNegativeButton("取消",(d,which) -> {})
            .setNeutralButton("全部使用内置",null).setPositiveButton("保存",null).create();
        Application.ActivityLifecycleCallbacks lifecycle=new Application.ActivityLifecycleCallbacks() {
            public void onActivityCreated(Activity a,Bundle b) {}
            public void onActivityStarted(Activity a) {}
            public void onActivityResumed(Activity a) {}
            public void onActivityPaused(Activity a) {}
            public void onActivityStopped(Activity a) {}
            public void onActivitySaveInstanceState(Activity a,Bundle b) {}
            public void onActivityDestroyed(Activity a) {if(a==activity)dialog.dismiss();}
        };
        activity.getApplication().registerActivityLifecycleCallbacks(lifecycle);
        dialog.setOnDismissListener(d -> {
            OPEN.remove(activity);activity.getApplication().unregisterActivityLifecycleCallbacks(lifecycle);
            if(!activity.isDestroyed()) close(callback);
        });
        OPEN.put(activity,new WeakReference<>(dialog));
        dialog.setOnShowListener(d -> {
            dialog.getButton(-3).setOnClickListener(v -> {for(EditText e:inputs.values()){e.setText("");e.setError(null);}});
            dialog.getButton(-1).setOnClickListener(v -> {
                Map<String,String> raw=new LinkedHashMap<>();
                for(Map.Entry<String,EditText> e:inputs.entrySet()){e.getValue().setError(null);raw.put(e.getKey(),e.getValue().getText().toString());}
                final Map<String,String> values;
                try {values=WifiConfigValues.validate(raw);}
                catch(WifiConfigValues.Invalid e) {
                    EditText input=inputs.get(e.key);
                    if(input!=null){input.setError(e.getMessage());input.requestFocus();scroll.smoothScrollTo(0,input.getTop());}
                    return;
                }
                dialog.setCancelable(false);
                for(int button:new int[]{-1,-2,-3}) dialog.getButton(button).setEnabled(false);
                dialog.getButton(-1).setText("保存中…");
                new Thread(() -> {
                    String failure=null;
                    try {WifiConfigRuntime.save(snapshot.key,values);}catch(Exception e){failure=message(e);}
                    final String error=failure;
                    MAIN.post(() -> {
                        if(!dialog.isShowing() || activity.isDestroyed()) return;
                        if(error==null){dialog.dismiss();Toast.makeText(activity,"已保存，下次开启 Wi-Fi 通话生效",Toast.LENGTH_LONG).show();}
                        else {
                            dialog.setCancelable(true);
                            for(int button:new int[]{-1,-2,-3})dialog.getButton(button).setEnabled(true);
                            dialog.getButton(-1).setText("保存");Toast.makeText(activity,error,Toast.LENGTH_LONG).show();
                        }
                    });
                },"simhub-config-save").start();
            });
        });
        dialog.show();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialog.getWindow().setLayout(-1,-1);
        body.setFocusableInTouchMode(true);body.requestFocus();
    }
}
