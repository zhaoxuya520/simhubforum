"""Exact-input hooks for the existing config entry, state and IKE/ESP proposals."""
import hashlib
import re

ORIGINAL_SHA256 = {
    'zl5.smali': '916faaec619ffee0fb49016d6d93bcd838733f3fc5b8cbe55253975baa05ed66',
    'gl5.smali': '8033ae822f8d0eb336ec22f601c892cb9e93c150916fbb0203f68e84d813afda',
    'yd2.smali': '9e6c65cea1672984f3fcd72517416369c62c7668ed61e5fb5d549247c9a29c9e',
    'b72.smali': 'cba2cef63be29e04187a5d4cf42e72eb702fd37c3e3a045ee1445ff77129bca9',
}
PREFIX = 'Lcc/forserein/simhub/internal/'

def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

def in_method(text, signature, edit):
    pattern = r'^\.method ' + re.escape(signature) + r'\n.*?^\.end method'
    assert len(re.findall(pattern, text, flags=re.M|re.S)) == 1, signature
    return re.sub(pattern, lambda m: edit(m[0]), text, flags=re.M|re.S)

def patch_wifi_class(name, text):
    assert hashlib.sha256(text.encode()).hexdigest() == ORIGINAL_SHA256[name], name
    if name == 'gl5.smali':
        signature = 'public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZLel5;Lek5;Lxi5;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lsd2;ZLhl5;Lfl5;Ljava/lang/Long;Ljava/util/List;Ljava/util/List;ZLjava/lang/String;J)V'
        def state(m):
            old = '    iput-object p6, p0, Lgl5;->f:Lxi5;'
            m = replace_once(m, old, f'''    invoke-static {{p5, p6}}, {PREFIX}WifiConfigRuntime;->resolve(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object p6
    check-cast p6, Lxi5;
{old}''')
            for param, field, method in [('p8','h','epdg'),('p9','i','smsc'),('p10','j','imei')]:
                old = f'    iput-object {param}, p0, Lgl5;->{field}:Ljava/lang/String;'
                m = replace_once(m, old, f'''    invoke-static {{p5, {param}}}, {PREFIX}WifiConfigRuntime;->{method}(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;
    move-result-object {param}
{old}''')
            return m
        return in_method(text, signature, state)
    if name == 'yd2.smali':
        old = '    invoke-static/range {v4 .. v11}, Lsd2;->a(Lus1;ZZZLzn0;Llu1;II)V'
        new = f'''    sget-object v0, Lh7;->b:Lhu4;
    invoke-virtual {{p1, v0}}, Llu1;->k(Lrv3;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/content/Context;
    invoke-static {{v0, p0}}, {PREFIX}WifiConfigEditor;->present(Landroid/content/Context;Ljava/lang/Object;)V'''
        return in_method(text, 'public static final j(Lus1;Llu1;I)V', lambda m:replace_once(m,old,new))
    if name == 'zl5.smali':
        # u() is a suspend method with 91 locals. v10 is the config and v4 the candidate
        # inner families at this single initial-attempt anchor; no coroutine slots change.
        old = '    :goto_f\n    invoke-static {v8, v5}, Lyk0;->T0(Ljava/lang/Iterable;I)Ljava/util/List;'
        new = f'''    :goto_f
    invoke-static {{v10, v4}}, {PREFIX}WifiConfigModel;->addressFamilies(Ljava/lang/Object;Ljava/util/List;)Ljava/util/List;
    move-result-object v4
    invoke-static {{v8, v5}}, Lyk0;->T0(Ljava/lang/Iterable;I)Ljava/util/List;'''
        return in_method(text, 'public final u(Lac5;Lxi5;Lek5;ILdt0;)Ljava/lang/Object;', lambda m:replace_once(m,old,new))
    if name == 'b72.smali':
        # Before p0 is reused for the result; preserve every live register and SPI generation.
        old = '    new-instance p0, Lf52;'
        text = in_method(text, 'public final j(Ljava/util/List;)Lf52;', lambda m:replace_once(m,old,
            f'    invoke-static {{p0, v0}}, {PREFIX}WifiConfigModel;->restrictIke(Ljava/lang/Object;Ljava/util/ArrayList;)V\n'+old))
        # v6/v7 held 0x100 for OR-ing the SPI and are dead here; next use defines both again.
        return in_method(text, 'public final f()Lf52;', lambda m:replace_once(m,old,
            f'    iget-object v6, p0, Lb72;->a:Lxi5;\n    invoke-static {{v6, v0}}, {PREFIX}WifiConfigModel;->restrictEsp(Ljava/lang/Object;Ljava/util/ArrayList;)V\n'+old))
    raise AssertionError(name)
