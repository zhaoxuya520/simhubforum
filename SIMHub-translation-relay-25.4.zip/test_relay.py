import asyncio
import base64
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import tempfile
import unittest

from aiohttp import web, WSMsgType
from aiohttp.test_utils import TestClient, TestServer

from relay import application, MODEL, pair


class RelayTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.devices = Path(self.temp.name) / "devices"
        self.token = self.pair_phone()
        self.headers = {"Authorization": "Bearer " + self.token}
        self.received = []
        self.live_connections = 0
        self.google = TestServer(self.provider_app())
        await self.google.start_server()
        self.client = TestClient(TestServer(self.relay_app()))
        await self.client.start_server()

    def pair_phone(self):
        output = io.StringIO()
        with redirect_stdout(output):
            pair("https://relay.example", self.devices)
        return output.getvalue().strip().split("#")[1]

    def relay_app(self):
        return application(
            "test-google-key",
            self.devices,
            caption_url=self.google.make_url("/caption"),
            live_url=self.google.make_url("/live"),
        )

    def provider_app(self):
        app = web.Application()
        app.router.add_post("/caption", self.google_caption)
        app.router.add_get("/live", self.google_live)
        return app

    def verify_upstream(self, req):
        self.assertEqual(req.headers.get("x-goog-api-key"), "test-google-key")
        self.assertNotIn("Authorization", req.headers)
        self.assertFalse(req.query)

    async def google_caption(self, req):
        self.verify_upstream(req)
        data = await req.json()
        self.assertIn("zh-Hans", data["systemInstruction"]["parts"][0]["text"])
        self.assertNotIn(self.token, json.dumps(data))
        self.received.append(data)
        return web.json_response(
            {
                "candidates": [
                    {
                        "finishReason": "STOP",
                        "content": {
                            "parts": [{"text": json.dumps({"caption": "你好"})}]
                        },
                    }
                ]
            }
        )

    async def google_live(self, req):
        self.verify_upstream(req)
        ws = web.WebSocketResponse()
        await ws.prepare(req)
        self.live_connections += 1
        setup = (await ws.receive_json())["setup"]
        self.assertEqual(setup["model"], "models/" + MODEL)
        self.assertEqual(
            setup["generationConfig"]["translationConfig"]["targetLanguageCode"],
            "zh-Hans",
        )
        await ws.send_json({"setupComplete": {}})
        async for msg in ws:
            if msg.type != WSMsgType.TEXT:
                break
            audio = json.loads(msg.data)["realtimeInput"]["audio"]
            self.assertEqual(audio["mimeType"], "audio/pcm;rate=16000")
            samples = base64.b64decode(audio["data"])
            if any(samples):
                self.received.append(samples)
                if bytes((0, 32)) * 4 in samples:
                    await ws.close()
                    break
                if bytes((0, 24)) * 4 in samples:
                    await ws.send_json({"goAway": {"timeLeft": "30s"}})
                await ws.send_json(
                    {
                        "serverContent": {
                            "outputTranscription": {"text": "你好"},
                            "modelTurn": {
                                "parts": [
                                    {
                                        "inlineData": {
                                            "mimeType": "audio/pcm;rate=24000",
                                            "data": base64.b64encode(
                                                bytes((0, 10)) * 2400
                                            ).decode(),
                                        }
                                    }
                                ]
                            },
                            "turnComplete": True,
                        }
                    }
                )
        return ws

    async def asyncTearDown(self):
        await self.client.close()
        await self.google.close()
        self.temp.cleanup()

    async def test_pairing_and_caption(self):
        payload = {
            "target": "zh-Hans",
            "previous": "上文",
            "wav": base64.b64encode(b"RIFF" + bytes(4) + b"WAVE" + bytes(64)).decode(),
        }
        for headers, code in [
            ({}, 401),
            ({"Authorization": self.token}, 401),
            ({"Authorization": "Bearer sh1_" + "z" * 43}, 403),
        ]:
            response = await self.client.post(
                "/v1/caption", json=payload, headers=headers
            )
            self.assertEqual(response.status, code)
        response = await self.client.post(
            "/v1/caption", json=payload, headers=self.headers
        )
        self.assertEqual(await response.json(), {"caption": "你好"})
        parts = self.received[0]["contents"][0]["parts"]
        self.assertIn("上文", parts[0]["text"])
        self.assertEqual(parts[1]["inlineData"]["data"], payload["wav"])

    async def test_live_stream_and_isolation(self):
        async def start():
            return await self.client.post(
                "/v1/live", json={"target": "zh-Hans"}, headers=self.headers
            )

        path = "/v1/live/" + (await (await start()).json())["session"]
        self.assertEqual((await start()).status, 409)
        other = {"Authorization": "Bearer " + self.pair_phone()}
        self.assertEqual((await self.client.delete(path, headers=other)).status, 404)
        events = await self.client.get(path + "/events", headers=self.headers)

        async def event():
            return json.loads(await asyncio.wait_for(events.content.readline(), 3))

        self.assertTrue((await event())["ready"])
        complete = asyncio.Event()

        async def microphone():
            yield bytes((4, 1)) * 1600
            await complete.wait()

        upload = asyncio.create_task(
            self.client.post(path + "/audio", data=microphone(), headers=self.headers)
        )
        try:
            self.assertEqual(await event(), {"text": "你好"})
            self.assertEqual(
                base64.b64decode((await event())["pcm"]), bytes((0, 10)) * 2400
            )
            self.assertEqual(await event(), {"end": True})
        finally:
            complete.set()
            self.assertEqual((await upload).status, 204)
            events.close()
        self.assertEqual(
            (await self.client.delete(path, headers=self.headers)).status, 404
        )

    async def test_announced_connection_rotation(self):
        start = await self.client.post(
            "/v1/live", json={"target": "zh-Hans"}, headers=self.headers
        )
        path = "/v1/live/" + (await start.json())["session"]
        events = await self.client.get(path + "/events", headers=self.headers)
        await events.content.readline()
        finish = asyncio.Event()
        second = asyncio.Event()

        async def data():
            yield bytes((0, 24)) * 1600
            await second.wait()
            yield bytes((1, 1)) * 1600
            await finish.wait()

        up = asyncio.create_task(
            self.client.post(path + "/audio", headers=self.headers, data=data())
        )
        try:
            for _ in range(2):
                while True:
                    row = await asyncio.wait_for(events.content.readline(), 3)
                    if json.loads(row).get("end"):
                        break
                second.set()
            self.assertEqual(self.live_connections, 2)
        finally:
            finish.set()
            await up
            events.close()
