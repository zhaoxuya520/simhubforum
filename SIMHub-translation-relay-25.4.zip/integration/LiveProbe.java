package cc.forserein.simhub.internal;

import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public final class LiveProbe implements CaptionBackend.Listener {
    final CountDownLatch ready=new CountDownLatch(1), text=new CountDownLatch(1), partial=new CountDownLatch(1);
    volatile String error;
    public void onReady(){ready.countDown();}
    public void onPartial(String caption){if (caption.equals("你好")) partial.countDown();}
    public void onText(String caption){if (caption.equals("你好")) text.countDown();}
    public void onError(String detail){error=detail;}
    public static void main(String[] args) throws Exception {
        String link=args[0];
        int rate=Integer.parseInt(args[1]);
        LiveProbe probe=new LiveProbe();
        try(CaptionBackend backend=new CaptionBackend(link,"zh-Hans",rate,probe)){
            backend.enableVoice(link,"zh-Hans");
            short[] frame=new short[rate/100];
            Arrays.fill(frame,(short)777);
            backend.render(frame);
            if(frame[0]!=777)throw new AssertionError("original audio before connection");
            backend.start();
            if(!probe.ready.await(6,TimeUnit.SECONDS))throw new AssertionError("connect: "+probe.error);
            backend.render(frame);
            if(frame[0]!=0)throw new AssertionError("suppress original when interpreting");
            short[] remote=new short[rate/50];
            Arrays.fill(remote,(short)1234);
            for(int i=0;i<5;i++) backend.offer(remote,0,remote.length);
            if(!probe.text.await(5,TimeUnit.SECONDS)||!probe.partial.await(1,TimeUnit.SECONDS))
                throw new AssertionError("translated subtitle: "+probe.error);
            backend.render(frame);
            for(short sample:frame) if(sample!=2560) throw new AssertionError("translated PCM");
            Arrays.fill(remote,(short)8192);
            for(int i=0;i<5;i++) backend.offer(remote,0,remote.length);
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(4);
            while(probe.error==null && System.nanoTime()<deadline) Thread.sleep(20);
            if(probe.error==null)throw new AssertionError("upstream disconnect unreported");
            Arrays.fill(frame,(short)777);
            backend.render(frame);
            if(frame[0]!=777)throw new AssertionError("original audio after network failure");
            backend.close();
            Arrays.fill(frame,(short)777);
            backend.render(frame);
            if(frame[0]!=777)throw new AssertionError("original audio after close");
        }
        LiveProbe captions=new LiveProbe();
        try(CaptionBackend backend=new CaptionBackend(link,"zh-Hans",rate,captions)){
            backend.start();
            if(!captions.ready.await(2,TimeUnit.SECONDS))throw new AssertionError("caption worker");
            short[] speech=new short[rate/50];
            for(int i=0;i<speech.length;i++) speech[i]=(short)((i%2==0)?2000:-2000);
            for(int i=0;i<8;i++) backend.offer(speech,0,speech.length);
            for(int i=0;i<24;i++) backend.offer(null,0,0);
            if(!captions.text.await(5,TimeUnit.SECONDS))throw new AssertionError("caption HTTPS request: "+captions.error);
            short[] original={777};
            backend.render(original);
            if(original[0]!=777)throw new AssertionError("caption-only audio");
        }
        System.out.println("PASS "+rate+" Hz: TLS captions with original audio, simultaneous upload/download, partial+final text, translated playout, original on disconnect and stop");
    }
}
