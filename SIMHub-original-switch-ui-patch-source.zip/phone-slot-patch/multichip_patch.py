"""Coordinate every discovered multi-chip reader and protect its AID selection while suspended."""
from pathlib import Path
import shutil

def patch_chip_selection(text):
    anchor='.method public final D(Ljava/lang/String;)V\n'
    assert text.count(anchor)==1 and ':multichip_selection_allowed' not in text
    start=text.index(anchor)+len(anchor)
    local_end=text.index('\n',text.index('    .locals ',start))
    return text[:local_end]+'''\n    invoke-static {p0}, Lcc/forserein/simhub/internal/MultiChipSwitch;->allowSelection(Ljava/lang/Object;)Z
    move-result v0
    if-nez v0, :multichip_selection_allowed
    return-void
    :multichip_selection_allowed'''+text[local_end:]

def apply_multichip(smali):
    path=Path(smali)/'cg0.smali'
    text=path.read_text()
    assert text.count('new-instance p1, Lhz3;')==1
    assert text.count('Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V')==1
    text=text.replace('new-instance p1, Lhz3;', 'new-instance p1, LInternalSimMultiChipSwitch;')
    text=text.replace('Lhz3;-><init>(Liz3;Lqy3;ZLct0;)V','LInternalSimMultiChipSwitch;-><init>(Liz3;Lqy3;ZLct0;)V')
    path.write_text(text)
    for name in ('InternalSimMultiChipSwitch.smali','InternalSimCheckedRead.smali','InternalSimChipRead.smali'):
        shutil.copyfile(Path(__file__).parent/'smali'/name,Path(smali)/name)
    path=Path(smali)/'iz3.smali'
    path.write_text(patch_chip_selection(path.read_text()))

