#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import os
import re
import struct
import subprocess
import zipfile
import xml.etree.ElementTree as ET
from signing_policy import patch_security_policy, test_signer_digest
from dialing_patch import ORIGINAL_SHA256, patch_dialing_class

ROOT = Path(__file__).resolve().parent
ORIGINAL = Path(os.environ.get('SIMHUB_RECOVERED', '/workspace/recovered/SIMHub-Android-23.1'))
APK = ROOT / 'build/SIMHub-23.1-internal-sim-unsigned.apk'
DECODED = ROOT / 'build/apktool'
SMALI = DECODED / 'smali'

def descriptors(data):
    u32 = lambda at: struct.unpack_from('<I', data, at)[0]
    strings, types, definitions = u32(60), u32(68), u32(100)
    result = set()
    for i in range(u32(96)):
        string_id = u32(types + 4 * u32(definitions + i * 32))
        p = u32(strings + 4 * string_id)
        while data[p] & 128: p += 1
        p += 1
        result.add(data[p:data.index(b'\0', p)].decode('utf-8'))
    return result

old = descriptors((ORIGINAL / 'original-bytecode/classes.dex').read_bytes())
with zipfile.ZipFile(APK) as archive:
    assert archive.testzip() is None
    new = descriptors(archive.read('classes.dex'))
    assert old <= new
    assert all(name in ('LInternalSimReaderTask;', 'LInternalSimConnectContinuation;', 'LInternalSimProfileState;', 'LInternalSimChannelDispatch;', 'LInternalSimChannelContinuation;', 'LInternalSimProfileUi;') or name.startswith('Lcc/forserein/simhub/internal/') for name in new - old)
    assert not any(name.startswith('Landroid/') for name in new - old), 'Test doubles leaked into APK'
    asset_count = 0
    changed_assets = []
    for path in (ORIGINAL / 'apktool').rglob('*'):
        relative = path.relative_to(ORIGINAL / 'apktool').as_posix()
        if path.is_file() and relative.startswith(('assets/', 'lib/')):
            if path.read_bytes() == archive.read(relative):
                asset_count += 1
            else:
                changed_assets.append(relative)
    assert changed_assets == ['assets/i18n/zh-Hans.strings'], changed_assets
expected_changes = {'lf3.smali', 'qf3.smali', 'qf5.smali', 'pf3.smali', 'nf3.smali', 'rf1.smali', 'hz3.smali', 'hh1.smali', 'ac5.smali', 'mg.smali', 'bf0.smali'}
expected_changes.update(ORIGINAL_SHA256)
actual_changes = set()
for source in (ORIGINAL / 'apktool/smali').rglob('*.smali'):
    rel = source.relative_to(ORIGINAL / 'apktool/smali')
    if source.read_bytes() != (SMALI / rel).read_bytes(): actual_changes.add(rel.as_posix())
assert actual_changes == expected_changes, actual_changes
for name in ORIGINAL_SHA256:
    assert (SMALI / name).read_text() == patch_dialing_class(name, (ORIGINAL / 'apktool/smali' / name).read_text()), name
assert (SMALI / 'mg.smali').read_text() == patch_security_policy((ORIGINAL / 'apktool/smali/mg.smali').read_text()), 'Security bytecode changed beyond the pinned signer addition'
assert (SMALI / 'tb0.smali').read_bytes() == (ORIGINAL / 'apktool/smali/tb0.smali').read_bytes(), 'Card-operation security gate changed'
profile_ui_call = '''    move-object/from16 v1, p0
    iget-object v1, v1, Lbf0;->W:Liz3;
    invoke-static {v0, v1, v10, v7}, LInternalSimProfileUi;->render(Lus1;Liz3;Llu1;I)V'''
profile_original_call = '    invoke-static {v0, v10, v7}, Lna2;->q(Lus1;Llu1;I)V'
profile_screen = (SMALI / 'bf0.smali').read_text()
assert profile_screen.count(profile_ui_call) == 1
assert profile_screen.replace(profile_ui_call, profile_original_call) == (ORIGINAL / 'apktool/smali/bf0.smali').read_text(), 'Profile screen changed beyond the empty/error-state dispatcher'
assert (SMALI / 'na2.smali').read_bytes() == (ORIGINAL / 'apktool/smali/na2.smali').read_bytes(), 'Shared Compose renderers changed'

# Cross-check every new helper invocation's exact descriptor against generated definitions.
definitions = set()
adapters = ['InternalSimReaderTask.smali', 'InternalSimConnectContinuation.smali', 'InternalSimProfileState.smali', 'InternalSimChannelDispatch.smali', 'InternalSimChannelContinuation.smali', 'InternalSimProfileUi.smali']
for source in list((SMALI / 'cc/forserein/simhub/internal').glob('*.smali')) + [SMALI / name for name in adapters]:
    text = source.read_text()
    cls = re.search(r'^\.class (?:[^\n]* )?(L\S+;)$', text, re.M)[1]
    for signature in re.findall(r'^\.method .* ([^ ]+\([^\n]+)$', text, re.M):
        definitions.add(cls + '->' + signature)
checked = 0
for name in list(expected_changes) + adapters:
    for ref in re.findall(r'invoke-[^\n]+, (L(?:cc/forserein/simhub/internal/|InternalSim)[^\n]+)', (SMALI / name).read_text()):
        assert ref in definitions, ref
        checked += 1
android = '{http://schemas.android.com/apk/res/android}'
manifest = ET.parse(DECODED / 'AndroidManifest.xml').getroot()
before = ET.parse(ORIGINAL / 'apktool/AndroidManifest.xml').getroot()
assert ET.tostring(manifest) == ET.tostring(before), 'Unexpected component or permission change'
assert 'Lcc/forserein/simhub/internal/InternalSimDiagnosticsActivity;' not in new, 'Obsolete separate diagnostics page included'
permissions = lambda m: {p.get(android + 'name') for p in m.findall('uses-permission')}
assert permissions(manifest) == permissions(before)

# Verify that integration retains the original downstream management and IMS backend,
# not just a disconnected new discovery UI. Only the logical-channel dispatcher is changed
# inside the management/authentication backend classes.
dispatch = 'LInternalSimChannelDispatch;->open(Lfu0;Lkt1;Lct0;)Ljava/lang/Object;'
for name in ('hh1.smali', 'ac5.smali'):
    patched = (SMALI / name).read_text()
    original = (ORIGINAL / 'apktool/smali' / name).read_text()
    assert patched.count(dispatch) == 1
    assert patched.replace(dispatch, 'Lxq0;->g0(Lfu0;Lkt1;Lct0;)Ljava/lang/Object;') == original
pf = (SMALI / 'pf3.smali').read_text()
assert '.field public pendingChannel:Lcc/forserein/simhub/internal/ChannelLease;' in pf
clone = pf.split('.method public final o(', 1)[1].split('.end method', 1)[0]
assert 'iget-object v1, p0, Lpf3;->pendingChannel:' in clone
assert 'iput-object v1, v0, Lpf3;->pendingChannel:' in clone
route = {
    'iz3.smali': ['Llf3;->a(Landroid/content/Context;Ljava/lang/String;Ldt0;)',
                  'Liz3;->b(Lqg0;Lay3;Ljava/lang/String;Ldt0;)',
                  'Liz3;->z(Ldt0;)', 'Liz3;->w(ZLdt0;)'],
    'hh1.smali': ['Ls4;', 'Lpf3;-><init>(Lqf3;[BLct0;)V'],
    'ac5.smali': ['Ls4;', 'Lpf3;-><init>(Lqf3;[BLct0;)V'],
    'tf0.smali': ['Lpx3;->e(Liz3;Lm83;ZLcz4;I)'],
    'px3.smali': ['Lzl5;->d(Lqg0;Ljava/lang/String;Ldt0;)'],
    'zl5.smali': ['Lac5;-><init>(Lqg0;Landroid/content/Context;)V'],
}
for file, references in route.items():
    text = (SMALI / file).read_text()
    for ref in references: assert ref in text, (file, ref)
subprocess.run([str(Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery')) / 'sdk/android-15/zipalign'), '-c', '-P', '16', '4', str(APK)], check=True)
digest = hashlib.sha256(APK.read_bytes()).hexdigest()
APK.with_suffix('.apk.sha256').write_text(digest + '  ' + APK.name + '\n')
tests = json.loads((ROOT / 'build/test-results.json').read_text())
flow = json.loads((ROOT / 'build/refresh-flow-results.json').read_text())
assert flow['failed'] == flow['errors'] == 0 and flow['cases'] == 10
dialing = json.loads((ROOT / 'build/dialing-integration-results.json').read_text())
assert dialing['failed'] == 0
report = {
    'apk_sha256': digest,
    'original_classes': len(old), 'patched_classes': len(new), 'new_classes': sorted(new - old),
    'changed_original_classes': sorted(actual_changes), 'helper_references_checked': checked,
    'assets_and_native_files_identical': asset_count, 'zip_integrity': 'passed',
    'changed_assets': changed_assets,
    'zip_alignment_16k_native_libraries': 'passed', 'new_permissions': [],
    'protocol_assertions': tests['SimProtocolTest'],
    'omapi_adapter_assertions_using_test_doubles': tests['OmapiSupportTest'],
    'connection_ownership_assertions_using_test_doubles': tests['ConnectionLeaseTest'],
    'profile_refresh_and_confirmation_assertions': tests['ProfileRefreshTest'],
    'channel_ownership_and_concurrency_assertions': tests['ChannelLeaseTest'],
    'profile_read_state_assertions': tests['ProfileReadStateTest'],
    'dialing_normalization_assertions': tests['DialingSupportTest'],
    'dialing_integration_static_checks': dialing['checks'],
    'mainland_destination_app_block': 'removed',
    'sms_destination_normalization': 'ASCII decimal digits, fullwidth plus, 00 international prefix',
    'refresh_flow_simulated_cases': flow['cases'],
    'separate_diagnostic_activity': False, 'original_management_and_ims_route': 'preserved_static_check',
    'signing': 'unsigned', 'android_device_test': 'not_run',
    'declared_test_signer_sha256': test_signer_digest(),
    'security_check_change': 'add_pinned_test_certificate_only',
    'oneplus13_esim_management': 'not_verified', 'oneplus13_aka_ims_wifi_calling': 'not_verified'
}
(ROOT / 'build/validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
