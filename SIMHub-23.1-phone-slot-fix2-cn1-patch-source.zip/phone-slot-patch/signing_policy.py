"""Bind the test build's existing self-check to its public signing certificate."""
from pathlib import Path
import hashlib
import re
import ssl

ROOT = Path(__file__).resolve().parent
PUBLIC_CERTIFICATE = ROOT / 'signing/local-test-certificate.pem'
ORIGINAL_SIGNERS = (
    'dd0dddbee79fc418ccf1523e670ff62f22926ed76a8ff50b1b63106195deab13',
    '4139278aacce8338c03dc9a6b0172c1880e0a4949ff3e05292c2e781765026fa',
    '6966004ad0161165335f9204f8f5a52df49fe068c9545c0c589c23221af8d3a4',
)
ORIGINAL_ALLOWLIST = ','.join(ORIGINAL_SIGNERS)


def test_signer_digest():
    pem = PUBLIC_CERTIFICATE.read_text().strip()
    if not re.fullmatch(r'-----BEGIN CERTIFICATE-----\s+[A-Za-z0-9+/=\s]+-----END CERTIFICATE-----', pem):
        raise ValueError('Expected exactly one public X.509 certificate')
    return hashlib.sha256(ssl.PEM_cert_to_DER_cert(pem)).hexdigest()


def expected_allowlist():
    digest = test_signer_digest()
    if digest in ORIGINAL_SIGNERS:
        raise ValueError('Test signing certificate unexpectedly matches an original signer')
    return ORIGINAL_ALLOWLIST + ',' + digest


def patch_security_policy(original):
    before = 'const-string v2, "' + ORIGINAL_ALLOWLIST + '"'
    after = 'const-string v2, "' + expected_allowlist() + '"'
    method = original.split('.method public static a(Landroid/content/Context;)Z\n', 1)[1].split('.end method', 1)[0]
    if original.count(before) != 1 or method.count(before) != 1:
        raise ValueError('Unexpected original signature-check bytecode')
    # Preserve signature hashing, rejection paths, debugger and hook checks.
    return original.replace(before, after)
