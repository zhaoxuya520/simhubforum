.class public final LInternalSimProfileUi;
.super Ljava/lang/Object;

.method public static render(Lus1;Liz3;Llu1;I)V
    .locals 6
    invoke-virtual {p1}, Liz3;->s()Lqg0;
    move-result-object v0
    instance-of v0, v0, Lqf3;
    invoke-virtual {p1}, Liz3;->n()Ljava/lang/String;
    move-result-object v1
    invoke-virtual {p1}, Liz3;->o()Ljava/lang/String;
    move-result-object v2
    invoke-static {v0, v1, v2}, Lcc/forserein/simhub/internal/ProfileReadState;->unconfirmed(ZLjava/lang/String;Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, :confirmed
    invoke-static {}, Lge2;->u()Lqb2;
    move-result-object v0
    const-string v1, "尚未读取到配置\n读取失败或尚未完成，不能判断卡内是否有 Profile。"
    const/4 v2, 0x0
    const/4 v3, 0x0
    move-object v4, p2
    const/4 v5, 0x0
    invoke-static/range {v0 .. v5}, Lna2;->p(Lqb2;Ljava/lang/String;Ljava/lang/String;Lus1;Llu1;I)V
    return-void
    :confirmed
    invoke-static {p0, p2, p3}, Lna2;->q(Lus1;Llu1;I)V
    return-void
.end method
