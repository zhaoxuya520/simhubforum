.class public final LInternalSimReaderTask;
.super Ljava/lang/Object;
.implements Lkt1;

.field private final context:Landroid/content/Context;
.field private final name:Ljava/lang/String;
.field private final lease:Lcc/forserein/simhub/internal/ConnectionLease;

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, LInternalSimReaderTask;->context:Landroid/content/Context;
    iput-object p2, p0, LInternalSimReaderTask;->name:Ljava/lang/String;
    new-instance v0, Lcc/forserein/simhub/internal/ConnectionLease;
    invoke-direct {v0}, Lcc/forserein/simhub/internal/ConnectionLease;-><init>()V
    iput-object v0, p0, LInternalSimReaderTask;->lease:Lcc/forserein/simhub/internal/ConnectionLease;
    return-void
.end method

.method public final complete(Z)V
    .locals 1
    iget-object v0, p0, LInternalSimReaderTask;->lease:Lcc/forserein/simhub/internal/ConnectionLease;
    invoke-virtual {v0, p1}, Lcc/forserein/simhub/internal/ConnectionLease;->complete(Z)V
    return-void
.end method

.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    iget-object v0, p0, LInternalSimReaderTask;->context:Landroid/content/Context;
    iget-object v1, p0, LInternalSimReaderTask;->name:Ljava/lang/String;
    if-nez v1, :open
    sget-object v1, Lnk2;->b:Ljava/util/List;
    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/OmapiSupport;->discover(Landroid/content/Context;Ljava/util/List;)[Ljava/lang/String;
    move-result-object v0
    new-instance v1, Ljava/util/ArrayList;
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    const/4 v2, 0x0
    array-length v3, v0
    :loop
    if-ge v2, v3, :done
    aget-object v4, v0, v2
    new-instance v5, Lgf3;
    invoke-direct {v5, v4}, Lgf3;-><init>(Ljava/lang/String;)V
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    add-int/lit8 v2, v2, 0x1
    goto :loop
    :done
    return-object v1
    :open
    invoke-static {v0}, Lcc/forserein/simhub/internal/OmapiSupport;->connect(Landroid/content/Context;)Landroid/se/omapi/SEService;
    move-result-object v2
    :try_start
    iget-object v5, p0, LInternalSimReaderTask;->lease:Lcc/forserein/simhub/internal/ConnectionLease;
    invoke-virtual {v5, v2}, Lcc/forserein/simhub/internal/ConnectionLease;->attach(Landroid/se/omapi/SEService;)V
    invoke-static {v0, v2, v1}, Lcc/forserein/simhub/internal/OmapiSupport;->select(Landroid/content/Context;Landroid/se/omapi/SEService;Ljava/lang/String;)Landroid/se/omapi/Reader;
    move-result-object v3
    new-instance v4, Lqf3;
    invoke-direct {v4, v2, v3}, Lqf3;-><init>(Landroid/se/omapi/SEService;Landroid/se/omapi/Reader;)V
    :try_end
    .catchall {:try_start .. :try_end} :cleanup
    return-object v4
    :cleanup
    move-exception v0
    const/4 v1, 0x0
    invoke-virtual {p0, v1}, LInternalSimReaderTask;->complete(Z)V
    throw v0
.end method
