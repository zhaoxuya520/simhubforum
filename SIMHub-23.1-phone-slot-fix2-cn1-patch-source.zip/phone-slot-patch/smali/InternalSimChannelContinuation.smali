.class public final LInternalSimChannelContinuation;
.super Ljava/lang/Object;
.implements Lct0;

.field private final delegate:Lct0;
.field private final lease:Lcc/forserein/simhub/internal/ChannelLease;

.method public constructor <init>(Lct0;Lcc/forserein/simhub/internal/ChannelLease;)V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, LInternalSimChannelContinuation;->delegate:Lct0;
    iput-object p2, p0, LInternalSimChannelContinuation;->lease:Lcc/forserein/simhub/internal/ChannelLease;
    return-void
.end method

.method public final h()Lfu0;
    .locals 1
    iget-object v0, p0, LInternalSimChannelContinuation;->delegate:Lct0;
    invoke-interface {v0}, Lct0;->h()Lfu0;
    move-result-object v0
    return-object v0
.end method

.method public final s(Ljava/lang/Object;)V
    .locals 2
    :try_start
    invoke-static {p1}, Loc2;->N(Ljava/lang/Object;)V
    :try_end
    .catchall {:try_start .. :try_end} :failed
    const/4 v0, 0x1
    goto :complete
    :failed
    move-exception v0
    const/4 v0, 0x0
    :complete
    iget-object v1, p0, LInternalSimChannelContinuation;->lease:Lcc/forserein/simhub/internal/ChannelLease;
    invoke-virtual {v1, v0}, Lcc/forserein/simhub/internal/ChannelLease;->complete(Z)V
    iget-object v0, p0, LInternalSimChannelContinuation;->delegate:Lct0;
    invoke-interface {v0, p1}, Lct0;->s(Ljava/lang/Object;)V
    return-void
.end method
