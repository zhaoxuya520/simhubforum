.class public final LInternalSimChannelDispatch;
.super Ljava/lang/Object;

.method public static open(Lfu0;Lkt1;Lct0;)Ljava/lang/Object;
    .locals 3
    move-object v0, p1
    check-cast v0, Lpf3;
    iget-object v0, v0, Lpf3;->pendingChannel:Lcc/forserein/simhub/internal/ChannelLease;
    new-instance v1, LInternalSimChannelContinuation;
    invoke-direct {v1, p2, v0}, LInternalSimChannelContinuation;-><init>(Lct0;Lcc/forserein/simhub/internal/ChannelLease;)V
    :try_start
    invoke-static {p0, p1, v1}, Lxq0;->g0(Lfu0;Lkt1;Lct0;)Ljava/lang/Object;
    move-result-object v2
    :try_end
    .catchall {:try_start .. :try_end} :failed
    sget-object v1, Lpu0;->T:Lpu0;
    if-eq v2, v1, :return
    const/4 v1, 0x1
    invoke-virtual {v0, v1}, Lcc/forserein/simhub/internal/ChannelLease;->complete(Z)V
    :return
    return-object v2
    :failed
    move-exception v2
    const/4 v1, 0x0
    invoke-virtual {v0, v1}, Lcc/forserein/simhub/internal/ChannelLease;->complete(Z)V
    throw v2
.end method
