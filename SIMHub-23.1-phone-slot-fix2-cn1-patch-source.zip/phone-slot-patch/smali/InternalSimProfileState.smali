.class public final LInternalSimProfileState;
.super Ljava/lang/Object;

.method public static matches(Ljava/util/List;Ljava/lang/String;Z)Z
    .locals 6
    if-eqz p0, :invalid
    invoke-interface {p0}, Ljava/util/List;->size()I
    move-result v0
    new-array v1, v0, [Ljava/lang/String;
    new-array v2, v0, [Z
    const/4 v3, 0x0
    :loop
    if-ge v3, v0, :check
    invoke-interface {p0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v4
    instance-of v5, v4, Lqy3;
    if-eqz v5, :invalid
    check-cast v4, Lqy3;
    iget-object v5, v4, Lqy3;->a:Ljava/lang/String;
    aput-object v5, v1, v3
    iget-boolean v5, v4, Lqy3;->b:Z
    aput-boolean v5, v2, v3
    add-int/lit8 v3, v3, 0x1
    goto :loop
    :check
    invoke-static {p1, p2, v1, v2}, Lcc/forserein/simhub/internal/ProfileRefresh;->confirmed(Ljava/lang/String;Z[Ljava/lang/String;[Z)Z
    move-result v0
    return v0
    :invalid
    const/4 v0, 0x0
    return v0
.end method
