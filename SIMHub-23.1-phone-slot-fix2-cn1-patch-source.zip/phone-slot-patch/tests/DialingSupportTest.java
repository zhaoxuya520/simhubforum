import cc.forserein.simhub.internal.DialingSupport;

public final class DialingSupportTest {
    private static int passed;
    private static void eq(String expected, String actual, String label) {
        if (!expected.equals(actual)) throw new AssertionError(label + ": " + actual);
        passed++;
    }
    private static void rejectsNull(int method) {
        try {
            if (method == 0) DialingSupport.ascii(null);
            else if (method == 1) DialingSupport.normalize(null);
            else DialingSupport.smsDestination(null);
            throw new AssertionError("null must retain original rejection");
        } catch (NullPointerException expected) { passed++; }
    }
    public static void main(String[] args) {
        String cn = "+8613800000000";
        eq(cn, DialingSupport.normalize("+86 (138) 0000-0000"), "formatted mainland");
        eq(cn, DialingSupport.normalize(" ＋８６（１３８）００００－００００ "), "fullwidth pasted number");
        eq(cn, DialingSupport.normalize("+٨٦١٣٨٠٠٠٠٠٠٠٠"), "decimal digits become ASCII");
        eq("123", DialingSupport.normalize("\uD835\uDFD9\uD835\uDFDA\uD835\uDFDB"), "supplementary decimal digits");
        eq("", DialingSupport.normalize("abc"), "non-number stays invalid");
        eq("+", DialingSupport.normalize("＋"), "no invented digits");
        eq("13800000000", DialingSupport.normalize("13800000000"), "no guessed country code");
        eq("008613800000000", DialingSupport.normalize("00 86 138 0000 0000"), "UI keeps international access prefix");
        eq("888", DialingSupport.normalize("888"), "short code unchanged");
        eq("110", DialingSupport.normalize("１１０"), "emergency check receives canonical digits");
        eq("112", DialingSupport.normalize("１１２"), "international emergency check");
        eq("*123#", DialingSupport.ascii("*１２３#"), "call service syntax retained");
        eq("+86 (138) 0000-0000", DialingSupport.ascii("＋８６ (１３８) ００００-００００"), "wire call keeps formatting for original parser");
        for (String input : new String[] {cn, "00 86 138 0000 0000", "＋８６１３８００００００００", "００８６１３８００００００００", " +86 (138) 0000-0000 "}) {
            String actual = DialingSupport.smsDestination(input);
            eq(cn, actual, "SMS canonical recipient");
            eq(actual, DialingSupport.smsDestination(actual), "SMS coroutine cloning is idempotent");
            // Existing ub4 strips '+' before BCD and sets international TON for '+'.
            eq("8613800000000", actual.substring(1), "SMS address excludes the 00 access prefix");
        }
        eq("+442000000000", DialingSupport.smsDestination("0044 2000 000000"), "other countries");
        eq("888", DialingSupport.smsDestination("8 8 8"), "formatted short SMS recipient");
        eq("13800000000", DialingSupport.smsDestination("13800000000"), "no domestic-to-international inference");
        eq("0118613800000000", DialingSupport.smsDestination("0118613800000000"), "no locale-free 011 rewrite");
        eq("00", DialingSupport.smsDestination("00"), "incomplete prefix not converted to plus only");
        eq("", DialingSupport.smsDestination(""), "empty stays empty");
        for (int i = 0; i < 3; i++) rejectsNull(i);
        System.out.println("PASS: " + passed + " dialing normalization assertions");
    }
}
