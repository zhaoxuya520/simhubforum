#!/usr/bin/env python3
"""Artifact regression: old self-rejecting APK fails, fixed APK passes."""
from pathlib import Path
import argparse
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from verify_signed import verify

parser = argparse.ArgumentParser()
parser.add_argument('--previous', required=True, type=Path)
parser.add_argument('--current', required=True, type=Path)
parser.add_argument('--original', required=True, type=Path)
args = parser.parse_args()
results = []
for path, expected in (
    (args.previous, 'APK self-check does not trust its test signer'),
    (args.original, 'APK signer does not match the declared test certificate'),
):
    try:
        verify(path.resolve())
    except ValueError as exc:
        if not str(exc).startswith(expected):
            raise
        results.append({'apk': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'expected_rejection': expected, 'passed': True})
    else:
        raise AssertionError('Verifier accepted an APK that should be rejected: ' + path.name)
report = verify(args.current.resolve())
results.append({'apk': args.current.name, 'sha256': report['signed_apk_sha256'],
                'expected_acceptance': True, 'passed': True})
result = {'cases': len(results), 'failed': 0, 'android_runtime_test': False, 'results': results}
(ROOT / 'build/signing-regression-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
