package android.se.omapi;
public class Session {
    public RuntimeException failure;
    public java.io.IOException ioFailure;
    public Channel channel = new Channel();
    public boolean closed;
    public RuntimeException closeFailure;
    public int closes;
    public byte[] selectedAid;
    public Channel openLogicalChannel(byte[] aid) throws java.io.IOException {
        selectedAid = aid.clone();
        if (ioFailure != null) throw ioFailure;
        if (failure != null) throw failure;
        return channel;
    }
    public void close() {
        closes++;
        if (closeFailure != null) throw closeFailure;
        closed = true;
    }
}
