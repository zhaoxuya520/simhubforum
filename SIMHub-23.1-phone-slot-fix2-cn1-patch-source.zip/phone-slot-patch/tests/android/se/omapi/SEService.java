package android.se.omapi;
import android.content.Context;
import java.util.concurrent.Executor;
public class SEService {
    public interface OnConnectedListener { void onConnected(); }
    public static Reader[] available = new Reader[0];
    public static Reader explicitSlot;
    public static Reader secondSlot;
    public static RuntimeException enumerationFailure;
    public static RuntimeException firstSlotFailure;
    public static int slotQueries;
    public static boolean shouldConnect = true;
    public static int shutdowns;
    private boolean connected;
    public SEService(Context context, Executor executor, OnConnectedListener listener) {
        connected = shouldConnect;
        if (connected) executor.execute(listener::onConnected);
    }
    public boolean isConnected() { return connected; }
    public Reader[] getReaders() {
        if (enumerationFailure != null) throw enumerationFailure;
        return available;
    }
    public Reader getUiccReader(int slot) {
        slotQueries++;
        if (slot == 1 && firstSlotFailure != null) throw firstSlotFailure;
        if (slot == 1 && explicitSlot != null) return explicitSlot;
        if (slot == 2 && secondSlot != null) return secondSlot;
        throw new IllegalArgumentException("No slot");
    }
    public void shutdown() { shutdowns++; connected = false; }
}
