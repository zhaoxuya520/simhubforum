package android.se.omapi;
public class Channel {
    public boolean open = true;
    public RuntimeException failure;
    public RuntimeException stateFailure;
    public RuntimeException closeFailure;
    public int closes;
    public byte[] response = {(byte)0x90, 0};
    public byte[] lastCommand;
    public int transmits;
    public boolean isOpen() {
        if (stateFailure != null) throw stateFailure;
        return open;
    }
    public void close() {
        closes++;
        if (closeFailure != null) throw closeFailure;
        open = false;
    }
    public byte[] transmit(byte[] command) {
        transmits++;
        lastCommand = command;
        if (failure != null) throw failure;
        return response;
    }
}
