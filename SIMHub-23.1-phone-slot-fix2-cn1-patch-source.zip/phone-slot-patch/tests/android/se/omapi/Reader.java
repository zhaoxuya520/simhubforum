package android.se.omapi;
public class Reader {
    private final String name;
    private final boolean present;
    public Session session = new Session();
    public RuntimeException failure;
    public RuntimeException nameFailure;
    public Reader(String name, boolean present) { this.name = name; this.present = present; }
    public String getName() {
        if (nameFailure != null) throw nameFailure;
        return name;
    }
    public boolean isSecureElementPresent() { return present; }
    public Session openSession() {
        if (failure != null) throw failure;
        return session;
    }
}
