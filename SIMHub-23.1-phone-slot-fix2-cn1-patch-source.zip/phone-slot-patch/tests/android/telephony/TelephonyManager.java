package android.telephony;
public class TelephonyManager {
    public int getActiveModemCount() { return 2; }
}
