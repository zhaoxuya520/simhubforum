package android.content;
public class Context {
    public Context getApplicationContext() { return this; }
    public <T> T getSystemService(Class<T> type) { return null; }
}
