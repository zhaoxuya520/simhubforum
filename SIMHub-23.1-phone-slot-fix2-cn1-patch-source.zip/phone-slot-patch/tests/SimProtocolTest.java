import cc.forserein.simhub.internal.SimProtocol;
import java.io.IOException;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

public final class SimProtocolTest {
    private static int passed;
    private static final String EID = "89012345678901234567890123456789";
    private static void check(boolean value, String name) {
        if (!value) throw new AssertionError(name);
        passed++;
    }
    private static void fails(SimProtocol.Exchange exchange, String name) throws Exception {
        try { SimProtocol.readEid(exchange); throw new AssertionError(name); }
        catch (IOException expected) { passed++; }
    }
    public static void main(String[] args) throws Exception {
        check(SimProtocol.isUiccName("SIM1"), "SIM1 discovery");
        check(SimProtocol.isUiccName(" simslot2 "), "preserve vendor SIM prefix");
        check(SimProtocol.isUiccName("eUICC1"), "eUICC reader");
        check(!SimProtocol.isUiccName("eSE1"), "exclude payment secure element");
        check(!SimProtocol.isUiccName(null), "null reader name");
        check(Arrays.equals(SimProtocol.hex(EID), SimProtocol.readEid(c -> SimProtocol.hex("BF3E125A10" + EID + "9000"))), "read complete EID");
        check(Arrays.equals(SimProtocol.hex(EID), SimProtocol.readEid(c -> SimProtocol.hex("BF3E81135A8110" + EID + "9000"))), "long BER length");
        List<byte[]> calls = new ArrayList<>();
        byte[] eid = SimProtocol.readEid(c -> {
            calls.add(c.clone());
            return calls.size() == 1 ? SimProtocol.hex("BF3E125A106110") : SimProtocol.hex(EID + "9000");
        });
        check(Arrays.equals(eid, SimProtocol.hex(EID)), "GET RESPONSE collects data");
        check(SimProtocol.hex(calls.get(1)).equals("00C0000010"), "GET RESPONSE uses SW2");
        calls.clear();
        SimProtocol.readEid(c -> {
            calls.add(c.clone());
            return calls.size() == 1 ? SimProtocol.hex("6C20") : SimProtocol.hex("BF3E125A10" + EID + "9000");
        });
        check(SimProtocol.hex(calls.get(1)).equals("80E2910006BF3E035C015A20"), "correct Le without changing request data");
        fails(c -> null, "null response");
        fails(c -> new byte[]{(byte)0x90}, "truncated status");
        fails(c -> SimProtocol.hex("6982"), "access denied not success");
        fails(c -> SimProtocol.hex("9000"), "empty EID not success");
        fails(c -> SimProtocol.hex("BF3E125A10899000"), "truncated BER");
        fails(c -> SimProtocol.hex("BF3E805A10" + EID + "9000"), "indefinite BER rejected");
        fails(c -> SimProtocol.hex("BF3E125A10F90123456789012345678901234567899000"), "nondecimal EID rejected");
        fails(c -> SimProtocol.hex("5A10" + EID + "9000"), "unrelated tag 5A not eUICC proof");
        fails(c -> SimProtocol.hex("BF3E135A10" + EID + "5A9000"), "malformed TLV after EID not ignored");
        fails(c -> SimProtocol.hex("BF3E245A10" + EID + "5A10" + EID + "9000"), "duplicate EIDs rejected");
        calls.clear();
        fails(c -> { calls.add(c); return SimProtocol.hex("6101"); }, "infinite response bounded");
        check(calls.size() == 32, "response loop limit");
        calls.clear();
        fails(c -> { calls.add(c); return SimProtocol.hex("6C00"); }, "infinite Le retry bounded");
        check(calls.size() == 32, "Le loop limit");
        check(SimProtocol.purpose(SimProtocol.USIM).contains("Wi-Fi Calling"), "separate authentication capability");
        check(SimProtocol.purpose(SimProtocol.ISDR).contains("管理"), "separate management capability");
        System.out.println("PASS: " + passed + " protocol assertions");
    }
}
