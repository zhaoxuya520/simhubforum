import cc.forserein.simhub.internal.OmapiSupport;
import cc.forserein.simhub.internal.SimProtocol;
import android.content.Context;
import android.os.Build;
import android.se.omapi.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.ArrayList;
import java.util.List;

public class OmapiSupportTest {
    private static int passed;
    private static void check(boolean result, String name) {
        if (!result) throw new AssertionError(name);
        passed++;
    }
    interface Operation { void run() throws Exception; }
    private static void fails(Operation operation, String message) throws Exception {
        try { operation.run(); throw new AssertionError("Expected failure " + message); }
        catch (IOException | IllegalStateException e) { check(e.getMessage().contains(message), e.toString()); }
    }
    public static void main(String[] args) throws Exception {
        Context context = new Context();
        Reader euicc = new Reader("SIM1", true);
        euicc.session.channel.response = SimProtocol.hex("BF3E125A10890123456789012345678901234567899000");
        Reader denied = new Reader("UICC3", true);
        denied.session.failure = new SecurityException("Card ACL");
        Reader ordinary = new Reader("SIM4", true);
        ordinary.session.failure = new NoSuchElementException("No ISD-R");
        Reader busy = new Reader("SIM5", true);
        busy.session.channel = null;
        SEService.available = new Reader[]{euicc, new Reader("SIM2", false), new Reader("eSE1", true), denied, ordinary, busy};
        SEService.explicitSlot = new Reader("VendorUiccSlot", true);
        String[] choices = OmapiSupport.discover(context);
        check(Arrays.asList(choices).contains("SIM1"), "present SIM");
        check(Arrays.asList(choices).contains("VendorUiccSlot"), "explicit OEM slot");
        check(!Arrays.asList(choices).contains("SIM2"), "empty slot excluded");
        check(!Arrays.asList(choices).contains("eSE1"), "embedded payment element excluded");
        check(choices.length == 5, "only real present readers, no synthetic row");
        check(SEService.shutdowns == 1, "discovery releases service");
        check(OmapiSupport.cardTitle("SIM1").startsWith("eSIM 芯片卡"), "valid EID identifies eUICC in existing row");
        check(Arrays.equals(euicc.session.selectedAid, SimProtocol.ISDR), "standard ISD-R selected");
        check(Arrays.equals(euicc.session.channel.lastCommand, SimProtocol.hex("80E2910006BF3E035C015A00")), "read-only GET EID, no profile or authentication mutation");
        check(euicc.session.closed && !euicc.session.channel.open, "probe closes its own session and channel");
        check(Arrays.asList(choices).contains("UICC3"), "ACL denial does not hide physical card");
        check(!OmapiSupport.cardTitle("UICC3").startsWith("eSIM 芯片卡"), "denied card not falsely identified as eUICC");
        check(OmapiSupport.cardSubtitle("UICC3").contains("拒绝访问"), "ACL denial reported in row");
        check(denied.session.closed, "denied channel cleans session");
        check(OmapiSupport.cardSubtitle("SIM4").contains("未找到"), "missing ISD-R reported without claiming ordinary SIM");
        check(ordinary.session.closed, "missing AID cleans session");
        check(OmapiSupport.cardSubtitle("SIM5").contains("正忙"), "no free channel retained as selectable reader");
        check(busy.session.closed, "channel exhaustion cleans session");
        check(!OmapiSupport.cardTitle("VendorUiccSlot").startsWith("eSIM 芯片卡"), "open ISD-R alone is not eUICC proof");
        check(SEService.explicitSlot.session.closed && !SEService.explicitSlot.session.channel.open, "invalid EID cleans channel and session");
        SEService service = OmapiSupport.connect(context);
        check(OmapiSupport.select(context, service, "VendorUiccSlot").getName().equals("VendorUiccSlot"), "OEM slot can also connect");
        fails(() -> OmapiSupport.select(context, service, "SIM2"), "未开放");
        check(!OmapiSupport.isConnected(service, new Reader("SIM1", false)), "removed card not connected");
        OmapiSupport.shutdown(service);
        check(!OmapiSupport.isConnected(service, new Reader("SIM1", true)), "service closure not connected");
        Session session = new Session();
        session.failure = new SecurityException("access denied");
        fails(() -> OmapiSupport.openLogicalChannel(session, SimProtocol.USIM), "Wi-Fi Calling");
        fails(() -> OmapiSupport.openLogicalChannel(session, SimProtocol.ISDR), "管理通道");
        SecurityException platformDenial = new SecurityException("AccessControlEnforcer: no matching rule\nUID denied");
        session.failure = platformDenial;
        try {
            OmapiSupport.openLogicalChannel(session, SimProtocol.ISDR);
            throw new AssertionError("SecurityException must not turn into success");
        } catch (IOException e) {
            check(e.getCause() == platformDenial, "original Android denial retained as cause");
            check(e.getMessage().contains("AID=" + SimProtocol.hex(SimProtocol.ISDR)), "denied AID retained for comparison with working LPA");
            check(e.getMessage().contains("AccessControlEnforcer: no matching rule"), "platform reason retained instead of guessing certificate policy");
            check(e.getMessage().contains("SecurityException") && !e.getMessage().contains("\n"), "exception type retained and control characters removed");
        }
        session.failure = new SecurityException();
        fails(() -> OmapiSupport.openLogicalChannel(session, SimProtocol.ISDR), "平台未提供具体原因");
        session.failure = new SecurityException(new String(new char[300]).replace('\0', 'x'));
        try {
            OmapiSupport.openLogicalChannel(session, SimProtocol.ISDR);
            throw new AssertionError("Expected bounded denial");
        } catch (IOException e) {
            check(e.getMessage().length() < 350 && e.getMessage().endsWith("…"), "oversized platform reason bounded");
        }
        session.failure = null;
        session.ioFailure = new IOException("Card transport disconnected");
        try {
            OmapiSupport.openLogicalChannel(session, SimProtocol.ISDR);
            throw new AssertionError("Expected transport error");
        } catch (IOException e) {
            check(e == session.ioFailure, "transport failure is not relabeled as permission denial");
        }
        session.ioFailure = null;
        session.failure = new NoSuchElementException("not found");
        fails(() -> OmapiSupport.openLogicalChannel(session, SimProtocol.ISDR), "不存在");
        session.failure = null;
        session.channel = null;
        fails(() -> OmapiSupport.openLogicalChannel(session, SimProtocol.ISDR), "没有可用逻辑通道");
        Channel channel = new Channel();
        byte[] command = SimProtocol.hex("00A40004026FAD");
        check(OmapiSupport.transmit(channel, command)[0] == (byte)0x90, "transmit success");
        check(Arrays.equals(channel.lastCommand, command), "APDU preserved");
        channel.failure = new SecurityException("denied");
        int before = channel.transmits;
        fails(() -> OmapiSupport.transmit(channel, command), "拒绝此 APDU");
        check(channel.transmits == before + 1, "no unauthorized retry");
        channel.failure = null;
        channel.response = new byte[]{0};
        fails(() -> OmapiSupport.transmit(channel, command), "状态字");
        channel.open = false;
        fails(() -> OmapiSupport.transmit(channel, command), "已关闭");
        fails(() -> OmapiSupport.transmit(channel, new byte[3]), "不完整");
        channel.stateFailure = new IllegalStateException("service disconnected");
        before = channel.transmits;
        fails(() -> OmapiSupport.transmit(channel, command), "重新连接");
        check(channel.transmits == before, "stale channel does not send command");
        channel.stateFailure = null;
        channel.open = true;
        channel.failure = new IllegalStateException("card refresh during command");
        fails(() -> OmapiSupport.transmit(channel, command), "重新连接");
        check(channel.transmits == before + 1, "mutation not retried after card refresh");

        Reader bad = new Reader("SIMbad", true);
        bad.nameFailure = new IllegalStateException("broken reader");
        Reader apduDenied = new Reader("SIM6", true);
        apduDenied.session.channel.failure = new SecurityException("command denied");
        SEService.available = new Reader[]{null, bad, apduDenied};
        SEService.explicitSlot = null;
        SEService.secondSlot = new Reader("VendorSecond", true);
        choices = OmapiSupport.discover(context);
        check(choices.length == 2 && Arrays.asList(choices).contains("VendorSecond"), "broken and null reader cannot hide second slot");
        check(OmapiSupport.cardSubtitle("SIM6").contains("命令被拒绝"), "command ACL denial distinguished from missing EID");
        check(apduDenied.session.closed && !apduDenied.session.channel.open, "command ACL failure releases resources");
        check(!OmapiSupport.cardTitle("SIM1").startsWith("eSIM 芯片卡"), "removed card classification cleared");
        SEService.enumerationFailure = new IllegalStateException("vendor getReaders bug");
        SEService.firstSlotFailure = new SecurityException("slot one denied");
        choices = OmapiSupport.discover(context);
        check(choices.length == 1 && choices[0].equals("VendorSecond"), "explicit second slot survives getReaders failure and first-slot denial");
        SEService.secondSlot = new Reader(" ", true);
        choices = OmapiSupport.discover(context);
        check(choices.length == 0, "invalid explicit reader name excluded");
        check(OmapiSupport.unavailableMessage().contains("无法枚举"), "enumeration error not misreported as successful empty scan");
        SEService.enumerationFailure = null;
        SEService.firstSlotFailure = null;
        SEService.available = new Reader[]{new Reader("UICC1", true)};
        Build.VERSION.SDK_INT = 29;
        int queried = SEService.slotQueries;
        choices = OmapiSupport.discover(context);
        check(choices.length == 1, "Android 10 retains named UICC discovery");
        check(SEService.slotQueries == queried, "Android 10 never invokes API 30 accessor");

        final byte[] vendorAid = SimProtocol.hex("A0000005591010FFFFFFFF8900050500");
        final List<Session> opened = new ArrayList<Session>();
        final List<Channel> openedChannels = new ArrayList<Channel>();
        Reader vendor = new Reader("SIM1", true) {
            @Override public Session openSession() {
                Session next = new Session() {
                    @Override public Channel openLogicalChannel(byte[] aid) {
                        selectedAid = aid.clone();
                        if (Arrays.equals(aid, SimProtocol.ISDR)) throw new SecurityException("standard AID denied; vendor AID permitted");
                        if (!Arrays.equals(aid, vendorAid)) throw new NoSuchElementException("unknown AID");
                        Channel selected = new Channel();
                        selected.response = SimProtocol.hex("BF3E125A10890123456789012345678901234567899000");
                        openedChannels.add(selected);
                        return selected;
                    }
                };
                opened.add(next);
                return next;
            }
        };
        SEService.available = new Reader[]{vendor};
        choices = OmapiSupport.discover(context, Arrays.asList(null, vendorAid, vendorAid, new byte[17]));
        check(choices.length == 1 && OmapiSupport.cardTitle("SIM1").startsWith("eSIM 芯片卡"), "vendor eUICC identified despite denied standard AID");
        check(opened.size() == 2, "invalid and duplicate AIDs skipped; one successful candidate is sufficient");
        check(Arrays.equals(opened.get(0).selectedAid, SimProtocol.ISDR), "standard AID tried before vendor list");
        check(Arrays.equals(opened.get(1).selectedAid, vendorAid), "management backend vendor AID preserved");
        check(opened.get(0).closed && opened.get(1).closed, "each candidate session closed before next candidate");
        check(openedChannels.size() == 1 && !openedChannels.get(0).open, "vendor probe does not retain a logical channel");
        check(openedChannels.get(0).transmits == 1, "vendor discovery sends only GET EID, no profile or AKA mutations");
        opened.clear();
        choices = OmapiSupport.discover(context, Arrays.asList(new byte[]{1,2,3,4,5}));
        check(!OmapiSupport.cardTitle("SIM1").startsWith("eSIM 芯片卡"), "failed rescan cannot retain old vendor eUICC identification");
        check(OmapiSupport.cardSubtitle("SIM1").contains("拒绝访问"), "ACL denial preserved when remaining candidates are missing");
        Build.VERSION.SDK_INT = 27;
        choices = OmapiSupport.discover(context);
        check(choices.length == 0, "unsupported OS never creates fake card");
        check(OmapiSupport.unavailableMessage().contains("Android 9"), "error displayed in existing empty list");
        check(!OmapiSupport.cardTitle("SIM1").startsWith("eSIM 芯片卡"), "refresh clears stale identification");
        Build.VERSION.SDK_INT = 35;
        SEService.shouldConnect = false;
        int shutdowns = SEService.shutdowns;
        long start = System.nanoTime();
        fails(() -> OmapiSupport.connect(context), "超时");
        check(SEService.shutdowns == shutdowns + 1, "timed-out connection released");
        check(System.nanoTime() - start < 8_000_000_000L, "bounded connection wait");
        System.out.println("PASS: " + passed + " OMAPI adapter assertions (Android service doubles; not a device test)");
    }
}
