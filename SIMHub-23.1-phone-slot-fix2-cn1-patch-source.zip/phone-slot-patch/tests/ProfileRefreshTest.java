import cc.forserein.simhub.internal.ProfileRefresh;
import cc.forserein.simhub.internal.SimProtocol;
import java.util.Arrays;

public final class ProfileRefreshTest {
    private static int passed;
    private static void check(boolean result, String name) {
        if (!result) throw new AssertionError(name);
        passed++;
    }
    public static void main(String[] args) {
        byte[] iccid = SimProtocol.hex("981032547698103254F6");
        check(Arrays.equals(ProfileRefresh.command(iccid, 0, true), SimProtocol.hex("BF3111A00C5A0A981032547698103254F68101FF")), "phone enable requests modem REFRESH");
        check(Arrays.equals(ProfileRefresh.command(iccid, 1, true), SimProtocol.hex("BF3211A00C5A0A981032547698103254F68101FF")), "phone disable requests modem REFRESH");
        check(Arrays.equals(ProfileRefresh.command(iccid, 0, false), SimProtocol.hex("BF3111A00C5A0A981032547698103254F6810100")), "USB enable request unchanged");
        check(Arrays.equals(ProfileRefresh.command(iccid, 1, false), SimProtocol.hex("BF3211A00C5A0A981032547698103254F6810100")), "USB disable request unchanged");
        check(SimProtocol.hex(iccid).equals("981032547698103254F6"), "input ICCID preserved");
        String[] ids = {"old", "target"};
        check(ProfileRefresh.confirmed("target", true, ids, new boolean[]{false, true}), "new profile confirmed");
        check(!ProfileRefresh.confirmed("target", true, ids, new boolean[]{true, false}), "stale profile list not success");
        check(ProfileRefresh.confirmed("target", false, ids, new boolean[]{true, false}), "disable verified separately");
        check(!ProfileRefresh.confirmed("target", true, new String[]{"another card"}, new boolean[]{true}), "wrong card/profile cannot confirm switch");
        check(!ProfileRefresh.confirmed("target", false, new String[0], new boolean[0]), "missing profile not successful disable");
        check(!ProfileRefresh.confirmed("target", true, new String[]{"target", "target"}, new boolean[]{true, true}), "ambiguous duplicate profile rejected");
        check(!ProfileRefresh.confirmed("target", true, ids, new boolean[0]), "inconsistent readback rejected");
        System.out.println("PASS: " + passed + " profile refresh and state confirmation assertions");
    }
}
