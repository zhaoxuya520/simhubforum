#!/usr/bin/env python3
"""Check the actual patched call/SMS entry points; these are static checks, not device calls."""
from pathlib import Path
import json
import os
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dialing_patch import ORIGINAL_SHA256, patch_dialing_class, CALL_ANCHOR, CALL_HOOK, SMS_ANCHOR, SMS_HOOK

ORIGINAL = Path(os.environ.get('SIMHUB_RECOVERED', '/workspace/recovered/SIMHub-Android-23.1')) / 'apktool/smali'
PATCHED = Path(sys.argv[1])
checks = []


def check(value, label):
    assert value, label
    checks.append(label)


def method(text, signature):
    return re.search(r'^\.method ' + re.escape(signature) + r'\n(.*?)^\.end method', text, re.M | re.S)[1]


for name in ORIGINAL_SHA256:
    before = (ORIGINAL / name).read_text()
    after = (PATCHED / name).read_text()
    check(after == patch_dialing_class(name, before), name + ': only the declared modifications')
    for changed in (before + '\n', after):
        try:
            patch_dialing_class(name, changed)
        except ValueError:
            checks.append(name + ': rejects unexpected/repatched input')
        else:
            raise AssertionError(name + ': accepted stale input')

before = (ORIGINAL / 'u10.smali').read_text()
after = (PATCHED / 'u10.smali').read_text()
for signature in ('static constructor <clinit>()V', 'public static a(Ljava/lang/String;)Z'):
    check(method(after, signature) == method(before, signature), 'emergency-number set and minimum-length validator preserved: ' + signature)
guard = method(after, 'public static b(Ljava/lang/String;Ljava/lang/String;)Z')
instructions = [line.strip() for line in guard.splitlines() if line.strip()]
check(instructions == ['.locals 1', 'invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;',
                       'const/4 v0, 0x0', 'return v0'], 'destination classifier returns false, retains null contract')
check('"+86"' not in after, 'country-prefix matcher removed from destination class')

callers = ('a00.smali', 'k10.smali', 'cc/forserein/simhub/vowifi/calling/VoWiFiConnectionService.smali', 'f82.smali')
for name in callers:
    before = (ORIGINAL / name).read_text()
    after = (PATCHED / name).read_text()
    check(after.count('Lu10;->b(Ljava/lang/String;Ljava/lang/String;)Z') == 1, name + ': reaches shared destination policy')
    if name == 'f82.smali':
        check(after.replace(CALL_ANCHOR + CALL_HOOK, CALL_ANCHOR) == before,
              'call normalizer touches only outgoing-number branch, no call ID/cancel/answer changes')
    else:
        check(after == before, name + ': original emergency, permission and call-state checks retained')

before = (ORIGINAL / 'ub4.smali').read_text()
after = (PATCHED / 'ub4.smali').read_text()
check(after.replace(SMS_HOOK + SMS_ANCHOR, SMS_ANCHOR) == before,
      'SMS changes only constructor recipient; body/SMSC/encoding/retry/continuations retained')
for name in ('rb4.smali', 'yk.smali', 'lf4.smali', 'o82.smali', 'cb4.smali', 'mg.smali', 'tb0.smali'):
    if name == 'mg.smali':
        from signing_policy import patch_security_policy
        check((PATCHED / name).read_text() == patch_security_policy((ORIGINAL / name).read_text()),
              'existing pinned signer policy retained')
    else:
        check((PATCHED / name).read_bytes() == (ORIGINAL / name).read_bytes(),
              name + ': transport/codec/receive/security unchanged')

result = {'checks': len(checks), 'failed': 0, 'android_device_test': False, 'results': checks}
(ROOT / 'build/dialing-integration-results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'failed': 0, 'kind': 'static bytecode integration'}, ensure_ascii=False))
