import android.content.Context;
import android.se.omapi.SEService;
import cc.forserein.simhub.internal.ConnectionLease;
import cc.forserein.simhub.internal.OmapiSupport;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

public final class ConnectionLeaseTest {
    private static int passed;
    private static void check(boolean value, String name) {
        if (!value) throw new AssertionError(name);
        passed++;
    }
    public static void main(String[] args) throws Exception {
        Context context = new Context();
        SEService service = OmapiSupport.connect(context);
        ConnectionLease lease = new ConnectionLease();
        lease.attach(service);
        int before = SEService.shutdowns;
        lease.complete(false); // IO finished, but withContext's dispatch rejected delivery on cancellation.
        check(!service.isConnected(), "cancelled result closes service before ownership transfer");
        lease.complete(false);
        check(SEService.shutdowns == before + 1, "duplicate failure cleanup is idempotent");

        service = OmapiSupport.connect(context);
        lease = new ConnectionLease();
        lease.attach(service);
        lease.complete(true);
        lease.complete(false);
        check(service.isConnected(), "success transfers ownership; lease cannot close a live transport");
        OmapiSupport.shutdown(service);

        final ConnectionLease pending = new ConnectionLease();
        final SEService late = OmapiSupport.connect(context);
        final CountDownLatch cancelDone = new CountDownLatch(1);
        final AtomicReference<Throwable> failure = new AtomicReference<Throwable>();
        Thread worker = new Thread(() -> {
            try {
                cancelDone.await();
                pending.attach(late);
                failure.set(new AssertionError("cancelled lease accepted late connection"));
            } catch (CancellationException expected) {
                // Connection cannot escape cleanup even if it appears after cancellation.
            } catch (Throwable e) { failure.set(e); }
        });
        worker.start();
        pending.complete(false);
        cancelDone.countDown();
        worker.join(2000);
        check(!worker.isAlive() && failure.get() == null, "cancellation before connection arrives is handled");
        check(!late.isConnected(), "late resource released");
        System.out.println("PASS: " + passed + " connection ownership assertions");
    }
}
