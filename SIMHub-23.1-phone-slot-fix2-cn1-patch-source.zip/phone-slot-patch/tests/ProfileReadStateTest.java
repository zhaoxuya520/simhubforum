import cc.forserein.simhub.internal.ProfileReadState;

public final class ProfileReadStateTest {
    private static int passed;
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
        passed++;
    }
    public static void main(String[] args) {
        String eid = "89012345678901234567890123456789";
        check(ProfileReadState.unconfirmed(true, null, "OMAPI access denied"), "denied local read is not an empty card");
        check(ProfileReadState.unconfirmed(true, eid, "Profile query failed"), "EID alone cannot prove an empty profile list");
        check(ProfileReadState.unconfirmed(true, null, null), "unread local card is not an empty card");
        check(ProfileReadState.unconfirmed(true, "  ", null), "blank EID is not a successful read");
        check(!ProfileReadState.unconfirmed(true, eid, null), "successful local empty result retains original empty-card UI");
        check(!ProfileReadState.unconfirmed(true, eid, ""), "empty error string is not a failure");
        check(!ProfileReadState.unconfirmed(false, null, "error"), "existing external reader UI is unchanged");
        System.out.println("PASS: " + passed + " profile read-state assertions");
    }
}
