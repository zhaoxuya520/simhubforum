import android.se.omapi.Channel;
import android.se.omapi.Session;
import cc.forserein.simhub.internal.ChannelLease;
import cc.forserein.simhub.internal.SynchronizedChannelSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

public final class ChannelLeaseTest {
    private static int passed;
    private static void check(boolean result, String name) {
        if (!result) throw new AssertionError(name);
        passed++;
    }
    public static void main(String[] args) throws Exception {
        Channel channel = new Channel();
        Session session = new Session();
        SynchronizedChannelSet tracking = new SynchronizedChannelSet();
        tracking.add(channel);
        ChannelLease lease = new ChannelLease();
        lease.attach(channel, session, tracking);
        lease.complete(false);
        check(!channel.open && session.closed && tracking.isEmpty(), "cancelled handoff releases channel/session and tracking");
        lease.complete(false);
        check(channel.closes == 1 && session.closes == 1, "cleanup idempotent");

        channel = new Channel(); session = new Session(); tracking.add(channel);
        lease = new ChannelLease(); lease.attach(channel, session, tracking);
        lease.complete(true); lease.complete(false);
        check(channel.open && !session.closed && tracking.contains(channel), "successful handoff remains owned by original channel wrapper");
        channel.close(); session.close(); tracking.clear();

        channel = new Channel(); session = new Session(); tracking.add(channel);
        channel.closeFailure = new IllegalStateException("card already reset");
        lease = new ChannelLease(); lease.attach(channel, session, tracking); lease.complete(false);
        check(session.closed && tracking.isEmpty(), "channel close failure cannot skip session cleanup");

        channel = new Channel(); session = new Session(); tracking.add(channel);
        session.closeFailure = new IllegalStateException("service disconnected");
        lease = new ChannelLease(); lease.attach(channel, session, tracking); lease.complete(false);
        check(!channel.open && tracking.isEmpty(), "session close failure cannot retain channel or mask cancellation");

        // Force the cancellation and registration operations to race, then check final ownership.
        AtomicReference<Throwable> failure = new AtomicReference<Throwable>();
        for (int i = 0; i < 100; i++) {
            final Channel opened = new Channel();
            final Session owner = new Session();
            final SynchronizedChannelSet entries = new SynchronizedChannelSet();
            entries.add(opened);
            final ChannelLease pending = new ChannelLease();
            final CountDownLatch start = new CountDownLatch(1);
            Thread register = new Thread(() -> {
                try { start.await(); pending.attach(opened, owner, entries); }
                catch (CancellationException expected) { }
                catch (Throwable e) { failure.set(e); }
            });
            Thread cancel = new Thread(() -> {
                try { start.await(); pending.complete(false); }
                catch (Throwable e) { failure.set(e); }
            });
            register.start(); cancel.start(); start.countDown();
            register.join(2000); cancel.join(2000);
            if (register.isAlive() || cancel.isAlive() || failure.get() != null || opened.open || !owner.closed || !entries.isEmpty()
                    || opened.closes != 1 || owner.closes != 1) throw new AssertionError("handoff race " + i, failure.get());
        }
        check(true, "100 concurrent registration/cancellation races release exactly once");

        final SynchronizedChannelSet shared = new SynchronizedChannelSet();
        Channel first = new Channel(), second = new Channel(), third = new Channel();
        shared.add(first); shared.add(second);
        Iterator<Channel> snapshot = shared.iterator();
        shared.remove(second); shared.add(third);
        check(snapshot.next() == first && snapshot.next() == second && !snapshot.hasNext(), "iteration remains stable after concurrent changes");
        Iterator<Channel> removable = shared.iterator();
        removable.next(); removable.remove();
        check(!shared.contains(first) && shared.contains(third), "iterator removal updates live set");
        check(shared.toArray().length == 1 && shared.toArray(new Channel[0])[0] == third, "typed/untyped snapshots preserve values");
        List<Channel> closing = SynchronizedChannelSet.copyOf(shared);
        shared.clear();
        check(closing.size() == 1 && closing.get(0) == third, "close owns stable copy independent of tracking mutations");
        shared.add(third);

        Thread writer = new Thread(() -> {
            try {
                for (int i = 0; i < 10000; i++) {
                    Channel next = new Channel(); shared.add(next); shared.remove(next);
                }
            } catch (Throwable e) { failure.set(e); }
        });
        writer.start();
        for (int i = 0; i < 3000; i++) {
            for (Channel ignored : shared) { }
            new ArrayList<Channel>(shared);
            shared.toArray(new Channel[0]);
            SynchronizedChannelSet.copyOf(shared);
        }
        writer.join(3000);
        check(!writer.isAlive() && failure.get() == null && shared.size() == 1, "concurrent tracking and snapshots do not corrupt or throw");
        System.out.println("PASS: " + passed + " logical channel ownership and concurrency assertions");
    }
}
