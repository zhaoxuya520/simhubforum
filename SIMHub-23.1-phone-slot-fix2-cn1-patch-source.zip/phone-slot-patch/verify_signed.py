#!/usr/bin/env python3
"""Verify the delivered APK, including its own signer acceptance policy."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import struct
import subprocess
import zipfile

from signing_policy import ORIGINAL_ALLOWLIST, expected_allowlist, test_signer_digest

ROOT = Path(__file__).resolve().parent
TOOLS = Path(os.environ.get('SIMHUB_TOOLS', '/workspace/tools/android-recovery'))


def dex_strings(data):
    count, offset = struct.unpack_from('<II', data, 56)
    for index in range(count):
        pos = struct.unpack_from('<I', data, offset + 4 * index)[0]
        while data[pos] & 0x80:
            pos += 1
        pos += 1
        # Signing policy strings are ASCII, so no MUTF-8 conversion is needed.
        yield data[pos:data.index(b'\0', pos)]


def verify(signed):
    output = subprocess.check_output([
        'java', '-jar', str(TOOLS / 'sdk/android-15/lib/apksigner.jar'),
        'verify', '--verbose', '--print-certs', str(signed)], text=True)
    signers = re.findall(r'^Signer #\d+ certificate SHA-256 digest: ([0-9a-f]{64})$', output, re.M)
    if signers != [test_signer_digest()]:
        raise ValueError('APK signer does not match the declared test certificate')
    with zipfile.ZipFile(signed) as archive:
        if archive.testzip() is not None:
            raise ValueError('APK ZIP integrity check failed')
        strings = set(dex_strings(archive.read('classes.dex')))
        if ORIGINAL_ALLOWLIST.encode() in strings or expected_allowlist().encode() not in strings:
            raise ValueError('APK self-check does not trust its test signer: the old card-operation blocker is still present')
        unsigned = ROOT / 'build/SIMHub-23.1-internal-sim-unsigned.apk'
        with zipfile.ZipFile(unsigned) as original:
            if set(archive.namelist()) != set(original.namelist()):
                raise ValueError('Signed and verified unsigned APK entries differ')
            for name in original.namelist():
                if archive.read(name) != original.read(name):
                    raise ValueError('Signed payload differs from verified unsigned APK: ' + name)
    subprocess.run([str(TOOLS / 'sdk/android-15/zipalign'), '-c', '-P', '16', '4', str(signed)], check=True)
    report = json.loads((ROOT / 'build/validation.json').read_text())
    if hashlib.sha256(unsigned.read_bytes()).hexdigest() != report['apk_sha256']:
        raise ValueError('Unsigned APK validation report is stale')
    for scheme in ('v2', 'v3'):
        if not re.search(r'^Verified using ' + scheme + r' scheme .*: true$', output, re.M):
            raise ValueError('Required APK signature scheme not verified: ' + scheme)
    sha = hashlib.sha256(signed.read_bytes()).hexdigest()
    sha1 = re.search(r'^Signer #1 certificate SHA-1 digest: ([0-9a-f]{40})$', output, re.M)[1]
    report.update({
        'signed_apk': signed.name, 'signed_apk_sha256': sha,
        'signed_apk_bytes': signed.stat().st_size, 'signing': 'v2/v3 verified',
        'signer_sha1': sha1.upper(), 'signer_sha256': signers[0],
        'app_self_check_trusts_actual_signer': True,
        'signed_payload_matches_verified_unsigned_apk': True,
    })
    signed.with_suffix('.apk.sha256').write_text(sha + '  ' + signed.name + '\n')
    (ROOT / 'build/signed-validation.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('apk', type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.apk.resolve()), indent=2))
