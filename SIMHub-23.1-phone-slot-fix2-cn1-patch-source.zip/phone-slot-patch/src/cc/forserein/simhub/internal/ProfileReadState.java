package cc.forserein.simhub.internal;

/** Used only when the existing screen's profile list is empty. */
public final class ProfileReadState {
    private ProfileReadState() {}

    public static boolean unconfirmed(boolean phoneSlot, String eid, String error) {
        if (!phoneSlot) return false;
        return eid == null || eid.trim().isEmpty()
                || (error != null && !error.trim().isEmpty());
    }
}
