package cc.forserein.simhub.internal;

import android.se.omapi.Channel;
import android.se.omapi.Session;
import java.util.Collection;
import java.util.concurrent.CancellationException;

/** Owns an opened channel/session until the coroutine dispatcher delivers its result. */
public final class ChannelLease {
    private Channel channel;
    private Session session;
    private Collection<Channel> tracked;
    private boolean finished;

    public synchronized void attach(Channel next, Session owner, Collection<Channel> tracking) {
        if (finished) {
            release(next, owner, tracking);
            throw new CancellationException("卡片通道操作已取消");
        }
        if (channel != null) throw new IllegalStateException("A channel is already pending");
        channel = next;
        session = owner;
        tracked = tracking;
    }

    public void complete(boolean delivered) {
        Channel pendingChannel;
        Session pendingSession;
        Collection<Channel> tracking;
        synchronized (this) {
            if (finished) return;
            finished = true;
            pendingChannel = channel;
            pendingSession = session;
            tracking = tracked;
            channel = null;
            session = null;
            tracked = null;
        }
        if (!delivered) release(pendingChannel, pendingSession, tracking);
    }

    private static void release(Channel channel, Session session, Collection<Channel> tracked) {
        if (channel != null) try { channel.close(); } catch (RuntimeException ignored) { }
        if (tracked != null) try { tracked.remove(channel); } catch (RuntimeException ignored) { }
        if (session != null) try { session.close(); } catch (RuntimeException ignored) { }
    }
}
