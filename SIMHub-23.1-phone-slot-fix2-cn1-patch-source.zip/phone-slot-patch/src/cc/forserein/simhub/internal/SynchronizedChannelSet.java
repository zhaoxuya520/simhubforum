package cc.forserein.simhub.internal;

import android.se.omapi.Channel;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;

/** Preserves the original field type, with snapshot iteration during concurrent close/open. */
public final class SynchronizedChannelSet extends LinkedHashSet<Channel> {
    private static final long serialVersionUID = 1L;
    @Override public synchronized boolean add(Channel channel) { return super.add(channel); }
    @Override public synchronized boolean remove(Object channel) { return super.remove(channel); }
    @Override public synchronized void clear() { super.clear(); }
    @Override public synchronized int size() { return super.size(); }
    @Override public synchronized boolean isEmpty() { return super.isEmpty(); }
    @Override public synchronized boolean contains(Object channel) { return super.contains(channel); }
    @Override public synchronized boolean addAll(Collection<? extends Channel> channels) { return super.addAll(channels); }
    @Override public synchronized Object[] toArray() { return snapshot().toArray(); }
    @Override public synchronized <T> T[] toArray(T[] array) { return snapshot().toArray(array); }

    /** A single snapshot replaces Kotlin's multi-step size/iterator conversion on close. */
    public static List<Channel> copyOf(Collection<Channel> channels) {
        synchronized (channels) { return new ArrayList<Channel>(channels); }
    }

    private ArrayList<Channel> snapshot() {
        ArrayList<Channel> copy = new ArrayList<Channel>(super.size());
        Iterator<Channel> live = super.iterator();
        while (live.hasNext()) copy.add(live.next());
        return copy;
    }

    @Override public synchronized Iterator<Channel> iterator() {
        final Iterator<Channel> snapshot = snapshot().iterator();
        return new Iterator<Channel>() {
            private Channel last;
            private boolean canRemove;
            @Override public boolean hasNext() { return snapshot.hasNext(); }
            @Override public Channel next() { last = snapshot.next(); canRemove = true; return last; }
            @Override public void remove() {
                if (!canRemove) throw new IllegalStateException();
                SynchronizedChannelSet.this.remove(last);
                canRemove = false;
            }
        };
    }
}
