package cc.forserein.simhub.internal;

import android.content.Context;
import android.os.Build;
import android.se.omapi.Channel;
import android.se.omapi.Reader;
import android.se.omapi.SEService;
import android.se.omapi.Session;
import android.telephony.TelephonyManager;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

/** Unprivileged OMAPI only. Card ACLs and Android access controls remain authoritative. */
public final class OmapiSupport {
    private OmapiSupport() {}

    // Presentation only: never use a cached identification to grant access or skip card selection.
    private enum CardState { MISSING, UNKNOWN, DENIED, BUSY, EUICC }
    private static final class CardInfo {
        final CardState state;
        final String detail;
        CardInfo(CardState state, String detail) { this.state = state; this.detail = detail; }
    }
    private static final class Discovery {
        final Map<String, CardInfo> cards;
        final String emptyMessage;
        Discovery(Map<String, CardInfo> cards, String emptyMessage) {
            this.cards = Collections.unmodifiableMap(new LinkedHashMap<String, CardInfo>(cards));
            this.emptyMessage = emptyMessage;
        }
    }
    private static volatile Discovery latest = new Discovery(Collections.<String, CardInfo>emptyMap(),
            "未发现可访问的手机卡槽。请确认已插卡，并且系统向应用开放了卡槽访问。");

    /** Invoke on an IO dispatcher, never the Android main thread. */
    public static SEService connect(Context context) {
        if (Build.VERSION.SDK_INT < 28) throw new IllegalStateException("内置卡槽访问需要 Android 9 或更新版本");
        final CountDownLatch connected = new CountDownLatch(1);
        SEService service;
        try {
            service = new SEService(context.getApplicationContext(), new Executor() {
                @Override public void execute(Runnable task) { task.run(); }
            }, new SEService.OnConnectedListener() {
                @Override public void onConnected() { connected.countDown(); }
            });
        } catch (RuntimeException e) {
            throw new IllegalStateException("手机未提供可用的安全元件服务，无法访问内置卡槽", e);
        }
        boolean ready = false;
        try {
            ready = connected.await(5, TimeUnit.SECONDS) && service.isConnected();
            if (!ready) throw new IllegalStateException("连接手机卡槽服务超时（5 秒），请检查系统是否支持 UICC OMAPI");
            return service;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("连接手机卡槽已取消", e);
        } finally {
            if (!ready) shutdown(service);
        }
    }

    public static LinkedHashMap<String, Reader> readers(Context context, SEService service) {
        LinkedHashMap<String, Reader> result = new LinkedHashMap<String, Reader>();
        Reader[] available = null;
        RuntimeException enumerationFailure = null;
        try { available = service.getReaders(); }
        catch (RuntimeException e) { enumerationFailure = e; }
        if (available != null) {
            for (Reader reader : available) {
                try {
                    if (reader != null && SimProtocol.isUiccName(reader.getName())) addPresent(result, reader);
                } catch (RuntimeException ignored) { /* Continue with the other slots. */ }
            }
        }
        // API 30's explicit slot accessor also handles vendor reader names that are not SIM1/SIM2.
        if (Build.VERSION.SDK_INT >= 30) {
            int slots = 2;
            try {
                TelephonyManager tm = context.getSystemService(TelephonyManager.class);
                if (tm != null) slots = Math.max(slots, tm.getActiveModemCount());
            } catch (RuntimeException ignored) { /* OMAPI does not require READ_PHONE_STATE. */ }
            for (int slot = 1; slot <= Math.min(slots, 8); slot++) {
                try { addPresent(result, service.getUiccReader(slot)); }
                catch (IllegalArgumentException | IllegalStateException | UnsupportedOperationException | SecurityException ignored) { }
            }
        }
        if (result.isEmpty() && enumerationFailure != null) {
            throw new IllegalStateException("系统无法枚举可访问的手机卡槽，请刷新重试", enumerationFailure);
        }
        return result;
    }

    private static void addPresent(Map<String, Reader> result, Reader reader) {
        try {
            if (reader != null && reader.isSecureElementPresent()) {
                String name = reader.getName();
                if (name != null && !name.trim().isEmpty()) result.put(name, reader);
            }
        } catch (RuntimeException ignored) { /* One unavailable slot must not hide another card. */ }
    }

    public static String[] discover(Context context) {
        return discover(context, Collections.singletonList(SimProtocol.ISDR));
    }

    public static synchronized String[] discover(Context context, List<byte[]> supportedAids) {
        LinkedHashMap<String, CardInfo> cards = new LinkedHashMap<String, CardInfo>();
        String emptyMessage = "未发现可访问的手机卡槽。请确认已插卡，并且系统向应用开放了卡槽访问。";
        SEService service = null;
        try {
            service = connect(context);
            for (Map.Entry<String, Reader> entry : readers(context, service).entrySet()) {
                cards.put(entry.getKey(), identify(entry.getValue(), supportedAids));
            }
        } catch (RuntimeException e) {
            emptyMessage = e.getMessage() == null ? "手机卡槽暂不可用，请刷新重试。" : e.getMessage();
        } finally {
            shutdown(service);
            latest = new Discovery(cards, emptyMessage);
        }
        return cards.keySet().toArray(new String[cards.size()]);
    }

    private static CardInfo identify(Reader reader, List<byte[]> supportedAids) {
        // Use the exact candidate set used by SIMHub's management backend. Try the standard
        // AID first for fast discovery; vendor AIDs remain subject to their own card ACLs.
        LinkedHashMap<String, byte[]> candidates = new LinkedHashMap<String, byte[]>();
        candidates.put(SimProtocol.hex(SimProtocol.ISDR), SimProtocol.ISDR.clone());
        if (supportedAids != null) for (byte[] aid : supportedAids) {
            if (aid != null && aid.length >= 5 && aid.length <= 16) {
                candidates.put(SimProtocol.hex(aid), aid.clone());
            }
        }
        CardInfo best = new CardInfo(CardState.MISSING, "已发现卡片，未找到受支持的 eSIM 管理应用；可点选尝试连接。");
        for (byte[] aid : candidates.values()) {
            CardInfo result = identifyAid(reader, aid);
            if (result.state == CardState.EUICC || result.state == CardState.BUSY) return result;
            if (result.state.ordinal() > best.state.ordinal()) best = result;
        }
        return best;
    }

    private static CardInfo identifyAid(Reader reader, byte[] aid) {
        Session session = null;
        Channel channel = null;
        try {
            session = reader.openSession();
            // A slot name, subscription, or open channel alone does not identify an eUICC.
            channel = openLogicalChannel(session, aid);
            if (channel == null) return new CardInfo(CardState.BUSY, "卡片通道正忙；关闭其他读卡应用后刷新，或点选重试。");
            final Channel selected = channel;
            SimProtocol.readEid(new SimProtocol.Exchange() {
                @Override public byte[] transmit(byte[] command) throws IOException {
                    return OmapiSupport.transmit(selected, command);
                }
            });
            // Do not retain EIDs, and do not probe authentication with fabricated challenges.
            return new CardInfo(CardState.EUICC, "点选连接后管理 eSIM；Wi-Fi Calling、短信和通话还需卡片允许通信认证。");
        } catch (SecurityException e) {
            return new CardInfo(CardState.DENIED, accessDenied("建立卡片会话", aid, e));
        } catch (NoSuchElementException e) {
            return new CardInfo(CardState.MISSING, "已发现卡片，未找到受支持的 eSIM 管理应用；可点选尝试连接。");
        } catch (IOException e) {
            if (e.getCause() instanceof SecurityException) {
                return new CardInfo(CardState.DENIED, e.getMessage());
            }
            if (e.getCause() instanceof NoSuchElementException) {
                return new CardInfo(CardState.MISSING, "已发现卡片，未找到受支持的 eSIM 管理应用；可点选尝试连接。");
            }
            if (e instanceof NoFreeChannelException) {
                return new CardInfo(CardState.BUSY, "卡片通道正忙；关闭其他读卡应用后刷新，或点选重试。");
            }
            return new CardInfo(CardState.UNKNOWN, "已发现卡片，暂未确认是否为 eSIM；可点选连接或刷新重试。");
        } catch (RuntimeException e) {
            return new CardInfo(CardState.UNKNOWN, "已发现卡片，暂未确认是否为 eSIM；可点选连接或刷新重试。");
        } finally {
            if (channel != null) try { channel.close(); } catch (RuntimeException ignored) { }
            if (session != null) try { session.close(); } catch (RuntimeException ignored) { }
        }
    }

    public static String cardTitle(String name) {
        CardInfo card = latest.cards.get(name);
        return (card != null && card.state == CardState.EUICC ? "eSIM 芯片卡 · 本机 " : "手机卡槽 · ") + name;
    }

    public static String cardSubtitle(String name) {
        CardInfo card = latest.cards.get(name);
        return card == null ? "点选连接手机卡槽里的卡片。" : card.detail;
    }

    public static String unavailableMessage() {
        return latest.emptyMessage;
    }

    public static Reader select(Context context, SEService service, String name) {
        Reader reader = readers(context, service).get(name);
        if (reader == null) throw new IllegalStateException("该卡槽未开放或没有可访问的卡片，请返回卡片列表刷新重试");
        return reader;
    }

    public static Channel openLogicalChannel(Session session, byte[] aid) throws IOException {
        try {
            Channel channel = session.openLogicalChannel(aid);
            if (channel == null) throw new NoFreeChannelException(SimProtocol.purpose(aid) + "暂时没有可用逻辑通道；请关闭其他读卡应用后重试");
            return channel;
        } catch (SecurityException e) {
            throw new IOException(accessDenied("打开逻辑通道", aid, e), e);
        } catch (NoSuchElementException e) {
            throw new IOException(SimProtocol.purpose(aid) + "不存在或当前配置未激活；请确认卡片型号和已启用的配置", e);
        }
    }

    public static byte[] transmit(Channel channel, byte[] command) throws IOException {
        if (command == null || command.length < 4) throw new IOException("APDU 命令不完整");
        try {
            if (!channel.isOpen()) throw new IOException("卡片通道已关闭，切卡或卡片刷新后请重新连接");
            // Android assigns the channel bits. Do not send raw MANAGE CHANNEL or retry mutations.
            byte[] response = channel.transmit(command);
            if (response == null || response.length < 2) throw new IOException("卡片响应缺少状态字");
            return response;
        } catch (SecurityException e) {
            throw new IOException("Android 拒绝此 APDU（SecurityException，命令被拒绝）；原因：" + platformReason(e), e);
        } catch (IllegalStateException e) {
            throw new IOException("卡片服务或通道已失效，切卡或卡片刷新后请重新连接", e);
        }
    }

    private static final class NoFreeChannelException extends IOException {
        NoFreeChannelException(String message) { super(message); }
    }

    private static String accessDenied(String operation, byte[] aid, SecurityException failure) {
        return SimProtocol.purpose(aid) + "：Android 拒绝访问（SecurityException，" + operation
                + "）；AID=" + SimProtocol.hex(aid) + "；原因：" + platformReason(failure);
    }

    private static String platformReason(Throwable failure) {
        String message = failure.getMessage();
        if (message == null || message.trim().isEmpty()) return "平台未提供具体原因";
        // AIDs and platform access errors are useful; never record APDU payloads or EIDs.
        message = message.replaceAll("[\\p{Cc}\\p{Cf}]+", " ").trim();
        return message.length() > 200 ? message.substring(0, 200) + "…" : message;
    }

    public static boolean isConnected(SEService service, Reader reader) {
        try { return service.isConnected() && reader.isSecureElementPresent(); }
        catch (RuntimeException e) { return false; }
    }

    public static void shutdown(SEService service) {
        if (service != null) try { service.shutdown(); } catch (RuntimeException ignored) { }
    }
}
