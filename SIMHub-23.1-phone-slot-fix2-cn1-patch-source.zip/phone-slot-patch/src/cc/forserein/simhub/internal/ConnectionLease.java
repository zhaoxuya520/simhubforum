package cc.forserein.simhub.internal;

import android.se.omapi.SEService;
import java.util.concurrent.CancellationException;

/** Owns a service until withContext successfully delivers the transport to its caller. */
public final class ConnectionLease {
    private SEService pending;
    private boolean finished;

    public synchronized void attach(SEService service) {
        if (finished) {
            OmapiSupport.shutdown(service);
            throw new CancellationException("手机卡槽连接已取消");
        }
        if (pending != null) throw new IllegalStateException("A connection is already pending");
        pending = service;
    }

    public void complete(boolean delivered) {
        SEService release;
        synchronized (this) {
            if (finished) return;
            finished = true;
            release = pending;
            pending = null;
        }
        if (!delivered) OmapiSupport.shutdown(release);
    }
}
