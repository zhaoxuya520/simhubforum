package cc.forserein.simhub.internal;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Locale;

/** Protocol helpers independent of Android; never logs APDUs or authentication material. */
public final class SimProtocol {
    public static final byte[] ISDR = hex("A0000005591010FFFFFFFF8900000100");
    public static final byte[] USIM = hex("A0000000871002");
    private SimProtocol() {}

    public interface Exchange { byte[] transmit(byte[] command) throws IOException; }

    public static boolean isUiccName(String name) {
        if (name == null) return false;
        String n = name.trim().toUpperCase(Locale.ROOT);
        return n.startsWith("SIM")
                || n.startsWith("UICC") || n.startsWith("EUICC");
    }

    public static byte[] hex(String value) {
        if (value == null || (value.length() & 1) != 0) throw new IllegalArgumentException("Invalid hex");
        byte[] result = new byte[value.length() / 2];
        for (int i = 0; i < result.length; i++) {
            int hi = Character.digit(value.charAt(i * 2), 16);
            int lo = Character.digit(value.charAt(i * 2 + 1), 16);
            if (hi < 0 || lo < 0) throw new IllegalArgumentException("Invalid hex");
            result[i] = (byte) ((hi << 4) | lo);
        }
        return result;
    }

    public static String hex(byte[] value) {
        StringBuilder result = new StringBuilder();
        for (byte b : value) result.append(String.format(Locale.ROOT, "%02X", b & 255));
        return result.toString();
    }

    public static String purpose(byte[] aid) {
        String value = hex(aid);
        if (value.startsWith("A0000000871002")) return "USIM 认证通道（Wi-Fi Calling）";
        if (value.startsWith("A0000005591010")) return "eSIM 管理通道（ISD-R）";
        return "卡片应用通道";
    }

    /** Read-only eUICC identification, with bounded GET RESPONSE processing. */
    public static byte[] readEid(Exchange exchange) throws IOException {
        byte[] command = hex("80E2910006BF3E035C015A00");
        ByteArrayOutputStream collected = new ByteArrayOutputStream();
        for (int attempts = 0; attempts < 32; attempts++) {
            byte[] response = exchange.transmit(command);
            if (response == null || response.length < 2) throw new IOException("卡片返回了不完整的响应");
            int n = response.length;
            int sw1 = response[n - 2] & 255;
            int sw2 = response[n - 1] & 255;
            if (sw1 == 0x6c && n == 2) {
                command = command.clone();
                command[command.length - 1] = (byte) sw2;
                continue;
            }
            if (collected.size() + n - 2 > 65536) throw new IOException("卡片响应超出大小限制");
            collected.write(response, 0, n - 2);
            if (sw1 == 0x61) {
                command = new byte[]{0, (byte) 0xc0, 0, 0, (byte) sw2};
                continue;
            }
            if (sw1 != 0x90 || sw2 != 0) throw new IOException(String.format(Locale.ROOT, "GET EID 返回 %02X%02X", sw1, sw2));
            byte[] body = collected.toByteArray();
            if (body.length < 3 || (body[0] & 255) != 0xbf || (body[1] & 255) != 0x3e) {
                throw new IOException("响应不是有效的 GET EID 数据");
            }
            byte[] eid = findEid(body, 0);
            if (eid == null) throw new IOException("响应中没有有效的 16 字节 EID");
            return eid;
        }
        throw new IOException("GET EID 响应次数超限");
    }

    private static byte[] findEid(byte[] tlv, int depth) throws IOException {
        if (depth > 8) throw new IOException("TLV 嵌套过深");
        int p = 0;
        byte[] found = null;
        while (p < tlv.length) {
            int first = tlv[p++] & 255;
            int tag = first;
            if ((first & 31) == 31) {
                int bytes = 0, next;
                do {
                    if (p >= tlv.length || ++bytes > 3) throw new IOException("TLV 标签损坏");
                    next = tlv[p++] & 255;
                    tag = (tag << 8) | next;
                } while ((next & 128) != 0);
            }
            if (p >= tlv.length) throw new IOException("TLV 长度缺失");
            int length = tlv[p++] & 255;
            if ((length & 128) != 0) {
                int count = length & 127;
                if (count == 0 || count > 2 || p + count > tlv.length) throw new IOException("TLV 长度无效");
                length = 0;
                for (int i = 0; i < count; i++) length = (length << 8) | (tlv[p++] & 255);
            }
            if (length > tlv.length - p) throw new IOException("TLV 数据截断");
            byte[] value = new byte[length];
            System.arraycopy(tlv, p, value, 0, length);
            if (tag == 0x5a && length == 16) {
                for (byte b : value) if ((b & 15) > 9 || ((b & 255) >>> 4) > 9) throw new IOException("EID 编码无效");
                if (found != null) throw new IOException("响应包含重复 EID");
                found = value;
            }
            if ((first & 32) != 0) {
                byte[] nested = findEid(value, depth + 1);
                if (nested != null) {
                    if (found != null) throw new IOException("响应包含重复 EID");
                    found = nested;
                }
            }
            p += length;
        }
        return found;
    }
}
