package cc.forserein.simhub.internal;

/** Number formatting at the existing call and SMS entry points. No carrier guessing. */
public final class DialingSupport {
    private DialingSupport() {}

    /** Preserve dial-string punctuation while converting decimal digits and fullwidth +. */
    public static String ascii(String input) {
        input.getClass();
        StringBuilder out = new StringBuilder(input.length());
        for (int offset = 0; offset < input.length();) {
            int cp = input.codePointAt(offset);
            offset += Character.charCount(cp);
            if (Character.isDigit(cp)) {
                out.append((char) ('0' + Character.digit(cp, 10)));
            } else if (cp == 0xff0b) {
                out.append('+');
            } else {
                out.appendCodePoint(cp);
            }
        }
        return out.toString();
    }

    /** Retain the original UI's digits/leading-plus policy, with ASCII output. */
    public static String normalize(String input) {
        String text = ascii(input);
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c >= '0' && c <= '9') || (c == '+' && out.length() == 0)) {
                out.append(c);
            }
        }
        return out.toString();
    }

    /** Match the existing call path's 00-prefix support before SMS BCD encoding. */
    public static String smsDestination(String input) {
        String number = normalize(input);
        if (number.startsWith("00") && number.length() > 2) {
            return "+" + number.substring(2);
        }
        return number;
    }
}
