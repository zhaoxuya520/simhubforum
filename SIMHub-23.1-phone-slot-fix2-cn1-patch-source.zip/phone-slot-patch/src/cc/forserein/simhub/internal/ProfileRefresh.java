package cc.forserein.simhub.internal;

/** ES10c switch requests and read-back confirmation; never retransmits a mutation. */
public final class ProfileRefresh {
    private ProfileRefresh() {}

    public static byte[] command(byte[] iccid, int action, boolean phoneSlot) {
        if (iccid == null || iccid.length == 0 || iccid.length > 32 || (action != 0 && action != 1)) {
            throw new IllegalArgumentException("无效的配置切换参数");
        }
        // EnableProfile BF31 / DisableProfile BF32: profileIdentifier [0] { iccid [APPLICATION 26] },
        // refreshFlag [1] BOOLEAN. DER true is FF. Keep reader behavior at false.
        byte[] result = new byte[iccid.length + 10];
        result[0] = (byte) 0xbf;
        result[1] = (byte) (action == 0 ? 0x31 : 0x32);
        result[2] = (byte) (iccid.length + 7);
        result[3] = (byte) 0xa0;
        result[4] = (byte) (iccid.length + 2);
        result[5] = 0x5a;
        result[6] = (byte) iccid.length;
        System.arraycopy(iccid, 0, result, 7, iccid.length);
        result[result.length - 3] = (byte) 0x81;
        result[result.length - 2] = 1;
        result[result.length - 1] = phoneSlot ? (byte) 0xff : 0;
        return result;
    }

    public static boolean confirmed(String expectedIccid, boolean expectedEnabled, String[] iccids, boolean[] enabled) {
        if (expectedIccid == null || iccids == null || enabled == null || iccids.length != enabled.length) return false;
        boolean found = false;
        for (int i = 0; i < iccids.length; i++) {
            if (expectedIccid.equals(iccids[i])) {
                if (found || enabled[i] != expectedEnabled) return false;
                found = true;
            }
        }
        return found;
    }
}
