"""Narrow, reproducible destination-policy and number-format patches for APK 23.1."""
import hashlib
import re

ORIGINAL_SHA256 = {
    'u10.smali': '413142109713c6aeff25f0ed12d0b4430017799cf964ce804786f907ca5d7bad',
    'f82.smali': 'e3df19c4b8e571edcafc23ce5548880cf04f463a838a987c795d8b54f2f3e8a9',
    'ub4.smali': '3228bc8994ed8896f302e6116109eb783d83e6d7d8afc35c674a23c2dfc9543e',
}
HELPER = 'Lcc/forserein/simhub/internal/DialingSupport;'
CALL_ANCHOR = '    :cond_1\n    iget-object v1, v0, Lf82;->Z:Ljava/lang/String;'
CALL_HOOK = ('\n    invoke-static {v1}, ' + HELPER + '->ascii(Ljava/lang/String;)Ljava/lang/String;'
             '\n    move-result-object v1')
SMS_ANCHOR = '    iput-object p3, p0, Lub4;->g0:Ljava/lang/String;'
SMS_HOOK = ('    invoke-static {p3}, ' + HELPER + '->smsDestination(Ljava/lang/String;)Ljava/lang/String;'
            '\n    move-result-object p3\n')


def replace_method(text, signature, body):
    pattern = re.compile(r'^\.method ' + re.escape(signature) + r'\n.*?^\.end method', re.M | re.S)
    assert len(pattern.findall(text)) == 1, signature
    return pattern.sub(lambda _: '.method ' + signature + '\n' + body.strip('\n') + '\n.end method', text)


def patch_dialing_class(name, original):
    if hashlib.sha256(original.encode()).hexdigest() != ORIGINAL_SHA256[name]:
        raise ValueError('Unexpected original dialing bytecode: ' + name)
    if name == 'u10.smali':
        # This method only classifies mainland destinations. Emergency handling,
        # permissions, signing and IMS registration checks live elsewhere.
        text = replace_method(original, 'public static b(Ljava/lang/String;Ljava/lang/String;)Z', '''
    .locals 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    const/4 v0, 0x0
    return v0
''')
        return replace_method(text, 'public static c(Ljava/lang/String;)Ljava/lang/String;', '''
    .locals 1
    invoke-static {p0}, Lcc/forserein/simhub/internal/DialingSupport;->normalize(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
''')
    if name == 'f82.smali':
        # Touch only the outgoing dial-string branch, never the call IDs used by
        # the other coroutine modes (answer, hang up, SDP lookup, decline).
        assert original.count(CALL_ANCHOR) == 1
        return original.replace(CALL_ANCHOR, CALL_ANCHOR + CALL_HOOK)
    assert name == 'ub4.smali'
    # g0 is the recipient. f0 is the SMSC and h0 is the user's message body.
    # Canonicalizing here is idempotent when the coroutine clones itself.
    assert original.count(SMS_ANCHOR) == 1
    return original.replace(SMS_ANCHOR, SMS_HOOK + SMS_ANCHOR)
