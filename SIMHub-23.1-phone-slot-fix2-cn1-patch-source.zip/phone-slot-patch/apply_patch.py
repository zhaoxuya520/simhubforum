#!/usr/bin/env python3
"""Apply only to a fresh copy of the decoded 23.1 APK; fail on unexpected bytecode."""
from pathlib import Path
import re
import shutil
import sys
from signing_policy import patch_security_policy
from dialing_patch import ORIGINAL_SHA256, patch_dialing_class

root = Path(sys.argv[1]).resolve()
here = Path(__file__).resolve().parent
smali = root / 'smali'

for name in ORIGINAL_SHA256:
    path = smali / name
    path.write_text(patch_dialing_class(name, path.read_text()))

# The original card-operation gate verifies the APK signing certificate. Trust
# the pinned public test certificate, retaining every other security check.
security = smali / 'mg.smali'
security.write_text(patch_security_policy(security.read_text()))

def replace_method(filename, signature, body):
    path = smali / filename
    text = path.read_text()
    pattern = re.compile(r'^\.method ' + re.escape(signature) + r'\n.*?^\.end method', re.M | re.S)
    assert len(pattern.findall(text)) == 1, (filename, signature)
    path.write_text(pattern.sub(lambda _: '.method ' + signature + '\n' + body.strip('\n') + '\n.end method', text))

replace_method('lf3.smali', 'public final a(Landroid/content/Context;Ljava/lang/String;Ldt0;)Ljava/lang/Object;', '''
    .locals 3
    new-instance v0, LInternalSimReaderTask;
    invoke-direct {v0, p1, p2}, LInternalSimReaderTask;-><init>(Landroid/content/Context;Ljava/lang/String;)V
    new-instance v1, LInternalSimConnectContinuation;
    invoke-direct {v1, p3, v0}, LInternalSimConnectContinuation;-><init>(Lct0;LInternalSimReaderTask;)V
    :try_start
    sget-object v2, Lcz0;->V:Lcz0;
    invoke-static {v2, v0, v1}, Lxq0;->g0(Lfu0;Lkt1;Lct0;)Ljava/lang/Object;
    move-result-object v2
    :try_end
    .catchall {:try_start .. :try_end} :failed
    sget-object v1, Lpu0;->T:Lpu0;
    if-eq v2, v1, :return
    const/4 v1, 0x1
    invoke-virtual {v0, v1}, LInternalSimReaderTask;->complete(Z)V
    :return
    return-object v2
    :failed
    move-exception v2
    const/4 v1, 0x0
    invoke-virtual {v0, v1}, LInternalSimReaderTask;->complete(Z)V
    throw v2
''')
replace_method('lf3.smali', 'public final b(Landroid/content/Context;Ldt0;)Ljava/io/Serializable;', '''
    .locals 3
    const/4 v0, 0x0
    new-instance v1, LInternalSimReaderTask;
    invoke-direct {v1, p1, v0}, LInternalSimReaderTask;-><init>(Landroid/content/Context;Ljava/lang/String;)V
    sget-object v2, Lcz0;->V:Lcz0;
    invoke-static {v2, v1, p2}, Lxq0;->g0(Lfu0;Lkt1;Lct0;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/io/Serializable;
    return-object v0
''')
replace_method('qf3.smali', 'public final f()Z', '''
    .locals 2
    iget-boolean v0, p0, Lqf3;->e:Z
    if-nez v0, :unavailable
    iget-object v0, p0, Lqf3;->a:Landroid/se/omapi/SEService;
    iget-object v1, p0, Lqf3;->b:Landroid/se/omapi/Reader;
    invoke-static {v0, v1}, Lcc/forserein/simhub/internal/OmapiSupport;->isConnected(Landroid/se/omapi/SEService;Landroid/se/omapi/Reader;)Z
    move-result v0
    return v0
    :unavailable
    const/4 v0, 0x0
    return v0
''')

# Keep the existing click action intact: gf3 -> iz3.h -> iz3.b -> hh1/ac5.
# Only the presentation of real reader rows changes; there are no synthetic rows.
path = smali / 'qf5.smali'
text = path.read_text()
old = 'invoke-virtual {v8, v7}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;'
new = 'invoke-static {v7}, Lcc/forserein/simhub/internal/OmapiSupport;->cardTitle(Ljava/lang/String;)Ljava/lang/String;'
# Scope to the builtin-reader list method to avoid modifying unrelated Compose screens.
start = text.index('.method public static final b(Liz3;ILlu1;I)V')
end = text.index('.end method', start)
method = text[start:end]
assert method.count(old) == 1
method = method.replace(old, new)
anchor = '    :cond_12\n    invoke-interface {v3}, Lot4;->getValue()Ljava/lang/Object;'
replacement = '''    :cond_12
    iget-object v8, v2, Lgf3;->a:Ljava/lang/String;
    invoke-static {v8}, Lcc/forserein/simhub/internal/OmapiSupport;->cardSubtitle(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v9
    invoke-interface {v3}, Lot4;->getValue()Ljava/lang/Object;'''
assert method.count(anchor) == 1
method = method.replace(anchor, replacement)
anchor = '    :cond_e\n    invoke-virtual {v6}, Llu1;->P()Ljava/lang/Object;'
replacement = '''    :cond_e
    invoke-static {}, Lcc/forserein/simhub/internal/OmapiSupport;->unavailableMessage()Ljava/lang/String;
    move-result-object v7
    invoke-virtual {v6}, Llu1;->P()Ljava/lang/Object;'''
assert method.count(anchor) == 1
method = method.replace(anchor, replacement)
path.write_text(text[:start] + method + text[end:])

path = smali / 'qf3.smali'
text = path.read_text()
old = 'invoke-static {p2, p1}, Lbu0;->m(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;'
assert text.count(old) == 1
path.write_text(text.replace(old, 'invoke-static {p1}, Lcc/forserein/simhub/internal/OmapiSupport;->cardTitle(Ljava/lang/String;)Ljava/lang/String;'))

replacements = {
    'pf3.smali': (
        r'invoke-virtual (\{[^}]+\}), Landroid/se/omapi/Session;->openLogicalChannel\(\[B\)Landroid/se/omapi/Channel;',
        r'invoke-static \1, Lcc/forserein/simhub/internal/OmapiSupport;->openLogicalChannel(Landroid/se/omapi/Session;[B)Landroid/se/omapi/Channel;'),
    'nf3.smali': (
        r'invoke-virtual (\{[^}]+\}), Landroid/se/omapi/Channel;->transmit\(\[B\)\[B',
        r'invoke-static \1, Lcc/forserein/simhub/internal/OmapiSupport;->transmit(Landroid/se/omapi/Channel;[B)[B')
}
for filename, (pattern, replacement) in replacements.items():
    path = smali / filename
    text, count = re.subn(pattern, replacement, path.read_text())
    assert count == 1, (filename, count)
    path.write_text(text)

# Retain ownership of an opened logical channel until withContext delivers it.
# pf3 creates a coroutine copy in o(); both instances must share the same lease.
path = smali / 'pf3.smali'
text = path.read_text()
field = '.field public pendingChannel:Lcc/forserein/simhub/internal/ChannelLease;\n\n'
anchor = '# instance fields\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + field)
anchor = '.method public constructor <init>(Lqf3;[BLct0;)V\n    .locals 0'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor.replace('.locals 0', '.locals 1'))
anchor = '    invoke-direct {p0, p1, p3}, Lcz4;-><init>(ILct0;)V'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '''
    new-instance v0, Lcc/forserein/simhub/internal/ChannelLease;
    invoke-direct {v0}, Lcc/forserein/simhub/internal/ChannelLease;-><init>()V
    iput-object v0, p0, Lpf3;->pendingChannel:Lcc/forserein/simhub/internal/ChannelLease;
''')
anchor = '.method public final q(Ljava/lang/Object;)Ljava/lang/Object;\n    .locals 6'
assert text.count(anchor) == 1
text = text.replace(anchor, '''.method public final q(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    iget-object v6, p0, Lpf3;->pendingChannel:Lcc/forserein/simhub/internal/ChannelLease;''')
anchor = '    invoke-direct {v0, v2, v5}, Lof3;-><init>(Landroid/se/omapi/Channel;Ldc3;)V'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '''
    iget-object v5, v3, Lqf3;->d:Ljava/util/LinkedHashSet;
    invoke-virtual {v6, v2, p1, v5}, Lcc/forserein/simhub/internal/ChannelLease;->attach(Landroid/se/omapi/Channel;Landroid/se/omapi/Session;Ljava/util/Collection;)V
''')
path.write_text(text)
replace_method('pf3.smali', 'public final o(Lct0;Ljava/lang/Object;)Lct0;', '''
    .locals 3
    new-instance v0, Lpf3;
    iget-object v1, p0, Lpf3;->c0:Lqf3;
    iget-object v2, p0, Lpf3;->d0:[B
    invoke-direct {v0, v1, v2, p1}, Lpf3;-><init>(Lqf3;[BLct0;)V
    iget-object v1, p0, Lpf3;->pendingChannel:Lcc/forserein/simhub/internal/ChannelLease;
    iput-object v1, v0, Lpf3;->pendingChannel:Lcc/forserein/simhub/internal/ChannelLease;
    iput-object p2, v0, Lpf3;->b0:Ljava/lang/Object;
    return-object v0
''')
for filename in ('hh1.smali', 'ac5.smali'):
    path = smali / filename
    text = path.read_text()
    # Scope to the unique dispatch directly following the pf3 constructor.
    pattern = r'(invoke-direct \{[^}]+\}, Lpf3;-><init>\(Lqf3;\[BLct0;\)V.*?invoke-static \{[^}]+\}, )Lxq0;->g0(\(Lfu0;Lkt1;Lct0;\)Ljava/lang/Object;)'
    text, count = re.subn(pattern, r'\1LInternalSimChannelDispatch;->open\2', text, flags=re.S)
    assert count == 1, (filename, count)
    path.write_text(text)

path = smali / 'qf3.smali'
text = path.read_text()
text = text.replace('.field public e:Z', '.field public volatile e:Z')
for old, new in (
    ('new-instance p1, Ljava/util/LinkedHashSet;', 'new-instance p1, Lcc/forserein/simhub/internal/SynchronizedChannelSet;'),
    ('invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V', 'invoke-direct {p1}, Lcc/forserein/simhub/internal/SynchronizedChannelSet;-><init>()V'),
    ('invoke-static {v0}, Lyk0;->Z0(Ljava/lang/Iterable;)Ljava/util/List;', 'invoke-static {v0}, Lcc/forserein/simhub/internal/SynchronizedChannelSet;->copyOf(Ljava/util/Collection;)Ljava/util/List;')):
    assert text.count(old) == 1
    text = text.replace(old, new)
path.write_text(text)

# The original rf1 always encoded refreshFlag=false. A modem-owned card needs a
# REFRESH request for enable and disable, followed by read-back rather than resending.
replace_method('rf1.smali', 'public final i(Ljava/lang/Object;)Ljava/lang/Object;', '''
    .locals 2
    iget v0, p0, Lrf1;->T:I
    iget-object v1, p0, Lrf1;->U:Lhh1;
    iget-object v1, v1, Lhh1;->a:Lqg0;
    instance-of v1, v1, Ls4;
    check-cast p1, [B
    invoke-static {p1, v0, v1}, Lcc/forserein/simhub/internal/ProfileRefresh;->command([BIZ)[B
    move-result-object p1
    return-object p1
''')

path = smali / 'hz3.smali'
text = path.read_text()
start = text.index('.method public final q(Ljava/lang/Object;)Ljava/lang/Object;')
end = text.index('.end method', start)
method = '\n'.join(line for line in text[start:end].splitlines() if line.strip() and not line.strip().startswith('.line')) + '\n'

def once(old, new):
    global method
    assert method.count(old) == 1, old
    method = method.replace(old, new)

once('    :goto_0\n', '''    :goto_0
    iget-object p1, v0, Lhh1;->a:Lqg0;
    instance-of p1, p1, Ls4;
    if-nez p1, :slot_refresh
''')
once('    iput-boolean v3, v0, Lhh1;->d:Z', '''    :slot_refresh
    iput-boolean v3, v0, Lhh1;->d:Z''')
once('    :goto_2\n    if-ge v3, v4, :cond_6\n    if-lez v3, :cond_3', '''    :goto_2
    const/4 v4, 0x2
    iget-object v7, v0, Lhh1;->a:Lqg0;
    instance-of v7, v7, Ls4;
    if-eqz v7, :attempt_limit_ready
    const/16 v4, 0x1e
    :attempt_limit_ready
    if-ge v3, v4, :cond_6
    if-nez v7, :wait_before_profile_read
    if-lez v3, :cond_3
    :wait_before_profile_read''')
once('    const-wide/16 v7, 0x1f4', '''    const-wide/16 v7, 0x1f4
    iget-object p1, v0, Lhh1;->a:Lqg0;
    instance-of p1, p1, Ls4;
    if-eqz p1, :read_delay_ready
    const-wide/16 v7, 0x3e8
    if-nez v3, :read_delay_ready
    const-wide/16 v7, 0xbb8
    :read_delay_ready''')
once('    :goto_5\n', '''    :goto_5
    instance-of v3, p1, Ljava/util/concurrent/CancellationException;
    if-eqz v3, :read_failure
    throw p1
    :read_failure
''')
once('    :cond_5\n    check-cast p1, Ljava/util/List;', '''    :cond_5
    check-cast p1, Ljava/util/List;
    iget-object v7, v0, Lhh1;->a:Lqg0;
    instance-of v7, v7, Ls4;
    if-eqz v7, :profile_check_done
    iget-object v7, p0, Lhz3;->c0:Lqy3;
    iget-object v7, v7, Lqy3;->a:Ljava/lang/String;
    iget-boolean v8, p0, Lhz3;->d0:Z
    invoke-static {p1, v7, v8}, LInternalSimProfileState;->matches(Ljava/util/List;Ljava/lang/String;Z)Z
    move-result v7
    if-nez v7, :profile_check_done
    move-object p1, v6
    :profile_check_done''')
once('    :cond_6\n    if-eqz p1, :cond_9', '''    :cond_6
    if-nez p1, :confirmed_profile
    iget-object v7, v0, Lhh1;->a:Lqg0;
    instance-of v7, v7, Ls4;
    if-eqz v7, :cond_9
    new-instance p1, Ljava/lang/IllegalStateException;
    const-string v7, "配置变更已请求，但未确认卡槽刷新结果。请刷新配置列表确认当前状态后再操作。"
    invoke-direct {p1, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    throw p1
    :confirmed_profile''')
path.write_text(text[:start] + method + text[end:])

# Do not present a failed local card read as an empty eUICC or offer profile
# download from that state. Keep the original empty-card UI after a valid read.
path = smali / 'bf0.smali'
text = path.read_text()
old = '    invoke-static {v0, v10, v7}, Lna2;->q(Lus1;Llu1;I)V'
assert text.count(old) == 1
text = text.replace(old, '''    move-object/from16 v1, p0
    iget-object v1, v1, Lbf0;->W:Liz3;
    invoke-static {v0, v1, v10, v7}, LInternalSimProfileUi;->render(Lus1;Liz3;Llu1;I)V''')
path.write_text(text)

for name in ('InternalSimReaderTask.smali', 'InternalSimConnectContinuation.smali', 'InternalSimProfileState.smali', 'InternalSimChannelDispatch.smali', 'InternalSimChannelContinuation.smali', 'InternalSimProfileUi.smali'):
    shutil.copyfile(here / 'smali' / name, smali / name)
# The category and transport selectors remain the original ones. Fix their Chinese copy
# so the ordinary-SIM category describes its built-in-card workflow, too.
strings = root / 'assets/i18n/zh-Hans.strings'
text = strings.read_text()
key = 'card_reader_category_hint_plain'
text, count = re.subn(r'^"' + key + r'" = ".*";$',
    '"' + key + '" = "手机卡槽内的 SIM / eSIM 芯片卡，或 USB 读卡器内的 SIM 卡。连接后可使用通信功能；eSIM 芯片卡还可管理配置。";', text, flags=re.M)
assert count == 1
additions = {
    'card_reader_mode_builtin_sim': '手机卡槽',
    'card_reader_hint_builtin_sim': '读取手机卡槽里的卡片。eSIM 芯片卡可直接进入配置管理及 Wi-Fi Calling。',
    'card_reader_builtin_sim_searching': '正在读取手机卡槽并识别 eSIM 芯片卡…',
}
for key, value in additions.items():
    assert ('"' + key + '" =') not in text
    text += '\n"' + key + '" = "' + value + '";\n'
strings.write_text(text)
print('Applied in-list eUICC identification and real-card access hooks; original management/IMS click route preserved.')
