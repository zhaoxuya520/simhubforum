#!/usr/bin/env python3
"""Sign with a separately held key and reject a self-check/signature mismatch."""
from pathlib import Path
import argparse
import json
import subprocess

from verify_signed import ROOT, TOOLS, verify

parser = argparse.ArgumentParser()
parser.add_argument('--keystore', required=True, type=Path)
parser.add_argument('--alias', required=True)
parser.add_argument('--password-file', required=True, type=Path)
parser.add_argument('--out', required=True, type=Path)
args = parser.parse_args()
subprocess.run(['python3', str(ROOT / 'verify.py')], check=True)
subprocess.run([
    'java', '-jar', str(TOOLS / 'sdk/android-15/lib/apksigner.jar'), 'sign',
    '--v1-signing-enabled', 'false', '--v2-signing-enabled', 'true',
    '--v3-signing-enabled', 'true',
    '--ks', str(args.keystore.resolve()), '--ks-key-alias', args.alias,
    '--ks-pass', 'file:' + str(args.password_file.resolve()),
    '--out', str(args.out.resolve()),
    str(ROOT / 'build/SIMHub-23.1-internal-sim-unsigned.apk'),
], check=True)
print(json.dumps(verify(args.out.resolve()), indent=2))
