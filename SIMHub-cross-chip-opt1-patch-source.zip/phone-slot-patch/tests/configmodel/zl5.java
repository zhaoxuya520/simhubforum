public class zl5 {public static boolean active;public static boolean k(){return active;}public static android.content.Context f;public static final Flow b=new Flow();}
