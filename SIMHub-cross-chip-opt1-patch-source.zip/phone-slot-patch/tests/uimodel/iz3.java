public class iz3 extends MultiChipSwitchTest.Controller {
 public boolean busy;public String error;
 public iz3(MultiChipSwitchTest.Chip...c){super(c);}
 public boolean u(){return busy;}
 public void G(String s){error=s;}
}
