public class qy3 {public String a;public boolean b;public qy3(String id,boolean enabled){a=id;b=enabled;}}
