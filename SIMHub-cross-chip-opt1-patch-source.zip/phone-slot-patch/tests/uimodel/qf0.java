public class qf0 implements us1 {
 public static int launches;public static boolean enabled,connect;
 public qf0(iz3 owner,qy3 target,boolean enable,boolean connection,ws1 refresh,us1 close){enabled=enable;connect=connection;}
 public Object a(){launches++;return sc5.a;}
}
