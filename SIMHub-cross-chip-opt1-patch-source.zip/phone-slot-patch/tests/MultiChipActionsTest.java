import cc.forserein.simhub.internal.MultiChipActions;
public class MultiChipActionsTest {
 static int passed;static void check(boolean b){if(!b)throw new AssertionError();passed++;}
 public static void main(String[]args)throws Exception {
  iz3 owner=new iz3(new MultiChipSwitchTest.Chip("a"),new MultiChipSwitchTest.Chip("b"));
  qy3 target=new qy3("target",true);lu1 c=new lu1();
  MultiChipActions.render(owner,target,c);check(ak2.activationLabel.equals("只启用此配置") && ak2.activation!=null);
  ak2.activation.a();check(qf0.launches==1 && qf0.enabled && !qf0.connect);
  owner.busy=true;MultiChipActions.render(owner,target,c);check(ak2.activation==null);
  MultiChipActions.activate(owner,target);check(qf0.launches==1);
  owner.busy=false;zl5.active=true;MultiChipActions.activate(owner,target);check(qf0.launches==1 && owner.error.contains("关闭 Wi-Fi"));zl5.active=false;
  ak2.activationLabel=null;target.b=false;MultiChipActions.render(owner,target,c);check(ak2.activationLabel==null);
  target.b=true;owner=new iz3(new MultiChipSwitchTest.Chip("one"));MultiChipActions.render(owner,target,c);check(ak2.activationLabel==null);
  check(c.depth==0);
  System.out.println("PASS: "+passed+" explicit cross-chip activation assertions");
 }
}
