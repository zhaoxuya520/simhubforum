package cc.forserein.simhub.internal;

import java.lang.reflect.*;
import java.util.*;

/** Explicit activation of an already-enabled profile; browsing chips never changes a card. */
public final class MultiChipActions {
    private MultiChipActions(){}
    private interface Action{Object run(Object[] args)throws Exception;}
    private static Class<?> type(String name)throws Exception{return name.equals("int")?int.class:Class.forName(name);}
    private static Object call(String owner,String name,String[] types,Object target,Object...args)throws Exception {
        Class<?>[] signature=new Class<?>[types.length];for(int i=0;i<types.length;i++)signature[i]=type(types[i]);
        return type(owner).getMethod(name,signature).invoke(target,args);
    }
    private static Object get(Object o,String field)throws Exception{return o.getClass().getField(field).get(o);}
    private static Object unit()throws Exception{return type("sc5").getField("a").get(null);}
    private static Object function(String iface,Action action)throws Exception {
        Class<?> c=type(iface);
        return Proxy.newProxyInstance(c.getClassLoader(),new Class<?>[]{c},(proxy,m,args)->{
            if(m.getDeclaringClass()==Object.class){
                if(m.getName().equals("equals"))return proxy==args[0];
                if(m.getName().equals("hashCode"))return System.identityHashCode(proxy);
                return "MultiChipAction";
            }
            return action.run(args==null?new Object[0]:args);
        });
    }
    private static Object invoke(Object owner,String name)throws Exception{return owner.getClass().getMethod(name).invoke(owner);}
    private static void error(Object owner,String message){try{owner.getClass().getMethod("G",String.class).invoke(owner,message);}catch(Exception ignored){}}
    public static void activate(Object owner,Object target) {
        try {
            if(Boolean.TRUE.equals(invoke(owner,"u")))return;
            if(Boolean.TRUE.equals(call("zl5","k",new String[]{},null))){error(owner,"请先关闭 Wi-Fi 通话，再执行跨芯片切换");return;}
            Object close=function("us1",args->unit());
            // Reuse the original launch/safety route; its cg0 operation is already coordinated.
            Object action=type("qf0").getConstructor(type("iz3"),type("qy3"),boolean.class,boolean.class,type("ws1"),type("us1"))
                .newInstance(owner,target,true,false,null,close);
            invoke(action,"a");
        }catch(Exception e){error(owner,"跨芯片切换未能启动，请刷新后重试（"+e.getClass().getSimpleName()+"）");}
    }
    public static void render(Object owner,Object target,Object composer) {
        try {
            call("lu1","e0",new String[]{"int"},composer,0x2168c003);
            try {
                if(((List<?>)invoke(owner,"l")).size()>1 && Boolean.TRUE.equals(get(target,"b"))) {
                    Object click=Boolean.TRUE.equals(invoke(owner,"u"))?null:function("us1",args->{activate(owner,target);return unit();});
                    call("ak2","b",new String[]{"java.lang.String","java.lang.String","us1","fl0","lu1","int","int"},null,
                        "只启用此配置","",click,null,composer,0,8);
                }
            }finally {
                Object scope=call("lu1","u",new String[]{},composer);
                if(scope!=null)scope.getClass().getField("d").set(scope,function("kt1",args->{render(owner,target,args[0]);return unit();}));
            }
        }catch(Exception e){throw new IllegalStateException("跨芯片操作入口载入失败",e);}
    }
}
