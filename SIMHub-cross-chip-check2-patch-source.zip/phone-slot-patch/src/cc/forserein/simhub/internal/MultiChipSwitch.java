package cc.forserein.simhub.internal;

import java.util.*;

/** Coroutine-independent transaction state; every list is freshly read before planning changes. */
public final class MultiChipSwitch {
    private final Object controller, target;
    private Object backend;
    private static final Map<Object,MultiChipSwitch> ACTIVE=new WeakHashMap<>();
    private static final ThreadLocal<Object> SELECTING=new ThreadLocal<>();
    public static boolean shouldCoordinate(Object owner,Object backend)throws Exception {
        int count=((List<?>)invoke(owner,"l")).size();
        log(backend,"切卡入口：chips="+count+" transport="+get(backend,"a").getClass().getSimpleName());
        return count>1;
    }
    public static MultiChipSwitch create(Object owner,Object backend,Object target,boolean enable)throws Exception {
        MultiChipSwitch p=new MultiChipSwitch(owner,target,enable);p.backend=backend;
        synchronized(ACTIVE){if(ACTIVE.containsKey(owner))throw new IllegalStateException("已有跨芯片操作正在执行");ACTIVE.put(owner,p);}
        p.trace("开始 "+(enable?"启用":"禁用")+" ICCID="+IdentityBinding.tail((String)get(target,"a")));
        return p;
    }
    public static boolean allowSelection(Object owner){synchronized(ACTIVE){return !ACTIVE.containsKey(owner)||SELECTING.get()==owner;}}
    private static void log(Object backend,String message){
        if(backend==null)return;
        try{backend.getClass().getMethod("u",String.class).invoke(backend,"[跨芯片] "+message);}catch(Exception ignored){}
    }
    private void trace(String message){log(backend,message);}
    public static void verifyEid(String expected,String actual){
        if(expected==null||actual==null||!expected.equals(actual))throw new IllegalStateException("管理通道 EID 不匹配：目标 "+IdentityBinding.tail(expected)+"，实际 "+IdentityBinding.tail(actual)+"，已停止切卡");
    }
    public String readingEid(){return reading;}
    private void release(){synchronized(ACTIVE){if(ACTIVE.get(controller)==this)ACTIVE.remove(controller);}}

    private final boolean enable;
    private final List<String> chips=new ArrayList<>();
    private final Map<String,List<?>> observed=new LinkedHashMap<>();
    private final List<Object> disable=new ArrayList<>();
    private String targetChip, reading;
    private int scan, mutation, phase;
    public int kind; // 0 done, 1 read selected chip, 2 original profile operation
    public Object profile;
    public boolean enabled;
    public MultiChipSwitch(Object controller,Object target,boolean enable) throws Exception {
        this.controller=controller;this.target=target;this.enable=enable;
        String wanted=(String)get(target,"a");
        for(Object chip:(List<?>)invoke(controller,"l")) {
            String eid=(String)get(chip,"b");
            if(chips.contains(eid))throw new IllegalStateException("芯片标识重复，请重新连接读卡器");
            chips.add(eid);
            for(Object p:(List<?>)get(chip,"d"))if(wanted.equals(get(p,"a"))) {
                if(targetChip!=null)throw new IllegalStateException("配置标识重复，无法确定目标芯片");
                targetChip=eid;
            }
        }
        if(targetChip==null)throw new IllegalStateException("目标配置已变化，请刷新后重试");
    }
    private static Object get(Object o,String f)throws Exception{return o.getClass().getField(f).get(o);}
    private static Object invoke(Object o,String name)throws Exception{return o.getClass().getMethod(name).invoke(o);}
    private void select(String eid)throws Exception {
        if(backend!=null && get(controller,"d")!=backend)throw new IllegalStateException("读卡器连接已改变，停止切卡");
        Object previous=SELECTING.get();SELECTING.set(controller);
        try{controller.getClass().getMethod("D",String.class).invoke(controller,eid);}
        finally{if(previous==null)SELECTING.remove();else SELECTING.set(previous);}
        if(!eid.equals(invoke(controller,"r")))throw new IllegalStateException("芯片选择失败，请重新连接读卡器");
        trace("选择 EID="+IdentityBinding.tail(eid));
    }
    private void publish(List<?> list)throws Exception {
        controller.getClass().getMethod("J",List.class).invoke(controller,list);
        invoke(controller,"K");
    }
    /** Called after the previous suspend operation completed successfully. */
    public void next(Object result)throws Exception {
        if(reading!=null) {
            if(!(result instanceof List))throw new IllegalStateException("未能读取芯片配置，停止切换");
            List<?> list=new ArrayList<>((List<?>)result);
            Set<String> ids=new HashSet<>();
            for(Object p:list)if(!ids.add((String)get(p,"a")))throw new IllegalStateException("芯片配置标识重复");
            int active=0;for(Object p:list)if(Boolean.TRUE.equals(get(p,"b"))){active++;trace("读回 EID="+IdentityBinding.tail(reading)+" 启用 ICCID="+IdentityBinding.tail((String)get(p,"a")));}
            trace("读取 EID="+IdentityBinding.tail(reading)+" profiles="+list.size()+" enabled="+active);
            observed.put(reading,list);publish(list);reading=null;
        }
        if(phase==0) {
            if(scan<chips.size()){reading=chips.get(scan++);select(reading);kind=1;return;}
            boolean found=false;
            String wanted=(String)get(target,"a");
            for(Map.Entry<String,List<?>> entry:observed.entrySet())for(Object p:entry.getValue()) {
                boolean isTarget=entry.getKey().equals(targetChip)&&wanted.equals(get(p,"a"));
                found|=isTarget;
                if(enable && !isTarget && Boolean.TRUE.equals(get(p,"b")))disable.add(p);
            }
            if(!found)throw new IllegalStateException("目标配置已不存在，请刷新后重试");
            phase=1;
        }
        if(phase==1) {
            if(mutation<disable.size()) {
                profile=disable.get(mutation++);enabled=false;
                select(owner(profile));trace("发送禁用 ICCID="+IdentityBinding.tail((String)get(profile,"a")));kind=2;return;
            }
            select(targetChip);profile=target;enabled=enable;trace("发送目标命令 ICCID="+IdentityBinding.tail((String)get(profile,"a"))+" enable="+enable);kind=2;phase=2;return;
        }
        if(phase==2){phase=3;scan=0;observed.clear();}
        if(scan<chips.size()){reading=chips.get(scan++);select(reading);kind=1;return;}
        String wanted=(String)get(target,"a");boolean targetSeen=false;
        for(Map.Entry<String,List<?>> entry:observed.entrySet())for(Object p:entry.getValue()) {
            boolean active=Boolean.TRUE.equals(get(p,"b"));
            boolean isTarget=entry.getKey().equals(targetChip)&&wanted.equals(get(p,"a"));
            if(isTarget){targetSeen=true;if(active!=enable)throw new IllegalStateException("目标配置状态未确认，请刷新后重试");}
            else if(enable && active)throw new IllegalStateException("仍检测到其他启用配置，请刷新确认后重试");
        }
        if(!targetSeen)throw new IllegalStateException("目标配置状态未确认");
        select(targetChip);kind=0;trace("完成：已核对全部芯片状态");release();
    }
    private String owner(Object profile)throws Exception {
        for(Map.Entry<String,List<?>> entry:observed.entrySet())if(entry.getValue().contains(profile))return entry.getKey();
        throw new IllegalStateException("配置所属芯片已变化");
    }
    public void restore(){try{select(targetChip);trace("中止：保留实际读回状态，请查看错误原因");}catch(Exception ignored){/* preserve original failure */}finally{release();}}
}
